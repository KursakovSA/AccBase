﻿namespace WB;
[Serializable]
public partial class Sign : Shell
{//созд - 2021, изм - 22.07.2022
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    public Sign()
    {//созд - 2022, изм - 23.07.2022
        //public ctor не может содержать ничего, кроме присваивания простых значений
    }
    public Sign(int? id = default, Sign? parent = default, DateTimeOffset? date1 = default, string? date2 = default, string? code = default, string? description = default, Role? role = default, Info? info = default, string? more = default)
    {//созд - 2022, изм - 23.07.2022
        Id = id;
        Parent = parent;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        Role = role;
        Info = info;
        More = more;
    }
    static Sign()
    {//созд - 2022, изм - 23.07.2022
        //static ctor не может содержать ничего, кроме присваивания простых значений
    }
    public static Sign TestSign()
    {//созд - 2022, изм - 21.07.2022
        Sign outSign = new();

        //TraceState(outSign, "TestSign(...), outSign ");
        return outSign;
    }
    public override string ToString()
    {
        return $"{GetType()}, {Id.ToString() ?? "No Id"}, {Parent?.ToString() ?? "No Parent"}, {Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"} ";
    }
}
