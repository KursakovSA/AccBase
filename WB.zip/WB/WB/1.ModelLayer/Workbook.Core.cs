﻿namespace WB;
[Serializable]
public partial class Workbook : Shell
{//созд - 2021, изм - 22.07.2022
    public Face? Face1 { get; set; }
    public Face? Face2 { get; set; }
    public Face? Face { get; set; }
    public Slice? Slice { get; set; }
    public Geo? Geo { get; set; }
    public Sign? Sign { get; set; }
    public Account? Account { get; set; }
    public Workbook? Workbook1 { get; set; }
    public Process? Process1 { get; set; }
    public Tax? Tax { get; set; }
    public Item? Item { get; set; }
    public Deal? Deal { get; set; }
    public Price? Price { get; set; }
    public Asset? Asset { get; set; }
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    public Meter? Meter { get; set; }
    public string? MeterValue { get; set; }
    public Unit? Unit { get; set; }
    public Mark? Mark { get; set; }
    public Workbook()
    {//созд - 2021, изм - 23.07.2022
        //public ctor не может содержать ничего, кроме присваивания простых значений
    }
    public Workbook(int? id = default, Workbook? parent = default, Face? face1 = default, Face? face2 = default, Face? face = default, DateTimeOffset? date1 = default, string? date2 = default, string? code = default, string? description = default, Slice? slice = default, Geo? geo = default, Sign? sign = default, Account? account = default, Workbook? workbook1 = default, Process? process1 = default, Asset? asset = default, Deal? deal = default, Item? item = default, Tax? tax = default, Price? price = default, Role? role = default, Info? info = default, Meter? meter = default, string? metervalue = default, Unit? unit = default, string? more = default)
    {//созд - 2021, изм - 23.07.2022
        Id = id;
        Parent = parent;
        Face1 = face1;
        Face2 = face2;
        Face = face;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        Slice = slice;
        Geo = geo;
        Sign = sign;
        Account = account;
        Workbook1 = workbook1;
        Process1 = process1;
        Asset = asset;
        Deal = deal;
        Item = item;
        Tax = tax;
        Price = price;
        Role = role;
        Info = info;
        Meter = meter;
        MeterValue = metervalue;
        Unit = unit;
        More = more;
    }
    static Workbook()
    {//созд - 2022, изм - 23.07.2022
        //static ctor не может содержать ничего, кроме присваивания простых значений
    }
    public static double? Turnover<Workbook>(List<Workbook> inLog)
    {
        double? outTurnover = default;

        //TraceState(outTurnover, "Workbook.Turnover(...), outTurnover ");
        return outTurnover;
    }
    public static Workbook TestWorkbook()
    {//созд - 2022, изм - 21.07.2022
        Workbook outWorkbook = new();

        //TraceState(outWorkbook, "TestWorkbook(...), outWorkbook ");
        return outWorkbook;
    }
    public override string ToString()
    {
        return $"{GetType()}, {Id.ToString() ?? "No Id"}, {Parent?.ToString() ?? "No Parent"}, " +
            $"{Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"} ";
    }
}
