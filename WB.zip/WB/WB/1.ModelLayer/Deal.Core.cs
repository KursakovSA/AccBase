﻿namespace WB;
[Serializable]
public partial class Deal : Shell
{//созд - 2021, изм - 24.07.2022
    public Face? Face1 { get; set; }
    public Face? Face2 { get; set; }
    public Face? Face { get; set; }
    public Geo? Geo { get; set; }
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    public List<Deal>? Delivery = new(); //TODO
    public List<Deal>? Movement = new(); //TODO
    public Deal()
    {//созд - 2021, изм - 23.07.2022
        //public ctor не может содержать ничего, кроме присваивания простых значений
    }
    public Deal(int? id = default, Deal? parent = default, Face? face1 = default, Face? face2 = default, Face? face = default, Geo? geo = default, DateTimeOffset? date1 = default, string? date2 = default, string? code = default, string? description = default, Role? role = default, Info? info = default, string? more = default)
    {//созд - 2021, изм - 23.07.2022
        //public ctor не может содержать ничего, кроме присваивания простых значений
        Id = id;
        Parent = parent;
        Face1 = face1;
        Face2 = face2;
        Face = face;
        Geo = geo;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        Role = role;
        Info = info;
        More = more;
    }
    static Deal()
    {//созд - 2022, изм - 23.07.2022
        //static ctor не может содержать ничего, кроме присваивания простых значений
    }
    public static Deal TestDeal()
    {//созд - 2021, изм - 21.07.2022
        //public ctor не может содержать ничего, кроме присваивания простых значений
        Deal outDeal = new();

        //TraceState(outDeal, "TestDeal(...), outDeal ");
        return outDeal;
    }
    public override string ToString()
    {
        return $"{GetType()}, {Id.ToString() ?? "No Id"}, {Parent?.ToString() ?? "No Parent"}, " +
            $"{Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"} ";
    }
}
