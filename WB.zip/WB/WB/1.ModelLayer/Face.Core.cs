﻿namespace WB;
[Serializable]
public partial class Face : Shell
{//созд - 2021, изм - 29.07.2022
    public Face? Face1 { get; set; }
    public Face? Face2 { get; set; }
    public Geo? Geo { get; set; }
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    public static List<Face> StoreBasic = new(); //TODO
    public List<Face> Store = new(); //TODO
    public static List<Face> UserBasic = new(); //TODO
    public static List<Face> DepartmentBasic = new(); //TODO
    public static List<Face> CashBasic = new(); //TODO
    public static List<Face> BankBasic = new(); //TODO
    public static List<Face> StaffTable = new();  //TODO
    public List<Face>? Staff = new();  //TODO
    public List<Workbook>? Address = new(); //TODO
    public List<Workbook>? TaxModeFace; //TODO
    public Face()
    {//созд - 2021, изм - 23.07.2022
        //public ctor не может содержать ничего, кроме присваивания простых значений
    }
    public Face(int? id = default, Face? parent = default, Face? face1 = default, Face? face2 = default, Geo? geo = default, DateTimeOffset? date1 = default, string? date2 = default, string? code = default, string? description = default, Role? role = default, Info? info = default, string? more = default)
    {//созд - 2021, изм - 29.07.2022
        Id = id;
        Parent = parent;
        Face1 = face1;
        Face2 = face2;
        Geo = geo;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        Role = role;
        Info = info;
        More = more;
    }
    static Face()
    {//созд - 2021, изм - 23.07.2022
        //static ctor не может содержать ничего, кроме присваивания простых значений
    }
    public static Workbook? GetTaxModeFaceValue(DateTime Date1, string? Date2, Face? Face, Tax? Tax) //TODO
    {//созд - 2021, изм - 29.07.2022
        Workbook? TaxModeFaceValue = default;

        TraceState(TaxModeFaceValue, "GetTaxModeFaceValue(...), TaxModeFaceValue ");
        return TaxModeFaceValue;
    }
    public static Face TestFace()
    {//созд - 2022, изм - 21.07.2022
        Face outFace = new();

        //TraceState(outFace, "TestFace(...), outFace ");
        return outFace;
    }
    public override string ToString()
    {
        return $"{GetType()}, {Id.ToString() ?? "No Id"}, {Parent?.ToString() ?? "No Parent"}, {Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"} ";
    }
}
