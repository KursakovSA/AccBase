﻿namespace WB;
[Serializable]
public partial class Debt : Shell
{//созд - 2021, изм - 02.02.2023
    public Face? Face1 { get; set; }
    public Face? Face2 { get; set; }
    public Geo? Geo { get; set; }
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    public Debt? Base = default; //TODO
    public Debt? Rate = default; //TODO
    public Debt? Mode = default; //TODO
    public Debt? Deduction = default; //TODO
    public Debt? GetTaxMode(DateTime Date1, string? Date2, Debt? Debt) //TODO
    {//созд - 2021, изм - 02.02.2023
        Debt? TaxMode = default;

        //TraceState(TaxMode, "GetTaxMode(...), TaxMode ");
        return TaxMode;
    }
    public decimal? GetTaxBaseMinLimitValue(DateTime Date1, string? Date2, Debt? TaxBase) //TODO
    {//созд - 01.12.2022, изм - 02.02.2023
        decimal? TaxBaseMinLimitValue = default;

        //TraceState(TaxBaseMinLimitValue, "GetTaxBaseMinLimitValue(...), TaxBaseMinLimitValue ");
        return TaxBaseMinLimitValue;
    }
    public decimal? GetTaxBaseMaxLimitValue(DateTime Date1, string? Date2, Debt? TaxBase) //TODO
    {//созд - 01.12.2022, изм - 02.02.2023
        decimal? TaxBaseMaxLimitValue = default;

        //TraceState(TaxBaseMaxLimitValue, "GetTaxBaseMaxLimitValue(...), TaxBaseMaxLimitValue ");
        return TaxBaseMaxLimitValue;
    }
    public decimal? GetTaxBaseExistValue(DateTime Date1, string? Date2, Debt? TaxBase) //TODO
    {//созд - 01.12.2022, изм - 02.02.2023
        decimal? TaxBaseValue = default;

        //TraceState(TaxBaseExistValue, "GetTaxBaseValue(...), TaxBaseValue ");
        return TaxBaseValue;
    }
    public decimal? GetTaxBaseValue(DateTime Date1, string? Date2, Debt? Tax) //TODO
    {//созд - 2021, изм - 02.02.2023
        decimal? TaxBaseValue = default;

        //TraceState(TaxBaseValue, "GetTaxBaseValue(...), TaxBaseValue ");
        return TaxBaseValue;
    }
    public static decimal? GetTaxRateDefaultValue(DateTime? Date1, string? TaxRateCode)
    {//созд - 28.11.2022, изм - 02.02.2023
        decimal? outTaxRateDefaultValue = 0;

        ////TODO - сделать твердые ставки по разным видам налогов в зависимости от кода ставки налога

        outTaxRateDefaultValue = SetZeroIfNegative(outTaxRateDefaultValue);  //приравниваем нулю, если отрицательное
        //TraceState(outTaxRateDefaultValue, "GetTaxRateDefaultValue(...), outTaxRateDefaultValue ");
        return outTaxRateDefaultValue;
    }
    public static decimal? GetTaxRateValue(DateTime? Date1, string? TaxRateCode)
    {//созд - 28.11.2022, изм - 02.02.2023
        decimal? outTaxRateValue = GetTaxRateDefaultValue(Date1, TaxRateCode);

        ////TODO - сделать выборку из внешнего файла ставок налогов

        outTaxRateValue = SetZeroIfNegative(outTaxRateValue);  //приравниваем нулю, если отрицательное
        //TraceState(outTaxRateValue, "GetTaxRateValue(...), outTaxRateValue ");
        return outTaxRateValue;
    }
    //public decimal? GetTaxRateValue(DateTime Date1, string? Date2, Tax? Tax) //TODO
    //{
    //    decimal? TaxRateValue = default;

    //    //TraceState(TaxRateValue, "GetTaxRateValue(...), TaxRateValue ");
    //    return TaxRateValue;
    //}
    public decimal? GetTaxDeductionExistValue(DateTime Date1, string? Date2, Debt? TaxDeduction) //TODO
    {//созд - 01.12.2022, изм - 23.01.2023
        decimal? TaxDeductionExistValue = default;

        //TraceState(TaxDeductionExistValue, "GetTaxDeductionExistValue(...), TaxDeductionExistValue ");
        return TaxDeductionExistValue;
    }
    public decimal? GetTaxDeductionValue(DateTime Date1, string? Date2, Debt? TaxDeduction) //TODO
    {//созд - 2021, изм - 23.01.2023
        decimal? TaxDeductionValue = default;

        //TraceState(TaxDeductionValue, "GetTaxDeductionValue(...), TaxDeductionValue ");
        return TaxDeductionValue;
    }
    public Debt()
    {//созд - 2021, изм - 23.01.2023
        //public ctor не может содержать ничего, кроме присваивания простых значений
    }
    public Debt(int? id = default, Debt? parent = default, Face? face1 = default, Face? face2 = default, Geo? geo = default, DateTime? date1 = default, string? date2 = default, string? code = default, string? description = default, Role? role = default, Info? info = default, string? more = default)
    {//созд - 2021, изм - 02.02.2023
        Id = id;
        Parent = parent;
        Face1 = face1;
        Face2 = face2;
        Geo = geo;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        Role = role;
        Info = info;
        More = more;
    }
    static Debt()
    {//созд - 2022, изм - 23.01.2023
        //static ctor не может содержать ничего, кроме присваивания простых значений
    }
    public static Debt TestDebt()
    {//созд - 2022, изм - 23.01.2023
        Debt outDebt = new();

        //TraceState(outDebt, "TestDebt(...), outDebt ");
        return outDebt;
    }
    public override string ToString()
    {
        return $"{GetType()}, {Id.ToString() ?? "No Id"}, {Parent?.ToString() ?? "No Parent"}, " +
            $"{Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"} ";
    }
}
