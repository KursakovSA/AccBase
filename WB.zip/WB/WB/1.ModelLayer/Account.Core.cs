﻿namespace WB;
[Serializable]
public partial class Account : Shell
{//созд - 2021, изм - 02.02.2023
    public Slice? Slice { get; set; }
    public Role? Role { get; set; }
    public Sign? Sign { get; set; }
    public Account? AccountTable { get; set; }
    public Account()
    {//созд - 2021, изм - 23.07.2022
        //public ctor не может содержать ничего, кроме присваивания простых значений
    }
    public Account(int? id = default, Account? parent = default, DateTime? date1 = default, string? date2 = default, string? code = default, string? description = default, string? more = default, Role? role = default, Sign? sign = default, Account? accountTable = default)
    {//созд - 2021, изм - 02.02.2023
        //public ctor не может содержать ничего, кроме присваивания простых значений
        Id = id;
        Parent = parent;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        More = more;
        Role = role;
        Sign = sign;
        AccountTable = accountTable;
    }
    static Account()
    {//созд - 2022, изм - 23.07.2022
        //static ctor не может содержать ничего, кроме присваивания простых значений
    }
    public static Account TestAccount()
    {//созд - 2022, изм - 23.07.2022
        Account outAccount = new();
        //TraceState(outAccount, "TestAccount(...), outAccount ");
        return outAccount;
    }
    public override string ToString()
    {
        return $"{GetType()}, {Id?.ToString() ?? "No Id"}, {Parent?.Code?.ToString() ?? "No Parent"}, {Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"}, {AccountTable?.Description ?? "No AccountTable"}";
    }
}
