﻿//public static List<string>? ListBaseEmergency = new() //список баз на экземпляре МС СКЛ,  если из внешнего файла Connection ничего не поступило
//{//созд - 2022, изм - 2022
//    @"BaseN1",
//    @"BaseN2",
//    @"BaseN3",
//};
//public static List<string>? ListDataSourceEmergency = new() //DataSource для учетных баз, если из внешнего файла Connection ничего не поступило 
//{//созд - 2022, изм - 07.08.2022
//    @".\SQLEXPRESS",
//    @"(local)",
//};

//public static string FormatTraceItem(Shell? TraceItem)
//{//созд - 2022, изм - 27.07.2022
//    string outStrTraceItem = "";
//    //outStrTraceItem += TraceItem?.Code + ", " + TraceItem?.Description;
//    outStrTraceItem += TraceItem?.Description + ", " + TraceItem?.Code;
//    outStrTraceItem += Environment.NewLine;
//    return outStrTraceItem;
//}

//public static void AddTraceTime()
//{//созд - 2022, изм - 2022
//    if (StartTestTime != DateTimeOffset.MinValue)
//    {
//        if (FinishTestTime != DateTimeOffset.MinValue)
//        {
//            TraceState(StartTestTime, "Main, Program, StartTestTime ");
//            TraceState(FinishTestTime, "Main, Program, FinishTestTime ");
//            //SpanTestTime = (TimeSpan)(FinishTestTime - StartTestTime);
//            SpanTestTime = (TimeSpan)GetSpanTime(FinishTestTime, StartTestTime);
//            //TraceState((uint)SpanTestTime.Seconds, "Main, Program, SpanTestTime, sec. ");
//            TraceState(SpanTestTime, "Main, Program, SpanTestTime, sec. ");
//        }
//    }
//}

//{//созд - 2022, изм - 26.07.2022

//public static Abc? GetAbc(List<Abc>? inAbc, string? templateCode = null, string? templateDescription = null, string? templateMore = null)  //TODO - получение единичного Abc  ???   
//{//созд - 2022, изм - 24.07.2022
//    Abc outAbc = new();
//    if ((templateCode is not null) || (templateDescription is not null) || (templateMore is not null))
//    {
//        if (templateCode is not null)//если ищем в списке Авс элемент по совпадению Code 
//        {
//            templateCode = templateCode.Trim();
//            IEnumerable<Abc> subset = from g in inAbc let code = g.Code where code.Contains(templateCode) select g;
//            foreach (var s in subset)
//            {
//                outAbc = s;
//            }
//        }
//        if (templateDescription is not null)//если ищем в списке Авс элемент по совпадению Description 
//        {
//            templateDescription = templateDescription.Trim();
//            IEnumerable<Abc> subset = from g in inAbc let code = g.Code where code.Contains(templateDescription) select g;
//            foreach (var s in subset)
//            {
//                outAbc = s;
//            }
//        }
//        if (templateMore is not null)//если ищем в списке Авс элемент по совпадению More 
//        {
//            templateMore = templateMore.Trim();
//            IEnumerable<Abc> subset = from g in inAbc let code = g.Code where code.Contains(templateMore) select g;
//            foreach (var s in subset)
//            {
//                outAbc = s;
//            }
//        }
//    }

//    //TraceState(outAbc, "GetABC(...), outAbc");
//    return outAbc;
//}

//string? strTable = "Account";
//string? templMore;
//templMore = "'%" + strTable + ".Basic%'";//компонуем строку фильтра More для запроса типа "'%Account.Basic%'"
//List<Shell> AccountBasic = GetTable(conn: MainConnCurr, strTable, templateMore:templMore);
//TraceState(AccountBasic.Count, "Program.Test(...), AccountBasic");

//templMore = "'%" + strTable + ".Catalog%'";
//List<Shell> AccountCatalog = GetTable(conn: MainConnCurr, strTable, templateMore: templMore);
//TraceState(AccountCatalog.Count, "Program.Test(...), AccountCatalog");

//public static List<Abc>? GetAbcTable(SqlConnection conn, string strTable)//отбор Abc по принципу - это все строки таблицы с More = basic, в 1-м экземпляре, хотя та же строка может быть и други типом Abc, например, switch
//{//созд - 2022, изм - 18.07.2022
//    string? templMore = "'%" + strTable + ".Basic%'";//компонуем строку фильтра More для запроса типа "'%Account.Basic%'"
//    //templMore = "'%" + strTable + ".table%'";//например, для проверки, для Account/Table = 2
//    List<Shell>?  ListShell = GetTable(conn, strTable, templateMore: templMore);
//    List<Abc>? outAbc = new();
//    foreach (Shell? shl in ListShell)
//    {
//        outAbc.Add(new Abc { Id = shl.Id, Parent = shl.Parent, Date1 = shl.Date1, Date2 = shl.Date2, Code = shl.Code, Description = shl.Description, More = shl.More });
//    }
//    //TraceState(ListShell.Count + "/" + strTable.ToString() + "/" +templMore, "GetAbcTable(...), ListShell.Count / strTable / templateMore");
//    //TraceState(outAbc.Count, "GetAbcTable(...), outAbc");
//    return outAbc;
//}

//public Abc(int? id = default, Abc? parent = default, DateTimeOffset? date1 = default, string? date2 = default, string? code = default, string? description = default, string? more = default)
//{
//    Id = id;
//    Parent = parent;
//    Code = code;
//    Date1 = date1;
//    Date2 = date2;
//    Description = description;
//    More = more;
//}

//public static void GetAbcDb()
//{//созд - 2022, изм - 24.07.2022
//    //TODO --- потом как-нибудь может быть сделать что-то типа делегата, энуменатора, указание на метод в зависимости от наим-я таблицы
//    Account.Abc = GetAbcTable(conn: MainConnCurr, "Account");
//    TraceState(Account.Abc?.Count(), "Abc.GetAbcDb(...), Account.Abc?.Count() ");
//    //Account.Root = (Account?)GetRoot(GetAbc(Account.Abc, templateCode: "Account"));
//    //TraceState(Account.Root, "Abc.GetAbcDb(...), Account.Root ");

//    Asset.Abc = GetAbcTable(conn: MainConnCurr, "Asset");
//    TraceState(Asset.Abc?.Count(), "Abc.GetAbcDb(...), Asset.Abc?.Count() ");
//}

//public static void GetRootDb()
//{
//    Account.Root = (Account?)GetRoot(GetAbc(Account.Abc, templateCode: "Account"));
//    TraceState(Account.Root?.ToString(), "Abc.GetRootDb(...), Account.Root ");

//    Asset.Root = (Asset?)GetRoot(GetAbc(Asset.Abc, templateCode: "Asset"));
//    TraceState(Asset.Root?.ToString(), "Abc.GetRootDb(...), Asset.Root ");
//}

//public static Shell? GetRoot(Abc? inAbc)
//{//созд - 2022, изм - 24.07.2022
//    Shell? outRoot = new()
//    {
//        Id = inAbc?.Id,
//        Parent = null,  //родителя у элемента Root нет
//        Date1 = inAbc?.Date1,
//        Date2 = inAbc?.Date2,
//        Code = inAbc?.Code,
//        Description = inAbc?.Description,
//        More = inAbc?.More,
//    };
//    return outRoot;
//}

//сериализация JSON
//..https://metanit.com/sharp/tutorial/6.5.php

//public int? Id { get; set; }
//public Shell? Parent { get; set; }
//private DateTimeOffset? date1;
//public DateTimeOffset? Date1
//{
//    get => date1;
//    set => date1 = FixDate(value);
//}
//private string? date2;
//public string? Date2
//{
//    get => date2;
//    set => date2 = FixTrim(value);
//}
//private string? code;
//public string? Code
//{
//    get => code;
//    set => code = FixTrim(value);
//}
//private string? description;
//public string? Description
//{
//    get => description;
//    set => description = FixTrim(value);
//}
//private string? more;
//public string? More
//{
//    get => more;
//    set => more = FixTrim(value);
//}

//static Account()
//{
//    //CurrentTable = Basic[key: "AccTable2019"];  ////TODO - надо как-то 
//}

//public static Account? FixParent(Account? inParent = default) //комм - 07.07.2022
//{
//    //Account? outParent = inParent ?? new Account { };
//    Account? outParent = inParent ?? Account.Root;

//    //TraceState(outParent, "Account.FixParent(...), FixParent.outParent ");
//    return outParent;
//}

//public StringBuilder SwiftOPV(Workbook? WorkbookSalary = default)
//{//созд - 2021
//    StringBuilder TextSwift = new();
//    Exchange SwiftOPV = Basic[key: "Role.Exchange.SwiftOPV"];
//    SwiftOPV.TargetFile = @"Swift_OPV.txt";
//    SwiftOPV.TargetExchange = GetTargetExchangeValue(TargetPath, TargetFile);
//    TODO - выгрузка свифт файла для ОПВ

//    TraceState(TextSwift, "SwiftOPV(...), TextSwift ");
//    return TextSwift;
//}

////IEnumerable<Account> subset = from g in ListTable where g.More.Contains("basic") orderby g select g;
//IEnumerable<Account> subset = from g in ListTable select g;
//var subset = from g in ListTable select g;
//foreach (var s in ListTable)
//{
//    Console.WriteLine($"ListTable.Key:{s.Key}, ListTable.Value:{s.Value}");
//    Console.ReadLine();
//}

//static Price()
//{
//    Markup.Add("Price.MarkupBasic", Price.Basic[key: "Price.MarkupBasic"]);
//    Sale.Add("Price.SaleBasic", Price.Basic[key: "Price.SaleBasic"]);
//}

//public string? FixDescription(string? inDescr = "")
//{
//    string? FixDescr = inDescr?.Trim() ?? "";

//    //TraceState(FixDescr, "Shell.FixDescription(...), FixDescr ");
//    return FixDescr;
//}
//public string? FixCode(string? inCode = "")
//{
//    string? FixCode = inCode?.Trim() ?? "";

//    //TraceState(FixCode, "Shell.FixCode(...), FixCode ");
//    return FixCode;
//}

//public static void FromClipboardToStringForBasic()
//{
//    //запрашиваем блок строк с переносами, вводимый из буфера обмена
//    //делаем из этой строки массив с кавычками по 5 элементов  
//    //это нужно для быстрого импорта строк в ctor static basic-поля из XLS-файлов
//    var DataObject = Clipboard.GetDataObject();
//    if (DataObject.ToString().Length == 0) return;
//    string text = DataObject.GetData("UnicodeText", true).ToString();
//    string[] Arr = text.Split(new[] { '\n' }, System.StringSplitOptions.RemoveEmptyEntries);
//    string StrToClipboard = "";
//    int Count = 0;
//    foreach (string tmpArr in Arr)
//    {
//        Count++;
//        StrToClipboard += "\"" + tmpArr.Trim() + "\"" + ",";
//        if (Count % 5 == 0)
//        {
//            StrToClipboard += Environment.NewLine;
//        }
//    }
//    if (Count != 0)
//    {
//        Clipboard.SetText(StrToClipboard);
//    }
//}

//public static void Test()
//{//созд - 13.07.2022, изм - 17.07.2022
//    StartTestTime = DateTimeOffset.Now;
//    GetTable(MainConnCurr, "Account");
//    GetTable(MainConnCurr, "Account", templateDescription: "'%налог%'", templateMore: "'%Account.Catalog%'");
//    GetTable(MainConnCurr, "Account", templateMore: "'%Account.Basic%'");

//    GetTableDb(conn: MainConnCurr);
//    GetAbcTable(conn: MainConnCurr, "Account");
//    TestAccount();

//    FinishTestTime = DateTimeOffset.Now;
//    ListDataSource = GetListDataSource();
//    ListConnCurr = GetListConnCurr();
//    TraceState(MainConnCurr.DataSource.ToString(), "Program(...), MainConnCurr.ToString()");

//    TraceState(Exchange.Basic["Role.Exchange.SwiftOPV"], "Exchange.Basic[Role.Exchange.SwiftOPV]");
//    Exchange? exc = new();
//    TraceState(exc, "Exchange.exc");
//    StringBuilder sb = new();
//    sb = exc.SwiftOPV(null);
//}

//public static Dictionary<string, string>? ListPartTab = new()
//{//созд - 2021
//    ["SelectBase"] = "",
//    ["Dialog"] = "",
//    ["Tree"] = "",
//    ["Main"] = "",
//    ["SelectSwitchMark"] = "",
//    ["SelectSwitchSlice"] = "",
//    ["Validation"] = "",
//    ["Filter"] = "",
//};

//public static Dictionary<string, string>? ListAppTab = new()
//{//созд - 2021
//    ["List"] = "List",
//    //["One"] = "One",  //думаю, нет нужды делать отдельный смысл One - List тоже может отображать одну строку, это и будет One   
//    ["Detail"] = "Detail",
//    ["Console"] = "Console",
//};