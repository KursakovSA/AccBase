﻿namespace WB;
[Serializable]
public partial class Conn
{//созд - 2022, изм - 23.01.2023
    public static List<string>? ListBaseTableFact = default; //фактический список учетных баз
    public static List<string> ListBaseTableExpected = new()  //список базовых таблиц ожидаемый  
    {//созд - 2022, изм - 23.01.2023
        "Account", "Asset", "Deal", "Face", "Geo", "Info", "Item", "Mark", "Meter", "Price", "Process",
        "Role", "Sign", "Slice", "Debt", "Unit", "Workbook",
    };
    public static List<string>? GetListDataSource()  //TODO - сделать поиск скл северов и выбор из них  
    {//созд - 2022, изм - 01.01.2023
        List<string>? outListDataSource = default;
        //TODO --- сделать выборку DataSource из внешнего файла Connection
        //если рез-та выборки нет, пытаемся присвоить теоретически возможные DataSource
        if (outListDataSource is null)
        {
            //outListDataSource = ListDataSourceEmergency;
        }

        //TraceState(outListDataSource?.Count, "GetListDataSource(...), outListDataSource?.Count ");
        return outListDataSource;
    }
    public static SqlConnection MainConnCurr = new();  //TODO -- основная Connection из внешнего файла
    public static SqlConnection MainConnDefault = new();
    public static string DataSourceDefault = @".\SQLExpress";
    public static string InitialCatalogDefault = @"BaseN1";
    public static List<SqlConnection>? ListConnCurr = new();
    public static List<string>? ListDataSource = new();
    public static void GetMainConn()
    {//созд - 2022, изм - 01.01.2023
        //MainConnDefault = GetConn(inDataSource: @".\SQLExpress", inInitialCatalog: "BaseN1");
        MainConnDefault = GetConn(inDataSource: DataSourceDefault, inInitialCatalog: InitialCatalogDefault);
        SqlConnection tmpCopyTestedConn = MainConnDefault;
        TestConn(GetConn(inDataSource: DataSourceDefault, inInitialCatalog: InitialCatalogDefault));
        MainConnCurr = MainConnDefault;
        //TestConn(MainConnCurr);
        //MainConnDefault = GetConn();
        //GetMainConnCurr();
        //TraceState(MainConnCurr.ConnectionString, "GetMainConn(...), MainConnCurr.ConnectionString ");
    }
    public static void GetMainConnCurr()  //TODO -- получить основную Connection из внешнего файла, или из иных источников  
    {//созд - 2022, изм - 01.01.2023
        //SqlConnection testedConn = new();
        //if (ListConnCurr is null)  //если из внешнего файла не получено никаких Connection  
        //{
        //bool connIsValid = TestConn(MainConnDefault);
        //if (connIsValid == true)
        //{
            MainConnCurr = MainConnDefault;
            //TODO - для случая false продумать позже  ????
        //}
        //}

        //TraceState(MainConnCurr.ConnectionString, "GetMainConnCurr(...), MainConnCurr.ConnectionString ");
    }
    public static bool TestConn(SqlConnection testedConn)  //проверить Connection
    {//созд - 2022, изм - 01.01.2023
        SqlConnection tmpCopyTestedConn = testedConn;
        bool outTestedConnIsValid = false;  //изначально считаем, что Connection нерабочая
        short? EtalonConnBaseTableCount = (short)ListBaseTableExpected.Count;
        List<string>? ListBaseTableFact = GetListBaseTableFact(tmpCopyTestedConn);
        short? TestedConnBaseTableCount = new();
        if (ListBaseTableFact is not null)
        {
            TestedConnBaseTableCount = (short)ListBaseTableFact.Count;
            if (TestedConnBaseTableCount >= EtalonConnBaseTableCount)  //в текущей БД может быть больше таблиц, чем в эталонной БД
            {
                if (ListBaseTableExpected.SequenceEqual(ListBaseTableFact))
                {
                    outTestedConnIsValid = true;
                }
            }
        }
       
        TraceState(testedConn.ConnectionString +"/"+ outTestedConnIsValid.ToString(), "TestConn(...), testedConn.ConnectionString ");
        return outTestedConnIsValid;
    }
    public static List<SqlConnection>? GetListConnCurr()  //получить список основных Connection из внешнего файла
    {//созд - 2022, изм - 01.01.2023
        List<SqlConnection>? outListConnCurr = new();
        //if ((short)ListConnCurr.Count = 0)
        //{
            outListConnCurr.Add(MainConnCurr);
        //}

        //TraceState(outListConnCurr.Count(), "GetListConnCurr(...), outListConnCurr.Count() ");
        return outListConnCurr;
    }
    public static List<string>? GetListBaseTableFact(SqlConnection conn)  //получить фактический список базовых таблиц для Connection  
    {//созд - 2022, изм - 22.12.2022
        List<string>? outListBaseTableFact = new();
        try
        {
            conn.Open();
            DataTable tbl = conn.GetSchema("Tables");
            foreach (DataRow row in tbl.Rows)
            {
                if (row["TABLE_TYPE"].ToString() == "BASE TABLE")
                {
                    outListBaseTableFact.Add(row["TABLE_NAME"].ToString() ?? "No base table");
                }
            }
            conn.Close();
            conn.Dispose();
            outListBaseTableFact.Sort();
        }
        catch (Exception ex)
        {
            _ = ex.Message;
            //TraceState(ex.Message, "GetListBaseTableFact(...), ex.Message ");
        }
        finally { }
        
        TraceState(outListBaseTableFact.Count(), "GetListBaseTable(...), outListBaseTableFact.Count() ");
        return outListBaseTableFact;
    }
    public static SqlConnection BuildSqlConn(SqlConnectionStringBuilder SqlConnStrBuild)
    {//созд - 2022, изм - 2022
        return new()
        {
            ConnectionString = SqlConnStrBuild.ConnectionString,
        };
    }
    public static SqlConnectionStringBuilder BuildSqlConnStrBuilder(string dataSource, string initialCatalog)  //по умолчанию, если нет никаких данных Connection
    //public static SqlConnectionStringBuilder BuildSqlConnStrBuilder(string dataSource = @".\SQLEXPRESS", string initialCatalog = "BaseN1")  //по умолчанию, если нет никаких данных Connection
    {//созд - 2022, изм - 01.01.2023
        SqlConnectionStringBuilder SqlConnStrBuild = new();
        SqlConnStrBuild.DataSource = dataSource;
        SqlConnStrBuild.InitialCatalog = initialCatalog;
        SqlConnStrBuild.IntegratedSecurity = true;
        //TraceState(SqlConnStrBuild, "BuildSqlConnStrBuilder(...), SqlConnStrBuild() ");
        return SqlConnStrBuild;
    }
    public static SqlConnection GetConn(string inDataSource, string inInitialCatalog)
    //public static SqlConnection GetConn(string inDataSource = @".\SQLEXPRESS", string inInitialCatalog = "BaseN1")
    {//созд - 2022, изм - 22.12.2022
        //получить Connection по DataSource и InitialCatalog, без проверки, просто объект  
        SqlConnection outSqlConn = new();
        SqlConnectionStringBuilder? SqlConnStrBuild = BuildSqlConnStrBuilder(dataSource: inDataSource, initialCatalog: inInitialCatalog);
        outSqlConn = BuildSqlConn(SqlConnStrBuild);

        TraceState(outSqlConn.ConnectionString, "GetConn(...), outSqlConn.ConnectionString ");
        return outSqlConn;
    }
    public Conn() { }
    static Conn() { }
    //public static string? ConnToString(SqlConnection conn)
    //{//созд - 2022, изм - 06.08.2022
    //    //return $"{GetType()}, {conn.ConnectionString ?? "No ConnectionString"}";
    //    //return $"{conn.ConnectionString.ToString() ?? "No ConnectionString"}";
    //    return $"{conn.ConnectionString}";
    //}
}