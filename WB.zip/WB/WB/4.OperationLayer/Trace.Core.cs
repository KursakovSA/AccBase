﻿namespace WB;
[Serializable]
public partial class Trace
{//созд - 2022, изм - 22.12.2022
    public static int eventCounter = 0;
    //private static List<string>? traceList;
    public static List<string>? TraceList = new();
    //public static StringBuilder TraceLog = new StringBuilder("TraceLog Start" + Environment.NewLine + " " + Environment.NewLine);
    //public static void WriteTraceList(List<Shell> trcList)
    //{//созд - 2022, изм - 07.08.2022
    //    DateTimeOffset? predDate1 = null;
    //    //TimeSpan? currSpanTime = new();
    //    foreach (var trc in trcList)
    //    {
    //        TraceLog.Append(GetFormatSecondTimeSpan(GetSecondTimeSpan(GetSpanTime(predDate1, trc?.Date1))) + ", " + trc?.Description + ", " + trc?.Code + Environment.NewLine);
    //        predDate1 = trc?.Date1;
    //    }
    //    TraceLog.Append(" "+ Environment.NewLine + "TraceLog End" + Environment.NewLine);
    //}
    public static string? TraceState(object? Obj, string? ContextObj)
    {//созд - 2021, изм - 22.12.2022
        string? outTraceStateAdd = "";  //добавка к полному листингу Trace
        if (IsDev)
        {
            //AddTraceLog(Obj, ContextObj);
            //AddTraceList(Obj, ContextObj);
            //if ((Obj != null) && (ContextObj != null))
            //{
                eventCounter++;
                outTraceStateAdd = "#" + eventCounter.ToString() +", "+ DateTimeOffset.Now.ToString() + ", " + Obj?.ToString() + ", " + ContextObj?.ToString();
                TraceList?.Add(outTraceStateAdd);  //полный листинг Trace
            //}
        }
        return outTraceStateAdd;
    }
    //public static void AddTraceList(object? Obj = default, string? ContextObj = default)
    //{//созд - 2021, изм - 22.12.2022
    //    TraceList.Add(DateTimeOffset.Now.ToString() + Obj?.ToString() + ContextObj?.ToString());
    //}
    //public static void AddTraceLog(object? Obj = default, string? ContextObj = default)
    //{//созд - 2021, изм - 28.07.2022
    //    string? AddToTraceLog = "";
    //    if ((ContextObj != null) && (Obj != null))
    //    {
    //        AddToTraceLog = $"{ContextObj} = {Obj.ToString()}";
    //    }
    //    if ((AddToTraceLog != null) && (AddToTraceLog != String.Empty))
    //    {
    //        TraceLog.AppendLine(AddToTraceLog);
    //    }
    //}
    static Trace() 
    {
        //TraceList = TraceState(IsDev, "MainWindow(), OnStartApp(), IsDev ");
        //TraceList = default;
    }
    public Trace() { }
    public static string TraceListToString(List<string>? inTraceList)
    {//созд - 22.12.2022, изм - 22.12.2022
        string outTraceListString = "";
        if (inTraceList != null)
        {
            foreach (var trLst in inTraceList)
            {
                outTraceListString = outTraceListString + trLst.ToString() + Environment.NewLine;
            }
        }
        return outTraceListString;
    }
    public override string ToString()
    {
        return TraceListToString(TraceList);
    }
}