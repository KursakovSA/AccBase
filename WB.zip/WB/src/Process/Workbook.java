import java.time.LocalDate;

public class Workbook {
	// origin - 28.09.2023, last edit - 12.10.2025
	public String src, table, id, parent, face1, face2, face, slice, date1, date2, code, description, sign, account;
	public String geo, role, info, debt, item, meter, meterValue, unit, more, mark, process, asset, deal, templateId;
	public boolean isValid, isExist;
	public String docId, outsideDocId; // TODO //this is not dto.id
	// public String outsideDocId; //TODO //ex. [IB1][2024-09-27T06:56:36][#85021],

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Workbook.static ctor, ex=" + ex.getMessage(), "", "Workbook");
		}
	}

	public void fix() throws Exception {
		// origin - 29.12.2024, last edit - 15.09.2025
		try {
			this.mark = DefVal.set(this.mark, "Mark.DD");
			this.slice = DefVal.set(this.slice, "Slice.Accounting");
		} catch (Exception ex) {
			WB.addLog("Workbook.fix():void, ex=" + ex.getMessage(), "", "Workbook");
		}
	}

	public static double getTurn(LocalDate date1, LocalDate date2, ModelDto filter) throws Exception {// TODO
		// origin - 18.10.2023, last edit - 13.06.2025
		// find turn Debt at period from date1 to date2
		// currContext may be equals -- "VAT.Sum", "VAT.Base.Sum", "VAT.Base.MaxLimit",
		// "IncomePersonTax.Dediction".... etc.
		double res = 0.0;
		// TODO - here need do get processRateVAT from WorkDatabase.sqlite3
		res = Etc.roundCustom(res);
		return res;
	}

	public static double getRest(LocalDate date1, LocalDate date2, ModelDto filter) throws Exception {// TODO
		// origin - 18.10.2023, last edit - 19.03.2025
		// find rest Debt on currDate
		// currContext may be equals -- "VAT.Sum", "VAT.Base.Sum", "VAT.Base.MaxLimit",
		// "IncomePersonTax.Dediction".... etc.
		double res = 0.0;
		// TODO - here need do get processRateVAT from WorkDatabase.sqlite3
		res = Etc.roundCustom(res);
		return res;
	}

	public Workbook(String Id) throws Exception {
		// origin - 05.12.2023, last edit - 11.08.2025
		this.clear();
		this.src = this.id = Id;
	}

	public Workbook() throws Exception {
		// origin - 05.12.2023, last edit - 11.08.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 01.05.2025, last edit - 06.09.2025
		try {
			this.table = "Workbook";
			this.src = this.id = this.parent = this.face1 = this.face2 = "";
			this.face = this.slice = this.date1 = this.date2 = this.code = this.description = "";
			this.sign = this.account = this.geo = this.role = this.info = this.meter = this.meterValue = "";
			this.unit = this.more = this.mark = this.process = this.asset = this.deal = this.templateId = "";
			this.isValid = true;
			this.isExist = false;
		} catch (Exception ex) {
			WB.addLog("ModelDto.clear():void, ex=" + ex.getMessage(), "", "ModelDto");
		}
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 13.06.2025
		try {

		} catch (Exception ex) {
			WB.addLog("Workbook.test():void, ex=" + ex.getMessage(), "", "Workbook");
		}
	}
}