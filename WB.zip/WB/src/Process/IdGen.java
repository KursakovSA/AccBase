import java.util.ArrayList;
import java.util.List;

public final class IdGen {
	// origin - 14.08.2024, last edit - 12.10.2025
	public String idKind, id, idRaw, role;
	public String department, database, store, table, point, context = "";

//	idCommonCompositeRandom = ex. [CB1][2024-08-28T07:44:51][#12684]
//	idStringGrowingDigitalGlobal = ex. 005, 000345, 000234, etc.
//	idIntegerGrowingDigitalGlobal = ex. 45, 87, 46565, etc.
//	idStringGrowingDigitalInfobase = ex. [IB1]00005, etc.
//	idStringGrowingDigitalPoint = ex. [P4]578, [P2]4523 etc.

	public String partNumberLeftPlaceholder = "";
	public int partNumberStep, partNumberStart, partNumberLenght;
	public String partDatabase, partStore, partPoint, partDepartment, partDatetime, partNumber, partNumberOuter;

	public IdGen.Tuner custom, actual;

	public static int defaultNumberStep, defaultNumberStart, defaultPartNumberLenght;
	public static String defaultLeftPlaceholder = "";

	static {
		try {
			IdGen.defaultNumberStep = 1;
			IdGen.defaultNumberStart = 0;
			IdGen.defaultPartNumberLenght = 5;
			IdGen.defaultLeftPlaceholder = "0";
		} catch (Exception ex) {
			WB.addLog("IdGen.static ctor, ex=" + ex.getMessage(), "", "IdGen");
		}
	}

	// inner class Tuner for outer class IdGen
	private class Tuner {// for tuning outer IdGen
		// origin - 30.08.2024, last edit - 19.03.2025
		private String idKind = "";
		private String context2 = "";
		private int partNumberLenght2 = 0;
		private int partNumberStep2 = 0;
		private int partNumberStart2 = 0;
		private String partNumberLeftPlaceholder2 = "";
		private String partNumber2 = ""; // for outer partNumber, ex. article asset
		private String id = "";

		private Tuner() throws Exception {
			// origin - 31.08.2024, last edit - 31.08.2024
		}

		private Tuner(String IdKind, String Context) throws Exception {
			// origin - 30.08.2024, last edit - 20.03.2025
			this.idKind = IdKind;
			this.context2 = Context;

			if (this.idKind.isEmpty() == false) {// find local idgen only if idkind not empty

				switch (Context.toLowerCase()) {

				case "custom":
					Abc abcLocal = WB.abcLocal;
					// filter
					var filteredIdGen1 = ReadSet.getEqualsByDescription(abcLocal.idGen, IdKind);
					var filteredIdGen2 = ReadSet.getEqualsByDescription(filteredIdGen1, Context);
					// custom
					this.partNumberLenght2 = Conv.getInt(
							ReadSet.getMeterValueByContainsDescription(filteredIdGen2, "partNumberLenght.Custom"));
					this.partNumberStep2 = Conv.getInt(
							ReadSet.getMeterValueByContainsDescription(filteredIdGen2, "partNumberStep.Custom"));
					this.partNumberStart2 = Conv.getInt(
							ReadSet.getMeterValueByContainsDescription(filteredIdGen2, "partNumberStart.Custom"));
					this.partNumberLeftPlaceholder2 = ReadSet.getMeterValueByContainsDescription(filteredIdGen2,
							"partNumberLeftplaceholder.Custom");
					break;

				default:
					Etc.doNothing();
					break;
				}
			}
			// WB.addLog2("IdGen.Tuner(idKind, Context), res="
			// +this.toString(),"","IdGen.Tuner");
		}

		public String toString() {
			// origin - 19.09.2024, last edit - 29.06.2025
			String res = "";
			try {
				res = res + Fmtr.addIfNotEmpty(" idKind ", this.idKind);
				res = res + Fmtr.addIfNotEmpty(" context2 ", this.context2);
				res = res + Fmtr.addIfNotEmpty(" partNumberLenght2 ", this.partNumberLenght2);
				res = res + Fmtr.addIfNotEmpty(" partNumberStep2 ", this.partNumberStep2);
				res = res + Fmtr.addIfNotEmpty(" partNumberStart2 ", this.partNumberStart2);
				res = res + Fmtr.addIfNotEmpty(" partNumberLeftPlaceholder2 ", this.partNumberLeftPlaceholder2);
				res = res + Fmtr.addIfNotEmpty(" partNumber2 ", this.partNumber2);
				res = res + Fmtr.addIfNotEmpty(" id ", this.id);
				res = "{" + res + "}";
			} catch (Exception ex) {
			}
			return res;
		}
	}

	private void getTable() throws Exception {
		// origin - 17.08.2024, last edit - 02.07.2025
		try {
			this.table = switch (this.idKind) {
			case "CrewId", "StaffTableId", "PointId", "DeptId", "CashId", "UserId", "StoreId", "EmpId", "FaceId" ->
				"Face";
			case "AssetId" -> "Asset";
			case "DealId, PawnId", "MoveId" -> "Deal";
			case "InfoId" -> "Info";

			default -> "Face";
			};

			this.table = DefVal.set(this.table, "Info");// because table "Info" always short
		} catch (Exception ex) {
			WB.addLog2("IdGen.getTable():void, ex=" + ex.getMessage(), "", "IdGen");
		}
	}

	private void getNumber() throws Exception {
		// origin - 28.06.2025, last edit - 28.06.2025
		try {
			String strNumb = this.actual.partNumber2;
			strNumb = DefVal.set(strNumb, String.valueOf(this.partNumberStart));
			int numb = Integer.parseInt(strNumb);
			numb = numb + this.partNumberStep;
			this.partNumber = Etc.addLeaderPlaceholder(String.valueOf(numb), this.partNumberLenght,
					this.partNumberLeftPlaceholder);
		} catch (Exception ex) {
			WB.addLog2("IdGen.getNumber():void, ex=" + ex.getMessage(), "", "IdGen");
		}
	}

	private void getPart() throws Exception {
		// origin - 15.08.2024, last edit - 02.07.2025
		try {
			this.partDatabase = this.database;
			this.partDepartment = this.department;
			this.partStore = this.store;
			this.partPoint = this.point;
			this.partDatetime = String.valueOf(DateTool.formatter2(DateTool.getNow2()));

			switch (this.context) {
			case "idIntegerGrowingDigitalGlobal", "idStringGrowingDigitalGlobal", "idStringGrowingDigitalInfobase",
					"idStringGrowingDigitalPoint":
				List<ModelDto> tmp = new ArrayList<ModelDto>();

				if (this.role.isEmpty()) {
					tmp = DAL.getByTemplate(WB.lastConnWork, Qry.getMoreFilter(this.idKind), this.table);
				}

				if (this.role.isEmpty() == false) {
					tmp = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleMoreFilter(this.role, this.idKind), this.table);
				}

				this.getMaxValueFromMoreById(tmp);
				this.getNumber();
				break;

			case "idCommonCompositeRandom":
				this.partNumber = "#" + Etc.getIntRnd(Etc.initRndDefault);
				break;

			default:
				this.partNumber = "#" + Etc.getIntRnd(Etc.initRndDefault);
				break;
			}
		} catch (Exception ex) {
			WB.addLog("IdGen.getPart():void, ex=" + ex.getMessage(), "", "IdGen");
		}
	}

	public IdGen(String IdKind, String Context, String Role) throws Exception {
		// origin - 02.07.2025, last edit - 02.07.2025
		this(IdKind);
		this.context = Context;
		this.role = Role;

		// tuning difference standard
		switch (Context) {
		case "idIntegerGrowingDigitalGlobal":
			this.partNumberLeftPlaceholder = " ";
			break;

		default:
			Etc.doNothing();
		}

		this.getTable();
		this.database = MoreVal.getFieldByKey(Face.currFA.more, "InfoBaseId");
		this.database = DefVal.set(this.database, Conn.defaultInfoBaseId);
		this.partPoint = User.getCurr(DateTool.formatter5(DateTool.getNow()), Face.currFA.code, Context).pointId; // TODO
		this.getPart();
		this.getNew();
	}

	public IdGen(String IdKind, String Context) throws Exception {
		// origin - 18.08.2024, last edit - 30.06.2025
		this(IdKind);
		this.context = Context;

		// tuning difference standard
		switch (Context) {
		case "idIntegerGrowingDigitalGlobal":
			this.partNumberLeftPlaceholder = " ";
			break;

		default:
			Etc.doNothing();
		}

		this.getTable();
		this.database = MoreVal.getFieldByKey(Face.currFA.more, "InfoBaseId");
		this.database = DefVal.set(this.database, Conn.defaultInfoBaseId);
		this.partPoint = User.getCurr(DateTool.formatter5(DateTool.getNow()), Face.currFA.code, Context).pointId; // TODO
		this.getPart();
		this.getNew();
	}

	public IdGen(String IdKind) throws Exception {
		// origin - 14.08.2024, last edit - 29.06.2025
		this.clear();
		this.idKind = IdKind;

		// customization
		this.custom = new Tuner(this.idKind, "custom");
		this.partNumberLenght = DefVal.setCustom(this.partNumberLenght, this.custom.partNumberLenght2); // 1 custom
		this.partNumberStep = DefVal.setCustom(this.partNumberStep, this.custom.partNumberStep2); // 2 custom
		this.partNumberStart = DefVal.setCustom(this.partNumberStart, this.custom.partNumberStart2); // 3 custom
		this.partNumberLeftPlaceholder = DefVal.setCustom(this.partNumberLeftPlaceholder,
				this.custom.partNumberLeftPlaceholder2); // 4 custom

		// actualization
		this.actual = new Tuner(this.idKind, "actual");
	}

	public IdGen() throws Exception {
		// origin - 31.08.2024, last edit - 29.06.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 29.06.2025, last edit - 06.09.2025
		try {
			this.idKind = this.id = this.idRaw = this.role = this.department = this.database = this.store = this.table = "";
			this.point = this.context = this.partNumberLeftPlaceholder = "";
			this.partNumberStep = this.partNumberStart = this.partNumberLenght = 0;
			this.partDatabase = this.partStore = this.partPoint = this.partDepartment = this.partDatetime = this.partNumber = this.partNumberOuter = "";

			this.custom = new IdGen.Tuner();
			this.actual = new IdGen.Tuner();

			this.partNumberLeftPlaceholder = IdGen.defaultLeftPlaceholder;
			this.partNumberStep = IdGen.defaultNumberStep;
			this.partNumberStart = IdGen.defaultNumberStart;
			this.partNumberLenght = IdGen.defaultPartNumberLenght;
		} catch (Exception ex) {
			WB.addLog("IdGen.clear():void, ex=" + ex.getMessage(), "", "IdGen");
		}
	}

	public void getNew() throws Exception {
		// origin - 19.08.2024, last edit - 30.06.2025
		String res = "";

		try {
			switch (this.context) {
			case "idStringGrowingDigitalPoint": // sectoral pawnshop
				if (this.partPoint.isEmpty() == false) {
					res = res + "[" + this.partPoint + "]";
				}
				res = res + this.partNumber;
				break;

			case "idStringGrowingDigitalInfobase":
				if (this.partDatabase.isEmpty() == false) {
					res = res + "[" + this.partDatabase + "]";
				}
				res = res + this.partNumber;
				break;

			case "idIntegerGrowingDigitalGlobal":
				res = res + this.partNumber;
				res = Etc.delStr(res, List.of("[", "]", "#"));
				break;

			case "idStringGrowingDigitalGlobal":
				res = res + this.partNumber;
				res = Etc.delStr(res, List.of("[", "]", "#"));
				break;

			case "idCommonCompositeRandom", "":
				if (this.partDatabase.isEmpty() == false) {
					res = res + "[" + this.partDatabase + "]";
				}
				// res = Fmtr.id(res, this.partDepartment);
				if (this.partDepartment.isEmpty() == false) {
					res = res + "[" + this.partDepartment + "]";
				}
				// res = Fmtr.id(res, this.partStore);
				if (this.partStore.isEmpty() == false) {
					res = res + "[" + this.partStore + "]";
				}
				res = res + "[" + this.partDatetime + "]";
				res = res + "[" + this.partNumber + "]";
				break;

			default: // "idCommonCompositeRandom"
				if (this.partDatabase.isEmpty() == false) {
					res = res + "[" + this.partDatabase + "]";
				}
				// res = Fmtr.id(res, this.partDepartment);
				if (this.partDepartment.isEmpty() == false) {
					res = res + "[" + this.partDepartment + "]";
				}
				// res = Fmtr.id(res, this.partStore);
				if (this.partStore.isEmpty() == false) {
					res = res + "[" + this.partStore + "]";
				}
				res = res + "[" + this.partDatetime + "]";
				res = res + "[" + this.partNumber + "]";
				break;
			}
			this.id = res; // this is res
		} catch (Exception ex) {
			WB.addLog2("IdGen.getNew():void, ex=" + ex.getMessage(), "", "IdGen");
		}
	}

	public String toString() {
		// origin - 14.08.2024, last edit - 02.07.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(" id ", this.id);
			res = res + Fmtr.addIfNotEmpty(" idKind ", this.idKind);
			res = res + Fmtr.addIfNotEmpty(" idRaw ", this.idRaw);
			res = res + Fmtr.addIfNotEmpty(" ", this.role);
			res = res + Fmtr.addIfNotEmpty(" department ", this.department);
			res = res + Fmtr.addIfNotEmpty(" database ", this.database);
			res = res + Fmtr.addIfNotEmpty(" store ", this.store);
			res = res + Fmtr.addIfNotEmpty(" point ", this.point);
			res = res + Fmtr.addIfNotEmpty(" context ", this.context);

			res = res + Fmtr.addIfNotEmpty(" partDatabase ", this.partDatabase);
			res = res + Fmtr.addIfNotEmpty(" partStore ", this.partStore);
			res = res + Fmtr.addIfNotEmpty(" partPoint ", this.partPoint);
			res = res + Fmtr.addIfNotEmpty(" partDepartment ", this.partDepartment);
			res = res + Fmtr.addIfNotEmpty(" partDatetime ", this.partDatetime);
			res = res + Fmtr.addIfNotEmpty(" partNumber ", this.partNumber);
			res = res + Fmtr.addIfNotEmpty(" partNumberOuter ", partNumberOuter);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	private void getMaxValueFromMoreById(List<ModelDto> dto) throws Exception {
		// origin - 13.08.2024, last edit - 13.06.2025
		String resIdActual = "";
		String currIdActual = "";
		String resIdActualPartNumber = "";

		try {
			String[] items = {};
			String splitValueInMore = ";";
			String currVal = "";
			int currMaxVal = 0;
			for (var currDto : dto) {

				// items = Etc.getArrayFromStrSplit(currDto.more, splitValueInMore); // if value
				// are diffferent in list ???
				items = currDto.more.split(splitValueInMore); // if value are diffferent in list ???
				currVal = MoreVal.getFromEquation(items, this.idKind);
				currIdActual = currVal;
				currVal = DefVal.set(currVal, this.partNumberLenght);// cut off string on the right what hit to norm
																		// lenght
				currVal = Etc.delLeaderPlaceholder(currVal, this.partNumberLeftPlaceholder);

				if ((Etc.isDigitAll(currVal)) && // ??
						(Integer.parseInt(currVal) != 0) && (currMaxVal < Integer.parseInt(currVal))) {
					currMaxVal = Integer.parseInt(currVal);
					// res = currVal;
					resIdActualPartNumber = currVal;
					resIdActual = currIdActual;
				}
			}
		} catch (Exception ex) {
			WB.addLog("IdGen.getMaxValueFromMoreById(List<ModelDto> dto):void, ex=" + ex.getMessage(), "", "IdGen");
		}

		this.actual.partNumber2 = resIdActualPartNumber; // this is res1
		this.actual.id = resIdActual; // this is res2
	}

	public static void test() throws Exception {
		// origin - 14.08.2024, last edit - 14.08.2025
		try {

//			WB.addLog2("IdGen.test.ctor(3String)", "", "IdGen");  //TODO
//			for (var tmp1 : new String[] { "FaceId", "StoreId", "PawnId" }) {
//				for (var tmp2 : new String[] { "idIntegerGrowingDigitalGlobal", "idStringGrowingDigitalGlobal",
//						"idStringGrowingDigitalInfobase", "idStringGrowingDigitalPoint" }) {
//					for (var tmp3 : new String[] { "Role.Store.Basic", "Role.Deal.Pawn" }) {
//						WB.addLog2("IdGen.test, ctor(" + tmp1 + "," + tmp2 + "," + tmp3 + ")="
//								+ new IdGen(tmp1, tmp2, tmp3).id, "", "IdGen");
//						var tmp = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleMoreFilter(tmp3, tmp1),
//								new IdGen(tmp1, tmp2, tmp3).table);
//						WB.addLog2("IdGen.test.ctor(3String), DAL.getByTemplate.size=" + tmp.size() + ", isKind=" + tmp1
//								+ ", context=" + tmp2 + ", role=" + tmp3, "", "IdGen");
//						WB.log(tmp, "IdGen");
//					}
//				}
//			}

//			WB.addLog2("IdGen.test.ctor(2String)", "", "IdGen");  //TODO
//			for (var tmp1 : new String[] { "", "FaceId", "StoreId", "EmpId", "AssetId", "PawnId" }) {
//				for (var tmp2 : new String[] { "", "idIntegerGrowingDigitalGlobal", "idStringGrowingDigitalGlobal",
//						"idStringGrowingDigitalInfobase", "idStringGrowingDigitalPoint" }) {
//					WB.addLog2("IdGen.test, ctor(" + tmp1 + "," + tmp2 + ")=" + new IdGen(tmp1, tmp2).id, "", "IdGen");
//					var tmp = DAL.getByTemplate(WB.lastConnWork, Qry.getMoreFilter(tmp1), new IdGen(tmp1, tmp2).table);
//					WB.addLog2("IdGen.test.ctor(2String), DAL.getByTemplate.size=" + tmp.size() + ", isKind=" + tmp1
//							+ ", context=" + tmp2, "", "IdGen");
//					WB.log(tmp, "IdGen");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("IdGen.test():void, ex=" + ex.getMessage(), "", "IdGen");
		}
	}
}