import java.time.LocalDate;
import java.util.List;

public final class BasicDto {
	// origin - 28.02.2025, last edit - 12.10.2025
	public String id, parent, date1, date2, code, description, more;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("BasicDto.static ctor, ex=" + ex.getMessage(), "", "BasicDto");
		}
	}

	public static BasicDto getChrono(LocalDate calcDate, List<BasicDto> listBasicDto) throws Exception {
		// origin - 01.03.2025, last edit - 14.06.2025
		BasicDto res = new BasicDto();
		LocalDate currDate1;
		LocalDate currDate2;
		try {
			for (var currDto : listBasicDto) {
				currDate1 = DateTool.getLocalDate(currDto.date1);// left border in data
				currDate2 = DateTool.getLocalDate(currDto.date2);// right border in data

				// left border hit or right border hit
				if ((Etc.strEquals(currDate1.toString(), calcDate.toString()))
						|| (Etc.strEquals(currDate2.toString(), calcDate.toString()))) {
					res = currDto;
					break;
				}

				// range from left border to right border hit
				if ((currDate1.isBefore(calcDate)) && (currDate2.isAfter(calcDate))) {
					res = currDto;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("BasicDto.getChrono(LocalDate calcDate, List<BasicDto> listBasicDto):BasicDto, ex=" + ex.getMessage(), "", "BasicDto");
		}
		return res;
	}

	public BasicDto(String Id, String Parent, String Date1, String Date2, String Code, String Description, String More)
			throws Exception {
		// origin - 28.02.2025, last edit - 28.02.2025
		this();
		this.id = Id;
		this.parent = Parent;
		this.date1 = Date1;
		this.date2 = Date2;
		this.code = Code;
		this.description = Description;
		this.more = More;
	}

	private void clear() throws Exception {
		// origin - 28.02.2025, last edit - 06.09.2025
		try {
			this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.more = "";
		} catch (Exception ex) {
			WB.addLog("BasicDto.clear():void, ex=" + ex.getMessage(), "", "BasicDto");
		}
	}

	public BasicDto() throws Exception {
		// origin - 28.02.2025, last edit - 28.02.2025
		this.clear();
	}

	public String toString() {
		// origin - 28.02.2025, last edit - 20.03.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.02.2025, last edit - 14.06.2025
		try {

		} catch (Exception ex) {
			WB.addLog("BasicDto.test():void, ex=" + ex.getMessage(), "", "BasicDto");
		}
	}
}