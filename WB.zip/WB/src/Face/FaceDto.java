import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public final class FaceDto {
	// origin - 02.03.2025, last edit - 12.10.2025
	// common fields
	public String id, parent, date1, date2, code, description, geo, role, info, mark, more;
	// special fields
	public String crewId, deptId, storeId, staffTableId, pointId, jobTurnId, empId, cashId, paymasterEmpId, faceCatId,
			IBAN, BIC, salary, span, docReg, IIN, BIN, RNN;
	public String fullName, comment, sex, password;
	public JobCycle jobCycle;
	public Access access;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("FaceDto.static ctor, ex=" + ex.getMessage(), "", "FaceDto");
		}
	}

	public static FaceDto getCodeRole(String code, String role) throws Exception {
		// origin - 28.03.2025, last edit - 20.09.2025
		FaceDto res = new FaceDto();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getCodeRoleFilter(code, role), "Face");
			if (faceList.size() != 0) {
				if (faceList.size() != 0) {
					for (var currFace : faceList) {
						res = new FaceDto(currFace.id, currFace.parent, currFace.date1, currFace.date2, currFace.code,
								currFace.description, currFace.geo, currFace.role, currFace.info, currFace.more,
								currFace.mark);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("FaceDto.getCodeRole(2String):FaceDto, ex=" + ex.getMessage(), "", "FaceDto");
		}
		return res;
	}

	public static List<FaceDto> getChronoSpan(SpanDate spanDate, List<FaceDto> listFaceDto) throws Exception {
		// origin - 09.05.2025, last edit - 13.06.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		LocalDate currDate1;
		LocalDate currDate2;
		try {
			LocalDate spanDate1 = DateTool.getLocalDate(spanDate.date1.getFirst());
			LocalDate spanDate2 = DateTool.getLocalDate(spanDate.date2.getFirst());
			for (var currDto : listFaceDto) {
				currDate1 = DateTool.getLocalDate(currDto.date1);// left border in data
				currDate2 = DateTool.getLocalDate(currDto.date2);// right border in data

				if (currDate1.isBefore(spanDate1)) {
					continue;
				}

				if (currDate2.isAfter(spanDate2)) {
					continue;
				}

				if ((Etc.strEquals(currDate1.toString(), spanDate1.toString()))
						& (Etc.strEquals(currDate2.toString(), spanDate2.toString()))) {
					res.add(currDto);
					continue;
				}

				if ((Etc.strEquals(currDate1.toString(), spanDate1.toString())) & (currDate2.isBefore(spanDate2))) {
					res.add(currDto);
					continue;
				}

				if ((currDate1.isAfter(spanDate1)) & (Etc.strEquals(currDate2.toString(), spanDate2.toString()))) {
					res.add(currDto);
					continue;
				}

				if ((currDate1.isAfter(spanDate1)) & (currDate2.isBefore(spanDate2))) {
					res.add(currDto);
					continue;
				}
			}
		} catch (Exception ex) {
			WB.addLog("FaceDto.getChronoSpan(SpanDate spanDate, List<FaceDto> listFaceDto):List<FaceDto>, ex="
					+ ex.getMessage(), "", "FaceDto");
		}
		return res;
	}

	public static List<FaceDto> getChrono(LocalDate calcDate, List<FaceDto> listFaceDto) throws Exception {
		// origin - 26.04.2025, last edit - 13.06.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		LocalDate currDate1;
		LocalDate currDate2;
		try {
			for (var currDto : listFaceDto) {
				currDate1 = DateTool.getLocalDate(currDto.date1);// left border in data
				currDate2 = DateTool.getLocalDate(currDto.date2);// right border in data

				// left border hit or right border hit
				if ((Etc.strEquals(currDate1.toString(), calcDate.toString()))
						|| (Etc.strEquals(currDate2.toString(), calcDate.toString()))) {
					res.add(currDto);
					continue;
				}

				// range from left border to right border hit
				if ((currDate1.isBefore(calcDate)) && (currDate2.isAfter(calcDate))) {
					res.add(currDto);
					continue;
				}
			}
		} catch (Exception ex) {
			WB.addLog("FaceDto.getChrono(LocalDate calcDate, List<FaceDto> listFaceDto):List<FaceDto>, ex="
					+ ex.getMessage(), "", "FaceDto");
		}
		return res;
	}

	public static FaceDto getChrono(LocalDate calcDate, List<FaceDto> listFaceDto, String context) throws Exception {
		// origin - 02.03.2025, last edit - 13.06.2025
		FaceDto res = new FaceDto();
		LocalDate currDate1;
		LocalDate currDate2;
		try {
			for (var currDto : listFaceDto) {
				if (context.isEmpty() == false) {
					if (Etc.strContains(currDto.info, context) == false) {
						continue;
					}
				}

				currDate1 = DateTool.getLocalDate(currDto.date1);// left border in data
				currDate2 = DateTool.getLocalDate(currDto.date2);// right border in data

				// left border hit or right border hit
				if ((Etc.strEquals(currDate1.toString(), calcDate.toString()))
						|| (Etc.strEquals(currDate2.toString(), calcDate.toString()))) {
					res = currDto;
					break;
				}

				// range from left border to right border hit
				if ((currDate1.isBefore(calcDate)) && (currDate2.isAfter(calcDate))) {
					res = currDto;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("FaceDto.getChrono(LocalDate calcDate, List<FaceDto> listFaceDto, String context):FaceDto, ex="
					+ ex.getMessage(), "", "FaceDto");
		}
		return res;
	}

	private void isExist() throws Exception {
		// origin - 25.09.2025, last edit - 25.09.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), "Face");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.id = dto.id;
				this.code = dto.code;
				this.parent = dto.parent;
				this.date1 = dto.date1;
				this.date2 = dto.date2;
				this.description = dto.description;
				this.geo = DefVal.set(dto.geo, Geo.currCountry.id);
				this.role = dto.role;
				this.info = dto.info;
				this.more = dto.more;
				this.mark = DefVal.set(dto.mark, "Mark.DD");
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("FaceDto.isExist():void, ex=" + ex.getMessage(), "", "FaceDto");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 20.09.2025, last edit - 12.10.2025
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.sex = MoreVal.getFieldByKey(this.more, "Sex");
			this.storeId = MoreVal.getFieldByKey(this.more, "StoreId");
			this.cashId = MoreVal.getFieldByKey(this.more, "CashId");
			this.paymasterEmpId = MoreVal.getFieldByKey(this.more, "PaymasterEmpId");
			this.deptId = MoreVal.getFieldByKey(this.more, "DeptId");
			this.pointId = MoreVal.getFieldByKey(this.more, "PointId");
			this.staffTableId = MoreVal.getFieldByKey(this.more, "StaffTableId");
			this.jobTurnId = MoreVal.getFieldByKey(this.more, "JobTurnId");
			this.faceCatId = MoreVal.getFieldByKey(this.more, "FaceCatId");
			this.empId = MoreVal.getFieldByKey(this.more, "EmpId");
			this.crewId = MoreVal.getFieldByKey(this.more, "CrewId");
			this.BIN = MoreVal.getFieldByKey(this.more, "BIN");
			this.IIN = MoreVal.getFieldByKey(this.more, "IIN");
			this.RNN = MoreVal.getFieldByKey(this.more, "RNN");
			this.IBAN = MoreVal.getFieldByKey(this.more, "IBAN");
			this.BIC = MoreVal.getFieldByKey(this.more, "BIC");
			this.salary = MoreVal.getFieldByKey(this.more, "Salary");
			this.span = MoreVal.getFieldByKey(this.more, "Span");
			this.docReg = MoreVal.getFieldByKey(this.more, "DocReg");
			this.jobCycle = new JobCycle(MoreVal.getFieldByKey(this.more, "JobCycle"));
			this.access = new Access(MoreVal.getFieldByKey(this.more, "Access"));
			this.password = MoreVal.getFieldByKey(this.more, "Password");
		} catch (Exception ex) {
			WB.addLog("Face.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Face");
		}
	}

	public FaceDto(String Id) throws Exception {
		// origin - 25.09.2025, last edit - 25.09.2025
		this.clear();
		this.id = Id;
		this.isExist();
	}

	public FaceDto(String Id, String Parent, String Date1, String Date2, String Code, String Description, String Geo,
			String Role, String Info, String More, String Mark) throws Exception {
		// origin - 02.03.2025, last edit - 24.09.2025
		this.clear();
		this.id = Id;
		this.parent = Parent;
		this.date1 = Date1;
		this.date2 = Date2;
		this.code = Code;
		this.description = Description;
		this.geo = Geo;
		this.role = Role;
		this.info = Info;
		this.more = More;
		this.mark = Mark;
		this.getFieldFromMore();
	}

	private void clear() throws Exception {
		// origin - 02.03.2025, last edit - 12.10.2025
		try {
			this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.more = "";
			this.geo = this.role = this.info = this.mark = "";
			this.crewId = this.deptId = this.storeId = this.staffTableId = this.pointId = this.jobTurnId = this.empId = this.cashId = "";
			this.salary = this.span = this.paymasterEmpId = this.faceCatId = this.BIN = this.IIN = this.RNN = this.IBAN = this.BIC = "";
			this.fullName = this.comment = this.sex = this.docReg = this.password = "";
			this.jobCycle = new JobCycle();
			this.access = new Access();
		} catch (Exception ex) {
			WB.addLog("FaceDto.clear():void, ex=" + ex.getMessage(), "", "FaceDto");
		}
	}

	public FaceDto() throws Exception {
		// origin - 02.03.2025, last edit - 02.03.2025
		this.clear();
	}

	public String toString() {
		// origin - 02.03.2025, last edit - 12.10.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addAnyway(", date1 ", this.date1);
			res = res + Fmtr.addAnyway(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", jobCycle ", this.jobCycle.id);
			res = res + Fmtr.addIfNotEmpty(", salary ", this.salary);
			res = res + Fmtr.addIfNotEmpty(", span ", this.span);
			res = res + Fmtr.addIfNotEmpty(", empId ", this.empId);
			res = res + Fmtr.addIfNotEmpty(", crewId ", this.crewId);
			res = res + Fmtr.addIfNotEmpty(", deptId ", this.deptId);
			res = res + Fmtr.addIfNotEmpty(", storeId ", this.storeId);
			res = res + Fmtr.addIfNotEmpty(", staffTableId ", this.staffTableId);
			res = res + Fmtr.addIfNotEmpty(", pointId ", this.pointId);
			res = res + Fmtr.addIfNotEmpty(", jobTurnId ", this.jobTurnId);
			res = res + Fmtr.addIfNotEmpty(", cashId ", this.cashId);
			res = res + Fmtr.addIfNotEmpty(", paymasterEmpId ", this.paymasterEmpId);
			res = res + Fmtr.addIfNotEmpty(", faceCatId ", this.faceCatId);
			res = res + Fmtr.addIfNotEmpty(", IBAN ", this.IBAN);
			res = res + Fmtr.addIfNotEmpty(", BIC ", this.BIC);
			res = res + Fmtr.addIfNotEmpty(", IIN ", this.IIN);
			res = res + Fmtr.addIfNotEmpty(", BIN ", this.BIN);
			res = res + Fmtr.addIfNotEmpty(", RNN ", this.RNN);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", sex ", this.sex);
			res = res + Fmtr.addIfNotEmpty(", docReg ", this.docReg);
			res = res + Fmtr.addIfNotEmpty(", access ", this.access);
			res = res + Fmtr.addIfNotEmpty(", password ", this.password);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 02.03.2025, last edit - 10.10.2025
		try {

//			WB.addLog2("FaceDto.test.ctor()", "", "FaceDto");
//			WB.addLog2("FaceDto.test.ctor()=" + new FaceDto(), "", "FaceDto");

		} catch (Exception ex) {
			WB.addLog("FaceDto.test():void, ex=" + ex.getMessage(), "", "FaceDto");
		}
	}
}