﻿--Курсаков С.А. https://github.com/KursakovSA/AccBase 

PRAGMA foreign_keys = off;

CREATE TABLE IF NOT EXISTS [Account](
	[Id] INTEGER PRIMARY KEY ASC AUTOINCREMENT,
	[Parent] INTEGER NULL references Account(Id),
	[Slice] INTEGER NULL references Slice(Id),
	[Date1] TEXT  DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT NULL,
	[Code] TEXT NULL,
	[Description] TEXT NULL,
    [Role] INTEGER NULL references Role(Id),
    [Sign] INTEGER NULL references Sign(Id),
	[More] TEXT NULL
 );

CREATE TABLE IF NOT EXISTS [Asset](
	[Id] INTEGER PRIMARY KEY ASC AUTOINCREMENT,
	[Parent] INTEGER NULL references Asset(Id),
	[Date1] TEXT  DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT NULL,
	[Code] TEXT NULL,
	[Description] TEXT NULL,
	[Geo] INTEGER NULL references Geo(Id),
	[Role] INTEGER NULL references Role(Id),
	[Info] INTEGER NULL references Info(Id),
	[Unit] INTEGER NULL references Unit(Id),
	[More] TEXT NULL
 );

CREATE TABLE IF NOT EXISTS [Deal](
	[Id] INTEGER PRIMARY KEY ASC AUTOINCREMENT,
	[Parent] INTEGER NULL references Deal(Id),
	[Face1] INTEGER NULL references Face(Id),
	[Face2] INTEGER NULL references Face(Id),
	[Face] INTEGER NULL references Face(Id),
	[Date1] TEXT  DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT NULL,
	[Code] TEXT NULL,
	[Description] TEXT NULL,
	[Geo] INTEGER NULL references Geo(Id),
	[Role] INTEGER NULL references Role(Id),
	[Info] INTEGER NULL references Info(Id),
	[More] TEXT NULL
 );

CREATE TABLE IF NOT EXISTS [Debt](
	[Id] INTEGER PRIMARY KEY ASC  AUTOINCREMENT,
	[Parent] INTEGER NULL references Debt(Id),
	[Date1] TEXT  DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT NULL,
	[Code] TEXT NULL,
	[Description] TEXT NULL,
	[Geo] INTEGER NULL references Geo(Id),
	[Role] INTEGER NULL references Role(Id),
	[Info] INTEGER NULL references Info(Id),
	[More] TEXT NULL
  ); 
 
CREATE TABLE IF NOT EXISTS [Face](
	[Id] INTEGER PRIMARY KEY ASC  AUTOINCREMENT,
	[Parent] INTEGER NULL references Face(Id),
	[Date1] TEXT  DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT NULL,
	[Code] TEXT NULL,
	[Description] TEXT NULL,
	[Geo] INTEGER NULL references Geo(Id),
	[Role] INTEGER NULL references Role(Id),
	[Info] INTEGER NULL references Info(Id),
	[More] TEXT NULL
 );
 
CREATE TABLE IF NOT EXISTS [Geo](
	[Id] INTEGER PRIMARY KEY ASC AUTOINCREMENT,
	[Parent] INTEGER NULL references Geo(Id),
	[Date1] TEXT  DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT NULL,
	[Code] TEXT NULL,
	[Description] TEXT NULL,
        [Role] INTEGER NULL references Role(Id),
	[Unit] INTEGER NULL references Unit(Id),
	[More] TEXT NULL
 );
 
CREATE TABLE IF NOT EXISTS [Info](
	[Id] INTEGER PRIMARY KEY ASC AUTOINCREMENT,
	[Parent] INTEGER NULL references Info(Id),
	[Date1] TEXT  DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT NULL,
	[Code] TEXT NULL,
	[Description] TEXT NULL,
	[More] TEXT NULL
 );
 
CREATE TABLE IF NOT EXISTS [Item](
	[Id] INTEGER PRIMARY KEY ASC AUTOINCREMENT,
	[Parent] INTEGER NULL references Item(Id),
	[Date1] TEXT  DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT NULL,
	[Code] TEXT NULL,
	[Description] TEXT NULL,
	[More] TEXT NULL
 );
 
CREATE TABLE IF NOT EXISTS [Mark](
	[Id] INTEGER PRIMARY KEY ASC AUTOINCREMENT,
	[Parent] INTEGER NULL references Mark(Id),
	[Date1] TEXT  DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT NULL,
	[Code] TEXT NULL,
	[Description] TEXT NULL,
	[More] TEXT NULL
 );
 
CREATE TABLE IF NOT EXISTS [Meter](
	[Id] INTEGER PRIMARY KEY ASC AUTOINCREMENT,
	[Parent] INTEGER NULL references Meter(Id),
	[Date1] TEXT  DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT NULL,
	[Code] TEXT NULL,
	[Description] TEXT NULL,
	[Unit] INTEGER NULL references Unit(Id),
	[More] TEXT NULL
 );
 
CREATE TABLE IF NOT EXISTS [Price](
	[Id] INTEGER PRIMARY KEY ASC AUTOINCREMENT,
	[Parent] INTEGER NULL references Price(Id),
	[Date1] TEXT  DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT NULL,
	[Code] TEXT NULL,
	[Description] TEXT NULL,
	[Role] INTEGER NULL references Role(Id),
	[Info] INTEGER NULL references Info(Id),
	[Unit] INTEGER NULL references Unit(Id),
	[More] TEXT NULL
 );
 
CREATE TABLE IF NOT EXISTS [Process](
	[Id] INTEGER PRIMARY KEY ASC AUTOINCREMENT,
	[Parent] INTEGER NULL references Process(Id),
	[Face1] INTEGER NULL references Face(Id),
	[Face2] INTEGER NULL references Face(Id),
	[Face] INTEGER NULL references Face(Id),
	[Slice] INTEGER NULL references Slice(Id),
	[Date1] TEXT  DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT NULL,
	[Code] TEXT NULL,
	[Description] TEXT NULL,
	[Sign] INTEGER NULL references Sign(Id),
	[Account] INTEGER NULL references Account(Id),
    [Asset] INTEGER NULL references Asset(Id),
    [Deal] INTEGER NULL references Deal(Id),
    [Item] INTEGER NULL references Item(Id),
	[Debt] INTEGER NULL references Debt(Id),
	[Price] INTEGER NULL references Price(Id),
	[Role] INTEGER NULL references Role(Id),
	[Info] INTEGER NULL references Info(Id),
	[Meter] INTEGER NULL references Meter(Id),
	[MeterValue] TEXT NULL,
	[Unit] INTEGER NULL references Unit(Id),
	[More] TEXT NULL,
	[Mark] INTEGER NULL references Mark(Id)
 );
 
CREATE TABLE IF NOT EXISTS [Role](
	[Id] INTEGER PRIMARY KEY ASC AUTOINCREMENT,
	[Parent] INTEGER NULL references Role(Id),
	[Date1] TEXT  DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT NULL,
	[Code] TEXT NULL,
	[Description] TEXT NULL,
	[More] TEXT NULL
 );
 
CREATE TABLE IF NOT EXISTS [Sign](
	[Id] INTEGER PRIMARY KEY ASC AUTOINCREMENT,
	[Parent] INTEGER NULL references Sign(Id),
	[Date1] TEXT  DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT NULL,
	[Code] TEXT NULL,
	[Description] TEXT NULL,
	[Role] INTEGER NULL references Role(Id),
	[Info] INTEGER NULL references Info(Id),
	[More] TEXT NULL
 );
 
CREATE TABLE IF NOT EXISTS [Slice](
	[Id] INTEGER PRIMARY KEY ASC AUTOINCREMENT,
	[Parent] INTEGER NULL references Slice(Id),
	[Date1] TEXT  DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT NULL,
	[Code] TEXT NULL,
	[Description] TEXT NULL,
	[More] TEXT NULL
 );
 
CREATE TABLE IF NOT EXISTS [Unit](
	[Id] INTEGER PRIMARY KEY ASC AUTOINCREMENT,
	[Parent] INTEGER NULL references Unit(Id),
	[Date1] TEXT  DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT NULL,
	[Code] TEXT NULL,
	[Description] TEXT NULL,
	[Role] INTEGER NULL references Role(Id),
	[More] TEXT NULL
 );
 
CREATE TABLE IF NOT EXISTS [Workbook](
	[Id] INTEGER PRIMARY KEY ASC AUTOINCREMENT,
	[Parent] INTEGER NULL references Workbook(Id),
	[Face1] INTEGER NULL references Face(Id),
	[Face2] INTEGER NULL references Face(Id),
	[Face] INTEGER NULL references Face(Id),
	[Slice] INTEGER NULL references Slice(Id),
	[Date1] TEXT  DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT NULL,
	[Code] TEXT NULL,
	[Description] TEXT NULL,
	[Geo] INTEGER NULL references Geo(Id),
	[Sign] INTEGER NULL references Sign(Id),
	[Account] INTEGER NULL references Account(Id),
	[Process] INTEGER NULL references Process(Id),
    [Asset] INTEGER NULL references Asset(Id),
    [Deal] INTEGER NULL references Deal(Id),
    [Item] INTEGER NULL references Item(Id),
	[Debt] INTEGER NULL references Debt(Id),
	[Price] INTEGER NULL references Price(Id),
	[Role] INTEGER NULL references Role(Id),
	[Info] INTEGER NULL references Info(Id),
	[Meter] INTEGER NULL references Meter(Id),
	[MeterValue] TEXT NULL,
	[Unit] INTEGER NULL references Unit(Id),
	[More] TEXT NULL,
	[Mark] INTEGER NULL references Mark(Id)
 );
 
CREATE INDEX IF NOT EXISTS AssetDate1 ON Asset (
    Date1
);

CREATE INDEX IF NOT EXISTS AssetCode ON Asset (
    Code
);
 
CREATE INDEX IF NOT EXISTS AssetDescription ON Asset (
    Description
);

CREATE INDEX IF NOT EXISTS AssetRole ON Asset (
    Role
);

CREATE INDEX IF NOT EXISTS AssetInfo ON Asset (
    Info
);

CREATE INDEX IF NOT EXISTS DealParent ON Deal (
    Parent
);

CREATE INDEX IF NOT EXISTS DealFace1 ON Deal (
    Face1
);

CREATE INDEX IF NOT EXISTS DealFace2 ON Deal (
    Face2
);

CREATE INDEX IF NOT EXISTS DealFace ON Deal (
    Face
);

CREATE INDEX IF NOT EXISTS DealCode ON Deal (
    Code
);
 
CREATE INDEX IF NOT EXISTS DealDescription ON Deal (
    Description
);

CREATE INDEX IF NOT EXISTS DealRole ON Deal (
    Role
);

CREATE INDEX IF NOT EXISTS DealInfo ON Deal (
    Info
);

CREATE INDEX IF NOT EXISTS FaceParent ON Face (
    Parent
);

CREATE INDEX IF NOT EXISTS FaceDate1 ON Face (
    Date1
);

CREATE INDEX IF NOT EXISTS FaceCode ON Face (
    Code
);
 
CREATE INDEX IF NOT EXISTS FaceDescription ON Face (
    Description
);

CREATE INDEX IF NOT EXISTS FaceRole ON Face (
    Role
);

CREATE INDEX IF NOT EXISTS FaceInfo ON Face (
    Info
);
 
CREATE INDEX IF NOT EXISTS WorkbookParent ON Workbook (
    Parent
);

CREATE INDEX IF NOT EXISTS WorkbookFace1 ON Workbook (
    Face1
);

CREATE INDEX IF NOT EXISTS WorkbookFace2 ON Workbook (
    Face2
);

CREATE INDEX IF NOT EXISTS WorkbookFace ON Workbook (
    Face
);

CREATE INDEX IF NOT EXISTS WorkbookDate1 ON Workbook (
    Date1
);

CREATE INDEX IF NOT EXISTS WorkbookCode ON Workbook (
    Code
);
 
CREATE INDEX IF NOT EXISTS WorkbookDescription ON Workbook (
    Description
);

CREATE INDEX IF NOT EXISTS WorkbookSign ON Workbook (
    Sign
);

CREATE INDEX IF NOT EXISTS WorkbookAccount ON Workbook (
    Account
);

CREATE INDEX IF NOT EXISTS WorkbookProcess ON Workbook (
    Process
);

CREATE INDEX IF NOT EXISTS WorkbookDebt ON Workbook (
    Debt
);

CREATE INDEX IF NOT EXISTS WorkbookDeal ON Workbook (
    Deal
);

CREATE INDEX IF NOT EXISTS WorkbookAsset ON Workbook (
    Asset
);

CREATE INDEX IF NOT EXISTS WorkbookRole ON Workbook (
    Role
);

CREATE INDEX IF NOT EXISTS WorkbookInfo ON Workbook (
    Info
);

-- View: AccountList
CREATE VIEW IF NOT EXISTS AccountList AS
    SELECT Account.Id,
           Account.Parent,
           Account2.Code AS ParentCode,
           Account2.Description AS ParentDescription,
           Account.Slice,
           Slice.Code AS SliceCode,
           Slice.Description AS SliceDescription,
           Account.Date1 AS Date1,
           Account.Date2 AS Date2,
           Account.Code AS Code,
           Account.Description AS Description,
           Account.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Account.Sign,
           Sign.Code AS SignCode,
           Sign.Description AS SignDescription,
           Account.More AS More
      FROM Account AS Account
           LEFT JOIN
           Account AS Account2 ON Account.Parent = Account2.Id
           LEFT JOIN
           Slice AS Slice ON Account.Slice = Slice.Id
           LEFT JOIN
           Role AS Role ON Account.Role = Role.Id
           LEFT JOIN
           Sign AS Sign ON Account.Sign = Sign.Id;

-- View: AssetList
CREATE VIEW IF NOT EXISTS AssetList AS
    SELECT Asset.Id,
           Asset.Parent,
           Asset2.Code AS ParentCode,
           Asset2.Description AS ParentDescription,
           Asset.Date1 AS Date1,
           Asset.Date2 AS Date2,
           Asset.Code,
           Asset.Description,
           Asset.Geo,
           Geo.Code AS GeoCode,
           Geo.Description AS GeoDescription,
           Asset.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Asset.Info,
           Info.Code AS InfoCode,
           Info.Description AS InfoDescription,
           Asset.Unit,
           Unit.Code AS UnitCode,
           Unit.Description AS UnitDescription,
           Asset.More AS More
      FROM Asset AS Asset
           LEFT JOIN
           Asset AS Asset2 ON Asset.Parent = Asset2.Id
           LEFT JOIN
           Geo AS Geo ON Asset.Geo = Geo.Id
           LEFT JOIN
           Role AS Role ON Asset.Role = Role.Id
           LEFT JOIN
           Info AS Info ON Asset.Info = Info.Id
           LEFT JOIN
           Unit AS Unit ON Asset.Unit = Unit.Id;

-- View: DealList
CREATE VIEW IF NOT EXISTS DealList AS
    SELECT Deal.Id,
           Deal.Parent,
           Deal2.Code AS ParentCode,
           Deal2.Description AS ParentDescription,
           Deal.Face1,
           Face1.Code AS Face1Code,
           Face1.Description AS Face1Description,
           Deal.Face2,
           Face2.Code AS Face2Code,
           Face2.Description AS Face2Description,
           Deal.Face,
           Face.Code AS FaceCode,
           Face.Description AS FaceDescription,
           Deal.Date1 AS Date1,
           Deal.Date2 AS Date2,
           Deal.Code AS Code,
           Deal.Description AS Description,
           Deal.Geo,
           Geo.Code AS GeoCode,
           Geo.Description AS GeoDescription,
           Deal.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Deal.Info,
           Info.Code AS InfoCode,
           Info.Description AS InfoDescription,
           Deal.More AS More
      FROM Deal AS Deal
           LEFT JOIN
           Deal AS Deal2 ON Deal.Parent = Deal2.Id
           LEFT JOIN
           Face AS Face ON Deal.Face = Face.Id
           LEFT JOIN
           Face AS Face1 ON Deal.Face1 = Face1.Id
           LEFT JOIN
           Face AS Face2 ON Deal.Face2 = Face2.Id
           LEFT JOIN
           Geo AS Geo ON Deal.Geo = Geo.Id
           LEFT JOIN
           Role AS Role ON Deal.Role = Role.Id
           LEFT JOIN
           Info AS Info ON Deal.Info = Info.Id;

-- View: DebtList
CREATE VIEW IF NOT EXISTS DebtList AS
    SELECT Debt.Id,
           Debt.Parent,
           Debt2.Code AS ParentCode,
           Debt2.Description AS ParentDescription,
           Debt.Date1 AS Date1,
           Debt.Date2 AS Date2,
           Debt.Code AS Code,
           Debt.Description AS Description,
           Debt.Geo,
           Geo.Code AS GeoCode,
           Geo.Description AS GeoDescription,
           Debt.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Debt.Info,
           Info.Code AS InfoCode,
           Info.Description AS InfoDescription,
           Debt.More AS More
      FROM Debt AS Debt
           LEFT JOIN
           Debt AS Debt2 ON Debt.Parent = Debt2.Id
           LEFT JOIN
           Geo AS Geo ON Debt.Geo = Geo.Id
           LEFT JOIN
           Role AS Role ON Debt.Role = Role.Id
           LEFT JOIN
           Info AS Info ON Debt.Info = Info.Id;

-- View: FaceList
CREATE VIEW IF NOT EXISTS FaceList AS
    SELECT Face.Id,
           Face.Parent,
           Face2.Code AS ParentCode,
           Face2.Description AS ParentDescription,
           Face.Date1 AS Date1,
           Face.Date2 AS Date2,
           Face.Code AS Code,
           Face.Description AS Description,
           Face.Geo,
           Geo.Code AS GeoCode,
           Geo.Description AS GeoDescription,
           Face.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Face.Info,
           Info.Code AS InfoCode,
           Info.Description AS InfoDescription,
           Face.More AS More
      FROM Face AS Face
           LEFT JOIN
           Face AS Face2 ON Face.Parent = Face2.Id
           LEFT JOIN
           Geo AS Geo ON Face.Geo = Geo.Id
           LEFT JOIN
           Role AS Role ON Face.Role = Role.Id
           LEFT JOIN
           Info AS Info ON Face.Info = Info.Id;

-- View: GeoList
CREATE VIEW IF NOT EXISTS GeoList AS
    SELECT Geo.Id,
           Geo.Parent,
           Geo2.Code AS ParentCode,
           Geo2.Description AS ParentDescription,
           Geo.Date1 AS Date1,
           Geo.Date2 AS Date2,
           Geo.Code AS Code,
           Geo.Description AS Description,
           Geo.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Geo.Unit,
           Unit.Code AS UnitCode,
           Unit.Description AS UnitDescription,
           Geo.More AS More
      FROM Geo AS Geo
           LEFT JOIN
           Geo AS Geo2 ON Geo.Parent = Geo2.Id
           LEFT JOIN
           Role AS Role ON Geo.Role = Role.Id
           LEFT JOIN
           Unit AS Unit ON Geo.Unit = Unit.Id;

-- View: InfoList
CREATE VIEW IF NOT EXISTS InfoList AS
    SELECT Info.Id,
           Info.Parent,
           Info2.Code AS ParentCode,
           Info2.Description AS ParentDescription,
           Info.Date1 AS Date1,
           Info.Date2 AS Date2,
           Info.Code AS Code,
           Info.Description AS Description,
           Info.More AS More
      FROM Info AS Info
           LEFT JOIN
           Info AS Info2 ON Info.Parent = Info2.Id;

-- View: ItemList
CREATE VIEW IF NOT EXISTS ItemList AS
    SELECT Item.Id,
           Item.Parent,
           Item2.Code AS ParentCode,
           Item2.Description AS ParentDescription,
           Item.Date1 AS Date1,
           Item.Date2 AS Date2,
           Item.Code AS Code,
           Item.Description AS Description,
           Item.More AS More
      FROM Item AS Item
           LEFT JOIN
           Item AS Item2 ON Item.Parent = Item2.Id;

-- View: MarkList
CREATE VIEW IF NOT EXISTS MarkList AS
    SELECT Mark.Id,
           Mark.Parent,
           Mark2.Code AS ParentCode,
           Mark2.Description AS ParentDescription,
           Mark.Date1 AS Date1,
           Mark.Date2 AS Date2,
           Mark.Code AS Code,
           Mark.Description AS Description,
           Mark.More AS More
      FROM Mark AS Mark
           LEFT JOIN
           Mark AS Mark2 ON Mark.Parent = Mark2.Id;

-- View: MeterList
CREATE VIEW IF NOT EXISTS MeterList AS
    SELECT Meter.Id,
           Meter.Parent,
           Meter2.Code AS ParentCode,
           Meter2.Description AS ParentDescription,
           Meter.Date1 AS Date1,
           Meter.Date2 AS Date2,
           Meter.Code AS Code,
           Meter.Description AS Description,
           Meter.More AS More
      FROM Meter AS Meter
           LEFT JOIN
           Meter AS Meter2 ON Meter.Parent = Meter2.Id;

-- View: PriceList
CREATE VIEW IF NOT EXISTS PriceList AS
    SELECT Price.Id,
           Price.Parent,
           Price2.Code AS ParentCode,
           Price2.Description AS ParentDescription,
           Price.Date1 AS Date1,
           Price.Date2 AS Date2,
           Price.Code AS Code,
           Price.Description AS Description,
           Price.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Price.Info,
           Info.Code AS InfoCode,
           Info.Description AS InfoDescription,
           Price.Unit,
           Unit.Code AS UnitCode,
           Unit.Description AS UnitDescription,
           Price.More AS More
      FROM Price AS Price
           LEFT JOIN
           Price AS Price2 ON Price.Parent = Price2.Id
           LEFT JOIN
           Role AS Role ON Price.Role = Role.Id
           LEFT JOIN
           Info AS Info ON Price.Info = Info.Id
           LEFT JOIN
           Unit AS Unit ON Price.Unit = Unit.Id;

-- View: ProcessList
CREATE VIEW IF NOT EXISTS ProcessList AS
    SELECT Process.Id,
           Process.Parent,
           Process2.Code AS ParentCode,
           Process2.Description AS ParentDescription,
           Process.Face1,
           Face1.Code AS Face1Code,
           Face1.Description AS Face1Description,
           Process.Face2,
           Face2.Code AS Face2Code,
           Face2.Description AS Face2Description,
           Process.Face,
           Face.Code AS FaceCode,
           Face.Description AS FaceDescription,
           Process.Slice,
           Slice.Code AS SliceCode,
           Slice.Description AS SliceDescription,
           Process.Date1 AS Date1,
           Process.Date2 AS Date2,
           Process.Code AS Code,
           Process.Description AS Description,
           Process.Sign,
           Sign.Code AS SignCode,
           Sign.Description AS SignDescription,
           Process.Account,
           T9.Code AS AccountCode,
           T9.Description AS AccountDescription,
           Process.Asset,
           Asset.Code AS AssetCode,
           Asset.Description AS AssetDescription,
           Process.Deal,
           Deal.Code AS DealCode,
           Deal.Description AS DealDescription,
           Process.Item,
           Item.Code AS ItemCode,
           Item.Description AS ItemDescription,
           Process.Debt,
           Debt.Code AS DebtCode,
           Debt.Description AS DebtDescription,
           Process.Price,
           Price.Code AS PriceCode,
           Price.Description AS PriceDescription,
           Process.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Process.Info,
           Info.Code AS InfoCode,
           Info.Description AS InfoDescription,
           Process.Meter,
           Meter.Code AS MeterCode,
           Meter.Description AS MeterDescription,
           Process.MeterValue AS MeterValue,
           Process.Unit,
           Unit.Code AS UnitCode,
           Unit.Description AS UnitDescription,
           Process.More AS More
      FROM Process AS Process
           LEFT JOIN
           Process AS Process2 ON Process.Parent = Process2.Id
           LEFT JOIN
           Slice AS Slice ON Process.Slice = Slice.Id
           LEFT JOIN
           Face AS Face ON Process.Face = Face.Id
           LEFT JOIN
           Face AS Face1 ON Process.Face1 = Face1.Id
           LEFT JOIN
           Face AS Face2 ON Process.Face2 = Face2.Id
           LEFT JOIN
           Account AS T9 ON Process.Account = T9.Id
           LEFT JOIN
           Role AS Role ON Process.Role = Role.Id
           LEFT JOIN
           Info AS Info ON Process.Info = Info.Id
           LEFT JOIN
           Sign AS Sign ON Process.Sign = Sign.Id
           LEFT JOIN
           Unit AS Unit ON Process.Unit = Unit.Id
           LEFT JOIN
           Debt AS Debt ON Process.Debt = Debt.Id
           LEFT JOIN
           Item AS Item ON Process.Item = Item.Id
           LEFT JOIN
           Deal AS Deal ON Process.Deal = Deal.Id
           LEFT JOIN
           Price AS Price ON Process.Price = Price.Id
           LEFT JOIN
           Asset AS Asset ON Process.Asset = Asset.Id
           LEFT JOIN
           Meter AS Meter ON Process.Meter = Meter.Id;

-- View: RoleList
CREATE VIEW IF NOT EXISTS RoleList AS
    SELECT Role.Id,
           Role.Parent,
           Role2.Code AS ParentCode,
           Role2.Description AS ParentDescription,
           Role.Date1 AS Date1,
           Role.Date2 AS Date2,
           Role.Code AS Code,
           Role.Description AS Description,
           Role.More AS More
      FROM Role AS Role
           LEFT JOIN
           Role AS Role2 ON Role.Parent = Role2.Id;

-- View: SignList
CREATE VIEW IF NOT EXISTS SignList AS
    SELECT Sign.Id,
           Sign.Parent,
           Sign2.Code AS ParentCode,
           Sign2.Description AS ParentDescription,
           Sign.Date1 AS Date1,
           Sign.Date2 AS Date2,
           Sign.Code AS Code,
           Sign.Description AS Description,
           Sign.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Sign.Info,
           Info.Code AS InfoCode,
           Info.Description AS InfoDescription,
           Sign.More AS More
      FROM Sign AS Sign
           LEFT JOIN
           Sign AS Sign2 ON Sign.Parent = Sign2.Id
           LEFT JOIN
           Role AS Role ON Sign.Role = Role.Id
           LEFT JOIN
           Info AS Info ON Sign.Info = Info.Id;

-- View: SliceList
CREATE VIEW IF NOT EXISTS SliceList AS
    SELECT Slice.Id,
           Slice.Parent,
           Slice2.Code AS ParentCode,
           Slice2.Description AS ParentDescription,
           Slice.Date1 AS Date1,
           Slice.Date2 AS Date2,
           Slice.Code AS Code,
           Slice.Description AS Description,
           Slice.More AS More
      FROM Slice AS Slice
           LEFT JOIN
           Slice AS Slice2 ON Slice.Parent = Slice2.Id;

-- View: UnitList
CREATE VIEW IF NOT EXISTS UnitList AS
    SELECT Unit.Id,
           Unit.Parent,
           Unit2.Code AS ParentCode,
           Unit2.Description AS ParentDescription,
           Unit.Date1 AS Date1,
           Unit.Date2 AS Date2,
           Unit.Code AS Code,
           Unit.Description AS Description,
           Unit.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Unit.More AS More
      FROM Unit AS Unit
           LEFT JOIN
           Unit AS Unit2 ON Unit.Parent = Unit2.Id
           LEFT JOIN
           Role AS Role ON Unit.Role = Role.Id;

-- View: WorkbookList
CREATE VIEW IF NOT EXISTS WorkbookList AS
    SELECT Workbook.Id,
           Workbook.Parent,
           Workbook2.Code AS ParentCode,
           Workbook2.Description AS ParentDescription,
           Workbook.Face1,
           Face1.Code AS Face1Code,
           Face1.Description AS Face1Description,
           Workbook.Face2,
           Face2.Code AS Face2Code,
           Face2.Description AS Face2Description,
           Workbook.Face,
           Face.Code AS FaceCode,
           Face.Description AS FaceDescription,
           Workbook.Slice,
           Slice.Code AS SliceCode,
           Slice.Description AS SliceDescription,
           Workbook.Date1 AS Date1,
           Workbook.Date2 AS Date2,
           Workbook.Code AS Code,
           Workbook.Description AS Description,
           Workbook.Geo,
           Geo.Code AS GeoCode,
           Geo.Description AS GeoDescription,
           Workbook.Sign,
           Sign.Code AS SignCode,
           Sign.Description AS SignDescription,
           Workbook.Account,
           Account.Code AS AccountCode,
           Account.Description AS AccountDescription,
           Workbook.Process,
           Process.Code AS ProcessCode,
           Process.Description AS ProcessDescription,
           Workbook.Debt,
           Debt.Code AS DebtCode,
           Debt.Description AS DebtDescription,
           Workbook.Item,
           Item.Code AS ItemCode,
           Item.Description AS ItemDescription,
           Workbook.Deal,
           Deal.Code AS DealCode,
           Deal.Description AS DealDescription,
           Workbook.Price,
           Price.Code AS PriceCode,
           Price.Description AS PriceDescription,
           Workbook.Asset,
           Asset.Code AS AssetCode,
           Asset.Description AS AssetDescription,
           Workbook.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Workbook.Info,
           Info.Code AS InfoCode,
           Info.Description AS InfoDescription,
           Workbook.Meter,
           Meter.Code AS MeterCode,
           Meter.Description AS MeterDescription,
           Workbook.MeterValue AS MeterValue,
           Workbook.Unit,
           Unit.Code AS UnitCode,
           Unit.Description AS UnitDescription,
           Workbook.Mark,
           Mark.Code AS MarkCode,
           Mark.Description AS MarkDescription
      FROM Workbook AS Workbook
           LEFT JOIN
           Workbook AS Workbook2 ON Workbook.Parent = Workbook2.Id
           LEFT JOIN
           Mark AS Mark ON Workbook.Mark = Mark.Id
           LEFT JOIN
           Slice AS Slice ON Workbook.Slice = Slice.Id
           LEFT JOIN
           Face AS Face ON Workbook.Face = Face.Id
           LEFT JOIN
           Face AS Face1 ON Workbook.Face1 = Face1.Id
           LEFT JOIN
           Face AS Face2 ON Workbook.Face2 = Face2.Id
           LEFT JOIN
           Geo AS Geo ON Workbook.Geo = Geo.Id
           LEFT JOIN
           Account AS Account ON Workbook.Account = Account.Id
           LEFT JOIN
           Role AS Role ON Workbook.Role = Role.Id
           LEFT JOIN
           Info AS Info ON Workbook.Info = Info.Id
           LEFT JOIN
           Sign AS Sign ON Workbook.Sign = Sign.Id
           LEFT JOIN
           Unit AS Unit ON Workbook.Unit = Unit.Id
           LEFT JOIN
           Process AS Process ON Workbook.Process = Process.Id
           LEFT JOIN
           Debt AS Debt ON Workbook.Debt = Debt.Id
           LEFT JOIN
           Item AS Item ON Workbook.Item = Item.Id
           LEFT JOIN
           Deal AS Deal ON Workbook.Deal = Deal.Id
           LEFT JOIN
           Price AS Price ON Workbook.Price = Price.Id
           LEFT JOIN
           Asset AS Asset ON Workbook.Asset = Asset.Id
           LEFT JOIN
           Meter AS Meter ON Workbook.Meter = Meter.Id;