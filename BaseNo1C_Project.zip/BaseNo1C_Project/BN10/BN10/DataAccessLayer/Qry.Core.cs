﻿namespace BN;
[Serializable]
public partial class Qry
{//созд - 2022, изм - 06.07.2022
    public static string? BuildQrySqlSelectDb()
    {
        string? qrySql = "";
        qrySql += "SELECT [name] from sys.databases";

        //TraceState(qrySql, "BuildQrySqlSelectDb(...), qrySql ");
        return qrySql;
    }
    public static string? BuildQrySqlSelectTable(string? tableView, string? templateCode = null, string? templateDescription = null, string? templateMore = null)
    {//изм - 06.07.2022
        string? qrySql = "";
        if (tableView == null)
        {
            return qrySql;
        }
        tableView = tableView.Trim();
        qrySql += "SELECT * FROM dbo." + tableView.ToString();
        if ((templateCode is not null) || (templateDescription is not null) || (templateMore is not null))
        {
            qrySql += " WHERE ";
            if (templateCode != null)
            {
                templateCode = templateCode.Trim();
                qrySql += "Code LIKE " + templateCode.ToString();
                if ((templateDescription != null) || (templateMore != null))
                {
                    qrySql += " AND ";
                }
            }
            if (templateDescription != null)
            {
                templateDescription = templateDescription.Trim();
                qrySql += "Description LIKE " + templateDescription.ToString();
                if (templateMore != null)
                {
                    qrySql += " AND ";
                }
            }
            if (templateMore != null)
            {
                templateMore = templateMore.Trim();
                qrySql += "More LIKE " + templateMore.ToString();
            }
        }

        //TraceState(qrySql, "BuildQrySqlSelectTable(...), qrySql ");
        return qrySql;
    }
    public Qry() { }
    static Qry() { }
}
