﻿namespace BN;
[Serializable]
public partial class Qry
{
    public static string? BuildQuerySql(string? tableView,
                                        string? templateCode = null,
                                        string? templateDescription = null,
                                        string? templateMore = null)
    {
        string? qrySql = "";
        if (tableView != null)
        {
            qrySql += "SELECT * FROM dbo.";
            qrySql += tableView.ToString();
            if (templateCode is not null)   ////сделать чтобы WHERE был только если есть хоть один отбор
            {
                qrySql += " WHERE ";
            }
            else if (templateDescription is not null)
            {
                qrySql += " WHERE ";
            }
            else if (templateMore is not null)
            {
                qrySql += " WHERE ";
            }
            if (templateCode != null)  //фильтр по Code
            {
                qrySql += "Code LIKE ";
                qrySql += templateCode.ToString();
            }
            if (templateDescription != null)  //фильтр по Description
            {
                qrySql += "Description LIKE ";
                qrySql += templateDescription.ToString();
            }
            if (templateMore != null)  //фильтр по More
            {
                qrySql += "More LIKE ";
                qrySql += templateMore.ToString();
            }
        }

        //TraceState(qrySql, "BuildQuerySql(...), qrySql ");
        return qrySql;
    }
    public Qry() { }
    static Qry() { }
}
