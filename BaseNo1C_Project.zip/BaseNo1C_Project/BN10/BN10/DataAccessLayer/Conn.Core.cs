﻿namespace BN;
[Serializable]
public partial class Conn
{
    public static List<string>? ListBaseTableFact = default; //фактический список учетных баз
    public static List<string>? ListBaseEmergency = new() //список баз на экземпляре МС СКЛ,  если из внешнего файла Connection ничего не поступило
    {
        @"BaseN0",
        @"BaseN1",
        @"BaseN2",
        @"BaseN3",
    };
    public static List<string>? ListDataSourceEmergency = new() //DataSource для учетных баз, если из внешнего файла Connection ничего не поступило 
    {
        @".\SQLExpress",
        @"(local)",
        @".\SQL2017",
    };
    public static List<string> ListBaseTableExpected = new()  //список базовых таблиц ожидаемый  
    {
        "Account", "Asset", "Deal", "Face", "Geo", "Info", "Item", "Mark", "Meter", "Price", "Process",
        "Role", "Sign", "Slice", "Tax", "Unit", "Workbook",
    };
    public static List<string>? GetListDataSource()  //TODO - сделать поиск скл северов и выбор из них  
    {
        List<string>? outListDataSource = default;
        //TODO --- сделать выборку DataSource из внешнего файла Connection
        //если рез-та выборки нет, пытаемся присвоить теоретически возможные DataSource
        if (outListDataSource is null)
        {
            outListDataSource = ListDataSourceEmergency;
        }

        TraceState(outListDataSource?.Count, "GetListDataSource(...), outListDataSource?.Count ");
        return outListDataSource;
    }
    public static SqlConnection MainConnCurr = new();  //TODO -- основная Connection из внешнего файла
    public static SqlConnection MainConnDefault = new();
    public static SqlConnection MainConnDev = new();
    public static List<SqlConnection>? ListConnCurr = new();
    public static List<string>? ListDataSource = new();
    public static SqlConnection GetMainConnCurr()  //TODO -- получить основную Connection из внешнего файла, или из иных источников  
    {
        SqlConnection outMainConnCurr = new();
        SqlConnection testedConn = new();
        bool connIsValid = false;
        //if (ListConnCurr is null)  //если из внешнего файла не получено никаких Connection  
        //{
            //testedConn = GetConn(DataSource: @".\SQLExpress", InitialCatalog: "BaseN1");
            testedConn = MainConnDefault;
            connIsValid = TestConn(testedConn);
            if (connIsValid == false)
            {
                //outMainConnCurr = GetConn(DataSource: @".\SQL2017", InitialCatalog: "BaseN0");
                outMainConnCurr = MainConnDev;
            }
        //}

        TraceState(ConnToString(outMainConnCurr), "GetMainConnCurr(...), ConnToString(outMainConnCurr) ");
        return outMainConnCurr;
    }
    public static bool TestConn(SqlConnection testedConn)  //проверить Connection
    {
        bool outTestedConnIsValid = false;  //изначально считаем, что Connection нерабочая
        short? EtalonConnBaseTableCount = (short)ListBaseTableExpected.Count;
        List<string>? ListBaseTableFact = GetListBaseTableFact(testedConn);
        short? TestedConnBaseTableCount = new();
        if (ListBaseTableFact is not null)
        {
            TestedConnBaseTableCount = (short)ListBaseTableFact.Count;
            if (TestedConnBaseTableCount >= EtalonConnBaseTableCount)  //в текущей БД может быть больше таблиц, чем в эталонной БД
            {
                if (ListBaseTableExpected.SequenceEqual(ListBaseTableFact))
                {
                    outTestedConnIsValid = true;
                }
            }
        }

        //TraceState(ConnToString(testedConn)+ outTestedConnIsValid.ToString(), "TestConn(...), ConnToString(testedConn)+ outTestedConnIsValid.ToString() ");
        return outTestedConnIsValid;
    }
    public static List<SqlConnection>? GetListConnCurr()  //получить список основных Connection из внешнего файла
    {
        List<SqlConnection>? outListConnCurr = new();
        //if ((short)ListConnCurr.Count = 0)
        //{
            outListConnCurr.Add(MainConnCurr);
        //}
        TraceState(outListConnCurr.Count(), "GetListConnCurr(...), outListConnCurr.Count() ");
        return outListConnCurr;
    }
    public static List<string>? GetListBaseTableFact(SqlConnection conn)  //получить фактический список базовых таблиц для Connection  
    {
        List<string>? outListBaseTableFact = new();
        try
        {
            conn.Open();
            DataTable tbl = conn.GetSchema("Tables");
            foreach (DataRow row in tbl.Rows)
            {
                if (row["TABLE_TYPE"].ToString() == "BASE TABLE")
                {
                    outListBaseTableFact.Add(row["TABLE_NAME"].ToString() ?? "No base table");
                }
            }
            conn.Close();
            conn.Dispose();
            outListBaseTableFact.Sort();
        }
        //catch (Exception ex)
        catch
        {
            //TraceState(ex.Message, "GetListBaseTableFact(...), ex.Message ");
        }
        finally { }
        
        //TraceState(outListBaseTableFact.Count(), "GetListBaseTable(...), outListBaseTableFact.Count() ");
        return outListBaseTableFact;
    }
    public static SqlConnection BuildSqlConn(SqlConnectionStringBuilder SqlConnStrBuild)
    {
        return new()
        {
            ConnectionString = SqlConnStrBuild.ConnectionString,
        };
    }
    public static SqlConnectionStringBuilder BuildSqlConnStrBuilder(string dataSource = @".\SQLExpress", string initialCatalog = "BaseN1")  //по умолчанию, если нет никаких данных Connection
    {
        SqlConnectionStringBuilder SqlConnStrBuild = new();
        SqlConnStrBuild.DataSource = dataSource;
        SqlConnStrBuild.InitialCatalog = initialCatalog;
        SqlConnStrBuild.IntegratedSecurity = true;
        SqlConnStrBuild.ConnectTimeout = 30;
        return SqlConnStrBuild;
    }
    public static SqlConnection GetConn(string DataSource = @".\SQLExpress", string InitialCatalog = "BaseN1")
    {
        //получить Connection по DataSource и InitialCatalog, без проверки, просто объект  
        SqlConnection outSqlConn = new();
        SqlConnectionStringBuilder? SqlConnStrBuild = BuildSqlConnStrBuilder(dataSource: DataSource, initialCatalog: InitialCatalog);
        outSqlConn = BuildSqlConn(SqlConnStrBuild);

        //TraceState(ConnToString(outSqlConn), "GetConn(...), ConnToString(outSqlConn) ");
        return outSqlConn;
    }
    public Conn() { }
    static Conn() { }
    public static string ConnToString(SqlConnection conn)
    {
        return $"{conn.GetType()}, {conn.ConnectionString ?? "No ConnectionString"}";
    }
}