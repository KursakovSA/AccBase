﻿namespace BN;
[Serializable]
public partial class Conn
{//созд - 2022, изм - 10.07.2022
    public static List<string>? ListBaseTableFact = default; //фактический список учетных баз
    public static List<string>? ListBaseEmergency = new() //список баз на экземпляре МС СКЛ,  если из внешнего файла Connection ничего не поступило
    {//созд - 2022, изм - 2022
        @"BaseN0",
        @"BaseN1",
        @"BaseN2",
        @"BaseN3",
    };
    public static List<string>? ListDataSourceEmergency = new() //DataSource для учетных баз, если из внешнего файла Connection ничего не поступило 
    {//созд - 2022, изм - 2022
        @".\SQLExpress",
        @"(local)",
        @".\SQL2017",
    };
    public static List<string> ListBaseTableExpected = new()  //список базовых таблиц ожидаемый  
    {//созд - 2022, изм - 2022
        "Account", "Asset", "Deal", "Face", "Geo", "Info", "Item", "Mark", "Meter", "Price", "Process",
        "Role", "Sign", "Slice", "Tax", "Unit", "Workbook",
    };
    public static List<string>? GetListDataSource()  //TODO - сделать поиск скл северов и выбор из них  
    {//созд - 2022, изм - 2022
        List<string>? outListDataSource = default;
        //TODO --- сделать выборку DataSource из внешнего файла Connection
        //если рез-та выборки нет, пытаемся присвоить теоретически возможные DataSource
        if (outListDataSource is null)
        {
            outListDataSource = ListDataSourceEmergency;
        }

        TraceState(outListDataSource?.Count, "GetListDataSource(...), outListDataSource?.Count ");
        return outListDataSource;
    }
    public static SqlConnection MainConnCurr = new();  //TODO -- основная Connection из внешнего файла
    //public static SqlConnection MainConnCurr2 = new();  //TODO -- основная Connection из внешнего файла
    public static SqlConnection MainConnDefault = new();
    public static SqlConnection MainConnDev = new();
    public static List<SqlConnection>? ListConnCurr = new();
    public static List<string>? ListDataSource = new();
    public static void GetConn()
    {//созд - 2022, изм - 2022
        MainConnDefault = Conn.GetConn(DataSource: @".\SQLExpress", InitialCatalog: "BaseN1");
        MainConnDev = Conn.GetConn(DataSource: @".\SQL2017", InitialCatalog: "BaseN0");
        GetMainConnCurr();
    }
    public static void GetMainConnCurr()  //TODO -- получить основную Connection из внешнего файла, или из иных источников  
    {//созд - 2022, изм - 09.07.2022
        SqlConnection testedConn = new();
        //if (ListConnCurr is null)  //если из внешнего файла не получено никаких Connection  
        //{
        bool connIsValid = TestConn(MainConnDefault);
        if (connIsValid == false)
        {
            MainConnCurr = MainConnDev;
            //MainConnCurr2 = MainConnDev;
        }
        //}

        //TraceState(ConnToString(MainConnCurr), "GetMainConnCurr(...), ConnToString(MainConnCurr) ");
    }
    public static bool TestConn(SqlConnection testedConn)  //проверить Connection
    {//созд - 2022, изм - 2022
        bool outTestedConnIsValid = false;  //изначально считаем, что Connection нерабочая
        short? EtalonConnBaseTableCount = (short)ListBaseTableExpected.Count;
        List<string>? ListBaseTableFact = GetListBaseTableFact(testedConn);
        short? TestedConnBaseTableCount = new();
        if (ListBaseTableFact is not null)
        {
            TestedConnBaseTableCount = (short)ListBaseTableFact.Count;
            if (TestedConnBaseTableCount >= EtalonConnBaseTableCount)  //в текущей БД может быть больше таблиц, чем в эталонной БД
            {
                if (ListBaseTableExpected.SequenceEqual(ListBaseTableFact))
                {
                    outTestedConnIsValid = true;
                }
            }
        }

        //TraceState(ConnToString(testedConn)+ outTestedConnIsValid.ToString(), "TestConn(...), ConnToString(testedConn)+ outTestedConnIsValid.ToString() ");
        return outTestedConnIsValid;
    }
    public static List<SqlConnection>? GetListConnCurr()  //получить список основных Connection из внешнего файла
    {//созд - 2022, изм - 2022
        List<SqlConnection>? outListConnCurr = new();
        //if ((short)ListConnCurr.Count = 0)
        //{
            outListConnCurr.Add(MainConnCurr);
        //}
        TraceState(outListConnCurr.Count(), "GetListConnCurr(...), outListConnCurr.Count() ");
        return outListConnCurr;
    }
    public static List<string>? GetListBaseTableFact(SqlConnection conn)  //получить фактический список базовых таблиц для Connection  
    {//созд - 2022, изм - 2022
        List<string>? outListBaseTableFact = new();
        try
        {
            conn.Open();
            DataTable tbl = conn.GetSchema("Tables");
            foreach (DataRow row in tbl.Rows)
            {
                if (row["TABLE_TYPE"].ToString() == "BASE TABLE")
                {
                    outListBaseTableFact.Add(row["TABLE_NAME"].ToString() ?? "No base table");
                }
            }
            conn.Close();
            conn.Dispose();
            outListBaseTableFact.Sort();
        }
        //catch (Exception ex)
        catch
        {
            //TraceState(ex.Message, "GetListBaseTableFact(...), ex.Message ");
        }
        finally { }
        
        //TraceState(outListBaseTableFact.Count(), "GetListBaseTable(...), outListBaseTableFact.Count() ");
        return outListBaseTableFact;
    }
    public static SqlConnection BuildSqlConn(SqlConnectionStringBuilder SqlConnStrBuild)
    {//созд - 2022, изм - 2022
        return new()
        {
            ConnectionString = SqlConnStrBuild.ConnectionString,
        };
    }
    public static SqlConnectionStringBuilder BuildSqlConnStrBuilder(string dataSource = @".\SQLExpress", string initialCatalog = "BaseN1")  //по умолчанию, если нет никаких данных Connection
    {//созд - 2022, изм - 2022
        SqlConnectionStringBuilder SqlConnStrBuild = new();
        SqlConnStrBuild.DataSource = dataSource;
        SqlConnStrBuild.InitialCatalog = initialCatalog;
        SqlConnStrBuild.IntegratedSecurity = true;
        return SqlConnStrBuild;
    }
    public static SqlConnection GetConn(string DataSource = @".\SQLExpress", string InitialCatalog = "BaseN1")
    {//созд - 2022, изм - 2022
        //получить Connection по DataSource и InitialCatalog, без проверки, просто объект  
        SqlConnection outSqlConn = new();
        SqlConnectionStringBuilder? SqlConnStrBuild = BuildSqlConnStrBuilder(dataSource: DataSource, initialCatalog: InitialCatalog);
        outSqlConn = BuildSqlConn(SqlConnStrBuild);

        //TraceState(ConnToString(outSqlConn), "GetConn(...), ConnToString(outSqlConn) ");
        return outSqlConn;
    }
    public Conn() { }
    static Conn() { }
    public static string ConnToString(SqlConnection conn)
    {//созд - 2022, изм - 2022
        return $"{conn.GetType()}, {conn.ConnectionString ?? "No ConnectionString"}";
    }
}