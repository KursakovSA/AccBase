﻿namespace BN;
[Serializable]
public partial class DataAccessLayer
{
    public static void GetListBaseTable(List<string>? ListBaseTable, SqlConnection? conn = default)
    {
        try { }
        catch { }
        finally { }
        //TraceState(ListBaseTable?.Count, "TestListBaseTable(...), ListBaseTable.Count ");
    }
    public static List<object> GetTable(SqlConnection conn,
                                        string table,
                                        string? templateCode = null,
                                        string? templateDescription = null,
                                        string? templateMore = null)
    {
        List<object> outListTable = new();
        table = GetTableViewNameQuery(table);    //на всякий случай преобразуем что-либо типа "Account" в "AccountList"
        string? qrySql = BuildQuerySql(table,
                                       templateCode: templateCode,
                                       templateDescription: templateDescription,
                                       templateMore: templateMore);
        try
        {
            SqlCommand sqlComm = new SqlCommand(qrySql, conn);
            conn.Open();
            using (SqlDataReader DataReader = sqlComm.ExecuteReader())
            {
                if (DataReader.HasRows)
                {
                    while (DataReader.Read())
                    {
                        AddListTable(table, outListTable, DataReader);
                    }
                }
                DataReader.Close();
            }
            conn.Close();
            conn.Dispose();
        }
        catch (Exception ex)
        {
            TraceState(ex.Message, "GetTable(...), ex.Message ");
        }
        finally { }

        TraceState(outListTable.Count, "GetTable(...), outListTable.Count " + table.ToString());
        return outListTable;
    }
    public static void AddListTable(string tbl, List<object> lstTbl, SqlDataReader dr)
    {
        //TODO --- потом как-нибудь может быть сделать что-то типа делегата, указание на метод в зависимости от наим-я таблицы   
        if (tbl == "AccountList")
        {
            lstTbl.Add(NewAccount(dr));
        }
        if (tbl == "AssetList")
        {
            lstTbl.Add(NewAsset(dr));
        }
        if (tbl == "DealList")
        {
            lstTbl.Add(NewDeal(dr));
        }
        if (tbl == "GeoList")
        {
            lstTbl.Add(NewGeo(dr));
        }
        if (tbl == "InfoList")
        {
            lstTbl.Add(NewInfo(dr));
        }
        if (tbl == "ItemList")
        {
            lstTbl.Add(NewItem(dr));
        }
        if (tbl == "FaceList")
        {
            lstTbl.Add(NewFace(dr));
        }
        if (tbl == "MarkList")
        {
            lstTbl.Add(NewMark(dr));
        }
        if (tbl == "SliceList")
        {
            lstTbl.Add(NewSlice(dr));
        }
        if (tbl == "SignList")
        {
            lstTbl.Add(NewSign(dr));
        }
        if (tbl == "MeterList")
        {
            lstTbl.Add(NewMeter(dr));
        }
        if (tbl == "RoleList")
        {
            lstTbl.Add(NewRole(dr));
        }
        if (tbl == "PriceList")
        {
            lstTbl.Add(NewPrice(dr));
        }
        if (tbl == "UnitList")
        {
            lstTbl.Add(NewUnit(dr));
        }
        if (tbl == "TaxList")
        {
            lstTbl.Add(NewTax(dr));
        }
        if (tbl == "ProcessList")
        {
            lstTbl.Add(NewProcess(dr));
        }
        if (tbl == "WorkbookList")
        {
            lstTbl.Add(NewWorkbook(dr));
        }
    }
    public static Workbook NewWorkbook(SqlDataReader dr)
    {
        return new Workbook
        {
            Id = GetId<int>(dr),
            Parent = GetWorkbook(dr, "Parent"),
            Face1 = GetFace(dr, "Face1"),
            Face2 = GetFace(dr, "Face2"),
            Face = GetFace(dr, "Face"),
            Slice = GetSlice(dr, "Slice"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Geo = GetGeo(dr, "Geo"),
            Sign = GetSign(dr, "Sign"),
            Account = GetAccount(dr, "Account1"),
            Workbook1 = GetWorkbook(dr, "Workbook1"),
            Process1 = GetProcess(dr, "Process1"),
            Asset = GetAsset(dr, "Asset1"),
            Deal = GetDeal(dr, "Deal"),
            Item = GetItem(dr, "Item"),
            Tax = GetTax(dr, "Tax"),
            Price = GetPrice(dr, "Price"),
            Role = GetRole(dr, "Role"),
            Info = GetInfo(dr, "Info"),
            Meter = GetMeter(dr, "Meter"),
            MeterValue = GetSimpleString(dr, "MeterValue"),
            Unit = GetUnit(dr, "Unit"),
            More = GetSimpleString(dr, "More"),
            Mark = GetMark(dr, "Mark"),
        };
    }
    public static Process NewProcess(SqlDataReader dr)
    {
        return new Process
        {
            Id = GetId<short>(dr),
            Parent = GetProcess(dr, "Parent"),
            Face1 = GetFace(dr, "Face1"),
            Face2 = GetFace(dr, "Face2"),
            Face = GetFace(dr, "Face"),
            Slice = GetSlice(dr, "Slice"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Sign = GetSign(dr, "Sign"),
            Account = GetAccount(dr, "Account1"),
            Workbook1 = GetWorkbook(dr, "Workbook1"),
            Workbook2 = GetWorkbook(dr, "Workbook2"),
            Process1 = GetProcess(dr, "Process1"),
            Asset = GetAsset(dr, "Asset1"),
            Deal = GetDeal(dr, "Deal"),
            Item = GetItem(dr, "Item"),
            Tax = GetTax(dr, "Tax"),
            Price = GetPrice(dr, "Price"),
            Role = GetRole(dr, "Role"),
            Info = GetInfo(dr, "Info"),
            Meter = GetMeter(dr, "Meter"),
            MeterValue = GetSimpleString(dr, "MeterValue"),
            Unit = GetUnit(dr, "Unit"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Tax NewTax(SqlDataReader dr)
    {
        return new Tax
        {
            Id = GetId<short>(dr),
            Parent = GetTax(dr, "Parent"),
            Face1 = GetFace(dr, "Face1"),
            Face2 = GetFace(dr, "Face2"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Geo = GetGeo(dr, "Geo"),
            Role = GetRole(dr, "Role"),
            Info = GetInfo(dr, "Info"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Unit NewUnit(SqlDataReader dr)
    {
        return new Unit
        {
            Id = GetId<short>(dr),
            Parent = GetUnit(dr, "Parent"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Role = GetRole(dr, "Role"),
            Unit1 = GetUnit(dr, "Unit"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Price NewPrice(SqlDataReader dr)
    {
        return new Price
        {
            Id = GetId<short>(dr),
            Parent = GetPrice(dr, "Parent"),
            Face1 = GetFace(dr, "Face1"),
            Face2 = GetFace(dr, "Face2"),
            Face = GetFace(dr, "Face"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Role = GetRole(dr, "Role"),
            Info = GetInfo(dr, "Info"),
            Unit = GetUnit(dr, "Unit"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Role NewRole(SqlDataReader dr)
    {
        return new Role
        {
            Id = GetId<byte>(dr),
            Parent = GetRole(dr, "Parent"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Meter NewMeter(SqlDataReader dr)
    {
        return new Meter
        {
            Id = GetId<byte>(dr),
            Parent = GetMeter(dr, "Parent"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Unit = GetUnit(dr, "Unit"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Sign NewSign(SqlDataReader dr)
    {
        return new Sign
        {
            Id = GetId<byte>(dr),
            Parent = GetSign(dr, "Parent"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Role = GetRole(dr, "Role"),
            Info = GetInfo(dr, "Info"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Slice NewSlice(SqlDataReader dr)
    {
        return new Slice
        {
            Id = GetId<byte>(dr),
            Parent = GetSlice(dr, "Parent"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Mark NewMark(SqlDataReader dr)
    {
        return new Mark
        {
            Id = GetId<byte>(dr),
            Parent = GetMark(dr, "Parent"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Face NewFace(SqlDataReader dr)
    {
        return new Face
        {
            Id = GetId<int>(dr),
            Parent = GetFace(dr, "Parent"),
            Face1 = GetFace(dr, "Face1"),
            Face2 = GetFace(dr, "Face2"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Geo = GetGeo(dr, "Geo"),
            Role = GetRole(dr, "Role"),
            Info = GetInfo(dr, "Info"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Item NewItem(SqlDataReader dr)
    {
        return new Item
        {
            Id = GetId<short>(dr),
            Parent = GetItem(dr, "Parent"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Info NewInfo(SqlDataReader dr)
    {
        return new Info
        {
            Id = GetId<short>(dr),
            Parent = GetInfo(dr, "Parent"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Geo NewGeo(SqlDataReader dr)
    {
        return new Geo
        {
            Id = GetId<short>(dr),
            Parent = GetGeo(dr, "Parent"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Role = GetRole(dr, "Role"),
            Unit = GetUnit(dr, "Unit"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Deal NewDeal(SqlDataReader dr)
    {
        return new Deal
        {
            Id = GetId<int>(dr),
            Parent = GetDeal(dr, "Parent"),
            Face1 = GetFace(dr, "Face1"),
            Face2 = GetFace(dr, "Face2"),
            Face = GetFace(dr, "Face"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Geo = GetGeo(dr, "Geo"),
            Role = GetRole(dr, "Role"),
            Info = GetInfo(dr, "Info"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Asset NewAsset(SqlDataReader dr)
    {
        return new Asset
        {
            Id = GetId<int>(dr),
            Parent = GetAsset(dr, "Parent"),
            Face1 = GetFace(dr, "Face1"),
            Face2 = GetFace(dr, "Face2"),
            Face = GetFace(dr, "Face"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Geo = GetGeo(dr, "Geo"),
            Asset1 = GetAsset(dr, "Asset1"),
            Role = GetRole(dr, "Role"),
            Info = GetInfo(dr, "Info"),
            Unit = GetUnit(dr, "Unit"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Account NewAccount(SqlDataReader dr)
    {
        return new Account
        {
            Id = GetId<short>(dr),
            Parent = GetAccount(dr, "Parent"),
            Slice = GetSlice(dr, "Slice"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Account1 = GetAccount(dr, "Account1"),
            Role = GetRole(dr, "Role"),
            Sign = GetSign(dr, "Sign"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static T? GetId<T>(SqlDataReader dr)
    {
        T? outObj = default;
        if (dr["Id"].GetType().ToString() != "System.DBNull")
        {
            outObj = (T)dr["Id"];
        }

        //TraceState(outObj, "GetId(...), outObj ");
        return outObj;
    }
    public static Asset? GetAsset(SqlDataReader dr, string? NameId = default)
    {
        Asset? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Asset { Id = (int)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetAsset(...), outObj ");
        return outObj;
    }
    public static Face? GetFace(SqlDataReader dr, string? NameId = default)
    {
        Face? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Face { Id = (int)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetFace(...), outObj ");
        return outObj;
    }
    public static Deal? GetDeal(SqlDataReader dr, string? NameId = default)
    {
        Deal? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Deal { Id = (int)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetDeal(...), outObj ");
        return outObj;
    }
    public static Geo? GetGeo(SqlDataReader dr, string? NameId = default)
    {
        Geo? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Geo { Id = (short)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetGeo(...), outObj ");
        return outObj;
    }
    public static Tax? GetTax(SqlDataReader dr, string? NameId = default)
    {
        Tax? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Tax { Id = (short)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetTax(...), outObj ");
        return outObj;
    }
    public static Price? GetPrice(SqlDataReader dr, string? NameId = default)
    {
        Price? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Price { Id = (short)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetPrice(...), outObj ");
        return outObj;
    }
    public static Meter? GetMeter(SqlDataReader dr, string? NameId = default)
    {
        Meter? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Meter { Id = (byte)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetMeter(...), outObj ");
        return outObj;
    }
    public static Role? GetRole(SqlDataReader dr, string? NameId = default)
    {
        Role? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Role { Id = (short)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetRole(...), outObj ");
        return outObj;
    }
    public static Info? GetInfo(SqlDataReader dr, string? NameId = default)
    {
        Info? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Info { Id = (short)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetInfo(...), outObj ");
        return outObj;
    }
    public static Item? GetItem(SqlDataReader dr, string? NameId = default)
    {
        Item? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Item { Id = (short)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetItem(...), outObj ");
        return outObj;
    }
    public static Slice? GetSlice(SqlDataReader dr, string? NameId = default)
    {
        Slice? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Slice { Id = (byte)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetSlice(...), outObj ");
        return outObj;
    }
    public static Sign? GetSign(SqlDataReader dr, string? NameId = default)
    {
        Sign? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Sign { Id = (byte)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetSign(...), outObj ");
        return outObj;
    }
    public static Mark? GetMark(SqlDataReader dr, string? NameId = default)
    {
        Mark? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Mark { Id = (byte)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetMark(...), outObj ");
        return outObj;
    }
    public static Account? GetAccount(SqlDataReader dr, string? NameId = default)
    {
        Account? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Account { Id = (short)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetAccount(...), outObj ");
        return outObj;
    }
    public static Unit? GetUnit(SqlDataReader dr, string? NameId = default)
    {
        Unit? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Unit { Id = (short)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetUnit(...), outObj ");
        return outObj;
    }
    public static Workbook? GetWorkbook(SqlDataReader dr, string? NameId = default)
    {
        Workbook? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Workbook { Id = (int)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetWorkbook(...), outObj ");
        return outObj;
    }
    public static Process? GetProcess(SqlDataReader dr, string? NameId = default)
    {
        Process? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Process { Id = (short)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetProcess(...), outObj ");
        return outObj;
    }
    public static DateTimeOffset? GetDate1(SqlDataReader dr)
    {
        DateTimeOffset? outObj = default;
        if (dr["Date1"].GetType().ToString() != "System.DBNull")
        {
            outObj = (DateTimeOffset)dr["Date1"];
        }

        //TraceState(outObj, "GetData1(...), outObj ");
        return outObj;
    }
    public static string? GetSimpleString(SqlDataReader dr, string? NameStr = default)
    {
        string? outObj = default;
        if (dr[NameStr].GetType().ToString() != "System.DBNull")
        {
            outObj = (string)dr[NameStr];
        }

        //TraceState(outObj, "GetSimpleString(...), outObj ");
        return outObj;
    }
    public static string GetTableViewNameQuery(string table)
    {
        //получаем из имени таблицы\класса в запросе типа "Account" "чистое" имя представления типа "AccountList"
        string TableViewNameQuery = table.Trim();
        if (table != null)
        {
            TableViewNameQuery = TableViewNameQuery.Replace("List", "");  //сначала удалим суффикс List, вдруг он есть
            TableViewNameQuery += "List";  //добавим суффикс "List" для получения имени представления типа "AccountList"
        }

        //TraceState(table, "GetTableViewNameQuery(...), table ");
        //TraceState(TableViewNameQuery, "GetTableViewNameQuery(...), TableViewNameQuery ");
        return TableViewNameQuery;
    }
    public static string GetTableNameQuery(string tableView)
    {
        //получаем из имени таблицы или view в запросе типа "AccountList" "чистое" имя таблицы типа "Account"
        string TableNameQuery = tableView.Trim();
        if (tableView != null)
        {
            TableNameQuery = TableNameQuery.Replace("List", "");
        }

        //TraceState(tableView, "GetTableNameQuery(...), tableView ");
        //TraceState(TableNameQuery, "GetTableNameQuery(...), TableNameQuery ");
        return TableNameQuery;
    }
    public static string? GetNameCode(string? NameId = default)
    {
        //получаем из имени Id в запросе типа "Account" имя поля кода типа "AccountCode"
        string? NameCode = default;
        if (NameId != null)
        {
            NameCode = NameId + "Code";
        }

        //TraceState(NameId, "GetNameCode(...), NameId ");
        //TraceState(NameCode, "GetNameCode(...), NameCode");
        return NameCode;
    }
    public DataAccessLayer() { }
    static DataAccessLayer() { }
}
