﻿namespace BN;
[Serializable]
public partial class Util
{
    public static bool IsDev;
    public static Dictionary<string, string>? ListPartTab = new()
    {
        ["SelectBase"] = "",
        ["Dialog"] = "",
        ["Tree"] = "",
        ["Main"] = "",
        ["SelectSwitchMark"] = "",
        ["SelectSwitchSlice"] = "",
        ["Validation"] = "",
        ["Filter"] = "",
    };
    public static Dictionary<string, string>? ListAppTab = new()
    {
        ["List"] = "List",
        //["One"] = "One",  //думаю, нет нужды делать отдельный смысл One - List тоже может отображать одну строку, это и будет One   
        ["Detail"] = "Detail",
        ["Console"] = "Console",
    };
    public static string? StartDirectory;
    public static string? LastSaveDirectory;
    public static string? LastSelectFileDirectory;
    public Util() { }
    static Util() { }
}

