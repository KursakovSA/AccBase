﻿namespace BN;
public partial class Trace
{
    public static StringBuilder TraceLog = new StringBuilder("TraceLog" + Environment.NewLine);
    public static DateTimeOffset StartTestTime = DateTimeOffset.MinValue;
    public static DateTimeOffset FinishTestTime = DateTimeOffset.MinValue;
    public static TimeSpan SpanTestTime = new();
    public static List<Workbook> TraceObj = new();  //TODO - сделать заполнение этого списка объектами трассировки и их расчет  
    public static void TraceState(object? Obj = default, string? ContextObj = default, object? objFilter = default)
    {
        if (IsDev == true)
        {
            if ((objFilter != null) && (objFilter == Obj))
            {
                AddTraceLog(Obj, ContextObj);
            }
            if (objFilter == null)
            {
                AddTraceLog(Obj, ContextObj);
            }
        }
    }
    public static void AddTraceLog(object? Obj = default, string? ContextObj = default)
    {
        string? AddToTraceLog = "";
        if ((ContextObj != null) && (Obj != null))
        {
            AddToTraceLog = $"{ContextObj} = {Obj.ToString()}";   //{Environment.NewLine}";
        }
        if ((ContextObj == null) && (Obj != null))
        {
            AddToTraceLog = $"{Obj.ToString()}";   // {Environment.NewLine}";
        }
        if ((ContextObj != null) && (Obj == null))
        {
            AddToTraceLog = $"{ContextObj}";    // == {Environment.NewLine}";
        }
        if ((AddToTraceLog != null) && (AddToTraceLog != String.Empty))
        {
            TraceLog.AppendLine(AddToTraceLog);
        }
    }
    public static void AddTraceTime()
    {
        if (StartTestTime != DateTimeOffset.MinValue)
        {
            if (FinishTestTime != DateTimeOffset.MinValue)
            {
                TraceState(StartTestTime, "Main, Program, StartTestTime ");
                TraceState(FinishTestTime, "Main, Program, FinishTestTime ");
                //SpanTestTime = (TimeSpan)(FinishTestTime - StartTestTime);
                SpanTestTime = (TimeSpan)GetSpanTime(FinishTestTime, StartTestTime);
                TraceState(SpanTestTime, "Main, Program, SpanTestTime ");
            }
        }
    }
    static Trace() { }
    public Trace() { }
}