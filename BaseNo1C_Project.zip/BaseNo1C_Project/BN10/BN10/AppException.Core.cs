﻿namespace BN;
[Serializable]
public class NotValidPriceException : ApplicationException
{
    public decimal? GetPriceException(string? inPrice)
    {
        decimal? Price = default;
        try { }
        catch (NotValidPriceException e) { Console.WriteLine(e); }
        catch (Exception e) { Console.WriteLine(e); }
        finally { };
        return Price;
    }
}
