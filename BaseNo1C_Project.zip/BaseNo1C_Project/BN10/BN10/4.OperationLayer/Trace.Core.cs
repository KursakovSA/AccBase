﻿namespace BN;
[Serializable]
public partial class Trace
{//созд - 2022, изм - 28.07.2022
    public static List<Shell> TraceList = new();
    public static StringBuilder TraceLog = new StringBuilder("TraceLog Start" + Environment.NewLine + " " + Environment.NewLine);
    public static void WriteTraceList(List<Shell> trcList)
    {//созд - 2022, изм - 07.08.2022
        DateTimeOffset? predDate1 = null;
        //TimeSpan? currSpanTime = new();
        foreach (var trc in trcList)
        {
            //TraceLog.Append(FormatTraceItem(trc));
            //currSpanTime = (TimeSpan)(trc.Date1 - predDate1);
            //currSpanTime = GetSpanTime(predDate1, trc.Date1);
            //TraceLog.Append(currSpanTime + ", " + trc.Description + ", " + trc.Code + Environment.NewLine);
            TraceLog.Append(GetFormatSecondTimeSpan(GetSecondTimeSpan(GetSpanTime(predDate1, trc?.Date1))) + ", " + trc?.Description + ", " + trc?.Code + Environment.NewLine);
            predDate1 = trc?.Date1;
        }
        TraceLog.Append(" "+ Environment.NewLine + "TraceLog End" + Environment.NewLine);
    }
    public static void TraceState(object? Obj = default, string? ContextObj = default)
    {//созд - 2021, изм - 28.07.2022
        if (IsDev)
        {
            //AddTraceLog(Obj, ContextObj);
            AddTraceList(Obj, ContextObj);
        }
    }
    public static void AddTraceList(object? Obj = default, string? ContextObj = default)
    {
        TraceList.Add(new Shell { Date1 = DateTimeOffset.Now, Code = Obj?.ToString(), Description = ContextObj?.ToString() });
    }
    public static void AddTraceLog(object? Obj = default, string? ContextObj = default)
    {//созд - 2021, изм - 28.07.2022
        string? AddToTraceLog = "";
        if ((ContextObj != null) && (Obj != null))
        {
            AddToTraceLog = $"{ContextObj} = {Obj.ToString()}";
        }
        if ((AddToTraceLog != null) && (AddToTraceLog != String.Empty))
        {
            TraceLog.AppendLine(AddToTraceLog);
        }
    }
    static Trace() { }
    public Trace() { }
    //public override string ToString()
    //{
    //    return $"{GetType()}, {Id?.ToString() ?? "No Id"}, {Parent?.Code?.ToString() ?? "No Parent"}, {Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"} ";
    //}
}