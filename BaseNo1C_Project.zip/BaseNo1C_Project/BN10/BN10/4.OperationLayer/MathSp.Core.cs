﻿namespace BN;
[Serializable]
public partial class MathSp //различные математические функции, как правило, специальные, для приложения
{//созд - 20.11.2022, изм - 20.11.2022
    public static decimal? SetZeroIfNegative(decimal? inNumber) //приравниваем нулю число, если оно меньше нуля, так часто нужно при расчетах зарплаты, налогов и т.д.
    {//созд - 28.11.2022, изм - 01.12.2022
        decimal? outNumber = inNumber;
        if (outNumber < 0)
        {
            outNumber = 0;
        }
        //TraceState(outNumber, "SetZeroIfNegative(...), outNumber ");
        return outNumber;
    }
    public static decimal Prorate(decimal numerator, decimal denominator) //коэффициент - пропорциональная доля, нужен для доли оклада, например, или доли суммы оплаты
    {//созд - 20.11.2022, изм - 20.11.2022
        decimal outProrate = 1; //поскольку коэф-доля обычно используется для умножения на что-то. по умолчанию он должен быть = 1
        
        if (denominator == 0) //если знаменатель = 0, то доля = 1, потому что неясно от чего
        {
            return outProrate;
        }

        if ((numerator > denominator) & (denominator != 0))//если числитель больше знаменателя, то доля = 1, потому что не может он быть больше
        {
            return outProrate;
        }
        
        outProrate = Math.Abs((decimal)(numerator / denominator)); //доля должны быть положительной
        //TraceState(outProrate, "Proportion(...), outProrate ");
        return outProrate; 
    }
    public static string? GetFormatSecondTimeSpan(decimal? tsSecDec)
    {//созд - 2022, изм - 07.08.2022
        string? outFormat = default;
        outFormat = string.Format("{0:0.00}", tsSecDec) + "sec.";
        //TraceState(outFormat, "GetFormatSecondTimeSpan(...), outFormat ");
        return outFormat;
    }
    public static decimal? GetSecondTimeSpan(TimeSpan? ts)
    {//созд - 2022, изм - 07.08.2022
        decimal? outSecond = default;
        outSecond = (decimal?)(ts?.TotalSeconds);    //промежуток в секундах всего
        //TraceState(outSecond, "GetSecondTimeSpan(...), outSecond ");
        return outSecond;
    }
    public static TimeSpan? GetSpanTime(DateTimeOffset? d1, DateTimeOffset? d2)
    {//созд - 2022, изм - 07.08.2022
        //для расчета разницы между например, между Date1 одного экземпляра, и Date1 другого экземпляра  
        //или между любыми переменными типов DateTimeOffset  
        TimeSpan? outSpanTime = default;
        if ((d1 == null) && (d2 != null))  //если d1 не заполнен, то приравниваем его к d2 - для первого события trace
        {
            d1 = d2;
        }
        if ((d1 != null) && (d2 == null))  //если d2 не заполнен, то приравниваем его к d1
        {
            d2 = d1;
        }
        try
        {
            outSpanTime = (TimeSpan?)(d2 - d1);
        }
        catch (Exception ex)
        {
            _ = ex.Message;
            //TraceState(ex.Message, "GetSpanTime(...), ex.Message ");
        }
        finally { }
        //TraceState(outSpanTime, "GetSpanTime(...), outSpanTime ");
        return outSpanTime;
    }
    public static decimal? GetPercent(decimal? Amount1 = 0, //сумма с НДС (бОльшая)
                                      decimal? Amount2 = 0,//сумма без НДС (меньшая)
                                      decimal? Percent1 = 0,//
                                      decimal? Percent2 = 0)//ставка НДС в том числе (меньший процент)
    {//созд - 2022, изм - 28.07.2022   
        decimal? outValue = 0;

        //вытащить сумму НДС из общей суммы (Amount1), зная ставку НДС (Percent2)
        if ((Amount1 != 0) && (Percent2 != 0))
        {
            outValue = (Amount1 * Percent2) / (100 + Percent2);
        }

        //накрутить НДС на сумму без НДС (Amount2), зная ставку НДС (Percent2)
        if ((Amount2 != 0) && (Percent2 != 0))
        {
            outValue = (Amount2 * (Percent2 + 100)) / 100;
        }

        //TraceState(outValue, "Shell.GetPercent(...), outValue ");
        return outValue;
    }
    public MathSp()
    {//созд - 28.11.2022, изм - 28.11.2022
        //public ctor не может содержать ничего, кроме присваивания простых значений
    }
    static MathSp()
    {//созд - 28.11.2022, изм - 28.11.2022
        //static ctor не может содержать ничего, кроме присваивания простых значений
    }
}