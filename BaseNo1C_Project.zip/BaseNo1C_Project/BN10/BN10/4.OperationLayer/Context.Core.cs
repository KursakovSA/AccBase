﻿namespace BN;
[Serializable]
public partial class Context
{//созд - 17.07.2022, изм - 20.07.2022
    public static bool IsDev;
    public static string? StartDirectory;
    public static string? LastSaveDirectory;
    public static string? LastSelectFileDirectory;
    public static void GetDirectory()  //получить стартовую директорию программы
    {//созд - 2022, изм - 30.11.2022
        StartDirectory = Environment.CurrentDirectory;
        LastSaveDirectory = StartDirectory;
        LastSelectFileDirectory = StartDirectory;
    }
    public Context() { }
    static Context() { }
}