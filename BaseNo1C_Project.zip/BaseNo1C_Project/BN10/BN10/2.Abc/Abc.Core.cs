﻿namespace BN;
[Serializable]
public static partial class Abc
{//созд - 2022, изм - 30.11.2022
    public static List<string> ListAbcExpected = new()  //список базовых видов Abc ожидаемый  
    {//созд - 2022, изм - 30.11.2022
        "Basic", "Catalog", "CodePay", "Exchange", "Markup", "Sale", "Switch", "Table",
    };
    public static List<Shell>? Basic = new();  //основной вид Abc, включает в себя все нижележащие
    public static List<Shell>? Catalog = new(); //в том числе, это подвид Abc
    public static List<Shell>? CodePay = new(); //в том числе, это подвид Abc
    public static List<Shell>? Exchange = new(); //в том числе, это подвид Abc
    public static List<Shell>? Markup = new(); //в том числе, это подвид Abc
    public static List<Shell>? Sale = new(); //в том числе, это подвид Abc
    public static List<Shell>? Switch = new(); //в том числе, это подвид Abc
    public static List<Shell>? Table = new(); //в том числе, это подвид Abc

    public static List<Shell>? Example = new();//TODO
    public static List<Shell>? Template = new();//TODO
    public static List<Shell>? Root = new();//TODO
    public static bool GetAbcDb(SqlConnection conn)
    {//созд - 2022, изм - 27.07.2022
        bool TestGetAbcListTableIsPassed = false;
        int countFillTable = 0;
        
        Abc.Basic = GetBasicDb(conn);
        if (Abc.Basic.Count > 0)
        {
            countFillTable++;
        }

        Abc.Catalog = GetBasicAbc(Abc.Basic, templateMore: "Catalog");
        if (Abc.Catalog.Count > 0)
        {
            countFillTable++;
        }

        Abc.CodePay = GetBasicAbc(Abc.Basic, templateMore: "CodePay");
        if (Abc.CodePay.Count > 0)
        {
            countFillTable++;
        }

        Abc.Exchange = GetBasicAbc(Abc.Basic, templateMore: "Exchange");
        if (Abc.Exchange.Count > 0)
        {
            countFillTable++;
        }

        Abc.Markup = GetBasicAbc(Abc.Basic, templateMore: "Markup");
        if (Abc.Markup.Count > 0)
        {
            countFillTable++;
        }

        Abc.Sale = GetBasicAbc(Abc.Basic, templateMore: "Sale");
        if (Abc.Sale.Count > 0)
        {
            countFillTable++;
        }

        Abc.Switch = GetBasicAbc(Abc.Basic, templateMore: "Switch");
        if (Abc.Switch.Count > 0)
        {
            countFillTable++;
        }

        Abc.Table = GetBasicAbc(Abc.Basic, templateMore: "Table");
        if (Abc.Switch.Count > 0)
        {
            countFillTable++;
        }

        if (countFillTable == ListAbcExpected.Count)//заполненных basic таблиц должно быть столько же, сколько и всего таблиц
        {
            TestGetAbcListTableIsPassed = true;
        }

        TraceState(countFillTable.ToString() + "/" + TestGetAbcListTableIsPassed.ToString(), "GetAbcDb(...), countFillTable / TestGetAbcListTableIsPassed");
        return TestGetAbcListTableIsPassed;
    }
    public static List<Shell> GetBasicAbc(List<Shell>? basic, string templateMore = "")
    {//созд - 2022, изм - 07.08.2022
        //получаем Abc из Basic через Linq
        List<Shell>? outList = new();
        templateMore = templateMore.Trim();
        //string? templMore = "'%" + strTable + ".Basic%'";//компонуем строку фильтра More для запроса типа "'%Account.Basic%'"
        IEnumerable<Shell>? subset = from g in basic let more = g.More where more.Contains(templateMore) select g;
        foreach (var s in subset)
        {
            outList.Add(s);
        }

        //TraceState(outList.Count + "/" + templateMore, "GetBasicAbc(...), outList.Count / templateMore");
        return outList;
    }
    public static List<Shell> GetBasicDb(SqlConnection conn, string? table = default, string? templateMore = null)
    {//созд - 2022, изм - 26.07.2022
        //отбор Abc по принципу - это все строки таблицы с More = basic, в 1-м экземпляре, хотя та же строка может быть и други типом Abc, например, switch
        List<Shell>? outBasic = new();
        List<Shell>? tempBasic = new();
        bool TestGetListTableIsPassed = false;
        int countFillTable = 0;
        foreach (var strTable in ListBaseTableExpected)
        {
            string? templMore = "'%" + strTable + ".Basic%'";//компонуем строку фильтра More для запроса типа "'%Account.Basic%'"
            //templMore = "'%" + strTable + ".table%'";//например, для проверки, для Account/Table = 2
            tempBasic = GetTable(conn, strTable, templateMore: templMore);
            foreach (var tmpBasic in tempBasic)
            {
                outBasic.Add(tmpBasic);
            }
            if (tempBasic.Count > 0)
            {
                countFillTable++;
                tempBasic.Clear();
            }
        }
        if (countFillTable == ListBaseTableExpected.Count)//заполненных basic таблиц должно быть столько же, сколько и всего таблиц
        {
            TestGetListTableIsPassed = true;
        }

        TraceState(countFillTable.ToString() + "/" + TestGetListTableIsPassed.ToString(), "GetBasicDb(...), countFillTable / TestGetListTableIsPassed");
        //TraceState(outBasic.Count, "GetBasicDb(...), outBasic");
        return outBasic;
    }
    static Abc()
    {//созд - 2022, изм - 25.07.2022
        //static ctor не может содержать ничего, кроме присваивания простых значений
    }
}