﻿namespace BN;
[Serializable]
public partial class DataAccessLayer
{
    public static SqlConnectionStringBuilder SqlConnStrBuild = new()
    {
        //DataSource = @".\SQLExpress",
        DataSource = @".\SQL2017",
        InitialCatalog = "BaseN1",
        IntegratedSecurity = true,
        ConnectTimeout = 30,
    };
    public static SqlConnection SqlConn = new()
    {
        ConnectionString = SqlConnStrBuild.ConnectionString,
    };
    public static string? BuildQuerySql(string? tableView, string? templateMore)
    {
        string? qrySql = "";
        if (tableView != null)
        {
            qrySql += "SELECT * FROM dbo.";
            qrySql += tableView.ToString();
            if (templateMore != null)
            {
                qrySql += " WHERE ";    ////TODO - сделать чтобы WHERE был только если есть хоть один отбор
                qrySql += "More LIKE ";
                qrySql += templateMore.ToString();
            }
        }

        //TraceState(qrySql, "BuildQuerySql(...), qrySql ");
        return qrySql;
    }
    //public static List<Account> GetAbc(string? tableView)
    //{
    //    List<Account> listAcc = new();
    //    //foreach (var mast in AbcKind)
    //    //{
    //    //string? templateMore = "'%" + mast.Value.ToString() + "%'";
    //    string? templateMore = null;
    //    using (SqlDataReader DataReader = GetDataReader(tableView, templateMore))
    //    {
    //        if (DataReader.HasRows)
    //        {
    //            while (DataReader.Read())
    //            {
    //                Console.WriteLine($"Id: {DataReader["Id"]}, Code: {DataReader["Code"]}, More: {DataReader["More"]}");
    //                //res.Add(new Abc {Id = (int)DataReader["Id"], Code = (string)DataReader["Code"], More = (string)DataReader["More"] });
    //                //listAcc.Add(new Account { Id = (short)DataReader["Id"], Date1 = (DateTimeOffset)DataReader["Date1"], Code = (string)DataReader["Code"], More = (string)DataReader["More"] });
    //                listAcc.Add(new Account { Id = (short)DataReader["Id"], Date1 = (DateTimeOffset)DataReader["Date1"], Code = (string)DataReader["Code"], More = (string)DataReader["More"] });
    //            }
    //        }
    //        DataReader.Close();
    //        CloseConn(SqlConn);
    //    }
    //    TraceState(listAcc.Count, "GetABC(...), listAcc.Count ");
    //    //TraceState(res.Count, "GetABC(...), res.Count ");
    //    return listAcc;
    //}
    public static SortedDictionary<string, object> GetTable(string table,
                                                            string? templateCode = null,
                                                            string? templateDescription = null,
                                                            string? templateMore = null)
    {
        SortedDictionary<string, object> ListTable = new();
        string? qrySql = BuildQuerySql(table, templateMore);
        using (SqlConnection workConn = new SqlConnection(SqlConn.ConnectionString))
        {
            SqlCommand sqlComm = new SqlCommand(qrySql, workConn);
            workConn.Open();
            using (SqlDataReader DataReader = sqlComm.ExecuteReader())
            {
                if (DataReader.HasRows)
                {
                    while (DataReader.Read())
                    {
                        #region AccountList
                        if (table == "AccountList")
                        {
                            ListTable.Add((string)DataReader["Code"], new Account
                            {
                                Id = GetId<short>(DataReader),
                                Parent = GetAccount(DataReader, "Parent"),
                                Slice = GetSlice(DataReader, "Slice"),
                                Date1 = GetDate1(DataReader),
                                Date2 = GetSimpleString(DataReader, "Date2"),
                                Code = GetSimpleString(DataReader, "Code"),
                                Description = GetSimpleString(DataReader, "Description"),
                                Account1 = GetAccount(DataReader, "Account1"),
                                Role = GetRole(DataReader, "Role"),
                                Sign = GetSign(DataReader, "Sign"),
                                More = GetSimpleString(DataReader, "More"),
                            });
                            TraceState(ListTable[(string)DataReader["Code"]], "GetTable(...), ListTable.CurrentItem ");
                        }
                        #endregion
                        #region AssetList
                        if (table == "AssetList")
                        {
                            ListTable.Add((string)DataReader["Code"], new Asset
                            {
                                Id = GetId<int>(DataReader),
                                Parent = GetAsset(DataReader, "Parent"),
                                Face1 = GetFace(DataReader, "Face1"),
                                Face2 = GetFace(DataReader, "Face2"),
                                Face = GetFace(DataReader, "Face"),
                                Date1 = GetDate1(DataReader),
                                Date2 = GetSimpleString(DataReader, "Date2"),
                                Code = GetSimpleString(DataReader, "Code"),
                                Description = GetSimpleString(DataReader, "Description"),
                                Geo = GetGeo(DataReader, "Geo"),
                                Asset1 = GetAsset(DataReader, "Asset1"),
                                Role = GetRole(DataReader, "Role"),
                                Info = GetInfo(DataReader, "Info"),
                                Unit = GetUnit(DataReader, "Unit"),
                                More = GetSimpleString(DataReader, "More"),
                            });
                            TraceState(ListTable[(string)DataReader["Code"]], "GetTable(...), ListTable.CurrentItem ");
                        }
                        #endregion
                        #region DealList
                        if (table == "DealList")
                        {
                            ListTable.Add((string)DataReader["Code"], new Deal
                            {
                                Id = GetId<int>(DataReader),
                                Parent = GetDeal(DataReader, "Parent"),
                                Face1 = GetFace(DataReader, "Face1"),
                                Face2 = GetFace(DataReader, "Face2"),
                                Face = GetFace(DataReader, "Face"),
                                Date1 = GetDate1(DataReader),
                                Date2 = GetSimpleString(DataReader, "Date2"),
                                Code = GetSimpleString(DataReader, "Code"),
                                Description = GetSimpleString(DataReader, "Description"),
                                Geo = GetGeo(DataReader, "Geo"),
                                Role = GetRole(DataReader, "Role"),
                                Info = GetInfo(DataReader, "Info"),
                                More = GetSimpleString(DataReader, "More"),
                            });
                            TraceState(ListTable[(string)DataReader["Code"]], "GetTable(...), ListTable.CurrentItem ");
                        }
                        #endregion
                        #region GeoList
                        if (table == "GeoList")
                        {
                            ListTable.Add((string)DataReader["Code"], new Geo
                            {
                                Id = GetId<short>(DataReader),
                                Parent = GetGeo(DataReader, "Parent"),
                                Date1 = GetDate1(DataReader),
                                Date2 = GetSimpleString(DataReader, "Date2"),
                                Code = GetSimpleString(DataReader, "Code"),
                                Description = GetSimpleString(DataReader, "Description"),
                                Role = GetRole(DataReader, "Role"),
                                Unit = GetUnit(DataReader, "Unit"),
                                More = GetSimpleString(DataReader, "More"),
                            });
                            TraceState(ListTable[(string)DataReader["Code"]], "GetTable(...), ListTable.CurrentItem ");
                        }
                        #endregion
                        #region InfoList
                        if (table == "InfoList")
                        {
                            ListTable.Add((string)DataReader["Code"], new Info
                            {
                                Id = GetId<short>(DataReader),
                                Parent = GetInfo(DataReader, "Parent"),
                                Date1 = GetDate1(DataReader),
                                Date2 = GetSimpleString(DataReader, "Date2"),
                                Code = GetSimpleString(DataReader, "Code"),
                                Description = GetSimpleString(DataReader, "Description"),
                                More = GetSimpleString(DataReader, "More"),
                            });
                            TraceState(ListTable[(string)DataReader["Code"]], "GetTable(...), ListTable.CurrentItem ");
                        }
                        #endregion
                        #region ItemList
                        if (table == "ItemList")
                        {
                            ListTable.Add((string)DataReader["Code"], new Item
                            {
                                Id = GetId<short>(DataReader),
                                Parent = GetItem(DataReader, "Parent"),
                                Date1 = GetDate1(DataReader),
                                Date2 = GetSimpleString(DataReader, "Date2"),
                                Code = GetSimpleString(DataReader, "Code"),
                                Description = GetSimpleString(DataReader, "Description"),
                                More = GetSimpleString(DataReader, "More"),
                            });
                            TraceState(ListTable[(string)DataReader["Code"]], "GetTable(...), ListTable.CurrentItem ");
                        }
                        #endregion
                        #region FaceList
                        if (table == "FaceList")
                        {
                            ListTable.Add((string)DataReader["Code"], new Face
                            {
                                Id = GetId<int>(DataReader),
                                Parent = GetFace(DataReader, "Parent"),
                                Face1 = GetFace(DataReader, "Face1"),
                                Face2 = GetFace(DataReader, "Face2"),
                                Date1 = GetDate1(DataReader),
                                Date2 = GetSimpleString(DataReader, "Date2"),
                                Code = GetSimpleString(DataReader, "Code"),
                                Description = GetSimpleString(DataReader, "Description"),
                                Geo = GetGeo(DataReader, "Geo"),
                                Role = GetRole(DataReader, "Role"),
                                Info = GetInfo(DataReader, "Info"),
                                More = GetSimpleString(DataReader, "More"),
                            });
                            TraceState(ListTable[(string)DataReader["Code"]], "GetTable(...), ListTable.CurrentItem ");
                        }
                        #endregion
                        #region MarkList
                        if (table == "MarkList")
                        {
                            ListTable.Add((string)DataReader["Code"], new Mark
                            {
                                Id = GetId<byte>(DataReader),
                                Parent = GetMark(DataReader, "Parent"),
                                Date1 = GetDate1(DataReader),
                                Date2 = GetSimpleString(DataReader, "Date2"),
                                Code = GetSimpleString(DataReader, "Code"),
                                Description = GetSimpleString(DataReader, "Description"),
                                More = GetSimpleString(DataReader, "More"),
                            });
                            TraceState(ListTable[(string)DataReader["Code"]], "GetTable(...), ListTable.CurrentItem ");
                        }
                        #endregion
                        #region SliceList
                        if (table == "SliceList")
                        {
                            ListTable.Add((string)DataReader["Code"], new Slice
                            {
                                Id = GetId<byte>(DataReader),
                                Parent = GetSlice(DataReader, "Parent"),
                                Date1 = GetDate1(DataReader),
                                Date2 = GetSimpleString(DataReader, "Date2"),
                                Code = GetSimpleString(DataReader, "Code"),
                                Description = GetSimpleString(DataReader, "Description"),
                                More = GetSimpleString(DataReader, "More"),
                            });
                            TraceState(ListTable[(string)DataReader["Code"]], "GetTable(...), ListTable.CurrentItem ");
                        }
                        #endregion
                        #region SignList
                        if (table == "SignList")
                        {
                            ListTable.Add((string)DataReader["Code"], new Sign
                            {
                                Id = GetId<byte>(DataReader),
                                Parent = GetSign(DataReader, "Parent"),
                                Date1 = GetDate1(DataReader),
                                Date2 = GetSimpleString(DataReader, "Date2"),
                                Code = GetSimpleString(DataReader, "Code"),
                                Description = GetSimpleString(DataReader, "Description"),
                                Role = GetRole(DataReader, "Role"),
                                Info = GetInfo(DataReader, "Info"),
                                More = GetSimpleString(DataReader, "More"),
                            });
                            TraceState(ListTable[(string)DataReader["Code"]], "GetTable(...), ListTable.CurrentItem ");
                        }
                        #endregion
                        #region MeterList
                        if (table == "MeterList")
                        {
                            ListTable.Add((string)DataReader["Code"], new Meter
                            {
                                Id = GetId<byte>(DataReader),
                                Parent = GetMeter(DataReader, "Parent"),
                                Date1 = GetDate1(DataReader),
                                Date2 = GetSimpleString(DataReader, "Date2"),
                                Code = GetSimpleString(DataReader, "Code"),
                                Description = GetSimpleString(DataReader, "Description"),
                                Unit = GetUnit(DataReader, "Unit"),
                                More = GetSimpleString(DataReader, "More"),
                            });
                            TraceState(ListTable[(string)DataReader["Code"]], "GetTable(...), ListTable.CurrentItem ");
                        }
                        #endregion
                        #region RoleList
                        if (table == "RoleList")
                        {
                            ListTable.Add((string)DataReader["Code"], new Role
                            {
                                Id = GetId<byte>(DataReader),
                                Parent = GetRole(DataReader, "Parent"),
                                Date1 = GetDate1(DataReader),
                                Date2 = GetSimpleString(DataReader, "Date2"),
                                Code = GetSimpleString(DataReader, "Code"),
                                Description = GetSimpleString(DataReader, "Description"),
                                More = GetSimpleString(DataReader, "More"),
                            });
                            TraceState(ListTable[(string)DataReader["Code"]], "GetTable(...), ListTable.CurrentItem ");
                        }
                        #endregion
                        #region PriceList
                        if (table == "PriceList")
                        {
                            ListTable.Add((string)DataReader["Code"], new Price
                            {
                                Id = GetId<short>(DataReader),
                                Parent = GetPrice(DataReader, "Parent"),
                                Face1 = GetFace(DataReader, "Face1"),
                                Face2 = GetFace(DataReader, "Face2"),
                                Face = GetFace(DataReader, "Face"),
                                Date1 = GetDate1(DataReader),
                                Date2 = GetSimpleString(DataReader, "Date2"),
                                Code = GetSimpleString(DataReader, "Code"),
                                Description = GetSimpleString(DataReader, "Description"),
                                Role = GetRole(DataReader, "Role"),
                                Info = GetInfo(DataReader, "Info"),
                                Unit = GetUnit(DataReader, "Unit"),
                                More = GetSimpleString(DataReader, "More"),
                            });
                            TraceState(ListTable[(string)DataReader["Code"]], "GetTable(...), ListTable.CurrentItem ");
                        }
                        #endregion
                        #region UnitList
                        if (table == "UnitList")
                        {
                            ListTable.Add((string)DataReader["Code"], new Unit
                            {
                                Id = GetId<short>(DataReader),
                                Parent = GetUnit(DataReader, "Parent"),
                                Date1 = GetDate1(DataReader),
                                Date2 = GetSimpleString(DataReader, "Date2"),
                                Code = GetSimpleString(DataReader, "Code"),
                                Description = GetSimpleString(DataReader, "Description"),
                                Role = GetRole(DataReader, "Role"),
                                Unit1 = GetUnit(DataReader, "Unit"),
                                More = GetSimpleString(DataReader, "More"),
                            });
                            TraceState(ListTable[(string)DataReader["Code"]], "GetTable(...), ListTable.CurrentItem ");
                        } 
                        #endregion
                        if (table == "TaxList")
                        {
                            ListTable.Add((string)DataReader["Code"], new Tax
                            {
                                Id = GetId<short>(DataReader),
                                Parent = GetTax(DataReader, "Parent"),
                                Face1 = GetFace(DataReader, "Face1"),
                                Face2 = GetFace(DataReader, "Face2"),
                                Date1 = GetDate1(DataReader),
                                Date2 = GetSimpleString(DataReader, "Date2"),
                                Code = GetSimpleString(DataReader, "Code"),
                                Description = GetSimpleString(DataReader, "Description"),
                                Geo = GetGeo(DataReader, "Geo"),
                                Role = GetRole(DataReader, "Role"),
                                Info = GetInfo(DataReader, "Info"),
                                More = GetSimpleString(DataReader, "More"),
                            });
                            TraceState(ListTable[(string)DataReader["Code"]], "GetTable(...), ListTable.CurrentItem ");
                        }
                    }
                }
                DataReader.Close();
            }
            workConn.Close();
        }

        ////IEnumerable<Account> subset = from g in ListTable where g.More.Contains("basic") orderby g select g;
        //IEnumerable<Account> subset = from g in ListTable select g;
        //var subset = from g in ListTable select g;
        
        //foreach (var s in ListTable)
        //{
        //    Console.WriteLine($"ListTable.Key:{s.Key}, ListTable.Value:{s.Value}");
        //    Console.ReadLine();
        //}

        TraceState(ListTable.Count, "GetTable(...), ListTable.Count ");
        return ListTable;
    }
    #region GetObjMain
    public static T? GetId<T>(SqlDataReader dr)
    {
        T? outObj = default;
        if (dr["Id"].GetType().ToString() != "System.DBNull")
        {
            outObj = (T)dr["Id"];
        }

        //TraceState(outObj, "GetId(...), outObj ");
        return outObj;
    }
    public static Asset? GetAsset(SqlDataReader dr, string? NameId = default)
    {
        Asset? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Asset { Id = (int)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetAsset(...), outObj ");
        return outObj;
    }
    public static Face? GetFace(SqlDataReader dr, string? NameId = default)
    {
        Face? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Face { Id = (int)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetFace(...), outObj ");
        return outObj;
    }
    public static Deal? GetDeal(SqlDataReader dr, string? NameId = default)
    {
        Deal? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Deal { Id = (int)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetDeal(...), outObj ");
        return outObj;
    }
    public static Geo? GetGeo(SqlDataReader dr, string? NameId = default)
    {
        Geo? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Geo { Id = (short)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetGeo(...), outObj ");
        return outObj;
    }
    public static Tax? GetTax(SqlDataReader dr, string? NameId = default)
    {
        Tax? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Tax { Id = (short)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetTax(...), outObj ");
        return outObj;
    }
    public static Price? GetPrice(SqlDataReader dr, string? NameId = default)
    {
        Price? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Price { Id = (short)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetPrice(...), outObj ");
        return outObj;
    }
    public static Meter? GetMeter(SqlDataReader dr, string? NameId = default)
    {
        Meter? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Meter { Id = (byte)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetMeter(...), outObj ");
        return outObj;
    }
    public static Role? GetRole(SqlDataReader dr, string? NameId = default)
    {
        Role? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Role { Id = (short)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetRole(...), outObj ");
        return outObj;
    }
    public static Info? GetInfo(SqlDataReader dr, string? NameId = default)
    {
        Info? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Info { Id = (short)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetInfo(...), outObj ");
        return outObj;
    }
    public static Item? GetItem(SqlDataReader dr, string? NameId = default)
    {
        Item? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Item { Id = (short)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetItem(...), outObj ");
        return outObj;
    }
    public static Slice? GetSlice(SqlDataReader dr, string? NameId = default)
    {
        Slice? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Slice { Id = (byte)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetSlice(...), outObj ");
        return outObj;
    }
    public static Sign? GetSign(SqlDataReader dr, string? NameId = default)
    {
        Sign? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Sign { Id = (byte)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetSign(...), outObj ");
        return outObj;
    }
    public static Mark? GetMark(SqlDataReader dr, string? NameId = default)
    {
        Mark? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Mark { Id = (byte)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetMark(...), outObj ");
        return outObj;
    }
    public static Account? GetAccount(SqlDataReader dr, string? NameId = default)
    {
        Account? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Account { Id = (short)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetAccount(...), outObj ");
        return outObj;
    }
    public static Unit? GetUnit(SqlDataReader dr, string? NameId = default)
    {
        Unit? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Unit { Id = (short)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetUnit(...), outObj ");
        return outObj;
    }
    public static DateTimeOffset? GetDate1(SqlDataReader dr)
    {
        DateTimeOffset? outObj = default;
        if (dr["Date1"].GetType().ToString() != "System.DBNull")
        {
            outObj = (DateTimeOffset)dr["Date1"];
        }

        //TraceState(outObj, "GetData1(...), outObj ");
        return outObj;
    }
    public static string? GetSimpleString(SqlDataReader dr, string? NameStr = default)
    {
        string? outObj = default;
        if (dr[NameStr].GetType().ToString() != "System.DBNull")
        {
            outObj = (string)dr[NameStr];
        }

        //TraceState(outObj, "GetSimpleString(...), outObj ");
        return outObj;
    }
    #endregion
    #region GetObjAdd
    public static string GetTableNameQuery(string tableView)
    {
        //получаем из имени таблицы или view в запросе типа "AccountList" "чистое" имя таблицы типа "Account"
        string TableNameQuery = tableView.Trim();
        if (tableView != null)
        {
            TableNameQuery = TableNameQuery.Replace("List", "");
        }

        //TraceState(tableView, "GetTableNameQuery(...), tableView ");
        //TraceState(TableNameQuery, "GetTableNameQuery(...), TableNameQuery ");
        return TableNameQuery;
    }
    public static string? GetNameCode(string? NameId = default)
    {
        //получаем из имени Id в запросе типа "Account" имя поля кода типа "AccountCode"
        string? NameCode = default;
        if (NameId != null)
        {
            NameCode = NameId + "Code";
        }

        //TraceState(NameId, "GetNameCode(...), NameId ");
        //TraceState(NameCode, "GetNameCode(...), NameCode");
        return NameCode;
    } 
    #endregion
}
