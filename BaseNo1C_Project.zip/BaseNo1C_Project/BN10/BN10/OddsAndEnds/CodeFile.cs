﻿//public static List<string> AbcKind = new()
//    {
//        "Basic","Catalog","CodePay","Switch","Table","Template",
//    };

//сериализация JSON
//..https://metanit.com/sharp/tutorial/6.5.php

//public int? Id { get; set; }
//public Shell? Parent { get; set; }
//private DateTimeOffset? date1;
//public DateTimeOffset? Date1
//{
//    get => date1;
//    set => date1 = FixDate(value);
//}
//private string? date2;
//public string? Date2
//{
//    get => date2;
//    set => date2 = FixTrim(value);
//}
//private string? code;
//public string? Code
//{
//    get => code;
//    set => code = FixTrim(value);
//}
//private string? description;
//public string? Description
//{
//    get => description;
//    set => description = FixTrim(value);
//}
//private string? more;
//public string? More
//{
//    get => more;
//    set => more = FixTrim(value);
//}

//static Account()
//{
//    //CurrentTable = Basic[key: "AccTable2019"];  ////TODO - надо как-то 
//}

//public static Account? FixParent(Account? inParent = default) //комм - 07.07.2022
//{
//    //Account? outParent = inParent ?? new Account { };
//    Account? outParent = inParent ?? Account.Root;

//    //TraceState(outParent, "Account.FixParent(...), FixParent.outParent ");
//    return outParent;
//}

//public StringBuilder SwiftOPV(Workbook? WorkbookSalary = default)
//{//созд - 2021
//    StringBuilder TextSwift = new();
//    Exchange SwiftOPV = Basic[key: "Role.Exchange.SwiftOPV"];
//    SwiftOPV.TargetFile = @"Swift_OPV.txt";
//    SwiftOPV.TargetExchange = GetTargetExchangeValue(TargetPath, TargetFile);
//    TODO - выгрузка свифт файла для ОПВ

//    TraceState(TextSwift, "SwiftOPV(...), TextSwift ");
//    return TextSwift;
//}

//public static Abc GetAbc(string? table)  //TODO - получение единичного Abc  ???   
//{//созд - 2022, изм - 17.07.2022
//    Abc outAbc = new();
//    //string? templateMore = "'%" + mast.Value.ToString() + "%'";
//    string? templateMore = null;
//    using (SqlDataReader DataReader = GetDataReader(tableView, templateMore))
//        TraceState(outAbc.ToString(), "GetABC(...), outAbc");
//    return outAbc;
//}

////IEnumerable<Account> subset = from g in ListTable where g.More.Contains("basic") orderby g select g;
//IEnumerable<Account> subset = from g in ListTable select g;
//var subset = from g in ListTable select g;

//foreach (var s in ListTable)
//{
//    Console.WriteLine($"ListTable.Key:{s.Key}, ListTable.Value:{s.Value}");
//    Console.ReadLine();
//}

//static Price()
//{
//    Markup.Add("Price.MarkupBasic", Price.Basic[key: "Price.MarkupBasic"]);
//    Sale.Add("Price.SaleBasic", Price.Basic[key: "Price.SaleBasic"]);
//}

//public decimal? GetTurnover(DateTime inDate1,
//                            string? inDate2) //TODO
//{
//    decimal? Turnover = default;
//    Date1 = FixDate1(Date1);

//    TraceState(Turnover, "HeadClass.GetTurnover(...), Turnover ");
//    return Turnover;
//}
//public decimal? GetSaldo(DateTime inDate1,
//                         string? inDate2)  //TODO
//{
//    decimal? Saldo = default;
//    Date1 = FixDate1(Date1);

//    TraceState(Saldo, "Shell.GetSaldo(...), Saldo ");
//    return Saldo;
//}
//public string? FixDescription(string? inDescr = "")
//{
//    string? FixDescr = inDescr?.Trim() ?? "";

//    //TraceState(FixDescr, "Shell.FixDescription(...), FixDescr ");
//    return FixDescr;
//}
//public string? FixCode(string? inCode = "")
//{
//    string? FixCode = inCode?.Trim() ?? "";

//    //TraceState(FixCode, "Shell.FixCode(...), FixCode ");
//    return FixCode;
//}

//public static void FromClipboardToStringForBasic()
//{
//    //запрашиваем блок строк с переносами, вводимый из буфера обмена
//    //делаем из этой строки массив с кавычками по 5 элементов  
//    //это нужно для быстрого импорта строк в ctor static basic-поля из XLS-файлов
//    var DataObject = Clipboard.GetDataObject();
//    if (DataObject.ToString().Length == 0) return;
//    string text = DataObject.GetData("UnicodeText", true).ToString();
//    string[] Arr = text.Split(new[] { '\n' }, System.StringSplitOptions.RemoveEmptyEntries);
//    string StrToClipboard = "";
//    int Count = 0;
//    foreach (string tmpArr in Arr)
//    {
//        Count++;
//        StrToClipboard += "\"" + tmpArr.Trim() + "\"" + ",";
//        if (Count % 5 == 0)
//        {
//            StrToClipboard += Environment.NewLine;
//        }
//    }
//    if (Count != 0)
//    {
//        Clipboard.SetText(StrToClipboard);
//    }
//}

//public static void Test()
//{//созд - 13.07.2022, изм - 17.07.2022
//    StartTestTime = DateTimeOffset.Now;
//    GetTable(MainConnCurr, "Account");
//    GetTable(MainConnCurr, "Account", templateDescription: "'%налог%'", templateMore: "'%Account.Catalog%'");
//    GetTable(MainConnCurr, "Account", templateMore: "'%Account.Basic%'");

//    GetTableDb(conn: MainConnCurr);
//    GetAbcTable(conn: MainConnCurr, "Account");
//    TestAccount();

//    FinishTestTime = DateTimeOffset.Now;
//    ListDataSource = GetListDataSource();
//    ListConnCurr = GetListConnCurr();
//    TraceState(MainConnCurr.DataSource.ToString(), "Program(...), MainConnCurr.ToString()");

//    TraceState(Exchange.Basic["Role.Exchange.SwiftOPV"], "Exchange.Basic[Role.Exchange.SwiftOPV]");
//    Exchange? exc = new();
//    TraceState(exc, "Exchange.exc");
//    StringBuilder sb = new();
//    sb = exc.SwiftOPV(null);
//}

//public static Dictionary<string, string>? ListPartTab = new()
//{//созд - 2021
//    ["SelectBase"] = "",
//    ["Dialog"] = "",
//    ["Tree"] = "",
//    ["Main"] = "",
//    ["SelectSwitchMark"] = "",
//    ["SelectSwitchSlice"] = "",
//    ["Validation"] = "",
//    ["Filter"] = "",
//};

//public static Dictionary<string, string>? ListAppTab = new()
//{//созд - 2021
//    ["List"] = "List",
//    //["One"] = "One",  //думаю, нет нужды делать отдельный смысл One - List тоже может отображать одну строку, это и будет One   
//    ["Detail"] = "Detail",
//    ["Console"] = "Console",
//};