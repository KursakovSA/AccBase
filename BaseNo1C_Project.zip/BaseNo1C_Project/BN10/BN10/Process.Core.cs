﻿namespace BN;
[Serializable]
public partial class Process : Shell
{
    private short? id;
    public short? Id
    {
        get => id;
        set => id = FixId(value);
    }
    public Process? Parent { get; set; }
    private DateTimeOffset? date1;

    public DateTimeOffset? Date1
    {
        get => date1;
        set => date1 = FixDate1(value);
    }
    public string? Date2 { get; set; }
    public string? Code { get; set; }
    public string? Description { get; set; }
    public string? More { get; set; }
    public Face? Face1 { get; set; }
    public Face? Face2 { get; set; }
    public Slice? Slice { get; set; }
    public Sign? Sign { get; set; }
    public Account? Account { get; set; }
    public Workbook? Workbook1 { get; set; }
    public Workbook? Workbook2 { get; set; }
    public Process? Process1 { get; set; }
    public Asset? Asset { get; set; }
    public Deal? Deal { get; set; }
    public Item? Item { get; set; }
    public Tax? Tax { get; set; }
    public Price? Price { get; set; }
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    public Meter? Meter { get; set; }
    public string? MeterValue { get; set; }
    public Unit? Unit { get; set; }
    public static SortedDictionary<string, Process>? Abc { get; set; }  //ключ типа = "Account.Basic.Ac.1010"
    public Process() { }
    public Process(short? id = default,
                 Process? parent = default,
                 Face? face1 = default,
                 Face? face2 = default,
                 DateTimeOffset? date1 = default,
                 string? date2 = default,
                 string? code = default,
                 string? description = default,
                 Slice? slice = default,
                 Sign? sign = default,
                 Account? account = default,
                 Workbook? workbook1 = default,
                 Workbook? workbook2 = default,
                 Process? process1 = default,
                 Asset? asset = default,
                 Deal? deal = default,
                 Item? item = default,
                 Tax? tax = default,
                 Price? price = default,
                 Role? role = default,
                 Info? info = default,
                 Meter? meter = default,
                 string? metervalue = default,
                 Unit? unit = default,
                 string? more = default)
    {
        Id = id;
        Parent = parent;
        Face1 = face1;
        Face2 = face2;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        Slice = slice;
        Sign = sign;
        Account = account;
        Workbook1 = workbook1;
        Workbook2 = workbook2;
        Process1 = process1;
        Asset = asset;
        Deal = deal;
        Item = item;
        Tax = tax;
        Price = price;
        Role = role;
        Info = info;
        Meter = meter;
        MeterValue = metervalue;
        Unit = unit;
        More = more;
    }
    static Process() { }
    public short? FixId(short? inId = default)
    {
        short? FixId = inId;
        if (FixId < 0)
        {
            FixId = 0;
        }

        //TraceState(FixId, "Process.FixId(...), FixId ");
        return FixId;
    }
    public static DateTimeOffset? FixDate1(DateTimeOffset? inDate1 = default)
    {
        DateTimeOffset? FixDate1 = inDate1 ?? (DateTimeOffset)DateTime.Today;
        if (inDate1 < StartDate)
        {
            FixDate1 = StartDate;
        }
        if (inDate1 > EndDate)
        {
            FixDate1 = EndDate;
        }

        //TraceState(FixDate1, "Process.FixDate1(...), FixDate1 ");
        return FixDate1;
    }
    public override string ToString()
    {
        return $"{GetType()}, {Id.ToString() ?? "No Id"}, {Parent?.ToString() ?? "No Parent"}, {Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"} ";
    }
}
