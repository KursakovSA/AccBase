﻿global using System;
global using System.Collections;
global using System.Collections.Generic;
global using System.Text;
global using static BN.Util;
global using System.Data;
global using System.Data.SqlClient;
global using System.Data.Common;
global using static BN.DataAccessLayer;
namespace BN;
class Program
{
    static void Main(string[] args)
    {
        OnStartApp();
        try
        {
            //TraceState(Process.Basic["PettyCash.4 (ReturnCash)"], "Main, Process.Basic[PettyCash.4 (ReturnCash)] : ");
            //TraceState(Asset.Basic["FNO100.FixedAsset.Group1"], "Main, Catalog.Basic[FNO100.FixedAsset.Group1] : ");

            StartTestTime = DateTimeOffset.Now;
            SortedDictionary<string, object> AccList = new();
            //AccList = GetTable("AccountList");
            //AccList = GetTable("AssetList");
            AccList = GetTable("DealList");
            FinishTestTime = DateTimeOffset.Now;

            //AccList = GetTable("AccountList", @"'%Catalog%'");
            //TraceState(Account.Abc["Item.Advance"], "Main, Item.Basic[Item.Advance] : ");

            //List<Abc> AbcModel = GetAbc("AccountList");
            //TraceState(AbcModel.Count, "Program(...), AbcModel ");

            //HeadClass.GetPrice();

            //TraceState(Exchange.Basic["Role.Exchange.SwiftOPV"], "Exchange.Basic[Role.Exchange.SwiftOPV]");
            //Exchange? exc = new();
            //TraceState(exc, "Exchange.exc");
            //StringBuilder sb = new();
            //sb = exc.SwiftOPV(null);
        }
        catch (Exception ex)
        {
            TraceState(ex.Message, "Program(...), ex.Message ");
        }
        finally { }

        OnExitApp();
    }
    public static void OnStartApp()
    {
        IsDev = true;    ////закомментировать, если это не так  
        TraceState(IsDev, "Main, OnStartApp(), IsDev ");
    }
    public static void OnExitApp()
    {
        if (IsDev)
        {
            AddTraceTime();
            Console.WriteLine(TraceLog);
            Console.ReadLine();
        }
        TraceState(IsDev, "Main, OnExitApp(), IsDev ");
    }
}

