﻿global using System;
global using System.Collections;
global using System.Collections.Generic;
global using System.Text;
global using System.Data;
global using System.Data.Sql;
global using System.Data.SqlClient;
global using System.Data.Common;
global using static BN.DataAccessLayer;
global using static BN.Conn;
global using static BN.Qry;
global using static BN.Shell;
global using static BN.Trace;
global using static BN.Abc;
global using static BN.Context;
global using static BN.Account;
global using static BN.Asset;
global using static BN.Deal;
global using static BN.Example;
global using static BN.Face;
global using static BN.Geo;
global using static BN.Info;
global using static BN.Item;
global using static BN.Mark;
global using static BN.Meter;
global using static BN.Price;
global using static BN.Process;
global using static BN.Role;
global using static BN.Sign;
global using static BN.Slice;
global using static BN.Tax;
global using static BN.Unit;
global using static BN.Workbook;
global using static BN.MathSp;
namespace BN;
class Program
{//созд - 2021, изм - 08.08.2022
    static void Main(string[] args)
    {//созд - 2021, изм - 08.08.2022
        try
        {
            OnStartApp();
            Test();
        }
        catch (Exception ex)
        {
            _ = ex.Message;
            TraceState(ex.Message, "Program(...), ex.Message ");
        }
        finally 
        {
            OnExitApp();
        }
    }
    public static void Test()
    {//созд - 13.07.2022, изм - 07.08.2022
        //TestTable();
        //TestModel();
    }
    public static void TestTable()
    {//созд - 2022, изм - 23.07.2022
        GetTableDb(conn: MainConnCurr);
    }
    public static void TestModel()
    {//созд - 2022, изм - 20.07.2022
        TestAccount();
        TestAsset();
        TestDeal();
        TestFace();
        TestGeo();
        TestInfo();
        TestItem();
        TestMark();
        TestMeter();
        TestPrice();
        TestProcess();
        TestRole();
        TestSign();
        TestSlice();
        TestTax();
        TestUnit();
        TestWorkbook();
    }
    public static void OnStartApp()
    {//созд - 2022, изм - 07.08.2022
        try
        {
            IsDev = true;    //закомментировать, если это не так  
            TraceState(IsDev, "Main, OnStartApp(), IsDev ");

            GetDirectory();
            GetMainConn();
            GetAbcDb(conn: MainConnCurr);
        }
        catch (Exception ex)
        {
            _ = ex.Message;
            TraceState(ex.Message, "OnStartApp(...), ex.Message ");
        }
        finally { }
    }
    public static void OnExitApp()
    {//созд - 2022, изм - 08.08.2022 
        try
        {
            if (IsDev)
            {
                TraceState(IsDev, "Main, OnExitApp(), IsDev ");
                //AddTraceTime();
                WriteTraceList(TraceList);
                Console.WriteLine(TraceLog);
                Console.ReadLine();
            }
        }
        catch (Exception ex)
        {
            _ = ex.Message;
            TraceState(ex.Message, "OnExitApp(...), ex.Message ");
        }
        finally { }
    }
}

