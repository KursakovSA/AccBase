﻿global using System;
global using System.Collections;
global using System.Collections.Generic;
global using System.Text;
global using static BN.Util;
global using System.Data;
global using System.Data.Sql;
global using System.Data.SqlClient;
global using System.Data.Common;
global using static BN.DataAccessLayer;
global using static BN.Conn;
global using static BN.Qry;
global using static BN.Shell;
global using static BN.Trace;
namespace BN;
class Program
{
    static void Main(string[] args)
    {
        StartTestTime = DateTimeOffset.Now;
        OnStartApp();
        try
        {
            List<object> AccList = new();
            //AccList = GetTable(MainConnCurr,"Account");
            AccList = GetTable(MainConnCurr,"Account", templateMore : "'%Account.Table%'");

            //MainConnDefault = GetConn(DataSource : @".\SQLExpress", InitialCatalog : "BaseN1");
            //MainConnDev = GetConn(DataSource: @".\SQL2017", InitialCatalog: "BaseN0");
            //MainConnCurr = GetMainConnCurr();
            //ListDataSource = GetListDataSource();
            //ListConnCurr = GetListConnCurr();
            //TraceState(MainConnCurr.DataSource.ToString(), "Program(...), MainConnCurr.ToString()");

            //TraceState(Account.Abc["Item.Advance"], "Main, Item.Basic[Item.Advance] : ");

            //TraceState(Exchange.Basic["Role.Exchange.SwiftOPV"], "Exchange.Basic[Role.Exchange.SwiftOPV]");
            //Exchange? exc = new();
            //TraceState(exc, "Exchange.exc");
            //StringBuilder sb = new();
            //sb = exc.SwiftOPV(null);
        }
        catch (Exception ex)
        {
            TraceState(ex.Message, "Program(...), ex.Message ");
        }
        finally { }
        OnExitApp();
        FinishTestTime = DateTimeOffset.Now;
    }
    public static void OnStartApp()
    {
        try
        {
            IsDev = true;    ////закомментировать, если это не так  
            TraceState(IsDev, "Main, OnStartApp(), IsDev ");
            StartDirectory = Environment.CurrentDirectory;
            LastSaveDirectory = StartDirectory;
            LastSelectFileDirectory = StartDirectory;

            MainConnDefault = GetConn(DataSource: @".\SQLExpress", InitialCatalog: "BaseN1");
            MainConnDev = GetConn(DataSource: @".\SQL2017", InitialCatalog: "BaseN0");
            MainConnCurr = GetMainConnCurr();
        }
        catch (Exception ex)
        {
            TraceState(ex.Message, "OnStartApp(...), ex.Message ");
        }
        finally { }
    }
    public static void OnExitApp()
    {
        try
        {
            if (IsDev)
            {
                AddTraceTime();
                Console.WriteLine(TraceLog);
                Console.ReadLine();
            }
        }
        catch (Exception ex)
        {
            TraceState(ex.Message, "OnExitApp(...), ex.Message ");
        }
        finally { }
    }
}

