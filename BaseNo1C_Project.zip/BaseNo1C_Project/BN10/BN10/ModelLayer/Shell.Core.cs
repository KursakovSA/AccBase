﻿namespace BN;
[Serializable]
public partial class Shell
{
    public string? FullDescription;
    public string? FullName;
    public string? ShortDescription;
    public string? ShortName;
    public static readonly DateTime StartDate = new DateTime(2000, 01, 01);  //1 янв 2000 - начало возм действий в программе, стартовая дата, не раньше   
    public static readonly DateTime EndDate = new DateTime(2060, 12, 31);  //31 дек 2060 - конец возм действий в программе, финишная дата, не позже
    public static SortedDictionary<string, string>? State = new(); //TODO
    public static TimeSpan GetSpanTime(DateTimeOffset d1, DateTimeOffset d2)
    {
        //для расчета разницы между например, между Date1 одного экземпляра, и Date1 другого экземпляра  
        //или между любыми переменными типов DateTimeOffset  
        TimeSpan outSpanTime = default;
        try
        {
            outSpanTime = (TimeSpan)(d2 - d1);
        }
        catch (Exception ex)
        {
            TraceState(ex.Message, "GetSpanTime(...), ex.Message ");
        }
        finally { }
        //TraceState(outSpanTime, "GetSpanTime(...), outSpanTime ");
        return outSpanTime;
    }
    public static decimal? GetPrice(Asset? inAsset = default,
                                    Deal? inDeal = default,
                                    DateTime? inDate1 = default,
                                    string? inDate2 = default)  //TODO
    {
        decimal? Price = default;
        
        TraceState(Price, "Shell.GetPrice(...), Price ");
        return Price;
    }
    public static decimal? GetPercent(decimal? inAmount,
                               decimal? inPercent1,
                               decimal? inPercent2)  //TODO
    {
        //найти процент inPercent1 (например, НДС 12%) от суммы inAmount, которая составляет inPercent2 (например, 112%, или 100%)
        decimal? Amount = default;
        if (inPercent1 != 0)
        {
            Amount = (inAmount / inPercent2) * inPercent1;
        }
        
        TraceState(Amount, "Shell.GetPercent(...), Amount ");
        return Amount;
    }
    //public decimal? GetTurnover(DateTime inDate1,
    //                            string? inDate2) //TODO
    //{
    //    decimal? Turnover = default;
    //    Date1 = FixDate1(Date1);

    //    TraceState(Turnover, "HeadClass.GetTurnover(...), Turnover ");
    //    return Turnover;
    //}
    //public decimal? GetSaldo(DateTime inDate1,
    //                         string? inDate2)  //TODO
    //{
    //    decimal? Saldo = default;
    //    Date1 = FixDate1(Date1);

    //    TraceState(Saldo, "Shell.GetSaldo(...), Saldo ");
    //    return Saldo;
    //}
    public string? FixDescription(string? inDescr = "")
    {
        string? FixDescr = inDescr?.Trim() ?? "";
        
        TraceState(FixDescr, "Shell.FixDescription(...), FixDescr ");
        return FixDescr;
    }
    static Shell() {}
    public Shell(){}
}
