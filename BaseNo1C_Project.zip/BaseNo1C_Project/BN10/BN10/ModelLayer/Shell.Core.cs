﻿namespace BN;
[Serializable]
public partial class Shell
{//созд - 2021, изм - 20.07.2022
    public int? Id { get; set; }
    public Shell? Parent { get; set; }
    private DateTimeOffset? date1;
    public DateTimeOffset? Date1
    {
        get => date1;
        set => date1 = FixDate(value);
    }
    private string? date2;
    public string? Date2
    {
        get => date2;
        set => date2 = FixTrim(value);
    }
    private string? code;
    public string? Code
    {
        get => code;
        set => code = FixTrim(value);
    }
    private string? description;
    public string? Description
    {
        get => description;
        set => description = FixTrim(value);
    }
    private string? more;
    public string? More
    {
        get => more;
        set => more = FixTrim(value);
    }
    public string? FullDescription;
    public string? FullName;
    public string? ShortDescription;
    public string? ShortName;
    public static List<Abc>? Abc { get; set; }
    public static Shell? Root;  //TODO - корневой элемент, не имеющий родителя Parent, потом заполнить ???
    public static readonly DateTime StartDate = new DateTime(2000, 01, 01);  //1 янв 2000 - начало возм действий в программе, стартовая дата, не раньше   
    public static readonly DateTime EndDate = new DateTime(2080, 12, 31);  //31 дек 2060 - конец возм действий в программе, финишная дата, не позже
    public static SortedDictionary<string, string>? State = new(); //TODO
    public static TimeSpan GetSpanTime(DateTimeOffset d1, DateTimeOffset d2)
    {
        //для расчета разницы между например, между Date1 одного экземпляра, и Date1 другого экземпляра  
        //или между любыми переменными типов DateTimeOffset  
        TimeSpan outSpanTime = default;
        try
        {
            outSpanTime = (TimeSpan)(d2 - d1);
        }
        catch (Exception ex)
        {
            TraceState(ex.Message, "GetSpanTime(...), ex.Message ");
        }
        finally { }
        //TraceState(outSpanTime, "GetSpanTime(...), outSpanTime ");
        return outSpanTime;
    }
    public static decimal? GetPrice(Asset? inAsset = default, Deal? inDeal = default, DateTime? inDate1 = default, string? inDate2 = default)  //TODO
    {
        decimal? Price = default;
        
        TraceState(Price, "Shell.GetPrice(...), Price ");
        return Price;
    }
    public static decimal? GetPercent(decimal? inAmount, decimal? inPercent1, decimal? inPercent2)  //TODO
    {
        //найти процент inPercent1 (например, НДС 12%) от суммы inAmount, которая составляет inPercent2 (например, 112%, или 100%)
        decimal? Amount = default;
        if (inPercent1 != 0)
        {
            Amount = (inAmount / inPercent2) * inPercent1;
        }
        
        TraceState(Amount, "Shell.GetPercent(...), Amount ");
        return Amount;
    }
    public static string? FixTrim(string? inStr = "")
    {//созд - 04.07.2022, изм - 06.07.2022
        string? outFix = inStr?.Trim() ?? "";

        //TraceState(outFix, "Shell.FixTrim(...), outFix ");
        return outFix;
    }
    public static DateTimeOffset? FixDate(DateTimeOffset? inDate = default)
    {
        DateTimeOffset? outDate = inDate ?? (DateTimeOffset)DateTime.Today;
        if (inDate < StartDate)
        {
            outDate = StartDate;
        }
        if (inDate > EndDate)
        {
            outDate = EndDate;
        }

        //TraceState(outDate, "Shell.FixDate(...), outDate ");
        return outDate;
    }
    static Shell()
    {//созд - 2022, изм - 23.07.2022
        //static ctor не может содержать ничего, кроме присваивания простых значений
    }
    public Shell()
    {//созд - 2022, изм - 23.07.2022
        //public ctor не может содержать ничего, кроме присваивания простых значений
    }
}
