﻿namespace BN;
[Serializable]
public partial class Exchange : Shell
{
    private byte? id;
    public byte? Id
    {
        get => id;
        set => id = FixId(value);
    }
    public Exchange? Parent { get; set; }
    private DateTimeOffset? date1;
    public DateTimeOffset? Date1
    {
        get => date1;
        set => date1 = FixDate1(value);
    }
    public string? Date2 { get; set; }
    public string? Code { get; set; }
    public string? Description { get; set; }
    public string? More { get; set; }
    public Role? Role { get; set; }
    public string? TargetPath;
    public string? TargetFile;
    public string? TargetExchange;
    public static SortedDictionary<string, Exchange>? Abc { get; set; }  //ключ типа = "Account.Basic.Ac.1010"
    public Exchange() { }
    public Exchange(byte? id = default,
                   Exchange? parent = default,
                   DateTimeOffset? date1 = default,
                   string? date2 = default,
                   string? code = default,
                   string? description = default,
                   Role? role = default,
                   string? more = default)
    {
        Id = id;
        Parent = parent;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        Role = role;
        More = more;
        TargetPath = StartDirectory;
    }
    static Exchange() { }
    public StringBuilder SwiftOPV(Workbook? WorkbookSalary = default)
    {
        StringBuilder TextSwift = new();
        //Exchange SwiftOPV = Basic[key: "Role.Exchange.SwiftOPV"];
        //SwiftOPV.TargetFile = @"Swift_OPV.txt";
        //SwiftOPV.TargetExchange = GetTargetExchangeValue(TargetPath, TargetFile);
        //TODO - выгрузка свифт файла для ОПВ
        
        TraceState(TextSwift, "SwiftOPV(...), TextSwift ");
        return TextSwift;
    }
    public static string GetTargetExchangeValue(string? inTargetPath, string? inTargetFile)
    {
        string? TargetExchangeValue = inTargetPath + "\\" + inTargetFile;
        if (TargetExchangeValue == null)
        {
            TargetExchangeValue = "GetTargetExchangeValue.No TargetExchangeValue";
        }
        
        TraceState(TargetExchangeValue, "GetTargetExchangeValue(...), TargetExchangeValue ");
        return TargetExchangeValue;
    }
    public byte? FixId(byte? inId = default)
    {
        byte? FixId = inId;
        if (FixId < 0)
        {
            FixId = 0;
        }

        //TraceState(FixId, "Exchange.FixId(...), FixId ");
        return FixId;
    }
    public static DateTimeOffset? FixDate1(DateTimeOffset? inDate1 = default)
    {
        DateTimeOffset? FixDate1 = inDate1 ?? (DateTimeOffset)DateTime.Today;
        if (inDate1 < StartDate)
        {
            FixDate1 = StartDate;
        }
        if (inDate1 > EndDate)
        {
            FixDate1 = EndDate;
        }

        //TraceState(FixDate1, "Exchange.FixDate1(...), FixDate1 ");
        return FixDate1;
    }
    public override string ToString()
    {
        return $"{GetType()}, {Id.ToString() ?? "No Id"}, {Parent?.ToString() ?? "No Parent"}, {Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"} ";
    }
}
