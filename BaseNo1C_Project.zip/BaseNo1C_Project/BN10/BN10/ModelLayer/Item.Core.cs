﻿namespace BN;
[Serializable]
public partial class Item : Shell
{//созд - 2021, //изм - 22.07.2022
    public Item()
    {//созд - 2021, изм - 23.07.2022
        //public ctor не может содержать ничего, кроме присваивания простых значений
    }
    public Item(int? id = default,
               Item? parent = default,
               DateTimeOffset? date1 = default,
               string? date2 = default,
               string? code = default,
               string? description = default,
               string? more = default)
    {
        Id = id;
        Parent = parent;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        More = more;
    }
    static Item()
    {//созд - 2022, изм - 23.07.2022
        //static ctor не может содержать ничего, кроме присваивания простых значений
    }
    public static Item TestItem()
    {//созд - 2022, изм - 21.07.2022
        Item outItem = new();

        //TraceState(outItem, "Item.TestItem(...), TestItem.outItem ");
        return outItem;
    }
    public override string ToString()
    {
        return $"{GetType()}, {Id.ToString() ?? "No Id"}, {Parent?.ToString() ?? "No Parent"}, {Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"} ";
    }
}
