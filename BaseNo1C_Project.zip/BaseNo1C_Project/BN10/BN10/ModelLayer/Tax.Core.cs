﻿namespace BN;
[Serializable]
public partial class Tax : Shell
{
    private short? id;
    public short? Id
    {
        get => id;
        set => id = FixId(value);
    }
    public Tax? Parent { get; set; }
    private DateTimeOffset? date1;
    public DateTimeOffset? Date1
    {
        get => date1;
        set => date1 = FixDate1(value);
    }
    public string? Date2 { get; set; }
    public string? Code { get; set; }
    public string? Description { get; set; }
    public string? More { get; set; }
    public Face? Face1 { get; set; }
    public Face? Face2 { get; set; }
    public Geo? Geo { get; set; }
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    public Tax? Base = default; //TODO
    public Tax? Rate = default; //TODO
    public Tax? Mode = default; //TODO
    public Tax? Deduction = default; //TODO
    public static SortedDictionary<string, Tax>? Abc { get; set; }  //ключ типа = "Account.Basic.Ac.1010"
    public static Tax? Root;  //TODO - корневой элемент, не имеющий родителя Parent, потом заполнить ???
    public Tax() { }
    public Tax(short? id = default,
               Tax? parent = default,
               Face? face1 = default,
               Face? face2 = default,
               Geo? geo = default,
               DateTimeOffset? date1 = default,
               string? date2 = default,
               string? code = default,
               string? description = default,
               Role? role = default,
               Info? info = default,
               string? more = default)
    {
        Id = id;
        Parent = parent;
        Face1 = face1;
        Face2 = face2;
        Geo = geo;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        Role = role;
        Info = info;
        More = more;
    }
    static Tax() { }
    public Role? GetTaxModeValue(DateTime Date1,
                                string? Date2,
                                Tax? Tax) //TODO
    {
        Role? TaxModeValue = default;

        TraceState(TaxModeValue, "Tax.GetTaxModeValue(...), TaxModeValue ");
        return TaxModeValue;
    }
    public Role? GetTaxBaseValue(DateTime Date1,
                                string? Date2,
                                Tax? Tax) //TODO
    {
        Role? TaxBaseValue = default;

        TraceState(TaxBaseValue, "Tax.GetTaxBaseValue(...), TaxBaseValue ");
        return TaxBaseValue;
    }
    public decimal? GetTaxRateValue(DateTime Date1,
                                string? Date2,
                                Tax? Tax) //TODO
    {
        decimal? TaxRateValue = default;

        TraceState(TaxRateValue, "Tax.GetTaxRateValue(...), TaxRateValue ");
        return TaxRateValue;
    }
    public decimal? GetTaxDeductionValue(DateTime Date1,
                                string? Date2,
                                Tax? Tax) //TODO
    {
        decimal? TaxDeductionValue = default;

        TraceState(TaxDeductionValue, "Tax.GetTaxDeductionValue(...), TaxDeductionValue ");
        return TaxDeductionValue;
    }
    public short? FixId(short? inId = default)
    {
        short? FixId = inId;
        if (FixId < 0)
        {
            FixId = 0;
        }

        //TraceState(FixId, "Tax.FixId(...), FixId ");
        return FixId;
    }
    public static DateTimeOffset? FixDate1(DateTimeOffset? inDate1 = default)
    {
        DateTimeOffset? FixDate1 = inDate1 ?? (DateTimeOffset)DateTime.Today;
        if (inDate1 < StartDate)
        {
            FixDate1 = StartDate;
        }
        if (inDate1 > EndDate)
        {
            FixDate1 = EndDate;
        }

        //TraceState(FixDate1, "Tax.FixDate1(...), FixDate1 ");
        return FixDate1;
    }
    public override string ToString()
    {
        return $"{GetType()}, {Id.ToString() ?? "No Id"}, {Parent?.ToString() ?? "No Parent"}, " +
            $"{Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"} ";
    }
}
