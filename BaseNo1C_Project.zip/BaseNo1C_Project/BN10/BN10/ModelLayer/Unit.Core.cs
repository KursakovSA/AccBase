﻿namespace BN;
[Serializable]
public partial class Unit : Shell
{
    private short? id;
    public short? Id
    {
        get => id;
        set => id = FixId(value);
    }
    public Unit? Parent { get; set; }
    private DateTimeOffset? date1;
    public DateTimeOffset? Date1
    {
        get => date1;
        set => date1 = FixDate1(value);
    }
    public string? Date2 { get; set; }
    public string? Code { get; set; }
    public string? Description { get; set; }
    public string? More { get; set; }
    public Role? Role { get; set; }
    public Unit? Unit1 { get; set; }
    public static SortedDictionary<string, Unit>? Abc { get; set; }  //ключ типа = "Account.Basic.Ac.1010"
    public static Unit? Root;  //TODO - корневой элемент, не имеющий родителя Parent, потом заполнить ???
    public Unit() { }
    public Unit(short? id = default,
                 Unit? parent = default,
                 Face? face1 = default,
                 Face? face2 = default,
                 Face? face = default,
                 Geo? geo = default,
                 DateTimeOffset? date1 = default,
                 string? date2 = default,
                 string? code = default,
                 string? description = default,
                 Role? role = default,
                 Unit? unit1 = default,
                 string? more = default)
    {
        Id = id;
        Parent = parent;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        Role = role;
        Unit1 = unit1;
        More = more;
    }
    static Unit() { }
    public short? FixId(short? inId = default)
    {
        short? FixId = inId;
        if (FixId < 0)
        {
            FixId = 0;
        }

        //TraceState(FixId, "Unit.FixId(...), FixId ");
        return FixId;
    }
    public static DateTimeOffset? FixDate1(DateTimeOffset? inDate1 = default)
    {
        DateTimeOffset? FixDate1 = inDate1 ?? (DateTimeOffset)DateTime.Today;
        if (inDate1 < StartDate)
        {
            FixDate1 = StartDate;
        }
        if (inDate1 > EndDate)
        {
            FixDate1 = EndDate;
        }

        //TraceState(FixDate1, "Unit.FixDate1(...), FixDate1 ");
        return FixDate1;
    }
    public override string ToString()
    {
        return $"{GetType()}, {Id.ToString() ?? "No Id"}, {Parent?.ToString() ?? "No Parent"}, " +
            $"{Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"} ";
    }
}
