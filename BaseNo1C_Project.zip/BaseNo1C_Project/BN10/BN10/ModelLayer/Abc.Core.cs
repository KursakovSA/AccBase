﻿namespace BN;
[Serializable]
public partial class Abc : Shell
{
    public static List<string> ListAbcKind = new()
    {
        "Basic",
        "Catalog",
        "CodePay",
        "Switch",
        "Table",
        "Template",
    };
    public static List<Object> GetAbc(string? table)
    {
        List<Object> listAcc = new();
        foreach (var AbcKind in ListAbcKind)
        {
            //    //string? templateMore = "'%" + mast.Value.ToString() + "%'";
            //    string? templateMore = null;
            //    using (SqlDataReader DataReader = GetDataReader(tableView, templateMore))
            //    {
            //        if (DataReader.HasRows)
            //        {
            //            while (DataReader.Read())
            //            {
            //                Console.WriteLine($"Id: {DataReader["Id"]}, Code: {DataReader["Code"]}, More: {DataReader["More"]}");
            //                //res.Add(new Abc {Id = (int)DataReader["Id"], Code = (string)DataReader["Code"], More = (string)DataReader["More"] });
            //                //listAcc.Add(new Account { Id = (short)DataReader["Id"], Date1 = (DateTimeOffset)DataReader["Date1"], Code = (string)DataReader["Code"], More = (string)DataReader["More"] });
            //                listAcc.Add(new Account { Id = (short)DataReader["Id"], Date1 = (DateTimeOffset)DataReader["Date1"], Code = (string)DataReader["Code"], More = (string)DataReader["More"] });
            //            }
            //        }
            //        DataReader.Close();
            //        CloseConn(SqlConn);
        }
        //    TraceState(listAcc.Count, "GetABC(...), listAcc.Count ");
        //    //TraceState(res.Count, "GetABC(...), res.Count ");
        return listAcc;
    }

    ////IEnumerable<Account> subset = from g in ListTable where g.More.Contains("basic") orderby g select g;
    //IEnumerable<Account> subset = from g in ListTable select g;
    //var subset = from g in ListTable select g;

    //foreach (var s in ListTable)
    //{
    //    Console.WriteLine($"ListTable.Key:{s.Key}, ListTable.Value:{s.Value}");
    //    Console.ReadLine();
    //}
}