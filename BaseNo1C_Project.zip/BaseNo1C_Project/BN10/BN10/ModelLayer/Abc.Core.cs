﻿namespace BN;
[Serializable]
public partial class Abc : Shell
{//созд - 2022, изм - 23.07.2022
    public static void GetAbcDb()
    {//созд - 2022, изм - 23.07.2022
        //TODO --- потом как-нибудь может быть сделать что-то типа делегата, энуменатора, указание на метод в зависимости от наим-я таблицы
        Account.Abc = GetAbcTable(conn: MainConnCurr, "Account");
        TraceState(Account.Abc?.Count(), "Abc.GetAbcDb(...), Account.Abc?.Count() ");
        
        Asset.Abc = GetAbcTable(conn: MainConnCurr, "Asset");
        TraceState(Asset.Abc?.Count(), "Abc.GetAbcDb(...), Asset.Abc?.Count() ");

        Deal.Abc = GetAbcTable(conn: MainConnCurr, "Deal");
        TraceState(Deal.Abc?.Count(), "Abc.GetAbcDb(...), Deal.Abc?.Count() ");

        Face.Abc = GetAbcTable(conn: MainConnCurr, "Face");
        TraceState(Face.Abc?.Count(), "Abc.GetAbcDb(...), Face.Abc?.Count() ");

        Geo.Abc = GetAbcTable(conn: MainConnCurr, "Geo");
        TraceState(Geo.Abc?.Count(), "Abc.GetAbcDb(...), Geo.Abc?.Count() ");

        Info.Abc = GetAbcTable(conn: MainConnCurr, "Info");
        TraceState(Info.Abc?.Count(), "Abc.GetAbcDb(...), Info.Abc?.Count() ");

        Item.Abc = GetAbcTable(conn: MainConnCurr, "Item");
        TraceState(Item.Abc?.Count(), "Abc.GetAbcDb(...), Item.Abc?.Count() ");

        Mark.Abc = GetAbcTable(conn: MainConnCurr, "Mark");
        TraceState(Mark.Abc?.Count(), "Abc.GetAbcDb(...), Mark.Abc?.Count() ");

        Meter.Abc = GetAbcTable(conn: MainConnCurr, "Meter");
        TraceState(Meter.Abc?.Count(), "Abc.GetAbcDb(...), Meter.Abc?.Count() ");

        Price.Abc = GetAbcTable(conn: MainConnCurr, "Price");
        TraceState(Price.Abc?.Count(), "Abc.GetAbcDb(...), Price.Abc?.Count() ");

        Process.Abc = GetAbcTable(conn: MainConnCurr, "Process");
        TraceState(Process.Abc?.Count(), "Abc.GetAbcDb(...), Process.Abc?.Count() ");

        Role.Abc = GetAbcTable(conn: MainConnCurr, "Role");
        TraceState(Role.Abc?.Count(), "Abc.GetAbcDb(...), Role.Abc?.Count() ");

        Sign.Abc = GetAbcTable(conn: MainConnCurr, "Sign");
        TraceState(Sign.Abc?.Count(), "Abc.GetAbcDb(...), Sign.Abc?.Count() ");

        Slice.Abc = GetAbcTable(conn: MainConnCurr, "Slice");
        TraceState(Slice.Abc?.Count(), "Abc.GetAbcDb(...), Slice.Abc?.Count() ");

        Tax.Abc = GetAbcTable(conn: MainConnCurr, "Tax");
        TraceState(Tax.Abc?.Count(), "Abc.GetAbcDb(...), Tax.Abc?.Count() ");

        Unit.Abc = GetAbcTable(conn: MainConnCurr, "Unit");
        TraceState(Unit.Abc?.Count(), "Abc.GetAbcDb(...), Unit.Abc?.Count() ");

        Workbook.Abc = GetAbcTable(conn: MainConnCurr, "Workbook");
        TraceState(Workbook.Abc?.Count(), "Abc.GetAbcDb(...), Workbook.Abc?.Count() ");
    }
    public static List<Abc>? GetAbcTable(SqlConnection conn, string strTable)//отбор Abc по принципу - это все строки таблицы с More = basic, в 1-м экземпляре, хотя та же строка может быть и други типом Abc, например, switch
    {//созд - 2022, изм - 18.07.2022
        string? templMore = "'%" + strTable + ".Basic%'";//компонуем строку фильтра More для запроса типа "'%Account.Basic%'"
        //templMore = "'%" + strTable + ".table%'";//например, для проверки, для Account/Table = 2
        List<Shell>?  ListShell = GetTable(conn, strTable, templateMore: templMore);
        List<Abc>? outAbc = new();
        foreach (Shell? shl in ListShell)
        {
            outAbc.Add(new Abc { Id = shl.Id, Parent = shl.Parent, Date1 = shl.Date1, Date2 = shl.Date2, Code = shl.Code, Description = shl.Description, More = shl.More });
        }
        //TraceState(ListShell.Count + "/" + strTable.ToString() + "/" +templMore, "GetAbcTable(...), ListShell.Count / strTable / templateMore");
        //TraceState(outAbc.Count, "GetAbcTable(...), outAbc");
        return outAbc;
    }
    public static Abc GetAbc(string? table)  //TODO - получение единичного Abc  ???   
    {//созд - 2022, изм - 20.07.2022
        Abc outAbc = new();
        
        TraceState(outAbc.ToString(), "GetABC(...), outAbc");
        return outAbc;
    }
    public Abc()
    {//созд - 2022, изм - 23.07.2022
        //public ctor не может содержать ничего, кроме присваивания простых значений
    }
    public Abc(int? id = default, Abc? parent = default, DateTimeOffset? date1 = default, string? date2 = default, string? code = default, string? description = default, string? more = default)
    {
        Id = id;
        Parent = parent;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        More = more;
    }
    static Abc()
    {//созд - 2022, изм - 23.07.2022
        //static ctor не может содержать ничего, кроме присваивания простых значений
        Abc = new List<Abc> { new Abc { Code = "Basic" }, new Abc { Code = "Catalog" }, new Abc { Code = "CodePay" }, new Abc { Code = "Switch" }, new Abc { Code = "Table" }, new Abc { Code = "Template" }, };
    }
    public static Abc TestAbc()
    {//созд - 2022, изм - 20.07.2022
        Abc outAbc = new();

        //TraceState(outAbc, "Abc.TestAbc(...), TestAbc.outAbc ");
        return outAbc;
    }
    public override string ToString()
    {//созд - 2022, изм - 2022
        return $"{GetType()}, {Id?.ToString() ?? "No Id"}, {Parent?.Code?.ToString() ?? "No Parent"}, {Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"} ";
    }
}