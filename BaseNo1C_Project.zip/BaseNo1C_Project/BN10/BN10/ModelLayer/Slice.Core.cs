﻿namespace BN;
[Serializable]
public partial class Slice : Shell
{//созд - 2021, изм - 22.07.2022
    public Slice(int? id = default, Slice? parent = default, DateTimeOffset? date1 = default, string? date2 = default, string? code = default, string? description = default, string? more = default)
    {//созд - 2021, изм - 23.07.2022
        Id = id;
        Parent = parent;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        More = more;
    }
    public Slice()
    {//созд - 2021, изм - 23.07.2022
        //public ctor не может содержать ничего, кроме присваивания простых значений
    }
    static Slice()
    {//созд - 2022, изм - 23.07.2022
        //static ctor не может содержать ничего, кроме присваивания простых значений
    }
    public static Slice TestSlice()
    {//созд - 2022, изм - 21.07.2022
        Slice outSlice = new();

        //TraceState(outSlice, "Slice.TestSlice(...), TestSlice.outSlice ");
        return outSlice;
    }
    public override string ToString()
    {
        return $"{GetType()}, {Id.ToString() ?? "No Id"}, {Parent?.ToString() ?? "No Parent"}, {Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"} ";
    }
}
