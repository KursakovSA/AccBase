﻿namespace BN;
[Serializable]
public partial class Account : Shell
{
    private short? id;
    public short? Id
    {
        get => id;
        set => id = FixId(value);
    }
    private Account? parent;
    public Account? Parent
    {
        get => parent;
        set => parent = FixParent(value);
    }
    //public short Parent { get; set; }
    private DateTimeOffset? date1;
    public DateTimeOffset? Date1
    {
        get => date1;
        set => date1 = FixDate1(value);
    }
    public string? Date2 { get; set; }
    public string? Code { get; set; }
    public string? Description { get; set; }
    public Slice? Slice { get; set; }
    public Account? Account1 { get; set; }
    public Role? Role { get; set; }
    public Sign? Sign { get; set; }
    public string? More { get; set; }
    public Account? AccountTable;
    public static Account? PreviousTable;   //TODO, пока пустое поле, до очередной смены плана счетов
    public static Account? CurrentTable;
    public static Account? FutureTable;   //TODO, пока пустое поле, до очередной смены плана счетов
    public static SortedDictionary<string, string>? ClosePlan { get; set; } //TODO 
    public static SortedDictionary<string, string>? ConversePlan { get; set; } //TODO, пока пустое поле, до очередной смены плана счетов
    public static SortedDictionary<string, Account>? Abc { get; set; }  //ключ типа = "Account.Basic.Ac.1010"
    public static Account? Root;  //TODO - корневой элемент, не имеющий родителя Parent, потом заполнить ???
    public Account() { }
    public Account(short? id = default,
                   Account? parent = default,
                   DateTimeOffset? date1 = default,
                   string? date2 = default,
                   string? code = default,
                   string? description = default,
                   Account? account1 = default,
                   string? more = default,
                   Account? accountTable = default)
    {
        Id = id;
        Parent = parent;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        Account1 = account1;
        More = more;
        AccountTable = accountTable;
    }
    static Account()
    {
        //CurrentTable = Basic[key: "AccTable2019"];  ////TODO - надо как-то 
    }
    public static short? FixId(short? inId = default)
    {
        short? FixId = inId;
        if (FixId < 1)
        {
            FixId = 0;
        }

        //TraceState(FixId, "Account.FixId(...), FixId ");
        return FixId;
    }
    public static DateTimeOffset? FixDate1(DateTimeOffset? inDate1 = default)
    {
        DateTimeOffset? FixDate1 = inDate1 ?? (DateTimeOffset)DateTime.Today;
        if (inDate1 < StartDate)
        {
            FixDate1 = StartDate;
        }
        if (inDate1 > EndDate)
        {
            FixDate1 = EndDate;
        }

        //TraceState(FixDate1, "Account.FixDate1(...), FixDate1 ");
        return FixDate1;
    }
    public static Account? FixParent(Account? inParent = default)
    {
        Account? FixParent = inParent ?? new Account { };

        //TraceState(inParent, "Account.FixParent(...), FixParent.inParent ");
        //TraceState(FixParent, "Account.FixParent(...), FixParent.FixParent ");
        return FixParent;
    }
    public override string ToString()
    {
        return $"{GetType()}, {Id?.ToString() ?? "No Id"}, {Parent?.Code?.ToString() ?? "No Parent"},{Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"}, {AccountTable?.Description}";
    }
}
