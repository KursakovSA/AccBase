﻿namespace BN;
[Serializable]
public partial class Price : Shell
{
    private short? id;
    public short? Id
    {
        get => id;
        set => id = FixId(value);
    }
    public Price? Parent { get; set; }
    private DateTimeOffset? date1;
    public DateTimeOffset? Date1
    {
        get => date1;
        set => date1 = FixDate1(value);
    }
    public string? Date2 { get; set; }
    public string? Code { get; set; }
    public string? Description { get; set; }
    public string? More { get; set; }
    public Face? Face1 { get; set; }
    public Face? Face2 { get; set; }
    public Face? Face { get; set; }
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    public Unit? Unit { get; set; }
    public static SortedDictionary<string, Price>? Markup = new(); //TODO
    public static SortedDictionary<string, Price>? Sale = new(); //TODO
    public static SortedDictionary<string, Price>? Abc { get; set; }  //ключ типа = "Account.Basic.Ac.1010"
    public static Price? Root;  //TODO - корневой элемент, не имеющий родителя Parent, потом заполнить ???
    public Price() { }
    public Price(short? id = default,
                 Price? parent = default,
                 Face? face1 = default,
                 Face? face2 = default,
                 Face? face = default,
                 DateTimeOffset? date1 = default,
                 string? date2 = default,
                 string? code = default,
                 string? description = default,
                 Role? role = default,
                 Info? info = default,
                 Unit? unit = default,
                 string? more = default)
    {
        Id = id;
        Parent = parent;
        Face1 = face1;
        Face2 = face2;
        Face = face;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        Role = role;
        Info = info;
        Unit = unit;
        More = more;
    }
    static Price()
    {
        //Markup.Add("Price.MarkupBasic", Price.Basic[key: "Price.MarkupBasic"]);
        //Sale.Add("Price.SaleBasic", Price.Basic[key: "Price.SaleBasic"]);
    }
    public short? FixId(short? inId = default)
    {
        short? FixId = inId;
        if (FixId < 0)
        {
            FixId = 0;
        }

        //TraceState(FixId, "Price.FixId(...), FixId ");
        return FixId;
    }
    public static DateTimeOffset? FixDate1(DateTimeOffset? inDate1 = default)
    {
        DateTimeOffset? FixDate1 = inDate1 ?? (DateTimeOffset)DateTime.Today;
        if (inDate1 < StartDate)
        {
            FixDate1 = StartDate;
        }
        if (inDate1 > EndDate)
        {
            FixDate1 = EndDate;
        }

        //TraceState(FixDate1, "Price.FixDate1(...), FixDate1 ");
        return FixDate1;
    }
    public override string ToString()
    {
        return $"{GetType()}, {Id.ToString() ?? "No Id"}, {Parent?.ToString() ?? "No Parent"}, {Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"} ";
    }
}
