﻿namespace BN;
[Serializable]
public partial class Face : Shell
{
    private int? id;
    public int? Id
    {
        get => id;
        set => id = FixId(value);
    }
    private DateTimeOffset? date1;
    public DateTimeOffset? Date1
    {
        get => date1;
        set => date1 = FixDate1(value);
    }
    public string? Date2 { get; set; }
    public string? Code { get; set; }
    public string? Description { get; set; }
    public string? More { get; set; }
    public Face? Parent { get; set; }
    public Face? Face1 { get; set; }
    public Face? Face2 { get; set; }
    public Geo? Geo { get; set; }
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    public static SortedDictionary<string, Face> StoreBasic = new(); //TODO
    public SortedDictionary<string, Face> Store = new(); //TODO
    public static SortedDictionary<string, Face> UserBasic = new(); //TODO
    public static SortedDictionary<string, Face> DepartmentBasic = new(); //TODO
    public static SortedDictionary<string, Face> CashBasic = new(); //TODO
    public static SortedDictionary<string, Face> BankBasic = new(); //TODO
    public static SortedDictionary<string, Face> StaffTable = new();  //TODO
    public SortedDictionary<string, Face>? Staff = new();  //TODO
    public SortedDictionary<string, Workbook>? Address = new(); //TODO
    public static SortedDictionary<string, Info>? CodeEnterprise = new();  //TODO
    public static SortedDictionary<string, Info>? CodePerson = new();  //TODO
    public Workbook? TaxModeFace; //TODO
    public static SortedDictionary<string, Face>? Abc { get; set; }  //ключ типа = "Account.Basic.Ac.1010"
    public static Face? Root;  //TODO - корневой элемент, не имеющий родителя Parent, потом заполнить ???
    public Face() { }
    public Face(int? id = default,
                 Face? parent = default,
                 Face? face1 = default,
                 Face? face2 = default,
                 Geo? geo = default,
                 DateTimeOffset? date1 = default,
                 string? date2 = default,
                 string? code = default,
                 string? description = default,
                 Role? role = default,
                 Info? info = default,
                 string? more = default)
    {
        Id = id;
        Parent = parent;
        Face1 = face1;
        Face2 = face2;
        Geo = geo;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        Role = role;
        Info = info;
        More = more;
    }
    static Face() { }
    public int? FixId(int? inId = default)  
    {
        int? FixId = inId;
        if (FixId < 0)
        {
            FixId = 0;
        }

        //TraceState(FixId, "Face.FixId(...), FixId ");
        return FixId;
    }
    public static DateTimeOffset? FixDate1(DateTimeOffset? inDate1 = default)
    {
        DateTimeOffset? FixDate1 = inDate1 ?? (DateTimeOffset)DateTime.Today;
        if (inDate1 < StartDate)
        {
            FixDate1 = StartDate;
        }
        if (inDate1 > EndDate)
        {
            FixDate1 = EndDate;
        }

        //TraceState(FixDate1, "Face.FixDate1(...), FixDate1 ");
        return FixDate1;
    }
    public static Workbook? GetTaxModeFaceValue(DateTime Date1,
                                string? Date2,
                                Face? Face,
                                Tax? Tax) //TODO
    {
        Workbook? TaxModeFaceValue = default;

        TraceState(TaxModeFaceValue, "GetTaxModeFaceValue(...), TaxModeFaceValue ");
        return TaxModeFaceValue;
    }
    public override string ToString()
    {
        return $"{GetType()}, {Id.ToString() ?? "No Id"}, {Parent?.ToString() ?? "No Parent"}, {Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"} ";
    }
}
