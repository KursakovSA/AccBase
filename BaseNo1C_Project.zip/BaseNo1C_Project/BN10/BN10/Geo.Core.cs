﻿namespace BN;
[Serializable]
public partial class Geo : Shell
{
    private short? id;
    public short? Id
    {
        get => id;
        set => id = FixId(value);
    }
    private DateTimeOffset? date1;
    public DateTimeOffset? Date1
    {
        get => date1;
        set => date1 = FixDate1(value);
    }
    public string? Date2 { get; set; }
    public string? Code { get; set; }
    public string? Description { get; set; }
    public string? More { get; set; }
    public Geo? Parent { get; set; }
    public Role? Role { get; set; }
    public Unit? Unit { get; set; }
    public string? AddressPost;
    public static SortedDictionary<string, Geo>? Abc { get; set; }  //ключ типа = "Account.Basic.Ac.1010"
    public Geo() { }
    public Geo(short? id = default,
               Geo? parent = default,
               DateTimeOffset? date1 = default,
               string? date2 = default,
               string? code = default,
               string? description = default,
               Role? role = default,
               Unit? unit = default,
               string? more = default)
    {
        Id = id;
        Parent = parent;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        Role = role;
        Unit = unit;
        More = more;
    }
    static Geo() { }
    public short? FixId(short? inId = default)
    {
        short? FixId = inId;
        if (FixId < 0)
        {
            FixId = 0;
        }

        //TraceState(FixId, "Geo.FixId(...), FixId ");
        return FixId;
    }
    public static DateTimeOffset? FixDate1(DateTimeOffset? inDate1 = default)
    {
        DateTimeOffset? FixDate1 = inDate1 ?? (DateTimeOffset)DateTime.Today;
        if (inDate1 < StartDate)
        {
            FixDate1 = StartDate;
        }
        if (inDate1 > EndDate)
        {
            FixDate1 = EndDate;
        }

        //TraceState(FixDate1, "Geo.FixDate1(...), FixDate1 ");
        return FixDate1;
    }
    public override string ToString()
    {
        return $"{GetType()}, {Id.ToString() ?? "No Id"}, {Parent?.ToString() ?? "No Parent"}, {Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"} ";
    }
}
