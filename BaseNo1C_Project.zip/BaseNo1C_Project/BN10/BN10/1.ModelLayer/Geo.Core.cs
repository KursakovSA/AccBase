﻿namespace BN;
[Serializable]
public partial class Geo : Shell
{//созд - 2021, изм - 22.07.2022
    public Role? Role { get; set; }
    public Unit? Unit { get; set; }
    public string? AddressPost;
    public Geo()
    {//созд - 2021, изм - 23.07.2022
        //public ctor не может содержать ничего, кроме присваивания простых значений
    }
    public Geo(int? id = default, Geo? parent = default, DateTimeOffset? date1 = default, string? date2 = default, string? code = default, string? description = default, Role? role = default, Unit? unit = default, string? more = default)
    {
        Id = id;
        Parent = parent;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        Role = role;
        Unit = unit;
        More = more;
    }
    static Geo()
    {//созд - 2022, изм - 23.07.2022
        //static ctor не может содержать ничего, кроме присваивания простых значений
    }
    public static Geo TestGeo()
    {//созд - 2022, изм - 21.07.2022
        Geo outGeo = new();

        //TraceState(outGeo, "TestGeo(...), outGeo ");
        return outGeo;
    }
    public override string ToString()
    {
        return $"{GetType()}, {Id.ToString() ?? "No Id"}, {Parent?.ToString() ?? "No Parent"}, {Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"} ";
    }
}
