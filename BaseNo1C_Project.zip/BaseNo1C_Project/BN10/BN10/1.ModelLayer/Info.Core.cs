﻿namespace BN;
[Serializable]
public partial class Info : Shell
{//созд - 2021, изм - 29.07.2022
    public static List<Info>? CodeEnterprise = new();  //TODO
    public static List<Info>? CodePerson = new();  //TODO
    public Info()
    {//созд - 2021, изм - 23.07.2022
        //public ctor не может содержать ничего, кроме присваивания простых значений
    }
    public Info(int? id = default, Info? parent = default, DateTimeOffset? date1 = default, string? date2 = default, string? code = default, string? description = default, string? more = default)
    {//созд - 2021, изм - 29.07.2022
        Id = id;
        Parent = parent;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        More = more;
    }
    static Info()
    {//созд - 2022, изм - 23.07.2022
        //static ctor не может содержать ничего, кроме присваивания простых значений
    }
    public static Info TestInfo()
    {//созд - 2022, изм - 21.07.2022
        Info outInfo = new();

        //TraceState(outInfo, "TestInfo(...), outInfo ");
        return outInfo;
    }
    public override string ToString()
    {
        return $"{GetType()}, {Id.ToString() ?? "No Id"}, {Parent?.ToString() ?? "No Parent"}, " +
            $"{Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"}";
    }
}
