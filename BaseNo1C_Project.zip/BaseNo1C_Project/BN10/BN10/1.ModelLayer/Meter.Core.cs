﻿namespace BN;
[Serializable]
public partial class Meter : Shell
{//созд - 2021, изм - 22.07.2022
    public Unit? Unit { get; set; }
    public Meter()
    {//созд - 2021, изм - 23.07.2022
        //public ctor не может содержать ничего, кроме присваивания простых значений
    }
    public Meter(int? id = default,
                 Meter? parent = default,
                 DateTimeOffset? date1 = default,
                 string? date2 = default,
                 string? code = default,
                 string? description = default,
                 Unit? unit = default,
                 string? more = default)
    {
        Id = id;
        Parent = parent;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        Unit = unit;
        More = more;
    }
    static Meter()
    {//созд - 2022, изм - 23.07.2022
        //static ctor не может содержать ничего, кроме присваивания простых значений
    }
    public static Meter TestMeter()
    {//созд - 2022, изм - 21.07.2022
        Meter outMeter = new();

        //TraceState(outMeter, "TestMeter(...), outMeter ");
        return outMeter;
    }
    public override string ToString()
    {
        return $"{GetType()}, {Id.ToString() ?? "No Id"}, {Parent?.ToString() ?? "No Parent"}, {Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"} ";
    }
}
