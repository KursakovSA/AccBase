﻿namespace BN;
[Serializable]
public partial class Tax : Shell
{//созд - 2021, изм - 01.12.2022
    public Face? Face1 { get; set; }
    public Face? Face2 { get; set; }
    public Geo? Geo { get; set; }
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    public Tax? Base = default; //TODO
    public Tax? Rate = default; //TODO
    public Tax? Mode = default; //TODO
    public Tax? Deduction = default; //TODO
    public Tax? GetTaxMode(DateTime Date1, string? Date2, Tax? Tax) //TODO
    {
        Tax? TaxMode = default;

        //TraceState(TaxMode, "GetTaxMode(...), TaxMode ");
        return TaxMode;
    }
    public decimal? GetTaxBaseMinLimitValue(DateTime Date1, string? Date2, Tax? TaxBase) //TODO
    {//созд - 01.12.2022, изм - 01.12.2022
        decimal? TaxBaseMinLimitValue = default;

        //TraceState(TaxBaseMinLimitValue, "GetTaxBaseMinLimitValue(...), TaxBaseMinLimitValue ");
        return TaxBaseMinLimitValue;
    }
    public decimal? GetTaxBaseMaxLimitValue(DateTime Date1, string? Date2, Tax? TaxBase) //TODO
    {//созд - 01.12.2022, изм - 01.12.2022
        decimal? TaxBaseMaxLimitValue = default;

        //TraceState(TaxBaseMaxLimitValue, "GetTaxBaseMaxLimitValue(...), TaxBaseMaxLimitValue ");
        return TaxBaseMaxLimitValue;
    }
    public decimal? GetTaxBaseExistValue(DateTime Date1, string? Date2, Tax? TaxBase) //TODO
    {//созд - 01.12.2022, изм - 01.12.2022
        decimal? TaxBaseValue = default;

        //TraceState(TaxBaseExistValue, "GetTaxBaseValue(...), TaxBaseValue ");
        return TaxBaseValue;
    }
    public decimal? GetTaxBaseValue(DateTime Date1, string? Date2, Tax? Tax) //TODO
    {//созд - 2021, изм - 01.12.2022
        decimal? TaxBaseValue = default;

        //TraceState(TaxBaseValue, "GetTaxBaseValue(...), TaxBaseValue ");
        return TaxBaseValue;
    }
    public static decimal? GetTaxRateDefaultValue(DateTimeOffset? Date1, string? TaxRateCode)
    {//созд - 28.11.2022, изм - 01.12.2022
        decimal? outTaxRateDefaultValue = 0;

        ////TODO - сделать твердые ставки по разным видам налогов в зависимости от кода ставки налога

        outTaxRateDefaultValue = SetZeroIfNegative(outTaxRateDefaultValue);  //приравниваем нулю, если отрицательное
        //TraceState(outTaxRateDefaultValue, "GetTaxRateDefaultValue(...), outTaxRateDefaultValue ");
        return outTaxRateDefaultValue;
    }
    public static decimal? GetTaxRateValue(DateTimeOffset? Date1, string? TaxRateCode)
    {//созд - 28.11.2022, изм - 01.12.2022
        decimal? outTaxRateValue = GetTaxRateDefaultValue(Date1, TaxRateCode);

        ////TODO - сделать выборку из внешнего файла ставок налогов

        outTaxRateValue = SetZeroIfNegative(outTaxRateValue);  //приравниваем нулю, если отрицательное
        //TraceState(outTaxRateValue, "GetTaxRateValue(...), outTaxRateValue ");
        return outTaxRateValue;
    }
    //public decimal? GetTaxRateValue(DateTime Date1, string? Date2, Tax? Tax) //TODO
    //{
    //    decimal? TaxRateValue = default;

    //    //TraceState(TaxRateValue, "GetTaxRateValue(...), TaxRateValue ");
    //    return TaxRateValue;
    //}
    public decimal? GetTaxDeductionExistValue(DateTime Date1, string? Date2, Tax? TaxDeduction) //TODO
    {//созд - 01.12.2022, изм - 01.12.2022
        decimal? TaxDeductionExistValue = default;

        //TraceState(TaxDeductionExistValue, "GetTaxDeductionExistValue(...), TaxDeductionExistValue ");
        return TaxDeductionExistValue;
    }
    public decimal? GetTaxDeductionValue(DateTime Date1, string? Date2, Tax? TaxDeduction) //TODO
    {//созд - 2021, изм - 01.12.2022
        decimal? TaxDeductionValue = default;

        //TraceState(TaxDeductionValue, "GetTaxDeductionValue(...), TaxDeductionValue ");
        return TaxDeductionValue;
    }
    public Tax()
    {//созд - 2021, изм - 23.07.2022
        //public ctor не может содержать ничего, кроме присваивания простых значений
    }
    public Tax(int? id = default, Tax? parent = default, Face? face1 = default, Face? face2 = default, Geo? geo = default, DateTimeOffset? date1 = default, string? date2 = default, string? code = default, string? description = default, Role? role = default, Info? info = default, string? more = default)
    {//созд - 2021, изм - 23.07.2022
        Id = id;
        Parent = parent;
        Face1 = face1;
        Face2 = face2;
        Geo = geo;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        Role = role;
        Info = info;
        More = more;
    }
    static Tax()
    {//созд - 2022, изм - 23.07.2022
        //static ctor не может содержать ничего, кроме присваивания простых значений
    }
    public static Tax TestTax()
    {//созд - 2022, изм - 21.07.2022
        Tax outTax = new();

        //TraceState(outTax, "TestTax(...), outTax ");
        return outTax;
    }
    public override string ToString()
    {
        return $"{GetType()}, {Id.ToString() ?? "No Id"}, {Parent?.ToString() ?? "No Parent"}, " +
            $"{Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"} ";
    }
}
