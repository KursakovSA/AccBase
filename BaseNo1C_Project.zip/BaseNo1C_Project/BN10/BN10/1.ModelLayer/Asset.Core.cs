﻿namespace BN;
[Serializable]
public partial class Asset : Shell
{//созд - 2021, изм - 24.07.2022
    public Face? Face1 { get; set; }
    public Face? Face2 { get; set; }
    public Face? Face { get; set; }
    public Geo? Geo { get; set; }
    public Asset? Asset1 { get; set; }  //catalog
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    public Unit? Unit { get; set; }
    public List<Asset>? SubAsset = new(); //TODO
    public Asset()
    {//созд - 2021, изм - 23.07.2022
        //public ctor не может содержать ничего, кроме присваивания простых значений
    }
    public Asset(int? id = default, Asset? parent = default, Face? face1 = default, Face? face2 = default, Face? face = default, Geo? geo = default, DateTimeOffset? date1 = default, string? date2 = default, string? code = default, string? description = default, Role? role = default, Info? info = default, Unit? unit = default, string? more = default)
    {//созд - 2021, изм - 23.07.2022
        Id = id;
        Parent = parent;
        Face1 = face1;
        Face2 = face2;
        Face = face;
        Geo = geo;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        Role = role;
        Info = info;
        Unit = unit;
        More = more;
    }
    static Asset()
    {//созд - 2021, изм - 23.07.2022
        //static ctor не может содержать ничего, кроме присваивания простых значений
    }
    public static Asset TestAsset()
    {//созд - 2022, изм - 20.07.2022
        Asset outAsset = new();

        //TraceState(outAsset, "TestAsset(...), outAsset ");
        return outAsset;
    }
    public override string ToString()
    {//созд - 2021, изм - 23.07.2022
        return $"{GetType()}, {Id.ToString() ?? "No Id"}, {Parent?.ToString() ?? "No Parent"}, {Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"} ";
    }
}
