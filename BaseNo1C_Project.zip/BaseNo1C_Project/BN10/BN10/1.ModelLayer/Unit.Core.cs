﻿namespace BN;
[Serializable]
public partial class Unit : Shell
{//созд - 2021, изм - 22.07.2022
    public Role? Role { get; set; }
    public Unit? Unit1 { get; set; }
    public Unit()
    {//созд - 2021, изм - 23.07.2022
        //public ctor не может содержать ничего, кроме присваивания простых значений
    }
    public Unit(int? id = default, Unit? parent = default, Face? face1 = default, Face? face2 = default, Face? face = default, Geo? geo = default, DateTimeOffset? date1 = default, string? date2 = default, string? code = default, string? description = default, Role? role = default, Unit? unit1 = default, string? more = default)
    {//созд - 2021, изм - 23.07.2022
        Id = id;
        Parent = parent;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        Role = role;
        Unit1 = unit1;
        More = more;
    }
    static Unit()
    {//созд - 2022, изм - 23.07.2022
        //static ctor не может содержать ничего, кроме присваивания простых значений
    }
    public static Unit TestUnit()
    {//созд - 2022, изм - 21.07.2022
        Unit outUnit = new();

        //TraceState(outUnit, "TestUnit(...), outUnit ");
        return outUnit;
    }
    public override string ToString()
    {
        return $"{GetType()}, {Id.ToString() ?? "No Id"}, {Parent?.ToString() ?? "No Parent"}, " +
            $"{Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"} ";
    }
}
