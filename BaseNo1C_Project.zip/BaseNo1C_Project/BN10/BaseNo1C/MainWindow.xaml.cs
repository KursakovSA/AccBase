﻿global using static System;
global using static System.Collections;
global using static System.Collections.Generic;
global using static System.Text;
global using static System.Data;
global using static System.Data.Sql;
global using static System.Data.SqlClient;
global using static System.Data.Common;
//global using static BN.DataAccessLayer;
//global using static BN.Conn;
//global using static BN.Qry;
//global using static BN.Shell;
//global using static BN.Trace;
//global using static BN.Abc;
//global using static BN.Context;
//global using static BN.Account;
//global using static BN.Asset;
//global using static BN.Deal;
//global using static BN.Example;
//global using static BN.Face;
//global using static BN.Geo;
//global using static BN.Info;
//global using static BN.Item;
//global using static BN.Mark;
//global using static BN.Meter;
//global using static BN.Price;
//global using static BN.Process;
//global using static BN.Role;
//global using static BN.Sign;
//global using static BN.Slice;
//global using static BN.Tax;
//global using static BN.Unit;
//global using static BN.Workbook;
//global using static BN.MathSp;
global using static System.Linq;
global using static System.Text;
global using static System.Threading.Tasks;
global using static System.Windows;
global using static System.Windows.Controls;
global using static System.Windows.Data;
global using static System.Windows.Documents;
global using static System.Windows.Input;
global using static System.Windows.Media;
global using static System.Windows.Media.Imaging;
global using static System.Windows.Navigation;
global using static System.Windows.Shapes;

namespace BaseNo1C
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
