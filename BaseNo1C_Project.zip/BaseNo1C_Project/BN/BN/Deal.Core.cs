﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.UtilClass;

namespace BN
{
    [Serializable]
    public partial class Deal : HeadClass
    {
        public Deal Parent;
        public Face Face1;
        public Face Face2;
        public Face Face;
        public Slice Slice;
        public Geo Geo;
        public Role Role;
        public Info Info;
        public Mark Mark;
    }
}
