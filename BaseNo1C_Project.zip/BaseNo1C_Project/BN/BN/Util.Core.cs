﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BN
{
    [Serializable]
    public partial class Util
    {
        //public static void FixObj(HeadClass checkObj, out HeadClass fixObj)   //исправляем строки объектов, самые распространенные ошибки
        //{                                                  //чтобы не звонили по каждой мелочи 300 раз !!!!
        //    HeadClass fixObj.Code = checkObj.Code.Trim();   //самое первое - удаляем пробелы начальные и конечные   
        //}
        
        public static bool IsDev = false;
        public static string LogConsole = default;

        public static SortedDictionary<string, string> ListBase = new SortedDictionary<string, string>
        {
            ["BaseN1"] = "BaseN1",
            ["BaseN2"] = "BaseN2",
            ["BaseN3"] = "BaseN3",
        };
        public static Dictionary<string, string> PartTab = new Dictionary<string, string>
        {
            ["SelectBase"] = "",
            ["Dialog"] = "",
            ["Tree"] = "",
            ["Main"] = "",
            ["SelectChangeMark"] = "",
            ["SelectChangeSlice"] = "",
        };
        public static Dictionary<string, string> Tab = new Dictionary<string, string>
        {
            ["List"] = "List",
            ["Detail"] = "Detail",
            ["Edit"] = "Edit",
            ["New"] = "New",
            ["Console"] = "Console",
        };
        public static Dictionary<string, string> EditableTable = new Dictionary<string, string>
        {
            ["Geo"] = "Geo",
            ["Log"] = "Log",
            ["Face"] = "Face",
            ["Deal"] = "Deal",
            ["Asset"] = "Asset",
            ["Price"] = "Price",
        };
        public static void TraceState(object Obj, string ContextObj)
        {
            if ((IsDev) && (Obj != null))
            {
                string tempstr = ContextObj + " == " + Obj.ToString() + Environment.NewLine;
                LogConsole += tempstr;
            }
        }
        public static string StrListObj<T>(List<T> ListObj)
        {
            string outListObj = default;
            foreach (T obj in ListObj)
            {
                //TODO - сделать сериализацию реквизитов obj
                if (obj != null)
                {
                    outListObj += obj.ToString();  //TODO - сделать добавление разделителя строк
                }
            }
            return outListObj;
        }
        public Util() { }
        static Util() { }
    }
}

