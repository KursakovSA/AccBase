﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.UtilClass;

namespace BN
{
    [Serializable]
    public partial class Mark : HeadClass
    {
        //db field
        public Mark Parent;
        public Role Role;

        //отсортировано  db more\log field

        //отсортировано  not db field

        //отсортировано  static field
        
        public Mark() { }
        static Mark() { }
    }

    public class ChangeMark : HeadClass
    {
        //db field
        public Mark Parent;
        public Role Role;

        //отсортировано  db more\log field

        //отсортировано  not db field
        public SortedDictionary<Mark,Mark> ChangePlan;  //TODO - заполнить  

        //отсортировано  static field
       
        public ChangeMark() { }
        static ChangeMark() { }
        public ChangeMark(int id, string code, string description)
        {
            Id = id;
            Code = code;
            Description = description;
        }
        public override string ToString()
        => $"Type={GetType()}, Id={Id}, Code={Code}, Description={Description}";
    }
}
