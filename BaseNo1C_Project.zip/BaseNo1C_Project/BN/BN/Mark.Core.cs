﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.Util;

namespace BN
{
    [Serializable]
    public partial class Mark : HeadClass
    {
        //db field
        public Mark Parent;
        public Role Role;

        //db more\log field

        //not db field

        //static field
        public static SortedDictionary<string, Mark> MainMark;

        public Mark() { }
        static Mark()
        {
            MainMark = new SortedDictionary<string, Mark>
            {
                ["CD"] = new Mark { Code = "CD" },
                ["DD"] = new Mark { Code = "DD" },
                ["DelD"] = new Mark { Code = "DelD" },
                ["ExD"] = new Mark { Code = "ExD" },
                ["MD"] = new Mark { Code = "MD" },
                ["TemplD"] = new Mark { Code = "TemplD" }
            };
        }
    }

    public class ChangeMark : HeadClass
    {
        //db field
        public Mark Parent;
        public Role Role;

        //db more\log field

        //not db field
        public SortedDictionary<Mark, Mark> ChangePlan;  //TODO - заполнить  

        //static field
        public static SortedDictionary<string,ChangeMark> MainChangeMark;

        public ChangeMark() { }
        static ChangeMark()
        {
            MainChangeMark = new SortedDictionary<string,ChangeMark>
            {
                ["ToCD"] = new ChangeMark { Code = "ToCD" },
                ["ToDD"] = new ChangeMark { Code = "ToDD" },
                ["ToDelD"] = new ChangeMark { Code = "ToDelD" }
            };
        }
    }
}
