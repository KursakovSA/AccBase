﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.UtilClass;

namespace BN
{
    [Serializable]
    public partial class Mark : HeadClass
    {
        public Mark Parent;
        public Role Role;
    }

    public class ChangeMark : Mark
    {
        public List<Mark> FromMark;
        public Mark ToMark;
        public ChangeMark() : this(default, default, default, default)
        { }
        public ChangeMark(int id, string code, string description, Mark toMark)
        {
            Id = id;
            Code = code;
            Description = description;
            ToMark = toMark;
            //ObjToConsole(this, "");
        }
        public override string ToString()
        => $"Type={GetType()}, Id={Id}, Code={Code}, Description={Description}, ToMark={ToMark.Code}";
    }
}
