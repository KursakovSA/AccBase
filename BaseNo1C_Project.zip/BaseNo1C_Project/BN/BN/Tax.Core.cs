﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.UtilClass;

namespace BN
{
    [Serializable]
    public partial class Tax : HeadClass
    {
        public Tax Parent;
        public Tax Root;
        public Face Face1;
        public Face Face2;
        public Geo Geo;
        public Account Account;
        public Role Role;
        public Info Info;
    }
}
