﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.UtilClass;

namespace BN
{
    public partial class Account
    {
        public Account Parent;
        public Slice Slice;
        public Role Role;
        public Sign Sign;
    }
}
