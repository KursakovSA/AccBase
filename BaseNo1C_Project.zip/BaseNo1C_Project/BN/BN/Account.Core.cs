﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.Util;

namespace BN
{
    [Serializable]
    public partial class AccTable : HeadClass
    {
        //db field
        public AccTable Parent { get; set; }
        public Slice Slice { get; set; }
        public Role Role { get; set; }

        ////not db field
        public SortedDictionary<Account, Account> ClosingPlan { get; set; } //TODO - сделать заполнение
        public SortedDictionary<string, Account> AccTableList { get; set; } //TODO - сделать заполнение  ?????
        public SortedDictionary<Account, Account> ConversionPlan { get; set; } //TODO - сделать заполнение
        private SortedDictionary<string, Account> mainAccount;
        public SortedDictionary<string, Account> MainAccount
        {
            get { return mainAccount; }
            set
            {
                switch (Code)
                {
                    #region AccTable2019.MainAccount.Fill
                    case "AccTable2019":
                        mainAccount = new SortedDictionary<string, Account>
                        {
                            ["Asset"] = new Account { Code = "Ac.1", AccTable = this },
                            ["AssetBio"] = new Account { Code = "Ac.1600", AccTable = this },
                            ["AssetCoverall"] = new Account { Code = "Ac.1310", Description = "Спецодежда", AccTable = this },
                            ["AssetGood"] = new Account { Code = "Ac.1330", AccTable = this },
                            ["AssetIntangible"] = new Account { Code = "Ac.2730", AccTable = this },
                            ["AssetMaterial"] = new Account { Code = "Ac.1310", Description = "Материал", AccTable = this },
                            ["AssetMortgage"] = new Account { Code = "Ac.1330", Description = "Залоговое имущество", AccTable = this },
                            ["AssetProduction"] = new Account { Code = "Ac.1320", AccTable = this },
                            ["AssetTool"] = new Account { Code = "Ac.1310", Description = "Инструмент", AccTable = this },
                            ["AssetUnfinishedProduction"] = new Account { Code = "Ac.1340", AccTable = this },
                            ["Customer"] = new Account { Code = "Ac.1210", AccTable = this },
                            ["CustomerPrepaid"] = new Account { Code = "Ac.3510", AccTable = this },
                            ["Equity"] = new Account { Code = "Ac.5", AccTable = this },
                            ["ExpenseCost"] = new Account { Code = "Ac.7010", AccTable = this },
                            ["ExpenseGeneral"] = new Account { Code = "Ac.7210", AccTable = this },
                            ["ExpenseSell"] = new Account { Code = "Ac.7110", AccTable = this },
                            ["FixedAsset"] = new Account { Code = "Ac.2410", AccTable = this },
                            ["FixedAssetBuilding"] = new Account { Code = "Ac.2410", Description = "Здания", AccTable = this },
                            ["FixedAssetCar"] = new Account { Code = "Ac.2410", Description = "Автотранспорт", AccTable = this },
                            ["FixedAssetDepreciation"] = new Account { Code = "Ac.2420", AccTable = this },
                            ["FixedAssetFurniture"] = new Account { Code = "Ac.2410", Description = "Мебель", AccTable = this },
                            ["FixedAssetLand"] = new Account { Code = "Ac.2410", Description = "Земля", AccTable = this },
                            ["FixedAssetMachine"] = new Account { Code = "Ac.2410", Description = "Машинное оборудование", AccTable = this },
                            ["FixedAssetOfficeEquipment"] = new Account { Code = "Ac.2410", Description = "Офисное оборудование", AccTable = this },
                            ["FixedAssetOther"] = new Account { Code = "Ac.2410", Description = "Прочие основные средства", AccTable = this },
                            ["FixedAssetUnfinishedConstruction"] = new Account { Code = "Ac.2930", AccTable = this },
                            ["Imprest"] = new Account { Code = "Ac.1250", AccTable = this },
                            ["IncomeSell"] = new Account { Code = "Ac.6010", AccTable = this },
                            ["Money"] = new Account { Code = "Ac.1000", AccTable = this },
                            ["MoneyBank"] = new Account { Code = "Ac.1030", AccTable = this },
                            ["MoneyCash"] = new Account { Code = "Ac.1010", AccTable = this },
                            ["MoneyTransit"] = new Account { Code = "Ac.1020", AccTable = this },
                            ["Salary"] = new Account { Code = "Ac.3350", AccTable = this },
                            ["SalaryDeduction"] = new Account { Code = "Ac.3380", AccTable = this },
                            ["Seller"] = new Account { Code = "Ac.3310", AccTable = this },
                            ["SellerPrepaid"] = new Account { Code = "Ac.1710", AccTable = this },
                            ["Tax"] = new Account { Code = "Ac.3110", AccTable = this },
                            ["TaxCar"] = new Account { Code = "Ac.3170", AccTable = this },
                            ["TaxExcise"] = new Account { Code = "Ac.3140", AccTable = this },
                            ["TaxIncome"] = new Account { Code = "Ac.3110", AccTable = this },
                            ["TaxIncomePerson"] = new Account { Code = "Ac.3120", AccTable = this },
                            ["TaxLand"] = new Account { Code = "Ac.3160", AccTable = this },
                            ["TaxOther"] = new Account { Code = "Ac.3190", AccTable = this },
                            ["TaxProperty"] = new Account { Code = "Ac.3180", AccTable = this },
                            ["TaxVATIn"] = new Account { Code = "Ac.1420", AccTable = this },
                            ["TaxVATOut"] = new Account { Code = "Ac.3130", AccTable = this },

                        };
                        break;
                    #endregion

                    #region AccTable2005.MainAccount.Fill
                    case "AccTable2005":
                        mainAccount = new SortedDictionary<string, Account>  //TODO - дозаполнить
                        {
                            ["Asset"] = new Account { Code = "Ac.1", AccTable = this },
                            ["FixedAssetBuilding"] = new Account { Code = "Ac.2410", Description = "Здания", AccTable = this },
                            ["MoneyBank"] = new Account { Code = "Ac.1030", AccTable = this },
                            //незаполнено до конца просто как пример...
                        };
                        break;
                    #endregion

                    default:
                        break;
                }
            }
        }

        //static field
        public static AccTable PreviousAccTable;
        public static AccTable CurrentAccTable;
        public static AccTable FutureAccTable;
        public AccTable(int id = default,
                        DateTime date1 = default,
                        string date2 = default,
                        string code = default,
                        string description = default,
                        Slice slice = default,
                        Role role = default,
                        string more = default,
                        SortedDictionary<string, Account> mainAccount = default)
        {
            Id = id;
            Date1 = DateTime.Today;//date1;
            Date2 = date2;
            Code = code;
            Description = description;
            More = more;
            Role = role;
            Slice = slice;
            MainAccount = mainAccount;
        }
        public AccTable() { }
        static AccTable() { }
        public void Closing(AccTable ClosingAccTable) { }
        public void Conversion(AccTable ConversionAccTable) { }
        public override string ToString()
        => $"{GetType()}, {Code}, {Description}, Slice={Slice.Code}, {MainAccountToString(this)}";
        public string MainAccountToString(AccTable AccTable)
        {
            string MainAccountToString = "MainAccount=" + AccTable.MainAccount["Asset"].Code;  //TODO - дозаполнить
            return MainAccountToString;
        }
    }
    [Serializable]
    public partial class Account : HeadClass
    {
        //db field
        public Account Parent;
        public Slice Slice;
        public Role Role;
        public Sign Sign;

        //db more\log field

        //not db field
        //[NotMapped]
        public Account CloseAccount;  //этот счет бывает не всегда
        //[NotMapped]
        public Account ContrAccount;  //этот счет бывает не всегда
        public AccTable AccTable;

        //static field 

        public Account() { }
        public Account(int id = default,
                       DateTime date1 = default,
                       string date2 = default,
                       string code = default,
                       string description = default,
                       string more = default,
                       AccTable accTable = default,
                       Account closeAccount = default,
                       Account contrAccount = default)
        {
            Id = id;
            Code = code;
            Date1 = DateTime.Today;//date1;
            Date2 = date2;
            Description = description;
            More = more;
            AccTable = accTable;
            CloseAccount = closeAccount;
            ContrAccount = contrAccount;
        }
        static Account() { }
        public override string ToString()
        => $"{GetType()}, {Code}, {Description ?? ""}, {AccTable.Description}";
    }


}
