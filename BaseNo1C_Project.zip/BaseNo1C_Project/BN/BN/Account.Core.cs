﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.UtilClass;

namespace BN
{
    [Serializable]
    public partial class AccTable : HeadClass
    {
        //db field
        public AccTable Parent;
        public Slice Slice;
        public Role Role;
        public Sign Sign;

        ////отсортировано not db field group1
        public Dictionary<Account, Account> ClosingPlan;  //TODO - сделать заполнение
        public List<Account> AccTableList;   //TODO - сделать заполнение
        public SortedDictionary<Account, Account> ConversionPlan;  //TODO - сделать заполнение

        ////отсортировано not db field group2
        public Account Bank;
        public Account Cash;
        public Account Cost;
        public Account Customer;
        public Account CustomerPrepaid;
        public Account Depreciation;
        public Account FixedAsset;
        public Account GeneralExpense;
        public Account Good;
        public Account Imprest;
        public Account Material;
        public Account Income;
        public Account MoneyTransit;
        public Account Production;
        public Account Salary;
        public Account Seller;
        public Account SellerPrepaid;
        public Account UnfinishedConstruction;
        public Account UnfinishedProduction;

        //отсортировано  static field
        public AccTable() { }
        static AccTable() { }

        public void Closing(List<Account> ClosingAccTableList, SortedDictionary<Account, Account> ClosingPlan) { }

        public void Conversion(List<Account> ConversionAccTableList, SortedDictionary<Account, Account> ConversionPlan) { }
    }
    [Serializable]
    public partial class Account : HeadClass
    {
        //db field
        public Account Parent;
        public Slice Slice;
        public Role Role;
        public Sign Sign;

        //отсортировано  db more\log field

        //отсортировано  not db field
        //[NotMapped]
        public Account CloseAccount;  //этот счет бывает не всегда
        //[NotMapped]
        public Account ContrAccount;  //этот счет бывает не всегда
        public AccTable AccTable;

        //отсортировано  static field 
        public static Account Bank;
        public static Account Cash;
        public static Account Cost;
        public static Account Customer;
        public static Account CustomerPrepaid;
        public static Account Depreciation;
        public static Account FixedAsset;
        public static Account GeneralExpense;
        public static Account Good;
        public static Account Imprest;
        public static Account Material;
        public static Account Income;
        public static Account MoneyTransit;
        public static Account Production;
        public static Account Salary;
        public static Account Seller;
        public static Account SellerPrepaid;
        public static Account UnfinishedConstruction;
        public static Account UnfinishedProduction;

        public Account() { }
        public Account(int id, string code, string description, AccTable accTable)
        {
            Id = id;
            Code = code;
            Description = description;
            AccTable = accTable;
        }
        static Account() { }
        public override string ToString()
        => $"Type={GetType()}, Id={Id}, Code={Code}, Description={Description}, AccTable={AccTable.Description}";
    }


}
