﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.Util;

namespace BN
{
    [Serializable]
    public partial class Slice : HeadClass
    {
        //db field
        public Slice Parent { get; set; }

        //db more\log field

        //not db field

        //static field
        public static SortedDictionary<string, Slice> MainSlice;
        static Slice()
        {
            MainSlice = new SortedDictionary<string, Slice>
            {
                ["Accounting"] = new Slice { Code = "Accounting" },
                ["Fact"] = new Slice { Code = "Fact" },
                ["Norm"] = new Slice { Code = "Norm" },
                ["Plan"] = new Slice { Code = "Plan" },
                ["Report"] = new Slice { Code = "Report" },
            };
        }
        public Slice() { }
    }
    public class ChangeSlice : HeadClass
    {
        //db field
        public Slice Parent { get; set; }

        //db more\log field

        //not db field

        //static field
        public static SortedDictionary<string,Slice> MainChangeSlice;  //TODO - заполнить

        public ChangeSlice() { }
        static ChangeSlice()
        {
            MainChangeSlice = new SortedDictionary<string, Slice>
            {
                ["ToAccounting"] = new Slice { Code = "ToAccounting" },
                ["ToFact"] = new Slice { Code = "ToFact" },
                ["ToPlan"] = new Slice { Code = "ToPlan" },
            };
        }
    }
}
