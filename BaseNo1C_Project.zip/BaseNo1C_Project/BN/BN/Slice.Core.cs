﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.UtilClass;

namespace BN
{
    [Serializable]
    public partial class Slice : HeadClass
    {
        //db field
        public Slice Parent { get; set; }

        //отсортировано  db more\log field

        //отсортировано  not db field

        //отсортировано static field
        public static Slice Accounting;
        public static Slice Fact;
        public static Slice Norm;
        public static Slice Plan;
        public static Slice Report;
        static Slice() { }
        public Slice() { }
    }
    public class ChangeSlice : HeadClass
    {
        //db field
        public Slice Parent { get; set; }

        //отсортировано  db more\log field

        //отсортировано  not db field
        public SortedDictionary<Slice, Slice> ChangePlan;  //TODO - заполнить
                                                           //from acc to fact
                                                           //from acc to plan
                                                           //from fact to acc
                                                           //from plan to acc
                                                           //from plan to fact

        //отсортировано  static field

        public ChangeSlice() { }
        static ChangeSlice() { }
        public ChangeSlice(int id, string code, string description)
        {
            Id = id;
            Code = code;
            Description = description;
        }
        public override string ToString()
        => $"Type={GetType()}, Id={Id}, Code={Code}, Description={Description}";
    }
}
