﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.UtilClass;

namespace BN
{
    [Serializable]
    public partial class HeadClass
    {
        public int Id { get; set; }
        public DateTime Date1 { get; set; }
        public string Date2 { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
        public string More { get; set; }
        public override string ToString()
        => $"Type={GetType()}, Id={Id}, Code={Code}, Description={Description}";

        public void BeforeState(State StateObj)
        {
        }
        public void AfterState(State StateObj)
        {
        }
        public enum State
        {
            List = 1,
            Detail = 2,
            New = 3,
            Edit = 4,
            Console = 5
        }
        public void RuleOnHeadClass(HeadClass checkObj, out HeadClass fixObj)    //проверяем условия для HeadClass
        {
            if (checkObj == null)  //проверяемый объект нулевой
            {
                throw new NotValidDate1Exception($"checkObj {checkObj}=NULL");
            }

            fixObj = checkObj;
            DateTime checkDate = checkObj.Date1;
            string checkCode = checkObj.Code;

            if (checkDate < StartDate)  //дата1 у проверяемого объекта меньше, чем начальная
            {
                //Console.WriteLine($"[checkObj={checkObj}; checkDate={checkDate}]");
                throw new NotValidDate1Exception($"{checkObj}.Date1={checkDate} < RootClass.StartDate={StartDate}");
            }

            if (checkDate > EndDate)  //дата1 у проверяемого объекта больше, чем максимальная
            {
                //Console.WriteLine($"[checkObj={checkObj}; checkDate={checkDate}]");
                throw new NotValidDate1Exception($"{checkObj}.Date1={checkDate} > RootClass.EndDate={EndDate}");
            }
        }
        public HeadClass() : this(default, default, default)
        { }
        public HeadClass(int id, string code, string description)
        {
            Id = id;
            Code = code;
            Description = description; 
            //ObjToConsole(this, "");
        }
    }
}
