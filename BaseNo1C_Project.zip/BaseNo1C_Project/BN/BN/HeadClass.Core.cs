﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.Util;

namespace BN
{
    [Serializable]
    public partial class HeadClass
    {
        //db field
        private int id;
        public int Id 
        { 
            get => id;
            set 
            {
                _ = (id < 0) ? id = 0 : id;
                //if (id < 0)
                //{
                //    id = 0;
                //}
            } 
        }
        private DateTime date1;
        public DateTime Date1
        {
            get => date1;
            set
            {
                _ = (value < StartDate) ? date1 = StartDate : date1 = value;
                _ = (value > EndDate) ? date1 = EndDate : date1 = value;
                //if (value < StartDate)
                //{
                //    date1 = StartDate;
                //}
                //if (value > EndDate)
                //{
                //    date1 = EndDate;
                //}
            }
        }
        public string Date2 { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
        public string More { get; set; }

        //db more\log field
        public string FullDescription;
        public string FullName;
        public string ShortDescription;
        public string ShortName;

        //not db field
        public static readonly DateTime StartDate = new DateTime(2000, 01, 01);  //1 янв 2020 - начало возм действий в программе, стартовая дата, не раньше   
        public static readonly DateTime EndDate = new DateTime(2060, 12, 31);  //31 дек 2060 - конец возм действий в программе, финишная дата, не позже

        //static field

        public override string ToString()
        => $"Type={GetType()}, Id={Id}, Code={Code}, Description={Description}";
        public void RuleOnHeadClass(HeadClass checkObj, out HeadClass fixObj)    //проверяем условия для HeadClass
        {
            if (checkObj == null)  //проверяемый объект нулевой
            {
                throw new NotValidDate1Exception($"checkObj {checkObj}=NULL");
            }

            fixObj = checkObj;
            DateTime checkDate = checkObj.Date1;
            string checkCode = checkObj.Code;

            if (checkDate < StartDate)  //дата1 у проверяемого объекта меньше, чем начальная
            {
                //Console.WriteLine($"[checkObj={checkObj}; checkDate={checkDate}]");
                throw new NotValidDate1Exception($"{checkObj}.Date1={checkDate} < RootClass.StartDate={StartDate}");
            }

            if (checkDate > EndDate)  //дата1 у проверяемого объекта больше, чем максимальная
            {
                //Console.WriteLine($"[checkObj={checkObj}; checkDate={checkDate}]");
                throw new NotValidDate1Exception($"{checkObj}.Date1={checkDate} > RootClass.EndDate={EndDate}");
            }
        }
        public HeadClass() { }
        static HeadClass() { }
        public HeadClass(int id = default,
                         DateTime date1 = default,
                         string date2 = default,
                         string code = default,
                         string description = default,
                         string more = default)
        {
            Id = id;
            Date1 = DateTime.Today;//date1;
            Date2 = date2;
            Code = code;
            Description = description;
            More = more;
        }
        public void MoveState() { }  //TODO - перемещение элемента - заготовка
        public void CopyState() { }  //TODO - копирование элемента - заготовка
        public void DeleteState() { }  //TODO - удаление элемента - заготовка
        public void ClearState() { }  //TODO - очистка элемента - заготовка
    }
}
