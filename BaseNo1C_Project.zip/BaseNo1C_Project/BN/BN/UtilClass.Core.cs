﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BN
{
    [Serializable]
    public partial class UtilClass
    {
        //public static void FixObj(HeadClass checkObj, out HeadClass fixObj)   //исправляем строки объектов, самые распространенные ошибки
        //{                                                  //чтобы не звонили по каждой мелочи 300 раз !!!!
        //    HeadClass fixObj.Code = checkObj.Code.Trim();   //самое первое - удаляем пробелы начальные и конечные   
        //}
        //это нужно для корректной работы с датами, для отбрасывания "нереальных" дат
        public static readonly DateTime StartDate = new DateTime(2000, 01, 01);  //1 янв 2020 - начало возм действий в программе, стартовая дата, не раньше   
        public static readonly DateTime EndDate = new DateTime(2060, 12, 31);  //31 дек 2060 - конец возм действий в программе, финишная дата, не позже
        public static bool IsDev = false;
        public static string LogConsole = default;
        public static void TraceState(object Obj, string ContextObj)
        {
            if (IsDev)
            {
                if (Obj != null)
                {
                    string tempstr = ContextObj +" == "+ Obj.ToString() + Environment.NewLine;
                    LogConsole += tempstr;
                }
            }
        }
        public static string StrListObj<T>(List<T> ListObj)
        {
            string outListObj = default;
            foreach (T obj in ListObj)
            {
                //TODO - сделать сериализацию реквизитов obj
                if (obj != null)
                {
                    outListObj += obj.ToString();  //TODO - сделать добавление разделителя строк
                }
            }
            return outListObj;
        }
        public UtilClass() { }
    }
}

