﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static BN.UtilClass;

namespace BN
{
    class Program
    {
        static void Main(string[] args)
        {
            OnStartApp();

            //TraceState(Slice.Accounting, "Main, Slice.Accounting : ");
            //TraceState(Mark.CD, "Main, MD : ");
            //TraceState(ChangeMark.ToCD, "Main, ToCD : ");
            //TraceState(Geo.Qazaqstan, "Main, Qazaqstan : ");

            #region AcctableAccount
            AccTable AccTable2005 = new AccTable { Id = 0, Code = "AccTable2005", Description = "Account Table 2005" }; ;
            AccTable AccTable2019 = new AccTable { Id = 0, Code = "AccTable2019", Description = "Account Table 2019" };

            AccTable PreviosAccTable = AccTable2005;
            if (PreviosAccTable == AccTable2005)
            {
                AccTable2005.Bank = new Account { Id = 0, Code = "Ac.441", Description = "Деньги на текущих счетах в национальной валюте", AccTable = AccTable2005 };
                TraceState(AccTable2005.Bank, "Main, AccTable2005.Bank");
            }
            AccTable CurrentAccTable = AccTable2019;
            //AccTable FutureAccTable = default;

            if (CurrentAccTable == AccTable2019)  //только для AccTable2019
            {
                //отсортировано
                AccTable2019.Bank = new Account { Id = 0, Code = "Ac.1030", Description = "Денежные средства на текущих банковских счетах", AccTable = AccTable2019 };
                AccTable2019.Cash = new Account { Id = 0, Code = "Ac.1010", Description = "Денежные средства в кассе", AccTable = AccTable2019 };
                AccTable2019.Cost = new Account { Id = 0, Code = "Ac.7010", Description = "Себестоимость реализованной продукции и оказанных услуг", AccTable = AccTable2019 };
                AccTable2019.Customer = new Account { Id = 0, Code = "Ac.1210", Description = "Краткосрочная дебиторская задолженность покупателей и заказчиков", AccTable = AccTable2019 };
                AccTable2019.CustomerPrepaid = new Account { Id = 0, Code = "Ac.3510", Description = "Краткосрочные авансы полученные", AccTable = AccTable2019 };
                AccTable2019.Depreciation = new Account { Id = 0, Code = "Ac.2420", Description = "Амортизация основных средств", AccTable = AccTable2019 };
                AccTable2019.FixedAsset = new Account { Id = 0, Code = "Ac.2410", Description = "Основные средства", AccTable = AccTable2019 };
                AccTable2019.GeneralExpense = new Account { Id = 0, Code = "Ac.7210", Description = "Административные расходы", AccTable = AccTable2019 };
                AccTable2019.Good = new Account { Id = 0, Code = "Ac.1330", Description = "Товары", AccTable = AccTable2019 };
                AccTable2019.Imprest = new Account { Id = 0, Code = "Ac.1250", Description = "Краткосрочная дебиторская задолженность работников", AccTable = AccTable2019 };
                AccTable2019.Material = new Account { Id = 0, Code = "Ac.1310", Description = "Сырье и материалы", AccTable = AccTable2019 };
                AccTable2019.Income = new Account { Id = 0, Code = "Ac.6010", Description = "Доход от реализации продукции и оказания услуг", AccTable = AccTable2019 };
                AccTable2019.MoneyTransit = new Account { Id = 0, Code = "Ac.1020", Description = "Денежные средства в пути", AccTable = AccTable2019 };
                AccTable2019.Production = new Account { Id = 31, Code = "Ac.1320", Description = "Готовая продукция", AccTable = AccTable2019 };
                AccTable2019.Salary = new Account { Id = 0, Code = "Ac.3350", Description = "Краткосрочная задолженность по оплате труда" };
                AccTable2019.Seller = new Account { Id = 0, Code = "Ac.3310", Description = "Краткосрочная кредиторская задолженность поставщикам и подрядчикам", AccTable = AccTable2019 };
                AccTable2019.SellerPrepaid = new Account { Id = 0, Code = "Ac.1710", Description = "Краткосрочные авансы выданные", AccTable = AccTable2019 };
                AccTable2019.UnfinishedConstruction = new Account { Id = 0, Code = "Ac.2930", Description = "Незавершенное строительство", AccTable = AccTable2019 };
                AccTable2019.UnfinishedProduction = new Account { Id = 0, Code = "Ac.1340", Description = "Незавершенное производство", AccTable = AccTable2019 };
            }

            if (CurrentAccTable != null)  //для любого текущего CurrentAccTable  
            {
                //отсортировано
                Account.Bank = CurrentAccTable.Bank;
                Account.Cash = CurrentAccTable.Cash;
                Account.Cost = CurrentAccTable.Cost;
                Account.Customer = CurrentAccTable.Customer;
                Account.CustomerPrepaid = CurrentAccTable.CustomerPrepaid;
                Account.Depreciation = CurrentAccTable.Depreciation;
                Account.FixedAsset = CurrentAccTable.FixedAsset;
                Account.GeneralExpense = CurrentAccTable.GeneralExpense;
                Account.Good = CurrentAccTable.Good;
                Account.Imprest = CurrentAccTable.Imprest;
                Account.Material = CurrentAccTable.Material;
                Account.Income = CurrentAccTable.Income;
                Account.MoneyTransit = CurrentAccTable.MoneyTransit;
                Account.Production = CurrentAccTable.Production;
                Account.Salary = CurrentAccTable.Salary;
                Account.Seller = CurrentAccTable.Seller;
                Account.SellerPrepaid = CurrentAccTable.SellerPrepaid;
                Account.UnfinishedConstruction = CurrentAccTable.UnfinishedConstruction;
                Account.UnfinishedProduction = CurrentAccTable.UnfinishedProduction;
            }

            TraceState(AccTable2019.Bank, "Main, AccTable2019.Bank");
            TraceState(Account.Bank, "Main, Account.Bank"); 
            #endregion

            #region MarkChangeMark
            //отсортировано
            Mark CD = new Mark { Id = 0, Code = "CD", Description = "CurrentData" };
            Mark DD = new Mark { Id = 0, Code = "DD", Description = "DraftData" };
            Mark DelD = new Mark { Id = 0, Code = "DelD", Description = "DeleteData" };
            Mark ExD = new Mark { Id = 0, Code = "ExD", Description = "ExampleData" };
            Mark MD = new Mark { Id = 0, Code = "MD", Description = "MetaData" };
            Mark TemplD = new Mark { Id = 0, Code = "TemplD", Description = "TemplateData" };

            //отсортировано
            ChangeMark ToCD = new ChangeMark { Id = 0, Code = "ToCD", Description = "ToCurrentData" };
            ChangeMark ToDD = new ChangeMark { Id = 0, Code = "ToDD", Description = "ToDraftData" };
            ChangeMark ToDelD = new ChangeMark { Id = 0, Code = "ToDelD", Description = "ToDeleteData" };
            #endregion

            #region SliceChangeSlice
            //отсортировано
            Slice Accounting = new Slice { Id = 0, Code = "Accounting", Description = "учет" };
            Slice Fact = new Slice { Id = 0, Code = "Fact", Description = "факт" };
            Slice Norm = new Slice { Id = 0, Code = "Norm", Description = "норматив" };
            Slice Plan = new Slice { Id = 0, Code = "Plan", Description = "план" };
            Slice Report = new Slice { Id = 0, Code = "Report", Description = "отчет" };

            //отсортировано
            ChangeSlice ToAccounting = new ChangeSlice { Id = 0, Code = "ToAccounting", Description = "ToAccountingData" };
            ChangeSlice ToFact = new ChangeSlice { Id = 0, Code = "ToFact", Description = "ToFactData" };
            ChangeSlice ToPlan = new ChangeSlice { Id = 0, Code = "ToPlan", Description = "ToPlanData" }; 
            #endregion

            ExchangeData.SwiftOPV(null);

            OnExitApp();
        }
        public static void OnStartApp()
        {
            IsDev = true;    ////закомментировать, если это не так  
            TraceState(IsDev, "Main, UtilClass.IsDev");
        }
        public static void OnExitApp()
        {
            if (IsDev)
            {
                Console.WriteLine(LogConsole);
                Console.ReadLine();
            }
        }
    }
}
