﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static BN.UtilClass;

namespace BN
{
    class Program
    {
        static void Main(string[] args)
        {
            OnStartApp();  //// нужно ли ????

            Slice Accounting = new Slice { Id = 1, Code = "Accounting", Description = "учет" };
            ObjToConsole(Accounting, "Main, Accounting : ");
            Slice Fact = new Slice { Id = 5, Code = "Fact", Description = "факт" };
            Slice Norm = new Slice { Id = 7, Code = "Norm", Description = "норматив" };
            Slice Plan = new Slice { Id = 9, Code = "Plan", Description = "план" };
            Slice Report = new Slice { Id = 11, Code = "Report", Description = "отчет" };

            Mark MD = new Mark { Id = 11, Code = "MD", Description = "MetaData" };
            ObjToConsole(MD, "Main, MD : ");
            Mark TemplD = new Mark { Id = 13, Code = "TemplD", Description = "TemplateData" };
            Mark ExD = new Mark { Id = 5, Code = "ExD", Description = "ExampleData" };
            Mark DD = new Mark { Id = 3, Code = "DD", Description = "DraftData" };
            Mark CD = new Mark { Id = 2, Code = "CD", Description = "CurrentData" };
            Mark DelD = new Mark { Id = 4, Code = "DelD", Description = "DeleteData" };

            ChangeMark ToCD = new ChangeMark { Id = 8, Code = "ToCD", Description = "ToCurrentData", ToMark = CD };
            ObjToConsole(ToCD, "Main, ToCD : ");
            ChangeMark ToDD = new ChangeMark { Id = 9, Code = "ToDD", Description = "ToDraftData" };
            ChangeMark ToDelD = new ChangeMark { Id = 10, Code = "ToDelD", Description = "ToDeleteData" };

            Geo Qazaqstan = new Geo { Id = 11, Code = "Geo.Qazaqstan", Description = "РК" };

            //Thread.CurrentContext.GetProperty()

            ExchangeData.SwiftOPV(null);

            OnExitApp();   //// нужно ли ????
        }
        public static void OnStartApp()
        {
            IsDev = true;    ////закомментировать, если это не так  
            ObjToConsole(IsDev, "Main, UtilClass.IsDev : ");
        }
        public static void OnExitApp()
        {
            if (IsDev)
            {
                Console.WriteLine(LogConsole);
                Console.ReadLine();
            }
        }
    }
}
