﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static BN.Util;

namespace BN
{
    class Program
    {
        static void Main(string[] args)
        {
            OnStartApp();

            //TraceState(Slice.MainSlice["Norm"], "Main, Slice.MainSlice[Norm] : ");
            //TraceState(Mark.MainMark["CD"], "Main, Mark.MainMark[CD] : ");
            //TraceState(ChangeMark.MainChangeMark["ToCD"], "Main, ChangeMark.MainChangeMark[ToCD] : ");
            //TraceState(Geo.Qazaqstan, "Main, Qazaqstan : ");

            //AccTable.PreviousAccTable
            AccTable AccTable2005 = new AccTable 
            { 
                Code = "AccTable2005", 
                Description = "Account Table 2005",
                MainAccount = default,
            };
            AccTable.PreviousAccTable = AccTable2005;

            //AccTable.CurrentAccTable
            AccTable AccTable2019 = new AccTable
            {
                Code = "AccTable2019",
                Description = "Account Table 2019",
                Slice = Slice.MainSlice["Norm"],
                MainAccount = default,
            };
            AccTable.CurrentAccTable = AccTable2019;
            TraceState(AccTable2019, "Main, AccTable2019 : ");
            
            AccTable.FutureAccTable = default;

            ExchangeData.SwiftOPV(null);

            OnExitApp();
        }
        public static void OnStartApp()
        {
            IsDev = true;    ////закомментировать, если это не так  
            TraceState(IsDev, "Main, UtilClass.IsDev");
        }
        public static void OnExitApp()
        {
            if (IsDev)
            {
                Console.WriteLine(LogConsole);
                Console.ReadLine();
            }
        }
    }
}
