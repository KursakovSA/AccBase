﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.UtilClass;

namespace BN
{
    [Serializable]
    public partial class Process : HeadClass
    {
        public Process Parent;
        public Face Face1;
        public Face Face2;
        public Slice Slice;
        public Sign Sign;
        public Account Account;
        public Log Log1;
        public Log Log2;
        public Process Process1;
        public Asset Asset;
        public Deal Deal;
        public Item Item;
        public Tax Tax;
        public Price Price;
        public Role Role;
        public Info Info;
        public Meter Meter;
        public string MeterValue;
        public Unit Unit;
    }
}
