﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.Util;

namespace BN
{
    [Serializable]
    public partial class Sign : HeadClass
    {
        public Sign Parent;
        public Role Role;
        public Info Info;
        public Sign() { }
        static Sign() { }
    }
}
