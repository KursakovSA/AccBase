﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.UtilClass;

namespace BN
{
    [Serializable]
    public partial class Asset : HeadClass
    {
        public Asset Parent;
        public Face Face1;
        public Face Face2;
        public Face Face;
        public Slice Slice;
        public Geo Geo;
        public Asset Asset1;
        public Role Role;
        public Info Info;
        public Unit Unit;
        public Mark Mark;
    }
}
