﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.UtilClass;

namespace BN
{
    [Serializable]
    public partial class Asset : HeadClass
    {
        //db field
        public Asset Parent;
        public Face Face1;
        public Face Face2;
        public Face Face;
        public Slice Slice;
        public Geo Geo;
        public Asset Asset1;
        public Role Role;
        public Info Info;
        public Unit Unit;
        public Mark Mark;

        //отсортировано db more\log field

        //отсортировано not db field  

        //отсортировано static field  
        public static Asset FixedAssetGroup1;
        public static Asset FixedAssetGroup2;
        public static Asset FixedAssetGroup3;
        public static Asset FixedAssetGroup4;
        public static Asset Good;
        public static Asset Material;
        public static Asset Money;
        public static Asset Service;
        public static Asset Work;
        public Asset() { }
        static Asset()
        {
            //отсортировано static field   
            FixedAssetGroup1 = new Asset { Id = 0, Code = "FNO100.FixedAsset.Group1", Description = "ФНО100.Группа1.Здания, строения" };
            FixedAssetGroup2 = new Asset { Id = 0, Code = "FNO100.FixedAsset.Group2", Description = "ФНО100.Группа2.Машины, оборудование" };
            FixedAssetGroup3 = new Asset { Id = 0, Code = "FNO100.FixedAsset.Group3", Description = "ФНО100.Группа3.Офисное оборудование" };
            FixedAssetGroup4 = new Asset { Id = 0, Code = "FNO100.FixedAsset.Group4", Description = "ФНО100.Группа3.Прочее" };
            Good = new Asset { Id = 0, Code = "Asset.Template1.Good", Description = "Asset.Template1.Good" };
            Material = new Asset { Id = 0, Code = "Asset.Template2.Material", Description = "Asset.Template2.Material" };
            Money = new Asset { Id = 0, Code = "Asset.Money", Description = "ДС" };
            Service = new Asset { Id = 0, Code = "Asset.Template3.Service", Description = "Asset.Template3.Service" };
            Work = new Asset { Id = 0, Code = "Asset.Template4.Work", Description = "Asset.Template4.Work" };
        }
    }
}
