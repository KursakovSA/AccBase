﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.Util;

namespace BN
{
    [Serializable]
    public partial class Item : HeadClass
    {
        //db field
        public Item Parent;

        //db more\log field

        //not db field
        public Account ItemCostAccount;  //TODO - сделать заполнение
        public Account ItemIncomeAccount;  //TODO - сделать заполнение

        //static field
        public static Item Advance;
        public static Item Bank;
        public static Item Cost;
        public static Item Deduction;
        public static Item Depreciation;
        public static Item Purchase;
        public static Item Salary;
        public static Item Sell;
        public static Item Tax;
        public static Item WriteOff;

        public Item() { }
        static Item()
        {
            Advance = new Item { Code = "Item.Advance", Description = "авансы" };
            Bank = new Item { Code = "Item.Bank", Description = "РКО, услуги банка" };
            Cost = new Item { Code = "Item.Cost", Description = "себестоимость" };
            Deduction = new Item { Code = "Item.Deduction", Description = "удержания из ЗП" };
            Depreciation = new Item { Code = "Item.Depreciation", Description = "амортизация" };
            Purchase = new Item { Code = "Item.Purchase", Description = "приобретение" };
            Salary = new Item { Code = "Item.Salary", Description = "зарплата и отчисления" };
            Sell = new Item { Code = "Item.Sell", Description = "продажа" };
            Tax = new Item { Code = "Item.Tax", Description = "налоги, сборы, отчисления" };
            WriteOff = new Item { Code = "Item.WriteOff", Description = "списание" };
        }
    }
}
