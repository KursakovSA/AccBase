﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.UtilClass;

namespace BN
{
    [Serializable]
    public partial class Item : HeadClass
    {
        //db field
        public Item Parent;

        //отсортировано  db more\log field

        //отсортировано  not db field
        public Account ItemCostAccount;  //TODO - сделать заполнение
        public Account ItemIncomeAccount;  //TODO - сделать заполнение

        //отсортировано  static field
        public static Item Advance;
        public static Item Bank;
        public static Item Cost;
        public static Item Deduction;
        public static Item Depreciation;
        public static Item Purchase;
        public static Item Salary;
        public static Item Sell;
        public static Item Tax;
        public static Item WriteOff;

        public Item() { }
        static Item()
        {
            //отсортировано
            Advance = new Item { Id = 2, Code = "Item.Advance", Description = "авансы" };
            Bank = new Item { Id = 4, Code = "Item.Bank", Description = "РКО, услуги банка" };
            Cost = new Item { Id = 7, Code = "Item.Cost", Description = "себестоимость" };
            Deduction = new Item { Id = 8, Code = "Item.Deduction", Description = "удержания из ЗП" };
            Depreciation = new Item { Id = 9, Code = "Item.Depreciation", Description = "амортизация" };
            Purchase = new Item { Id = 25, Code = "Item.Purchase", Description = "приобретение" };
            Salary = new Item { Id = 28, Code = "Item.Salary", Description = "зарплата и отчисления" };
            Sell = new Item { Id = 30, Code = "Item.Sell", Description = "продажа" };
            Tax = new Item { Id = 33, Code = "Item.Tax", Description = "налоги, сборы, отчисления" };
            WriteOff = new Item { Id = 37, Code = "Item.WriteOff", Description = "списание" };
        }
    }
}
