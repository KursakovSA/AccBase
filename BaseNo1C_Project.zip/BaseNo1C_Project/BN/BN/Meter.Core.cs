﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.UtilClass;

namespace BN
{
    [Serializable]
    public partial class Meter : HeadClass
    {
        public Meter Parent;
        public Unit Unit;
    }
}
