﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.Util;

namespace BN
{
    [Serializable]
    public partial class Meter : HeadClass
    {
        //db field
        public Meter Parent;
        public Unit Unit;

        //db more\log field

        //not db field

        //static field
        public static Meter Amount;
        public static Meter Authentification;
        public static Meter Cost;
        public static Meter Counter;
        public static Meter Depth;
        public static Meter Diameter;
        public static Meter Height;
        public static Meter Lenght;
        public static Meter Price;
        public static Meter Quantity;
        public static Meter Rate;
        public static Meter Time;
        public static Meter Volume;
        public static Meter Weight;
        public static Meter Width;

        public Meter() { }
        static Meter()
        {
            Amount = new Meter { Id = 0, Code = "Amount", Description = "сумма" };
            Authentification = new Meter { Id = 0, Code = "Authentification", Description = "аутентификация" };
            Cost = new Meter { Id = 0, Code = "Cost", Description = "себестоимость" };
            Counter = new Meter { Id = 0, Code = "Counter", Description = "счетчик" };
            Depth = new Meter { Id = 0, Code = "Depth", Description = "толщина" };
            Diameter = new Meter { Id = 0, Code = "Diameter", Description = "диаметр" };
            Height = new Meter { Id = 0, Code = "Height", Description = "высота" };
            Lenght = new Meter { Id = 0, Code = "Lenght", Description = "длина" };
            Price = new Meter { Id = 0, Code = "Price", Description = "цена" };
            Quantity = new Meter { Id = 0, Code = "Quantity", Description = "количество" };
            Rate = new Meter { Id = 0, Code = "Rate", Description = "ставка" };
            Time = new Meter { Id = 0, Code = "Time", Description = "время" };
            Volume = new Meter { Id = 0, Code = "Volume", Description = "объем" };
            Weight = new Meter { Id = 0, Code = "Weight", Description = "вес" };
            Width = new Meter { Id = 0, Code = "Width", Description = "ширина" };
        }
    }
}
