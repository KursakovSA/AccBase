﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.UtilClass;

namespace BN
{
    [Serializable]
    public partial class Log : HeadClass
    {
        public Log Parent;
        public Face Face1;
        public Face Face2;
        public Face Face;
        public Slice Slice;
        public Geo Geo;
        public Sign Sign;
        public Account Account;
        public Log Log1;
        public Process Process1;
        public Tax Tax;
        public Item Item;
        public Deal Deal;
        public Price Price;
        public Asset Asset;
        public Role Role;
        public Info Info;
        public Meter Meter;
        public string MeterValue;
        public Unit Unit;
        public Mark Mark;
        public Log() { }
        static Log()
        {
        }
        public static double Turnover<Log>(List<Log> inLog)
        {
            double outTurnover = default;
            return outTurnover;
        }
    }
}
