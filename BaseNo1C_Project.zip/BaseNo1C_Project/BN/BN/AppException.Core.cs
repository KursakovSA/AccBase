﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.Util;

namespace BN
{
    public class NotValidDate1Exception : ApplicationException
    {
        private string messageDetail = String.Empty;
        public NotValidDate1Exception() { }
        public NotValidDate1Exception(string message)
        {
            messageDetail = message;
        }
        public override string Message => $"NotValidDate1Exception: {messageDetail}";
    }
}
