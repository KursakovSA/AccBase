﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.Util;

namespace BN
{
    [Serializable]
    public partial class Geo : HeadClass
    {
        //db field
        public Geo Parent;
        public Role Role;
        public Unit Unit;

        //db more\log field
        public string AddressPost;

        //not db field

        //static field
        public static Geo Qazaqstan;
        public Geo() { }
        static Geo()
        {
            //отсортировано  
            Qazaqstan = new Geo { Code = "Geo.Qazaqstan", Description = "РК" };
        }
    }
}
