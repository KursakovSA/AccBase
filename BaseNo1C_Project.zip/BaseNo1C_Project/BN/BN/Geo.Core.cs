﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.UtilClass;

namespace BN
{
    [Serializable]
    public partial class Geo : HeadClass
    {
        //db field
        public Geo Parent;
        public Role Role;
        public Unit Unit;

        //отсортировано  db more\log field
        public string AddressPost;

        //отсортировано  not db field

        //отсортировано  static field
        public static Geo Qazaqstan;
        public Geo() { }
        static Geo()
        {
            //отсортировано  
            Qazaqstan = new Geo { Id = 0, Code = "Geo.Qazaqstan", Description = "РК" };
        }
    }
}
