﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.UtilClass;

namespace BN
{
    [Serializable]
    public partial class Geo : HeadClass
    {
        public Geo Parent;
        public Role Role;
        public Unit Unit;
        //public Geo() : this(default, default, default)
        //{ }
        //public Geo(int id, string code, string description)
        //{
        //    Id = id;
        //    Code = code;
        //    Description = description; //Console.WriteLine("ctor - "+this.ToString());
        //}
    }
}
