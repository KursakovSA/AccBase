﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.UtilClass;

namespace BN
{
    [Serializable]
    public partial class Unit : HeadClass
    {
        public Unit Parent;
        public Role Role;
        public Unit Unit1;
        public Unit() { }
        static Unit()
        {
        }
    }
}
