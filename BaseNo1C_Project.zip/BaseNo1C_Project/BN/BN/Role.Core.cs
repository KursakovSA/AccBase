﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.UtilClass;

namespace BN
{
    [Serializable]
    public partial class Role : HeadClass
    {
        public Role Parent;
        public Account Account;
    }
    public partial class ExchangeData : Role
    {
        public static string TargetPath = @"C:\";
        public static Geo Geo = new Geo { Id = 11, Code = "Geo.Qazaqstan", Description = "РК" };
        public string TargetFile;
        public static StringBuilder SwiftOPV(Log LogSalary)
        {
            ExchangeData SwiftOPV = new ExchangeData { Id = 103, Code = "Role.ExchangeData.SwiftOPV", Description = "swift ОПВ" };
            SwiftOPV.TargetFile = @"Swift_OPV.txt";
            //ObjToConsole(SwiftOPV, "SwiftOPV, SwiftOPV : ");
            StringBuilder TextSwiftOPV = default;
            //TODO - выгрузка свифт файла для ОПВ
            return TextSwiftOPV;
        }
    }
}
