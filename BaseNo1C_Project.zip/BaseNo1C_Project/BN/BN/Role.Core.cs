﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.Util;

namespace BN
{
    [Serializable]
    public partial class Role : HeadClass
    {
        ////отсортировано db field
        public Role Parent;
        //public Account Account;

        //db more\log field

        //not db field

        //static field
        public static Role AccTable2019;
        public static Role Account;
        public static Role AccountTax;
        public static Role AccountSalary;
        public static Role AccountProduction;
        public static Role AccountOther;
        public static Role AccountMoney;
        public static Role AccountGroup2Level;
        public static Role AccountGroup1Level;
        public static Role AccountFixedAsset;
        public static Role AccountFace;
        public static Role AccountDepreciation;
        public static Role AccountCapital;
        public static Role AccountBudget;
        public static Role AccountAsset;
        public Role() { }
        static Role()
        {
            Account = new Role { Code = "Role.Account", Description = "Account" };
            AccTable2019 = new Role { Code = "Role.AccTable.2019", Description = "типовой план счетов 2019" };
            AccountTax = new Role { Code = "Role.Account.Tax", Description = "счет налогов и платежей" };
            AccountSalary = new Role { Code = "Role.Account.Salary", Description = "счет зарплаты" };
            AccountProduction = new Role { Code = "Role.Account.Production", Description = "счет производства" };
            AccountOther = new Role { Code = "Role.Account.Other", Description = "счет прочий" };
            AccountMoney = new Role { Code = "Role.Account.Money", Description = "счет денег" };
            AccountGroup2Level = new Role { Code = "Role.Account.Group2Level", Description = "группа счетов 2 уровня" };
            AccountGroup1Level = new Role { Code = "Role.Account.Group1Level", Description = "группа счетов 1 уровня" };
            AccountFixedAsset = new Role { Code = "Role.Account.FixedAsset", Description = "счет основных средств" };
            AccountFace = new Role { Code = "Role.Account.Face", Description = "счет лиц" };
            AccountDepreciation = new Role { Code = "Role.Account.Depreciation", Description = "счет амортизации" };
            AccountCapital = new Role { Code = "Role.Account.Capital", Description = "счет капитала" };
            AccountBudget = new Role { Code = "Role.Account.Budget", Description = "счет бюджета" };
            AccountAsset = new Role { Code = "Role.Account.Asset", Description = "счет активов" };
        }
    }
    [Serializable]
    public partial class ExchangeData : HeadClass
    {
        public static string TargetPath;
        public static Geo Geo;
        public string TargetFile;
        public ExchangeData() { }
        static ExchangeData()
        {
            TargetPath = @"C:\";
            Geo Geo = new Geo { Id = 0, Code = "Geo.Qazaqstan", Description = "РК" };
        }
        public static StringBuilder SwiftOPV(Log LogSalary)
        {
            ExchangeData SwiftOPV = new ExchangeData { Id = 0, Code = "Role.ExchangeData.SwiftOPV", Description = "swift ОПВ" };
            SwiftOPV.TargetFile = @"Swift_OPV.txt";
            //ObjToConsole(SwiftOPV, "SwiftOPV, SwiftOPV : ");
            StringBuilder TextSwiftOPV = default;
            //TODO - выгрузка свифт файла для ОПВ
            return TextSwiftOPV;
        }
    }
}
