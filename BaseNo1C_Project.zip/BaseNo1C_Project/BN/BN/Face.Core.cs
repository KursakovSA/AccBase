﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.UtilClass;

namespace BN
{
    [Serializable]
    public partial class Face : HeadClass
    {
        //db field
        public Face Parent;
        public Face Face1;
        public Face Face2;
        public Slice Slice;
        public Geo Geo;
        public Role Role;
        public Info Info;
        public Mark Mark;

        //отсортировано  db more\log field
        public string AddressHome;
        public string AddressLaw;
        public string AddressPost;
        public string AddressReg;

        //отсортировано  not db field

        //отсортировано  static field

        public Face() { }
        static Face()
        {
        }
    }
}
