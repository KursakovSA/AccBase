﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.Util;

namespace BN
{
    [Serializable]
    public partial class Price : HeadClass
    {
        public Price Parent;
        public Face Face1;
        public Face Face2;
        public Face Face;
        public Slice Slice;
        public Geo Geo;
        public Role Role;
        public Info Info;
        public Unit Unit;
        public Mark Mark;
        public Price() { }
        static Price()
        {
        }
    }
    public partial class Markup : HeadClass
    {
        public Price Parent;
        public Face Face1;
        public Face Face2;
        public Face Face;
        public Slice Slice;
        public Geo Geo;
        public Role Role;
        public Info Info;
        public Unit Unit;
        public Mark Mark;
        public Markup() { }
        static Markup()
        {
        }
    }
    public partial class Sale : HeadClass
    {
        public Price Parent;
        public Face Face1;
        public Face Face2;
        public Face Face;
        public Slice Slice;
        public Geo Geo;
        public Role Role;
        public Info Info;
        public Unit Unit;
        public Mark Mark;
        public Sale() { }
        static Sale()
        {
        }
    }
}
