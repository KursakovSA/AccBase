﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BN.Util;

namespace BN
{
    [Serializable]
    public partial class Info : HeadClass
    {
        public Info Parent;
        public Info() { }
        static Info()
        {
        }
    }
}
