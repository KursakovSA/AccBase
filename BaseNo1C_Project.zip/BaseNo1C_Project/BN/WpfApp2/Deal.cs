namespace WpfApp2
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Deal")]
    public partial class Deal
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Deal()
        {
            Deal1 = new HashSet<Deal>();
            Logs = new HashSet<Log>();
            Processes = new HashSet<Process>();
        }

        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }

        public int? Parent { get; set; }

        public int? Face1 { get; set; }

        public int? Face2 { get; set; }

        public int? Face { get; set; }

        public int? Slice { get; set; }

        [Column(TypeName = "smalldatetime")]
        public DateTime? Date1 { get; set; }

        [StringLength(100)]
        public string Date2 { get; set; }

        [StringLength(100)]
        public string Code { get; set; }

        [StringLength(255)]
        public string Description { get; set; }

        public int? Geo { get; set; }

        public int? Role { get; set; }

        public int? Info { get; set; }

        public string More { get; set; }

        public int? Mark { get; set; }

        public virtual Face Face3 { get; set; }

        public virtual Face Face4 { get; set; }

        public virtual Face Face5 { get; set; }

        public virtual Geo Geo1 { get; set; }

        public virtual Info Info1 { get; set; }

        public virtual Mark Mark1 { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Deal> Deal1 { get; set; }

        public virtual Deal Deal2 { get; set; }

        public virtual Role Role1 { get; set; }

        public virtual Slouse Slouse { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Log> Logs { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Process> Processes { get; set; }
    }
}
