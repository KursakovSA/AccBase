using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace WpfApp2
{
    public partial class Model1 : DbContext
    {
        public Model1()
            : base("name=Model1")
        {
        }

        public virtual DbSet<Account> Accounts { get; set; }
        public virtual DbSet<Asset> Assets { get; set; }
        public virtual DbSet<Deal> Deals { get; set; }
        public virtual DbSet<Face> Faces { get; set; }
        public virtual DbSet<Geo> Geos { get; set; }
        public virtual DbSet<Info> Infoes { get; set; }
        public virtual DbSet<Item> Items { get; set; }
        public virtual DbSet<Log> Logs { get; set; }
        public virtual DbSet<Mark> Marks { get; set; }
        public virtual DbSet<Meter> Meters { get; set; }
        public virtual DbSet<Price> Prices { get; set; }
        public virtual DbSet<Process> Processes { get; set; }
        public virtual DbSet<Report> Reports { get; set; }
        public virtual DbSet<Role> Roles { get; set; }
        public virtual DbSet<Sign> Signs { get; set; }
        public virtual DbSet<Slouse> Slice { get; set; }
        public virtual DbSet<Tax> Taxes { get; set; }
        public virtual DbSet<Unit> Units { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Account>()
                .HasMany(e => e.Account1)
                .WithOptional(e => e.Account2)
                .HasForeignKey(e => e.Parent);

            modelBuilder.Entity<Account>()
                .HasMany(e => e.Logs)
                .WithOptional(e => e.Account1)
                .HasForeignKey(e => e.Account);

            modelBuilder.Entity<Account>()
                .HasMany(e => e.Processes)
                .WithOptional(e => e.Account1)
                .HasForeignKey(e => e.Account);

            modelBuilder.Entity<Account>()
                .HasMany(e => e.Roles)
                .WithOptional(e => e.Account1)
                .HasForeignKey(e => e.Account);

            modelBuilder.Entity<Account>()
                .HasMany(e => e.Taxes)
                .WithOptional(e => e.Account1)
                .HasForeignKey(e => e.Account);

            modelBuilder.Entity<Asset>()
                .HasMany(e => e.Asset11)
                .WithOptional(e => e.Asset2)
                .HasForeignKey(e => e.Asset1);

            modelBuilder.Entity<Asset>()
                .HasMany(e => e.Asset12)
                .WithOptional(e => e.Asset3)
                .HasForeignKey(e => e.Parent);

            modelBuilder.Entity<Asset>()
                .HasMany(e => e.Logs)
                .WithOptional(e => e.Asset1)
                .HasForeignKey(e => e.Asset);

            modelBuilder.Entity<Asset>()
                .HasMany(e => e.Processes)
                .WithOptional(e => e.Asset1)
                .HasForeignKey(e => e.Asset);

            modelBuilder.Entity<Deal>()
                .HasMany(e => e.Deal1)
                .WithOptional(e => e.Deal2)
                .HasForeignKey(e => e.Parent);

            modelBuilder.Entity<Deal>()
                .HasMany(e => e.Logs)
                .WithOptional(e => e.Deal1)
                .HasForeignKey(e => e.Deal);

            modelBuilder.Entity<Deal>()
                .HasMany(e => e.Processes)
                .WithOptional(e => e.Deal1)
                .HasForeignKey(e => e.Deal);

            modelBuilder.Entity<Face>()
                .HasMany(e => e.Assets)
                .WithOptional(e => e.Face3)
                .HasForeignKey(e => e.Face);

            modelBuilder.Entity<Face>()
                .HasMany(e => e.Assets1)
                .WithOptional(e => e.Face4)
                .HasForeignKey(e => e.Face1);

            modelBuilder.Entity<Face>()
                .HasMany(e => e.Assets2)
                .WithOptional(e => e.Face5)
                .HasForeignKey(e => e.Face2);

            modelBuilder.Entity<Face>()
                .HasMany(e => e.Deals)
                .WithOptional(e => e.Face3)
                .HasForeignKey(e => e.Face);

            modelBuilder.Entity<Face>()
                .HasMany(e => e.Deals1)
                .WithOptional(e => e.Face4)
                .HasForeignKey(e => e.Face1);

            modelBuilder.Entity<Face>()
                .HasMany(e => e.Deals2)
                .WithOptional(e => e.Face5)
                .HasForeignKey(e => e.Face2);

            modelBuilder.Entity<Face>()
                .HasMany(e => e.Face11)
                .WithOptional(e => e.Face3)
                .HasForeignKey(e => e.Face1);

            modelBuilder.Entity<Face>()
                .HasMany(e => e.Face12)
                .WithOptional(e => e.Face4)
                .HasForeignKey(e => e.Face2);

            modelBuilder.Entity<Face>()
                .HasMany(e => e.Face13)
                .WithOptional(e => e.Face5)
                .HasForeignKey(e => e.Parent);

            modelBuilder.Entity<Face>()
                .HasMany(e => e.Logs)
                .WithOptional(e => e.Face3)
                .HasForeignKey(e => e.Face);

            modelBuilder.Entity<Face>()
                .HasMany(e => e.Logs1)
                .WithOptional(e => e.Face4)
                .HasForeignKey(e => e.Face1);

            modelBuilder.Entity<Face>()
                .HasMany(e => e.Logs2)
                .WithOptional(e => e.Face5)
                .HasForeignKey(e => e.Face2);

            modelBuilder.Entity<Face>()
                .HasMany(e => e.Prices)
                .WithOptional(e => e.Face3)
                .HasForeignKey(e => e.Face);

            modelBuilder.Entity<Face>()
                .HasMany(e => e.Prices1)
                .WithOptional(e => e.Face4)
                .HasForeignKey(e => e.Face1);

            modelBuilder.Entity<Face>()
                .HasMany(e => e.Prices2)
                .WithOptional(e => e.Face5)
                .HasForeignKey(e => e.Face2);

            modelBuilder.Entity<Face>()
                .HasMany(e => e.Processes)
                .WithOptional(e => e.Face3)
                .HasForeignKey(e => e.Face);

            modelBuilder.Entity<Face>()
                .HasMany(e => e.Processes1)
                .WithOptional(e => e.Face4)
                .HasForeignKey(e => e.Face1);

            modelBuilder.Entity<Face>()
                .HasMany(e => e.Processes2)
                .WithOptional(e => e.Face5)
                .HasForeignKey(e => e.Face2);

            modelBuilder.Entity<Face>()
                .HasMany(e => e.Taxes)
                .WithOptional(e => e.Face)
                .HasForeignKey(e => e.Face1);

            modelBuilder.Entity<Face>()
                .HasMany(e => e.Taxes1)
                .WithOptional(e => e.Face3)
                .HasForeignKey(e => e.Face2);

            modelBuilder.Entity<Geo>()
                .HasMany(e => e.Assets)
                .WithOptional(e => e.Geo1)
                .HasForeignKey(e => e.Geo);

            modelBuilder.Entity<Geo>()
                .HasMany(e => e.Deals)
                .WithOptional(e => e.Geo1)
                .HasForeignKey(e => e.Geo);

            modelBuilder.Entity<Geo>()
                .HasMany(e => e.Faces)
                .WithOptional(e => e.Geo1)
                .HasForeignKey(e => e.Geo);

            modelBuilder.Entity<Geo>()
                .HasMany(e => e.Geo1)
                .WithOptional(e => e.Geo2)
                .HasForeignKey(e => e.Parent);

            modelBuilder.Entity<Geo>()
                .HasMany(e => e.Logs)
                .WithOptional(e => e.Geo1)
                .HasForeignKey(e => e.Geo);

            modelBuilder.Entity<Geo>()
                .HasMany(e => e.Taxes)
                .WithOptional(e => e.Geo1)
                .HasForeignKey(e => e.Geo);

            modelBuilder.Entity<Info>()
                .HasMany(e => e.Assets)
                .WithOptional(e => e.Info1)
                .HasForeignKey(e => e.Info);

            modelBuilder.Entity<Info>()
                .HasMany(e => e.Deals)
                .WithOptional(e => e.Info1)
                .HasForeignKey(e => e.Info);

            modelBuilder.Entity<Info>()
                .HasMany(e => e.Faces)
                .WithOptional(e => e.Info1)
                .HasForeignKey(e => e.Info);

            modelBuilder.Entity<Info>()
                .HasMany(e => e.Info1)
                .WithOptional(e => e.Info2)
                .HasForeignKey(e => e.Parent);

            modelBuilder.Entity<Info>()
                .HasMany(e => e.Logs)
                .WithOptional(e => e.Info1)
                .HasForeignKey(e => e.Info);

            modelBuilder.Entity<Info>()
                .HasMany(e => e.Prices)
                .WithOptional(e => e.Info1)
                .HasForeignKey(e => e.Info);

            modelBuilder.Entity<Info>()
                .HasMany(e => e.Processes)
                .WithOptional(e => e.Info1)
                .HasForeignKey(e => e.Info);

            modelBuilder.Entity<Info>()
                .HasMany(e => e.Reports)
                .WithOptional(e => e.Info1)
                .HasForeignKey(e => e.Info);

            modelBuilder.Entity<Info>()
                .HasMany(e => e.Signs)
                .WithOptional(e => e.Info1)
                .HasForeignKey(e => e.Info);

            modelBuilder.Entity<Info>()
                .HasMany(e => e.Taxes)
                .WithOptional(e => e.Info1)
                .HasForeignKey(e => e.Info);

            modelBuilder.Entity<Item>()
                .HasMany(e => e.Item1)
                .WithOptional(e => e.Item2)
                .HasForeignKey(e => e.Parent);

            modelBuilder.Entity<Item>()
                .HasMany(e => e.Logs)
                .WithOptional(e => e.Item1)
                .HasForeignKey(e => e.Item);

            modelBuilder.Entity<Item>()
                .HasMany(e => e.Processes)
                .WithOptional(e => e.Item1)
                .HasForeignKey(e => e.Item);

            modelBuilder.Entity<Log>()
                .Property(e => e.More)
                .IsUnicode(false);

            modelBuilder.Entity<Log>()
                .HasMany(e => e.Log11)
                .WithOptional(e => e.Log2)
                .HasForeignKey(e => e.Log1);

            modelBuilder.Entity<Log>()
                .HasMany(e => e.Log12)
                .WithOptional(e => e.Log3)
                .HasForeignKey(e => e.Parent);

            modelBuilder.Entity<Log>()
                .HasMany(e => e.Processes)
                .WithOptional(e => e.Log)
                .HasForeignKey(e => e.Log1);

            modelBuilder.Entity<Log>()
                .HasMany(e => e.Processes1)
                .WithOptional(e => e.Log3)
                .HasForeignKey(e => e.Log2);

            modelBuilder.Entity<Mark>()
                .HasMany(e => e.Assets)
                .WithOptional(e => e.Mark1)
                .HasForeignKey(e => e.Mark);

            modelBuilder.Entity<Mark>()
                .HasMany(e => e.Deals)
                .WithOptional(e => e.Mark1)
                .HasForeignKey(e => e.Mark);

            modelBuilder.Entity<Mark>()
                .HasMany(e => e.Faces)
                .WithOptional(e => e.Mark1)
                .HasForeignKey(e => e.Mark);

            modelBuilder.Entity<Mark>()
                .HasMany(e => e.Logs)
                .WithOptional(e => e.Mark1)
                .HasForeignKey(e => e.Mark);

            modelBuilder.Entity<Mark>()
                .HasMany(e => e.Mark1)
                .WithOptional(e => e.Mark2)
                .HasForeignKey(e => e.Parent);

            modelBuilder.Entity<Mark>()
                .HasMany(e => e.Prices)
                .WithOptional(e => e.Mark1)
                .HasForeignKey(e => e.Mark);

            modelBuilder.Entity<Meter>()
                .HasMany(e => e.Logs)
                .WithOptional(e => e.Meter1)
                .HasForeignKey(e => e.Meter);

            modelBuilder.Entity<Meter>()
                .HasMany(e => e.Meter1)
                .WithOptional(e => e.Meter2)
                .HasForeignKey(e => e.Parent);

            modelBuilder.Entity<Meter>()
                .HasMany(e => e.Processes)
                .WithOptional(e => e.Meter1)
                .HasForeignKey(e => e.Meter);

            modelBuilder.Entity<Price>()
                .HasMany(e => e.Logs)
                .WithOptional(e => e.Price1)
                .HasForeignKey(e => e.Price);

            modelBuilder.Entity<Price>()
                .HasMany(e => e.Price1)
                .WithOptional(e => e.Price2)
                .HasForeignKey(e => e.Parent);

            modelBuilder.Entity<Price>()
                .HasMany(e => e.Processes)
                .WithOptional(e => e.Price1)
                .HasForeignKey(e => e.Price);

            modelBuilder.Entity<Process>()
                .HasMany(e => e.Logs)
                .WithOptional(e => e.Process)
                .HasForeignKey(e => e.Process1);

            modelBuilder.Entity<Process>()
                .HasMany(e => e.Process11)
                .WithOptional(e => e.Process2)
                .HasForeignKey(e => e.Parent);

            modelBuilder.Entity<Process>()
                .HasMany(e => e.Process12)
                .WithOptional(e => e.Process3)
                .HasForeignKey(e => e.Process1);

            modelBuilder.Entity<Report>()
                .HasMany(e => e.Report1)
                .WithOptional(e => e.Report2)
                .HasForeignKey(e => e.Parent);

            modelBuilder.Entity<Role>()
                .HasMany(e => e.Accounts)
                .WithOptional(e => e.Role1)
                .HasForeignKey(e => e.Role);

            modelBuilder.Entity<Role>()
                .HasMany(e => e.Assets)
                .WithOptional(e => e.Role1)
                .HasForeignKey(e => e.Role);

            modelBuilder.Entity<Role>()
                .HasMany(e => e.Deals)
                .WithOptional(e => e.Role1)
                .HasForeignKey(e => e.Role);

            modelBuilder.Entity<Role>()
                .HasMany(e => e.Faces)
                .WithOptional(e => e.Role1)
                .HasForeignKey(e => e.Role);

            modelBuilder.Entity<Role>()
                .HasMany(e => e.Geos)
                .WithOptional(e => e.Role1)
                .HasForeignKey(e => e.Role);

            modelBuilder.Entity<Role>()
                .HasMany(e => e.Logs)
                .WithOptional(e => e.Role1)
                .HasForeignKey(e => e.Role);

            modelBuilder.Entity<Role>()
                .HasMany(e => e.Marks)
                .WithOptional(e => e.Role1)
                .HasForeignKey(e => e.Role);

            modelBuilder.Entity<Role>()
                .HasMany(e => e.Prices)
                .WithOptional(e => e.Role1)
                .HasForeignKey(e => e.Role);

            modelBuilder.Entity<Role>()
                .HasMany(e => e.Processes)
                .WithOptional(e => e.Role1)
                .HasForeignKey(e => e.Role);

            modelBuilder.Entity<Role>()
                .HasMany(e => e.Reports)
                .WithOptional(e => e.Role1)
                .HasForeignKey(e => e.Role);

            modelBuilder.Entity<Role>()
                .HasMany(e => e.Role1)
                .WithOptional(e => e.Role2)
                .HasForeignKey(e => e.Parent);

            modelBuilder.Entity<Role>()
                .HasMany(e => e.Signs)
                .WithOptional(e => e.Role1)
                .HasForeignKey(e => e.Role);

            modelBuilder.Entity<Role>()
                .HasMany(e => e.Taxes)
                .WithOptional(e => e.Role1)
                .HasForeignKey(e => e.Role);

            modelBuilder.Entity<Role>()
                .HasMany(e => e.Units)
                .WithOptional(e => e.Role1)
                .HasForeignKey(e => e.Role);

            modelBuilder.Entity<Sign>()
                .HasMany(e => e.Accounts)
                .WithOptional(e => e.Sign1)
                .HasForeignKey(e => e.Sign);

            modelBuilder.Entity<Sign>()
                .HasMany(e => e.Logs)
                .WithOptional(e => e.Sign1)
                .HasForeignKey(e => e.Sign);

            modelBuilder.Entity<Sign>()
                .HasMany(e => e.Processes)
                .WithOptional(e => e.Sign1)
                .HasForeignKey(e => e.Sign);

            modelBuilder.Entity<Sign>()
                .HasMany(e => e.Sign1)
                .WithOptional(e => e.Sign2)
                .HasForeignKey(e => e.Parent);

            modelBuilder.Entity<Slouse>()
                .HasMany(e => e.Accounts)
                .WithOptional(e => e.Slouse)
                .HasForeignKey(e => e.Slice);

            modelBuilder.Entity<Slouse>()
                .HasMany(e => e.Assets)
                .WithOptional(e => e.Slouse)
                .HasForeignKey(e => e.Slice);

            modelBuilder.Entity<Slouse>()
                .HasMany(e => e.Deals)
                .WithOptional(e => e.Slouse)
                .HasForeignKey(e => e.Slice);

            modelBuilder.Entity<Slouse>()
                .HasMany(e => e.Faces)
                .WithOptional(e => e.Slouse)
                .HasForeignKey(e => e.Slice);

            modelBuilder.Entity<Slouse>()
                .HasMany(e => e.Logs)
                .WithOptional(e => e.Slouse)
                .HasForeignKey(e => e.Slice);

            modelBuilder.Entity<Slouse>()
                .HasMany(e => e.Prices)
                .WithOptional(e => e.Slouse)
                .HasForeignKey(e => e.Slice);

            modelBuilder.Entity<Slouse>()
                .HasMany(e => e.Processes)
                .WithOptional(e => e.Slouse)
                .HasForeignKey(e => e.Slice);

            modelBuilder.Entity<Slouse>()
                .HasMany(e => e.Slice1)
                .WithOptional(e => e.Slouse1)
                .HasForeignKey(e => e.Parent);

            modelBuilder.Entity<Tax>()
                .HasMany(e => e.Logs)
                .WithOptional(e => e.Tax1)
                .HasForeignKey(e => e.Tax);

            modelBuilder.Entity<Tax>()
                .HasMany(e => e.Processes)
                .WithOptional(e => e.Tax1)
                .HasForeignKey(e => e.Tax);

            modelBuilder.Entity<Tax>()
                .HasMany(e => e.Tax1)
                .WithOptional(e => e.Tax2)
                .HasForeignKey(e => e.Parent);

            modelBuilder.Entity<Unit>()
                .HasMany(e => e.Assets)
                .WithOptional(e => e.Unit1)
                .HasForeignKey(e => e.Unit);

            modelBuilder.Entity<Unit>()
                .HasMany(e => e.Geos)
                .WithOptional(e => e.Unit1)
                .HasForeignKey(e => e.Unit);

            modelBuilder.Entity<Unit>()
                .HasMany(e => e.Logs)
                .WithOptional(e => e.Unit1)
                .HasForeignKey(e => e.Unit);

            modelBuilder.Entity<Unit>()
                .HasMany(e => e.Meters)
                .WithOptional(e => e.Unit1)
                .HasForeignKey(e => e.Unit);

            modelBuilder.Entity<Unit>()
                .HasMany(e => e.Prices)
                .WithOptional(e => e.Unit1)
                .HasForeignKey(e => e.Unit);

            modelBuilder.Entity<Unit>()
                .HasMany(e => e.Processes)
                .WithOptional(e => e.Unit1)
                .HasForeignKey(e => e.Unit);

            modelBuilder.Entity<Unit>()
                .HasMany(e => e.Unit11)
                .WithOptional(e => e.Unit2)
                .HasForeignKey(e => e.Parent);

            modelBuilder.Entity<Unit>()
                .HasMany(e => e.Unit12)
                .WithOptional(e => e.Unit3)
                .HasForeignKey(e => e.Unit1);
        }
    }
}
