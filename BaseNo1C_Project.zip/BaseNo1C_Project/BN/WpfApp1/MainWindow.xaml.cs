﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            WpfApp1.BaseN1DataSet baseN1DataSet = ((WpfApp1.BaseN1DataSet)(this.FindResource("baseN1DataSet")));
            // Загрузить данные в таблицу Face. Можно изменить этот код как требуется.
            WpfApp1.BaseN1DataSetTableAdapters.FaceTableAdapter baseN1DataSetFaceTableAdapter = new WpfApp1.BaseN1DataSetTableAdapters.FaceTableAdapter();
            baseN1DataSetFaceTableAdapter.Fill(baseN1DataSet.Face);
            System.Windows.Data.CollectionViewSource faceViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("faceViewSource")));
            faceViewSource.View.MoveCurrentToFirst();
        }
    }
}
