use AccBase0;

DECLARE mycursor CURSOR for
select id,code from log;