--�������� �.�. https://github.com/KursakovSA/AccBase 
ALTER TABLE [dbo].[Account]  WITH CHECK ADD  CONSTRAINT [AccountParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Account] ([Id])
GO
ALTER TABLE [dbo].[Account] CHECK CONSTRAINT [AccountParent_FK]
GO
ALTER TABLE [dbo].[Account]  WITH CHECK ADD  CONSTRAINT [AccountAccount1_FK] FOREIGN KEY([Account1])
REFERENCES [dbo].[Account] ([Id])
GO
ALTER TABLE [dbo].[Account] CHECK CONSTRAINT [AccountAccount1_FK]
GO
ALTER TABLE [dbo].[Account]  WITH CHECK ADD  CONSTRAINT [AccountRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id])
GO
ALTER TABLE [dbo].[Account] CHECK CONSTRAINT [AccountRole_FK]
GO
ALTER TABLE [dbo].[Account]  WITH CHECK ADD  CONSTRAINT [AccountSign_FK] FOREIGN KEY([Sign])
REFERENCES [dbo].[Sign] ([Id])
GO
ALTER TABLE [dbo].[Account] CHECK CONSTRAINT [AccountSign_FK]
GO
ALTER TABLE [dbo].[Account]  WITH CHECK ADD  CONSTRAINT [AccountSlice_FK] FOREIGN KEY([Slice])
REFERENCES [dbo].[Slice] ([Id])
GO
ALTER TABLE [dbo].[Account] CHECK CONSTRAINT [AccountSlice_FK]
GO


ALTER TABLE [dbo].[Asset]  WITH CHECK ADD  CONSTRAINT [AssetAsset1_FK] FOREIGN KEY([Asset1])
REFERENCES [dbo].[Asset] ([Id])
GO
ALTER TABLE [dbo].[Asset] CHECK CONSTRAINT [AssetAsset1_FK]
GO
ALTER TABLE [dbo].[Asset]  WITH CHECK ADD  CONSTRAINT [AssetFace_FK] FOREIGN KEY([Face])
REFERENCES [dbo].[Face] ([Id])
GO
ALTER TABLE [dbo].[Asset] CHECK CONSTRAINT [AssetFace_FK]
GO
ALTER TABLE [dbo].[Asset]  WITH CHECK ADD  CONSTRAINT [AssetFace1_FK] FOREIGN KEY([Face1])
REFERENCES [dbo].[Face] ([Id])
GO
ALTER TABLE [dbo].[Asset] CHECK CONSTRAINT [AssetFace1_FK]
GO
ALTER TABLE [dbo].[Asset]  WITH CHECK ADD  CONSTRAINT [AssetFace2_FK] FOREIGN KEY([Face2])
REFERENCES [dbo].[Face] ([Id])
GO
ALTER TABLE [dbo].[Asset] CHECK CONSTRAINT [AssetFace2_FK]
GO
ALTER TABLE [dbo].[Asset]  WITH CHECK ADD  CONSTRAINT [AssetGeo_FK] FOREIGN KEY([Geo])
REFERENCES [dbo].[Geo] ([Id])
GO
ALTER TABLE [dbo].[Asset] CHECK CONSTRAINT [AssetGeo_FK]
GO
ALTER TABLE [dbo].[Asset]  WITH CHECK ADD  CONSTRAINT [AssetInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id])
GO
ALTER TABLE [dbo].[Asset] CHECK CONSTRAINT [AssetInfo_FK]
GO
ALTER TABLE [dbo].[Asset]  WITH CHECK ADD  CONSTRAINT [AssetParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Asset] ([Id])
GO
ALTER TABLE [dbo].[Asset] CHECK CONSTRAINT [AssetParent_FK]
GO
ALTER TABLE [dbo].[Asset]  WITH CHECK ADD  CONSTRAINT [AssetRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id])
GO
ALTER TABLE [dbo].[Asset] CHECK CONSTRAINT [AssetRole_FK]
GO
ALTER TABLE [dbo].[Asset]  WITH CHECK ADD  CONSTRAINT [AssetUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id])
GO
ALTER TABLE [dbo].[Asset] CHECK CONSTRAINT [AssetUnit_FK]
GO


ALTER TABLE [dbo].[Deal]  WITH CHECK ADD  CONSTRAINT [DealFace_FK] FOREIGN KEY([Face])
REFERENCES [dbo].[Face] ([Id])
GO
ALTER TABLE [dbo].[Deal] CHECK CONSTRAINT [DealFace_FK]
GO
ALTER TABLE [dbo].[Deal]  WITH CHECK ADD  CONSTRAINT [DealFace1_FK] FOREIGN KEY([Face1])
REFERENCES [dbo].[Face] ([Id])
GO
ALTER TABLE [dbo].[Deal] CHECK CONSTRAINT [DealFace1_FK]
GO
ALTER TABLE [dbo].[Deal]  WITH CHECK ADD  CONSTRAINT [DealFace2_FK] FOREIGN KEY([Face2])
REFERENCES [dbo].[Face] ([Id])
GO
ALTER TABLE [dbo].[Deal] CHECK CONSTRAINT [DealFace2_FK]
GO
ALTER TABLE [dbo].[Deal]  WITH CHECK ADD  CONSTRAINT [DealGeo_FK] FOREIGN KEY([Geo])
REFERENCES [dbo].[Geo] ([Id])
GO
ALTER TABLE [dbo].[Deal] CHECK CONSTRAINT [DealGeo_FK]
GO
ALTER TABLE [dbo].[Deal]  WITH CHECK ADD  CONSTRAINT [DealInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id])
GO
ALTER TABLE [dbo].[Deal] CHECK CONSTRAINT [DealInfo_FK]
GO
ALTER TABLE [dbo].[Deal]  WITH CHECK ADD  CONSTRAINT [DealParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Deal] ([Id])
GO
ALTER TABLE [dbo].[Deal] CHECK CONSTRAINT [DealParent_FK]
GO
ALTER TABLE [dbo].[Deal]  WITH CHECK ADD  CONSTRAINT [DealRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id])
GO
ALTER TABLE [dbo].[Deal] CHECK CONSTRAINT [DealRole_FK]
GO


ALTER TABLE [dbo].[Face]  WITH CHECK ADD  CONSTRAINT [FaceFace1_FK] FOREIGN KEY([Face1])
REFERENCES [dbo].[Face] ([Id])
GO
ALTER TABLE [dbo].[Face] CHECK CONSTRAINT [FaceFace1_FK]
GO
ALTER TABLE [dbo].[Face]  WITH CHECK ADD  CONSTRAINT [FaceFace2_FK] FOREIGN KEY([Face2])
REFERENCES [dbo].[Face] ([Id])
GO
ALTER TABLE [dbo].[Face] CHECK CONSTRAINT [FaceFace2_FK]
GO
ALTER TABLE [dbo].[Face]  WITH CHECK ADD  CONSTRAINT [FaceGeo_FK] FOREIGN KEY([Geo])
REFERENCES [dbo].[Geo] ([Id])
GO
ALTER TABLE [dbo].[Face] CHECK CONSTRAINT [FaceGeo_FK]
GO
ALTER TABLE [dbo].[Face]  WITH CHECK ADD  CONSTRAINT [FaceInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id])
GO
ALTER TABLE [dbo].[Face] CHECK CONSTRAINT [FaceInfo_FK]
GO
ALTER TABLE [dbo].[Face]  WITH CHECK ADD  CONSTRAINT [FaceParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Face] ([Id])
GO
ALTER TABLE [dbo].[Face] CHECK CONSTRAINT [FaceParent_FK]
GO
ALTER TABLE [dbo].[Face]  WITH CHECK ADD  CONSTRAINT [FaceRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id])
GO
ALTER TABLE [dbo].[Face] CHECK CONSTRAINT [FaceRole_FK]
GO

ALTER TABLE [dbo].[Geo]  WITH CHECK ADD  CONSTRAINT [GeoParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Geo] ([Id])
GO
ALTER TABLE [dbo].[Geo] CHECK CONSTRAINT [GeoParent_FK]
GO
ALTER TABLE [dbo].[Geo]  WITH CHECK ADD  CONSTRAINT [GeoRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id])
GO
ALTER TABLE [dbo].[Geo] CHECK CONSTRAINT [GeoRole_FK]
GO
ALTER TABLE [dbo].[Geo]  WITH CHECK ADD  CONSTRAINT [GeoUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id])
GO
ALTER TABLE [dbo].[Geo] CHECK CONSTRAINT [GeoUnit_FK]
GO

ALTER TABLE [dbo].[Info]  WITH CHECK ADD  CONSTRAINT [InfoParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Info] ([Id])
GO
ALTER TABLE [dbo].[Info] CHECK CONSTRAINT [InfoParent_FK]
GO

ALTER TABLE [dbo].[Item]  WITH CHECK ADD  CONSTRAINT [ItemParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Item] ([Id])
GO
ALTER TABLE [dbo].[Item] CHECK CONSTRAINT [ItemParent_FK]
GO

ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogAccount_FK] FOREIGN KEY([Account])
REFERENCES [dbo].[Account] ([Id])
GO
ALTER TABLE [dbo].[Log] CHECK CONSTRAINT [LogAccount_FK]
GO
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogAsset_FK] FOREIGN KEY([Asset])
REFERENCES [dbo].[Asset] ([Id])
GO
ALTER TABLE [dbo].[Log] CHECK CONSTRAINT [LogAsset_FK]
GO
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogDeal_FK] FOREIGN KEY([Deal])
REFERENCES [dbo].[Deal] ([Id])
GO
ALTER TABLE [dbo].[Log] CHECK CONSTRAINT [LogDeal_FK]
GO
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogFace_FK] FOREIGN KEY([Face])
REFERENCES [dbo].[Face] ([Id])
GO
ALTER TABLE [dbo].[Log] CHECK CONSTRAINT [LogFace_FK]
GO
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogFace1_FK] FOREIGN KEY([Face1])
REFERENCES [dbo].[Face] ([Id])
GO
ALTER TABLE [dbo].[Log] CHECK CONSTRAINT [LogFace1_FK]
GO
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogFace2_FK] FOREIGN KEY([Face2])
REFERENCES [dbo].[Face] ([Id])
GO
ALTER TABLE [dbo].[Log] CHECK CONSTRAINT [LogFace2_FK]
GO
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogGeo_FK] FOREIGN KEY([Geo])
REFERENCES [dbo].[Geo] ([Id])
GO
ALTER TABLE [dbo].[Log] CHECK CONSTRAINT [LogGeo_FK]
GO
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id])
GO
ALTER TABLE [dbo].[Log] CHECK CONSTRAINT [LogInfo_FK]
GO
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogItem_FK] FOREIGN KEY([Item])
REFERENCES [dbo].[Item] ([Id])
GO
ALTER TABLE [dbo].[Log] CHECK CONSTRAINT [LogItem_FK]
GO
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogLog1_FK] FOREIGN KEY([Log1])
REFERENCES [dbo].[Log] ([Id])
GO
ALTER TABLE [dbo].[Log] CHECK CONSTRAINT [LogLog1_FK]
GO
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogMark_FK] FOREIGN KEY([Mark])
REFERENCES [dbo].[Mark] ([Id])
GO
ALTER TABLE [dbo].[Log] CHECK CONSTRAINT [LogMark_FK]
GO
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogMeter_FK] FOREIGN KEY([Meter])
REFERENCES [dbo].[Meter] ([Id])
GO
ALTER TABLE [dbo].[Log] CHECK CONSTRAINT [LogMeter_FK]
GO
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Log] ([Id])
GO
ALTER TABLE [dbo].[Log] CHECK CONSTRAINT [LogParent_FK]
GO
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogPrice_FK] FOREIGN KEY([Price])
REFERENCES [dbo].[Price] ([Id])
GO
ALTER TABLE [dbo].[Log] CHECK CONSTRAINT [LogPrice_FK]
GO
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogProcess1_FK] FOREIGN KEY([Process1])
REFERENCES [dbo].[Process] ([Id])
GO
ALTER TABLE [dbo].[Log] CHECK CONSTRAINT [LogProcess1_FK]
GO
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id])
GO
ALTER TABLE [dbo].[Log] CHECK CONSTRAINT [LogRole_FK]
GO
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogSign_FK] FOREIGN KEY([Sign])
REFERENCES [dbo].[Sign] ([Id])
GO
ALTER TABLE [dbo].[Log] CHECK CONSTRAINT [LogSign_FK]
GO
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogSlice_FK] FOREIGN KEY([Slice])
REFERENCES [dbo].[Slice] ([Id])
GO
ALTER TABLE [dbo].[Log] CHECK CONSTRAINT [LogSlice_FK]
GO
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogTax_FK] FOREIGN KEY([Tax])
REFERENCES [dbo].[Tax] ([Id])
GO
ALTER TABLE [dbo].[Log] CHECK CONSTRAINT [LogTax_FK]
GO
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id])
GO
ALTER TABLE [dbo].[Log] CHECK CONSTRAINT [LogUnit_FK]
GO

ALTER TABLE [dbo].[Mark]  WITH CHECK ADD  CONSTRAINT [MarkParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Mark] ([Id])
GO
ALTER TABLE [dbo].[Mark] CHECK CONSTRAINT [MarkParent_FK]
GO

ALTER TABLE [dbo].[Meter]  WITH CHECK ADD  CONSTRAINT [MeterParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Meter] ([Id])
GO
ALTER TABLE [dbo].[Meter] CHECK CONSTRAINT [MeterParent_FK]
GO
ALTER TABLE [dbo].[Meter]  WITH CHECK ADD  CONSTRAINT [MeterUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id])
GO
ALTER TABLE [dbo].[Meter] CHECK CONSTRAINT [MeterUnit_FK]
GO

ALTER TABLE [dbo].[Price]  WITH CHECK ADD  CONSTRAINT [PriceFace_FK] FOREIGN KEY([Face])
REFERENCES [dbo].[Face] ([Id])
GO
ALTER TABLE [dbo].[Price] CHECK CONSTRAINT [PriceFace_FK]
GO
ALTER TABLE [dbo].[Price]  WITH CHECK ADD  CONSTRAINT [PriceFace1_FK] FOREIGN KEY([Face1])
REFERENCES [dbo].[Face] ([Id])
GO
ALTER TABLE [dbo].[Price] CHECK CONSTRAINT [PriceFace1_FK]
GO
ALTER TABLE [dbo].[Price]  WITH CHECK ADD  CONSTRAINT [PriceFace2_FK] FOREIGN KEY([Face2])
REFERENCES [dbo].[Face] ([Id])
GO
ALTER TABLE [dbo].[Price] CHECK CONSTRAINT [PriceFace2_FK]
GO
ALTER TABLE [dbo].[Price]  WITH CHECK ADD  CONSTRAINT [PriceInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id])
GO
ALTER TABLE [dbo].[Price] CHECK CONSTRAINT [PriceInfo_FK]
GO
ALTER TABLE [dbo].[Price]  WITH CHECK ADD  CONSTRAINT [PriceParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Price] ([Id])
GO
ALTER TABLE [dbo].[Price] CHECK CONSTRAINT [PriceParent_FK]
GO
ALTER TABLE [dbo].[Price]  WITH CHECK ADD  CONSTRAINT [PriceRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id])
GO
ALTER TABLE [dbo].[Price] CHECK CONSTRAINT [PriceRole_FK]
GO
ALTER TABLE [dbo].[Price]  WITH CHECK ADD  CONSTRAINT [PriceUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id])
GO
ALTER TABLE [dbo].[Price] CHECK CONSTRAINT [PriceUnit_FK]
GO

ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessAccount_FK] FOREIGN KEY([Account])
REFERENCES [dbo].[Account] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessAccount_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessAsset_FK] FOREIGN KEY([Asset])
REFERENCES [dbo].[Asset] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessAsset_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessDeal_FK] FOREIGN KEY([Deal])
REFERENCES [dbo].[Deal] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessDeal_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessFace_FK] FOREIGN KEY([Face])
REFERENCES [dbo].[Face] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessFace_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessFace1_FK] FOREIGN KEY([Face1])
REFERENCES [dbo].[Face] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessFace1_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessFace2_FK] FOREIGN KEY([Face2])
REFERENCES [dbo].[Face] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessFace2_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessInfo_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessItem_FK] FOREIGN KEY([Item])
REFERENCES [dbo].[Item] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessItem_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessLog2_FK] FOREIGN KEY([Log2])
REFERENCES [dbo].[Log] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessLog2_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessLog1_FK] FOREIGN KEY([Log1])
REFERENCES [dbo].[Log] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessLog1_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessMeter_FK] FOREIGN KEY([Meter])
REFERENCES [dbo].[Meter] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessMeter_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Process] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessParent_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessPrice_FK] FOREIGN KEY([Price])
REFERENCES [dbo].[Price] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessPrice_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessProcess1_FK] FOREIGN KEY([Process1])
REFERENCES [dbo].[Process] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessProcess1_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessRole_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessSign_FK] FOREIGN KEY([Sign])
REFERENCES [dbo].[Sign] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessSign_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessSlice_FK] FOREIGN KEY([Slice])
REFERENCES [dbo].[Slice] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessSlice_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessTax_FK] FOREIGN KEY([Tax])
REFERENCES [dbo].[Tax] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessTax_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessUnit_FK]
GO

ALTER TABLE [dbo].[Role]  WITH CHECK ADD  CONSTRAINT [RoleParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Role] ([Id])
GO
ALTER TABLE [dbo].[Role] CHECK CONSTRAINT [RoleParent_FK]
GO

ALTER TABLE [dbo].[Sign]  WITH CHECK ADD  CONSTRAINT [SignInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id])
GO
ALTER TABLE [dbo].[Sign] CHECK CONSTRAINT [SignInfo_FK]
GO
ALTER TABLE [dbo].[Sign]  WITH CHECK ADD  CONSTRAINT [SignParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Sign] ([Id])
GO
ALTER TABLE [dbo].[Sign] CHECK CONSTRAINT [SignParent_FK]
GO
ALTER TABLE [dbo].[Sign]  WITH CHECK ADD  CONSTRAINT [SignRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id])
GO
ALTER TABLE [dbo].[Sign] CHECK CONSTRAINT [SignRole_FK]
GO

ALTER TABLE [dbo].[Slice]  WITH CHECK ADD  CONSTRAINT [SliceParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Slice] ([Id])
GO
ALTER TABLE [dbo].[Slice] CHECK CONSTRAINT [SliceParent_FK]
GO

ALTER TABLE [dbo].[Tax]  WITH CHECK ADD  CONSTRAINT [TaxFace1_FK] FOREIGN KEY([Face1])
REFERENCES [dbo].[Face] ([Id])
GO
ALTER TABLE [dbo].[Tax] CHECK CONSTRAINT [TaxFace1_FK]
GO
ALTER TABLE [dbo].[Tax]  WITH CHECK ADD  CONSTRAINT [TaxFace2_FK] FOREIGN KEY([Face2])
REFERENCES [dbo].[Face] ([Id])
GO
ALTER TABLE [dbo].[Tax] CHECK CONSTRAINT [TaxFace2_FK]
GO
ALTER TABLE [dbo].[Tax]  WITH CHECK ADD  CONSTRAINT [TaxGeo_FK] FOREIGN KEY([Geo])
REFERENCES [dbo].[Geo] ([Id])
GO
ALTER TABLE [dbo].[Tax] CHECK CONSTRAINT [TaxGeo_FK]
GO
ALTER TABLE [dbo].[Tax]  WITH CHECK ADD  CONSTRAINT [TaxInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id])
GO
ALTER TABLE [dbo].[Tax] CHECK CONSTRAINT [TaxInfo_FK]
GO
ALTER TABLE [dbo].[Tax]  WITH CHECK ADD  CONSTRAINT [TaxParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Tax] ([Id])
GO
ALTER TABLE [dbo].[Tax] CHECK CONSTRAINT [TaxParent_FK]
GO
ALTER TABLE [dbo].[Tax]  WITH CHECK ADD  CONSTRAINT [TaxRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id])
GO
ALTER TABLE [dbo].[Tax] CHECK CONSTRAINT [TaxRole_FK]
GO

ALTER TABLE [dbo].[Unit]  WITH CHECK ADD  CONSTRAINT [UnitParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Unit] ([Id])
GO
ALTER TABLE [dbo].[Unit] CHECK CONSTRAINT [UnitParent_FK]
GO
ALTER TABLE [dbo].[Unit]  WITH CHECK ADD  CONSTRAINT [UnitRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id])
GO
ALTER TABLE [dbo].[Unit] CHECK CONSTRAINT [UnitRole_FK]
GO
ALTER TABLE [dbo].[Unit]  WITH CHECK ADD  CONSTRAINT [UnitUnit1_FK] FOREIGN KEY([Unit1])
REFERENCES [dbo].[Unit] ([Id])
GO
ALTER TABLE [dbo].[Unit] CHECK CONSTRAINT [UnitUnit1_FK]
GO

USE [master]
GO
ALTER DATABASE [BaseN1] SET  READ_WRITE 
GO
