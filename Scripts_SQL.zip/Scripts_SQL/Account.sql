USE [BaseN1]

SELECT [T1].[Id] AS [Id], 
[T1].[Parent] AS [ParentId], 
[T4].[Code] AS [ParentCode],

[T1].[Slice] AS [SliceId], 
[T3].[Code] AS [SliceCode], 

[T1].[Date1] AS [Date1], 
[T1].[Date2] AS [Date2],

[T1].[Code] AS [Code], 
[T1].[Description] AS [Description],

[T1].[Role] AS [RoleId], 
[T10].[Code] AS [RoleCode], 

[T1].[Sign] AS [SignId], 
[T12].[Code] AS [SignCode],

[T1].[More] AS [More] 

FROM [dbo].[Account] AS [T1]                           ---����� �������� [dbo].[�������]

LEFT JOIN [dbo].[Account] AS [T4] ON [T1].[Parent]=[T4].[Id]    ---����� �������� [dbo].[�������]
LEFT JOIN [dbo].[Slice] AS [T3] ON [T1].[Slice]=[T3].[Id]     
LEFT JOIN [dbo].[Role] AS [T10] ON [T1].[Role]=[T10].[Id] 
LEFT JOIN [dbo].[Sign] AS T12 ON [T1].[Sign]=[T12].[Id] 

Order By [Id] ASC