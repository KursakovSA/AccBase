USE [master];

CREATE DATABASE [AccBase0]
 CONTAINMENT = PARTIAL
 ON  PRIMARY 
( NAME = N'AccBase0', FILENAME = N'D:\AccBase0.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'AccBase0_Log', FILENAME = N'D:\AccBase0_Log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB );

IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [AccBase0].[dbo].[sp_fulltext_database] @action = 'enable'
end;

ALTER DATABASE [AccBase0] SET ANSI_NULL_DEFAULT OFF
ALTER DATABASE [AccBase0] SET ANSI_NULLS OFF
ALTER DATABASE [AccBase0] SET ANSI_PADDING OFF
ALTER DATABASE [AccBase0] SET ANSI_WARNINGS OFF
ALTER DATABASE [AccBase0] SET ARITHABORT OFF
ALTER DATABASE [AccBase0] SET AUTO_CLOSE OFF
ALTER DATABASE [AccBase0] SET AUTO_SHRINK OFF
ALTER DATABASE [AccBase0] SET AUTO_UPDATE_STATISTICS ON
ALTER DATABASE [AccBase0] SET CURSOR_CLOSE_ON_COMMIT OFF
ALTER DATABASE [AccBase0] SET CURSOR_DEFAULT  GLOBAL
ALTER DATABASE [AccBase0] SET CONCAT_NULL_YIELDS_NULL OFF
ALTER DATABASE [AccBase0] SET NUMERIC_ROUNDABORT OFF
ALTER DATABASE [AccBase0] SET QUOTED_IDENTIFIER OFF
ALTER DATABASE [AccBase0] SET RECURSIVE_TRIGGERS OFF
ALTER DATABASE [AccBase0] SET  DISABLE_BROKER
ALTER DATABASE [AccBase0] SET AUTO_UPDATE_STATISTICS_ASYNC OFF
ALTER DATABASE [AccBase0] SET DATE_CORRELATION_OPTIMIZATION OFF
ALTER DATABASE [AccBase0] SET TRUSTWORTHY OFF
ALTER DATABASE [AccBase0] SET ALLOW_SNAPSHOT_ISOLATION OFF
ALTER DATABASE [AccBase0] SET PARAMETERIZATION SIMPLE
ALTER DATABASE [AccBase0] SET READ_COMMITTED_SNAPSHOT OFF
ALTER DATABASE [AccBase0] SET HONOR_BROKER_PRIORITY OFF
ALTER DATABASE [AccBase0] SET RECOVERY SIMPLE
ALTER DATABASE [AccBase0] SET  MULTI_USER
ALTER DATABASE [AccBase0] SET PAGE_VERIFY CHECKSUM
ALTER DATABASE [AccBase0] SET DB_CHAINING OFF
ALTER DATABASE [AccBase0] SET DEFAULT_FULLTEXT_LANGUAGE = 1033
ALTER DATABASE [AccBase0] SET DEFAULT_LANGUAGE = 1033
ALTER DATABASE [AccBase0] SET NESTED_TRIGGERS = ON
ALTER DATABASE [AccBase0] SET TRANSFORM_NOISE_WORDS = OFF
ALTER DATABASE [AccBase0] SET TWO_DIGIT_YEAR_CUTOFF = 2049
ALTER DATABASE [AccBase0] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF )
ALTER DATABASE [AccBase0] SET TARGET_RECOVERY_TIME = 60 SECONDS
ALTER DATABASE [AccBase0] SET DELAYED_DURABILITY = DISABLED
ALTER DATABASE [AccBase0] SET QUERY_STORE = OFF
ALTER DATABASE [AccBase0] SET  READ_WRITE
GO

USE [AccBase0];

CREATE TABLE [dbo].[Account](
	[Id] [int] NOT NULL,
	[Parent] [int] NULL,
	[Face1] [int] NULL,
	[Face2] [int] NULL,
	[Face] [int] NULL,
	[Slice] [int] NULL,
	[Date1] [smalldatetime] NULL,
	[Date2] [nvarchar](100) NULL,
	[Code] [nvarchar](100) NULL,
	[Description] [nvarchar](255) NULL,
	[Geo] [int] NULL,
	[Account] [int] NULL,
	[Role] [int] NULL,
	[Info] [int] NULL,
	[Sign] [int] NULL,
	[Unit] [int] NULL,
	[More] [nvarchar](MAX) NULL,
	[Mark] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO

CREATE TABLE [dbo].[Asset](
	[Id] [int] NOT NULL,
	[Parent] [int] NULL,
	[Face1] [int] NULL,
	[Face2] [int] NULL,
	[Face] [int] NULL,
	[Slice] [int] NULL,
	[Date1] [smalldatetime] NULL,
	[Date2] [nvarchar](100) NULL,
	[Code] [nvarchar](100) NULL,
	[Description] [nvarchar](255) NULL,
	[Geo] [int] NULL,
	[Account] [int] NULL,
	[Asset] [int] NULL,
	[Role] [int] NULL,
	[Info] [int] NULL,
	[Unit] [int] NULL,
	[More] [nvarchar](MAX) NULL,
	[Mark] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO

CREATE TABLE [dbo].[Deal](
	[Id] [int] NOT NULL,
	[Parent] [int] NULL,
	[Face1] [int] NULL,
	[Face2] [int] NULL,
	[Face] [int] NULL,
	[Slice] [int] NULL,
	[Date1] [smalldatetime] NULL,
	[Date2] [nvarchar](100) NULL,
	[Code] [nvarchar](100) NULL,
	[Description] [nvarchar](255) NULL,
	[Geo] [int] NULL,
    [Account] [int] NULL,
	[Deal] [int] NULL,
	[Role] [int] NULL,
	[Info] [int] NULL,
	[Unit] [int] NULL,
	[More] [nvarchar](MAX) NULL,
	[Mark] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO

CREATE TABLE [dbo].[Face](
	[Id] [int] NOT NULL,
	[Parent] [int] NULL,
	[Face1] [int] NULL,
	[Face2] [int] NULL,
	[Face] [int] NULL,
	[Slice] [int] NULL,
	[Date1] [smalldatetime] NULL,
	[Date2] [nvarchar](100) NULL,
	[Code] [nvarchar](100) NULL,
	[Description] [nvarchar](255) NULL,
	[Geo] [int] NULL,
	[Account] [int] NULL,
	[Role] [int] NULL,
	[Info] [int] NULL,
	[Unit] [int] NULL,
	[More] [nvarchar](MAX) NULL,
	[Mark] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO

CREATE TABLE [dbo].[Geo](
	[Id] [int] NOT NULL,
	[Parent] [int] NULL,
	[Face1] [int] NULL,
	[Face2] [int] NULL,
	[Face] [int] NULL,
	[Slice] [int] NULL,
	[Date1] [smalldatetime] NULL,
	[Date2] [nvarchar](100) NULL,
	[Code] [nvarchar](100) NULL,
	[Description] [nvarchar](255) NULL,
	[Geo] [int] NULL,
	[Account] [int] NULL,
	[Role] [int] NULL,
	[Info] [int] NULL,
	[Unit] [int] NULL,
	[More] [nvarchar](MAX) NULL,
	[Mark] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO

CREATE TABLE [dbo].[Info](
	[Id] [int] NOT NULL,
	[Parent] [int] NULL,
	[Face1] [int] NULL,
	[Face2] [int] NULL,
	[Face] [int] NULL,
	[Slice] [int] NULL,
	[Date1] [smalldatetime] NULL,
	[Date2] [nvarchar](100) NULL,
	[Code] [nvarchar](100) NULL,
	[Description] [nvarchar](255) NULL,
	[Geo] [int] NULL,
	[Account] [int] NULL,
	[Role] [int] NULL,
	[Info] [int] NULL,
	[Unit] [int] NULL,
	[More] [nvarchar](MAX) NULL,
	[Mark] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO

CREATE TABLE [dbo].[Item](
	[Id] [int] NOT NULL,
	[Parent] [int] NULL,
	[Face1] [int] NULL,
	[Face2] [int] NULL,
	[Face] [int] NULL,
	[Slice] [int] NULL,
	[Date1] [smalldatetime] NULL,
	[Date2] [nvarchar](100) NULL,
	[Code] [nvarchar](100) NULL,
	[Description] [nvarchar](255) NULL,
	[Geo] [int] NULL,
	[Account] [int] NULL,
	[Item] [int] NULL,
	[Role] [int] NULL,
	[Info] [int] NULL,
	[Unit] [int] NULL,
	[More] [nvarchar](MAX) NULL,
	[Mark] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO

CREATE TABLE [dbo].[Log](
	[Id] [int] NOT NULL,
	[Parent] [int] NULL,
	[Face1] [int] NULL,
	[Face2] [int] NULL,
	[Face] [int] NULL,
	[Slice] [int] NULL,
	[Date1] [smalldatetime] NULL,
	[Date2] [nvarchar](100) NULL,
	[Code] [nvarchar](100) NULL,
	[Description] [nvarchar](255) NULL,
	[Geo] [int] NULL,
	[Sign] [int] NULL,
	[Account] [int] NULL,
	[Log] [int] NULL,
	[Process] [int] NULL,
	[Tax] [int] NULL,
	[Item] [int] NULL,
	[Deal] [int] NULL,
	[Price] [int] NULL,
	[Asset] [int] NULL,
	[Role] [int] NULL,
	[Info] [int] NULL,
	[Meter] [int] NULL,
	[ValueMeter] [nvarchar](100) NULL,
	[Unit] [int] NULL,
	[More] [varchar](MAX) NULL,
	[Mark] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO

CREATE TABLE [dbo].[Mark](
	[Id] [int] NOT NULL,
	[Parent] [int] NULL,
	[Face1] [int] NULL,
	[Face2] [int] NULL,
	[Face] [int] NULL,
	[Slice] [int] NULL,
	[Date1] [smalldatetime] NULL,
	[Date2] [nvarchar](100) NULL,
	[Code] [nvarchar](100) NULL,
	[Description] [nvarchar](255) NULL,
	[Geo] [int] NULL,
	[Account] [int] NULL,
	[Role] [int] NULL,
	[Info] [int] NULL,
	[Unit] [int] NULL,
	[More] [nvarchar](MAX) NULL,
	[Mark] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO

CREATE TABLE [dbo].[Meter](
	[Id] [int] NOT NULL,
	[Parent] [int] NULL,
	[Face1] [int] NULL,
	[Face2] [int] NULL,
	[Face] [int] NULL,
	[Slice] [int] NULL,
	[Date1] [smalldatetime] NULL,
	[Date2] [nvarchar](100) NULL,
	[Code] [nvarchar](100) NULL,
	[Description] [nvarchar](255) NULL,
	[Geo] [int] NULL,
	[Account] [int] NULL,
	[Role] [int] NULL,
	[Info] [int] NULL,
	[Meter] [int] NULL,
	[Unit] [int] NULL,
	[More] [nvarchar](MAX) NULL,
	[Mark] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO

CREATE TABLE [dbo].[Price](
	[Id] [int] NOT NULL,
	[Parent] [int] NULL,
	[Face1] [int] NULL,
	[Face2] [int] NULL,
	[Face] [int] NULL,
	[Slice] [int] NULL,
	[Date1] [smalldatetime] NULL,
	[Date2] [nvarchar](100) NULL,
	[Code] [nvarchar](100) NULL,
	[Description] [nvarchar](255) NULL,
	[Geo] [int] NULL,
	[Account] [int] NULL,
	[Price] [int] NULL,
	[Role] [int] NULL,
	[Info] [int] NULL,
	[Unit] [int] NULL,
	[More] [nvarchar](MAX) NULL,
	[Mark] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO

CREATE TABLE [dbo].[Process](
	[Id] [int] NOT NULL,
	[Parent] [int] NULL,
	[Face1] [int] NULL,
	[Face2] [int] NULL,
	[Face] [int] NULL,
	[Slice] [int] NULL,
	[Date1] [smalldatetime] NULL,
	[Date2] [nvarchar](100) NULL,
	[Code] [nvarchar](100) NULL,
	[Description] [nvarchar](255) NULL,
	[Geo] [int] NULL,
	[Sign] [int] NULL,
	[Account] [int] NULL,
	[Log] [int] NULL,
	[Log1] [int] NULL,
	[Process] [int] NULL,
	[Process1] [int] NULL,
	[Asset] [int] NULL,
	[Deal] [int] NULL,
	[Item] [int] NULL,
	[Tax] [int] NULL,
	[Price] [int] NULL,
	[Role] [int] NULL,
	[Info] [int] NULL,
	[Meter] [int] NULL,
	[ValueMeter] [nvarchar](100) NULL,
	[Unit] [int] NULL,
	[More] [nvarchar](MAX) NULL,
	[Mark] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO

CREATE TABLE [dbo].[Role](
	[Id] [int] NOT NULL,
	[Parent] [int] NULL,
	[Face1] [int] NULL,
	[Face2] [int] NULL,
	[Face] [int] NULL,
	[Slice] [int] NULL,
	[Date1] [smalldatetime] NULL,
	[Date2] [nvarchar](100) NULL,
	[Code] [nvarchar](100) NULL,
	[Description] [nvarchar](255) NULL,
	[Geo] [int] NULL,
	[Account] [int] NULL,
	[Role] [int] NULL,
	[Info] [int] NULL,
	[Unit] [int] NULL,
	[More] [nvarchar](MAX) NULL,
	[Mark] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO

CREATE TABLE [dbo].[Sign](
	[Id] [int] NOT NULL,
	[Parent] [int] NULL,
	[Face1] [int] NULL,
	[Face2] [int] NULL,
	[Face] [int] NULL,
	[Slice] [int] NULL,
	[Date1] [smalldatetime] NULL,
	[Date2] [nvarchar](100) NULL,
	[Code] [nvarchar](100) NULL,
	[Description] [nvarchar](255) NULL,
	[Geo] [int] NULL,
	[Sign] [int] NULL,
	[Account] [int] NULL,
	[Role] [int] NULL,
	[Info] [int] NULL,
	[Unit] [int] NULL,
	[More] [nvarchar](MAX) NULL,
	[Mark] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO

CREATE TABLE [dbo].[Slice](
	[Id] [int] NOT NULL,
	[Parent] [int] NULL,
	[Face1] [int] NULL,
	[Face2] [int] NULL,
	[Face] [int] NULL,
	[Slice] [int] NULL,
	[Date1] [smalldatetime] NULL,
	[Date2] [nvarchar](100) NULL,
	[Code] [nvarchar](100) NULL,
	[Description] [nvarchar](255) NULL,
	[Geo] [int] NULL,
	[Account] [int] NULL,
	[Role] [int] NULL,
	[Info] [int] NULL,
	[Unit] [int] NULL,
	[More] [nvarchar](MAX) NULL,
	[Mark] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO

CREATE TABLE [dbo].[Tax](
	[Id] [int] NOT NULL,
	[Parent] [int] NULL,
	[Face1] [int] NULL,
	[Face2] [int] NULL,
	[Face] [int] NULL,
	[Slice] [int] NULL,
	[Date1] [smalldatetime] NULL,
	[Date2] [nvarchar](100) NULL,
	[Code] [nvarchar](100) NULL,
	[Description] [nvarchar](255) NULL,
	[Geo] [int] NULL,
	[Account] [int] NULL,
	[Tax] [int] NULL,
	[Role] [int] NULL,
	[Info] [int] NULL,
	[Unit] [int] NULL,
	[More] [nvarchar](MAX) NULL,
	[Mark] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO

CREATE TABLE [dbo].[Unit](
	[Id] [int] NOT NULL,
	[Parent] [int] NULL,
	[Face1] [int] NULL,
	[Face2] [int] NULL,
	[Face] [int] NULL,
	[Slice] [int] NULL,
	[Date1] [smalldatetime] NULL,
	[Date2] [nvarchar](100) NULL,
	[Code] [nvarchar](100) NULL,
	[Description] [nvarchar](255) NULL,
	[Geo] [int] NULL,
	[Account] [int] NULL,
	[Role] [int] NULL,
	[Info] [int] NULL,
	[Unit] [int] NULL,
	[More] [nvarchar](MAX) NULL,
	[Mark] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO

CREATE TABLE [dbo].[View](
	[Id] [int] NOT NULL,
	[Parent] [int] NULL,
	[Face1] [int] NULL,
	[Face2] [int] NULL,
	[Face] [int] NULL,
	[Slice] [int] NULL,
	[Date1] [smalldatetime] NULL,
	[Date2] [nvarchar](100) NULL,
	[Code] [nvarchar](100) NULL,
	[Description] [nvarchar](255) NULL,
	[Geo] [int] NULL,
	[Account] [int] NULL,
	[View] [int] NULL,
	[Role] [int] NULL,
	[Info] [int] NULL,
	[Unit] [int] NULL,
	[More] [nvarchar](MAX) NULL,
	[Mark] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO