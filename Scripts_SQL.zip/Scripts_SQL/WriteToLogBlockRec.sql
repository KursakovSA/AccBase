USE AccBase0;
DECLARE @rec NUMERIC
DECLARE @LimitRec NUMERIC
DECLARE @StartTime DATETIME
DECLARE @EndTime DATETIME
DECLARE @SpanTime DATETIME
SET @rec = 0
SET @LimitRec = 1000000
SET @StartTime=SYSDATETIME()
WHILE (@rec<@LimitRec)
BEGIN
SET @rec=@rec+1
insert into Log(Id,Code,Description,Deal,Parent,Face1,Face2,Face,Slice,Date2,Geo,Sign,Account,Log,Process,Tax,Item,Price,Asset,Role,Info,Meter,ValueMeter,Unit,More,Mark) 
VALUES (@rec,@rec,@rec,@rec,@rec,@rec,@rec,@rec,@rec,@rec,@rec,@rec,@rec,@rec,@rec,@rec,@rec,@rec,@rec,@rec,@rec,@rec,@rec,@rec,@rec,@rec)
END

select Id,Code,Description from Log order by Code;

SET @EndTime=SYSDATETIME()
SET @SpanTime=@EndTime-@StartTime

SELECT @StartTime AS Start_time, @EndTime AS End_Time, @SpanTime AS Span_Time