--�������� �.�. https://github.com/KursakovSA/AccBase 
USE [BaseN1]

SELECT [T1].[Id], 
[T1].[Parent], 
[T4].[Code] AS [ParentCode],

[T1].[Date1] AS [Date1], 
[T1].[Date2] AS [Date2],

[T1].[Code] AS [Code], 
[T1].[Description] AS [Description],

[T1].[Role], 
[T10].[Code] AS [RoleCode], 

[T1].[Info], 
[T11].[Code] AS [InfoCode],

[T1].[More] AS [More]

FROM [dbo].[Sign] AS [T1]                       

LEFT JOIN [dbo].[Sign] AS [T4] ON [T1].[Parent]=[T4].[Id]    
LEFT JOIN [dbo].[Role] AS [T10] ON [T1].[Role]=[T10].[Id] 
LEFT JOIN [dbo].[Info] AS [T11] ON [T1].[Info]=[T11].[Id] 