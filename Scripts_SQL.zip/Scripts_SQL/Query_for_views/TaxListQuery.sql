--�������� �.�. https://github.com/KursakovSA/AccBase 
USE [BaseN1]

SELECT [T1].[Id], 
[T1].[Parent], 
[T4].[Code] AS [ParentCode],

[T1].[Face1], 
[T6].[Code] AS [Face1Code],

[T1].[Face2], 
[T7].[Code] AS [Face2Code],

[T1].[Date1] AS [Date1], 
[T1].[Date2] AS [Date2],

[T1].[Code] AS [Code], 
[T1].[Description] AS [Description],

[T1].[Geo], 
[T8].[Code] AS [GeoCode], 

[T1].[Role], 
[T10].[Code] AS [RoleCode], 

[T1].[Info], 
[T11].[Code] AS [InfoCode],

[T1].[More] AS [More]

FROM [dbo].[Tax] AS [T1]                          

LEFT JOIN [dbo].[Tax] AS [T4] ON [T1].[Parent]=[T4].[Id]    
LEFT JOIN [dbo].[Face] AS [T6] ON [T1].[Face1]=[T6].[Id]  
LEFT JOIN [dbo].[Face] AS [T7] ON [T1].[Face2]=[T7].[Id]

LEFT JOIN [dbo].[Geo] AS [T8] ON [T1].[Geo]=[T8].[Id]
LEFT JOIN [dbo].[Role] AS [T10] ON [T1].[Role]=[T10].[Id] 
LEFT JOIN [dbo].[Info] AS [T11] ON [T1].[Info]=[T11].[Id] 