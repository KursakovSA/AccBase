--�������� �.�. https://github.com/KursakovSA/AccBase 
USE [BaseN1]

SELECT [T1].[Id], 
[T1].[Parent], 
[T4].[Code] AS [ParentCode],

[T1].[Date1] AS [Date1], 
[T1].[Date2] AS [Date2],

[T1].[Code] AS [Code], 
[T1].[Description] AS [Description],

[T1].[More] AS [More]

FROM [dbo].[Info] AS [T1]                        

LEFT JOIN [dbo].[Info] AS [T4] ON [T1].[Parent]=[T4].[Id]    