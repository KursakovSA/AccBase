USE [AccBase0]

SELECT  M1.Id AS Id, M1.Code AS Code, M1.Description AS Descr, M2.Code AS MarkCode
FROM Account M1 INNER JOIN Mark M2
  ON M1.Mark=M2.Id 