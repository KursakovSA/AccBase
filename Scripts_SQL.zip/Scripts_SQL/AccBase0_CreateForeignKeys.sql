USE [AccBase0];
DBCC CHECKDB;

--template for foreign key
--ALTER TABLE [dbo].[TableChild]  WITH CHECK ADD  CONSTRAINT [TableChildTableParent_FK] FOREIGN KEY([TableChild.Field])
--REFERENCES [dbo].[TableParent] ([ReplicationId]);
--end template for foreign key

--Account
--Account.Parent FOREIGN KEY
ALTER TABLE [dbo].[Account]  WITH CHECK ADD  CONSTRAINT [AccountParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Account] ([Id]);
--Account.Face1 FOREIGN KEY
ALTER TABLE [dbo].[Account]  WITH CHECK ADD  CONSTRAINT [AccountFace1_FK] FOREIGN KEY([Face1])
REFERENCES [dbo].[Face] ([Id]);
--Account.Face2 FOREIGN KEY
ALTER TABLE [dbo].[Account]  WITH CHECK ADD  CONSTRAINT [AccountFace2_FK] FOREIGN KEY([Face2])
REFERENCES [dbo].[Face] ([Id]);
--Account.Face FOREIGN KEY
ALTER TABLE [dbo].[Account]  WITH CHECK ADD  CONSTRAINT [AccountFace_FK] FOREIGN KEY([Face])
REFERENCES [dbo].[Face] ([Id]);
--Account.Slice FOREIGN KEY
ALTER TABLE [dbo].[Account]  WITH CHECK ADD  CONSTRAINT [AccountSlice_FK] FOREIGN KEY([Slice])
REFERENCES [dbo].[Slice] ([Id]);
--Account.Geo FOREIGN KEY
ALTER TABLE [dbo].[Account]  WITH CHECK ADD  CONSTRAINT [AccountGeo_FK] FOREIGN KEY([Geo])
REFERENCES [dbo].[Geo] ([Id]);
--Account.Account FOREIGN KEY
ALTER TABLE [dbo].[Account]  WITH CHECK ADD  CONSTRAINT [AccountAccount_FK] FOREIGN KEY([Account])
REFERENCES [dbo].[Account] ([Id]);
--Account.Role FOREIGN KEY
ALTER TABLE [dbo].[Account]  WITH CHECK ADD  CONSTRAINT [AccountRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id]);
--Account.Info FOREIGN KEY
ALTER TABLE [dbo].[Account]  WITH CHECK ADD  CONSTRAINT [AccountInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id]);
--Account.Sign FOREIGN KEY
ALTER TABLE [dbo].[Account]  WITH CHECK ADD  CONSTRAINT [AccountSign_FK] FOREIGN KEY([Sign])
REFERENCES [dbo].[Sign] ([Id]);
--Account.Unit FOREIGN KEY
ALTER TABLE [dbo].[Account]  WITH CHECK ADD  CONSTRAINT [AccountUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id]);
--Account.Mark FOREIGN KEY
ALTER TABLE [dbo].[Account]  WITH CHECK ADD  CONSTRAINT [AccountMark_FK] FOREIGN KEY([Mark])
REFERENCES [dbo].[Mark] ([Id]);

--Asset
--Asset.Parent FOREIGN KEY
ALTER TABLE [dbo].[Asset]  WITH CHECK ADD  CONSTRAINT [AssetParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Asset] ([Id]);
--Asset.Face1 FOREIGN KEY
ALTER TABLE [dbo].[Asset]  WITH CHECK ADD  CONSTRAINT [AssetFace1_FK] FOREIGN KEY([Face1])
REFERENCES [dbo].[Face] ([Id]);
--Asset.Face2 FOREIGN KEY
ALTER TABLE [dbo].[Asset]  WITH CHECK ADD  CONSTRAINT [AssetFace2_FK] FOREIGN KEY([Face2])
REFERENCES [dbo].[Face] ([Id]);
--Asset.Face FOREIGN KEY
ALTER TABLE [dbo].[Asset]  WITH CHECK ADD  CONSTRAINT [AssetFace_FK] FOREIGN KEY([Face])
REFERENCES [dbo].[Face] ([Id]);
--Asset.Slice FOREIGN KEY
ALTER TABLE [dbo].[Asset]  WITH CHECK ADD  CONSTRAINT [AssetSlice_FK] FOREIGN KEY([Slice])
REFERENCES [dbo].[Slice] ([Id]);
--Asset.Geo FOREIGN KEY
ALTER TABLE [dbo].[Asset]  WITH CHECK ADD  CONSTRAINT [AssetGeo_FK] FOREIGN KEY([Geo])
REFERENCES [dbo].[Geo] ([Id]);
--Asset.Account FOREIGN KEY
ALTER TABLE [dbo].[Asset]  WITH CHECK ADD  CONSTRAINT [AssetAccount_FK] FOREIGN KEY([Account])
REFERENCES [dbo].[Account] ([Id]);
--Asset.Asset FOREIGN KEY
ALTER TABLE [dbo].[Asset]  WITH CHECK ADD  CONSTRAINT [AssetAsset_FK] FOREIGN KEY([Asset])
REFERENCES [dbo].[Asset] ([Id]);
--Asset.Role FOREIGN KEY
ALTER TABLE [dbo].[Asset]  WITH CHECK ADD  CONSTRAINT [AssetRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id]);
--Asset.Info FOREIGN KEY
ALTER TABLE [dbo].[Asset]  WITH CHECK ADD  CONSTRAINT [AssetInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id]);
--Asset.Unit FOREIGN KEY
ALTER TABLE [dbo].[Asset]  WITH CHECK ADD  CONSTRAINT [AssetUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id]);
--Asset.Mark FOREIGN KEY
ALTER TABLE [dbo].[Asset]  WITH CHECK ADD  CONSTRAINT [AssetMark_FK] FOREIGN KEY([Mark])
REFERENCES [dbo].[Mark] ([Id]);

--Deal
--Deal.Parent FOREIGN KEY
ALTER TABLE [dbo].[Deal]  WITH CHECK ADD  CONSTRAINT [DealParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Deal] ([Id]);
--Deal.Face1 FOREIGN KEY
ALTER TABLE [dbo].[Deal]  WITH CHECK ADD  CONSTRAINT [DealFace1_FK] FOREIGN KEY([Face1])
REFERENCES [dbo].[Face] ([Id]);
--Deal.Face2 FOREIGN KEY
ALTER TABLE [dbo].[Deal]  WITH CHECK ADD  CONSTRAINT [DealFace2_FK] FOREIGN KEY([Face2])
REFERENCES [dbo].[Face] ([Id]);
--Deal.Face FOREIGN KEY
ALTER TABLE [dbo].[Deal]  WITH CHECK ADD  CONSTRAINT [DealFace_FK] FOREIGN KEY([Face])
REFERENCES [dbo].[Face] ([Id]);
--Deal.Slice FOREIGN KEY
ALTER TABLE [dbo].[Deal]  WITH CHECK ADD  CONSTRAINT [DealSlice_FK] FOREIGN KEY([Slice])
REFERENCES [dbo].[Slice] ([Id]);
--Deal.Geo FOREIGN KEY
ALTER TABLE [dbo].[Deal]  WITH CHECK ADD  CONSTRAINT [DealGeo_FK] FOREIGN KEY([Geo])
REFERENCES [dbo].[Geo] ([Id]);
--Deal.Account FOREIGN KEY
ALTER TABLE [dbo].[Deal]  WITH CHECK ADD  CONSTRAINT [DealAccount_FK] FOREIGN KEY([Account])
REFERENCES [dbo].[Account] ([Id]);
--Deal.Deal FOREIGN KEY
ALTER TABLE [dbo].[Deal]  WITH CHECK ADD  CONSTRAINT [DealDeal_FK] FOREIGN KEY([Deal])
REFERENCES [dbo].[Deal] ([Id]);
--Deal.Role FOREIGN KEY
ALTER TABLE [dbo].[Deal]  WITH CHECK ADD  CONSTRAINT [DealRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id]);
--Deal.Info FOREIGN KEY
ALTER TABLE [dbo].[Deal]  WITH CHECK ADD  CONSTRAINT [DealInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id]);
--Deal.Unit FOREIGN KEY
ALTER TABLE [dbo].[Deal]  WITH CHECK ADD  CONSTRAINT [DealUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id]);
--Deal.Mark FOREIGN KEY
ALTER TABLE [dbo].[Deal]  WITH CHECK ADD  CONSTRAINT [DealMark_FK] FOREIGN KEY([Mark])
REFERENCES [dbo].[Mark] ([Id]);

--Face
--Face.Parent FOREIGN KEY
ALTER TABLE [dbo].[Face]  WITH CHECK ADD  CONSTRAINT [FaceParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Face] ([Id]);
--Face.Face1 FOREIGN KEY
ALTER TABLE [dbo].[Face]  WITH CHECK ADD  CONSTRAINT [FaceFace1_FK] FOREIGN KEY([Face1])
REFERENCES [dbo].[Face] ([Id]);
--Face.Face2 FOREIGN KEY
ALTER TABLE [dbo].[Face]  WITH CHECK ADD  CONSTRAINT [FaceFace2_FK] FOREIGN KEY([Face2])
REFERENCES [dbo].[Face] ([Id]);
--Face.Face FOREIGN KEY
ALTER TABLE [dbo].[Face]  WITH CHECK ADD  CONSTRAINT [FaceFace_FK] FOREIGN KEY([Face])
REFERENCES [dbo].[Face] ([Id]);
--Face.Slice FOREIGN KEY
ALTER TABLE [dbo].[Face]  WITH CHECK ADD  CONSTRAINT [FaceSlice_FK] FOREIGN KEY([Slice])
REFERENCES [dbo].[Slice] ([Id]);
--Face.Geo FOREIGN KEY
ALTER TABLE [dbo].[Face]  WITH CHECK ADD  CONSTRAINT [FaceGeo_FK] FOREIGN KEY([Geo])
REFERENCES [dbo].[Geo] ([Id]);
--Face.Account FOREIGN KEY
ALTER TABLE [dbo].[Face]  WITH CHECK ADD  CONSTRAINT [FaceAccount_FK] FOREIGN KEY([Account])
REFERENCES [dbo].[Account] ([Id]);
--Face.Role FOREIGN KEY
ALTER TABLE [dbo].[Face]  WITH CHECK ADD  CONSTRAINT [FaceRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id]);
--Face.Info FOREIGN KEY
ALTER TABLE [dbo].[Face]  WITH CHECK ADD  CONSTRAINT [FaceInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id]);
--Face.Unit FOREIGN KEY
ALTER TABLE [dbo].[Face]  WITH CHECK ADD  CONSTRAINT [FaceUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id]);
--Face.Mark FOREIGN KEY
ALTER TABLE [dbo].[Face]  WITH CHECK ADD  CONSTRAINT [FaceMark_FK] FOREIGN KEY([Mark])
REFERENCES [dbo].[Mark] ([Id]);

--Geo
--Geo.Parent FOREIGN KEY
ALTER TABLE [dbo].[Geo]  WITH CHECK ADD  CONSTRAINT [GeoParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Geo] ([Id]);
--Geo.Face1 FOREIGN KEY
ALTER TABLE [dbo].[Geo]  WITH CHECK ADD  CONSTRAINT [GeoFace1_FK] FOREIGN KEY([Face1])
REFERENCES [dbo].[Face] ([Id]);
--Geo.Face2 FOREIGN KEY
ALTER TABLE [dbo].[Geo]  WITH CHECK ADD  CONSTRAINT [GeoFace2_FK] FOREIGN KEY([Face2])
REFERENCES [dbo].[Face] ([Id]);
--Geo.Face FOREIGN KEY
ALTER TABLE [dbo].[Geo]  WITH CHECK ADD  CONSTRAINT [GeoFace_FK] FOREIGN KEY([Face])
REFERENCES [dbo].[Face] ([Id]);
--Geo.Slice FOREIGN KEY
ALTER TABLE [dbo].[Geo]  WITH CHECK ADD  CONSTRAINT [GeoSlice_FK] FOREIGN KEY([Slice])
REFERENCES [dbo].[Slice] ([Id]);
--Geo.Geo FOREIGN KEY
ALTER TABLE [dbo].[Geo]  WITH CHECK ADD  CONSTRAINT [GeoGeo_FK] FOREIGN KEY([Geo])
REFERENCES [dbo].[Geo] ([Id]);
--Geo.Account FOREIGN KEY
ALTER TABLE [dbo].[Geo]  WITH CHECK ADD  CONSTRAINT [GeoAccount_FK] FOREIGN KEY([Account])
REFERENCES [dbo].[Account] ([Id]);
--Geo.Role FOREIGN KEY
ALTER TABLE [dbo].[Geo]  WITH CHECK ADD  CONSTRAINT [GeoRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id]);
--Geo.Info FOREIGN KEY
ALTER TABLE [dbo].[Geo]  WITH CHECK ADD  CONSTRAINT [GeoInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id]);
--Geo.Unit FOREIGN KEY
ALTER TABLE [dbo].[Geo]  WITH CHECK ADD  CONSTRAINT [GeoUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id]);
--Geo.Mark FOREIGN KEY
ALTER TABLE [dbo].[Geo]  WITH CHECK ADD  CONSTRAINT [GeoMark_FK] FOREIGN KEY([Mark])
REFERENCES [dbo].[Mark] ([Id]);

--Info
--Info.Parent FOREIGN KEY
ALTER TABLE [dbo].[Info]  WITH CHECK ADD  CONSTRAINT [InfoParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Info] ([Id]);
--Info.Face1 FOREIGN KEY
ALTER TABLE [dbo].[Info]  WITH CHECK ADD  CONSTRAINT [InfoFace1_FK] FOREIGN KEY([Face1])
REFERENCES [dbo].[Face] ([Id]);
--Info.Face2 FOREIGN KEY
ALTER TABLE [dbo].[Info]  WITH CHECK ADD  CONSTRAINT [InfoFace2_FK] FOREIGN KEY([Face2])
REFERENCES [dbo].[Face] ([Id]);
--Info.Face FOREIGN KEY
ALTER TABLE [dbo].[Info]  WITH CHECK ADD  CONSTRAINT [InfoFace_FK] FOREIGN KEY([Face])
REFERENCES [dbo].[Face] ([Id]);
--Info.Slice FOREIGN KEY
ALTER TABLE [dbo].[Info]  WITH CHECK ADD  CONSTRAINT [InfoSlice_FK] FOREIGN KEY([Slice])
REFERENCES [dbo].[Slice] ([Id]);
--Info.Geo FOREIGN KEY
ALTER TABLE [dbo].[Info]  WITH CHECK ADD  CONSTRAINT [InfoGeo_FK] FOREIGN KEY([Geo])
REFERENCES [dbo].[Geo] ([Id]);
--Info.Account FOREIGN KEY
ALTER TABLE [dbo].[Info]  WITH CHECK ADD  CONSTRAINT [InfoAccount_FK] FOREIGN KEY([Account])
REFERENCES [dbo].[Account] ([Id]);
--Info.Role FOREIGN KEY
ALTER TABLE [dbo].[Info]  WITH CHECK ADD  CONSTRAINT [InfoRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id]);
--Info.Info FOREIGN KEY
ALTER TABLE [dbo].[Info]  WITH CHECK ADD  CONSTRAINT [InfoInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id]);
--Info.Unit FOREIGN KEY
ALTER TABLE [dbo].[Info]  WITH CHECK ADD  CONSTRAINT [InfoUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id]);
--Info.Mark FOREIGN KEY
ALTER TABLE [dbo].[Info]  WITH CHECK ADD  CONSTRAINT [InfoMark_FK] FOREIGN KEY([Mark])
REFERENCES [dbo].[Mark] ([Id]);

--Item
--Item.Parent FOREIGN KEY
ALTER TABLE [dbo].[Item]  WITH CHECK ADD  CONSTRAINT [ItemParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Item] ([Id]);
--Item.Face1 FOREIGN KEY
ALTER TABLE [dbo].[Item]  WITH CHECK ADD  CONSTRAINT [ItemFace1_FK] FOREIGN KEY([Face1])
REFERENCES [dbo].[Face] ([Id]);
--Item.Face2 FOREIGN KEY
ALTER TABLE [dbo].[Item]  WITH CHECK ADD  CONSTRAINT [ItemFace2_FK] FOREIGN KEY([Face2])
REFERENCES [dbo].[Face] ([Id]);
--Item.Face FOREIGN KEY
ALTER TABLE [dbo].[Item]  WITH CHECK ADD  CONSTRAINT [ItemFace_FK] FOREIGN KEY([Face])
REFERENCES [dbo].[Face] ([Id]);
--Item.Slice FOREIGN KEY
ALTER TABLE [dbo].[Item]  WITH CHECK ADD  CONSTRAINT [ItemSlice_FK] FOREIGN KEY([Slice])
REFERENCES [dbo].[Slice] ([Id]);
--Item.Geo FOREIGN KEY
ALTER TABLE [dbo].[Item]  WITH CHECK ADD  CONSTRAINT [ItemGeo_FK] FOREIGN KEY([Geo])
REFERENCES [dbo].[Geo] ([Id]);
--Item.Account FOREIGN KEY
ALTER TABLE [dbo].[Item]  WITH CHECK ADD  CONSTRAINT [ItemAccount_FK] FOREIGN KEY([Account])
REFERENCES [dbo].[Account] ([Id]);
--Item.Item FOREIGN KEY
ALTER TABLE [dbo].[Item]  WITH CHECK ADD  CONSTRAINT [ItemItem_FK] FOREIGN KEY([Item])
REFERENCES [dbo].[Item] ([Id]);
--Item.Role FOREIGN KEY
ALTER TABLE [dbo].[Item]  WITH CHECK ADD  CONSTRAINT [ItemRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id]);
--Item.Info FOREIGN KEY
ALTER TABLE [dbo].[Item]  WITH CHECK ADD  CONSTRAINT [ItemInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id]);
--Item.Unit FOREIGN KEY
ALTER TABLE [dbo].[Item]  WITH CHECK ADD  CONSTRAINT [ItemUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id]);
--Item.Mark FOREIGN KEY
ALTER TABLE [dbo].[Item]  WITH CHECK ADD  CONSTRAINT [ItemMark_FK] FOREIGN KEY([Mark])
REFERENCES [dbo].[Mark] ([Id]);

--Log
--Log.Parent FOREIGN KEY
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Log] ([Id]);
--Log.Face1 FOREIGN KEY
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogFace1_FK] FOREIGN KEY([Face1])
REFERENCES [dbo].[Face] ([Id]);
--Log.Face2 FOREIGN KEY
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogFace2_FK] FOREIGN KEY([Face2])
REFERENCES [dbo].[Face] ([Id]);
--Log.Face FOREIGN KEY
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogFace_FK] FOREIGN KEY([Face])
REFERENCES [dbo].[Face] ([Id]);
--Log.Slice FOREIGN KEY
ALTER TABLE [dbo].[log]  WITH CHECK ADD  CONSTRAINT [LogSlice_FK] FOREIGN KEY([Slice])
REFERENCES [dbo].[Slice] ([Id]);
--Log.Geo FOREIGN KEY
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogGeo_FK] FOREIGN KEY([Geo])
REFERENCES [dbo].[Geo] ([Id]);
--Log.Log FOREIGN KEY
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogLog_FK] FOREIGN KEY([Log])
REFERENCES [dbo].[Log] ([Id]);
--Log.Process FOREIGN KEY
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogProcess_FK] FOREIGN KEY([Process])
REFERENCES [dbo].[Process] ([Id]);
--Log.Sign FOREIGN KEY
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogSign_FK] FOREIGN KEY([Sign])
REFERENCES [dbo].[Sign] ([Id]);
--Log.Account FOREIGN KEY
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogAccount_FK] FOREIGN KEY([Account])
REFERENCES [dbo].[Account] ([Id]);
--Log.Tax FOREIGN KEY
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogTax_FK] FOREIGN KEY([Tax])
REFERENCES [dbo].[Tax] ([Id]);
--Log.Item FOREIGN KEY
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogItem_FK] FOREIGN KEY([Item])
REFERENCES [dbo].[Item] ([Id]);
--Log.Deal FOREIGN KEY
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogDeal_FK] FOREIGN KEY([Deal])
REFERENCES [dbo].[Deal] ([Id]);
--Log.Price FOREIGN KEY
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogPrice_FK] FOREIGN KEY([Price])
REFERENCES [dbo].[Price] ([Id]);
--Log.Asset FOREIGN KEY
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogAsset_FK] FOREIGN KEY([Asset])
REFERENCES [dbo].[Asset] ([Id]);
--Log.Role FOREIGN KEY
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id]);
--Log.Info FOREIGN KEY
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id]);
--Log.Meter FOREIGN KEY
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogMeter_FK] FOREIGN KEY([Meter])
REFERENCES [dbo].[Meter] ([Id]);
--Log.Unit FOREIGN KEY
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id]);
--Log.Mark FOREIGN KEY
ALTER TABLE [dbo].[Log]  WITH CHECK ADD  CONSTRAINT [LogMark_FK] FOREIGN KEY([Mark])
REFERENCES [dbo].[Mark] ([Id]);

--Mark
--Mark.Parent FOREIGN KEY
ALTER TABLE [dbo].[Mark]  WITH CHECK ADD  CONSTRAINT [MarkParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Mark] ([Id]);
--Mark.Face1 FOREIGN KEY
ALTER TABLE [dbo].[Mark]  WITH CHECK ADD  CONSTRAINT [MarkFace1_FK] FOREIGN KEY([Face1])
REFERENCES [dbo].[Face] ([Id]);
--Mark.Face2 FOREIGN KEY
ALTER TABLE [dbo].[Mark]  WITH CHECK ADD  CONSTRAINT [MarkFace2_FK] FOREIGN KEY([Face2])
REFERENCES [dbo].[Face] ([Id]);
--Mark.Face FOREIGN KEY
ALTER TABLE [dbo].[Mark]  WITH CHECK ADD  CONSTRAINT [MarkFace_FK] FOREIGN KEY([Face])
REFERENCES [dbo].[Face] ([Id]);
--Mark.Slice FOREIGN KEY
ALTER TABLE [dbo].[Mark]  WITH CHECK ADD  CONSTRAINT [MarkSlice_FK] FOREIGN KEY([Slice])
REFERENCES [dbo].[Slice] ([Id]);
--Mark.Geo FOREIGN KEY
ALTER TABLE [dbo].[Mark]  WITH CHECK ADD  CONSTRAINT [MarkGeo_FK] FOREIGN KEY([Geo])
REFERENCES [dbo].[Geo] ([Id]);
--Mark.Account FOREIGN KEY
ALTER TABLE [dbo].[Mark]  WITH CHECK ADD  CONSTRAINT [MarkAccount_FK] FOREIGN KEY([Account])
REFERENCES [dbo].[Account] ([Id]);
--Mark.Role FOREIGN KEY
ALTER TABLE [dbo].[Mark]  WITH CHECK ADD  CONSTRAINT [MarkRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id]);
--Mark.Info FOREIGN KEY
ALTER TABLE [dbo].[Mark]  WITH CHECK ADD  CONSTRAINT [MarkInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id]);
--Mark.Unit FOREIGN KEY
ALTER TABLE [dbo].[Mark]  WITH CHECK ADD  CONSTRAINT [MarkUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id]);
--Mark.Mark FOREIGN KEY
ALTER TABLE [dbo].[Mark]  WITH CHECK ADD  CONSTRAINT [MarkMark_FK] FOREIGN KEY([Mark])
REFERENCES [dbo].[Mark] ([Id]);

--Meter
--Meter.Parent FOREIGN KEY
ALTER TABLE [dbo].[Meter]  WITH CHECK ADD  CONSTRAINT [MeterParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Meter] ([Id]);
--Meter.Face1 FOREIGN KEY
ALTER TABLE [dbo].[Meter]  WITH CHECK ADD  CONSTRAINT [MeterFace1_FK] FOREIGN KEY([Face1])
REFERENCES [dbo].[Face] ([Id]);
--Meter.Face2 FOREIGN KEY
ALTER TABLE [dbo].[Meter]  WITH CHECK ADD  CONSTRAINT [MeterFace2_FK] FOREIGN KEY([Face2])
REFERENCES [dbo].[Face] ([Id]);
--Meter.Face FOREIGN KEY
ALTER TABLE [dbo].[Meter]  WITH CHECK ADD  CONSTRAINT [MeterFace_FK] FOREIGN KEY([Face])
REFERENCES [dbo].[Face] ([Id]);
--Meter.Slice FOREIGN KEY
ALTER TABLE [dbo].[Meter]  WITH CHECK ADD  CONSTRAINT [MeterSlice_FK] FOREIGN KEY([Slice])
REFERENCES [dbo].[Slice] ([Id]);
--Meter.Geo FOREIGN KEY
ALTER TABLE [dbo].[Meter]  WITH CHECK ADD  CONSTRAINT [MeterGeo_FK] FOREIGN KEY([Geo])
REFERENCES [dbo].[Geo] ([Id]);
--Meter.Account FOREIGN KEY
ALTER TABLE [dbo].[Meter]  WITH CHECK ADD  CONSTRAINT [MeterAccount_FK] FOREIGN KEY([Account])
REFERENCES [dbo].[Account] ([Id]);
--Meter.Role FOREIGN KEY
ALTER TABLE [dbo].[Meter]  WITH CHECK ADD  CONSTRAINT [MeterRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id]);
--Meter.Info FOREIGN KEY
ALTER TABLE [dbo].[Meter]  WITH CHECK ADD  CONSTRAINT [MeterInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id]);
--Meter.Meter FOREIGN KEY
ALTER TABLE [dbo].[Meter]  WITH CHECK ADD  CONSTRAINT [MeterMeter_FK] FOREIGN KEY([Meter])
REFERENCES [dbo].[Meter] ([Id]);
--Meter.Unit FOREIGN KEY
ALTER TABLE [dbo].[Meter]  WITH CHECK ADD  CONSTRAINT [MeterUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id]);
--Meter.Mark FOREIGN KEY
ALTER TABLE [dbo].[Meter]  WITH CHECK ADD  CONSTRAINT [MeterMark_FK] FOREIGN KEY([Mark])
REFERENCES [dbo].[Mark] ([Id]);

--Price
--Price.Parent FOREIGN KEY
ALTER TABLE [dbo].[Price]  WITH CHECK ADD  CONSTRAINT [PriceParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Price] ([Id]);
--Price.Face1 FOREIGN KEY
ALTER TABLE [dbo].[Price]  WITH CHECK ADD  CONSTRAINT [PriceFace1_FK] FOREIGN KEY([Face1])
REFERENCES [dbo].[Face] ([Id]);
--Price.Face2 FOREIGN KEY
ALTER TABLE [dbo].[Price]  WITH CHECK ADD  CONSTRAINT [PriceFace2_FK] FOREIGN KEY([Face2])
REFERENCES [dbo].[Face] ([Id]);
--Price.Face FOREIGN KEY
ALTER TABLE [dbo].[Price]  WITH CHECK ADD  CONSTRAINT [PriceFace_FK] FOREIGN KEY([Face])
REFERENCES [dbo].[Face] ([Id]);
--Price.Slice FOREIGN KEY
ALTER TABLE [dbo].[Price]  WITH CHECK ADD  CONSTRAINT [PriceSlice_FK] FOREIGN KEY([Slice])
REFERENCES [dbo].[Slice] ([Id]);
--Price.Geo FOREIGN KEY
ALTER TABLE [dbo].[Price]  WITH CHECK ADD  CONSTRAINT [PriceGeo_FK] FOREIGN KEY([Geo])
REFERENCES [dbo].[Geo] ([Id]);
--Price.Account FOREIGN KEY
ALTER TABLE [dbo].[Price]  WITH CHECK ADD  CONSTRAINT [PriceAccount_FK] FOREIGN KEY([Account])
REFERENCES [dbo].[Account] ([Id]);
--Price.Price FOREIGN KEY
ALTER TABLE [dbo].[Price]  WITH CHECK ADD  CONSTRAINT [PricePrice_FK] FOREIGN KEY([Price])
REFERENCES [dbo].[Price] ([Id]);
--Price.Role FOREIGN KEY
ALTER TABLE [dbo].[Price]  WITH CHECK ADD  CONSTRAINT [PriceRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id]);
--Price.Info FOREIGN KEY
ALTER TABLE [dbo].[Price]  WITH CHECK ADD  CONSTRAINT [PriceInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id]);
--Price.Unit FOREIGN KEY
ALTER TABLE [dbo].[Price]  WITH CHECK ADD  CONSTRAINT [PriceUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id]);
--Price.Mark FOREIGN KEY
ALTER TABLE [dbo].[Price]  WITH CHECK ADD  CONSTRAINT [PriceMark_FK] FOREIGN KEY([Mark])
REFERENCES [dbo].[Mark] ([Id]);

--Process
--Process.Parent FOREIGN KEY
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Process] ([Id]);
--Process.Face1 FOREIGN KEY
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessFace1_FK] FOREIGN KEY([Face1])
REFERENCES [dbo].[Face] ([Id]);
--Process.Face2 FOREIGN KEY
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessFace2_FK] FOREIGN KEY([Face2])
REFERENCES [dbo].[Face] ([Id]);
--Process.Face FOREIGN KEY
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessFace_FK] FOREIGN KEY([Face])
REFERENCES [dbo].[Face] ([Id]);
--Process.Slice FOREIGN KEY
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessSlice_FK] FOREIGN KEY([Slice])
REFERENCES [dbo].[Slice] ([Id]);
--Process.Geo FOREIGN KEY
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessGeo_FK] FOREIGN KEY([Geo])
REFERENCES [dbo].[Geo] ([Id]);
--Process.Sign FOREIGN KEY
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessSign_FK] FOREIGN KEY([Sign])
REFERENCES [dbo].[Sign] ([Id]);
--Process.Account FOREIGN KEY
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessAccount_FK] FOREIGN KEY([Account])
REFERENCES [dbo].[Account] ([Id]);
--Process.Log FOREIGN KEY
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessLog_FK] FOREIGN KEY([Log])
REFERENCES [dbo].[Log] ([Id]);
--Process.Log1 FOREIGN KEY
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessLog1_FK] FOREIGN KEY([Log1])
REFERENCES [dbo].[Log] ([Id]);
--Process.Process FOREIGN KEY
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessProcess_FK] FOREIGN KEY([Process])
REFERENCES [dbo].[Process] ([Id]);
--Process.Process1 FOREIGN KEY
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessProcess1_FK] FOREIGN KEY([Process1])
REFERENCES [dbo].[Process] ([Id]);
--Process.Asset FOREIGN KEY
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessAsset_FK] FOREIGN KEY([Asset])
REFERENCES [dbo].[Asset] ([Id]);
--Process.Deal FOREIGN KEY
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessDeal_FK] FOREIGN KEY([Deal])
REFERENCES [dbo].[Deal] ([Id]);
--Process.Item FOREIGN KEY
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessItem_FK] FOREIGN KEY([Item])
REFERENCES [dbo].[Item] ([Id]);
--Process.Tax FOREIGN KEY
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessTax_FK] FOREIGN KEY([Tax])
REFERENCES [dbo].[Tax] ([Id]);
--Process.Price FOREIGN KEY
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessPrice_FK] FOREIGN KEY([Price])
REFERENCES [dbo].[Price] ([Id]);
--Process.Role FOREIGN KEY
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id]);
--Process.Info FOREIGN KEY
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id]);
--Process.Meter FOREIGN KEY
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessMeter_FK] FOREIGN KEY([Meter])
REFERENCES [dbo].[Meter] ([Id]);
--Process.Unit FOREIGN KEY
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id]);
--Process.Mark FOREIGN KEY
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessMark_FK] FOREIGN KEY([Mark])
REFERENCES [dbo].[Mark] ([Id]);

--Role
--Role.Parent FOREIGN KEY
ALTER TABLE [dbo].[Role]  WITH CHECK ADD  CONSTRAINT [RoleParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Role] ([Id]);
--Role.Face1 FOREIGN KEY
ALTER TABLE [dbo].[Role]  WITH CHECK ADD  CONSTRAINT [RoleFace1_FK] FOREIGN KEY([Face1])
REFERENCES [dbo].[Face] ([Id]);
--Role.Face2 FOREIGN KEY
ALTER TABLE [dbo].[Role]  WITH CHECK ADD  CONSTRAINT [RoleFace2_FK] FOREIGN KEY([Face2])
REFERENCES [dbo].[Face] ([Id]);
--Role.Face FOREIGN KEY
ALTER TABLE [dbo].[Role]  WITH CHECK ADD  CONSTRAINT [RoleFace_FK] FOREIGN KEY([Face])
REFERENCES [dbo].[Face] ([Id]);
--Role.Slice FOREIGN KEY
ALTER TABLE [dbo].[Role]  WITH CHECK ADD  CONSTRAINT [RoleSlice_FK] FOREIGN KEY([Slice])
REFERENCES [dbo].[Slice] ([Id]);
--Role.Geo FOREIGN KEY
ALTER TABLE [dbo].[Role]  WITH CHECK ADD  CONSTRAINT [RoleGeo_FK] FOREIGN KEY([Geo])
REFERENCES [dbo].[Geo] ([Id]);
--Role.Account FOREIGN KEY
ALTER TABLE [dbo].[Role]  WITH CHECK ADD  CONSTRAINT [RoleAccount_FK] FOREIGN KEY([Account])
REFERENCES [dbo].[Account] ([Id]);
--Role.Role FOREIGN KEY
ALTER TABLE [dbo].[Role]  WITH CHECK ADD  CONSTRAINT [RoleRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id]);
--Role.Info FOREIGN KEY
ALTER TABLE [dbo].[Role]  WITH CHECK ADD  CONSTRAINT [RoleInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id]);
--Role.Unit FOREIGN KEY
ALTER TABLE [dbo].[Role]  WITH CHECK ADD  CONSTRAINT [RoleUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id]);
--Role.Mark FOREIGN KEY
ALTER TABLE [dbo].[Role]  WITH CHECK ADD  CONSTRAINT [RoleMark_FK] FOREIGN KEY([Mark])
REFERENCES [dbo].[Mark] ([Id]);

--Sign
--Sign.Parent FOREIGN KEY
ALTER TABLE [dbo].[Sign]  WITH CHECK ADD  CONSTRAINT [SignParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Sign] ([Id]);
--Sign.Face1 FOREIGN KEY
ALTER TABLE [dbo].[Sign]  WITH CHECK ADD  CONSTRAINT [SignFace1_FK] FOREIGN KEY([Face1])
REFERENCES [dbo].[Face] ([Id]);
--Sign.Face2 FOREIGN KEY
ALTER TABLE [dbo].[Sign]  WITH CHECK ADD  CONSTRAINT [SignFace2_FK] FOREIGN KEY([Face2])
REFERENCES [dbo].[Face] ([Id]);
--Sign.Face FOREIGN KEY
ALTER TABLE [dbo].[Sign]  WITH CHECK ADD  CONSTRAINT [SignFace_FK] FOREIGN KEY([Face])
REFERENCES [dbo].[Face] ([Id]);
--Sign.Slice FOREIGN KEY
ALTER TABLE [dbo].[Sign]  WITH CHECK ADD  CONSTRAINT [SignSlice_FK] FOREIGN KEY([Slice])
REFERENCES [dbo].[Slice] ([Id]);
--Sign.Geo FOREIGN KEY
ALTER TABLE [dbo].[Sign]  WITH CHECK ADD  CONSTRAINT [SignGeo_FK] FOREIGN KEY([Geo])
REFERENCES [dbo].[Geo] ([Id]);
--Sign.Sign FOREIGN KEY
ALTER TABLE [dbo].[Sign]  WITH CHECK ADD  CONSTRAINT [SignSign_FK] FOREIGN KEY([Sign])
REFERENCES [dbo].[Sign] ([Id]);
--Sign.Account FOREIGN KEY
ALTER TABLE [dbo].[Sign]  WITH CHECK ADD  CONSTRAINT [SignAccount_FK] FOREIGN KEY([Account])
REFERENCES [dbo].[Account] ([Id]);
--Sign.Role FOREIGN KEY
ALTER TABLE [dbo].[Sign]  WITH CHECK ADD  CONSTRAINT [SignRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id]);
--Sign.Info FOREIGN KEY
ALTER TABLE [dbo].[Sign]  WITH CHECK ADD  CONSTRAINT [SignInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id]);
--Sign.Unit FOREIGN KEY
ALTER TABLE [dbo].[Sign]  WITH CHECK ADD  CONSTRAINT [SignUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id]);
--Sign.Mark FOREIGN KEY
ALTER TABLE [dbo].[Sign]  WITH CHECK ADD  CONSTRAINT [SignMark_FK] FOREIGN KEY([Mark])
REFERENCES [dbo].[Mark] ([Id]);

--Slice
--Slice.Parent FOREIGN KEY
ALTER TABLE [dbo].[Slice]  WITH CHECK ADD  CONSTRAINT [SliceParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Slice] ([Id]);
--Slice.Face1 FOREIGN KEY
ALTER TABLE [dbo].[Slice]  WITH CHECK ADD  CONSTRAINT [SliceFace1_FK] FOREIGN KEY([Face1])
REFERENCES [dbo].[Face] ([Id]);
--Slice.Face2 FOREIGN KEY
ALTER TABLE [dbo].[Slice]  WITH CHECK ADD  CONSTRAINT [SliceFace2_FK] FOREIGN KEY([Face2])
REFERENCES [dbo].[Face] ([Id]);
--Slice.Face FOREIGN KEY
ALTER TABLE [dbo].[Slice]  WITH CHECK ADD  CONSTRAINT [SliceFace_FK] FOREIGN KEY([Face])
REFERENCES [dbo].[Face] ([Id]);
--Slice.Slice FOREIGN KEY
ALTER TABLE [dbo].[Slice]  WITH CHECK ADD  CONSTRAINT [SliceSlice_FK] FOREIGN KEY([Slice])
REFERENCES [dbo].[Slice] ([Id]);
--Slice.Geo FOREIGN KEY
ALTER TABLE [dbo].[Slice]  WITH CHECK ADD  CONSTRAINT [SliceGeo_FK] FOREIGN KEY([Geo])
REFERENCES [dbo].[Geo] ([Id]);
--Slice.Account FOREIGN KEY
ALTER TABLE [dbo].[Slice]  WITH CHECK ADD  CONSTRAINT [SliceAccount_FK] FOREIGN KEY([Account])
REFERENCES [dbo].[Account] ([Id]);
--Slice.Role FOREIGN KEY
ALTER TABLE [dbo].[Slice]  WITH CHECK ADD  CONSTRAINT [SliceRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id]);
--Slice.Info FOREIGN KEY
ALTER TABLE [dbo].[Slice]  WITH CHECK ADD  CONSTRAINT [SliceInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id]);
--Slice.Unit FOREIGN KEY
ALTER TABLE [dbo].[Slice]  WITH CHECK ADD  CONSTRAINT [SliceUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id]);
--Slice.Mark FOREIGN KEY
ALTER TABLE [dbo].[Slice]  WITH CHECK ADD  CONSTRAINT [SliceMark_FK] FOREIGN KEY([Mark])
REFERENCES [dbo].[Mark] ([Id]);

--Tax
--Tax.Parent FOREIGN KEY
ALTER TABLE [dbo].[Tax]  WITH CHECK ADD  CONSTRAINT [TaxParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Tax] ([Id]);
--Tax.Face1 FOREIGN KEY
ALTER TABLE [dbo].[Tax]  WITH CHECK ADD  CONSTRAINT [TaxFace1_FK] FOREIGN KEY([Face1])
REFERENCES [dbo].[Face] ([Id]);
--Tax.Face2 FOREIGN KEY
ALTER TABLE [dbo].[Tax]  WITH CHECK ADD  CONSTRAINT [TaxFace2_FK] FOREIGN KEY([Face2])
REFERENCES [dbo].[Face] ([Id]);
--Tax.Face FOREIGN KEY
ALTER TABLE [dbo].[Tax]  WITH CHECK ADD  CONSTRAINT [TaxFace_FK] FOREIGN KEY([Face])
REFERENCES [dbo].[Face] ([Id]);
--Tax.Slice FOREIGN KEY
ALTER TABLE [dbo].[Tax]  WITH CHECK ADD  CONSTRAINT [TaxSlice_FK] FOREIGN KEY([Slice])
REFERENCES [dbo].[Slice] ([Id]);
--Tax.Geo FOREIGN KEY
ALTER TABLE [dbo].[Tax]  WITH CHECK ADD  CONSTRAINT [TaxGeo_FK] FOREIGN KEY([Geo])
REFERENCES [dbo].[Geo] ([Id]);
--Tax.Account FOREIGN KEY
ALTER TABLE [dbo].[Tax]  WITH CHECK ADD  CONSTRAINT [TaxAccount_FK] FOREIGN KEY([Account])
REFERENCES [dbo].[Account] ([Id]);
--Tax.Tax FOREIGN KEY
ALTER TABLE [dbo].[Tax]  WITH CHECK ADD  CONSTRAINT [TaxTax_FK] FOREIGN KEY([Tax])
REFERENCES [dbo].[Tax] ([Id]);
--Tax.Role FOREIGN KEY
ALTER TABLE [dbo].[Tax]  WITH CHECK ADD  CONSTRAINT [TaxRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id]);
--Tax.Info FOREIGN KEY
ALTER TABLE [dbo].[Tax]  WITH CHECK ADD  CONSTRAINT [TaxInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id]);
--Tax.Unit FOREIGN KEY
ALTER TABLE [dbo].[Tax]  WITH CHECK ADD  CONSTRAINT [TaxUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id]);
--Tax.Mark FOREIGN KEY
ALTER TABLE [dbo].[Tax]  WITH CHECK ADD  CONSTRAINT [TaxMark_FK] FOREIGN KEY([Mark])
REFERENCES [dbo].[Mark] ([Id]);


--Unit
--Unit.Parent FOREIGN KEY
ALTER TABLE [dbo].[Unit]  WITH CHECK ADD  CONSTRAINT [UnitParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Unit] ([Id]);
--Unit.Face1 FOREIGN KEY
ALTER TABLE [dbo].[Unit]  WITH CHECK ADD  CONSTRAINT [UnitFace1_FK] FOREIGN KEY([Face1])
REFERENCES [dbo].[Face] ([Id]);
--Unit.Face2 FOREIGN KEY
ALTER TABLE [dbo].[Unit]  WITH CHECK ADD  CONSTRAINT [UnitFace2_FK] FOREIGN KEY([Face2])
REFERENCES [dbo].[Face] ([Id]);
--Unit.Face FOREIGN KEY
ALTER TABLE [dbo].[Unit]  WITH CHECK ADD  CONSTRAINT [UnitFace_FK] FOREIGN KEY([Face])
REFERENCES [dbo].[Face] ([Id]);
--Unit.Slice FOREIGN KEY
ALTER TABLE [dbo].[Unit]  WITH CHECK ADD  CONSTRAINT [UnitSlice_FK] FOREIGN KEY([Slice])
REFERENCES [dbo].[Slice] ([Id]);
--Unit.Geo FOREIGN KEY
ALTER TABLE [dbo].[Unit]  WITH CHECK ADD  CONSTRAINT [UnitGeo_FK] FOREIGN KEY([Geo])
REFERENCES [dbo].[Geo] ([Id]);
--Unit.Account FOREIGN KEY
ALTER TABLE [dbo].[Unit]  WITH CHECK ADD  CONSTRAINT [UnitAccount_FK] FOREIGN KEY([Account])
REFERENCES [dbo].[Account] ([Id]);
--Unit.Role FOREIGN KEY
ALTER TABLE [dbo].[Unit]  WITH CHECK ADD  CONSTRAINT [UnitRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id]);
--Unit.Info FOREIGN KEY
ALTER TABLE [dbo].[Unit]  WITH CHECK ADD  CONSTRAINT [UnitInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id]);
--Unit.Unit FOREIGN KEY
ALTER TABLE [dbo].[Unit]  WITH CHECK ADD  CONSTRAINT [UnitUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id]);
--Unit.Mark FOREIGN KEY
ALTER TABLE [dbo].[Unit]  WITH CHECK ADD  CONSTRAINT [UnitMark_FK] FOREIGN KEY([Mark])
REFERENCES [dbo].[Mark] ([Id]);


--Report
--Report.Parent FOREIGN KEY
ALTER TABLE [dbo].[Report]  WITH CHECK ADD  CONSTRAINT [ReportParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Report] ([Id]);
--Report.Face1 FOREIGN KEY
ALTER TABLE [dbo].[Report]  WITH CHECK ADD  CONSTRAINT [ReportFace1_FK] FOREIGN KEY([Face1])
REFERENCES [dbo].[Face] ([Id]);
--Report.Face2 FOREIGN KEY
ALTER TABLE [dbo].[Report]  WITH CHECK ADD  CONSTRAINT [ReportFace2_FK] FOREIGN KEY([Face2])
REFERENCES [dbo].[Face] ([Id]);
--Report.Face FOREIGN KEY
ALTER TABLE [dbo].[Report]  WITH CHECK ADD  CONSTRAINT [ReportFace_FK] FOREIGN KEY([Face])
REFERENCES [dbo].[Face] ([Id]);
--Report.Slice FOREIGN KEY
ALTER TABLE [dbo].[Report]  WITH CHECK ADD  CONSTRAINT [ReportSlice_FK] FOREIGN KEY([Slice])
REFERENCES [dbo].[Slice] ([Id]);
--Report.Geo FOREIGN KEY
ALTER TABLE [dbo].[Report]  WITH CHECK ADD  CONSTRAINT [ReportGeo_FK] FOREIGN KEY([Geo])
REFERENCES [dbo].[Geo] ([Id]);
--Report.Account FOREIGN KEY
ALTER TABLE [dbo].[Report]  WITH CHECK ADD  CONSTRAINT [ReportAccount_FK] FOREIGN KEY([Account])
REFERENCES [dbo].[Account] ([Id]);
--Report.Report FOREIGN KEY
ALTER TABLE [dbo].[Report]  WITH CHECK ADD  CONSTRAINT [ReportReport_FK] FOREIGN KEY([Report])
REFERENCES [dbo].[Report] ([Id]);
--Report.Role FOREIGN KEY
ALTER TABLE [dbo].[Report]  WITH CHECK ADD  CONSTRAINT [ReportRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id]);
--Report.Info FOREIGN KEY
ALTER TABLE [dbo].[Report]  WITH CHECK ADD  CONSTRAINT [ReportInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id]);
--Report.Unit FOREIGN KEY
ALTER TABLE [dbo].[Report]  WITH CHECK ADD  CONSTRAINT [ReportUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id]);
--Report.Mark FOREIGN KEY
ALTER TABLE [dbo].[Report]  WITH CHECK ADD  CONSTRAINT [ReportMark_FK] FOREIGN KEY([Mark])
REFERENCES [dbo].[Mark] ([Id]);
