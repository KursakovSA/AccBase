use BaseN2

DBCC CHECKDB
exec sp_msforeachtable N'DBCC DBREINDEX (''?'')'

DBCC FREEPROCCACHE

exec sp_msforeachtable N'UPDATE STATISTICS ? WITH FULLSCAN'
DBCC UPDATEUSAGE (BaseN2)