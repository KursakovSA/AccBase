DELETE from Log Where Description is NULL
select code,description from Log