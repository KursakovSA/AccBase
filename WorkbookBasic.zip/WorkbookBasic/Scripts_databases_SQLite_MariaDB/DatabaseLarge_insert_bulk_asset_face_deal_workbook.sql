
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;
--нагенерим Asset1
create table if not exists Asset1 as
with recursive Asset1(Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, Unit, More) as (
    select '1', NULL, current_timestamp, current_timestamp, 'Asset.', 'Asset.Data', 'Geo.Qazaqstan', 'Role.Asset.Good', 'Info.Asset.Asset', 'Unit.Piece', '{"Role.Generic.Code": "Asset.Basic"}'
    union all
    select
        cast(cast(Asset1.Id as integer) + 1 as text) as Id,
        cast(cast(Asset1.Id as integer) as text) as Parent,
        current_timestamp as Date1,
        current_timestamp as Date2,
        'Наименование товара ' || cast(Asset1.Id+1 as text) as Code,
        'Полное наименование товара ' || cast(Asset1.Id+1 as text) as Description,
         'Geo.Qazaqstan' as Geo, 
         'Role.Asset.Good' as Role,
         'Info.Asset.Asset' as Info,
         'Unit.Piece' as Unit,
         '{"Role.Generic.Code": "Asset.Basic"}' as More
    from Asset1
    limit 1000  --1 тыс активов  
)
select * from Asset1;

--закинем все строки из Asset1 в Asset
insert into Asset select * from Asset1;

--удалим Asset1 теперь она не нужна
drop table Asset1;
COMMIT TRANSACTION;
PRAGMA foreign_keys = on;


PRAGMA foreign_keys = off;
BEGIN TRANSACTION;
--нагенерим Face1
create table if not exists Face1 as
with recursive Face1(Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) as (
    select '1', NULL, current_timestamp, current_timestamp, 'Face.', 'Face.Data', 'Geo.Qazaqstan', 'Role.Face.Customer', 'Info.Face.Corp', '{"Role.Generic.Code": "Face.Basic"}'
    union all
    select
        cast(cast(Face1.Id as integer) + 1 as text) as Id,
        cast(cast(Face1.Id as integer) as text) as Parent,
        current_timestamp as Date1,
        current_timestamp as Date2,
        'Наименование лица ' || cast(Face1.Id+1 as text) as Code,
        'Полное наименование лица ' || cast(Face1.Id+1 as text) as Description,
        'Geo.Qazaqstan' as Geo, 
        'Role.Face.Customer' as Role,
        'Info.Face.Corp' as Info,
        '{"Role.Generic.Code": "Face.Basic"}' as More
    from Face1
    limit 10000  --10 тыс лиц
)
select * from Face1;

--закинем все строки из Face1 в Face
insert into Face select * from Face1;

--удалим Face1 теперь она не нужна
drop table Face1;
COMMIT TRANSACTION;
PRAGMA foreign_keys = on;


PRAGMA foreign_keys = off;
BEGIN TRANSACTION;
--нагенерим Deal1
create table if not exists Deal1 as
with recursive Deal1(Id, Parent, Face1, Face2, Face, Date1, Date2, Code, Description, Geo, Role, Info, More) as (
    select '1', NULL, 'Face.FA1.StaffTable.ChiefAccountant', 'Face.FA1.StaffTable.ChiefAccountant', 'Face.FA1.StaffTable.ChiefAccountant', current_timestamp, current_timestamp, 'Deal.', 'Deal.Data', 'Geo.Qazaqstan', 'Role.Deal.Basic', 'Info.Deal.Basic', '{"Role.Generic.Code": "Deal.Basic"}'
	union all
    select
        cast(cast(Deal1.Id as integer) + 1 as text) as Id,
        cast(cast(Deal1.Id as integer) as text) as Parent,
		--'Face.FA1.StaffTable.ChiefAccountant' as Face1,  --пробьем длинное название просто ради самой длины
		cast(abs(random() % 10000) as text) as Face1,
        cast(abs(random() % 10000) as text) as Face2,
        cast(abs(random() % 10000) as text) as Face,
        current_timestamp as Date1,
        current_timestamp as Date2,
        'Наименование договора ' || cast(Deal1.Id+1 as text) as Code,
        'Полное наименование договора ' || cast(Deal1.Id+1 as text) as Description,
         'Geo.Qazaqstan' as Geo, 
         'Role.Deal.Basic' as Role,
         'Info.Deal.Basic' as Info,
         '{"Role.Generic.Code": "Deal.Basic"}' as More
    from Deal1
    limit 10000   --10 тыс договоров
)
select * from Deal1;

--закинем все строки из Deal1 в Deal
insert into Deal select * from Deal1;

--удалим Deal1 теперь она не нужна
drop table Deal1;
COMMIT TRANSACTION;
PRAGMA foreign_keys = on;


PRAGMA foreign_keys = off;
BEGIN TRANSACTION;
--нагенерим Workbook1
create table if not exists Workbook1 as
with recursive Workbook1(Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Geo, Sign, Account, Process, Asset, Deal, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) as (
	select '1', NULL, 'Face.FA1', 'Face.FA1.StaffTable.ChiefAccountant', 'Face.FA1.User1', 'Slice.Accounting', 
	current_timestamp, current_timestamp, 'Workbook.', 'Workbook.Data', 'Geo.Qazaqstan', 'Sign.Acct.Dt', 'Account.1330', 
	'Process.Buy.5 (Arrival)', cast(abs(random() % 1000) as text), cast(abs(random() % 10000) as text), 
	'Price.Basic', 'Role.Workbook.Line1Manual', 'Info.Workbook.Level1.Quantity', 
	'Meter.Quantity', cast(abs(random() % 100000) as text), 'Unit.KZT', '{"Role.Generic.Code": "Workbook.Basic"}', 'Mark.CD'
    
	union all
    select
        cast(cast(Workbook1.Id as integer) + 1 as text) as Id,
        cast(cast(Workbook1.Id as integer) as text) as Parent,
        'Face.FA1' as Face1,
        cast(abs(random() % 10000) as text) as Face2,
        'Face.FA1.User1' as Face,
        'Slice.Accounting' as Slice, 
        current_timestamp as Date1,
        current_timestamp as Date2,
        'Рабочая книга ' || cast(cast(Workbook1.Id as integer)+1 as text) as Code,
        'Рабочая книга ' || cast(cast(Workbook1.Id as integer)+1 as text) as Description,
        'Geo.Qazaqstan' as Geo,
        'Sign.Acct.Dt' as Sign,   
        'Account.1330' as Account,  
        'Process.Buy.5 (Arrival)' as Process,  
        cast(abs(random() % 1000) as text) as Asset,  --случайное число от 1 до 1 тыс    
        cast(abs(random() % 10000) as text) as Deal,  --случайное число от 1 до 10 тыс
        'Price.Basic' as Price,
        'Role.Workbook.Line1Manual' as Role, 
        'Info.Workbook.Level1.Quantity' as Info,
        'Meter.Quantity' as Meter,
        cast(abs(random() % 100000) as text) as MeterValue,  --случайная сумма в диапазоне от 1 до 1 млн   
        'Unit.KZT' as Unit,
        '{"Role.Generic.Code": "Workbook.Basic"}' as More,
        'Mark.CD' as Mark  
    from Workbook1
    limit 1500000   --1.5 млн записей
)
select * from Workbook1;

--закинем все строки из Workbook1 в Workbook
insert into Workbook select * from Workbook1;

--удалим Workbook1 теперь она не нужна
drop table Workbook1;
COMMIT TRANSACTION;
PRAGMA foreign_keys = on;

---почему запись именно 1.5 млн физических записей тестируем в Workbook? Все просто, вот расчет ---
---берем для обычного (простого) ТОО примерно 5 накладных в день,  по 5 логических строк в накладной 
---это будет (5 * 5 физич строки Workbook) + 3-5 физ строк Workbook на шапку
---почему 5 физ строк Workbook на 1 логическую строку накладной - потому что отдельные строки Workbook на кол-ва, цены, суммы, НДС и себест-ть   
---тогда получается примерно 25 + 5 = 30 физических строк Workbook на 1 накладную реализации, сюда же входит СФ одной строкой (номер, дата)
---столько же инфы сколько и накладные, займут договора и\или счета, тогда ---   
---30 * 5 * 2 = 300 физ строк Workbook в день   
---300 * 30 дней = 9000 физ строк Workbook в месяц, берем с запасом 30 дней, а не 22 рабочих 
---хорошо, для круглой цифры принимаем 10000 физ строк Workbook в месяц     
---добавляем зарплату, прочие операции, цены товаров и т.д. и принимаем 12000 физ строк Workbook в месяц  
---12000 * 12 = 144000 физ строк Workbook в год   
---берем для ровного счета 150000 физ строк Workbook в год (учтем данные контрагентов, цен и т.д. в Workbook)
---таким образом для 10 лет работы ТОО нужно 150000 * 10 = 1.5 млн физических строк Workbook примерно
---
---результат таков - заполнение 1.5 млн физ строк таблицы Workbook занимает примерно 150 - 200 сек (notebook, Celeron, SSD, SqliteStudio)  
---и это при усложненный условиях заполнения, когда строка Workbook полностью заполняется реквизитами, хотя в обычных условиях 
---практически половина полей обычно должны быть пусты (Item, Price и т.д.)
---
---выборка итогового оборота по товару (Asset) с индексом допустим, 532, занимает 0.8 - 1.2 сек именно в этой 10-летней базе (индекс включен)
---почему нужно выбрать именно итоговый оборот - чтобы рассчитать сальдо по товару на текущий момент (например, при отпуске товара)