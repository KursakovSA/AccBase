﻿-- Курсаков С.А. https://github.com/KursakovSA/AccBase 

PRAGMA journal_mode=WAL;
PRAGMA synchronous = NORMAL;

PRAGMA foreign_keys = off;

CREATE TABLE IF NOT EXISTS Account(
	Id VARCHAR(255) PRIMARY KEY,
	Parent VARCHAR(255) references Account(Id),
	Date1 TEXT,
	Date2 TEXT,
	Code TEXT,
	Description TEXT,
    Role VARCHAR(255) references Role(Id),
    Sign VARCHAR(255) references Sign(Id),
	More TEXT
 );

CREATE TABLE IF NOT EXISTS Asset(
	Id VARCHAR(255) PRIMARY KEY,
	Parent VARCHAR(255) references Asset(Id),
	Date1 TEXT,
	Date2 TEXT,
	Code TEXT,
	Description TEXT,
	Geo VARCHAR(255) references Geo(Id),
	Role VARCHAR(255) references Role(Id),
	Info VARCHAR(255) references Info(Id),
	Unit VARCHAR(255) references Unit(Id),
	More TEXT,
	Mark VARCHAR(255) references Mark(Id)
 );

CREATE TABLE IF NOT EXISTS Deal(
	Id VARCHAR(255) PRIMARY KEY,
	Parent VARCHAR(255) references Deal(Id),
	Face1 VARCHAR(255) references Face(Id),
	Face2 VARCHAR(255) references Face(Id),
	Face VARCHAR(255) references Face(Id),
	Date1 TEXT,
	Date2 TEXT,
	Code TEXT,
	Description TEXT,
	Geo VARCHAR(255) references Geo(Id),
	Role VARCHAR(255) references Role(Id),
	Info VARCHAR(255) references Info(Id),
	More TEXT,
	Mark VARCHAR(255) references Mark(Id)
 );

CREATE TABLE IF NOT EXISTS Debt(
	Id VARCHAR(255) PRIMARY KEY,
	Parent VARCHAR(255) references Debt(Id),
	Date1 TEXT,
	Date2 TEXT,
	Code TEXT,
	Description TEXT,
	Geo VARCHAR(255) references Geo(Id),
	Role VARCHAR(255) references Role(Id),
	Info VARCHAR(255) references Info(Id),
	More TEXT
  ); 
 
CREATE TABLE IF NOT EXISTS Face(
	Id VARCHAR(255) PRIMARY KEY,
	Parent VARCHAR(255) references Face(Id),
	Date1 TEXT,
	Date2 TEXT,
	Code TEXT,
	Description TEXT,
	Geo VARCHAR(255) references Geo(Id),
	Role VARCHAR(255) references Role(Id),
	Info VARCHAR(255) references Info(Id),
	More TEXT,
	Mark VARCHAR(255) references Mark(Id)
 );
 
CREATE TABLE IF NOT EXISTS Geo(
	Id VARCHAR(255) PRIMARY KEY,
	Parent VARCHAR(255) references Geo(Id),
	Date1 TEXT,
	Date2 TEXT,
	Code TEXT,
	Description TEXT,
    Role VARCHAR(255) references Role(Id),
	More TEXT
 );
 
CREATE TABLE IF NOT EXISTS Info(
	Id VARCHAR(255) PRIMARY KEY,
	Parent VARCHAR(255) references Info(Id),
	Date1 TEXT,
	Date2 TEXT,
	Code TEXT,
	Description TEXT,
	More TEXT
 );
 
CREATE TABLE IF NOT EXISTS Item(
	Id VARCHAR(255) PRIMARY KEY,
	Parent VARCHAR(255) references Item(Id),
	Date1 TEXT,
	Date2 TEXT,
	Code TEXT,
	Description TEXT,
	More TEXT
 );
 
CREATE TABLE IF NOT EXISTS Mark(
	Id VARCHAR(255) PRIMARY KEY,
	Parent VARCHAR(255) references Mark(Id),
	Date1 TEXT,
	Date2 TEXT,
	Code TEXT,
	Description TEXT,
	More TEXT
 );
 
CREATE TABLE IF NOT EXISTS Meter(
	Id VARCHAR(255) PRIMARY KEY,
	Parent VARCHAR(255) references Meter(Id),
	Date1 TEXT,
	Date2 TEXT,
	Code TEXT,
	Description TEXT,
	More TEXT
 );
 
CREATE TABLE IF NOT EXISTS Price(
	Id VARCHAR(255) PRIMARY KEY,
	Parent VARCHAR(255) references Price(Id),
	Date1 TEXT,
	Date2 TEXT,
	Code TEXT,
	Description TEXT,
	Role VARCHAR(255) references Role(Id),
	More TEXT
 );
 
CREATE TABLE IF NOT EXISTS Process(
	Id VARCHAR(255) PRIMARY KEY,
	Parent VARCHAR(255) references Process(Id),
	Face1 VARCHAR(255) references Face(Id),
	Face2 VARCHAR(255) references Face(Id),
	Face VARCHAR(255) references Face(Id),
	Slice VARCHAR(255) references Slice(Id),
	Date1 TEXT,
	Date2 TEXT,
	Code TEXT,
	Description TEXT,
	Geo VARCHAR(255) references Geo(Id),
	[Sign] VARCHAR(255) references Sign(Id),
	Account VARCHAR(255) references Account(Id),
    Asset VARCHAR(255) references Asset(Id),
    Deal VARCHAR(255) references Deal(Id),
    Item VARCHAR(255) references Item(Id),
	Debt VARCHAR(255) references Debt(Id),
	Role VARCHAR(255) references Role(Id),
	Info VARCHAR(255) references Info(Id),
	Meter VARCHAR(255) references Meter(Id),
	MeterValue TEXT,
	Unit VARCHAR(255) references Unit(Id),
	More TEXT,
	Mark VARCHAR(255) references Mark(Id)
 );
 
CREATE TABLE IF NOT EXISTS Role(
	Id VARCHAR(255) PRIMARY KEY,
	Parent VARCHAR(255) references Role(Id),
	Date1 TEXT,
	Date2 TEXT,
	Code TEXT,
	Description TEXT,
	More TEXT
 );
 
CREATE TABLE IF NOT EXISTS Sign(
	Id VARCHAR(255) PRIMARY KEY,
	Parent VARCHAR(255) references Sign(Id),
	Date1 TEXT,
	Date2 TEXT,
	Code TEXT,
	Description TEXT,
	More TEXT
 );
 
CREATE TABLE IF NOT EXISTS Slice(
	Id VARCHAR(255) PRIMARY KEY,
	Parent VARCHAR(255) references Slice(Id),
	Date1 TEXT,
	Date2 TEXT,
	Code TEXT,
	Description TEXT,
	More TEXT
 );
 
CREATE TABLE IF NOT EXISTS Unit(
	Id VARCHAR(255) PRIMARY KEY,
	Parent VARCHAR(255) references Unit(Id),
	Date1 TEXT,
	Date2 TEXT,
	Code TEXT,
	Description TEXT,
	Role VARCHAR(255) references Role(Id),
	More TEXT
 );
 
CREATE TABLE IF NOT EXISTS Workbook(
	Id VARCHAR(255) PRIMARY KEY,
	Parent VARCHAR(255) references Workbook(Id),
	Face1 VARCHAR(255) references Face(Id),
	Face2 VARCHAR(255) references Face(Id),
	Face VARCHAR(255) references Face(Id),
	Slice VARCHAR(255) references Slice(Id),
	Date1 TEXT,
	Date2 TEXT,
	Code TEXT,
	Description TEXT,
	Geo VARCHAR(255) references Geo(Id),
	[Sign] VARCHAR(255) references Sign(Id),
	Account VARCHAR(255) references Account(Id),
	Process VARCHAR(255) references Process(Id),
    Asset VARCHAR(255) references Asset(Id),
    Deal VARCHAR(255) references Deal(Id),
	Role VARCHAR(255) references Role(Id),
	Info VARCHAR(255) references Info(Id),
	Meter VARCHAR(255) references Meter(Id),
	MeterValue TEXT,
	Unit VARCHAR(255) references Unit(Id),
	More TEXT,
	Mark VARCHAR(255) references Mark(Id)
 );
 
 CREATE INDEX IF NOT EXISTS AssetParent ON Asset (
    Parent
);
 
CREATE INDEX IF NOT EXISTS AssetDate1 ON Asset (
    Date1
);

CREATE INDEX IF NOT EXISTS AssetCode ON Asset (
    Code
);
 
CREATE INDEX IF NOT EXISTS AssetDescription ON Asset (
    Description
);

CREATE INDEX IF NOT EXISTS AssetRole ON Asset (
    Role
);

CREATE INDEX IF NOT EXISTS AssetInfo ON Asset (
    Info
);

CREATE INDEX IF NOT EXISTS DealParent ON Deal (
    Parent
);

CREATE INDEX IF NOT EXISTS DealFace1 ON Deal (
    Face1
);

CREATE INDEX IF NOT EXISTS DealFace2 ON Deal (
    Face2
);

CREATE INDEX IF NOT EXISTS DealFace ON Deal (
    Face
);

CREATE INDEX IF NOT EXISTS DealCode ON Deal (
    Code
);
 
CREATE INDEX IF NOT EXISTS DealDescription ON Deal (
    Description
);

CREATE INDEX IF NOT EXISTS DealRole ON Deal (
    Role
);

CREATE INDEX IF NOT EXISTS DealInfo ON Deal (
    Info
);

CREATE INDEX IF NOT EXISTS FaceParent ON Face (
    Parent
);

CREATE INDEX IF NOT EXISTS FaceDate1 ON Face (
    Date1
);

CREATE INDEX IF NOT EXISTS FaceCode ON Face (
    Code
);
 
CREATE INDEX IF NOT EXISTS FaceDescription ON Face (
    Description
);

CREATE INDEX IF NOT EXISTS FaceRole ON Face (
    Role
);

CREATE INDEX IF NOT EXISTS FaceInfo ON Face (
    Info
);
 
CREATE INDEX IF NOT EXISTS WorkbookParent ON Workbook (
    Parent
);

CREATE INDEX IF NOT EXISTS WorkbookFace1 ON Workbook (
    Face1
);

CREATE INDEX IF NOT EXISTS WorkbookFace2 ON Workbook (
    Face2
);

CREATE INDEX IF NOT EXISTS WorkbookFace ON Workbook (
    Face
);

CREATE INDEX IF NOT EXISTS WorkbookDate1 ON Workbook (
    Date1
);

CREATE INDEX IF NOT EXISTS WorkbookCode ON Workbook (
    Code
);
 
CREATE INDEX IF NOT EXISTS WorkbookDescription ON Workbook (
    Description
);

CREATE INDEX IF NOT EXISTS WorkbookSign ON Workbook (
    Sign
);

CREATE INDEX IF NOT EXISTS WorkbookAccount ON Workbook (
    Account
);

CREATE INDEX IF NOT EXISTS WorkbookProcess ON Workbook (
    Process
);

CREATE INDEX IF NOT EXISTS WorkbookDeal ON Workbook (
    Deal
);

CREATE INDEX IF NOT EXISTS WorkbookAsset ON Workbook (
    Asset
);

CREATE INDEX IF NOT EXISTS WorkbookRole ON Workbook (
    Role
);

CREATE INDEX IF NOT EXISTS WorkbookInfo ON Workbook (
    Info
);