use DatabaseTemplate

DBCC CHECKDB
exec sp_msforeachtable N'DBCC DBREINDEX (''?'')'

DBCC FREEPROCCACHE

exec sp_msforeachtable N'UPDATE STATISTICS ? WITH FULLSCAN'
DBCC UPDATEUSAGE (DatabaseTemplate)