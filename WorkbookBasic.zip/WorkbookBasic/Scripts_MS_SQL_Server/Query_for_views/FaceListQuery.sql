SELECT [T1].[Id], 

[T1].[Parent], 
[T4].[Code] AS [ParentCode],
[T4].[Description] AS [ParentDescription],

[T1].[Date1] AS [Date1],

[T1].[Date2] AS [Date2],

[T1].[Code] AS [Code],

[T1].[Description] AS [Description],

[T1].[Geo], 
[T8].[Code] AS [GeoCode], 
[T8].[Description] AS [GeoDescription],

[T1].[Role], 
[T10].[Code] AS [RoleCode], 
[T10].[Description] AS [RoleDescription],

[T1].[Info], 
[T11].[Code] AS [InfoCode],
[T11].[Description] AS [InfoDescription],

[T1].[More] AS [More]

FROM [dbo].[Face] AS [T1]

LEFT JOIN [dbo].[Face] AS [T4] ON [T1].[Parent]=[T4].[Id]
LEFT JOIN [dbo].[Geo] AS [T8] ON [T1].[Geo]=[T8].[Id]
LEFT JOIN [dbo].[Role] AS [T10] ON [T1].[Role]=[T10].[Id] 
LEFT JOIN [dbo].[Info] AS [T11] ON [T1].[Info]=[T11].[Id] 