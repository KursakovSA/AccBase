SELECT [T1].[Id], 

[T1].[Parent], 
[T4].[Code] AS [ParentCode],
[T4].[Description] AS [ParentDescription],


[T1].[Face1],
[T6].[Code] AS [Face1Code],
[T6].[Description] AS [Face1Description],

[T1].[Face2], 
[T7].[Code] AS [Face2Code],
[T7].[Description] AS [Face2Description],

[T1].[Face], 
[T5].[Code] AS [FaceCode],
[T5].[Description] AS [FaceDescription],

[T1].[Slice], 
[T3].[Code] AS [SliceCode],
[T3].[Description] AS [SliceDescription],

[T1].[Date1] AS [Date1],

[T1].[Date2] AS [Date2],

[T1].[Code] AS [Code],

[T1].[Description] AS [Description],

[T1].[Geo], 
[T8].[Code] AS [GeoCode],
[T8].[Description] AS [GeoDescription],

[T1].[Sign], 
[T12].[Code] AS [SignCode],
[T12].[Description] AS [SignDescription],

[T1].[Account], 
[T9].[Code] AS [AccountCode],
[T9].[Description] AS [AccountDescription],

[T1].[Process], 
[T16].[Code] AS [ProcessCode],
[T16].[Description] AS [ProcessDescription],

[T1].[Debt], 
[T17].[Code] AS [DebtCode],
[T17].[Description] AS [DebtDescription],

[T1].[Item], 
[T18].[Code] AS [ItemCode],
[T18].[Description] AS [ItemDescription],

[T1].[Deal], 
[T19].[Code] AS [DealCode],
[T19].[Description] AS [DealDescription],

[T1].[Price], 
[T20].[Code] AS [PriceCode],
[T20].[Description] AS [PriceDescription],

[T1].[Asset], 
[T21].[Code] AS [AssetCode],
[T21].[Description] AS [AssetDescription],

[T1].[Role], 
[T10].[Code] AS [RoleCode],
[T10].[Description] AS [RoleDescription],

[T1].[Info], 
[T11].[Code] AS [InfoCode],
[T11].[Description] AS [InfoDescription],

[T1].[Meter], 
[T22].[Code] AS [MeterCode],
[T22].[Description] AS [MeterDescription],

[T1].[MeterValue] AS [MeterValue], 

[T1].[Unit], 
[T13].[Code] AS [UnitCode],
[T13].[Description] AS [UnitDescription],

[T1].[Mark],
[T2].[Code] AS [MarkCode],
[T2].[Description] AS [MarkDescription]

FROM [dbo].[Workbook] AS [T1]                         

LEFT JOIN [dbo].[Workbook] AS [T4] ON [T1].[Parent]=[T4].[Id]    
LEFT JOIN [dbo].[Mark] AS [T2] ON [T1].[Mark]=[T2].[Id] 
LEFT JOIN [dbo].[Slice] AS [T3] ON [T1].[Slice]=[T3].[Id]     
LEFT JOIN [dbo].[Face] AS [T5] ON [T1].[Face]=[T5].[Id] 
LEFT JOIN [dbo].[Face] AS [T6] ON [T1].[Face1]=[T6].[Id]  
LEFT JOIN [dbo].[Face] AS [T7] ON [T1].[Face2]=[T7].[Id]
LEFT JOIN [dbo].[Geo] AS [T8] ON [T1].[Geo]=[T8].[Id]
LEFT JOIN [dbo].[Account] AS [T9] ON [T1].[Account]=[T9].[Id] 
LEFT JOIN [dbo].[Role] AS [T10] ON [T1].[Role]=[T10].[Id] 
LEFT JOIN [dbo].[Info] AS [T11] ON [T1].[Info]=[T11].[Id] 
LEFT JOIN [dbo].[Sign] AS T12 ON [T1].[Sign]=[T12].[Id] 
LEFT JOIN [dbo].[Unit] AS [T13] ON [T1].[Unit]=[T13].[Id] 
LEFT JOIN [dbo].[Process] AS [T16] ON [T1].[Process]=[T16].[Id] 
LEFT JOIN [dbo].[Debt] AS [T17] ON [T1].[Debt]=[T17].[Id] 
LEFT JOIN [dbo].[Item] AS [T18] ON [T1].[Item]=[T18].[Id] 
LEFT JOIN [dbo].[Deal] AS [T19] ON [T1].[Deal]=[T19].[Id] 
LEFT JOIN [dbo].[Price] AS [T20] ON [T1].[Price]=[T20].[Id] 
LEFT JOIN [dbo].[Asset] AS [T21] ON [T1].[Asset]=[T21].[Id] 
LEFT JOIN [dbo].[Meter] AS [T22] ON [T1].[Meter]=[T22].[Id] 