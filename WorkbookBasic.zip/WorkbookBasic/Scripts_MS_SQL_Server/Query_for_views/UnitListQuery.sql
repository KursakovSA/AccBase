SELECT [T1].[Id], 

[T1].[Parent], 
[T4].[Code] AS [ParentCode],
[T4].[Description] AS [ParentDescription],

[T1].[Date1] AS [Date1], 

[T1].[Date2] AS [Date2],

[T1].[Code] AS [Code], 

[T1].[Description] AS [Description],

[T1].[Role], 
[T10].[Code] AS [RoleCode], 
[T10].[Description] AS [RoleDescription], 

[T1].[More] AS [More]

FROM [dbo].[Unit] AS [T1]                       

LEFT JOIN [dbo].[Unit] AS [T4] ON [T1].[Parent]=[T4].[Id]    
LEFT JOIN [dbo].[Role] AS [T10] ON [T1].[Role]=[T10].[Id] 