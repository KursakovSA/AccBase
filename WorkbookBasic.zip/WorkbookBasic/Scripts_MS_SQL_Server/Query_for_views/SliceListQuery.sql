SELECT [T1].[Id], 

[T1].[Parent], 
[T4].[Code] AS [ParentCode],
[T4].[Description] AS [ParentDescription],

[T1].[Date1] AS [Date1], 

[T1].[Date2] AS [Date2],

[T1].[Code] AS [Code], 

[T1].[Description] AS [Description],

[T1].[More] AS [More] 

FROM [dbo].[Slice] AS [T1]                        

LEFT JOIN [dbo].[Slice] AS [T4] ON [T1].[Parent]=[T4].[Id]    