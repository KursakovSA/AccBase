--�������� �.�. https://github.com/KursakovSA/AccBase 
USE [DatabaseTemplate]
GO
ALTER TABLE [dbo].[Account]  WITH CHECK ADD  CONSTRAINT [AccountParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Account] ([Id])
GO
ALTER TABLE [dbo].[Account] CHECK CONSTRAINT [AccountParent_FK]
GO
ALTER TABLE [dbo].[Account]  WITH CHECK ADD  CONSTRAINT [AccountRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id])
GO
ALTER TABLE [dbo].[Account] CHECK CONSTRAINT [AccountRole_FK]
GO
ALTER TABLE [dbo].[Account]  WITH CHECK ADD  CONSTRAINT [AccountSign_FK] FOREIGN KEY([Sign])
REFERENCES [dbo].[Sign] ([Id])
GO
ALTER TABLE [dbo].[Account] CHECK CONSTRAINT [AccountSign_FK]
GO
ALTER TABLE [dbo].[Account]  WITH CHECK ADD  CONSTRAINT [AccountSlice_FK] FOREIGN KEY([Slice])
REFERENCES [dbo].[Slice] ([Id])
GO
ALTER TABLE [dbo].[Account] CHECK CONSTRAINT [AccountSlice_FK]
GO

ALTER TABLE [dbo].[Asset]  WITH CHECK ADD  CONSTRAINT [AssetGeo_FK] FOREIGN KEY([Geo])
REFERENCES [dbo].[Geo] ([Id])
GO
ALTER TABLE [dbo].[Asset] CHECK CONSTRAINT [AssetGeo_FK]
GO
ALTER TABLE [dbo].[Asset]  WITH CHECK ADD  CONSTRAINT [AssetInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id])
GO
ALTER TABLE [dbo].[Asset] CHECK CONSTRAINT [AssetInfo_FK]
GO
ALTER TABLE [dbo].[Asset]  WITH CHECK ADD  CONSTRAINT [AssetParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Asset] ([Id])
GO
ALTER TABLE [dbo].[Asset] CHECK CONSTRAINT [AssetParent_FK]
GO
ALTER TABLE [dbo].[Asset]  WITH CHECK ADD  CONSTRAINT [AssetRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id])
GO
ALTER TABLE [dbo].[Asset] CHECK CONSTRAINT [AssetRole_FK]
GO
ALTER TABLE [dbo].[Asset]  WITH CHECK ADD  CONSTRAINT [AssetUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id])
GO
ALTER TABLE [dbo].[Asset] CHECK CONSTRAINT [AssetUnit_FK]
GO


ALTER TABLE [dbo].[Deal]  WITH CHECK ADD  CONSTRAINT [DealFace_FK] FOREIGN KEY([Face])
REFERENCES [dbo].[Face] ([Id])
GO
ALTER TABLE [dbo].[Deal] CHECK CONSTRAINT [DealFace_FK]
GO
ALTER TABLE [dbo].[Deal]  WITH CHECK ADD  CONSTRAINT [DealFace1_FK] FOREIGN KEY([Face1])
REFERENCES [dbo].[Face] ([Id])
GO
ALTER TABLE [dbo].[Deal] CHECK CONSTRAINT [DealFace1_FK]
GO
ALTER TABLE [dbo].[Deal]  WITH CHECK ADD  CONSTRAINT [DealFace2_FK] FOREIGN KEY([Face2])
REFERENCES [dbo].[Face] ([Id])
GO
ALTER TABLE [dbo].[Deal] CHECK CONSTRAINT [DealFace2_FK]
GO
ALTER TABLE [dbo].[Deal]  WITH CHECK ADD  CONSTRAINT [DealGeo_FK] FOREIGN KEY([Geo])
REFERENCES [dbo].[Geo] ([Id])
GO
ALTER TABLE [dbo].[Deal] CHECK CONSTRAINT [DealGeo_FK]
GO
ALTER TABLE [dbo].[Deal]  WITH CHECK ADD  CONSTRAINT [DealInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id])
GO
ALTER TABLE [dbo].[Deal] CHECK CONSTRAINT [DealInfo_FK]
GO
ALTER TABLE [dbo].[Deal]  WITH CHECK ADD  CONSTRAINT [DealParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Deal] ([Id])
GO
ALTER TABLE [dbo].[Deal] CHECK CONSTRAINT [DealParent_FK]
GO
ALTER TABLE [dbo].[Deal]  WITH CHECK ADD  CONSTRAINT [DealRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id])
GO
ALTER TABLE [dbo].[Deal] CHECK CONSTRAINT [DealRole_FK]
GO

ALTER TABLE [dbo].[Face]  WITH CHECK ADD  CONSTRAINT [FaceGeo_FK] FOREIGN KEY([Geo])
REFERENCES [dbo].[Geo] ([Id])
GO
ALTER TABLE [dbo].[Face] CHECK CONSTRAINT [FaceGeo_FK]
GO
ALTER TABLE [dbo].[Face]  WITH CHECK ADD  CONSTRAINT [FaceInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id])
GO
ALTER TABLE [dbo].[Face] CHECK CONSTRAINT [FaceInfo_FK]
GO
ALTER TABLE [dbo].[Face]  WITH CHECK ADD  CONSTRAINT [FaceParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Face] ([Id])
GO
ALTER TABLE [dbo].[Face] CHECK CONSTRAINT [FaceParent_FK]
GO
ALTER TABLE [dbo].[Face]  WITH CHECK ADD  CONSTRAINT [FaceRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id])
GO
ALTER TABLE [dbo].[Face] CHECK CONSTRAINT [FaceRole_FK]
GO

ALTER TABLE [dbo].[Geo]  WITH CHECK ADD  CONSTRAINT [GeoParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Geo] ([Id])
GO
ALTER TABLE [dbo].[Geo] CHECK CONSTRAINT [GeoParent_FK]
GO
ALTER TABLE [dbo].[Geo]  WITH CHECK ADD  CONSTRAINT [GeoRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id])
GO
ALTER TABLE [dbo].[Geo] CHECK CONSTRAINT [GeoRole_FK]
GO
ALTER TABLE [dbo].[Geo]  WITH CHECK ADD  CONSTRAINT [GeoUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id])
GO
ALTER TABLE [dbo].[Geo] CHECK CONSTRAINT [GeoUnit_FK]
GO

ALTER TABLE [dbo].[Info]  WITH CHECK ADD  CONSTRAINT [InfoParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Info] ([Id])
GO
ALTER TABLE [dbo].[Info] CHECK CONSTRAINT [InfoParent_FK]
GO

ALTER TABLE [dbo].[Item]  WITH CHECK ADD  CONSTRAINT [ItemParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Item] ([Id])
GO
ALTER TABLE [dbo].[Item] CHECK CONSTRAINT [ItemParent_FK]
GO

ALTER TABLE [dbo].[Workbook]  WITH CHECK ADD  CONSTRAINT [WorkbookAccount_FK] FOREIGN KEY([Account])
REFERENCES [dbo].[Account] ([Id])
GO
ALTER TABLE [dbo].[Workbook] CHECK CONSTRAINT [WorkbookAccount_FK]
GO
ALTER TABLE [dbo].[Workbook]  WITH CHECK ADD  CONSTRAINT [WorkbookAsset_FK] FOREIGN KEY([Asset])
REFERENCES [dbo].[Asset] ([Id])
GO
ALTER TABLE [dbo].[Workbook] CHECK CONSTRAINT [WorkbookAsset_FK]
GO
ALTER TABLE [dbo].[Workbook]  WITH CHECK ADD  CONSTRAINT [WorkbookDeal_FK] FOREIGN KEY([Deal])
REFERENCES [dbo].[Deal] ([Id])
GO
ALTER TABLE [dbo].[Workbook] CHECK CONSTRAINT [WorkbookDeal_FK]
GO
ALTER TABLE [dbo].[Workbook]  WITH CHECK ADD  CONSTRAINT [WorkbookFace_FK] FOREIGN KEY([Face])
REFERENCES [dbo].[Face] ([Id])
GO
ALTER TABLE [dbo].[Workbook] CHECK CONSTRAINT [WorkbookFace_FK]
GO
ALTER TABLE [dbo].[Workbook]  WITH CHECK ADD  CONSTRAINT [WorkbookFace1_FK] FOREIGN KEY([Face1])
REFERENCES [dbo].[Face] ([Id])
GO
ALTER TABLE [dbo].[Workbook] CHECK CONSTRAINT [WorkbookFace1_FK]
GO
ALTER TABLE [dbo].[Workbook]  WITH CHECK ADD  CONSTRAINT [WorkbookFace2_FK] FOREIGN KEY([Face2])
REFERENCES [dbo].[Face] ([Id])
GO
ALTER TABLE [dbo].[Workbook] CHECK CONSTRAINT [WorkbookFace2_FK]
GO
ALTER TABLE [dbo].[Workbook]  WITH CHECK ADD  CONSTRAINT [WorkbookGeo_FK] FOREIGN KEY([Geo])
REFERENCES [dbo].[Geo] ([Id])
GO
ALTER TABLE [dbo].[Workbook] CHECK CONSTRAINT [WorkbookGeo_FK]
GO
ALTER TABLE [dbo].[Workbook]  WITH CHECK ADD  CONSTRAINT [WorkbookInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id])
GO
ALTER TABLE [dbo].[Workbook] CHECK CONSTRAINT [WorkbookInfo_FK]
GO
ALTER TABLE [dbo].[Workbook]  WITH CHECK ADD  CONSTRAINT [WorkbookItem_FK] FOREIGN KEY([Item])
REFERENCES [dbo].[Item] ([Id])
GO
ALTER TABLE [dbo].[Workbook] CHECK CONSTRAINT [WorkbookItem_FK]
GO
ALTER TABLE [dbo].[Workbook]  WITH CHECK ADD  CONSTRAINT [WorkbookMark_FK] FOREIGN KEY([Mark])
REFERENCES [dbo].[Mark] ([Id])
GO
ALTER TABLE [dbo].[Workbook] CHECK CONSTRAINT [WorkbookMark_FK]
GO
ALTER TABLE [dbo].[Workbook]  WITH CHECK ADD  CONSTRAINT [WorkbookMeter_FK] FOREIGN KEY([Meter])
REFERENCES [dbo].[Meter] ([Id])
GO
ALTER TABLE [dbo].[Workbook] CHECK CONSTRAINT [WorkbookMeter_FK]
GO
ALTER TABLE [dbo].[Workbook]  WITH CHECK ADD  CONSTRAINT [WorkbookParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Workbook] ([Id])
GO
ALTER TABLE [dbo].[Workbook] CHECK CONSTRAINT [WorkbookParent_FK]
GO
ALTER TABLE [dbo].[Workbook]  WITH CHECK ADD  CONSTRAINT [WorkbookPrice_FK] FOREIGN KEY([Price])
REFERENCES [dbo].[Price] ([Id])
GO
ALTER TABLE [dbo].[Workbook] CHECK CONSTRAINT [WorkbookPrice_FK]
GO
ALTER TABLE [dbo].[Workbook]  WITH CHECK ADD  CONSTRAINT [WorkbookProcess_FK] FOREIGN KEY([Process])
REFERENCES [dbo].[Process] ([Id])
GO
ALTER TABLE [dbo].[Workbook] CHECK CONSTRAINT [WorkbookProcess_FK]
GO
ALTER TABLE [dbo].[Workbook]  WITH CHECK ADD  CONSTRAINT [WorkbookRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id])
GO
ALTER TABLE [dbo].[Workbook] CHECK CONSTRAINT [WorkbookRole_FK]
GO
ALTER TABLE [dbo].[Workbook]  WITH CHECK ADD  CONSTRAINT [WorkbookSign_FK] FOREIGN KEY([Sign])
REFERENCES [dbo].[Sign] ([Id])
GO
ALTER TABLE [dbo].[Workbook] CHECK CONSTRAINT [WorkbookSign_FK]
GO
ALTER TABLE [dbo].[Workbook]  WITH CHECK ADD  CONSTRAINT [WorkbookSlice_FK] FOREIGN KEY([Slice])
REFERENCES [dbo].[Slice] ([Id])
GO
ALTER TABLE [dbo].[Workbook] CHECK CONSTRAINT [WorkbookSlice_FK]
GO
ALTER TABLE [dbo].[Workbook]  WITH CHECK ADD  CONSTRAINT [WorkbookDebt_FK] FOREIGN KEY([Debt])
REFERENCES [dbo].[Debt] ([Id])
GO
ALTER TABLE [dbo].[Workbook] CHECK CONSTRAINT [WorkbookDebt_FK]
GO
ALTER TABLE [dbo].[Workbook]  WITH CHECK ADD  CONSTRAINT [WorkbookUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id])
GO
ALTER TABLE [dbo].[Workbook] CHECK CONSTRAINT [WorkbookUnit_FK]
GO

ALTER TABLE [dbo].[Mark]  WITH CHECK ADD  CONSTRAINT [MarkParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Mark] ([Id])
GO
ALTER TABLE [dbo].[Mark] CHECK CONSTRAINT [MarkParent_FK]
GO

ALTER TABLE [dbo].[Meter]  WITH CHECK ADD  CONSTRAINT [MeterParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Meter] ([Id])
GO
ALTER TABLE [dbo].[Meter] CHECK CONSTRAINT [MeterParent_FK]
GO
ALTER TABLE [dbo].[Meter]  WITH CHECK ADD  CONSTRAINT [MeterUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id])
GO
ALTER TABLE [dbo].[Meter] CHECK CONSTRAINT [MeterUnit_FK]
GO

ALTER TABLE [dbo].[Price]  WITH CHECK ADD  CONSTRAINT [PriceInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id])
GO
ALTER TABLE [dbo].[Price] CHECK CONSTRAINT [PriceInfo_FK]
GO
ALTER TABLE [dbo].[Price]  WITH CHECK ADD  CONSTRAINT [PriceParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Price] ([Id])
GO
ALTER TABLE [dbo].[Price] CHECK CONSTRAINT [PriceParent_FK]
GO
ALTER TABLE [dbo].[Price]  WITH CHECK ADD  CONSTRAINT [PriceRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id])
GO
ALTER TABLE [dbo].[Price] CHECK CONSTRAINT [PriceRole_FK]
GO
ALTER TABLE [dbo].[Price]  WITH CHECK ADD  CONSTRAINT [PriceUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id])
GO
ALTER TABLE [dbo].[Price] CHECK CONSTRAINT [PriceUnit_FK]
GO

ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessAccount_FK] FOREIGN KEY([Account])
REFERENCES [dbo].[Account] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessAccount_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessAsset_FK] FOREIGN KEY([Asset])
REFERENCES [dbo].[Asset] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessAsset_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessDeal_FK] FOREIGN KEY([Deal])
REFERENCES [dbo].[Deal] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessDeal_FK]
GO
--ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessFace_FK] FOREIGN KEY([Face])
--REFERENCES [dbo].[Face] ([Id])
--GO
--ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessFace_FK]
--GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessFace1_FK] FOREIGN KEY([Face1])
REFERENCES [dbo].[Face] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessFace1_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessFace2_FK] FOREIGN KEY([Face2])
REFERENCES [dbo].[Face] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessFace2_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessInfo_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessItem_FK] FOREIGN KEY([Item])
REFERENCES [dbo].[Item] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessItem_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessMeter_FK] FOREIGN KEY([Meter])
REFERENCES [dbo].[Meter] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessMeter_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Process] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessParent_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessPrice_FK] FOREIGN KEY([Price])
REFERENCES [dbo].[Price] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessPrice_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessRole_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessSign_FK] FOREIGN KEY([Sign])
REFERENCES [dbo].[Sign] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessSign_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessSlice_FK] FOREIGN KEY([Slice])
REFERENCES [dbo].[Slice] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessSlice_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessDebt_FK] FOREIGN KEY([Debt])
REFERENCES [dbo].[Debt] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessDebt_FK]
GO
ALTER TABLE [dbo].[Process]  WITH CHECK ADD  CONSTRAINT [ProcessUnit_FK] FOREIGN KEY([Unit])
REFERENCES [dbo].[Unit] ([Id])
GO
ALTER TABLE [dbo].[Process] CHECK CONSTRAINT [ProcessUnit_FK]
GO

ALTER TABLE [dbo].[Role]  WITH CHECK ADD  CONSTRAINT [RoleParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Role] ([Id])
GO
ALTER TABLE [dbo].[Role] CHECK CONSTRAINT [RoleParent_FK]
GO

ALTER TABLE [dbo].[Sign]  WITH CHECK ADD  CONSTRAINT [SignInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id])
GO
ALTER TABLE [dbo].[Sign] CHECK CONSTRAINT [SignInfo_FK]
GO
ALTER TABLE [dbo].[Sign]  WITH CHECK ADD  CONSTRAINT [SignParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Sign] ([Id])
GO
ALTER TABLE [dbo].[Sign] CHECK CONSTRAINT [SignParent_FK]
GO
ALTER TABLE [dbo].[Sign]  WITH CHECK ADD  CONSTRAINT [SignRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id])
GO
ALTER TABLE [dbo].[Sign] CHECK CONSTRAINT [SignRole_FK]
GO

ALTER TABLE [dbo].[Slice]  WITH CHECK ADD  CONSTRAINT [SliceParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Slice] ([Id])
GO
ALTER TABLE [dbo].[Slice] CHECK CONSTRAINT [SliceParent_FK]
GO

ALTER TABLE [dbo].[Debt]  WITH CHECK ADD  CONSTRAINT [DebtGeo_FK] FOREIGN KEY([Geo])
REFERENCES [dbo].[Geo] ([Id])
GO
ALTER TABLE [dbo].[Debt] CHECK CONSTRAINT [DebtGeo_FK]
GO
ALTER TABLE [dbo].[Debt]  WITH CHECK ADD  CONSTRAINT [DebtInfo_FK] FOREIGN KEY([Info])
REFERENCES [dbo].[Info] ([Id])
GO
ALTER TABLE [dbo].[Debt] CHECK CONSTRAINT [DebtInfo_FK]
GO
ALTER TABLE [dbo].[Debt]  WITH CHECK ADD  CONSTRAINT [DebtParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Debt] ([Id])
GO
ALTER TABLE [dbo].[Debt] CHECK CONSTRAINT [DebtParent_FK]
GO
ALTER TABLE [dbo].[Debt]  WITH CHECK ADD  CONSTRAINT [DebtRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id])
GO
ALTER TABLE [dbo].[Debt] CHECK CONSTRAINT [DebtRole_FK]
GO

ALTER TABLE [dbo].[Unit]  WITH CHECK ADD  CONSTRAINT [UnitParent_FK] FOREIGN KEY([Parent])
REFERENCES [dbo].[Unit] ([Id])
GO
ALTER TABLE [dbo].[Unit] CHECK CONSTRAINT [UnitParent_FK]
GO
ALTER TABLE [dbo].[Unit]  WITH CHECK ADD  CONSTRAINT [UnitRole_FK] FOREIGN KEY([Role])
REFERENCES [dbo].[Role] ([Id])
GO
ALTER TABLE [dbo].[Unit] CHECK CONSTRAINT [UnitRole_FK]
GO

USE [master]
GO
ALTER DATABASE [DatabaseTemplate] SET  READ_WRITE 
GO
