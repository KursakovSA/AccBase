PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

--нагенерим Face1
create table if not exists Face1 as
with recursive Face1(Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More, Mark) as (
    select '1', NULL, current_timestamp, current_timestamp, 'Face.BulkTest.', 'Face.BulkTest.Data', 'Geo.Qazaqstan', 'Role.Face.Customer', 'Info.Face.Person', 'Test', 'Mark.CD'
    union all
    select
        cast(cast(Face1.Id as integer) + 1 as text) as Id,
        cast(cast(Face1.Id as integer) as text) as Parent,
        current_timestamp as Date1,
        current_timestamp as Date2,
        'Наименование лица ' || cast(Face1.Id+1 as text) as Code,
        'Наименование лица ' || cast(Face1.Id+1 as text) as Description, 
		'Geo.Qazaqstan' as Geo, 
        'Role.Face.Customer' as Role,
        'Info.Face.Person' as Info,
		 cast(abs(random() % 10000) as text) || ':' || cast(abs(random() % 10000) as text) as More,  --случайная сумма в диапазоне от 1 до 10000
		 'Mark.CD' as Mark
    from Face1
    limit 10000  --10000 строк  
)
select * from Face1;

--закинем все строки из Face1 в Face
insert into Face select * from Face1;

--удалим Face1 теперь она не нужна
drop table Face1;
COMMIT TRANSACTION;
PRAGMA foreign_keys = on;


---Протестируем скорость работы при выборке лиц за 10 лет ---