PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

--нагенерим Asset1
create table if not exists Asset1 as
with recursive Asset1(Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, Unit, More, Mark) as (
    select '1', NULL, current_timestamp, current_timestamp, 'Asset.BulkTest.', 'Asset.BulkTest.Data', 'Geo.Qazaqstan', 'Role.Asset.Good', 'Info.Asset.Asset', 'Unit.Piece', 'Test', 'Mark.CD'
    union all
    select
        cast(cast(Asset1.Id as integer) + 1 as text) as Id,
        cast(cast(Asset1.Id as integer) as text) as Parent,
        current_timestamp as Date1,
        current_timestamp as Date2,
        'Наименование товара ' || cast(Asset1.Id+1 as text) as Code,
        'Наименование товара ' || cast(Asset1.Id+1 as text) as Description, 
		'Geo.Qazaqstan' as Geo, 
        'Role.Asset.Good' as Role,
        'Info.Asset.Asset' as Info,
		'Unit.Piece' as Unit,
		 cast(abs(random() % 10000) as text) || ':' || cast(abs(random() % 10000) as text) as More,  --случайная сумма в диапазоне от 1 до 10000
		 'Mark.CD' as Mark
    from Asset1
    limit 3660  --16000 строк, 8000 товаров и 8000 цены  
)
select * from Asset1;

--закинем все строки из Asset1 в Asset
insert into Asset select * from Asset1;

--удалим Asset1 теперь она не нужна
drop table Asset1;
COMMIT TRANSACTION;
PRAGMA foreign_keys = on;


---Протестируем скорость работы при выборке цен товаров за 10 лет ---