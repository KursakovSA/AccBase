PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

--нагенерим Price1
create table if not exists Price1 as
with recursive Price1(Id, Parent, Date1, Date2, Code, Description, More) as (
    select '1', NULL, current_timestamp, current_timestamp, 'Price.ExchangeCurrency.', 'Price.ExchangeCurrency.Data', 'Test'
    union all
    select
        cast(cast(Price1.Id as integer) + 1 as text) as Id,
        cast(cast(Price1.Id as integer) as text) as Parent,
        current_timestamp as Date1,
        current_timestamp as Date2,
        'Qazaqstan.ExchangeCurrency ' || cast(Price1.Id+1 as text) as Code,
        'Казахстан курс валют ' || cast(Price1.Id+1 as text) as Description, 
		 cast(abs(random() % 1000) as text) as More  --случайная сумма в диапазоне от 1 до 1000
    from Price1
    limit 3660  --3660 строк валютных курсов, по 1 строке на каждый 1 день в течение 10 лет  
)
select * from Price1;

--закинем все строки из Price1 в Price
insert into Price select * from Price1;

--удалим Price1 теперь она не нужна
drop table Price1;
COMMIT TRANSACTION;
PRAGMA foreign_keys = on;


---Протестируем скорость работы при выборке валютных курсов за 10 лет ---