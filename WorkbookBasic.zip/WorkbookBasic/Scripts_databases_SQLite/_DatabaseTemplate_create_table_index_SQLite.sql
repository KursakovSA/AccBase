﻿--Курсаков С.А. https://github.com/KursakovSA/AccBase 

PRAGMA foreign_keys = off;

CREATE TABLE IF NOT EXISTS [Account](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Account(Id),
	[Slice] TEXT references Slice(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
    [Role] TEXT references Role(Id),
    [Sign] TEXT references Sign(Id),
	[More] TEXT
 );

CREATE TABLE IF NOT EXISTS [Asset](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Asset(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Geo] TEXT references Geo(Id),
	[Role] TEXT references Role(Id),
	[Info] TEXT references Info(Id),
	[Unit] TEXT references Unit(Id),
	[More] TEXT,
	[Mark] TEXT references Mark(Id)
 );

CREATE TABLE IF NOT EXISTS [Deal](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Deal(Id),
	[Face1] TEXT references Face(Id),
	[Face2] TEXT references Face(Id),
	[Face] TEXT references Face(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Geo] TEXT references Geo(Id),
	[Role] TEXT references Role(Id),
	[Info] TEXT references Info(Id),
	[More] TEXT,
	[Mark] TEXT references Mark(Id)
 );

CREATE TABLE IF NOT EXISTS [Debt](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Debt(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Geo] TEXT references Geo(Id),
	[Role] TEXT references Role(Id),
	[Info] TEXT references Info(Id),
	[More] TEXT
  ); 
 
CREATE TABLE IF NOT EXISTS [Face](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Face(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Geo] TEXT references Geo(Id),
	[Role] TEXT references Role(Id),
	[Info] TEXT references Info(Id),
	[More] TEXT,
	[Mark] TEXT references Mark(Id)
 );
 
CREATE TABLE IF NOT EXISTS [Geo](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Geo(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
    [Role] TEXT references Role(Id),
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Info](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Info(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Item](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Item(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Mark](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Mark(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Meter](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Meter(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Price](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Price(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Process](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Process(Id),
	[Face1] TEXT references Face(Id),
	[Face2] TEXT references Face(Id),
	[Face] TEXT references Face(Id),
	[Slice] TEXT references Slice(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Geo] TEXT references Geo(Id),
	[Sign] TEXT references Sign(Id),
	[Account] TEXT references Account(Id),
    [Asset] TEXT references Asset(Id),
    [Deal] TEXT references Deal(Id),
    [Item] TEXT references Item(Id),
	[Debt] TEXT references Debt(Id),
	[Role] TEXT references Role(Id),
	[Info] TEXT references Info(Id),
	[Meter] TEXT references Meter(Id),
	[MeterValue] TEXT,
	[Unit] TEXT references Unit(Id),
	[More] TEXT,
	[Mark] TEXT references Mark(Id)
 );
 
CREATE TABLE IF NOT EXISTS [Role](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Role(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Sign](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Sign(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Slice](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Slice(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Unit](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Unit(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Role] TEXT references Role(Id),
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Workbook](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Workbook(Id),
	[Face1] TEXT references Face(Id),
	[Face2] TEXT references Face(Id),
	[Face] TEXT references Face(Id),
	[Slice] TEXT references Slice(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Geo] TEXT references Geo(Id),
	[Sign] TEXT references Sign(Id),
	[Account] TEXT references Account(Id),
	[Process] TEXT references Process(Id),
    [Asset] TEXT references Asset(Id),
    [Deal] TEXT references Deal(Id),
    [Item] TEXT references Item(Id),
	[Debt] TEXT references Debt(Id),
	[Role] TEXT references Role(Id),
	[Info] TEXT references Info(Id),
	[Meter] TEXT references Meter(Id),
	[MeterValue] TEXT,
	[Unit] TEXT references Unit(Id),
	[More] TEXT,
	[Mark] TEXT references Mark(Id)
 );
 
CREATE INDEX IF NOT EXISTS AssetDate1 ON Asset (
    Date1
);

CREATE INDEX IF NOT EXISTS AssetCode ON Asset (
    Code
);
 
CREATE INDEX IF NOT EXISTS AssetDescription ON Asset (
    Description
);

CREATE INDEX IF NOT EXISTS AssetRole ON Asset (
    Role
);

CREATE INDEX IF NOT EXISTS AssetInfo ON Asset (
    Info
);

CREATE INDEX IF NOT EXISTS DealParent ON Deal (
    Parent
);

CREATE INDEX IF NOT EXISTS DealFace1 ON Deal (
    Face1
);

CREATE INDEX IF NOT EXISTS DealFace2 ON Deal (
    Face2
);

CREATE INDEX IF NOT EXISTS DealFace ON Deal (
    Face
);

CREATE INDEX IF NOT EXISTS DealCode ON Deal (
    Code
);
 
CREATE INDEX IF NOT EXISTS DealDescription ON Deal (
    Description
);

CREATE INDEX IF NOT EXISTS DealRole ON Deal (
    Role
);

CREATE INDEX IF NOT EXISTS DealInfo ON Deal (
    Info
);

CREATE INDEX IF NOT EXISTS FaceParent ON Face (
    Parent
);

CREATE INDEX IF NOT EXISTS FaceDate1 ON Face (
    Date1
);

CREATE INDEX IF NOT EXISTS FaceCode ON Face (
    Code
);
 
CREATE INDEX IF NOT EXISTS FaceDescription ON Face (
    Description
);

CREATE INDEX IF NOT EXISTS FaceRole ON Face (
    Role
);

CREATE INDEX IF NOT EXISTS FaceInfo ON Face (
    Info
);
 
CREATE INDEX IF NOT EXISTS WorkbookParent ON Workbook (
    Parent
);

CREATE INDEX IF NOT EXISTS WorkbookFace1 ON Workbook (
    Face1
);

CREATE INDEX IF NOT EXISTS WorkbookFace2 ON Workbook (
    Face2
);

CREATE INDEX IF NOT EXISTS WorkbookFace ON Workbook (
    Face
);

CREATE INDEX IF NOT EXISTS WorkbookDate1 ON Workbook (
    Date1
);

CREATE INDEX IF NOT EXISTS WorkbookCode ON Workbook (
    Code
);
 
CREATE INDEX IF NOT EXISTS WorkbookDescription ON Workbook (
    Description
);

CREATE INDEX IF NOT EXISTS WorkbookSign ON Workbook (
    Sign
);

CREATE INDEX IF NOT EXISTS WorkbookAccount ON Workbook (
    Account
);

CREATE INDEX IF NOT EXISTS WorkbookProcess ON Workbook (
    Process
);

CREATE INDEX IF NOT EXISTS WorkbookDebt ON Workbook (
    Debt
);

CREATE INDEX IF NOT EXISTS WorkbookDeal ON Workbook (
    Deal
);

CREATE INDEX IF NOT EXISTS WorkbookAsset ON Workbook (
    Asset
);

CREATE INDEX IF NOT EXISTS WorkbookRole ON Workbook (
    Role
);

CREATE INDEX IF NOT EXISTS WorkbookInfo ON Workbook (
    Info
);