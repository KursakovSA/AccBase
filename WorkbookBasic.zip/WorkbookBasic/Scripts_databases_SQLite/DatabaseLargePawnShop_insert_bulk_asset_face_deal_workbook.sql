PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

--нагенерим Asset1
create table if not exists Asset1 as
with recursive Asset1(Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, Unit, More, Mark) as (
    select '1', NULL, current_timestamp, current_timestamp, 'Asset.', 'Asset.Data', 'Geo.Qazaqstan', 'Role.Asset.Good', 'Info.Asset.Asset', 'Unit.Piece', 'Test', 'Mark.CD'
    union all
    select
        cast(cast(Asset1.Id as integer) + 1 as text) as Id,
        cast(cast(Asset1.Id as integer) as text) as Parent,
        current_timestamp as Date1,
        current_timestamp as Date2,
        'Наименование товара ' || cast(Asset1.Id+1 as text) as Code,
        'Полное наименование товара ' || cast(Asset1.Id+1 as text) as Description,
         'Geo.Qazaqstan' as Geo, 
         'Role.Asset.Good' as Role,
         'Info.Asset.Asset' as Info,
         'Unit.Piece' as Unit,
         'Test' as More, 
		 'Mark.CD' as Mark
    from Asset1
    limit 1000  --1 тыс активов  
)
select * from Asset1;

--закинем все строки из Asset1 в Asset
insert into Asset select * from Asset1;

--удалим Asset1 теперь она не нужна
drop table Asset1;
COMMIT TRANSACTION;
PRAGMA foreign_keys = on;


PRAGMA foreign_keys = off;
BEGIN TRANSACTION;
--нагенерим Face1
create table if not exists Face1 as
with recursive Face1(Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More, Mark) as (
    select '1', NULL, current_timestamp, current_timestamp, 'Face.', 'Face.Data', 'Geo.Qazaqstan', 'Role.Face.Customer', 'Info.Face.Corp', 'Test', 'Mark.CD'
    union all
    select
        cast(cast(Face1.Id as integer) + 1 as text) as Id,
        cast(cast(Face1.Id as integer) as text) as Parent,
        current_timestamp as Date1,
        current_timestamp as Date2,
        'Наименование лица ' || cast(Face1.Id+1 as text) as Code,
        'Полное наименование лица ' || cast(Face1.Id+1 as text) as Description,
        'Geo.Qazaqstan' as Geo, 
        'Role.Face.Customer' as Role,
        'Info.Face.Corp' as Info,
        'Test' as More,
		'Mark.CD' as Mark
    from Face1
    limit 200000  --200 тыс лиц
)
select * from Face1;

--закинем все строки из Face1 в Face
insert into Face select * from Face1;

--удалим Face1 теперь она не нужна
drop table Face1;
COMMIT TRANSACTION;
PRAGMA foreign_keys = on;


PRAGMA foreign_keys = off;
BEGIN TRANSACTION;
--нагенерим Deal1
create table if not exists Deal1 as
with recursive Deal1(Id, Parent, Face1, Face2, Face, Date1, Date2, Code, Description, Geo, Role, Info, More, Mark) as (
    select '1', NULL, 'Face.FA1.StaffTable.ChiefAccountant', 'Face.FA1.StaffTable.ChiefAccountant', 'Face.FA1.StaffTable.ChiefAccountant', current_timestamp, current_timestamp, 'Deal.', 'Deal.Data', 'Geo.Qazaqstan', 'Role.Deal.Basic', 'Info.Deal.Basic', 'Test', 'Mark.CD'
	union all
    select
        cast(cast(Deal1.Id as integer) + 1 as text) as Id,
        cast(cast(Deal1.Id as integer) as text) as Parent,
		--'Face.FA1.StaffTable.ChiefAccountant' as Face1,  --пробьем длинное название просто ради самой длины
		cast(abs(random() % 200000) as text) as Face1,
        cast(abs(random() % 200000) as text) as Face2,
        cast(abs(random() % 200000) as text) as Face,
        current_timestamp as Date1,
        current_timestamp as Date2,
        'Наименование договора ' || cast(Deal1.Id+1 as text) as Code,
        'Полное наименование договора ' || cast(Deal1.Id+1 as text) as Description,
         'Geo.Qazaqstan' as Geo, 
         'Role.Deal.Basic' as Role,
         'Info.Deal.Basic' as Info,
         'Test' as More,
		 'Mark.CD' as Mark
    from Deal1
    limit 200000   --200 тыс договоров
)
select * from Deal1;

--закинем все строки из Deal1 в Deal
insert into Deal select * from Deal1;

--удалим Deal1 теперь она не нужна
drop table Deal1;
COMMIT TRANSACTION;
PRAGMA foreign_keys = on;


PRAGMA foreign_keys = off;
BEGIN TRANSACTION;
--нагенерим Workbook1
create table if not exists Workbook1 as
with recursive Workbook1(
Id, 
Parent, 
Face1, 
Face2, 
Face, 
Slice, 
Date1, 
Date2, 
Code, 
Description, 
Geo, 
Sign, 
Account, 
Process, 
Asset, 
Deal, 
Item, 
Debt, 
Price, 
Role, 
Info, 
Meter, 
MeterValue, 
Unit,
More, 
Mark) as (
	select 
	'1', 
	NULL, 
	'Face.FA1', 
	'Face.FA1.StaffTable.ChiefAccountant', 
	'Face.FA1.User1', 
	'Slice.Accounting', 
	current_timestamp, 
	current_timestamp, 
	'Workbook.', 
	'Workbook.Data', 
	'Geo.Qazaqstan', 
	'Sign.Acct.Dt', 
	'Account.1330', 
	'Process.Buy.5 (Arrival)', 
	cast(abs(random() % 1000) as text), 
	cast(abs(random() % 200000) as text), 
	'Item.Production', 
	'Debt.IncomePerson.Base.Deduction.Standard', 
	'Price.Basic', 
	'Role.Workbook.Line1Manual', 
	'Info.Workbook.Level1.Quantity', 
	'Meter.Quantity', 
	cast(abs(random() % 100000) as text), 
	'Unit.KZT', 
	' ',
	'Mark.CD'
    
	union all
    select
        cast(cast(Workbook1.Id as integer) + 1 as text) as Id,
        cast(cast(Workbook1.Id as integer) as text) as Parent,
        'Face.FA1' as Face1,
        cast(abs(random() % 200000) as text) as Face2,
        'Face.FA1.User1' as Face,
        'Slice.Accounting' as Slice, 
        current_timestamp as Date1,
        current_timestamp as Date2,
        'Рабочая книга ' || cast(cast(Workbook1.Id as integer)+1 as text) as Code,
        'Рабочая книга ' || cast(cast(Workbook1.Id as integer)+1 as text) as Description,
        'Geo.Qazaqstan' as Geo,
        'Sign.Acct.Dt' as Sign,   
        'Account.1330' as Account,  
        'Process.Buy.5 (Arrival)' as Process,  
        cast(abs(random() % 1000) as text) as Asset,   
        cast(abs(random() % 200000) as text) as Deal,
        'Item.Production' as Item, 
        'Debt.IncomePerson.Base.Deduction.Standard' as Debt, 
        'Price.Basic' as Price,
        'Role.Workbook.Line1Manual' as Role, 
        'Info.Workbook.Level1.Quantity' as Info,
        'Meter.Quantity' as Meter,
        cast(abs(random() % 100000) as text) as MeterValue,  --случайная сумма в диапазоне от 1 до 100 тыс   
        'Unit.KZT' as Unit,
		' ' as More,
        'Mark.CD' as Mark  
    from Workbook1
    limit 3500000   --3.5 млн записей
)
select * from Workbook1;

--закинем все строки из Workbook1 в Workbook
insert into Workbook select * from Workbook1;

--удалим Workbook1 теперь она не нужна
drop table Workbook1;
drop table IF EXISTS vars;
COMMIT TRANSACTION;
PRAGMA foreign_keys = on;

---Протестируем скорость работы общей объединенной базы (бухгалтерия + операционая база) ломбарда за 10 лет ---
---берем для среднего ломбарда примерно 10 точек-пунктов, на каждой точке примерно 30 операций в день,
---каждая операция - это или ссуда, или вознаграждение, или пеня. Итого 300 физических строк Workbook в день на всю сеть точек ломбарда,
---плюс шапка документа, итого 300 + 300 строк, примем 600 физических строк Workbook в день на всю сеть    
---600 * 30 дней = 18000 физ строк Workbook в месяц, берем 30 дней 
---хорошо, для круглой цифры принимаем 20000 физ строк Workbook в месяц на всю сеть точек ломбарда    
---добавляем зарплату, прочие операции, цены товаров и т.д. и принимаем 25000 физ строк Workbook в месяц  
---25000 * 12 = 300000 физ строк Workbook в год   
---таким образом для 10 лет работы среднего ломбарда нужно 300000 * 10 = 3 млн физических строк Workbook примерно
---учтем еще строки залогов в Workbook - примерно 2 залога на 1 договор займа, то есть -- 
---примем из 300 строк в день примерно треть - это новые займы, тогда -- 100 строк залогов в Workbook в день, или 
---100 * 30 дней * 12 мес * 10 лет = 360 000 залогов за 10 лет работы, принимаем для круглого счета 500 000 строк залогов, тогда всего ---
---строк Workbook на 10 лет понадобится 3.5 млн строк Workbook на 10 лет работы 
---заемщиков будет примерно = 50 в день * 30 дней * 12 мес * 10 лет = 180 000, примем примерно 200 тыс заемщиков  
---столько же сколько заемщиков будет и договоров = 200 тыс договоров займа  
---заполним этими данными базу данных автоматически с помощью данного скрипта  
---
---результат таков - заполнение 3.5 млн физ строк таблицы Workbook занимает примерно 500 - 600 сек (notebook, Celeron, SSD, SqliteStudio)  
---размер итоговой базы = 5 - 6 гигабайт  
---и это при усложненный условиях заполнения, когда строка Workbook полностью заполняется реквизитами, хотя в обычных условиях 
---практически половина полей обычно должны быть пусты (Item, Debt и т.д.)
---
---выборка итогового оборота по заемщику (Face) с индексом допустим, 532, занимает 0.01 - 1 сек (notebook, Celeron, SSD, SqliteStudio)(индекс включен)
---почему нужно выбрать именно итоговый оборот - чтобы рассчитать сальдо заемщика на текущий момент (например, при уплате вознаграждения)
---
---выборка последних 1000 записей занимает 0.01 сек (notebook, Celeron, SSD, SqliteStudio)  
---  
---краткое тестирование базы (integrity check + reindex) занимает примерно 40 минут  
---операция vacuum заняла примерно 8 минут, она может запускаться отдельно и необязательно    
---отдельно integrity check заняло примерно 500 - 600 сек  
---отдельно reindex заняло примерно 400 - 500 сек   