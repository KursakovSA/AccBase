SELECT [T1].[Face1], [T1].[Slice], [T1].[Sign], [T1].[Account], [T1].[Asset], [T1].[Meter], [T1].[Unit], [T1].[Mark],
SUM(CAST([T1].[MeterValue] AS REAL)) AS MeterValue

FROM [Workbook] AS [T1]                            

WHERE 
[T1].[Slice] = 'Slice.Accounting' AND
[T1].[Mark] = 'Mark.CD' AND
[T1].[Meter] = 'Meter.Quantity' AND
[T1].[Unit] = 'Unit.KZT' AND
[T1].[Account] IS NOT NUll AND
[T1].[Sign] IS NOT NULL AND

[T1].[Asset] = 532 

GROUP BY [T1].[Face1], [T1].[Slice], [T1].[Asset], [T1].[Sign], [T1].[Account], [T1].[Meter], [T1].[Unit], [T1].[Mark]