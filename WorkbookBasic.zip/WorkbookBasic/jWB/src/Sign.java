public class Sign extends Model {
	// origin - 28.09.2023, last edit - 14.10.2023

}
