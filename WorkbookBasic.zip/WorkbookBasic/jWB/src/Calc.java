import java.time.LocalDate;

public class Calc {
	// origin - 01.10.2023, last edit - 18.10.2023
	public static double rateVAT = getRateVAT(LocalDate.now(), WB.currContext);
	public static int round0 = 0;
	public static int round2 = 2;
	public static int round4 = 4;
	
	public static boolean strEqual(String str1, String str2) {
		// origin - 18.10.2023, last edit - 18.10.2023
		boolean res = false;
		str1 = fixTrim(str1);
		str2 = fixTrim(str2);
		res = str1.equalsIgnoreCase(str2) == true ? true : res;
		return res;
	}
		
	public static double getSegmentDebt(LocalDate currDate, String currContext) {
		// origin - 18.10.2023, last edit - 18.10.2023
		//currContext may be equals -- "VAT.Rate", "VAT.Base.MinLimit", "VAT.Base.MaxLimit", "IncomePersonTax.Dediction".... etc. 
		double res = 0.0;
		
		// TODO - here need do get processRateVAT from DatabaseGlobal.sqlite3
		
		res = roundCustom(res);
		res = setZeroOnNeg(res);
		return res;
	}

	public static double ratio100(double ratePercent) {
		// origin - 17.10.2023, last edit - 17.10.2023
		double res = 0.0;
		res = ratePercent / 100.0;
		res = roundCustom(res, round4);
		return res;
	}

	public static double getSumTax(double sumBaseTax, double rateTax, int numberFractionalDigit) {
		// origin - 10.10.2023, last edit - 16.10.2023
		double res = 0.0;
		// sumBaseTax = roundCustom(sumBaseTax,numberFractionalDigit);
		res = sumBaseTax * (ratio100(rateTax)); // only net sum Tax, less baseTax
		res = roundCustom(res, numberFractionalDigit);
		res = setZeroOnNeg(res);
		return res;
	}

	public static double getRateVAT(LocalDate currDate, Workbook currContext) {
		// origin - 09.10.2023, last edit - 18.10.2023
		double res = 0.0;
		
		getSegmentDebt(currDate, "Debt.VAT.Sell.RateBasic");
		
		res = res == 0.0 ? 12.0 : res; //default stub = 12.0 when no rate vat from DatabaseGlobal.sqlite3
		res = roundCustom(res, round2);
		res = setZeroOnNeg(res);
		return res;
	}

	public static double subtractInVAT(double sumWithVAT, double rateVAT) {
		// origin - 08.10.2023, last edit - 17.10.2023
		double res = 0.0;
		sumWithVAT = roundCustom(sumWithVAT, round2);
		if ((sumWithVAT != 0.0) && (rateVAT != 0.0)) {
			res = sumWithVAT - getInVAT(sumWithVAT, rateVAT);
		}
		res = roundCustom(res, round2);
		return res;
	}

	public static double roundCustom(double sum) {
		// origin - 17.10.2023, last edit - 17.10.2023
		//variant round less number fractional digit as argument, take him = 2 
		double res = sum;
		res = roundCustom(sum, round2); // default = 2 numberFractionalDigit
		return res;
	}

	public static double roundCustom(double sum, int numberFractionalDigit) {
		// origin - 16.10.2023, last edit - 17.10.2023
		double res = sum;
		int power10 = (int) Math.pow(10, numberFractionalDigit);
		res = sum * power10;
		res = Math.round(res);
		res = res / power10;
		return res;
	}

	public static double addOutVAT(double sumLessVAT, double rateVAT) {
		// origin - 02.10.2023, last edit - 17.10.2023
		double res = 0.0;
		sumLessVAT = roundCustom(sumLessVAT, round2); // with cents
		if ((sumLessVAT != 0.0) && (rateVAT != 0.0)) {
			res = sumLessVAT + getOutVAT(sumLessVAT, rateVAT);
		}
		res = roundCustom(res, round2);
		return res;
	}

	public static double getOutVAT(double sumLessVAT, double rateVAT) {
		// origin - 08.10.2023, last edit - 17.10.2023
		double res = 0.0;
		sumLessVAT = roundCustom(sumLessVAT, round2); // with cents
		res = getSumTax(sumLessVAT, rateVAT, round2); // with cents
		res = roundCustom(res, round2); // with cents
		return res;
	}

	public static double getInVAT(double sumWithVAT, double rateVAT) {
		// origin - 02.10.2023, last edit - 17.10.2023
		double res = 0.0;
		sumWithVAT = roundCustom(sumWithVAT, round2); // with cents
		if ((sumWithVAT != 0.0) && (rateVAT != 0.0)) {
			res = (sumWithVAT * rateVAT) / (100.0 + rateVAT);
		}
		res = roundCustom(res, round2); // with cents
		return res;
	}

	public static LocalDate fixLocalDate(LocalDate fixDate) {
		// origin - 02.10.2023, last edit - 14.10.2023
		// LocalDate not must be big endDate and least startDate
		LocalDate res = fixDate;
		if (fixDate.isBefore(WB.startDate)) {
			res = WB.startDate;
		}
		if (fixDate.isAfter(WB.endDate)) {
			res = WB.endDate;
		}
		return res;
	}

	public static String fixTrim(String fixStr) {
		// origin - 02.10.2023, last edit - 14.10.2023
		String res = fixStr.strip();
		return res;
	}

	public static double setZeroOnNeg(Number fixNumb) {
		// origin - 01.10.2023, last edit - 14.10.2023
		// for tax calculate and etc where not need be negative number
		double res = (double) fixNumb;
		res = res < 0 ? 0 : res;
		return (double) res;
	}

	public static void test() {
		// origin - 01.10.2023, last edit - 17.10.2023
		
		// strEqual
		String str2 = "test1";
		for (String testArg1 : new String[] { "test1", "test1 ", " tEst1", "TEST1", "test22" }) {
			WB.addEvent("res=" + strEqual(testArg1,str2) + ", str1=" + testArg1+ ", str2=" + str2, "strEqual()", "Calc.test()");
		}

		// ratio
		for (double testArg1 : new double[] { 100.0, 67.43, 0.00, 23.56452, 12.0, 234.65432 }) {
			WB.addEvent("res=" + ratio100(testArg1) + ", rateTax=" + testArg1, "ratio100()", "Calc.test()");
		}

		// getSumTax
		for (double testArg11 : new double[] { 100.0, 567.43, 0.00, 323.56452 }) {
			WB.addEvent(
					"res=" + getSumTax(testArg11, rateVAT, round2) + ", baseTax=" + testArg11 + ", RateTax=" + rateVAT,
					"getSumTax()", "Calc.test()");
			// check
			WB.addEvent(
					"check, res=" + getOutVAT(testArg11, rateVAT) + ", baseTax=" + testArg11 + ", RateTax=" + rateVAT,
					"getOutVAT()", "Calc.test()");
		}

		// getRateVAT
		WB.addEvent("res=" + getRateVAT(LocalDate.now(), WB.currContext), "getRateVAT()", "Calc.test()");

		// subtractInVAT
		for (double testArg11 : new double[] { 112.0, 567.68, 0.00, 342.8456 }) {
			WB.addEvent(
					"res=" + subtractInVAT(testArg11, rateVAT) + ", sumWithVAT=" + testArg11 + ", rateVAT=" + rateVAT,
					"subtractInVAT()", "Calc.test()");
			// reverse check
			WB.addEvent("reverse check, res=" + addOutVAT(subtractInVAT(testArg11, rateVAT), rateVAT) + ", sumLessVAT="
					+ subtractInVAT(testArg11, rateVAT) + ", rateVAT=" + rateVAT, "addOutVAT()", "Calc.test()");
		}

//		// roundCustom - round2
//		for (double testArg1 : new double[] { 100.0, 57.4363, 43.0078, 21.212, 34.7845 }) {
//			WB.addEvent("res=" + roundCustom(testArg1, round2) + "), (sumLessRound=" + testArg1
//					+ ", numberFractionalDigit=" + round2, "roundCustom()", "Calc.test()");
//		}
//		// roundCustom - round0
//		for (double testArg1 : new double[] { 100.0, 57.4363, 43.0078, 21.212, 34.7845 }) {
//			WB.addEvent("res=" + roundCustom(testArg1, round0) + "), (sumLessRound=" + testArg1
//					+ ", numberFractionalDigit=" + round0, "roundCustom()", "Calc.test()");
//		}
//
		// addOutVAT
		for (double testArg1 : new double[] { 100.0, 567.43, 0.00, 323.56452 }) {
			WB.addEvent("res=" + addOutVAT(testArg1, rateVAT) + ", sumLessVAT=" + testArg1 + ", rateVAT=" + rateVAT,
					"addOutVAT()", "Calc.test()");
		}

		// getOutVAT
		for (double testArg1 : new double[] { 100.0, 567.43, 0.00, 323.56452 }) {
			WB.addEvent("res=" + getOutVAT(testArg1, rateVAT) + ", sumLessVAT=" + testArg1 + ", rateVAT=" + rateVAT,
					"getOutVAT()", "Calc.test()");
		}

		// getInVAT
		for (double testArg1 : new double[] { 112.0, 567.68, 0.00, 342.8456 }) {
			WB.addEvent("res=" + getInVAT(testArg1, rateVAT) + ", sumWithVAT=" + testArg1 + ", rateVAT=" + rateVAT,
					"getInVAT()", "Calc.test()");
		}

//		// fixLocalDate
//		for (LocalDate testArg1 : new LocalDate[] { LocalDate.of(2026, 4, 28), LocalDate.of(1967, 11, 25),
//				LocalDate.of(2100, 5, 26) }) {
//			WB.addEvent("res=" + fixLocalDate(testArg1) + ", fixDate=" + testArg1, "fixLocalDate()", "Calc.test()");
//		}
//
//		// fixTrim
//		for (String testArg1 : new String[] { "test1", "test2 ", " test3", " test4 " }) {
//			WB.addEvent("res=" + fixTrim(testArg1) + ", fixStr=" + testArg1, "fixTrim()", "Calc.test()");
//		}
//
//		// setZeroOnNeg
//		for (double testArg1 : new double[] { 1.25, -41.2556, 0.0, 0.0002, -0.0002, 64.1278 }) {
//			WB.addEvent("res=" + setZeroOnNeg(testArg1) + ", fixNumb=" + testArg1, "setZeroOnNeg()", "Calc.test()");
//		}
	}
}
