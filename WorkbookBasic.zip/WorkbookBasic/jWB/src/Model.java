import java.time.LocalDateTime;

public class Model {
	// origin - 26.09.2023, last edit - 14.10.2023
	public String id;
	public Model parent;
	public LocalDateTime date1;
	public String date2;
	public String code;
	public String description;
	public String more;
	public String fullDescription;
	public String fullName;
	public String shortDescription;
	public String shortName;
	public String basic;

	public static void test() {
		// origin - 26.09.2023, last edit - 14.10.2023
		try {
			WB.addEvent(new Account(), "testAccount", "Model.test()");
			WB.addEvent(new Asset(), "testAsset", "Model.test()");
			WB.addEvent(new Deal(), "testDeal", "Model.test()");
			WB.addEvent(new Debt(), "testDebt", "Model.test()");
			WB.addEvent(new Face(), "testFace", "Model.test()");
			WB.addEvent(new Geo(), "testGeo", "Model.test()");
			WB.addEvent(new Info(), "testInfo", "Model.test()");
			WB.addEvent(new Item(), "testItem", "Model.test()");
			WB.addEvent(new Mark(), "testMark", "Model.test()");
			WB.addEvent(new Meter(), "testMeter", "Model.test()");
			WB.addEvent(new Price(), "testPrice", "Model.test()");
			WB.addEvent(new Process(), "testProcess", "Model.test()");
			WB.addEvent(new Role(), "testRole", "Model.test()");
			WB.addEvent(new Sign(), "testSign", "Model.test()");
			WB.addEvent(new Slice(), "testSlice", "Model.test()");
			WB.addEvent(new Unit(), "testUnit", "Model.test()");
			WB.addEvent(new Workbook(), "testWorkbook", "Model.test()");
			WB.addEvent(new Abc(), "testAbc", "Model.test()");
			WB.addEvent(new Exchange(), "testExchange", "Model.test()");
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		} finally {
		}
	}

	public String toString() {
		// origin - 27.09.2023, last edit - 14.10.2023
		return this.getClass().getName() + "{" + "id='" + id + '\'' + ", code=" + code + ", description=" + description
				+ '}';
	}
}
