import java.time.LocalDateTime;

public class Model {// create - 26.09.2023, last edit - 28.09.2023
	public String id;
	public Model parent;
	public LocalDateTime date1;
	public String date2;
	public String code;
	public String description;
	public String more;
	public String fullDescription;
	public String fullName;
	public String shortDescription;
	public String shortName;
	public String basic;

	public static void test() {// create - 26.09.2023, last edit - 28.09.2023
		try {
			Account testAccount = new Account();
			WB.eventAdd(testAccount, "testAccount", "Model.test()");
			Asset testAsset = new Asset();
			WB.eventAdd(testAsset, "testAsset", "Model.test()");
			Deal testDeal = new Deal();
			WB.eventAdd(testDeal, "testDeal", "Model.test()");
			Debt testDebt = new Debt();
			WB.eventAdd(testDebt, "testDebt", "Model.test()");
			Face testFace = new Face();
			WB.eventAdd(testFace, "testFace", "Model.test()");
			Geo testGeo = new Geo();
			WB.eventAdd(testGeo, "testGeo", "Model.test()");
			Info testInfo = new Info();
			WB.eventAdd(testInfo, "testInfo", "Model.test()");
			Item testItem = new Item();
			WB.eventAdd(testItem, "testItem", "Model.test()");
			Mark testMark = new Mark();
			WB.eventAdd(testMark, "testMark", "Model.test()");
			Meter testMeter = new Meter();
			WB.eventAdd(testMeter, "testMeter", "Model.test()");
			Price testPrice = new Price();
			WB.eventAdd(testPrice, "testPrice", "Model.test()");
			Process testProcess = new Process();
			WB.eventAdd(testProcess, "testProcess", "Model.test()");
			Role testRole = new Role();
			WB.eventAdd(testRole, "testRole", "Model.test()");
			Sign testSign = new Sign();
			WB.eventAdd(testSign, "testSign", "Model.test()");
			Slice testSlice = new Slice();
			WB.eventAdd(testSlice, "testSlice", "Model.test()");
			Unit testUnit = new Unit();
			WB.eventAdd(testUnit, "testUnit", "Model.test()");
			Workbook testWorkbook = new Workbook();
			WB.eventAdd(testWorkbook, "testWorkbook", "Model.test()");
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		} finally {
		}
	}

	public String toString() {// create - 27.09.2023, last edit - 27.09.2023
		return this.getClass().getName() + "{" + "id='" + id + '\'' + ", code=" + code + ", description=" + description
				+ '}';
	}
}
