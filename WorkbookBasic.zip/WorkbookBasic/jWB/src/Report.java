public class Report extends Model {
	// origin - 16.10.2023, last edit - 16.10.2023
	public Face face1;
	public Face face2;
	public Face face;
	public Slice slice;
	public Geo geo;
	public Account account;
	public Asset asset;
	public Deal deal;
	public Item item;
	public Debt debt;
	public Role role;
	public Info info;
	public Mark mark;
}
