import java.time.LocalTime;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import javax.swing.*;

public class WB extends JFrame {
	// origin - 25.09.2023, last edit - 18.10.2023
	private static final long serialVersionUID = 1L;
	public static String startDir = System.getProperty("user.dir");
	public static String lastSaveDir = System.getProperty("user.dir");
	public static String lastSelectFileDir = System.getProperty("user.dir");
	public static String dbDir = System.getProperty("user.dir")+File.separator+"DB";
	public static String mediaDir = System.getProperty("user.dir")+File.separator+"Media";
	public static String swiftDir = System.getProperty("user.dir")+File.separator+"Swift";
	public static String docDir = System.getProperty("user.dir")+File.separator+"Doc";
	public static int eventCounter = 0;
	public static StringBuilder eventLog = new StringBuilder("");
	public static String eventLogFile = new String(startDir+File.separator+"WB.eventLogFile.txt");
	public static LocalDate startDate = LocalDate.of(2000, 01, 01);  
    public static LocalDate endDate = LocalDate.of(2060, 12, 31);
    public static Workbook currContext = new Workbook();

	public static void main(String[] args) {
		// origin - 25.09.2023, last edit - 14.09.2023
		try {
			onStartApp();
			
		} catch (Exception ex) {
			System.out.println(ex.getMessage());	
		} finally {
			eventTrace();
		}
	}

	public static void onStartApp() {
		// origin - 25.09.2023, last edit - 18.10.2023
		try {
			//WB.test();
			//Model.test();
			//ModelDto.test();
			Calc.test();
			// WB.testTable();
			//getGui();
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		} finally {
		}
	}
	
	public static void getGui() {
		// origin - 06.10.2023, last edit - 15.10.2023
		JFrame window = new JFrame("Workbook Basic, ");
		JPanel panel = new JPanel();
		//JButton button = new JButton("Click me!");
		//panel.add(button);
		window.add(panel);
		window.setSize(800,400);
		//button.addActionListener(e -> System.out.println("Ouch! You clicked me!"));
		window.setVisible(true);
	}

	public static void test() {
		// origin - 25.09.2023, last edit - 18.10.2023
		//TODO - check real exist test objects
		WB.addEvent(startDir, "WB.startDir", "WB.test()");
		WB.addEvent(lastSaveDir, "WB.lastSaveDir", "WB.test()");
		WB.addEvent(lastSelectFileDir, "WB.lastSelectFileDir", "WB.test()");
		WB.addEvent(dbDir, "WB.dbDir", "WB.test()");
		WB.addEvent(mediaDir, "WB.mediaDir", "WB.test()");
		WB.addEvent(swiftDir, "WB.swiftDir", "WB.test()");
		WB.addEvent(docDir, "WB.docDir", "WB.test()");
		WB.addEvent(eventLogFile, "WB.eventLogFile", "WB.test()");
	}

	public static void addEvent(Object EventObj, String EventCont, String EventMeth) {
		// origin - 26.09.2023, last edit - 14.10.2023
		eventCounter = eventCounter + 1;
		LocalDate ld = LocalDate.now();
		LocalTime lt = LocalTime.now();
		String currEventAdd = "[#" + eventCounter + "] (" + lt.atDate(ld).toString() + "), ("
				+ EventObj.toString() + "), (" + EventCont.toString() + "), (" + EventMeth.toString() + ")"
				+ System.lineSeparator();
		eventLog.append(currEventAdd.toString());
	}

	public static void openEventLog() {
		// origin - 15.10.2023, last edit - 16.10.2023
		try {
			// TODO if exist eclipse then it probably computer developers
			//java.lang.Process p = new ProcessBuilder("notepad.exe", WB.eventLogFile.toString()).start();
			new ProcessBuilder("notepad.exe", eventLogFile.toString()).start();
			//p.toString();
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		} finally {
		}
	}

	public static void eventTrace() {
		// origin - 26.09.2023, last edit - 15.10.2023
		try {
			//System.out.println(eventLog.toString());
			System.out.println(Files.write(Paths.get(eventLogFile), eventLog.toString().getBytes("utf-8")));
			openEventLog();
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		} finally {
		}
	}
}
