import java.time.LocalTime;
import java.time.LocalDate;

public class WB {// create - 25.09.2023, last edit - 28.09.2023
	// public static Context currCont = new Context();

	public static void main(String[] args) {// create - 25.09.2023, last edit - 27.09.2023
		try {
			onStartApp();
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		} finally {
			eventTrace();
		}
	}

	public static void onStartApp() {// create - 25.09.2023, last edit - 27.09.2023
		try {
			test();
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		} finally {
		}
	}

	public static void test() {// create - 25.09.2023, last edit - 28.09.2023
		//WB.testContext();
		Model.test();
		// WB.testTable();
	}

	public static void testContext() {// create - 25.09.2023, last edit - 27.09.2023
		WB.eventAdd(Context.startDirectory, "Context.StartDirectory", "TestContext()");
		WB.eventAdd(Context.lastSaveDirectory, "Context.LastSaveDirectory", "TestContext()");
		WB.eventAdd(Context.lastSelectFileDirectory, "Context.LastSelectFileDirectory", "TestContext()");
	}

	public static class Context {// create - 25.09.2023, last edit - 27.09.2023
		public static String startDirectory = System.getProperty("user.dir");
		public static String lastSaveDirectory = System.getProperty("user.dir");
		public static String lastSelectFileDirectory = System.getProperty("user.dir");
		public static int eventCounter = 0;
		public static StringBuilder eventLog = new StringBuilder("");
		public static LocalDate startDate = LocalDate.of(2000, 01, 01);  
        public static LocalDate endDate = LocalDate.of(2060, 12, 31);
	}

	public static void eventAdd(Object EventObj, String EventCont, String EventMeth) {// create - 26.09.2023, last edit - 27.09.2023
		Context.eventCounter = Context.eventCounter + 1;
		LocalDate ld = LocalDate.now();
		LocalTime lt = LocalTime.now();
		String currEventAdd = "[#" + Context.eventCounter + "] (" + lt.atDate(ld).toString() + "), ("
				+ EventObj.toString() + "), (" + EventCont.toString() + "), (" + EventMeth.toString() + ")"
				+ System.lineSeparator();
		Context.eventLog.append(currEventAdd.toString());
	}

	public static void eventTrace() {// create - 26.09.2023, last edit - 27.09.2023
		try {
			System.out.println(Context.eventLog.toString());
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		} finally {
		}
	}
}
