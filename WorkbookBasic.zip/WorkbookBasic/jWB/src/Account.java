public class Account extends Model {// create - 27.09.2023, last edit - 28.09.2023
	 public Slice slice;
	 public Role role;
	 public Sign sign;
	 //public static Workbook acctTableClosing;
	public Account accountTable;
}