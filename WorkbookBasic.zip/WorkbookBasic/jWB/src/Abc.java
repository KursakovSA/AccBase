import java.util.TreeSet;

public class Abc extends Model  {
	// origin - 28.09.2023, last edit - 16.10.2023
	public TreeSet<? extends Model> basic;
	public TreeSet<? extends Model> catalogAsset;
    public TreeSet<? extends Model> codePayInfo;
    public TreeSet<? extends Model> exchange;
    public TreeSet<? extends Model> markupPrice;
    public TreeSet<? extends Model> salePrice;
    public TreeSet<? extends Model> relay;
    public TreeSet<? extends Model> accountTable;
    public TreeSet<? extends Model> accountMatching;
    public TreeSet<? extends Model> accountClose;
    public TreeSet<? extends Model> storeFace;
    public TreeSet<? extends Model> userFace;
    public TreeSet<? extends Model> departmentFace;
    public TreeSet<? extends Model> cashFace;
    public TreeSet<? extends Model> bankFace;
    public TreeSet<? extends Model> staffTableFace;
    public TreeSet<? extends Model> example;
    public TreeSet<? extends Model> template;
    public TreeSet<? extends Model> root;
    public TreeSet<? extends Model> report;
    public TreeSet<? extends Model> table;
    public TreeSet<? extends Model> segmentTax;
}
