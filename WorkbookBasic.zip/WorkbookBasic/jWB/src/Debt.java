public class Debt extends Model {// create - 28.09.2023, last edit - 28.09.2023
	 public Geo geo;
	 public Role role;
	 public Info info;
}
