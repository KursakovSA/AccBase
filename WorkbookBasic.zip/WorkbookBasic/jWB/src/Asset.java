public class Asset extends Model {
	// origin - 28.09.2023, last edit - 14.10.2023
	 public Geo geo;
	 public Role role;
	 public Info info;
	 public Unit unit;
}