public class Exchange extends Model  {
	// origin - 30.09.2023, last edit - 14.10.2023
	public Role Role;
	public String TargetPath;
	public String TargetFileName;
	public String TargetExchange;

	public StringBuilder SwiftOPV(Workbook WorkbookSalary) {
		// origin - 30.09.2023, last edit - 14.10.2023
		StringBuilder TextSwift = new StringBuilder();

		WB.addEvent(TextSwift.length(), "TextSwift.length()", "Exchange.SwiftOPV()");
		return TextSwift;
	}
}
