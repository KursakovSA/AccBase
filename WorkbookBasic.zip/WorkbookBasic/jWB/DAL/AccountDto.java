public class AccountDto extends ModelDto {
	// origin - 30.09.2023, last edit - 14.10.2023
	public String slice;
	public String role;
	public String sign;
}