public class UnitDto extends ModelDto {
	// origin - 01.10.2023, last edit - 14.10.2023
	public String role;
}
