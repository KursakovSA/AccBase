public class DealDto extends ModelDto {
	// origin - 01.10.2023, last edit - 14.10.2023
	public String face1;
    public String face2;
    public String face;
    public String geo;
    public String role;
    public String info;
}
