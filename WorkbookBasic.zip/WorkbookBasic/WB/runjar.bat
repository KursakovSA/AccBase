@echo off
start C:\openjdk\jdk-21.0.1\bin\javaw.exe -jar %1