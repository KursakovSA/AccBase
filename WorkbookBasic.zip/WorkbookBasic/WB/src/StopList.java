import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class StopList {
	// origin - 23.08.2024, last edit - 26.08.2024
	@SuppressWarnings("unused")
	private String id = new String(); // "BorrowerId", etc.//TOTHINK
	@SuppressWarnings("unused")
	private String table = new String();
	@SuppressWarnings("unused")
	private Boolean idMilitaryService = false;
	@SuppressWarnings({ "unused" })
	private String fileNameCommon = "stoplist1.csv";
	@SuppressWarnings("unused")
	private List<ModelDto> position = new ArrayList<ModelDto>();

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("StopList.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "StopList");
		} finally {
			Etc.doNothing();
		}
	}

	@SuppressWarnings("unused")
	private Boolean listed(LocalDate dateNow, String idPerson) throws Exception {// TODO
		// origin - 24.08.2024, last edit - 24.08.2024
		Boolean res = false;
		try {
			// res = ModelDto.getValueField(segmentAbc, idListVal, codeListVal, ListVal.defaultListVal);
		} catch (Exception ex) {
			WB.addLog("StopList.listed, ex=" + ex.getMessage(), WB.strEmpty, "StopList");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("StopList.listed, res=" + res + ", segmentAbc=" + segmentAbc
		// + ", idListVal=" + idListVal, + ", codeListVal" + codeListVal
		// WB.strEmpty, "StopList");
		return res;
	}

	public StopList() throws Exception {
		// origin - 23.08.2024, last edit - 26.08.2024
		this.idMilitaryService = true;
	}

	public static void test() throws Exception {
		// origin - 23.08.2024, last edit - 23.08.2024
		try {

		} catch (Exception ex) {
			WB.addLog("StopList.test, ex=" + ex.getMessage(), WB.strEmpty, "StopList");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("StopList.test end ", WB.strEmpty, "StopList");
	}
}
