public class Action {
	// origin - 13.12.2023, last edit - 13.12.2023
	public static Action exit;
}
