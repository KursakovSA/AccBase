import java.util.ArrayList;
import java.util.List;

public class StaffTable {
	// origin - 09.03.2025, last edit - 14.03.2025
	public boolean isValid, isExist;
	public String table, src, id, parent, code, description, geo, role, info, mark, empId, fullName, comment;
	public ListVal date1, date2, salary;
	public List<FaceDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("StaffTable.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "StaffTable");
		}
	}

	// full list StaffTable positions on date1 (currSalary)
	public static List<FaceDto> getCurr(String date1, String parentId, String context) throws Exception {// context for
																											// different
		// origin - 11.03.2025, last edit - 14.03.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceByParent = DAL.getByTemplate(WB.lastConnWork, Qry.getParentFilter(parentId), "Face");
			for (var currFace : faceByParent) {
				if (Etc.strEquals(currFace.role, Role.faceStaffTable)) {
					var currFaceStaffTableNote = new StaffTable(currFace.id);
					var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceStaffTableNote.val, WB.strEmpty);
					if (curr.id.isEmpty() == false) {
						var tmp = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
								curr.geo, curr.role, curr.info, curr.more, curr.mark);
						res.add(tmp); // curr.more = currSalary
						// WB.addLog2("StaffTable.getVal, add tmp=" + tmp, WB.strEmpty,"StaffTable");
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("StaffTable.getCurr(List<FaceDto>), ex=" + ex.getMessage(), WB.strEmpty, "StaffTable");
		}
		return res;
	}

	// item StaffTable position on date1 (currSalary)
	public static FaceDto getCurr(String date1, String staffTableId) throws Exception {
		// origin - 09.03.2025, last edit - 14.03.2025
		FaceDto res = new FaceDto();
		try {
			var currFaceStaffTableNote = new StaffTable(staffTableId);
			var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceStaffTableNote.val, WB.strEmpty);
			if (curr.id.isEmpty() == false) {
				res = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description, curr.geo,
						curr.role, curr.info, curr.more, curr.mark); // curr.more = currSalary
			}
		} catch (Exception ex) {
			WB.addLog("StaffTable.getCurr(FaceDto), ex=" + ex.getMessage(), WB.strEmpty, "StaffTable");
		}
		return res;
	}

	private void getVal() throws Exception {
		// origin - 09.03.2025, last edit - 14.03.2025
		try {
			String currDate1 = WB.strEmpty;
			String currDate2 = WB.strEmpty;
			String currSalary = WB.strEmpty;
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currSalary = this.salary.getByIndex(i);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description, this.geo,
						this.role, this.info, currSalary, this.mark); // currSalary -> more
				this.val.add(tmp);
//				WB.addLog2("StaffTable.getVal, add tmp=" + tmp, WB.strEmpty,"StaffTable");
			}
		} catch (Exception ex) {
			WB.addLog("StaffTable.getVal, ex=" + ex.getMessage(), WB.strEmpty, "StaffTable");
		}
	}

	public void isExist() throws Exception {
		// origin - 09.03.2025, last edit - 14.03.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getCodeFilter(this.code), this.table);
			if (listDto.size() != WB.intZero) {
				for (var currDto : listDto) {
					if ((Etc.strEquals(currDto.role, Role.faceStaffTable))) {
						this.date1 = new ListVal(currDto.date1, WB.strEmpty);
						this.date2 = new ListVal(currDto.date2, WB.strEmpty);

						this.id = DefVal.setCustom(this.id, currDto.id);
						this.parent = DefVal.setCustom(this.parent, currDto.parent);
						this.code = DefVal.setCustom(this.code, currDto.code);
						this.description = DefVal.setCustom(this.description, currDto.description);
						this.geo = DefVal.setCustom(this.geo, currDto.geo);
						this.role = DefVal.setCustom(this.role, currDto.role);
						this.info = DefVal.setCustom(this.info, currDto.info);

						this.empId = MoreVal.getFieldByKey(currDto.more, "EmpId");
						this.fullName = MoreVal.getFieldByKey(currDto.more, "FullName");
						this.comment = MoreVal.getFieldByKey(currDto.more, "Comment");

						this.salary = new ListVal(MoreVal.getFieldByKey(currDto.more, "Salary"), WB.strEmpty);
						// WB.addLog2("StaffTable.isExist, this.salary.id=" +
						// this.salary.id,WB.strEmpty, "StaffTable");

						this.mark = DefVal.setCustom(this.mark, currDto.mark);
						this.isExist = true;
						break;
					}
				}
			}

		} catch (Exception ex) {
			WB.addLog("StaffTable.isExist, ex=" + ex.getMessage(), WB.strEmpty, "StaffTable");
		}
	}

	public StaffTable(String StaffTableId) throws Exception {
		// origin - 09.03.2025, last edit - 09.03.2025
		this();
		this.table = "Face"; // ??magic string??
		this.src = StaffTableId;
		this.code = StaffTableId;
		this.isExist();
		this.getVal();
	}

	public void clear() throws Exception {
		// origin - 09.03.2025, last edit - 14.03.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.mark = WB.strEmpty;
			this.date1 = this.date2 = this.salary = new ListVal();
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("StaffTable.clear, ex=" + ex.getMessage(), WB.strEmpty, "StaffTable");
		}
	}

	public StaffTable() throws Exception {
		// origin - 09.03.2025, last edit - 09.03.2025
		this.clear();
	}

	public String toString() {
		// origin - 09.03.2025, last edit - 10.03.2025
		String res = WB.strEmpty;
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);

			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);

			res = res + Fmtr.addIfNotEmpty(", empid ", this.empId);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);

			res = res + Fmtr.addIfNotEmpty(", salary ", this.salary.id);

			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 09.03.2025, last edit - 14.03.2025
		try {

//			// getCurr(List<FaceDto>)
//			for (var tmp1 : new String[] { "2025-01-31", "2025-02-20", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
//					WB.addLog2("StaffTable.test.getCurr(List<FaceDto>), res.size="
//							+ StaffTable.getCurr(tmp1, tmp2, WB.strEmpty).size() + ", date1=" + tmp1
//							+ ", parentId=" + tmp2, WB.strEmpty, "StaffTable");
//				}
//			}

//			// getCurr(FaceDto)
//			for (var tmp1 : new String[] { "2025-01-31", "2025-02-20", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1.StaffTable1.Boss", "Face.FA1.StaffTable1.ChiefAccountant",
//						"Face.FA1.StaffTable1.Tralala" }) {
//					WB.addLog2("StaffTable.test.getCurr, res.more(salary)="
//							+ StaffTable.getCurr(tmp1, tmp2).more + ", date1=" + tmp1 + ", staffTableId="
//							+ tmp2, WB.strEmpty, "StaffTable");
//				}
//			}

//			// ctor()
//			WB.addLog2("StaffTable.test.ctor()=" + new StaffTable(), WB.strEmpty, "StaffTable");

//			// ctor (String)
//			for (var tmp1 : new String[] { "Face.FA1.StaffTable1.Boss", "Face.FA1.StaffTable1.ChiefAccountant",
//					"Face.FA1.StaffTable1.Tralala" }) {
//				WB.addLog2("StaffTable.test.ctor(String)=" + new StaffTable(tmp1), WB.strEmpty,"StaffTable");
//			}

		} catch (Exception ex) {
			WB.addLog("StaffTable.test, ex=" + ex.getMessage(), WB.strEmpty, "StaffTable");
		}
	}
}