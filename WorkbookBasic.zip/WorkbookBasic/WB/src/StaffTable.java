import java.util.ArrayList;
import java.util.List;

public class StaffTable {
	// origin - 09.03.2025, last edit - 03.05.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, code, description, geo, role, info, mark;
	// special fields
	public String deptId, empId, fullName, comment;
	// special timestamp fields
	public ListVal date1, date2, salary;
	// list common + special + timestamp fields in unified val
	public List<FaceDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("StaffTable.static ctor, ex=" + ex.getMessage(), "", "StaffTable");
		}
	}

	// full list StaffTable.empId on date1
	public static List<String> getCurrEmpId(String date1, String parentFAId) throws Exception {
		// origin - 22.04.2025, last edit - 22.04.2025
		List<String> res = new ArrayList<String>();
		try {
			var staffTable = StaffTable.getCurr(date1, parentFAId);
			for (var curr : staffTable) {
				if (curr.empId.isEmpty() == false) {
					res.add(curr.empId);
				}
			}
		} catch (Exception ex) {
			WB.addLog("StaffTable.getCurrEmpId(List<String>), ex=" + ex.getMessage(), "", "StaffTable");
		}
		return res;
	}

	// item StaffTable position salary on date1
	public static double getCurrSalary(String date1, String parentId, String staffTableId) throws Exception {
		// origin - 28.03.2025, last edit - 28.03.2025
		double res = 0.00;
		try {
			var tmp = StaffTable.getCurr(date1, parentId, staffTableId).salary;
			res = Conv.getDouble(tmp);
		} catch (Exception ex) {
			WB.addLog("StaffTable.getCurrSalary(double), ex=" + ex.getMessage(), "", "StaffTable");
		}
		return res;
	}

	// full list StaffTable
	public static List<FaceDto> get(String parentId) throws Exception {
		// origin - 04.05.2025, last edit - 04.05.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, Role.faceStaffTable),
					"Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					for (var curr : new StaffTable(currFace.parent, currFace.code).val) {
						if (curr.id.isEmpty() == false) {
							var tmp = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code,
									curr.description, curr.geo, curr.role, curr.info, curr.more, curr.mark);
							tmp.salary = curr.salary;
							tmp.deptId = curr.deptId;
							tmp.empId = curr.empId;
							tmp.comment = curr.comment;
							tmp.fullName = curr.fullName;
							res.add(tmp);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("StaffTable.get(List<FaceDto>), ex=" + ex.getMessage(), "", "StaffTable");
		}
		return res;
	}

	// full list StaffTable on date1
	public static List<FaceDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 11.03.2025, last edit - 03.05.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, Role.faceStaffTable),
					"Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					var currFaceStaffTable = new StaffTable(currFace.parent, currFace.code);
					var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceStaffTable.val, "");
					if (curr.id.isEmpty() == false) {
						var tmp = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
								curr.geo, curr.role, curr.info, curr.more, curr.mark);
						tmp.salary = curr.salary;
						tmp.deptId = curr.deptId;
						tmp.empId = curr.empId;
						tmp.comment = curr.comment;
						tmp.fullName = curr.fullName;
						res.add(tmp);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("StaffTable.getCurr(List<FaceDto>), ex=" + ex.getMessage(), "", "StaffTable");
		}
		return res;
	}

	// item StaffTable on date1
	public static FaceDto getCurr(String date1, String parentId, String staffTableId) throws Exception {
		// origin - 09.03.2025, last edit - 03.05.2025
		FaceDto res = new FaceDto();
		try {
			var currStaffTable = new StaffTable(parentId, staffTableId);
			var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currStaffTable.val, "");
			if (curr.id.isEmpty() == false) {
				res = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description, curr.geo,
						curr.role, curr.info, curr.more, curr.mark);
				res.salary = curr.salary;
				res.deptId = curr.deptId;
				res.empId = curr.empId;
				res.comment = curr.comment;
				res.fullName = curr.fullName;
			}
		} catch (Exception ex) {
			WB.addLog("StaffTable.getCurr(FaceDto), ex=" + ex.getMessage(), "", "StaffTable");
		}
		return res;
	}

	private void getVal() throws Exception {
		// origin - 09.03.2025, last edit - 03.05.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currSalary = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currSalary = this.salary.getByIndex(i);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description, this.geo,
						this.role, this.info, currSalary, this.mark);
				tmp.salary = currSalary;
				tmp.deptId = this.deptId;
				tmp.empId = this.empId;
				tmp.comment = this.comment;
				tmp.fullName = this.fullName;
				this.val.add(tmp);
//				WB.addLog2("StaffTable.getVal, add tmp=" + tmp, ","StaffTable");
			}
		} catch (Exception ex) {
			WB.addLog("StaffTable.getVal, ex=" + ex.getMessage(), "", "StaffTable");
		}
	}

	private void isExist() throws Exception {
		// origin - 09.03.2025, last edit - 03.05.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentCodeRoleFilter(this.parent, this.code, Role.faceStaffTable), this.table);
			if (listDto.size() != 0) {
				for (var currDto : listDto) {
					var tmp = new SpanDate(currDto.date1, currDto.date2);
					this.date1 = new ListVal(tmp.date1);
					this.date2 = new ListVal(tmp.date2);

					this.id = DefVal.setCustom(this.id, currDto.id);
					this.parent = DefVal.setCustom(this.parent, currDto.parent);
					this.code = DefVal.setCustom(this.code, currDto.code);
					this.description = DefVal.setCustom(this.description, currDto.description);
					this.geo = DefVal.setCustom(this.geo, currDto.geo);
					this.role = DefVal.setCustom(this.role, currDto.role);
					this.info = DefVal.setCustom(this.info, currDto.info);

					this.deptId = MoreVal.getFieldByKey(currDto.more, "DeptId");
					this.empId = MoreVal.getFieldByKey(currDto.more, "EmpId");
					this.fullName = MoreVal.getFieldByKey(currDto.more, "FullName");
					this.comment = MoreVal.getFieldByKey(currDto.more, "Comment");
					this.salary = new ListVal(MoreVal.getFieldByKey(currDto.more, "Salary"), "");

					this.mark = DefVal.setCustom(this.mark, currDto.mark);
					this.isExist = true;
					break;
				}
			}

			if (listDto.size() == 0) {
				this.parent = this.code = "";
			}
		} catch (Exception ex) {
			WB.addLog("StaffTable.isExist, ex=" + ex.getMessage(), "", "StaffTable");
		}
	}

	public StaffTable(String ParentId, String StaffTableId) throws Exception {
		// origin - 09.03.2025, last edit - 28.03.2025
		this();
		this.table = "Face";
		this.src = ParentId + ", " + StaffTableId;
		this.parent = ParentId;
		this.code = StaffTableId;
		this.isExist();
		this.getVal();
	}

	private void clear() throws Exception {
		// origin - 09.03.2025, last edit - 03.05.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.mark = "";
			this.deptId = this.empId = this.fullName = this.comment = "";
			this.date1 = this.date2 = this.salary = new ListVal();
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("StaffTable.clear, ex=" + ex.getMessage(), "", "StaffTable");
		}
	}

	public StaffTable() throws Exception {
		// origin - 09.03.2025, last edit - 09.03.2025
		this.clear();
	}

	public String toString() {
		// origin - 09.03.2025, last edit - 03.05.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);

			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);

			res = res + Fmtr.addIfNotEmpty(", deptId ", this.deptId);
			res = res + Fmtr.addIfNotEmpty(", empId ", this.empId);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);

			res = res + Fmtr.addIfNotEmpty(", salary ", this.salary.id);

			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 09.03.2025, last edit - 04.05.2025
		try {

//			// get(List<FaceDto>)
//			WB.addLog2("StaffTable.test.get(List<FaceDto>)", "", "StaffTable");
//			for (var tmp1 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
//				WB.addLog2("StaffTable.test.get(List<FaceDto>), res.size=" + Address.get(tmp1).size() + ", parentId="
//						+ tmp1, "", "StaffTable");
//				FaceDto.log(StaffTable.get(tmp1));
//			}

//			// getCurrEmpId(List<String>)
//			WB.addLog2("StaffTable.test.getCurrEmpId(List<String>)", "", "StaffTable");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-15", "2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1" }) {
//					WB.addLog2("StaffTable.test.getCurrEmpId(List<String>), res=" + StaffTable.getCurrEmpId(tmp1, tmp2)
//							+ ", date1=" + tmp1 + ", parentFAId=" + tmp2, "", "StaffTable");
//				}
//			}

//			// getCurrSalary(double)
//			WB.addLog2("StaffTable.test.getCurrSalary(double)", "", "StaffTable");
//			for (var tmp1 : new String[] { "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01", "2025-02-28",
//					"2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1" }) {
//					for (var tmp3 : new String[] { "Face.FA1.StaffTable1.Boss",
//							"Face.FA1.StaffTable1.ChiefAccountant" }) {
//						WB.addLog2("StaffTable.test.getCurrSalary(double), res="
//								+ StaffTable.getCurrSalary(tmp1, tmp2, tmp3) + ", date1=" + tmp1 + ", parentId=" + tmp2
//								+ ", staffTableId=" + tmp3, "", "StaffTable");
//					}
//				}
//			}

//			// getCurr(List<FaceDto>)
//			WB.addLog2("StaffTable.test.getCurr(List<FaceDto>)", "", "StaffTable");
//			for (var tmp1 : new String[] { "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01", "2025-02-15",
//					"2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1" }) {
//					WB.addLog2("StaffTable.test.getCurr(List<FaceDto>), res.size="
//							+ StaffTable.getCurr(tmp1, tmp2).size() + ", date1=" + tmp1 + ", parentId=" + tmp2, "",
//							"StaffTable");
//			FaceDto.log(StaffTable.getCurr(tmp1, tmp2));
//				}
//			}

//			// getCurr(FaceDto)
//			WB.addLog2("StaffTable.test.getCurr(FaceDto)", "", "StaffTable");
//			for (var tmp1 : new String[] { "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01", "2025-02-28",
//					"2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1" }) {
//					for (var tmp3 : new String[] { "Face.FA1.StaffTable1.Boss",
//							"Face.FA1.StaffTable1.ChiefAccountant" }) {
//						WB.addLog2(
//								"StaffTable.test.getCurr(FaceDto), res=" + StaffTable.getCurr(tmp1, tmp2, tmp3)
//										+ ", date1=" + tmp1 + ", parentId=" + tmp2 + ", staffTableId=" + tmp3,
//								"", "StaffTable");
//					}
//				}
//			}

//			// ctor (String,String)
//			WB.addLog2("StaffTable.test.ctor(String,String)", "", "StaffTable");
//			for (var tmp1 : new String[] { "Face.FA1", "Face.Tralala" }) {
//				for (var tmp2 : new String[] { "Face.FA1.StaffTable1.Boss", "Face.FA1.StaffTable1.ChiefAccountant",
//						"Face.FA1.StaffTable1.Tralala" }) {
//					WB.addLog2("StaffTable.test.ctor(String,String)=" + new StaffTable(tmp1, tmp2), "", "StaffTable");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("StaffTable.test, ex=" + ex.getMessage(), "", "StaffTable");
		}
	}
}