public class Info extends Model {
	// origin - 06.12.2023, last edit - 06.07.2024
	public Geo parent;
	public Role role;
	public Unit unit;
	public static String argNumeric;
	public static String argCodeIIN;
	public static int argLenghtIIN;

	static {
		try {
			// root = new Info("Info", "Info", "InfoData");
			argNumeric = "Numeric";
			argCodeIIN = "Info.Code.IIN";
			argLenghtIIN = ModelDto.getLenghtField(Info.argNumeric, Info.argCodeIIN);
		} catch (Exception ex) {
			WB.addLog("WB.static ctor Info, ex=" + ex.getMessage(), WB.strEmpty, "WB");
		} finally {
			Etc.doNothing();
		}
	}

	public Info(String Id, String Code, String Description) throws Exception {
		// origin - 06.12.2023, last edit - 07.07.2024
		try {
			this.id = Id;
			this.code = Code;
			this.description = Description;
		} catch (Exception ex) {
			WB.addLog("Info.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Info");
		} finally {
			Etc.doNothing();
		}
	}

	public Info() throws Exception {
		// origin - 06.12.2023, last edit - 07.07.2024
		try {
		} catch (Exception ex) {
			WB.addLog("Info.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Info");
		} finally {
			Etc.doNothing();
		}
	}

	public static void test() throws Exception {
		// origin - 06.12.2023, last edit - 06.07.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Info.test, ex=" + ex.getMessage(), WB.strEmpty, "Info");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Info.test end ", WB.strEmpty, "Info");
	}
}
