public class Info extends Model {
	// origin - 06.12.2023, last edit - 26.06.2024
	public static Info root;
	public Geo parent;
	public Role role;
	public Unit unit;
	public static String argNumeric;
	public static String argCodeIIN;
	public static int argLenghtIIN;

	static {
		try {
			root = new Info("Info", "Info", "InfoData");
			argNumeric = "Numeric";
			argCodeIIN = "Info.Code.IIN";
			argLenghtIIN = ModelDto.getLenghtField(Info.argNumeric, Info.argCodeIIN);
		} catch (Exception ex) {
			WB.addLog("WB.static ctor Info, ex=" + ex.getMessage(), WB.strEmpty, "WB");
		} finally {
			Etc.doNothing();
		}
	}

	public Info(String Id, String Code, String Description) {
		// origin - 06.12.2023, last edit - 06.12.2023
		this.id = Id;
		this.code = Code;
		this.description = Description;
	}

	public Info() {
		// origin - 06.12.2023, last edit - 06.12.2023
	}

	public static void test() throws Exception {
		// origin - 06.12.2023, last edit - 26.06.2024
		WB.addLog("Info.test, Info.root=" + Info.root, WB.strEmpty, "Info");
	}
}
