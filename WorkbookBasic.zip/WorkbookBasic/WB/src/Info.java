import java.util.List;

public class Info extends ModelDto {
	// origin - 06.12.2023, last edit - 30.12.2024
	public static String argNumeric, argCodeIIN, genericBasic, dealBasic, assetActiv;
	public static int argLenghtIIN;

	static {
		try {
			Info.argNumeric = "Numeric";
			Info.argCodeIIN = "Info.Code.IIN";
			Info.genericBasic = "Info.Generic.Basic";
			Info.dealBasic = "Info.Deal.Basic";
			Info.assetActiv = "Info.Asset.Activ";
			Info.argLenghtIIN = Conv.getInt(MoreVal.getByKey(WB.abcLast.basic, Info.argNumeric, Info.argCodeIIN));
		} catch (Exception ex) {
			WB.addLog("Info.static ctor Info, ex=" + ex.getMessage(), WB.strEmpty, "Info");
		} finally {
			Etc.doNothing();
		}
	}

	public void isExist() throws Exception {
		// origin - 17.12.2024, last edit - 17.12.2024
		super.isExist();
		try {
			for (var currRole : WB.abcLast.info) {
				if (Etc.strEquals(currRole.id, this.id)) {
					this.slice = DefVal.setCustom(this.slice, currRole.slice);
					this.date1 = DefVal.setCustom(DateTool.getNow().toString(), currRole.date1);// this.date1,
					this.date2 = DefVal.setCustom(this.date2, currRole.date2);
					this.code = DefVal.setCustom(this.code, currRole.code);
					this.parent = DefVal.setCustom(this.parent, currRole.parent);
					this.description = DefVal.setCustom(this.description, currRole.description);
					this.more = DefVal.setCustom(this.more, currRole.more);

					this.isExist = true;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Info.isExist, ex=" + ex.getMessage(), WB.strEmpty, "Info");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Info.isExist=" + this.isExist, WB.strEmpty,"Info");
	}

	public void isValid() throws Exception {
		// origin - 17.12.2024, last edit - 17.12.2024
		super.isValid();
		try {
			if (this.date1.isEmpty()) {
				this.isValid = false;
			}
		} catch (Exception ex) {
			WB.addLog("Info.isValid, ex=" + ex.getMessage(), WB.strEmpty, "Info");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Info.isValid=" + this.isValid, WB.strEmpty,"Info");
	}

	public Info(String Id) throws Exception {
		// origin - 06.12.2023, last edit - 27.12.2024
		this();
		this.src = Id;
		if (Id.isEmpty() == false) {
			this.id = this.code = Id;
		}
		// this.date1 = DateTool.getNow().toString();
		this.isExist();
		this.isValid();
	}

	public Info() throws Exception {
		// origin - 06.12.2023, last edit - 17.12.2024
		this.clear();
		this.isExist();
		var root = Abc.getRoot(this.table);
		this.id = root.id;
		this.parent = root.parent;
		this.date1 = root.date1;
		this.date2 = root.date2;
		this.code = root.code;
		this.description = root.description;
		this.more = root.more;
	}

	public void clear() throws Exception {
		// origin - 17.12.2024, last edit - 17.12.2024
		try {
			super.clear();
			this.table = this.getClass().getName();
		} catch (Exception ex) {
			WB.addLog("Info.clear, ex=" + ex.getMessage(), WB.strEmpty, "Info");
		} finally {
			Etc.doNothing();
		}
	}

	public String toString() {
		// origin - 17.12.2024, last edit - 17.12.2024
		String res = WB.strEmpty;
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", ", this.slice);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	@SuppressWarnings("unused")
	public static void test() throws Exception {
		// origin - 06.12.2023, last edit - 27.12.2024
		try {
			var tmpList = List.of(WB.strEmpty, "Info.Asset", "Info.tralala", "Info.Deal");

//			// ctor (String Id)
//			for (var tmp : tmpList) {
//				WB.addLog2("Info.test.ctor(String)=" + new Info(tmp), WB.strEmpty, "Role");
//			}

		} catch (Exception ex) {
			WB.addLog("Info.test, ex=" + ex.getMessage(), WB.strEmpty, "Info");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Info.test end ", WB.strEmpty, "Info");
	}
}
