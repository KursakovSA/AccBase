public class Info extends Model {
	// origin - 06.12.2023, last edit - 18.01.2024
	public static Info root;
	public Geo parent;
	public Role role;
    public Unit unit;
    
    static {
		root = new Info("Info","Info","InfoData");
	}
    
    public Info(String Id, String Code, String Description) {
		// origin - 06.12.2023, last edit - 06.12.2023
		this.id = Id;
		this.code = Code;
		this.description = Description;
	}
    
    public Info() {
		// origin - 06.12.2023, last edit - 06.12.2023
	}
    
    public static void test() {
		// origin - 06.12.2023, last edit - 18.01.2024
    	WB.addLog("Info.test, Info.root=" + Info.root, "", "Info");
	}
}
