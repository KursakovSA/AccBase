public class Info extends ModelDto {
	// origin - 06.12.2023, last edit - 09.10.2024
	private static String argNumeric;
	private static String argCodeIIN;
	public static int argLenghtIIN;

	static {
		try {
			Info.argNumeric = "Numeric";
			Info.argCodeIIN = "Info.Code.IIN";
			// Info.argLenghtIIN = ModelDto.getLenghtField(Info.argNumeric,
			// Info.argCodeIIN);
			Info.argLenghtIIN = Conv.getInt(MoreVal.getByKey(WB.abcLast.basic, Info.argNumeric, Info.argCodeIIN));
		} catch (Exception ex) {
			WB.addLog("Info.static ctor Info, ex=" + ex.getMessage(), WB.strEmpty, "Info");
		} finally {
			Etc.doNothing();
		}
	}

//	public String getId(String moreId) throws Exception {
//		// origin - 17.08.2024, last edit - 20.08.2024
//		String res = WB.strEmpty;
//		try {
////			IdGen idGen = new IdGen(moreId);
////			res = idGen.getNew();
//			res = ModelDto.getId();
//		} catch (Exception ex) {
//			WB.addLog("Info.getId, ex=" + ex.getMessage(), WB.strEmpty, "Info");
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("Info.getId, res=" + res, WB.strEmpty, "Info");
//		return res;
//	}

	public Info(String Id, String Code, String Description) throws Exception {
		// origin - 06.12.2023, last edit - 11.08.2024
		super(Id, Code, Description);
		this.table = this.getClass().getName();
	}

	public Info() throws Exception {
		// origin - 06.12.2023, last edit - 11.08.2024
		super();
		this.table = this.getClass().getName();
	}

//	public String toString() {
//		// origin - 27.09.2024, last edit - 28.09.2024
//		String res = WB.strEmpty;
//		try {
//			res = this.code + WB.strSpace + this.description;
//		} catch (Exception ex) {
//			// WB.addLog("Info.toString, ex=" + ex.getMessage(), WB.strEmpty,
//			// "Info");
//		} finally {
//			Etc.doNothing();
//		}
//		return res;
//	}

	public static void test() throws Exception {
		// origin - 06.12.2023, last edit - 16.09.2024
		try {

//			// ctor Info(Id, Code, Description)
//			Info ctorInfo = new Info("Info", "Info", "InfoData");
//			WB.addLog2("Info.test, ctor(Id, Code, Description)=" + ctorInfo, WB.strEmpty, "Info");

		} catch (Exception ex) {
			WB.addLog("Info.test, ex=" + ex.getMessage(), WB.strEmpty, "Info");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Info.test end ", WB.strEmpty, "Info");
	}
}
