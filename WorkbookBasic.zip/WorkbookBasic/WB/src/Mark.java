import java.util.Arrays;
import java.util.TreeSet;

public class Mark extends Model {
	// origin - 06.12.2023, last edit - 06.12.2023
	public static Mark root;
	public static TreeSet<String> allowShift;
	public Mark parent;
    
    static {
		root = new Mark("Mark","Mark","MarkData");
		allowShift = new TreeSet<String>(Arrays.asList("Arc", "CD", "DD", "DelD"));
	}
    
    public Mark(String Id, String Code, String Description) {
		// origin - 06.12.2023, last edit - 06.12.2023
		this.id = Id;
		this.code = Code;
		this.description = Description;
	}
    
    public Mark() {
		// origin - 06.12.2023, last edit - 06.12.2023
	}
    
    public static void test() {
		// origin - 28.10.2023, last edit - 05.12.2023
    	Logger.add("Mark.test, Mark.root=" + Mark.root, "", "Mark");
	}
}
