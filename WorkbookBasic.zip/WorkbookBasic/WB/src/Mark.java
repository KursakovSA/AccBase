import java.util.LinkedHashMap;

public class Mark {
	// origin - 06.12.2023, last edit - 01.05.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, date1, date2, code, description, more;
	// special fields
	private static LinkedHashMap<String, String> shift = new LinkedHashMap<String, String>();
	public static String DD, CD;

	static {
		try {
			Mark.DD = "Mark.DD";
			Mark.CD = "Mark.CD";
			Mark.shift.put("Mark.ArcD", "Mark.DD");
			Mark.shift.put("Mark.DD", "Mark.CD");
			Mark.shift.put("Mark.CD", "Mark.DelD");
			Mark.shift.put("Mark.CD", "Mark.ArcD");
		} catch (Exception ex) {
			WB.addLog("Mark.static ctor, ex=" + ex.getMessage(), "", "Mark");
		}
	}

	public void isExist() throws Exception {
		// origin - 02.10.2024, last edit - 01.05.2025
		try {
			for (var currDto : WB.abcLast.mark) {
				if (Etc.strEquals(currDto.id, this.id)) {
					this.date1 = DefVal.setCustom(this.date1, currDto.date1);
					this.date2 = DefVal.setCustom(this.date2, currDto.date2);
					this.code = DefVal.setCustom(this.code, currDto.code);
					this.parent = DefVal.setCustom(this.parent, currDto.parent);
					this.description = DefVal.setCustom(this.description, currDto.description);
					this.more = DefVal.setCustom(this.more, currDto.more);

					this.isExist = true;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Mark.isExist, ex=" + ex.getMessage(), "", "Mark");
		}
	}

	public Mark(String Id) throws Exception {
		// origin - 06.12.2023, last edit - 01.05.2025
		this.clear();
		this.src = Id;
		if (Id.isEmpty() == false) {
			this.id = this.code = Id;
		}
		this.date1 = DateTool.getNow().toString();
		this.isExist();
	}

	public Mark() throws Exception {
		// origin - 06.12.2023, last edit - 11.08.2024
		this.clear();
	}

	public void clear() throws Exception {
		// origin - 01.05.2025, last edit - 01.05.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = this.getClass().getName();
			this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.more = "";
		} catch (Exception ex) {
			WB.addLog("Mark.clear, ex=" + ex.getMessage(), "", "Mark");
		}
	}

	public String toString() {
		// origin - 11.12.2024, last edit - 20.03.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 01.05.2025
		try {

//			// ctor (String Id)
//			for (var tmp : new String[] {"", "Mark.CD", "Mark.tralala", "Mark.MD"}) {
//				WB.addLog2("Mark.test.ctor(String)=" + new Mark(tmp.id), "", "Mark");
//			}

		} catch (Exception ex) {
			WB.addLog("Mark.test, ex=" + ex.getMessage(), "", "Mark");
		}
	}
}