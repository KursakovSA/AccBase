import java.util.LinkedHashMap;

@SuppressWarnings("unused")
public class Mark extends ModelDto {
	// origin - 06.12.2023, last edit - 04.10.2024
	private static LinkedHashMap<String, String> shift = new LinkedHashMap<String, String>();

	static {
		try {
			Mark.shift.put("Mark.ArcD", "Mark.DD");
			Mark.shift.put("Mark.DD", "Mark.CD");
			Mark.shift.put("Mark.CD", "Mark.DelD");
			Mark.shift.put("Mark.CD", "Mark.ArcD");
		} catch (Exception ex) {
			WB.addLog("Mark.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Mark");
		} finally {
			Etc.doNothing();
		}
	}

	private static boolean shiftValid(String fromMark, String toMark) throws Exception {
		// origin - 02.10.2024, last edit - 02.10.2024
		boolean res = false;
		try {
			for (var currShift : Mark.shift.entrySet()) {
				if (Etc.strEquals(currShift.getKey(), fromMark)) {
					if (Etc.strEquals(currShift.getValue(), toMark)) {
						res = true;
						break;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Mark.shiftValid, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Mark");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Mark.shiftValid, res=" + res + ", this=" + this, WB.strEmpty,
		// "Mark");
		return res;
	}

	private boolean isExist() throws Exception {
		// origin - 02.10.2024, last edit - 02.10.2024
		boolean res = false;
		try {
			var tableDto = DAL.getByTemplate(WB.lastConnWork, Qry.getMoreFilter(this.table), this.table);
			for (var currDto : tableDto) {
				if (Etc.strEquals(currDto.id, this.id)) {
					if (Etc.strEquals(currDto.code, this.code)) {
						if (Etc.strEquals(currDto.description, this.description)) {
							res = true;
							break;
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Mark.isExist, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Mark");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Mark.isExist, res=" + res + ", this=" + this, WB.strEmpty,
		// "Mark");
		return res;
	}

	public Mark(String Id, String Code, String Description) throws Exception {
		// origin - 06.12.2023, last edit - 11.08.2024
		super(Id, Code, Description);
		this.table = this.getClass().getName();
	}

	public Mark() throws Exception {
		// origin - 06.12.2023, last edit - 11.08.2024
		super();
		this.table = this.getClass().getName();
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 04.10.2024
		try {

//			// shiftValid
//			WB.addLog2("Mark.test.shiftValid, res=" + Mark.shiftValid("Mark.DD", "Mark.CD")
//					+ ", markFrom=Mark.DD, markTo=Mark.CD", WB.strEmpty, "Mark");
//			WB.addLog2("Mark.test.shiftValid, res=" + Mark.shiftValid("Mark.DD", "Mark.tralala")
//					+ ", markFrom=Mark.DD, markTo=Mark.tralala", WB.strEmpty, "Mark");
//			WB.addLog2("Mark.test.shiftValid, res=" + Mark.shiftValid("Mark.DelD", "Mark.MD")
//					+ ", markFrom=Mark.DelD, markTo=Mark.MD", WB.strEmpty, "Mark");

//			// isValid, isExist
//			Mark mark1 = new Mark("Mark.CD", "Mark.CD", "CurrentData");
//			WB.addLog2(
//					"Mark.test.ctor, mark1=" + mark1 + ", isExist=" + mark1.isExist() + ", isValid=" + mark1.isValid(),
//					WB.strEmpty, "Mark");
//			Mark mark2 = new Mark("Mark", "Mark.tralala", "Mark.tralala");
//			WB.addLog2(
//					"Mark.test.ctor, mark2=" + mark2 + ", isExist=" + mark2.isExist() + ", isValid=" + mark2.isValid(),
//					WB.strEmpty, "Mark");

		} catch (Exception ex) {
			WB.addLog("Mark.test, ex=" + ex.getMessage(), WB.strEmpty, "Mark");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Mark.test end ", WB.strEmpty, "Mark");
	}
}
