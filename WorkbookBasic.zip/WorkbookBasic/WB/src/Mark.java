import java.util.LinkedHashMap;

public class Mark extends ModelDto {
	// origin - 06.12.2023, last edit - 12.09.2024
	public static LinkedHashMap<String, String> shift = new LinkedHashMap<String, String>();

	static {
		try {
			Mark.shift.put("ArcD", "DD");
			Mark.shift.put("DD", "CD");
			Mark.shift.put("CD", "DelD");
			Mark.shift.put("CD", "ArcD");
		} catch (Exception ex) {
			WB.addLog("Mark.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Mark");
		} finally {
			Etc.doNothing();
		}
	}

	public Mark(String Id, String Code, String Description) throws Exception {
		// origin - 06.12.2023, last edit - 11.08.2024
		super(Id, Code, Description);
		this.table = this.getClass().getName();
	}

	public Mark() throws Exception {
		// origin - 06.12.2023, last edit - 11.08.2024
		super();
		this.table = this.getClass().getName();
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 16.09.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Mark.test, ex=" + ex.getMessage(), WB.strEmpty, "Mark");
		} finally {
			Etc.doNothing();
		}
		//WB.addLog2("Mark.test end ", WB.strEmpty, "Mark");
	}
}
