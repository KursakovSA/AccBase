import java.util.Arrays;
import java.util.TreeSet;

public class Mark extends Model {
	// origin - 06.12.2023, last edit - 06.07.2024
	public static TreeSet<String> allowShift;
	public Mark parent;

	static {
		try {
			allowShift = new TreeSet<String>(Arrays.asList("Arc", "CD", "DD", "DelD"));
		} catch (Exception ex) {
			WB.addLog("Mark.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Mark");
		} finally {
			Etc.doNothing();
		}
	}

	public Mark(String Id, String Code, String Description) throws Exception {
		// origin - 06.12.2023, last edit - 07.07.2024
		try {
			this.id = Id;
			this.code = Code;
			this.description = Description;
		} catch (Exception ex) {
			WB.addLog("Mark.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Mark");
		} finally {
			Etc.doNothing();
		}
	}

	public Mark() throws Exception {
		// origin - 06.12.2023, last edit - 07.07.2024
		try {
		} catch (Exception ex) {
			WB.addLog("Mark.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Mark");
		} finally {
			Etc.doNothing();
		}
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 06.07.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Mark.test, ex=" + ex.getMessage(), WB.strEmpty, "Mark");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Mark.test end ", WB.strEmpty, "Mark");
	}
}
