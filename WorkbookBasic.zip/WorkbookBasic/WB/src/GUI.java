import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.util.TreeSet;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.SwingConstants;

public class GUI {
	// origin - 03.12.2023, last edit - 23.05.2024
	private static JMenuBar basicMenuBar;
	private static JToolBar basicToolBar;

	static {
		try {
			basicMenuBar = getBasicMenuBar();
			basicToolBar = getBasicToolBar();
		} catch (Exception ex) {
			WB.addLog("GUI.static ctor, ex=" + ex.getMessage(), "", "GUI");
		} finally {
		}
	}

	public static JFrame getFrameBasic() throws Exception {
		// origin - 03.12.2023, last edit - 23.05.2024
		JFrame frame = new JFrame();
		EventQueue.invokeLater(() -> {
			try {
				frame.setTitle(WB.frameBasicTitle);
				JPanel panelBasic = new JPanel();
				panelBasic.setBackground(Color.lightGray);

				BorderLayout layout = new BorderLayout();
				panelBasic.setLayout(layout);
				frame.add(panelBasic);

				frame.setJMenuBar(basicMenuBar);
				panelBasic.add(basicToolBar, BorderLayout.NORTH);

				// JSlider slider1 = new JSlider();
				// slider1.setOrientation(SwingConstants.BOTTOM);
				// slider1.setLocation(SwingConstants.BOTTOM);
				// slider1.setMajorTickSpacing(10);

//		        slider1.addChangeListener(new ChangeListener() {
//		            public void stateChanged(ChangeEvent e) {
//		                int value = ((JSlider)e.getSource()).getValue();
//		                label.setText(value);
//		            }
//		        });

				// slider1.setPaintLabels(true);
				// panelBasic.add(label, BorderLayout.SOUTH);
				// panelBasic.add(slider1);

				JTextField dbConnList = new JTextField(100);
				dbConnList.setFont(new Font("Arial", Font.BOLD, 20));
				dbConnList.setText("Input dbConn");
				frame.add(dbConnList, BorderLayout.NORTH);

				Object[][] array = new String[][] { { "Кольцо с кам.", "гр", "1.5" }, { "Блезик", "гр", "4.0" },
						{ "Лом", "гр", "3.0" }, { "Браслет", "гр", "2.2" } };
				Object[] columnsHeader = new String[] { "Наименование", "Ед.измерения", "Количество" };
				JTable table1 = new JTable(array, columnsHeader);
				table1.setRowHeight(30);
				// table1.setAutoResizeMode(0);
				table1.setFont(new Font("Arial", Font.PLAIN, 20));
				panelBasic.add(table1);

				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				// frame.setPreferredSize(new Dimension(640, 480));
				frame.setExtendedState(java.awt.Frame.MAXIMIZED_BOTH);
				frame.setFont(new Font("Verdana", Font.BOLD, 15));
				frame.setVisible(true);
			} catch (Exception ex) {
				WB.addLog("GUI.getFrameBasic, ex=" + ex.getMessage(), "", "GUI");
			} finally {
				Etc.doNothing();
			}
		});
		WB.addLog("GUI.getFrameBasic, frame.getName=" + frame.getName(), "", "GUI");
		return frame;
	}

	private static JMenuBar getBasicMenuBar() throws Exception {
		// origin - 03.12.2023, last edit - 23.05.2024
		JMenuBar menuBar = new JMenuBar();
		EventQueue.invokeLater(() -> {
			try {
				JMenu menuFile = new JMenu("(File)");
				getFileMenu(menuBar, menuFile);

				JMenu menuFace = new JMenu("(Face)");
				getFaceMenu(menuBar, menuFace);

				JMenu menuAsset = new JMenu("(Asset)");
				getAssetMenu(menuBar, menuAsset);

				JMenu menuDeal = new JMenu("(Deal)");
				getDealMenu(menuBar, menuDeal);

				JMenu menuProcess = new JMenu("(Process)");
				getProcessMenu(menuBar, menuProcess);

				JMenu menuWorkbook = new JMenu("(Workbook)");
				getWorkbookMenu(menuBar, menuWorkbook);

				JMenu menuInput = new JMenu("(Input)");
				getInputMenu(menuBar, menuInput);

				JMenu menuOutput = new JMenu("(Output)");
				getOutputMenu(menuBar, menuOutput);

				JMenu menuReport = new JMenu("(Report)");
				getReportMenu(menuBar, menuReport);

				JMenu menuOther = new JMenu("(Other)");
				getOtherMenu(menuBar, menuOther);

				JMenu menuDb = new JMenu("(Database)");
				getDatabaseMenu(menuBar, menuDb);

				JMenu menuSupport = new JMenu("(Support)");
				getSupportMenu(menuBar, menuSupport);
				
				JMenu menuTest = new JMenu("(Test)");
				getTestMenu(menuBar, menuTest);

			} catch (Exception ex) {
				WB.addLog("GUI.getBasicMenuBar, ex=" + ex.getMessage(), "", "GUI");
			} finally {
				Etc.doNothing();
			}
		});

		return menuBar;
	}

	private static void getFileMenu(JMenuBar menuBar, JMenu menuFile) throws Exception {
		// origin - 19.12.2023, last edit - 31.12.2023
		setFont(menuFile);
		menuFile.add(getMenuItem("File - open (not ready)"));
		menuFile.add(getMenuItem("File - save (not ready)"));
		menuFile.addSeparator();
		addMenuItemCustom(menuFile);
		menuFile.add(getMenuItem("File - exit"));
		menuFile.addSeparator();
		menuBar.add(menuFile);
	}

	private static void getFaceMenu(JMenuBar menuBar, JMenu menuFace) throws Exception {
		// origin - 19.12.2023, last edit - 31.12.2023
		setFont(menuFace);
		menuFace.add(getMenuItem("(Face.10) Standard - new face (not ready)"));
		menuFace.add(getMenuItem("(Face.20) Standard - edit face (not ready)"));
		menuFace.addSeparator();
		menuFace.add(getMenuItem("(Face.PS.10) Sectoral pawn shop - new pledgor (not ready)"));
		menuFace.add(getMenuItem("(Face.PS.20) Sectoral pawn shop - edit pledgor (not ready)"));
		menuFace.addSeparator();
		addMenuItemCustom(menuFace);
		menuBar.add(menuFace);
	}

	private static void getAssetMenu(JMenuBar menuBar, JMenu menuAsset) throws Exception {
		// origin - 19.12.2023, last edit - 31.12.2023
		setFont(menuAsset);
		menuAsset.add(getMenuItem("(Asset.10) Standard - new asset (not ready)"));
		menuAsset.add(getMenuItem("(Asset.20) Standard - edit asset (not ready)"));
		menuAsset.addSeparator();
		menuAsset.add(getMenuItem("(Asset.PS.10) Sectoral pawn shop - new pawn (not ready)"));
		menuAsset.add(getMenuItem("(Asset.PS.20) Sectoral pawn shop - edit pawn (not ready)"));
		menuAsset.addSeparator();
		addMenuItemCustom(menuAsset);
		menuBar.add(menuAsset);
	}

	private static void getDealMenu(JMenuBar menuBar, JMenu menuDeal) throws Exception {
		// origin - 19.12.2023, last edit - 31.12.2023
		setFont(menuDeal);
		menuDeal.add(getMenuItem("(Deal.10) Standard - new deal (not ready)"));
		menuDeal.add(getMenuItem("(Deal.20) Standard - edit deal (not ready)"));
		menuDeal.addSeparator();
		menuDeal.add(getMenuItem("(Deal.PS.10) Sectoral pawn shop - new deposit (not ready)"));
		menuDeal.add(getMenuItem("(Deal.PS.20) Sectoral pawn shop - edit deposit (not ready)"));
		menuDeal.addSeparator();
		addMenuItemCustom(menuDeal);
		menuBar.add(menuDeal);
	}

	private static void getProcessMenu(JMenuBar menuBar, JMenu menuProcess) throws Exception {
		// origin - 19.12.2023, last edit - 31.12.2023
		setFont(menuProcess);
		menuProcess.add(getMenuItem("Standard - "));
		menuProcess.addSeparator();
		menuProcess.add(getMenuItem("(Process.PS.10) Sectoral - Accrual interest 1 (not ready)"));
		menuProcess.add(getMenuItem("(Process.PS.20) Sectoral pawn shop - Write off 1 (not ready)"));
		menuProcess.add(getMenuItem("(Process.PS.30) Sectoral pawn shop - Write off 2 (not ready)"));
		menuProcess.add(getMenuItem("(Process.PS.40) Sectoral pawn shop - Write off 3 (not ready)"));
		menuProcess.add(getMenuItem("(Process.PS.50) Sectoral pawn shop - Write off 4 (not ready)"));
		menuProcess.add(getMenuItem("(Process.PS.60) Sectoral pawn shop - Write off 5 (not ready)"));
		menuProcess.add(getMenuItem("(Process.PS.70) Sectoral pawn shop - Write off 6 (not ready)"));
		menuProcess.add(getMenuItem("(Process.PS.80) Sectoral pawn shop - Write off 7 (not ready)"));
		menuProcess.addSeparator();
		addMenuItemCustom(menuProcess);
		menuBar.add(menuProcess);
	}

	private static void getWorkbookMenu(JMenuBar menuBar, JMenu menuWorkbook) throws Exception {
		// origin - 19.12.2023, last edit - 31.12.2023
		setFont(menuWorkbook);
		menuWorkbook.add(getMenuItem("Standard - "));
		menuWorkbook.addSeparator();
		menuWorkbook.add(getMenuItem("Sectoral pawn shop - "));
		menuWorkbook.addSeparator();
		addMenuItemCustom(menuWorkbook);
		menuBar.add(menuWorkbook);
	}

	private static void getInputMenu(JMenuBar menuBar, JMenu menuInput) throws Exception {
		// origin - 19.12.2023, last edit - 31.12.2023
		setFont(menuInput);
		menuInput.add(getMenuItem("(Input.10) Standard - EsfXML (not ready)"));
		menuInput.addSeparator();
		menuInput.add(getMenuItem("(Input.PS.10) Sectoral pawn shop - PkbXLSX (not ready)"));
		menuInput.addSeparator();
		addMenuItemCustom(menuInput);
		menuBar.add(menuInput);
	}

	private static void getOutputMenu(JMenuBar menuBar, JMenu menuOutput) throws Exception {
		// origin - 19.12.2023, last edit - 20.05.2024
		setFont(menuOutput);
		menuOutput.add(getMenuItem("(Output.10) Standard - EsfXML  (not ready)"));
		menuOutput.add(getMenuItem("(Output.20) Standard - MT100  (not ready)"));
		menuOutput.add(getMenuItem("(Output.30) Standard - MT102 (not ready)"));
		menuOutput.add(getMenuItem("(Output.40) Standard - SwiftOPV (not ready)"));
		menuOutput.add(getMenuItem("(Output.50) Standard - SwiftGFSS (not ready)"));
		menuOutput.add(getMenuItem("(Output.60) Standard - SwiftOSMS (not ready)"));
		menuOutput.add(getMenuItem("(Output.70) Standard - SwiftOPVR (not ready)"));
		menuOutput.addSeparator();
		menuOutput.add(getMenuItem("(Output.PS.10) Sectoral pawn shop - National bank RQ (not ready)"));
		menuOutput.add(getMenuItem("(Output.PS.20) Sectoral pawn shop - First credit bureau (not ready)"));
		menuOutput.addSeparator();
		addMenuItemCustom(menuOutput);
		menuBar.add(menuOutput);
	}

	private static void getReportMenu(JMenuBar menuBar, JMenu menuReport) throws Exception {
		// origin - 19.12.2023, last edit - 31.12.2023
		setFont(menuReport);
		menuReport.add(getMenuItem("(Report.10) Standard - cash book (not ready)"));
		menuReport.addSeparator();
		menuReport.add(getMenuItem("Sectoral pawn shop - "));
		menuReport.addSeparator();
		addMenuItemCustom(menuReport);
		menuBar.add(menuReport);
	}

	private static void getOtherMenu(JMenuBar menuBar, JMenu menuOther) throws Exception {
		// origin - 19.12.2023, last edit - 31.12.2023
		setFont(menuOther);
		menuOther.add(getMenuItem("(Other.10) Standard - new debt (not ready)"));
		menuOther.add(getMenuItem("(Other.20) Standard - edit debt (not ready)"));
		menuOther.addSeparator();
		menuOther.add(getMenuItem("(Other.30) Standard - new geo (not ready)"));
		menuOther.add(getMenuItem("(Other.40) Standard - edit geo (not ready)"));
		menuOther.addSeparator();
		menuOther.add(getMenuItem("(Other.50) Standard - new item (not ready)"));
		menuOther.add(getMenuItem("(Other.60) Standard - edit item (not ready)"));
		menuOther.addSeparator();
		menuOther.add(getMenuItem("(Other.70) Standard - new unit (not ready)"));
		menuOther.add(getMenuItem("(Other.80) Standard - edit unit (not ready)"));
		menuOther.addSeparator();
		menuOther.add(getMenuItem("Sectoral pawn shop -"));
		menuOther.addSeparator();
		addMenuItemCustom(menuOther);
		menuBar.add(menuOther);
	}

	private static void getDatabaseMenu(JMenuBar menuBar, JMenu menuDb) throws Exception {
		// origin - 19.12.2023, last edit - 20.05.2024
		setFont(menuDb);
		menuDb.add(getMenuItem("(Database.10) Standard - backup"));
		menuDb.add(getMenuItem("(Database.20) Standard - integrity check"));
		menuDb.add(getMenuItem("(Database.30) Standard - reindex"));
		menuDb.add(getMenuItem("(Database.40) Standard - vacuum"));
		menuDb.addSeparator();
		menuDb.add(getMenuItem("(Database.50=10+20+30+40) Standard - backup, integrity check, reindex, vacuum"));
		menuDb.addSeparator();
		addMenuItemCustom(menuDb);
		menuDb.add(getMenuItem("Database - exit"));
		menuDb.addSeparator();
		menuBar.add(menuDb);
	}

	private static void getSupportMenu(JMenuBar menuBar, JMenu menuSupport) throws Exception {
		// origin - 19.12.2023, last edit - 23.05.2024
		setFont(menuSupport);
		menuSupport.add(getMenuItem("Support.10 - update bases"));
		menuSupport.add(getMenuItem("Support.20 - update ext files"));
		menuSupport.addSeparator();
		menuSupport.add(getMenuItem("Support.30=10+20 - update bases, update ext files"));
		menuSupport.addSeparator();
		menuSupport.add(getMenuItem("Support.40 - open github.com/KursakovSA/AccBase (not ready)"));
		menuSupport.add(getMenuItem("Support.50 - mail to kursakov.s@gmail.com (not ready)"));
		menuSupport.add(getMenuItem("Support.60 - open user manual local"));
		menuSupport.addSeparator();
		addMenuItemCustom(menuSupport);
		menuBar.add(menuSupport);
	}
	
	private static void getTestMenu(JMenuBar menuBar, JMenu menuTest) throws Exception {
		// origin - 20.05.2024, last edit - 24.05.2024
		setFont(menuTest);
		menuTest.add(getMenuItem("(Test.10) Standard - create bulk Db in 10 year (not ready)"));
		menuTest.add(getMenuItem("(Test.20) Standard - select Asset Store rest in 10 year (not ready)"));
		menuTest.add(getMenuItem("(Test.30) Standard - select last 1000 records in 10 year (not ready)"));
		menuTest.add(getMenuItem("(Test.40) Standard - large integrity check, reindex, vacuum (not ready)"));
		menuTest.add(getMenuItem("(Test.50) Standard - large last record"));
		menuTest.add(getMenuItem("(Test.60) Standard - replace into"));
		menuTest.addSeparator();
		menuTest.add(getMenuItem("(Test.PS.10) Sectoral pawn shop - create bulk Db in 10 year (not ready)"));
		menuTest.add(getMenuItem("(Test.PS.20) Sectoral pawn shop - select Face Deal rest in 10 year (not ready)"));
		menuTest.add(getMenuItem("(Test.PS.30) Sectoral pawn shop - select last 1000 records in 10 year (not ready)"));
		menuTest.addSeparator();
		addMenuItemCustom(menuTest);
		menuBar.add(menuTest);
	}

	private static void addMenuItemCustom(JMenu menu) throws Exception {
		// origin - 19.12.2023, last edit - 19.12.2023
		menu.add(getMenuItem("Custom standard - "));
		menu.add(getMenuItem("Custom pawn shop - "));
		menu.addSeparator();
	}

	private static void getActionListener(String menuItemTitle, JMenuItem menuItem) throws Exception {
		// origin - 10.12.2023, last edit - 24.05.2024
		
		// menuItem contain " - replace into"
		if (Etc.strContains(menuItemTitle, "- replace into")) {
			menuItem.addActionListener(event -> {
				TreeSet<String> setConn = Conn.work;
				try {
					Command.replaceInto(setConn);
				} catch (Exception ex) {
					WB.addLog("GUI.getActionListener, ex=" + ex.getMessage() + ", menuItemTitle=" + menuItemTitle, "",
							"GUI");
				} finally {
					Etc.doNothing();
				}
			});
		}
		
		// menuItem contain " - open user manual local"
		if (Etc.strContains(menuItemTitle, "- open user manual local")) {
			menuItem.addActionListener(event -> {
				try {
					Command.openUserManualLocal();
				} catch (Exception ex) {
					WB.addLog("GUI.getActionListener, ex=" + ex.getMessage() + ", menuItemTitle=" + menuItemTitle, "", "GUI");
				} finally {
					Etc.doNothing();
				}
			});
		}

		// menuItem contain " - update bases, update ext files"
		if (Etc.strContains(menuItemTitle, "- update bases, update ext files")) {
			menuItem.addActionListener(event -> {
				TreeSet<String> setConn = Conn.work;
				try {
					Command.updateBases(setConn);
					Command.updateExtFiles();
				} catch (Exception ex) {
					WB.addLog("GUI.getActionListener, ex=" + ex.getMessage() + ", menuItemTitle=" + menuItemTitle, "", "GUI");
				} finally {
					Etc.doNothing();
				}
			});
		}

		// menuItem contain " - backup, integrity check, reindex, vacuum"
		if (Etc.strContains(menuItemTitle, " - backup, integrity check, reindex, vacuum")) {
			menuItem.addActionListener(event -> {
				TreeSet<String> setConn = Conn.work;
				try {
					Command.backup(setConn);
					Command.integrityCheck(setConn);
					Command.reindex(setConn);
					Command.vacuum(setConn);
				} catch (Exception ex) {
					WB.addLog("GUI.getActionListener, ex=" + ex.getMessage() + ", menuItemTitle=" + menuItemTitle, "", "GUI");
				} finally {
					Etc.doNothing();
				}
			});
		}

		// menuItem contain " - update bases"
		if (Etc.strContains(menuItemTitle, "- update bases")) {
			menuItem.addActionListener(event -> {
				TreeSet<String> setConn = Conn.work;
				try {
					Command.updateBases(setConn);
				} catch (Exception ex) {
					WB.addLog("GUI.getActionListener, ex=" + ex.getMessage() + ", menuItemTitle=" + menuItemTitle, "", "GUI");
				} finally {
					Etc.doNothing();
				}
			});
		}

		// menuItem contain " - update ext files"
		if (Etc.strContains(menuItemTitle, "- update ext files")) {
			menuItem.addActionListener(event -> {
				try {
					Command.updateExtFiles();
				} catch (Exception ex) {
					WB.addLog("GUI.getActionListener, ex=" + ex.getMessage() + ", menuItemTitle=" + menuItemTitle, "", "GUI");
				} finally {
					Etc.doNothing();
				}
			});
		}

		// menuItem contain " - large last record"
		if (Etc.strContains(menuItemTitle, "- large last record")) {
			menuItem.addActionListener(event -> {
				TreeSet<String> setConn = Conn.largeDb;
				try {
					Command.getLastRecord(setConn);
				} catch (Exception ex) {
					WB.addLog("GUI.getActionListener, ex=" + ex.getMessage() + ", menuItemTitle=" + menuItemTitle, "", "GUI");
				} finally {
					Etc.doNothing();
				}
			});
		}

		// menuItem contain " - large integrity check, reindex, vacuum"
		if (Etc.strContains(menuItemTitle, "- large integrity check, reindex, vacuum")) {
			menuItem.addActionListener(event -> {
				TreeSet<String> setConn = Conn.largeDb;
				try {
					Command.integrityCheck(setConn);
					Command.reindex(setConn);
					Command.vacuum(setConn);
				} catch (Exception ex) {
					WB.addLog("GUI.getActionListener, ex=" + ex.getMessage() + ", menuItemTitle=" + menuItemTitle, "", "GUI");
				} finally {
					Etc.doNothing();
				}
			});
		}

		// menuItem contain " - vacuum"
		if (Etc.strContains(menuItemTitle, "- vacuum")) {
			menuItem.addActionListener(event -> {
				TreeSet<String> setConn = Conn.work;
				try {
					Command.vacuum(setConn);
				} catch (Exception ex) {
					WB.addLog("GUI.getActionListener, ex=" + ex.getMessage() + ", menuItemTitle=" + menuItemTitle, "", "GUI");
				} finally {
					Etc.doNothing();
				}
			});
		}

		// menuItem contain " - reindex"
		if (Etc.strContains(menuItemTitle, "- reindex")) {
			menuItem.addActionListener(event -> {
				TreeSet<String> setConn = Conn.work;
				try {
					Command.reindex(setConn);
				} catch (Exception ex) {
					WB.addLog("GUI.getActionListener, ex=" + ex.getMessage() + ", menuItemTitle=" + menuItemTitle, "", "GUI");
				} finally {
					Etc.doNothing();
				}
			});
		}

		// menuItem contain " - integrity check"
		if (Etc.strContains(menuItemTitle, "- integrity check")) {
			menuItem.addActionListener(event -> {
				TreeSet<String> setConn = Conn.work;
				try {
					Command.integrityCheck(setConn);
				} catch (Exception ex) {
					WB.addLog("GUI.getActionListener, ex=" + ex.getMessage() + ", menuItemTitle=" + menuItemTitle, "", "GUI");
				} finally {
					Etc.doNothing();
				}
			});
		}

		// menuItem contain "Standard - backup"
		if (Etc.strContains(menuItemTitle, "Standard - backup")) {
			menuItem.addActionListener(event -> {
				TreeSet<String> setConn = Conn.work;
				try {
					Command.backup(setConn);
				} catch (Exception ex) {
					WB.addLog("GUI.getActionListener, ex=" + ex.getMessage() + ", menuItemTitle=" + menuItemTitle, "", "GUI");
				} finally {
					Etc.doNothing();
				}
			});
		}

		// menuItem " - exit"
		if (Etc.strContains(menuItemTitle, " - exit")) {
			menuItem.addActionListener(event -> {
				try {
					Command.exit();
				} catch (Exception ex) {
					WB.addLog("GUI.getActionListener, ex=" + ex.getMessage() + ", menuItemTitle=" + menuItemTitle, "", "GUI");
				} finally {
					Etc.doNothing();
				}
			});
		}
	}

	private static void getActionListener(String buttonTitle, JButton button) throws Exception {
		// origin - 15.12.2023, last edit - 23.05.2024

		// toolBar button "Exit"
		if (Etc.strContains(buttonTitle, "Exit")) {
			button.addActionListener(event -> {
				try {
					Command.exit();
				} catch (Exception ex) {
					WB.addLog("GUI.getActionListener, ex=" + ex.getMessage() + ", buttonTitle=" + buttonTitle, "", "GUI");
				} finally {
					Etc.doNothing();
				}
			});
		}

		// toolBar button "Print template doc"
		if (Etc.strContains(buttonTitle, "Print template doc")) {
			button.addActionListener(event -> {
				try {
					// System.out.println("Print template doc");
				} catch (Exception ex) {
					WB.addLog("GUI.getActionListener, ex=" + ex.getMessage() + ", buttonTitle=" + buttonTitle, "", "GUI");
				} finally {
					Etc.doNothing();
				}
			});
		}
	}

	private static JToolBar getBasicToolBar() throws Exception {
		// origin - 05.12.2023, last edit - 23.05.2024
		JToolBar toolBar = new JToolBar();
		EventQueue.invokeLater(() -> {
			try {
				toolBar.setFloatable(false);
				toolBar.setOrientation(SwingConstants.HORIZONTAL);
				toolBar.add(getButton("Print template doc (not ready)"));
				toolBar.add(getButton("Shift process (not ready)"));
				toolBar.add(getButton("Quick select (not ready)"));
				toolBar.add(getButton("Quick rest (not ready)"));
				toolBar.add(getButton("Exit"));

			} catch (Exception ex) {
				WB.addLog("GUI.getBasicToolBar, ex=" + ex.getMessage(), "","GUI");
			} finally {
				Etc.doNothing();
			}
		});

		return toolBar;
	}

	private static JButton getButton(String buttonTitle) throws Exception {
		// origin - 15.12.2023, last edit - 15.12.2023
		JButton button = new JButton(buttonTitle);
		setFont(button);
		getActionListener(buttonTitle, button);
		return button;
	}

	private static void setFont(JComponent jcomp) throws Exception {
		// origin - 15.12.2023, last edit - 23.05.2024
		try {
			((JComponent) jcomp).setFont(new Font("Arial", Font.BOLD, 15));
		} catch (Exception ex) {
			WB.addLog("GUI.setFont, ex=" + ex.getMessage(), "", "GUI");
		} finally {
		}
	}

	private static JMenuItem getMenuItem(String menuItemTitle) throws Exception {
		// origin - 09.12.2023, last edit - 18.12.2023
		JMenuItem menuItem = new JMenuItem(menuItemTitle);
		setFont(menuItem);
		getActionListener(menuItemTitle, menuItem);
		return menuItem;
	}

	public static void test() throws Exception {
		// origin - 03.12.2023, last edit - 03.12.2023
	}
}