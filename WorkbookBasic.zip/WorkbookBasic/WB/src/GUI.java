import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.SwingConstants;

public class GUI {
	// origin - 03.12.2023, last edit - 13.12.2023
	private static JMenuBar basicMenuBar;
	private static JToolBar basicToolBar;

	static {
		try {
			basicMenuBar = getBasicMenuBar();
			basicToolBar = getBasicToolBar();
		} catch (Exception ex) {
			Logger.add("GUI.static ctor, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "GUI");
		} finally {
		}
	}

	public static JFrame getFrameBasic() throws Exception {
		// origin - 03.12.2023, last edit - 13.12.2023
		JFrame frame = new JFrame();
		EventQueue.invokeLater(() -> {
			try {
				frame.setTitle(WB.frameBasicTitle);
				JPanel panelBasic = new JPanel();
				panelBasic.setBackground(Color.lightGray);

				BorderLayout layout = new BorderLayout();
				panelBasic.setLayout(layout);
				frame.add(panelBasic);

				frame.setJMenuBar(basicMenuBar);
				panelBasic.add(basicToolBar, BorderLayout.NORTH);

			    JSlider slider1 = new JSlider();
				//slider1.setOrientation(SwingConstants.BOTTOM);
				//slider1.setLocation(SwingConstants.BOTTOM);
				// slider1.setMajorTickSpacing(10);

//		        slider1.addChangeListener(new ChangeListener() {
//		            public void stateChanged(ChangeEvent e) {
//		                int value = ((JSlider)e.getSource()).getValue();
//		                label.setText(value);
//		            }
//		        });

				// slider1.setPaintLabels(true);
				// panelBasic.add(label, BorderLayout.SOUTH);
				panelBasic.add(slider1);
				
				JTextField dbConnList = new JTextField(100);
				dbConnList.setFont(new Font("Arial", Font.BOLD, 20));
				dbConnList.setText("Input dbConn");
				frame.add(dbConnList, BorderLayout.NORTH);

				//JTable table1 = new JTable(array, columnsHeader);
				Object[][] array = new String[][] {{ "Сахар" , "кг", "1.5" },
                    { "Мука"  , "кг", "4.0" },
                    { "Молоко", "л" , "2.2" }};
                    Object[] columnsHeader = new String[] {"Наименование", "Ед.измерения", 
                    "Количество"};
                JTable table1 = new JTable(array, columnsHeader);
                table1.setRowHeight(45);
                table1.setFont(new Font("Arial", Font.BOLD, 40));
				//panelBasic.add(table1);

				frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
				//frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
				frame.setPreferredSize(new Dimension(640, 480));
				frame.setExtendedState(java.awt.Frame.MAXIMIZED_BOTH);
				frame.setVisible(true);
			} catch (Exception ex) {
				Logger.add("GUI.getFrameBasic, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "",
						"GUI");
			} finally {
			}
		});
		Logger.add("GUI.getFrameBasic, frame.getName=" + frame.getName(), "", "GUI");
		return frame;
	}

	private static JMenuBar getBasicMenuBar() throws Exception {
		// origin - 03.12.2023, last edit - 13.12.2023
		JMenuBar menuBar = new JMenuBar();
		//menuBar.setFont(new Font("Arial", Font.BOLD, 20));
		EventQueue.invokeLater(() -> {
			try {
				JMenu menuFile = new JMenu("File");
				menuFile.add(getMenuItem("File - open (not ready)"));
				menuFile.add(getMenuItem("File - save (not ready)"));
				menuFile.add(getMenuItem("File - exit", Action.exit));
				menuFile.addSeparator();
				menuBar.add(menuFile);

				JMenu menuFace = new JMenu("[1] Face");
				menuFace.add(getMenuItem("[1.1] Standard - new face (not ready)"));
				menuFace.add(getMenuItem("[1.2] Standard - edit face (not ready)"));
				menuFace.addSeparator();
				menuFace.add(getMenuItem("[PS1.1] Sectoral pawn shop - new pledgor (not ready)"));
				menuFace.add(getMenuItem("[PS1.2] Sectoral pawn shop - edit pledgor (not ready)"));
				menuFace.addSeparator();
				menuFace.add(getMenuItem("Custom standard - "));
				menuFace.add(getMenuItem("Custom pawn shop - "));
				menuFace.addSeparator();
				menuBar.add(menuFace);

				JMenu menuAsset = new JMenu("[2] Asset");
				menuAsset.add(getMenuItem("[2.1] Standard - new asset (not ready)"));
				menuAsset.add(getMenuItem("[2.2] Standard - edit asset (not ready)"));
				menuAsset.addSeparator();
				menuAsset.add(getMenuItem("[PS_2.1] Sectoral pawn shop - new pawn (not ready)"));
				menuAsset.add(getMenuItem("[PS_2.2] Sectoral pawn shop - edit pawn (not ready)"));
				menuAsset.addSeparator();
				menuAsset.add(getMenuItem("Custom standard - "));
				menuAsset.add(getMenuItem("Custom pawn shop - "));
				menuAsset.addSeparator();
				menuBar.add(menuAsset);

				JMenu menuDeal = new JMenu("[3] Deal");
				menuDeal.add(getMenuItem("[3.1] Standard - new deal (not ready)"));
				menuDeal.add(getMenuItem("[3.2] Standard - edit deal (not ready)"));
				menuDeal.addSeparator();
				menuDeal.add(getMenuItem("[PS_3.1] Sectoral pawn shop - new deposit (not ready)"));
				menuDeal.add(getMenuItem("[PS_3.2] Sectoral pawn shop - edit deposit (not ready)"));
				menuDeal.addSeparator();
				menuDeal.add(getMenuItem("Custom standard - "));
				menuDeal.add(getMenuItem("Custom pawn shop - "));
				menuDeal.addSeparator();
				menuBar.add(menuDeal);

				JMenu menuProcess = new JMenu("Process");
				menuProcess.add(getMenuItem("Standard - "));
				menuProcess.addSeparator();
				menuProcess.add(getMenuItem("Sectoral - Accrual interest 1 (not ready)"));
				menuProcess.add(getMenuItem("Sectoral pawn shop - Write off 1 (not ready)"));
				menuProcess.add(getMenuItem("Sectoral pawn shop - Write off 2 (not ready)"));
				menuProcess.add(getMenuItem("Sectoral pawn shop - Write off 3 (not ready)"));
				menuProcess.add(getMenuItem("Sectoral pawn shop - Write off 4 (not ready)"));
				menuProcess.add(getMenuItem("Sectoral pawn shop - Write off 5 (not ready)"));
				menuProcess.add(getMenuItem("Sectoral pawn shop - Write off 6 (not ready)"));
				menuProcess.add(getMenuItem("Sectoral pawn shop - Write off 7 (not ready)"));
				menuProcess.addSeparator();
				menuProcess.add(getMenuItem("Custom standard - "));
				menuProcess.add(getMenuItem("Custom pawn shop - "));
				menuProcess.addSeparator();
				menuBar.add(menuProcess);

				JMenu menuWorkbook = new JMenu("Workbook");
				menuWorkbook.add(getMenuItem("Standard - "));
				menuWorkbook.addSeparator();
				menuWorkbook.add(getMenuItem("Sectoral pawn shop - "));
				menuWorkbook.addSeparator();
				menuWorkbook.add(getMenuItem("Custom standard - "));
				menuWorkbook.add(getMenuItem("Custom pawn shop - "));
				menuWorkbook.addSeparator();
				menuBar.add(menuWorkbook);

				JMenu menuInput = new JMenu("Input");
				menuInput.add(getMenuItem("Standard - EsfXML (not ready)"));
				menuInput.addSeparator();
				menuInput.add(getMenuItem("Sectoral pawn shop - PkbXLSX (not ready)"));
				menuInput.addSeparator();
				menuInput.add(getMenuItem("Custom standard - "));
				menuInput.add(getMenuItem("Custom pawn shop - "));
				menuInput.addSeparator();
				menuBar.add(menuInput);

				JMenu menuOutput = new JMenu("Output");
				menuOutput.add(getMenuItem("Standard - EsfXML  (not ready)"));
				menuOutput.add(getMenuItem("Standard - MT100  (not ready)"));
				menuOutput.add(getMenuItem("Standard - MT102 (not ready)"));
				menuOutput.add(getMenuItem("Standard - SwiftOPV (not ready)"));
				menuOutput.add(getMenuItem("Standard - SwiftGFSS (not ready)"));
				menuOutput.add(getMenuItem("Standard - SwiftOSMS (not ready)"));
				menuOutput.addSeparator();
				menuOutput.add(getMenuItem("Sectoral pawn shop - National bank RQ (not ready)"));
				menuOutput.add(getMenuItem("Sectoral pawn shop - First credit bureau (not ready)"));
				menuOutput.addSeparator();
				menuOutput.add(getMenuItem("Custom standard - "));
				menuOutput.add(getMenuItem("Custom pawn shop - "));
				menuOutput.addSeparator();
				menuBar.add(menuOutput);

				JMenu menuReport = new JMenu("Report");
				menuReport.add(getMenuItem("Standard - cash book (not ready)"));
				menuReport.addSeparator();
				menuReport.add(getMenuItem("Sectoral pawn shop - "));
				menuReport.addSeparator();
				menuReport.add(getMenuItem("Custom standard - "));
				menuReport.add(getMenuItem("Custom pawn shop - "));
				menuReport.addSeparator();
				menuBar.add(menuReport);
				
				JMenu menuOther = new JMenu("Other");
				menuOther.add(getMenuItem("Standard - new debt (not ready)"));
				menuOther.add(getMenuItem("Standard - edit debt (not ready)"));
				menuOther.addSeparator();
				menuOther.add(getMenuItem("Standard - new geo (not ready)"));
				menuOther.add(getMenuItem("Standard - edit geo (not ready)"));
				menuOther.addSeparator();
				menuOther.add(getMenuItem("Standard - new item (not ready)"));
				menuOther.add(getMenuItem("Standard - edit item (not ready)"));
				menuOther.addSeparator();
				menuOther.add(getMenuItem("Standard - new unit (not ready)"));
				menuOther.add(getMenuItem("Standard - edit unit (not ready)"));
				menuOther.addSeparator();
				menuOther.add(getMenuItem("Sectoral pawn shop -"));
				menuOther.addSeparator();
				menuOther.add(getMenuItem("Custom standard - "));
				menuOther.add(getMenuItem("Custom pawn shop - "));
				menuOther.addSeparator();
				menuBar.add(menuOther);

				JMenu menuDbs = new JMenu("Database");
				menuDbs.add(getMenuItem("Standard - backup curr conn (not ready)"));
				menuDbs.add(getMenuItem("Standard - short test : integrity check, reindex (not ready)"));
				menuDbs.add(getMenuItem("Standard - vacuum (not ready)"));
				menuDbs.addSeparator();
				menuDbs.add(getMenuItem("Standard - create Db trader in 10 year (not ready)"));
				menuDbs.add(getMenuItem("Standard - select Asset Store rest in Db trader in 10 year (not ready)"));
				menuDbs.add(getMenuItem("Standard - select last 1000 records in Db trader in 10 year (not ready)"));
				menuDbs.addSeparator();
				menuDbs.add(getMenuItem("Sectoral pawn shop - create Db pawnshop in 10 year (not ready)"));
				menuDbs.add(getMenuItem(
						"Sectoral pawn shop - select Face Deal rest in Db pawnshop in 10 year (not ready)"));
				menuDbs.add(getMenuItem(
						"Sectoral pawn shop - select last 1000 records in Db pawnshop in 10 year (not ready)"));
				menuDbs.addSeparator();
				menuDbs.add(getMenuItem("Custom standard - "));
				menuDbs.add(getMenuItem("Custom pawn shop - "));
				menuDbs.addSeparator();
				menuBar.add(menuDbs);

				JMenu menuSupport = new JMenu("Support");
				menuSupport.add(getMenuItem("Support - open github.com/KursakovSA/AccBase"));
				menuSupport.add(getMenuItem("Support - mail to kursakov.s@gmail.com"));
				menuSupport.addSeparator();
				menuBar.add(menuSupport);
				
			} catch (Exception ex) {
				Logger.add("GUI.getBasicMenuBar, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "",
						"GUI");
			} finally {
			}
		});
		
		//menuBar.setFont(new Font("Arial", Font.BOLD, 80));
		
		return menuBar;
	}
	
	private static JMenuItem getMenuItem(String menuItemTitle, Action action) {
		// origin - 13.12.2023, last edit - 13.12.2023
		JMenuItem menuItem = new JMenuItem(menuItemTitle);
		menuItem.setFont(new Font("Verdana", Font.PLAIN, 15));
		//menuItem.addActionListener(event -> System.exit(0));
		getActionListener(menuItemTitle, menuItem);
		return menuItem;
	}

	private static JMenuItem getMenuItem(String menuItemTitle) {
		// origin - 09.12.2023, last edit - 13.12.2023
		JMenuItem menuItem = new JMenuItem(menuItemTitle);
		menuItem.setFont(new Font("Verdana", Font.PLAIN, 15));
		//menuItem.addActionListener(event -> System.exit(0));
		getActionListener(menuItemTitle, menuItem);
		return menuItem;
	}

	private static void getActionListener(String menuItemTitle, JMenuItem menuItem) {
		// origin - 10.12.2023, last edit - 12.12.2023
		if (menuItemTitle == "File - exit") {
			//System.out.println("File - exit, "+menuItem.getName());
			// menuItem.addActionListener(event -> System.exit(0));
			menuItem.addActionListener(event -> {
				try {
					WB.exit();
				} catch (Exception ex) {
					Logger.add("GUI.getActionListener, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(),
							"", "GUI");
				}
			});
		}
	}

	private static JToolBar getBasicToolBar() throws Exception {
		// origin - 05.12.2023, last edit - 13.12.2023
		JToolBar toolBar = new JToolBar();
		//toolBar.setFont(new Font("Arial", Font.BOLD, 20));
		EventQueue.invokeLater(() -> {
			try {
				toolBar.setFloatable(false);
				toolBar.setOrientation(SwingConstants.HORIZONTAL);
				toolBar.add(new JButton("Print template doc"));
				toolBar.add(new JButton("Shift process"));
				toolBar.add(new JButton("Quick select"));
				toolBar.add(new JButton("Quick rest"));

			} catch (Exception ex) {
				Logger.add("GUI.getBasicToolBar, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "",
						"GUI");
			} finally {
			}
		});

		return toolBar;
	}

	public static void test() throws Exception {
		// origin - 03.12.2023, last edit - 03.12.2023
	}
}