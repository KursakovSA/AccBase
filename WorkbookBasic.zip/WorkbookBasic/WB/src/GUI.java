import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.util.LinkedHashMap;
import java.util.TreeSet;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.SwingConstants;

public class GUI {
	// origin - 03.12.2023, last edit - 17.10.2024
	private static JMenuBar basicMenuBar;
	private static JToolBar basicToolBar;
	private static String strMenuMark;
	private static LinkedHashMap<String, String> basicMenuTitle = new LinkedHashMap<String, String>();
	public static String basicMenuStrLocal;// TOTHINK get it real value

	static {
		try {
			GUI.strMenuMark = "[Menu]";
			GUI.basicMenuTitle = GUI.getBasicMenuTitle();
			GUI.basicMenuStrLocal = LocInt.emergencyStrLang;
			GUI.basicMenuBar = GUI.getBasicMenuBar();
			GUI.basicToolBar = GUI.getBasicToolBar();
		} catch (Exception ex) {
			WB.addLog("GUI.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
		} finally {
			Etc.doNothing();
		}
	}

	private static String getPatternMenuItem(String initStrMenu) throws Exception {
		// origin - 22.07.2024, last edit - 25.07.2024
		String res = Etc.fixTrim(initStrMenu);
		try {
			res = Etc.delStr(res, GUI.strMenuMark);
			res = Etc.delStr(res, ")");// ??magic string ??
			res = res + WB.strDot; // ex. res="(Face."
		} catch (Exception ex) {
			WB.addLog("GUI.getPatternMenuItem, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("GUI.getPatternMenuItem, res=" + res + ", initStrMenu=" +
		// initStrMenu,
		// WB.strEmpty, "GUI");
		return res;
	}

	private static String delMark(String initStrMenu) throws Exception {
		// origin - 22.07.2024, last edit - 22.07.2024
		String res = Etc.fixTrim(initStrMenu);
		try {
			res = Etc.delStr(res, GUI.strMenuMark);
			// res = Etc.delStr(res, GUI.strMenuItemMark);
			// menuId.replaceAll("(", WB.strEmpty);
			// menuId.replaceAll(")", WB.strEmpty);
		} catch (Exception ex) {
			WB.addLog("GUI.delMark, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("GUI.delMark, res=" + res + ", initStrMenu=" + initStrMenu,
		// WB.strEmpty, "GUI");
		return res;
	}

	private static void addMenu2(JMenuBar menuBar, String initStrMenu) throws Exception {
		// origin - 20.07.2024, last edit - 22.07.2024
		try {
			JMenu currMenu = GUI.getMenu(GUI.setMenuTitle(initStrMenu));
			GUI.addMenu(currMenu, getPatternMenuItem(initStrMenu));
			menuBar.add(currMenu);
		} catch (Exception ex) {
			WB.addLog("GUI.addMenu, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
		} finally {
			Etc.doNothing();
		}
	}

	private static void addMenu(JMenu menu, String menuId) throws Exception {
		// origin - 19.07.2024, last edit - 22.07.2024
		try {
			// res = GUI.getMenu(GUI.setMenuTitle(menuId.toString()));
			for (var entry : GUI.basicMenuTitle.entrySet()) {
				String key = entry.getKey();
				if (Etc.strContains(key, menuId)) {
					menu.add(GUI.getMenuItem(GUI.setMenuTitle(key)));
				}
			}

			// add custom menu items
			GUI.addMenuItemCustom(menu);
		} catch (Exception ex) {
			WB.addLog("GUI.addMenu, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
		} finally {
			Etc.doNothing();
		}
	}

	private static String setMenuTitle(String menuId) throws Exception {
		// origin - 18.07.2024, last edit - 27.07.2024
		String res = WB.strEmpty;
		menuId = Etc.fixTrim(menuId);
		String resLocInt = WB.strEmpty;
		try {
			resLocInt = GUI.basicMenuTitle.get(menuId).toString();
			// resLocInt = LocInt.getLocal(LocInt.getListStrLocal(resLocInt),
			// GUI.basicMenuStrLocal);
			resLocInt = LocInt.getLocal(resLocInt, GUI.basicMenuStrLocal);

			if (Etc.strContains(menuId, WB.strDot)) {// if this menuItemId ex. "(Input.20)"
				res = menuId + WB.strSpace + resLocInt;
			} else {
				res = resLocInt; // if this menuId ex. "(Face)"
			}

		} catch (Exception ex) {
			WB.addLog("GUI.setMenuTitle, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("GUI.setMenuTitle, res=" + res + ", menuItemId=" + menuItemId,
		// WB.strEmpty, "GUI");
		return res;
	}

	public static JFrame getFrameBasic() throws Exception {
		// origin - 03.12.2023, last edit - 09.08.2024
		JFrame frame = new JFrame();
		EventQueue.invokeLater(() -> {
			try {
				frame.setTitle(WB.frameBasicTitle);
				JPanel panelBasic = new JPanel();
				panelBasic.setBackground(Color.lightGray);

				BorderLayout layout = new BorderLayout();
				panelBasic.setLayout(layout);
				frame.add(panelBasic);

				frame.setJMenuBar(GUI.basicMenuBar);
				panelBasic.add(GUI.basicToolBar, BorderLayout.NORTH);

				// JSlider slider1 = new JSlider();
				// slider1.setOrientation(SwingConstants.BOTTOM);
				// slider1.setLocation(SwingConstants.BOTTOM);
				// slider1.setMajorTickSpacing(10);

//		        slider1.addChangeListener(new ChangeListener() {
//		            public void stateChanged(ChangeEvent e) {
//		                int value = ((JSlider)e.getSource()).getValue();
//		                label.setText(value);
//		            }
//		        });

				// slider1.setPaintLabels(true);
				// panelBasic.add(label, BorderLayout.SOUTH);
				// panelBasic.add(slider1);

				JTextField dbConnList = new JTextField(100);
				dbConnList.setFont(new Font("Arial", Font.BOLD, 20));
				dbConnList.setText("Input dbConn");
				frame.add(dbConnList, BorderLayout.NORTH);

				Object[][] array = new String[][] {
						{ "Кольцо с кам.", "гр", "1,5", Conv.fixDouble("1,5"), Conv.formatterDouble("1,5") },
						{ "Блезик", "карат", "6676764,0", Conv.fixDouble("6676764,0"),
								Conv.formatterDouble("6676764,0"), Conv.formatterDouble("6676764,0", '.', ',') },
						{ "Лом", "карат", "307876.08545", Conv.fixDouble("307876.08545"),
								Conv.formatterDouble("307876.08545") },
						{ "Браслет", "карат", "245643.22", Conv.fixDouble("245643.22"),
								Conv.formatterDouble("245643.22") } };
				Object[] columnsHeader = new String[] { "Наименование", "Ед.измерения", "Количество", "Etc.fixDouble()",
						"Etc.formatterDouble()" };
				JTable table1 = new JTable(array, columnsHeader);
				table1.getTableHeader().setVisible(true);
				table1.setTableHeader(null);
				table1.setRowHeight(30);
				// table1.setAutoResizeMode(1);
				table1.setFont(new Font("Arial", Font.PLAIN, 20));
				panelBasic.add(table1);

				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				// frame.setPreferredSize(new Dimension(640, 480));
				frame.setExtendedState(java.awt.Frame.MAXIMIZED_BOTH);
				frame.setFont(new Font("Verdana", Font.BOLD, 15));
				frame.setVisible(true);
			} catch (Exception ex) {
				WB.addLog("GUI.getFrameBasic, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
			} finally {
				Etc.doNothing();
			}
		});
		WB.addLog("GUI.getFrameBasic, frame.getName=" + frame.getName(), WB.strEmpty, "GUI");
		return frame;
	}

	private static void addMenuItemCustom(JMenu menu) throws Exception {
		// origin - 19.12.2023, last edit - 20.07.2024
		try {
			menu.addSeparator();
			menu.add(GUI.getMenuItem("Custom standard - "));
			menu.add(GUI.getMenuItem("Custom pawn shop - "));
			// menu.addSeparator();
		} catch (Exception ex) {
			WB.addLog("GUI.addMenuItemCustom, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
		} finally {
			Etc.doNothing();
		}
	}

	private static String getMenuItemId(String menuItemTitle) throws Exception {
		// origin - 27.08.2024, last edit - 27.08.2024
		String res = WB.strEmpty;
		try {
			for (var entry : GUI.basicMenuTitle.entrySet()) {
				String key = entry.getKey();
				// String value = entry.getValue();
				if (Etc.strContains(menuItemTitle, key)) {
					res = key;
					res.replaceAll("(", WB.strEmpty);// ??magic string??
					res.replaceAll(")", WB.strEmpty);// ??magic string??
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("GUI.getMenuItemId, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("GUI.getMenuItemId, res=" + res + ", menuItemTitle=" +
		// menuItemTitle,
		// WB.strEmpty, "GUI");
		return res;
	}

	private static void getActionListener(String menuItemTitle, JMenuItem menuItem) throws Exception {
		// origin - 10.12.2023, last edit - 27.08.2024
		menuItem.addActionListener(event -> {
			try {
				TreeSet<String> setConn = Conn.work;
				// WB.addLog2("GUI.getActionListener, menuItemTitle=" + menuItemTitle,
				// WB.strEmpty, "GUI");

				String menuItemTitleId = GUI.getMenuItemId(menuItemTitle);
				switch (menuItemTitleId) { 
				
				case "(Support.80)" -> Command.clearSpoolerPrinters();
				case "(Support.70)" -> Command.openControlPrinters();
				case "(Support.40)" -> Command.cleanFolderProgram();

				case "(Input.20)" -> {
					String patternInOut = Conn.outputDbPattern;
					String patternTo = Conn.toAllPattern;
					TreeSet<String> setConnFrom = Conn.getDbList2(WB.inputOutputDir, patternInOut, patternTo);
					TreeSet<String> setConnTo = new TreeSet<String>();
					setConnTo.add(WB.lastConnWork);
					Command.input(setConnFrom, setConnTo, patternInOut, patternTo);
					Command.cleanInputOutput(patternInOut, patternTo);// after input clean
				}

				case "(Output.50)" -> {
					String patternInOut = Conn.outputDbPattern;
					String patternTo = Conn.toAllPattern;
					Command.cleanInputOutput(patternInOut, patternTo);// before output clean
					Command.outputBackup(setConn);
				}

				case "(Support.60)" -> Command.replaceInto(setConn);
				case "(Support.30)" -> Command.openUserManualLocal();

				case "(Support.20)" -> {
					Command.updateBases(setConn);
					Command.updateExtFiles();
				}

				case "(Support.10)" -> {
					Command.backup(setConn);
					Command.integrityCheck(setConn);
					Command.reindex(setConn);
					Command.vacuum(setConn);
				}
				case "(Support.50)" -> Command.getLastRecord(setConn);
				case " - exit" -> Command.exit();

				default -> Etc.doNothing();
				}

//				if (Etc.strContains(menuItemTitle, "Support.80")) {
//					Command.clearSpoolerPrinters();
//				}
//				if (Etc.strContains(menuItemTitle, "Support.70")) {
//					Command.openControlPrinters();
//				}
//				if (Etc.strContains(menuItemTitle, "Support.40")) {
//					Command.cleanFolderProgram();
//				}
//				if (Etc.strContains(menuItemTitle, "Input.20")) {
//					String patternInOut = Conn.outputDbPattern;
//					String patternTo = Conn.toAllPattern;
//					TreeSet<String> setConnFrom = Conn.getDbList2(WB.inputOutputDir, patternInOut, patternTo);
//					TreeSet<String> setConnTo = new TreeSet<String>();
//					setConnTo.add(WB.lastConnWork);
//					Command.input(setConnFrom, setConnTo, patternInOut, patternTo);
//					Command.cleanInputOutput(patternInOut, patternTo);// after input clean
//				}
//				if (Etc.strContains(menuItemTitle, "Output.50")) {
//					String patternInOut = Conn.outputDbPattern;
//					String patternTo = Conn.toAllPattern;
//					Command.cleanInputOutput(patternInOut, patternTo);// before output clean
//					Command.outputBackup(setConn);
//				}
//				if (Etc.strContains(menuItemTitle, "Support.60")) {
//					Command.replaceInto(setConn);
//				}
//				if (Etc.strContains(menuItemTitle, "Support.30")) {
//					Command.openUserManualLocal();
//				}
//				if (Etc.strContains(menuItemTitle, "Support.20")) {
//					Command.updateBases(setConn);
//					Command.updateExtFiles();
//				}
//				if (Etc.strContains(menuItemTitle, "Support.10")) {
//					Command.backup(setConn);
//					Command.integrityCheck(setConn);
//					Command.reindex(setConn);
//					Command.vacuum(setConn);
//				}
//				if (Etc.strContains(menuItemTitle, "Support.50")) {
//					Command.getLastRecord(setConn);
//				}
//				if (Etc.strContains(menuItemTitle, " - exit")) {// TOTHINK
//					Command.exit();
//				}
			} catch (Exception ex) {
				WB.addLog("GUI.getActionListener, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
			} finally {
				Etc.doNothing();
			}
		});
	}

	private static void getActionListener(String buttonTitle, JButton button) throws Exception {
		// origin - 15.12.2023, last edit - 19.07.2024
		button.addActionListener(event -> {
			try {
				if (Etc.strContains(buttonTitle, "Exit")) {
					Command.exit();
				}

				if (Etc.strContains(buttonTitle, "Print template doc")) {
					// System.out.println("Print template doc");
				}
			} catch (Exception ex) {
				WB.addLog("GUI.getActionListener, ex=" + ex.getMessage() + ", buttonTitle=" + buttonTitle, WB.strEmpty,
						"GUI");
			} finally {
				Etc.doNothing();
			}
		});
	}

	private static JToolBar getBasicToolBar() throws Exception {
		// origin - 05.12.2023, last edit - 27.06.2024
		JToolBar toolBar = new JToolBar();
		EventQueue.invokeLater(() -> {
			try {
				toolBar.setFloatable(false);
				toolBar.setOrientation(SwingConstants.HORIZONTAL);
				toolBar.add(getButton("Print template doc (not ready)"));
				toolBar.add(getButton("Shift process (not ready)"));
				toolBar.add(getButton("Quick select (not ready)"));
				toolBar.add(getButton("Quick rest (not ready)"));
				toolBar.add(getButton("Exit"));

			} catch (Exception ex) {
				WB.addLog("GUI.getBasicToolBar, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
			} finally {
				Etc.doNothing();
			}
		});
		return toolBar;
	}

	private static JButton getButton(String buttonTitle) throws Exception {
		// origin - 15.12.2023, last edit - 05.07.2024
		JButton button = new JButton(buttonTitle);
		try {
			setFont(button);
			getActionListener(buttonTitle, button);
		} catch (Exception ex) {
			WB.addLog("GUI.getButton, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
		} finally {
			Etc.doNothing();
		}
		return button;
	}

	private static void setFont(JComponent jcomp) throws Exception {
		// origin - 15.12.2023, last edit - 05.07.2024
		try {
			((JComponent) jcomp).setFont(new Font("Arial", Font.BOLD, 15));
		} catch (Exception ex) {
			WB.addLog("GUI.setFont, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
		} finally {
			Etc.doNothing();
		}
	}

	private static JMenu getMenu(String menuTitle) throws Exception {
		// origin - 19.07.2024, last edit - 22.07.2024
		menuTitle = GUI.delMark(menuTitle);
		JMenu menu = new JMenu(menuTitle);
		try {
			GUI.setFont(menu);
		} catch (Exception ex) {
			WB.addLog("GUI.getMenu, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
		} finally {
			Etc.doNothing();
		}
		return menu;
	}

	private static JMenuItem getMenuItem(String menuItemTitle) throws Exception {
		// origin - 09.12.2023, last edit - 18.07.2024
		JMenuItem menuItem = new JMenuItem(menuItemTitle);
		try {
			GUI.setFont(menuItem);
			GUI.getActionListener(menuItemTitle, menuItem);
		} catch (Exception ex) {
			WB.addLog("GUI.getMenuItem, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
		} finally {
			Etc.doNothing();
		}
		return menuItem;
	}

	private static LinkedHashMap<String, String> getBasicMenuTitle() throws Exception {
		// origin - 18.07.2024, last edit - 11.08.2024
		LinkedHashMap<String, String> res = new LinkedHashMap<String, String>();
		try {
			res.put("(File)[Menu]", "(File)[EN](Файл)[RU](Файл)[Қаз]");
			res.put("(File.10)",
					"(File - open (not ready)[EN]Файл - открыть (не готов)[RU]Файл - ашық (дайын емес)[Қаз]");
			res.put("(File.20)",
					"File - save (not ready)[EN]Файл - сохранить (не готов)[RU]Файл - сақтау (дайын емес)[Қаз]");

			res.put("(Face)[Menu]", "(Face)[EN](Лицо)[RU](Тұлға)[Қаз]");
			res.put("(Face.10)",
					"Standard - new face (not ready)[EN]Standard - нов лицо (не готов)[RU]Standard - жаңа тұлға (дайын емес)[Қаз]");
			res.put("(Face.20)",
					"Standard - edit face (not ready)[EN]Standard - изм лицо (не готов)[RU]Standard - тұлға-әлпеті (дайын емес)[Қаз]");
			res.put("(Face.PS.10)",
					"Sectoral pawn shop - new borrower (not ready)[EN]Sectoral pawn shop - новый заемщик (не готов)[RU]Sectoral pawn shop - жаңа қарыз алушы (дайын емес)[Қаз]");
			res.put("(Face.PS.20)",
					"Sectoral pawn shop - edit borrower (not ready)[EN]Sectoral pawn shop - изм заемщик (не готов)[RU]Sectoral pawn shop - өңдеу қарыз алушы (дайын емес)[Қаз]");

			res.put("(Asset)[Menu]", "(Asset)[EN](Актив)[RU](Актив)[Қаз]");
			res.put("(Asset.10)",
					"Standard - new asset (not ready)[EN]Standard - нов актив (не готов)[RU]Standard - жаңа актив (дайын емес)[Қаз]");
			res.put("(Asset.20)",
					"Standard - edit asset (not ready)[EN]Standard - изм актив (не готов)[RU]Standard - активті өңдеу (дайын емес)[Қаз]");
			res.put("(Asset.PS.10)",
					"Sectoral pawn shop - new pawn (not ready)[EN]Sectoral pawn shop - нов залог (не готов)[RU]Sectoral pawn shop - жаңа кепіл (дайын емес)[Қаз]");
			res.put("(Asset.PS.20)",
					"Sectoral pawn shop - edit pawn (not ready)[EN]Sectoral pawn shop - изм залог (не готов)[RU]Sectoral pawn shop - қамтамасыз етуді өзгерту (дайын емес)[Қаз]");

			res.put("(Deal)[Menu]", "(Deal)[EN](Договор)[RU](Келісім)[Қаз]");
			res.put("(Deal.10)",
					"Standard - new deal (not ready)[EN]Standard - нов договор (не готов)[RU]Standard - жаңа келісім (дайын емес)[Қаз]");
			res.put("(Deal.20)",
					"Standard - edit deal (not ready)[EN]Standard - изм договор (не готов)[RU]Standard - келісім-шартты өңдеу (дайын емес)[Қаз]");
			res.put("(Deal.PS.10)",
					"Sectoral pawn shop - new pawn doc (not ready)[EN]Sectoral pawn shop - нов залог билет (не готов)[RU]Sectoral pawn shop - жаңа кепіл билеті (дайын емес)[Қаз]");
			res.put("(Deal.PS.20)",
					"Sectoral pawn shop - edit pawn doc (not ready)[EN]Sectoral pawn shop - изм залог билет (не готов)[RU]Sectoral pawn shop - депозиттік билетті өзгерту (дайын емес)[Қаз]");

			res.put("(Process)[Menu]", "(Process)[EN](Процесс)[RU](Процесс)[Қаз]");
			res.put("(Process.PS.10)",
					"Sectoral pawn shop - Accrual interest 1 (not ready)[EN]Sectoral pawn shop - начисление вознаграждения[RU]Sectoral pawn shop - сыйақыны есептеу[Қаз]");
			res.put("(Process.PS.20)",
					"Sectoral pawn shop - Write off deal 1 (not ready)[EN]Sectoral pawn shop - списание договоров 1[RU]Sectoral pawn shop - шарттарды есептен шығару 1[Қаз]");
			res.put("(Process.PS.30)",
					"Sectoral pawn shop - Write off deal 2 (not ready)[EN]Sectoral pawn shop - списание договоров 2[RU]Sectoral pawn shop - шарттарды есептен шығару 2[Қаз]");
			res.put("(Process.PS.40)",
					"Sectoral pawn shop - Write off deal 3 (not ready)[EN]Sectoral pawn shop - списание договоров 3[RU]Sectoral pawn shop - шарттарды есептен шығару 3[Қаз]");
			res.put("(Process.PS.50)",
					"Sectoral pawn shop - Write off deal 4 (not ready)[EN]Sectoral pawn shop - списание договоров 4[RU]Sectoral pawn shop - шарттарды есептен шығару 4[Қаз]");
			res.put("(Process.PS.60)",
					"Sectoral pawn shop - Write off deal 5 (not ready)[EN]Sectoral pawn shop - списание договоров 5[RU]Sectoral pawn shop - шарттарды есептен шығару 5[Қаз]");
			res.put("(Process.PS.70)",
					"Sectoral pawn shop - Write off deal 6 (not ready)[EN]Sectoral pawn shop - списание договоров 6[RU]Sectoral pawn shop - шарттарды есептен шығару 6[Қаз]");
			res.put("(Process.PS.80)",
					"Sectoral pawn shop - Write off deal 7 (not ready)[EN]Sectoral pawn shop - списание договоров 7[RU]Sectoral pawn shop - шарттарды есептен шығару 7[Қаз]");

			res.put("(Workbook)[Menu]", "(Workbook)[EN](Рабочая книга)[RU](Жұмыс дәптері)[Қаз]");

			res.put("(Input)[Menu]", "(Input)[EN](Ввод)[RU](Енгізіңіз)[Қаз]");
			res.put("(Input.10)",
					"Standard - EsfXML (not ready)[EN]Standard - EsfXML (не готов)[RU]Standard - EsfXML (дайын емес)[Қаз]");
			res.put("(Input.20)",
					"Standard - from all to lastConnWork[EN]Standard - от всех в рабочие базы[RU]Standard - барлығынан жұмыс базаларына дейін[Қаз]");
			res.put("(Input.PS.10)",
					"Sectoral pawn shop - PkbXLSX (not ready)[EN]Sectoral pawn shop - PkbXLSX (не готов)[RU]Sectoral pawn shop - PkbXLSX (дайын емес)[Қаз]");

			res.put("(Output)[Menu]", "(Output)[EN](Вывод)[RU](Вывод)[Қаз]");
			res.put("(Output.10)",
					"Standard - EsfXML (not ready)[EN]Standard - EsfXML (не готов)[RU]Standard - EsfXML (дайын емес)[Қаз]");
			res.put("(Output.20)",
					"Standard - MT100 (not ready)[EN]Standard - MT100 (не готов)[RU]Standard - MT100 (дайын емес)[Қаз]");
			res.put("(Output.30)",
					"Standard - MT102 (not ready)[EN]Standard - MT102 (не готов)[RU]Standard - MT102 (дайын емес)[Қаз]");
			res.put("(Output.40)",
					"Standard - Swift all (not ready)[EN]Standard - Swift все (не готов)[RU]Standard - Swift барлығы (дайын емес)[Қаз]");
			res.put("(Output.50)",
					"Standard - from Conn.work to all[EN]Standard - от рабочих баз для всех (не готов)[RU]Standard - жұмыс орындарынан бастап барлығына дейін (дайын емес)[Қаз]");
			res.put("(Output.PS.10)",
					"Sectoral pawn shop - National bank RQ (not ready)[EN]Sectoral pawn shop - National bank RQ (не готов)[RU]Sectoral pawn shop - National bank RQ (дайын емес)[Қаз]");
			res.put("(Output.PS.20)",
					"Sectoral pawn shop - First credit bureau (not ready)[EN]Sectoral pawn shop - Первое кредитное бюро (не готов)[RU]Sectoral pawn shop - Бірінші несиелік бюро (дайын емес)[Қаз]");

			res.put("(Report)[Menu]", "(Report)[EN](Отчет)[RU](Отчет)[Қаз]");
			res.put("(Report.10)",
					"Standard - cash book (not ready)[EN]Standard - кассовая книга (не готов)[RU]Standard - кассалық кітап (дайын емес)[Қаз]");

			res.put("(Other)[Menu]", "(Other)[EN](Прочее)[RU](Прочее)[Қаз]");
			res.put("(Other.10)",
					"Standard - new debt (not ready)[EN]Standard - нов долг (не готов)[RU]Standard - жаңа міндет (дайын емес)[Қаз]");
			res.put("(Other.20)",
					"Standard - edit debt (not ready)[EN]Standard - изм долг (не готов)[RU]Standard - қарызды өңдеу (дайын емес)[Қаз]");
			res.put("(Other.30)",
					"Standard - new geo (not ready)[EN]Standard - нов гео (не готов)[RU]Standard - жаңа гео (дайын емес)[Қаз]");
			res.put("(Other.40)",
					"Standard - edit geo (not ready)[EN]Standard - изм гео (не готов)[RU]Standard - өңдеу гео (дайын емес)[Қаз]");
			res.put("(Other.50)",
					"Standard - new item (not ready)[EN]Standard - нов статья (не готов)[RU]Standard - жаңа мақала (дайын емес)[Қаз]");
			res.put("(Other.60)",
					"Standard - edit item (not ready)[EN]Standard - изм статья (не готов)[RU]Standard - мақаланы өңдеу (дайын емес)[Қаз]");
			res.put("(Other.70)",
					"Standard - new unit (not ready)[EN]Standard - нов ед изм (не готов)[RU]Standard - жаңа өзгеріс бірлігі (дайын емес)[Қаз]");
			res.put("(Other.80)",
					"Standard - edit unit (not ready)[EN]Standard - изм ед изм (не готов)[RU]Standard - Өлшем бірлігі Өлшеу (дайын емес)[Қаз]");

			res.put("(Support)[Menu]", "(Support)[EN](Техподдержка)[RU](Техподдержка)[Қаз]");
			res.put("(Support.10)",
					"Standard - backup, integrity check, reindex, vacuum[EN]Standard - полный сервис баз данных[RU]Standard - толық дерекқор қызметі[Қаз]");
			res.put("(Support.20)",
					"Standard - update bases, update ext files[EN]Standard - апдейт баз данных, апдейт внеш файлов[RU]Standard - дерекқорды жаңарту, сыртқы файлды жаңарту[Қаз]");
			res.put("(Support.30)",
					"Standard - open user manual local[EN]Standard - открыть локальное рук-во польз-ля[RU]Standard - жергілікті пайдаланушы нұсқаулығын ашыңыз[Қаз]");
			res.put("(Support.40)",
					"Standard - clean folder program[EN]Standard - очистка папки программы[RU]Standard - бағдарлама қалтасын тазалау[Қаз]");
			res.put("(Support.50)",
					"Standard - test get last record[EN]Standard - тест чтения последних записей[RU]Standard - соңғы жазбаларды оқу сынағы[Қаз]");
			res.put("(Support.60)",
					"Standard - test replace into[EN]Standard - тест записи[RU]Standard - жазу сынағы[Қаз]");
			res.put("(Support.70)",
					" Standard - open control printers[EN]Standard - открыть управление принтерами[RU]Standard - принтерді басқаруды ашыңыз[Қаз]");
			res.put("(Support.80)",
					"Standard - clear spooler printers[EN]Standard - очистка спулера принтеров[RU]Standard - принтерлерді спулер тазалау[Қаз]");
		} catch (Exception ex) {
			WB.addLog("GUI.getBasicMenuTitle, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	private static JMenuBar getBasicMenuBar() throws Exception {
		// origin - 03.12.2023, last edit - 28.08.2024
		JMenuBar menuBar = new JMenuBar();
		EventQueue.invokeLater(() -> {
			try {
				LinkedHashMap<String, String> menuOrder = new LinkedHashMap<String, String>();
				menuOrder = getMenuOrder(GUI.basicMenuTitle);

				for (var entry : menuOrder.entrySet()) {
					String initStrMenu = entry.getKey();
					GUI.addMenu2(menuBar, initStrMenu);
				}
			} catch (Exception ex) {
				WB.addLog("GUI.getBasicMenuBar, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
			} finally {
				Etc.doNothing();
			}
		});
		return menuBar;
	}

	private static LinkedHashMap<String, String> getMenuOrder(LinkedHashMap<String, String> listMenuTitle)
			throws Exception {
		// origin - 22.07.2024, last edit - 27.08.2024
		LinkedHashMap<String, String> res = new LinkedHashMap<String, String>();
		try {
			for (var entry : listMenuTitle.entrySet()) {
				String key = entry.getKey();
				String value = entry.getValue();
				if (Etc.strContains(key, GUI.strMenuMark)) {
					res.put(key, value);
				}
			}
		} catch (Exception ex) {
			WB.addLog("GUI.test, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("GUI.getMenuOrder, res.size=" + res.size(), WB.strEmpty, "GUI");
		return res;
	}
	
	private GUI() {
		// origin - 04.11.2024, last edit - 04.11.2024
	}

	public static void test() throws Exception {
		// origin - 03.12.2023, last edit - 16.09.2024
		try {

//			// getMenuItemId
//			var arg1 = new String[] { "00006715567453", "(Support.70) allo", "003", "00Fkmaf" };
//			for (var testArg1 : arg1) {
//				WB.addLog2("GUI.test.getMenuItemId, res=" + GUI.getMenuItemId(testArg1) + ", testArg1=" + testArg1,
//						WB.strEmpty, "GUI");
//			}

		} catch (Exception ex) {
			WB.addLog("GUI.test, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
		} finally {
			Etc.doNothing();
		}
		//WB.addLog2("GUI.test end ", WB.strEmpty, "GUI");
	}
}