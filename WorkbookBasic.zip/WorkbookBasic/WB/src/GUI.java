import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.util.LinkedHashMap;
import java.util.TreeSet;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.SwingConstants;

public class GUI {
	// origin - 03.12.2023, last edit - 04.08.2024
	private static JMenuBar basicMenuBar;
	private static JToolBar basicToolBar;
	private static String strMenuMark;
	// private static String strMenuItemMark;
	private static LinkedHashMap<String, String> basicMenuTitle = new LinkedHashMap<String, String>();
	public static String basicMenuStrLocal;// TOTHINK get it real value

	static {
		try {
			GUI.strMenuMark = "[Menu]";
			// strMenuItemMark = "[MenuItem]";
			GUI.basicMenuTitle = getBasicMenuTitle();
			GUI.basicMenuStrLocal = LocInt.emergencyStrLang;// "[RU]";// TOTHINK
			GUI.basicMenuBar = getBasicMenuBar();
			GUI.basicToolBar = getBasicToolBar();
		} catch (Exception ex) {
			WB.addLog("GUI.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
		} finally {
			Etc.doNothing();
		}
	}

	private static String getPatternMenuItem(String initStrMenu) throws Exception {
		// origin - 22.07.2024, last edit - 25.07.2024
		String res = Etc.fixTrim(initStrMenu);
		try {
			res = Etc.delStr(res, GUI.strMenuMark);
			res = Etc.delStr(res, ")");// ??magic string ??
			res = res + WB.strDot; // ex. res="(Face."
		} catch (Exception ex) {
			WB.addLog("GUI.getPatternMenuItem, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("GUI.getPatternMenuItem, res=" + res + ", initStrMenu=" +
		// initStrMenu,
		// WB.strEmpty, "GUI");
		return res;
	}

	private static String delMark(String initStrMenu) throws Exception {
		// origin - 22.07.2024, last edit - 22.07.2024
		String res = Etc.fixTrim(initStrMenu);
		try {
			res = Etc.delStr(res, GUI.strMenuMark);
			// res = Etc.delStr(res, GUI.strMenuItemMark);
			// menuId.replaceAll("(", WB.strEmpty);
			// menuId.replaceAll(")", WB.strEmpty);
		} catch (Exception ex) {
			WB.addLog("GUI.delMark, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("GUI.delMark, res=" + res + ", initStrMenu=" + initStrMenu,
		// WB.strEmpty, "GUI");
		return res;
	}

	private static void addMenu2(JMenuBar menuBar, String initStrMenu) throws Exception {
		// origin - 20.07.2024, last edit - 22.07.2024
		try {
			JMenu currMenu = GUI.getMenu(GUI.setMenuTitle(initStrMenu));
			GUI.addMenu(currMenu, getPatternMenuItem(initStrMenu));
			menuBar.add(currMenu);
		} catch (Exception ex) {
			WB.addLog("GUI.addMenu, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
		} finally {
			Etc.doNothing();
		}
	}

	private static void addMenu(JMenu menu, String menuId) throws Exception {
		// origin - 19.07.2024, last edit - 22.07.2024
		try {
			// res = GUI.getMenu(GUI.setMenuTitle(menuId.toString()));
			for (var entry : GUI.basicMenuTitle.entrySet()) {
				String key = entry.getKey();
				if (Etc.strContains(key, menuId)) {
					menu.add(GUI.getMenuItem(GUI.setMenuTitle(key)));
				}
			}

			// add custom menu items
			GUI.addMenuItemCustom(menu);
		} catch (Exception ex) {
			WB.addLog("GUI.addMenu, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
		} finally {
			Etc.doNothing();
		}
	}

	private static String setMenuTitle(String menuId) throws Exception {
		// origin - 18.07.2024, last edit - 27.07.2024
		String res = WB.strEmpty;
		menuId = Etc.fixTrim(menuId);
		String resLocInt = WB.strEmpty;
		try {
			resLocInt = GUI.basicMenuTitle.get(menuId).toString();
			// resLocInt = LocInt.getLocal(LocInt.getListStrLocal(resLocInt),
			// GUI.basicMenuStrLocal);
			resLocInt = LocInt.getLocal(resLocInt, GUI.basicMenuStrLocal);

			if (Etc.strContains(menuId, WB.strDot)) {// if this menuItemId ex. "(Input.20)"
				res = menuId + WB.strSpace + resLocInt;
			} else {
				res = resLocInt; // if this menuId ex. "(Face)"
			}

		} catch (Exception ex) {
			WB.addLog("GUI.setMenuTitle, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("GUI.setMenuTitle, res=" + res + ", menuItemId=" + menuItemId,
		// WB.strEmpty, "GUI");
		return res;
	}

	public static JFrame getFrameBasic() throws Exception {
		// origin - 03.12.2023, last edit - 18.07.2024
		JFrame frame = new JFrame();
		EventQueue.invokeLater(() -> {
			try {
				frame.setTitle(WB.frameBasicTitle);
				JPanel panelBasic = new JPanel();
				panelBasic.setBackground(Color.lightGray);

				BorderLayout layout = new BorderLayout();
				panelBasic.setLayout(layout);
				frame.add(panelBasic);

				frame.setJMenuBar(GUI.basicMenuBar);
				panelBasic.add(GUI.basicToolBar, BorderLayout.NORTH);

				// JSlider slider1 = new JSlider();
				// slider1.setOrientation(SwingConstants.BOTTOM);
				// slider1.setLocation(SwingConstants.BOTTOM);
				// slider1.setMajorTickSpacing(10);

//		        slider1.addChangeListener(new ChangeListener() {
//		            public void stateChanged(ChangeEvent e) {
//		                int value = ((JSlider)e.getSource()).getValue();
//		                label.setText(value);
//		            }
//		        });

				// slider1.setPaintLabels(true);
				// panelBasic.add(label, BorderLayout.SOUTH);
				// panelBasic.add(slider1);

				JTextField dbConnList = new JTextField(100);
				dbConnList.setFont(new Font("Arial", Font.BOLD, 20));
				dbConnList.setText("Input dbConn");
				frame.add(dbConnList, BorderLayout.NORTH);

				Object[][] array = new String[][] {
						{ "Кольцо с кам.", "гр", "1,5", Conv.fixDouble("1,5"), Conv.formatterDouble("1,5"),
								Conv.formatterDouble("1,5", '.', ','), Conv.formatterDouble("1,5", '.', '"') },
						{ "Блезик", "карат", "6676764,0", Conv.fixDouble("6676764,0"),
								Conv.formatterDouble("6676764,0"), Conv.formatterDouble("6676764,0", '.', ','),
								Conv.formatterDouble("6676764,0", '.', '"') },
						{ "Лом", "карат", "307876.08545", Conv.fixDouble("307876.08545"),
								Conv.formatterDouble("307876.08545"), Conv.formatterDouble("307876.08545", '.', ','),
								Conv.formatterDouble("307876.08545", '.', '"') },
						{ "Браслет", "карат", "245643.22", Conv.fixDouble("245643.22"),
								Conv.formatterDouble("245643.22"), Conv.formatterDouble("245643.22", '.', ','),
								Conv.formatterDouble("245643.22", '.', '"') } };
				Object[] columnsHeader = new String[] { "Наименование", "Ед.измерения", "Количество", "Etc.fixDouble()",
						"Etc.formatterDouble()", "Etc.formatterDouble2()", "Etc.formatterDouble3()" };
				JTable table1 = new JTable(array, columnsHeader);
				table1.getTableHeader().setVisible(true);
				table1.setTableHeader(null);
				table1.setRowHeight(30);
				// table1.setAutoResizeMode(1);
				table1.setFont(new Font("Arial", Font.PLAIN, 20));
				panelBasic.add(table1);

				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				// frame.setPreferredSize(new Dimension(640, 480));
				frame.setExtendedState(java.awt.Frame.MAXIMIZED_BOTH);
				frame.setFont(new Font("Verdana", Font.BOLD, 15));
				frame.setVisible(true);
			} catch (Exception ex) {
				WB.addLog("GUI.getFrameBasic, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
			} finally {
				Etc.doNothing();
			}
		});
		WB.addLog("GUI.getFrameBasic, frame.getName=" + frame.getName(), WB.strEmpty, "GUI");
		return frame;
	}

	private static void addMenuItemCustom(JMenu menu) throws Exception {
		// origin - 19.12.2023, last edit - 20.07.2024
		try {
			menu.addSeparator();
			menu.add(GUI.getMenuItem("Custom standard - "));
			menu.add(GUI.getMenuItem("Custom pawn shop - "));
			// menu.addSeparator();
		} catch (Exception ex) {
			WB.addLog("GUI.addMenuItemCustom, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
		} finally {
			Etc.doNothing();
		}
	}

	private static void getActionListener(String menuItemTitle, JMenuItem menuItem) throws Exception {
		// origin - 10.12.2023, last edit - 23.07.2024
		menuItem.addActionListener(event -> {
			try {
				TreeSet<String> setConn = Conn.work;

				if (Etc.strContains(menuItemTitle, "Support.80")) {
					Command.ClearSpoolerPrinters();
				}
				if (Etc.strContains(menuItemTitle, "Support.70")) {
					Command.OpenControlPrinters();
				}
				if (Etc.strContains(menuItemTitle, "Support.40")) {
					Command.cleanFolderProgram();
				}
				if (Etc.strContains(menuItemTitle, "Input.20")) {
					String patternInOut = Conn.outputDbPattern;
					String patternTo = Conn.toAllPattern;
					TreeSet<String> setConnFrom = Conn.getDbList2(WB.inputOutputDir, patternInOut, patternTo);
					TreeSet<String> setConnTo = new TreeSet<String>();
					setConnTo.add(WB.lastConnWork);
					Command.input(setConnFrom, setConnTo, patternInOut, patternTo);
					Command.cleanInputOutput(patternInOut, patternTo);// after input clean
				}
				if (Etc.strContains(menuItemTitle, "Output.50")) {
					String patternInOut = Conn.outputDbPattern;
					String patternTo = Conn.toAllPattern;
					Command.cleanInputOutput(patternInOut, patternTo);// before output clean
					Command.outputBackup(setConn);
				}
				if (Etc.strContains(menuItemTitle, "Support.60")) {
					Command.replaceInto(setConn);
				}
				if (Etc.strContains(menuItemTitle, "Support.30")) {
					Command.openUserManualLocal();
				}
				if (Etc.strContains(menuItemTitle, "Support.20")) {
					Command.updateBases(setConn);
					Command.updateExtFiles();
				}
				if (Etc.strContains(menuItemTitle, "Support.10")) {
					Command.backup(setConn);
					Command.integrityCheck(setConn);
					Command.reindex(setConn);
					Command.vacuum(setConn);
				}
				if (Etc.strContains(menuItemTitle, "Support.50")) {
					Command.getLastRecord(setConn);
				}
				if (Etc.strContains(menuItemTitle, " - exit")) {// TOTHINK
					Command.exit();
				}
			} catch (Exception ex) {
				WB.addLog("GUI.getActionListener, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
			} finally {
				Etc.doNothing();
			}
		});
	}

	private static void getActionListener(String buttonTitle, JButton button) throws Exception {
		// origin - 15.12.2023, last edit - 19.07.2024
		button.addActionListener(event -> {
			try {
				if (Etc.strContains(buttonTitle, "Exit")) {
					Command.exit();
				}

				if (Etc.strContains(buttonTitle, "Print template doc")) {
					// System.out.println("Print template doc");
				}
			} catch (Exception ex) {
				WB.addLog("GUI.getActionListener, ex=" + ex.getMessage() + ", buttonTitle=" + buttonTitle, WB.strEmpty,
						"GUI");
			} finally {
				Etc.doNothing();
			}
		});
	}

	private static JToolBar getBasicToolBar() throws Exception {
		// origin - 05.12.2023, last edit - 27.06.2024
		JToolBar toolBar = new JToolBar();
		EventQueue.invokeLater(() -> {
			try {
				toolBar.setFloatable(false);
				toolBar.setOrientation(SwingConstants.HORIZONTAL);
				toolBar.add(getButton("Print template doc (not ready)"));
				toolBar.add(getButton("Shift process (not ready)"));
				toolBar.add(getButton("Quick select (not ready)"));
				toolBar.add(getButton("Quick rest (not ready)"));
				toolBar.add(getButton("Exit"));

			} catch (Exception ex) {
				WB.addLog("GUI.getBasicToolBar, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
			} finally {
				Etc.doNothing();
			}
		});

		return toolBar;
	}

	private static JButton getButton(String buttonTitle) throws Exception {
		// origin - 15.12.2023, last edit - 05.07.2024
		JButton button = new JButton(buttonTitle);
		try {
			setFont(button);
			getActionListener(buttonTitle, button);
		} catch (Exception ex) {
			WB.addLog("GUI.getButton, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
		} finally {
			Etc.doNothing();
		}
		return button;
	}

	private static void setFont(JComponent jcomp) throws Exception {
		// origin - 15.12.2023, last edit - 05.07.2024
		try {
			((JComponent) jcomp).setFont(new Font("Arial", Font.BOLD, 15));
		} catch (Exception ex) {
			WB.addLog("GUI.setFont, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
		} finally {
			Etc.doNothing();
		}
	}

	private static JMenu getMenu(String menuTitle) throws Exception {
		// origin - 19.07.2024, last edit - 22.07.2024
		menuTitle = GUI.delMark(menuTitle);
		JMenu menu = new JMenu(menuTitle);
		try {
			GUI.setFont(menu);
		} catch (Exception ex) {
			WB.addLog("GUI.getMenu, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
		} finally {
			Etc.doNothing();
		}
		return menu;
	}

	private static JMenuItem getMenuItem(String menuItemTitle) throws Exception {
		// origin - 09.12.2023, last edit - 18.07.2024
		JMenuItem menuItem = new JMenuItem(menuItemTitle);
		try {
			GUI.setFont(menuItem);
			GUI.getActionListener(menuItemTitle, menuItem);
		} catch (Exception ex) {
			WB.addLog("GUI.getMenuItem, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
		} finally {
			Etc.doNothing();
		}
		return menuItem;
	}

	private static LinkedHashMap<String, String> getBasicMenuTitle() throws Exception {// TODO
		// origin - 18.07.2024, last edit - 22.07.2024
		LinkedHashMap<String, String> res = new LinkedHashMap<String, String>();
		try {
			res.put("(File)[Menu]", "(File)[EN](Файл)[RU]");
			res.put("(File.10)", "(File - open (not ready)[EN]Файл - открыть[RU]");
			res.put("(File.20)", "File - save (not ready[EN]Файл - сохранить[RU])");

			res.put("(Face)[Menu]", "(Face)[EN](Лицо)[RU]");
			res.put("(Face.10)", "Standard - new face (not ready)[EN]Standard - нов лицо (не готов)[RU]");
			res.put("(Face.20)", "Standard - edit face (not ready)[EN]Standard - изм лицо (не готов)[RU]");
			res.put("(Face.PS.10)", "Sectoral pawn shop - new pledgor (not ready)[EN]");
			res.put("(Face.PS.20)", "Sectoral pawn shop - edit pledgor (not ready)[EN]");

			res.put("(Asset)[Menu]", "(Asset)[EN](Актив)[RU]");
			res.put("(Asset.10)", "Standard - new asset (not ready)[EN]Standard - нов актив (не готов)[RU]");
			res.put("(Asset.20)", "Standard - edit asset (not ready)[EN]Standard - изм актив (не готов)[RU]");
			res.put("(Asset.PS.10)",
					"Sectoral pawn shop - new pawn (not ready)[EN]Sectoral pawn shop - нов займ (не готов)[RU]");
			res.put("(Asset.PS.20)",
					"Sectoral pawn shop - edit pawn (not ready)[EN]Sectoral pawn shop - изм займ (не готов)[RU]");

			res.put("(Deal)[Menu]", "(Deal)[EN](Договор)[RU]");
			res.put("(Deal.10)", "Standard - new deal (not ready)[EN]");
			res.put("(Deal.20)", "Standard - edit deal (not ready)[EN]");
			res.put("(Deal.PS.10)",
					"Sectoral pawn shop - new deposit (not ready)[EN]Sectoral pawn shop - нов залог (не готов)[RU]");
			res.put("(Deal.PS.20)",
					"Sectoral pawn shop - edit deposit (not ready)[EN]Sectoral pawn shop - изм залог (не готов)[RU]");

			res.put("(Process)[Menu]", "(Process)[EN](Процесс)[RU]");
			res.put("(Process.PS.10)", "Sectoral pawn shop - Accrual interest 1 (not ready)[EN]");
			res.put("(Process.PS.20)", "Sectoral pawn shop - Write off 1 (not ready)[EN]");
			res.put("(Process.PS.30)", "Sectoral pawn shop - Write off 2 (not ready)[EN]");
			res.put("(Process.PS.40)", "Sectoral pawn shop - Write off 3 (not ready)[EN]");
			res.put("(Process.PS.50)", "Sectoral pawn shop - Write off 4 (not ready)[EN]");
			res.put("(Process.PS.60)", "Sectoral pawn shop - Write off 5 (not ready)[EN]");
			res.put("(Process.PS.70)", "Sectoral pawn shop - Write off 6 (not ready)[EN]");
			res.put("(Process.PS.80)", "Sectoral pawn shop - Write off 7 (not ready)[EN]");

			res.put("(Workbook)[Menu]", "(Workbook)[EN](Рабочая книга)[RU]");

			res.put("(Input)[Menu]", "(Input)[EN](Ввод)[RU]");
			res.put("(Input.10)", "Standard - EsfXML (not ready)[EN]");
			res.put("(Input.20)", "Standard - from all to lastConnWork[EN]");
			res.put("(Input.PS.10)", "Sectoral pawn shop - PkbXLSX (not ready)[EN]");

			res.put("(Output)[Menu]", "(Output)[EN](Вывод)[RU]");
			res.put("(Output.10)", "Standard - EsfXML (not ready)[EN]");
			res.put("(Output.20)", "Standard - MT100 (not ready)[EN]");
			res.put("(Output.30)", "Standard - MT102 (not ready)[EN]");
			res.put("(Output.40)", "Standard - Swift all (not ready)[EN]");
			res.put("(Output.50)", "Standard - from Conn.work to all[EN]");
			res.put("(Output.PS.10)", "National bank RQ (not ready)[EN]");
			res.put("(Output.PS.20)", "First credit bureau (not ready)[EN]");

			res.put("(Report)[Menu]", "(Report)[EN](Отчет)[RU]");
			res.put("(Report.10)", "Standard - cash book (not ready)[EN]");

			res.put("(Other)[Menu]", "(Other)[EN](Прочее)[RU]");
			res.put("(Other.10)", "Standard - new debt (not ready)[EN]");
			res.put("(Other.20)", "Standard - edit debt (not ready)[EN]");
			res.put("(Other.30)", "Standard - new geo (not ready)[EN]");
			res.put("(Other.40)", "Standard - edit geo (not ready)[EN]");
			res.put("(Other.50)", "Standard - new item (not ready)[EN]");
			res.put("(Other.60)", "Standard - edit item (not ready)[EN]");
			res.put("(Other.70)", "Standard - new unit (not ready)[EN]");
			res.put("(Other.80)", "Standard - edit unit (not ready)[EN]");

			res.put("(Support)[Menu]", "(Support)[EN](Техподдержка)[RU]");
			res.put("(Support.10)",
					"Standard - backup, integrity check, reindex, vacuum[EN]Standard - полный сервис баз[RU]");
			res.put("(Support.20)",
					"Standard - update bases, update ext files[EN]Standard - апдейт баз, апдейт внеш файлов[RU]");
			res.put("(Support.30)",
					"Standard - open user manual local[EN]Standard - открыть локальное рук-во польз-ля[RU]");
			res.put("(Support.40)", "Standard - clean folder program[EN]Standard - очистка папки программы[RU]");
			res.put("(Support.50)", "Standard - test get last record[EN]");
			res.put("(Support.60)", "Standard - test replace into[EN]");
			res.put("(Support.70)",
					" Standard - open control printers[EN]Standard - открыть управление принтерами[RU]Standard - принтерді басқаруды ашыңыз[Қаз]");
			res.put("(Support.80)",
					"Standard - clear spooler printers[EN]Standard - очистка спулера принтеров[RU]Standard - принтерлерді спулер тазалау[Қаз]");
		} catch (Exception ex) {
			WB.addLog("GUI.getBasicMenuTitle, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	private static JMenuBar getBasicMenuBar() throws Exception {
		// origin - 03.12.2023, last edit - 22.07.2024
		JMenuBar menuBar = new JMenuBar();
		EventQueue.invokeLater(() -> {
			try {

				LinkedHashMap<String, String> menuOrder = new LinkedHashMap<String, String>();
				menuOrder = getMenuOrder(GUI.basicMenuTitle);
//				for (var entry : GUI.basicMenuTitle.entrySet()) {
//					String key = entry.getKey();
//					String value = entry.getValue();
//					if (Etc.strContains(key, GUI.strMenuMark)) {
//						menuOrder.put(key, value);
//					}
//				}

				for (var entry : menuOrder.entrySet()) {
					String initStrMenu = entry.getKey();
//					JMenu currMenu = GUI.getMenu(GUI.setMenuTitle(initStrMenu));
//					GUI.addMenu(currMenu, getPatternMenuItem(initStrMenu));
//					menuBar.add(currMenu);
					GUI.addMenu2(menuBar, initStrMenu);
				}
			} catch (Exception ex) {
				WB.addLog("GUI.getBasicMenuBar, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
			} finally {
				Etc.doNothing();
			}
		});
		return menuBar;
	}

	private static LinkedHashMap<String, String> getMenuOrder(LinkedHashMap<String, String> listMenutitle)
			throws Exception {
		// origin - 22.07.2024, last edit - 22.07.2024
		LinkedHashMap<String, String> res = new LinkedHashMap<String, String>();
		try {
			for (var entry : listMenutitle.entrySet()) {
				String key = entry.getKey();
				String value = entry.getValue();
				if (Etc.strContains(key, GUI.strMenuMark)) {
					res.put(key, value);
				}
			}
		} catch (Exception ex) {
			WB.addLog("GUI.test, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("GUI.getMenuOrder, res.size=" + res.size(), WB.strEmpty, "GUI");
		return res;
	}

	public static void test() throws Exception {
		// origin - 03.12.2023, last edit - 06.07.2024
		try {

		} catch (Exception ex) {
			WB.addLog("GUI.test, ex=" + ex.getMessage(), WB.strEmpty, "GUI");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("GUI.test end ", WB.strEmpty, "GUI");
	}
}