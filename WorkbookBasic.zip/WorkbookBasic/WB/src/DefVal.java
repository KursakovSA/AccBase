import java.time.LocalDate;
import java.util.TreeSet;

public class DefVal {
	// origin - 23.08.2024, last edit - 11.09.2024

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("DefVal.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "DefVal");
		} finally {
			Etc.doNothing();
		}
	}

	public static int setOutside(int val, int defaultVal) throws Exception {
		// origin - 11.09.2024, last edit - 11.09.2024
		int res = val;
		try {
			if (val > 0) {
				if (defaultVal > 0) {
					if (val > defaultVal) {
						res = defaultVal;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("DefVal.setOutside(int, int), ex=" + ex.getMessage(), WB.strEmpty, "DefVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DefVal.setOutside(int, int), res=" + res, WB.strEmpty, "DefVal");
		return res;
	}

	public static int setCustom(int val, int customVal) throws Exception {
		// origin - 31.08.2024, last edit - 31.08.2024
		int res = val;
		try {
			if (customVal != 0) {
				res = customVal;
			}
		} catch (Exception ex) {
			WB.addLog("DefVal.setCustom(int, int), ex=" + ex.getMessage(), WB.strEmpty, "DefVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DefVal.setCustom(int, int), res=" + res, WB.strEmpty, "DefVal");
		return res;
	}

	public static String setCustom(String val, String customVal) throws Exception {
		// origin - 31.08.2024, last edit - 31.08.2024
		String res = val;
		try {
			if (customVal.isEmpty() == false) {
				res = customVal;
			}
		} catch (Exception ex) {
			WB.addLog("DefVal.setCustomVal(string, string), ex=" + ex.getMessage(), WB.strEmpty, "DefVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DefVal.setCustom(string, string), res=" + res, WB.strEmpty,
		// "DefVal");
		return res;
	}

	public static LocalDate set(LocalDate val, LocalDate defaultVal) throws Exception {
		// origin - 26.08.2024, last edit - 29.08.2024
		LocalDate res = val;
		try {
			if (res == null) {
				res = defaultVal;
			}
		} catch (Exception ex) {
			WB.addLog("DefVal.set, ex=" + ex.getMessage(), WB.strEmpty, "DefVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DefVal.set(val, LocalDate), res=" + res, WB.strEmpty, "DefVal");
		return res;
	}

	public static String set(String val, int defaultStringLenght) throws Exception {// cut off string on the right what
																					// hit to
		// norm lenght
		// origin - 26.08.2024, last edit - 29.08.2024
		String res = Etc.fixTrim(val);
		try {
			if (res.length() > defaultStringLenght) {
				res = res.substring(res.length() - defaultStringLenght);
			}
		} catch (Exception ex) {
			WB.addLog("DefVal.set, ex=" + ex.getMessage(), WB.strEmpty, "DefVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DefVal.set(val, int), res=" + res, WB.strEmpty, "DefVal");
		return res;
	}

	public static TreeSet<String> set(TreeSet<String> val, TreeSet<String> defaultVal) throws Exception {
		// origin - 22.08.2024, last edit - 29.08.2024
		TreeSet<String> res = val;
		try {
			if (res.size() == 0) {// difference
				res = defaultVal;
			}
		} catch (Exception ex) {
			WB.addLog("DefVal.set, ex=" + ex.getMessage(), WB.strEmpty, "DefVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DefVal.set, res=" + res, WB.strEmpty, "DefVal");
		return res;
	}

	public static int set(int val, int defaultVal) throws Exception {
		// origin - 16.08.2024, last edit - 29.08.2024
		int res = val;
		try {
			if (res == 0) {// difference
				res = defaultVal;
			}
		} catch (Exception ex) {
			WB.addLog("DefVal.set, ex=" + ex.getMessage(), WB.strEmpty, "DefVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DefVal.set, res=" + res, WB.strEmpty, "DefVal");
		return res;
	}

	public static String set(String val, String defaultVal) throws Exception {
		// origin - 14.08.2024, last edit - 29.08.2024
		String res = Etc.fixTrim(val);
		try {
			if (res.isEmpty()) {// difference
				res = defaultVal;
			}
		} catch (Exception ex) {
			WB.addLog("DefVal.set, ex=" + ex.getMessage(), WB.strEmpty, "DefVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DefVal.set, res=" + res, WB.strEmpty, "DefVal");
		return res;
	}

	public static double set(double fixNumb) throws Exception {
		// origin - 01.10.2023, last edit - 29.08.2024
		// for tax calculate and etc where not need be negative number
		double res = (double) fixNumb;
		try {
			res = res < 0 ? 0 : res; // set 0, if < 0
		} catch (Exception ex) {
			WB.addLog("DefVal.set, ex=" + ex.getMessage(), WB.strEmpty, "DefVal");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public DefVal() throws Exception {
		// origin - 23.08.2024, last edit - 29.08.2024
	}

	public static void test() throws Exception {
		// origin - 23.08.2024, last edit - 16.09.2024
		try {

//			// set(string, int)
//			for (String testArg1 : new String[] { "te", "tes", "test", "test22" }) {
//				WB.addLog2("DefVal.test.set(string, int), res=" + DefVal.set(testArg1, 3) + ", testArg1=" + testArg1
//						+ ", int=3", WB.strEmpty, "DefVal");
//			}

		} catch (Exception ex) {
			WB.addLog("DefVal.test, ex=" + ex.getMessage(), WB.strEmpty, "DefVal");
		} finally {
			Etc.doNothing();
		}
		//WB.addLog2("DefVal.test end ", WB.strEmpty, "DefVal");
	}
}
