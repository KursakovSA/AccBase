import java.time.LocalDate;
import java.util.TreeSet;

public class DefVal {
	// origin - 23.08.2024, last edit - 04.03.2025

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("DefVal.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "DefVal");
		}
	}

	public static int setOutside(int val, int defaultVal) throws Exception {
		// origin - 11.09.2024, last edit - 04.03.2025
		int res = val;
		try {
			if ((val > 0) & (defaultVal > 0) & (val > defaultVal)) {
				res = defaultVal;
			}
		} catch (Exception ex) {
			WB.addLog("DefVal.setOutside(int, int), ex=" + ex.getMessage(), WB.strEmpty, "DefVal");
		}
		return res;
	}

	public static int setCustom(int val, int customVal) throws Exception {
		// origin - 31.08.2024, last edit - 04.03.2025
		int res = val;
		try {
			if (customVal != 0) {
				res = customVal;
			}
		} catch (Exception ex) {
			WB.addLog("DefVal.setCustom(int, int), ex=" + ex.getMessage(), WB.strEmpty, "DefVal");
		}
		return res;
	}

//	public static UnitVal setCustom(UnitVal val, UnitVal customVal) throws Exception {
//		// origin - 31.12.2024, last edit - 04.03.2025
//		UnitVal res = val;
//		try {
//
//			if ((val.id.isEmpty()) & (customVal.id.isEmpty() == false)) {
//				res = customVal;
//			}
//
//			if ((val.id.isEmpty() == false) & (customVal.id.isEmpty())) {
//				res = val;
//			}
//
//			if ((val.id.isEmpty() == false) & (customVal.id.isEmpty() == false)) {
//				res = customVal;
//			}
//
//		} catch (Exception ex) {
//			WB.addLog("DefVal.setCustomVal(unitval, unitval), ex=" + ex.getMessage(), WB.strEmpty, "DefVal");
//		}
//		return res;
//	}

//	public static RangeVal setCustom(RangeVal val, RangeVal customVal) throws Exception {
//		// origin - 31.12.2024, last edit - 04.03.2025
//		RangeVal res = val;
//		try {
//
//			if ((val.id.isEmpty()) & (customVal.id.isEmpty() == false)) {
//				res = customVal;
//			}
//
//			if ((val.id.isEmpty() == false) & (customVal.id.isEmpty())) {
//				res = val;
//			}
//
//			if ((val.id.isEmpty() == false) & (customVal.id.isEmpty() == false)) {
//				res = customVal;
//			}
//
//		} catch (Exception ex) {
//			WB.addLog("DefVal.setCustomVal(rangeval, rangeval), ex=" + ex.getMessage(), WB.strEmpty, "DefVal");
//		} 
//		return res;
//	}

	public static String setCustom(String val, String customVal) throws Exception {
		// origin - 31.08.2024, last edit - 04.03.2025
		val = Etc.fixTrim(val);
		String res = val;
		customVal = Etc.fixTrim(customVal);
		try {

			if ((val.isEmpty()) & (customVal.isEmpty() == false)) {
				res = customVal;
			}

			if ((val.isEmpty() == false) & (customVal.isEmpty())) {
				res = val;
			}

			if ((val.isEmpty() == false) & (customVal.isEmpty() == false)) {
				res = customVal;
			}

		} catch (Exception ex) {
			WB.addLog("DefVal.setCustomVal(string, string), ex=" + ex.getMessage(), WB.strEmpty, "DefVal");
		}
		return res;
	}

	public static LocalDate set(LocalDate val, LocalDate defaultVal) throws Exception {
		// origin - 26.08.2024, last edit - 04.03.2025
		LocalDate res = val;
		try {
			if (res == null) {
				res = defaultVal;
			}
		} catch (Exception ex) {
			WB.addLog("DefVal.set, ex=" + ex.getMessage(), WB.strEmpty, "DefVal");
		}
		return res;
	}

	public static String set(String val, int defaultStringLenght) throws Exception {// cut off string on the right what
																					// hit to
		// norm lenght
		// origin - 26.08.2024, last edit - 04.03.2025
		String res = Etc.fixTrim(val);
		try {
			if (res.length() > defaultStringLenght) {
				res = res.substring(res.length() - defaultStringLenght);
			}
		} catch (Exception ex) {
			WB.addLog("DefVal.set, ex=" + ex.getMessage(), WB.strEmpty, "DefVal");
		}
		return res;
	}

	public static TreeSet<String> set(TreeSet<String> val, TreeSet<String> defaultVal) throws Exception {
		// origin - 22.08.2024, last edit - 04.03.2025
		TreeSet<String> res = val;
		try {
			if (res.size() == 0) {// difference
				res = defaultVal;
			}
		} catch (Exception ex) {
			WB.addLog("DefVal.set, ex=" + ex.getMessage(), WB.strEmpty, "DefVal");
		}
		return res;
	}

	public static int set(int val, int defaultVal) throws Exception {
		// origin - 16.08.2024, last edit - 04.03.2025
		int res = val;
		try {
			if (res == 0) {// difference
				res = defaultVal;
			}
		} catch (Exception ex) {
			WB.addLog("DefVal.set, ex=" + ex.getMessage(), WB.strEmpty, "DefVal");
		}
		return res;
	}

	public static String set(String val, String defaultVal) throws Exception {
		// origin - 14.08.2024, last edit - 04.03.2025
		String res = Etc.fixTrim(val);
		try {
			if (res.isEmpty()) {// difference
				res = defaultVal;
			}
		} catch (Exception ex) {
			WB.addLog("DefVal.set, ex=" + ex.getMessage(), WB.strEmpty, "DefVal");
		}
		return res;
	}

	public static double set(double fixNumb) throws Exception {
		// origin - 01.10.2023, last edit - 04.03.2025
		// for tax calculate and etc where not need be negative number
		double res = (double) fixNumb;
		try {
			res = res < 0 ? 0 : res; // set 0, if < 0
		} catch (Exception ex) {
			WB.addLog("DefVal.set, ex=" + ex.getMessage(), WB.strEmpty, "DefVal");
		}
		return res;
	}

	private DefVal() throws Exception {
		// origin - 23.08.2024, last edit - 04.11.2024
	}

	public static void test() throws Exception {
		// origin - 23.08.2024, last edit - 04.03.2025
		try {

//			// set(string, int)
//			for (String testArg1 : new String[] { "te", "tes", "test", "test22" }) {
//				WB.addLog2("DefVal.test.set(string, int), res=" + DefVal.set(testArg1, 3) + ", testArg1=" + testArg1
//						+ ", int=3", WB.strEmpty, "DefVal");
//			}

		} catch (Exception ex) {
			WB.addLog("DefVal.test, ex=" + ex.getMessage(), WB.strEmpty, "DefVal");
		}
	}
}