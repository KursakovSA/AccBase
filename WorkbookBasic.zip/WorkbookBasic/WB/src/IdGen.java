import java.awt.Desktop;
import java.io.File;
import java.util.List;

@SuppressWarnings("unused")
public class IdGen {
	// origin - 14.08.2024, last edit - 19.03.2025
	public String idKind = ""; // ex. "EmpId", "FaceId", "AssetId", etc.
	public String id = "";
	public String idRaw = ""; // TOTHINK, ex. "EmpId=004" -- this is idRaw, what "004" - this is id

	public String department = ""; // ex. "Adm1", "Store1", "GenDir1", etc.
	public String database = ""; // ex. "IB1", "P1", etc.
	public String store = "";
	public String table = "";

	public String context = "";
//	idGrowingDigitalGlobal = ex. 1, 45, 67443, 0006, 000345, etc.
//	idCommonCompositeRandom = ex. [CB1][2024-08-28T07:44:51][#12684]
//	idStringGrowingDigitalGlobal = ex. 005, 000345, 000234, etc.
//	idIntegerGrowingDigitalGlobal = ex. 45, 87, 46565, etc.
//	idStringGrowingDigitalInfobase = ex. [IB1]00005, etc.

	public String partNumberLeftPlaceholder = "";
	public int partNumberStep;
	public int partNumberStart;
	public int partNumberLenght;

	public String partDatabase = "";
	public String partStore = "";
	public String partDepartment = "";
	public String partDatetime = "";
	public String partNumber = "";
	public String partNumberOuter = "";

	public IdGen.Tuner custom = new IdGen.Tuner();
	public IdGen.Tuner actual = new IdGen.Tuner();

	public static int defaultNumberStep;
	public static int defaultNumberStart;
	public static int defaultPartNumberLenght;
	public static String defaultLeftPlaceholder = "";

	static {
		try {
			IdGen.defaultNumberStep = 1;
			IdGen.defaultNumberStart = 0;
			IdGen.defaultPartNumberLenght = 5;
			IdGen.defaultLeftPlaceholder = "0";
		} catch (Exception ex) {
			WB.addLog("IdGen.static ctor, ex=" + ex.getMessage(), "", "IdGen");
		}
	}

	// inner class Tuner for outer class IdGen
	private class Tuner {// for tuning outer IdGen
		// origin - 30.08.2024, last edit - 19.03.2025
		private String idKind = "";
		private String context2 = "";
		private int partNumberLenght2 = 0;
		private int partNumberStep2 = 0;
		private int partNumberStart2 = 0;
		private String partNumberLeftPlaceholder2 = "";
		private String partNumber2 = ""; // for outer partNumber, ex. article asset
		private String id = "";

		private Tuner() throws Exception {
			// origin - 31.08.2024, last edit - 31.08.2024
		}

		private Tuner(String IdKind, String Context) throws Exception {
			// origin - 30.08.2024, last edit - 20.03.2025
			this.idKind = IdKind;
			this.context2 = Context;

			if (this.idKind.isEmpty() == false) {// find local idgen only if idkind not empty

				switch (Context.toLowerCase()) {

				case "custom":
					Abc abcLocal = WB.abcLocal;
					// filter
					var filteredIdGen1 = ReadSet.getEqualsByDescription(abcLocal.idGen, IdKind);
					var filteredIdGen2 = ReadSet.getEqualsByDescription(filteredIdGen1, Context);
					// custom
					this.partNumberLenght2 = Conv.getInt(
							ReadSet.getMeterValueByContainsDescription(filteredIdGen2, "partNumberLenght.Custom"));
					this.partNumberStep2 = Conv.getInt(
							ReadSet.getMeterValueByContainsDescription(filteredIdGen2, "partNumberStep.Custom"));
					this.partNumberStart2 = Conv.getInt(
							ReadSet.getMeterValueByContainsDescription(filteredIdGen2, "partNumberStart.Custom"));
					this.partNumberLeftPlaceholder2 = ReadSet.getMeterValueByContainsDescription(filteredIdGen2,
							"partNumberLeftplaceholder.Custom");
					break;

				default:
					Etc.doNothing();
					break;
				}
			}
			// WB.addLog2("IdGen.Tuner(idKind, Context), res="
			// +this.toString(),"","IdGen.Tuner");
		}

		public String toString() {
			// origin - 19.09.2024, last edit - 20.03.2025
			String res = "";
			try {
				res = Fmtr.reflect(this);
				res = "{" + res + "}";
			} catch (Exception ex) {
			}
			return res;
		}
	}

	private void getTable() throws Exception {
		// origin - 17.08.2024, last edit - 19.03.2025
		// res = this.table;
		try {
			this.table = switch (this.idKind) { // ?? add what more??
			case "EmpId", "FaceId" -> "Face";
			case "AssetId" -> "Asset";
			case "DealId, PawnId" -> "Deal";
			case "InfoId" -> "Info";
			default -> "Info";
			};

			this.table = DefVal.set(this.table, "Info");// because table "Info" always short
		} catch (Exception ex) {
			WB.addLog2("IdGen.getTable, ex=" + ex.getMessage(), "", "IdGen");
		}
	}

	private void getPart() throws Exception {
		// origin - 15.08.2024, last edit - 20.03.2025
		try {
			this.partDatabase = this.database;
			this.partDepartment = this.department;
			this.partStore = this.store;
			this.partDatetime = String.valueOf(DateTool.formatter2(DateTool.getNow2()));

			switch (this.context) {
			case "idIntegerGrowingDigitalGlobal", "idStringGrowingDigitalGlobal", "idStringGrowingDigitalInfobase":
				var tmp = DAL.getByTemplate(WB.lastConnWork, Qry.getMoreFilter(this.idKind), this.table);

//			String strNumb = ModelDto.getMaxValueFromMoreById(tmp, this.idKind, this.partNumberLenght,
//						this.partNumberLeftPlaceholder);

//				String strNumb = ModelDto.getMaxValueFromMoreById(tmp, this.idKind, this.partNumberLenght,
//						this.partNumberLeftPlaceholder).idActualPartNumber;
//				this.actual.id = ModelDto.getMaxValueFromMoreById(tmp, this.idKind, this.partNumberLenght,
//						this.partNumberLeftPlaceholder).idActual;
//				WB.addLog2("IdGen.getPart, this.actual.id=" + this.actual.id + ", idKind=" + this.idKind, "","IdGen");

				// this.actual.partNumber2 = strNumb;
//				WB.addLog2(
//						"IdGen.getPart, this.actual.partNumber2=" + this.actual.partNumber2 + ", idKind=" + this.idKind,
//						"", "IdGen");

				this.getMaxValueFromMoreById(tmp);
				String strNumb = this.actual.partNumber2;
				strNumb = DefVal.set(strNumb, String.valueOf(this.partNumberStart));
				int numb = Integer.parseInt(strNumb);
				numb = numb + this.partNumberStep;
				this.partNumber = Etc.addLeaderPlaceholder(String.valueOf(numb), this.partNumberLenght,
						this.partNumberLeftPlaceholder);
				// WB.addLog2("IdGen.getPart, this.partNumber=" + this.partNumber, "","IdGen");
				break;

			case "idCommonCompositeRandom":
				this.partNumber = "#" + Etc.getIntRnd(Etc.initRndDefault);
				break;

			default:
				// Etc.doNothing();
				this.partNumber = "#" + Etc.getIntRnd(Etc.initRndDefault);
				break;
			}

		} catch (Exception ex) {
			WB.addLog("IdGen.getPart, ex=" + ex.getMessage(), "", "IdGen");
		}
	}

	public IdGen(String IdKind, String Context, ModelDto obj) throws Exception {// TOTHINK
		// origin - 02.09.2024, last edit - 02.09.2024
		this(IdKind, Context);
		// this is ctor what need info about outer obj
	}

	public IdGen(String IdKind, String Context) throws Exception {
		// origin - 18.08.2024, last edit - 21.03.2025
		this(IdKind);
		this.context = Context;

		// tuning difference standard
		switch (Context) {
		case "idIntegerGrowingDigitalGlobal":
			this.partNumberLeftPlaceholder = " ";
			break;

		default:
			Etc.doNothing();
		}

		this.getTable();
		this.database = MoreVal.getByKey(WB.abcLast.infoBaseId, "infoBaseId", "Face.FA1");
		this.database = DefVal.set(this.database, Conn.defaultInfoBaseId); // TOTHINK
		// ModelDto.getValueField(WB.abcLast.infoBaseId, "infoBaseId", "Face.FA1",
		// ModelDto.defaultInfoBaseId); // ???magic string ???
		this.department = this.store = "";
		this.partDatabase = this.partStore = this.partDepartment = this.partDatetime = this.partNumber = "";
		this.getPart();
		this.getNew();
	}

	public IdGen(String IdKind) throws Exception {
		// origin - 14.08.2024, last edit - 20.03.2025
		this();
		this.idKind = IdKind;

		// customization
		this.custom = new Tuner(this.idKind, "custom");
		// WB.addLog2("IdGen.ctor.custom=" + this.custom.toString(), "", "IdGen");
		this.partNumberLenght = DefVal.setCustom(this.partNumberLenght, this.custom.partNumberLenght2); // 1 custom
		this.partNumberStep = DefVal.setCustom(this.partNumberStep, this.custom.partNumberStep2); // 2 custom
		this.partNumberStart = DefVal.setCustom(this.partNumberStart, this.custom.partNumberStart2); // 3 custom
		this.partNumberLeftPlaceholder = DefVal.setCustom(this.partNumberLeftPlaceholder,
				this.custom.partNumberLeftPlaceholder2); // 4 custom

		// actualization
		this.actual = new Tuner(this.idKind, "actual");
	}

	public IdGen() throws Exception {
		// origin - 31.08.2024, last edit - 05.11.2024
		this.partNumberLeftPlaceholder = IdGen.defaultLeftPlaceholder;
		this.partNumberStep = IdGen.defaultNumberStep;
		this.partNumberStart = IdGen.defaultNumberStart;
		this.partNumberLenght = IdGen.defaultPartNumberLenght;
	}

	public void getNew() throws Exception {
		// origin - 19.08.2024, last edit - 20.03.2025
		String res = "";

		try {
			switch (this.context) {
			case "idStringGrowingDigitalInfobase":
				res = res + "[" + this.partDatabase + "]";
				res = res + this.partNumber;
				break;

			case "idIntegerGrowingDigitalGlobal":
				res = res + this.partNumber;
				res = Etc.delStr(res, "[");
				res = Etc.delStr(res, "]");
				res = Etc.delStr(res, "#");
				break;

			case "idStringGrowingDigitalGlobal": // ?? "idGrowingDigitalGlobal" ??
				res = res + this.partNumber;
				res = Etc.delStr(res, "[");
				res = Etc.delStr(res, "]");
				res = Etc.delStr(res, "#");
				break;

			case "idCommonCompositeRandom", "":
				res = res + "[" + this.partDatabase + "]";
				res = Fmtr.id(res, this.partDepartment);
				res = Fmtr.id(res, this.partStore);
				res = res + "[" + this.partDatetime + "]";
				res = res + "[" + this.partNumber + "]";
				break;

			default: // "idCommonCompositeRandom"
				res = res + "[" + this.partDatabase + "]";
				res = Fmtr.id(res, this.partDepartment);
				res = Fmtr.id(res, this.partStore);
				res = res + "[" + this.partDatetime + "]";
				res = res + "[" + this.partNumber + "]";
				break;
			}
			this.id = res; // this is res
		} catch (Exception ex) {
			WB.addLog2("IdGen.getNew, ex=" + ex.getMessage(), "", "IdGen");
		}
	}

	public String toString() {
		// origin - 14.08.2024, last edit - 20.03.2025
		String res = "";
		try {
			res = Fmtr.reflect(this);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	private void getMaxValueFromMoreById(List<ModelDto> dto) throws Exception {
		// origin - 13.08.2024, last edit - 21.03.2025
		String resIdActual = "";
		String currIdActual = "";
		String resIdActualPartNumber = "";

		try {
			String[] items = {};
			String splitValueInMore = ";";
			String currVal = "";
			int currMaxVal = 0;
			for (var currDto : dto) {

				// items = Etc.getArrayFromStrSplit(currDto.more, splitValueInMore); // if value
				// are diffferent in list ???
				items = currDto.more.split(splitValueInMore); // if value are diffferent in list ???
				currVal = MoreVal.getFromEquation(items, this.idKind);
				currIdActual = currVal;
				currVal = DefVal.set(currVal, this.partNumberLenght);// cut off string on the right what hit to norm
																		// lenght
				currVal = Etc.delLeaderPlaceholder(currVal, this.partNumberLeftPlaceholder);

				if ((Etc.isDigitAll(currVal)) && // ??
						(Integer.parseInt(currVal) != 0) && (currMaxVal < Integer.parseInt(currVal))) {
					currMaxVal = Integer.parseInt(currVal);
					// res = currVal;
					resIdActualPartNumber = currVal;
					resIdActual = currIdActual;
				}
			}
		} catch (Exception ex) {
			WB.addLog("IdGen.getMaxValueFromMoreById, ex=" + ex.getMessage(), "", "IdGen");
		}

		this.actual.partNumber2 = resIdActualPartNumber; // this is res1
		this.actual.id = resIdActual; // this is res2
	}

	public static void test() throws Exception {
		// origin - 14.08.2024, last edit - 19.03.2025
		try {

//			// ctor IdGen(Id, Code, Description)
//			IdGen newIdGen = new IdGen("EmpId", "idStringGrowingDigitalGlobal");
//			WB.addLog2("IdGen.test, ctor('EmpId', 'idStringGrowingDigitalGlobal')=" + newIdGen, "", "Info");

		} catch (Exception ex) {
			WB.addLog("IdGen.test, ex=" + ex.getMessage(), "", "IdGen");
		}
	}
}