import java.awt.Desktop;
import java.io.File;
import java.util.List;

@SuppressWarnings("unused")
public class IdGen {
	// origin - 14.08.2024, last edit - 03.09.2024
	public String idKind = new String(); // ex. "EmpId", "FaceId", "AssetId", etc.
	public String id = new String();
	public String idRaw = new String(); // TOTHINK, ex. "EmpId=004" -- this is idRaw, what "004" - this is id

	public String department = new String(); // ex. "Adm1", "Store1", "GenDir1", etc.
	public String database = new String(); // ex. "IB1", "P1", etc.
	public String store = new String();
	public String table = new String();

	public String context = new String();
//	idGrowingDigitalGlobal = ex. 1, 45, 67443, 0006, 000345, etc.
//	idCommonCompositeRandom = ex. [CB1][2024-08-28T07:44:51][#12684]
//	idStringGrowingDigitalGlobal = ex. 005, 000345, 000234, etc.
//	idIntegerGrowingDigitalGlobal = ex. 45, 87, 46565, etc.
//	idStringGrowingDigitalInfobase = ex. [IB1]00005, etc.

	public String partNumberLeftPlaceholder = new String();
	public int partNumberStep;
	public int partNumberStart;
	public int partNumberLenght;

	public String partDatabase = new String();
	public String partStore = new String();
	public String partDepartment = new String();
	public String partDatetime = new String();
	public String partNumber = new String();
	public String partNumberOuter = new String();

	public Tuner custom = new Tuner();
	public Tuner actual = new Tuner();

	public static int defaultNumberStep;
	public static int defaultNumberStart;
	public static int defaultPartNumberLenght;
	public static String defaultLeftPlaceholder;

	static {
		try {
			IdGen.defaultNumberStep = 1; // ??magic string??
			IdGen.defaultNumberStart = 0; // ??magic string??
			IdGen.defaultPartNumberLenght = 5; // ??magic string??
			IdGen.defaultLeftPlaceholder = "0"; // ??magic string??
		} catch (Exception ex) {
			WB.addLog("IdGen.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "IdGen");
		} finally {
			Etc.doNothing();
		}
	}

	// inner class Tuner for outer class IdGen
	public class Tuner {// for tuning outer IdGen
		// origin - 30.08.2024, last edit - 03.09.2024
		public String idKind = new String();
		public String context2 = new String();
		public int partNumberLenght2 = 0;
		public int partNumberStep2 = 0;
		public int partNumberStart2 = 0;
		public String partNumberLeftPlaceholder2 = WB.strEmpty;
		public String partNumber2 = WB.strEmpty; // for outer partNumber, ex. article asset
		public String id = new String();

		private Tuner() throws Exception {
			// origin - 31.08.2024, last edit - 31.08.2024
		}

		private Tuner(String IdKind, String Context) throws Exception {
			// origin - 30.08.2024, last edit - 03.09.2024
			this.idKind = IdKind;
			this.context2 = Context;

			if (this.idKind.isEmpty() == false) {// find local idgen only if idkind not empty

				switch (Context) {

				case "custom":
					Abc abcLocal = WB.abcLocal;
					// filter
					var filteredIdGen1 = ModelDto.getSubsetByDescription(abcLocal.idGen, IdKind);
					var filteredIdGen2 = ModelDto.getSubsetByDescription(filteredIdGen1, Context);
					// custom
//					this.partNumberLenght2 = Abc.getMeterValueByDescription(filteredIdGen2, "partNumberLenght.Custom");
//					this.partNumberStep2 = Abc.getMeterValueByDescription(filteredIdGen2, "partNumberStep.Custom");
//					this.partNumberStart2 = Abc.getMeterValueByDescription(filteredIdGen2, "partNumberStart.Custom");
//					this.partNumberLeftPlaceholder2 = Abc.getMeterValueByDescription2(filteredIdGen2,
//							"partNumberLeftplaceholder.Custom");
					this.partNumberLenght2 = Conv
							.getInt(Abc.getMeterValueByDescription(filteredIdGen2, "partNumberLenght.Custom"));
					this.partNumberStep2 = Conv
							.getInt(Abc.getMeterValueByDescription(filteredIdGen2, "partNumberStep.Custom"));
					this.partNumberStart2 = Conv
							.getInt(Abc.getMeterValueByDescription(filteredIdGen2, "partNumberStart.Custom"));
					this.partNumberLeftPlaceholder2 = Abc.getMeterValueByDescription(filteredIdGen2,
							"partNumberLeftplaceholder.Custom");
					break;

				default:
					Etc.doNothing();
					break;
				}
			}
			// WB.addLog2("IdGen.Tuner(idKind, Context), res=" + this.toString(),
			// WB.strEmpty, "IdGen.Tuner");
		}

//		public String toString() {
//			// origin - 31.08.2024, last edit - 02.09.2024
//			String res = WB.strEmpty;
//			try {
//				res = Formatter.reflect(this);
//				res = WB.strBraceLeft + res + WB.strBraceRight;
//			} catch (Exception ex) {
//				// WB.addLog2("IdGen.Tuner.toString, ex=" + ex.getMessage(), WB.strEmpty,
//				// "IdGen.Tuner");
//			} finally {
//				Etc.doNothing();
//			}
//			return res;
//		}

	}

	private void getTable() throws Exception {
		// origin - 17.08.2024, last edit - 01.09.2024
		// res = this.table;
		try {
			this.table = switch (this.idKind) { // ?? add what more??
			case "EmpId", "FaceId" -> "Face";
			case "AssetId" -> "Asset";
			case "DealId, PawnId" -> "Deal";
			case "InfoId" -> "Info";
			default -> "Info";
			};

			this.table = DefVal.set(this.table, "Info");// because table "Info" always short
		} catch (Exception ex) {
			WB.addLog2("IdGen.getTable, ex=" + ex.getMessage(), WB.strEmpty, "IdGen");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("IdGen.getTable, this.table=" + this.table + ", this.idKind=" +
		// this.idKind, WB.strEmpty,
		// "IdGen");
	}

	private void getPart() throws Exception {
		// origin - 15.08.2024, last edit - 02.09.2024
		try {
			this.partDatabase = this.database;
			this.partDepartment = this.department;
			this.partStore = this.store;
			this.partDatetime = String.valueOf(DateTool.formatter2(DateTool.getNow2()));

			switch (this.context) {
			case "idIntegerGrowingDigitalGlobal", "idStringGrowingDigitalGlobal", "idStringGrowingDigitalInfobase":
				var tmp = DAL.getByTemplate(WB.lastConnWork, Qry.getMoreFilter(this.idKind), this.table);

//			String strNumb = ModelDto.getMaxValueFromMoreById(tmp, this.idKind, this.partNumberLenght,
//						this.partNumberLeftPlaceholder);

//				String strNumb = ModelDto.getMaxValueFromMoreById(tmp, this.idKind, this.partNumberLenght,
//						this.partNumberLeftPlaceholder).idActualPartNumber;
//				this.actual.id = ModelDto.getMaxValueFromMoreById(tmp, this.idKind, this.partNumberLenght,
//						this.partNumberLeftPlaceholder).idActual;
//				WB.addLog2("IdGen.getPart, this.actual.id=" + this.actual.id + ", idKind=" + this.idKind, WB.strEmpty,
//						"IdGen");

				// this.actual.partNumber2 = strNumb;
//				WB.addLog2(
//						"IdGen.getPart, this.actual.partNumber2=" + this.actual.partNumber2 + ", idKind=" + this.idKind,
//						WB.strEmpty, "IdGen");

				this.getMaxValueFromMoreById(tmp);
				String strNumb = this.actual.partNumber2;
				strNumb = DefVal.set(strNumb, String.valueOf(this.partNumberStart));
				int numb = Integer.parseInt(strNumb);
				numb = numb + this.partNumberStep;
				this.partNumber = Etc.addLeaderPlaceholder(String.valueOf(numb), this.partNumberLenght,
						this.partNumberLeftPlaceholder);
				// WB.addLog2("IdGen.getPart, this.partNumber=" + this.partNumber, WB.strEmpty,
				// "IdGen");
				break;

			case "idCommonCompositeRandom":
				this.partNumber = WB.strSharp + Etc.getIntRnd(Etc.initRndDefault);
				break;

			default:
				// Etc.doNothing();
				this.partNumber = WB.strSharp + Etc.getIntRnd(Etc.initRndDefault);
				break;
			}

		} catch (Exception ex) {
			WB.addLog("IdGen.getPart, ex=" + ex.getMessage(), WB.strEmpty, "IdGen");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("IdGen.getPart, this.toString()=" + this.toString(), WB.strEmpty,
		// "IdGen");
	}

	public IdGen(String IdKind, String Context, ModelDto obj) throws Exception {// TOTHINK
		// origin - 02.09.2024, last edit - 02.09.2024
		this(IdKind, Context);
		// this is ctor what need info about outer obj
	}

	public IdGen(String IdKind, String Context) throws Exception {
		// origin - 18.08.2024, last edit - 02.09.2024
		this(IdKind);
		this.context = Context;

		// tuning difference standard
		switch (Context) {
		case "idIntegerGrowingDigitalGlobal":
			this.partNumberLeftPlaceholder = WB.strSpace;
			break;

		default:
			Etc.doNothing();
		}

		this.getTable();
		this.database = ModelDto.getValueField(WB.abcLast.infoBaseId, "infoBaseId", "Face.FA1",
				ModelDto.defaultInfoBaseId); // ???magic string ???
		this.department = this.store = WB.strEmpty;
		this.partDatabase = this.partStore = this.partDepartment = this.partDatetime = this.partNumber = WB.strEmpty;
		this.getPart();
		this.getNew();
	}

	public IdGen(String IdKind) throws Exception {
		// origin - 14.08.2024, last edit - 01.09.2024
		this();
		this.idKind = IdKind;

		// customization
		this.custom = new Tuner(this.idKind, "custom");
		// WB.addLog2("IdGen.ctor.custom=" + this.custom.toString(), WB.strEmpty,
		// "IdGen");
		this.partNumberLenght = DefVal.setCustom(this.partNumberLenght, this.custom.partNumberLenght2); // 1 custom
		this.partNumberStep = DefVal.setCustom(this.partNumberStep, this.custom.partNumberStep2); // 2 custom
		this.partNumberStart = DefVal.setCustom(this.partNumberStart, this.custom.partNumberStart2); // 3 custom
		this.partNumberLeftPlaceholder = DefVal.setCustom(this.partNumberLeftPlaceholder,
				this.custom.partNumberLeftPlaceholder2); // 4 custom

		// actualization
		this.actual = new Tuner(this.idKind, "actual");
	}

	public IdGen() throws Exception {
		// origin - 31.08.2024, last edit - 31.08.2024
		this.partNumberLeftPlaceholder = IdGen.defaultLeftPlaceholder;
		this.partNumberStep = IdGen.defaultNumberStep;
		this.partNumberStart = IdGen.defaultNumberStart;
		this.partNumberLenght = IdGen.defaultPartNumberLenght;
	}

//	public void getNew() throws Exception {
//		// origin - 21.08.2024, last edit - 02.09.2024
//		String res = WB.strEmpty;
//		try {
//			//res = IdGen.getNew("", "idCommonCompositeRandom");
//			res = new IdGen("", "idCommonCompositeRandom").id;
//		} catch (Exception ex) {
//			WB.addLog2("IdGen.getNew(), ex=" + ex.getMessage(), WB.strEmpty, "IdGen");
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("IdGen.getNew(), res=" + res, WB.strEmpty, "IdGen");
//		//return res;
//	}

	public void getNew() throws Exception {
		// origin - 19.08.2024, last edit - 02.09.2024
		String res = WB.strEmpty;

		try {
			switch (this.context) {
			case "idStringGrowingDigitalInfobase":
				res = res + WB.strSquareBracketLeft + this.partDatabase + WB.strSquareBracketRight;
				res = res + this.partNumber;
				break;

			case "idIntegerGrowingDigitalGlobal":
				res = res + this.partNumber;
				res = Etc.delStr(res, WB.strSquareBracketLeft);
				res = Etc.delStr(res, WB.strSquareBracketRight);
				res = Etc.delStr(res, WB.strSharp);
				break;

			case "idStringGrowingDigitalGlobal": // ?? "idGrowingDigitalGlobal" ??
				res = res + this.partNumber;
				res = Etc.delStr(res, WB.strSquareBracketLeft);
				res = Etc.delStr(res, WB.strSquareBracketRight);
				res = Etc.delStr(res, WB.strSharp);
				break;

			case "idCommonCompositeRandom", "":
				res = res + WB.strSquareBracketLeft + this.partDatabase + WB.strSquareBracketRight;
				res = Formatter.id(res, this.partDepartment);
				res = Formatter.id(res, this.partStore);
				res = res + WB.strSquareBracketLeft + this.partDatetime + WB.strSquareBracketRight;
				res = res + WB.strSquareBracketLeft + this.partNumber + WB.strSquareBracketRight;
				break;

			default: // "idCommonCompositeRandom"
				res = res + WB.strSquareBracketLeft + this.partDatabase + WB.strSquareBracketRight;
				res = Formatter.id(res, this.partDepartment);
				res = Formatter.id(res, this.partStore);
				res = res + WB.strSquareBracketLeft + this.partDatetime + WB.strSquareBracketRight;
				res = res + WB.strSquareBracketLeft + this.partNumber + WB.strSquareBracketRight;
				break;
			}
			this.id = res; // this is res
		} catch (Exception ex) {
			WB.addLog2("IdGen.getNew, ex=" + ex.getMessage(), WB.strEmpty, "IdGen");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("IdGen.getNew, this.id=" + this.id + ", ig.actual.id=" +
		// ig.actual.id, WB.strEmpty, "IdGen");
	}

//	public String toString() {
//		// origin - 14.08.2024, last edit - 02.09.2024
//		String res = WB.strEmpty;
//		try {
//			res = Formatter.reflect(this);
//			res = WB.strBraceLeft + res + WB.strBraceRight;
//		} catch (Exception ex) {
//			// WB.addLog2("IdGen.toString, ex=" + ex.getMessage(), WB.strEmpty, "IdGen");
//		} finally {
//			Etc.doNothing();
//		}
//		return res;
//	}

	private void getMaxValueFromMoreById(List<ModelDto> dto) throws Exception {
		// origin - 13.08.2024, last edit - 01.09.2024
		String resIdActual = WB.strEmpty;
		String currIdActual = WB.strEmpty;
		String resIdActualPartNumber = WB.strEmpty;

		try {
			String[] items = {};
			String splitValueInMore = WB.strSemiColon;
			String currVal = WB.strEmpty;
			int currMaxVal = 0;
			for (var currDto : dto) {

				items = Etc.getArrayFromStrSplit(currDto.more, splitValueInMore); // if value are diffferent in list ???
				currVal = ModelDto.getValueByKeyFromEquation(items, this.idKind);
				currIdActual = currVal;
				currVal = DefVal.set(currVal, this.partNumberLenght);// cut off string on the right what hit to norm
																		// lenght
				currVal = Etc.delLeaderPlaceholder(currVal, this.partNumberLeftPlaceholder);

				if (Etc.isDigitAll(currVal)) {// ??
					if (Integer.parseInt(currVal) != 0) {
						if (currMaxVal < Integer.parseInt(currVal)) {
							currMaxVal = Integer.parseInt(currVal);
							// res = currVal;
							resIdActualPartNumber = currVal;
							resIdActual = currIdActual;
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("IdGen.getMaxValueFromMoreById, ex=" + ex.getMessage(), WB.strEmpty, "IdGen");
		} finally {
			Etc.doNothing();
		}

		this.actual.partNumber2 = resIdActualPartNumber; // this is res1
		this.actual.id = resIdActual; // this is res2
//		WB.addLog2("IdGen.getMaxValueFromMoreById, this.actual.partNumber2=" + this.actual.partNumber2
//				+ ", this.actual.id=" + this.actual.id, WB.strEmpty, "IdGen");
	}

	public static void test() throws Exception {
		// origin - 14.08.2024, last edit - 01.09.2024
		try {

//			// ctor IdGen(Id, Code, Description)
//			IdGen newIdGen = new IdGen("EmpId", "idStringGrowingDigitalGlobal");
//			WB.addLog2("IdGen.test, ctor('EmpId', 'idStringGrowingDigitalGlobal')=" + newIdGen, WB.strEmpty, "Info");

		} catch (Exception ex) {
			WB.addLog("IdGen.test, ex=" + ex.getMessage(), WB.strEmpty, "IdGen");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("IdGen.test end ", WB.strEmpty, "IdGen");
	}
}