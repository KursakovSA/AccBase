import java.lang.reflect.Field;

public class IdGen {
	// origin - 14.08.2024, last edit - 21.08.2024
	private String id = new String(); // "EmpId", "FaceId", "AssetId", etc.
	private String department = new String(); // "Adm1", "Store1", "GenDir1", etc.
	private String database = new String(); // "IB1", "P1", etc.
	private String store = new String();
	private String table = new String();

	public Boolean idGrowingDigitalGlobal = false;
	public Boolean idCommonCompositeRandom = false;
	public Boolean idStringGrowingDigitalGlobal = false;
	public Boolean idIntegerGrowingDigitalGlobal = false;

	private String partNumberLeftPlaceholder = new String();
	private int partNumberStep;
	private int partNumberStart;
	private int partNumberLenght;

	private String partDatabase = new String();
	private String partStore = new String();
	private String partDepartment = new String();
	private String partDatetime = new String();
	private String partNumber = new String();
	private String partNumberLast = new String();

	private static int defaultNumberStep;
	private static int defaultNumberStart;
	private static int defaultPartNumberLenght;
	private static String defaultLeftPlaceholder;
	public static String context = new String();

	static {
		try {
			IdGen.defaultNumberStep = 1;
			IdGen.defaultNumberStart = 0;
			IdGen.defaultPartNumberLenght = 5; // ??magic string??
			IdGen.defaultLeftPlaceholder = "0"; // ??magic string??
		} catch (Exception ex) {
			WB.addLog("IdGen.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "IdGen");
		} finally {
			Etc.doNothing();
		}
	}

	private String getTable(String inId) throws Exception {
		// origin - 17.08.2024, last edit - 21.08.2024
		String res = WB.strEmpty;
		try {
			if (Etc.strContains("EmpId, FaceId", inId)) {
				res = "Face";
			}
			if (Etc.strContains("AssetId", inId)) {
				res = "Asset";
			}
			if (Etc.strContains("DealId, PawnId", inId)) {
				res = "Deal";
			}
			if (Etc.strContains("InfoId", inId)) {
				res = "Info";
			}
			res = Etc.setDefault(res, "Info");// because table "Info" always short
		} catch (Exception ex) {
			WB.addLog2("IdGen.getTable, ex=" + ex.getMessage(), WB.strEmpty, "IdGen");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("IdGen.getTable, res=" + res + ", inId=" + inId, WB.strEmpty,
		// "IdGen");
		return res;
	}

	private void getPart() throws Exception {
		// origin - 15.08.2024, last edit - 21.08.2024
		try {
			this.partDatabase = this.database;
			this.partDepartment = this.department;
			this.partStore = this.store;
			this.partDatetime = String.valueOf(DateTool.formatter2(DateTool.getNow2()));

			if (this.idGrowingDigitalGlobal) {
				var tmp = DAL.getByTemplate(WB.lastConnWork, Qry.getMoreFilter(this.id), this.table);
				String strNumb = ModelDto.getMaxValueFromMoreById(tmp, this.id);
				strNumb = Etc.setDefault(strNumb, String.valueOf(this.partNumberStart));
				this.partNumberLast = strNumb;
				int numb = Integer.parseInt(strNumb);
				numb = numb + this.partNumberStep;
				this.partNumber = Etc.addLeaderPlaceholder(String.valueOf(numb), this.partNumberLenght,
						this.partNumberLeftPlaceholder);
				// WB.addLog2("IdGen.getPart, this.partNumber=" + this.partNumber, WB.strEmpty,
				// "IdGen");

			} else if (this.idCommonCompositeRandom) {
				this.partNumber = WB.strSharp + Etc.getIntRnd(Etc.initRndDefault);
			}

		} catch (Exception ex) {
			WB.addLog("IdGen.getPart, ex=" + ex.getMessage(), WB.strEmpty, "IdGen");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("IdGen.getPart, this.toString()=" + this.toString(), WB.strEmpty,
		// "IdGen");
	}

	public IdGen(String Id, String Context) throws Exception {
		// origin - 18.08.2024, last edit - 21.08.2024
		this();
		if (Etc.strEquals(Context, "idIntegerGrowingDigitalGlobal")) {
			// this.leftPlaceholder = WB.strEmpty;
			this.partNumberLeftPlaceholder = WB.strSpace;
			this.idGrowingDigitalGlobal = true;
		}
		if (Etc.strEquals(Context, "idStringGrowingDigitalGlobal")) {
			this.idGrowingDigitalGlobal = true;
		}
		if (Etc.strEquals(Context, "idCommonCompositeRandom")) {
			this.idCommonCompositeRandom = true;
		}
		this.id = Id;
		this.table = this.getTable(Id);
		this.database = ModelDto.getValueField(WB.abcLast.infoBaseId, "infoBaseId", "Face.FA1",
				ModelDto.defaultInfoBaseId); // ???magic string ???
		this.department = this.store = WB.strEmpty;
		this.partDatabase = this.partStore = this.partDepartment = this.partDatetime = this.partNumber = WB.strEmpty;
		this.getPart();
	}

	public IdGen() throws Exception {
		// origin - 14.08.2024, last edit - 16.08.2024
		this.partNumberLeftPlaceholder = IdGen.defaultLeftPlaceholder;
		this.partNumberStep = IdGen.defaultNumberStep;
		this.partNumberStart = IdGen.defaultNumberStart;
		this.partNumberLenght = IdGen.defaultPartNumberLenght;
	}

	public static String getNew() throws Exception {
		// origin - 21.08.2024, last edit - 21.08.2024
		String res = WB.strEmpty;
		try {
			res = IdGen.getNew("ModelDto", "idCommonCompositeRandom");
		} catch (Exception ex) {
			WB.addLog2("IdGen.getNew, ex=" + ex.getMessage(), WB.strEmpty, "IdGen");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("IdGen.getNew, res=" + res, WB.strEmpty, "IdGen");
		return res;
	}

	public static String getNew(String id, String context) throws Exception {// getNew(IdGen ig)
		// origin - 19.08.2024, last edit - 21.08.2024
		String res = WB.strEmpty;
		try {
			IdGen ig = new IdGen(id, context);
			// WB.addLog2("IdGen.getNew, ig=" + ig + ", id=" + ", context=" + context + ",
			// partNumberLast=" + ig.partNumberLast, WB.strEmpty, "IdGen");
			if (ig.idGrowingDigitalGlobal) {
				res = res + ig.partNumber;
				res = Etc.delStr(res, WB.strSquareBracketLeft);
				res = Etc.delStr(res, WB.strSquareBracketRight);
				res = Etc.delStr(res, WB.strSharp);

			} else if (ig.idCommonCompositeRandom) {
				res = res + WB.strSquareBracketLeft + ig.partDatabase + WB.strSquareBracketRight;
				res = Etc.formatterAdd(res, ig.partDepartment);
				res = Etc.formatterAdd(res, ig.partStore);
				res = res + WB.strSquareBracketLeft + ig.partDatetime + WB.strSquareBracketRight;
				res = res + WB.strSquareBracketLeft + ig.partNumber + WB.strSquareBracketRight;
			}
		} catch (Exception ex) {
			WB.addLog2("IdGen.getNew, ex=" + ex.getMessage(), WB.strEmpty, "IdGen");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("IdGen.getNew, res=" + res, WB.strEmpty, "IdGen");
		return res;
	}

	private String reflect() throws Exception {
		// origin - 21.08.2024, last edit - 21.08.2024
		String res = WB.strEmpty;
		try {
			Field[] fields = this.getClass().getFields();// ModelDto.class.getFields();
			for (var currField : fields) {
				currField.setAccessible(true);
				// if (currField.get(this)) { ?? static skip ??
				String strFieldValue = currField.get(this).toString();
				if (strFieldValue.isEmpty() == false) {
					res = appender(res, Etc.formatterEquals(currField.getName(), strFieldValue));
				}
				// }
			}
		} catch (Exception ex) {
			WB.addLog2("IdGen.reflect, ex=" + ex.getMessage(), WB.strEmpty, "IdGen");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("IdGen.reflect, res=" + res, WB.strEmpty, "IdGen");
		return res;
	}

	public String toString() {
		// origin - 14.08.2024, last edit - 21.08.2024
		String res = WB.strEmpty;
		try {
			res = this.reflect();
//			res = appender(res, formatter("id", this.id));
//			res = appender(res, formatter("leftPlaceholder", this.leftPlaceholder));
//			res = appender(res, formatter("partNumberStep", this.partNumberStep));
//			res = appender(res, formatter("partNumberStart", this.partNumberStart));
//			res = appender(res, formatter("partNumberLenght", this.partNumberLenght));
//			res = appender(res, formatter("partNumberLast", this.partNumberLast));
			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
			// WB.addLog2("IdGen.toString, ex=" + ex.getMessage(), WB.strEmpty, "IdGen");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

//	private static String appender2(String strRes, Object objAdd) throws Exception {// for output result
//		// origin - 14.08.2024, last edit - 18.08.2024
//		String res = strRes;
//		String fixStrAdd = Etc.fixTrim(objAdd.toString());
//		try {
//			if (fixStrAdd.isEmpty() != true) {
//				res = res + WB.strSquareBracketLeft + fixStrAdd + WB.strSquareBracketRight;
//			}
//		} catch (Exception ex) {
//			WB.addLog2("IdGen.appender2, ex=" + ex.getMessage(), WB.strEmpty, "IdGen");
//		} finally {
//			Etc.doNothing();
//		}
//		return res;
//	}

	private static String appender(String strRes, Object objAdd) throws Exception {// for toString
		// origin - 14.08.2024, last edit - 17.08.2024
		String res = strRes;
		String fixStrAdd = Etc.fixTrim(objAdd.toString());
		try {
			if (fixStrAdd.isEmpty() != true) {
				// if (fixStrAdd.length() > 2) { // better then "[]"
				res = res + fixStrAdd + WB.strSpace;
			}
		} catch (Exception ex) {
			WB.addLog2("IdGen.appender, ex=" + ex.getMessage(), WB.strEmpty, "IdGen");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

//	private static String formatter2(Object objAdd) throws Exception {// for output result
//		// origin - 15.08.2024, last edit - 21.08.2024
//		String res = WB.strEmpty;
//		String fixStrAdd = Etc.fixTrim(objAdd.toString());
//		try {
//			if (fixStrAdd.isEmpty() == false) {
//				res = res + fixStrAdd;
//			}
//		} catch (Exception ex) {
//			WB.addLog2("IdGen.formatter2, ex=" + ex.getMessage(), WB.strEmpty, "IdGen");
//		} finally {
//			Etc.doNothing();
//		}
//		return res;
//	}

//	private static String formatter(String name, Object objAdd) throws Exception {// for toString
//		// origin - 01.12.2023, last edit - 21.08.2024
//		String res = WB.strEmpty;
//		String fixStrAdd = Etc.fixTrim(objAdd.toString());
//		try {
//			if (fixStrAdd.isEmpty() == false) {
//				res = res + Etc.fixTrim(name) + WB.strEquals + fixStrAdd + WB.strCommaSpace;
//			}
//		} catch (Exception ex) {
//			WB.addLog2("IdGen.formatter, ex=" + ex.getMessage(), WB.strEmpty, "IdGen");
//		} finally {
//			Etc.doNothing();
//		}
//		return res;
//	}

	public static void test() throws Exception {
		// origin - 14.08.2024, last edit - 21.08.2024
		try {

			// ctor IdGen(Id, Code, Description)
			IdGen newIdGen = new IdGen("EmpId", "idStringGrowingDigitalGlobal");
			WB.addLog2("IdGen.test, ctor('EmpId', 'idStringGrowingDigitalGlobal')=" + newIdGen, WB.strEmpty, "Info");

//			// IdGen()
//			WB.addLog2("IdGen.getNew('EmpId','idIntegerGrowingDigitalGlobal'), IdGen.getNew="
//					+ IdGen.getNew("EmpId", "idIntegerGrowingDigitalGlobal"), WB.strEmpty, "IdGen");
//			WB.addLog2("IdGen.getNew('ModelDtoId','idCommonCompositeRandom'), IdGen.getNew="
//					+ IdGen.getNew("ModelDtoId", "idCommonCompositeRandom"), WB.strEmpty, "IdGen");
//			WB.addLog2("IdGen.getNew('EmpId', 'idStringGrowingDigitalGlobal'), IdGen.getNew="
//					+ IdGen.getNew("EmpId", "idStringGrowingDigitalGlobal"), WB.strEmpty, "IdGen");

		} catch (Exception ex) {
			WB.addLog("IdGen.test, ex=" + ex.getMessage(), WB.strEmpty, "IdGen");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("IdGen.test end ", WB.strEmpty, "IdGen");
	}
}