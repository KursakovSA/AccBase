public class Try {
	// origin - 20.10.2024, last edit - 20.10.2024
	public Try() throws Exception {
		// origin - 20.10.2024, last edit - 20.10.2024
	}

	public static void test() throws Exception {
		// origin - 20.10.2024, last edit - 20.10.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Try.test, ex=" + ex.getMessage(), WB.strEmpty, "Try");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Try.test end ", WB.strEmpty, "Try");
	}
}
