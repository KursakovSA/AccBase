import java.io.File;

public final class JSON { // TODO
	// origin - 02.02.2026, last edit - 02.02.2026
	public static String expectedDir;

	static {
		try {
			JSON.expectedDir = WB.commonDocDir; // ?? TODO
		} catch (Exception ex) {
			WB.addLog("JSON.static ctor, ex=" + ex.getMessage(), "", "JSON");
		}
	}

	public static String getByKeyValue(String key, String value) throws Exception {
		// origin - 02.02.2026, last edit - 03.02.2026
		String res = "";
		try {
			key = JSON.getNormKey(key);

			if (key.isEmpty() == false) {
				value = JSON.getNormValue(value);

				if (value.isEmpty()) {
					value = "null";
				}

				res = res + "\"" + Etc.fixTrim(key) + "\"";
				res = res + ":";

				if (JSON.needQuote(value)) {
					res = res + "\"" + Etc.fixTrim(value) + "\"";
				}
				if (JSON.needQuote(value) == false) {
					res = res + Etc.fixTrim(value);
				}
			}
		} catch (Exception ex) {
			WB.addLog("JSON.getByKeyValue(2String):String, ex=" + ex.getMessage(), "", "JSON");
		}
		return res;
	}

	private static String getNormValue(String dirtyStr) throws Exception {
		// origin - 02.02.2026, last edit - 03.02.2026
		String res = Etc.fixTrim(dirtyStr);
		try {
			res = res.replaceAll("\"", "'"); // from " to '
		} catch (Exception ex) {
			WB.addLog("JSON.getNormValue(String):String, ex=" + ex.getMessage(), "", "JSON");
		}
		return res;
	}

	private static String getNormKey(String dirtyStr) throws Exception {
		// origin - 02.02.2026, last edit - 02.02.2026
		String res = Etc.fixTrim(dirtyStr);
		try {
			res = Etc.delLeaderPlaceholder(res, "\""); // ex. "
			res = Etc.delTailPlaceholder(res, "\""); // ex. "
		} catch (Exception ex) {
			WB.addLog("JSON.getNormKey(String):String, ex=" + ex.getMessage(), "", "JSON");
		}
		return res;
	}

	private static boolean needQuote(String value) throws Exception {
		// origin - 02.02.2026, last edit - 02.02.2026
		boolean res = true;
		try {
			value = Etc.fixTrim(value);

			switch (value) {
			case "null" -> res = false;
			case "true" -> res = false;
			case "false" -> res = false;
			// default -> res = true;
			}

			if (Etc.strEquals(value, "0")) {
				res = false;
			}

//			if ((value.startsWith("0") == false) & (value.length() != 1)) { // ex. value=0000564
//				res = false;
//			}
		} catch (Exception ex) {
			WB.addLog("JSON.needQuote(String):boolean, ex=" + ex.getMessage(), "", "JSON");
		}
		return res;
	}

	public static String getSource(String fileName) throws Exception { // TODO
		// origin - 02.02.2026, last edit - 02.02.2026
		String res = "";
		try {
			res = ZIP.expectedDir + File.separator + fileName;
		} catch (Exception ex) {
			WB.addLog("JSON.getSource(String):String, ex=" + ex.getMessage() + ", fileName=" + fileName, "", "JSON");
		}
		return res;
	}

	private JSON() throws Exception {
		// origin - 02.02.2026, last edit - 02.02.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 02.02.2026, last edit - 02.02.2026
		try {
		} catch (Exception ex) {
			WB.addLog("JSON.clear():void, ex=" + ex.getMessage(), "", "JSON");
		}
	}

	public static void test() throws Exception {
		// origin - 02.02.2026, last edit - 03.02.2026
		try {

			WB.addLog2("JSON.test.getNormValue(String)", "", "JSON");
			for (var tmp1 : new String[] { "Альфа", "\"Альфа\"", "ТОО \"Альфа\"" }) {
				WB.addLog2("JSON.test.getNormValue(String), res=" + JSON.getNormValue(tmp1) + ", tmp1=" + tmp1, "",
						"JSON");
			}

			WB.addLog2("JSON.test.getNormKey(String)", "", "JSON");
			for (var tmp1 : new String[] { "\"myKey\"", "myKey" }) {
				WB.addLog2("JSON.test.getNormKey(String), res=" + JSON.getNormKey(tmp1) + ", tmp1=" + tmp1, "", "JSON");
			}

//			WB.addLog2("JSON.test.getByKeyValue(String)", "", "JSON");
//			for (var tmp1 : new String[] { "", "Slice", "creatorCode", "\"testNorm\"" }) {
//				for (var tmp2 : new String[] { "", "null", "true", "false", "1234567890", "0005764", "0" }) {
//					WB.addLog2("JSON.test.getByKeyValue(String), res=" + JSON.getByKeyValue(tmp1, tmp2) + ", tmp1="
//							+ tmp1 + ", tmp2=" + tmp2, "", "JSON");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("JSON.test():void, ex=" + ex.getMessage(), "", "JSON");
		}
	}
}