import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.util.List;

public final class StrDate {
	// origin - 01.05.2026, last edit - 01.05.2026
	public String id, src0, src1, strYear, strMonth, strDay;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("StrDate.static ctor, ex=" + ex.getMessage(), "", "StrDate");
		}
	}

	private void validate() throws Exception { // TODO
		// origin - 01.05.2026, last edit - 01.05.2026
		try {
		} catch (Exception ex) {
			WB.addLog("StrDate.validate():void, ex=" + ex.getMessage(), "", "StrDate");
		}
	}

	private void fix() throws Exception {
		// origin - 01.05.2026, last edit - 02.07.2026
		try {
			if (strYear.length() == 1) {
				strYear = "200" + strYear; // TODO ? first 3 char curr year ?
				strYear = strYear.substring(strYear.length() - 4);
			}

			if (strYear.length() == 2) {
				strYear = "20" + strYear; // TODO ? first 2 char curr year ?
				strYear = strYear.substring(strYear.length() - 4);
			}

			strYear = DefVal.setIf(strYear, "0000", String.valueOf(WB.minDateSupported.getYear()));

			if (strYear.length() > 0) {
				if (Integer.parseInt(strYear) < Integer.parseInt(String.valueOf(WB.minDateSupported.getYear()))) {
					strYear = String.valueOf(WB.minDateSupported.getYear());
				}
			}

			if (strYear.length() > 0) {
				if (Integer.parseInt(strYear) > Integer.parseInt(String.valueOf(WB.maxDateSupported.getYear()))) {
					strYear = String.valueOf(WB.maxDateSupported.getYear());
				}
			}

			if (strYear.length() == 0) {
				strYear = String.valueOf(DateTool.getNow().getYear());
			}

			strMonth = "00" + strMonth;
			strMonth = strMonth.substring(strMonth.length() - 2);

			strMonth = DefVal.setIf(strMonth, "00", "01");

			if (Integer.parseInt(strMonth) > 12) {
				strMonth = "12";
			}

			strDay = "00" + strDay;
			strDay = strDay.substring(strDay.length() - 2);

			strDay = DefVal.setIf(strDay, "00", "01");

			if (Integer.parseInt(strDay) > 31) {
				strDay = "31";
			}

			// correct not exist day, ex. 31 february
			String input = strDay + "." + strMonth + "." + strYear;
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.uuuu")
					.withResolverStyle(ResolverStyle.SMART);
			LocalDate fixedDate = LocalDate.parse(input, formatter);
			strDay = "00" + String.valueOf(fixedDate.getDayOfMonth());
			strDay = strDay.substring(strDay.length() - 2);

		} catch (Exception ex) {
			WB.addLog("StrDate.fix():void, ex=" + ex.getMessage(), "", "StrDate");
			strYear = String.valueOf(DateTool.getNow().getYear());
			strMonth = "01";
			strDay = "01";
		}
	}

	private void clear() throws Exception {
		// origin - 01.05.2026, last edit - 01.05.2026
		try {
			this.src0 = this.src1 = this.strYear = this.strMonth = this.strDay = "";
		} catch (Exception ex) {
			WB.addLog("StrDate.clear():void, ex=" + ex.getMessage(), "", "StrDate");
		}
	}

	public StrDate(String Src0) throws Exception {
		// origin - 01.05.2026, last edit - 29.06.2026
		this.clear();
		this.src0 = Src0;

		this.src1 = Etc.fixTrim(Src0);
		this.src1 = this.src1.replaceAll(" ", "");
		this.src1 = this.src1.replaceAll("--", "-"); // ex. 2026----01----31
		this.src1 = this.src1.replaceAll("--", "-");

		if (this.src0 == null) {
			this.src0 = DateTool.formatter5(DateTool.getNow());
		}

		if (this.src0.isEmpty()) {
			this.src0 = DateTool.formatter5(DateTool.getNow());
		}

		if (this.src1.length() > 10) { // need "2025-12-26", not need "2025-12-26 03:50:22"
			this.src1 = this.src1.substring(0, 10);
		}

		this.src1 = this.src1.replaceAll("\\.", "-"); // ex. 2026.01.31

		if (this.src1.isEmpty()) {
			this.src1 = DateTool.getNow().toString();
		}

		var tmp = List.of(this.src1.split("-"));
		if (tmp.size() == 3) {
			this.strYear = tmp.getFirst();
			this.strMonth = tmp.get(1);
			this.strDay = tmp.getLast();
		}

		this.fix();
		this.validate();
		this.id = this.strYear + "-" + this.strMonth + "-" + this.strDay;
	}

	public StrDate() throws Exception {
		// origin - 01.05.2026, last edit - 01.05.2026
		this.clear();
	}

	public String toString() {
		// origin - 01.05.2026, last edit - 02.05.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway(" src0 ", this.src0);
			res = res + Fmtr.addAnyway(", src1 ", this.src1);
			res = res + Fmtr.addAnyway(", id ", this.id);
			res = res + Fmtr.addAnyway(", strYear ", this.strYear);
			res = res + Fmtr.addAnyway(", strMonth ", this.strMonth);
			res = res + Fmtr.addAnyway(", strDay ", this.strDay);
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 01.05.2026, last edit - 02.07.2026
		try {

//			WB.addLog2("StrDate.test.ctor(String)", "", "StrDate");
//			for (var tmp1 : List.of("", "2025-12-26 03:50:22", "2025.05.18", "2025--05--18", "2025 - 05 - 18",
//					"0000-00-00", "2025-56-34", "3456-12-25", "23-45-56", "2097-12-24", "1967-11-25", "2025-05-18",
//					"2311-00-00", "2026-02-31", "2026-2-1", "6-2-1", "tralala")) {
//				WB.addLog2("StrDate.test.ctor(String)=" + new StrDate(tmp1), "", "StrDate");
//			}

		} catch (Exception ex) {
			WB.addLog("StrDate.test():void, ex=" + ex.getMessage(), "", "StrDate");
		}
	}
}