import java.util.ArrayList;
import java.util.List;

public final class Xlsx2csv {
	// origin - 10.08.2026, last edit - 10.08.2026

	public static String get(String pathXlsx) throws Exception {
		// origin - 10.08.2026, last edit - 10.08.2026
		String res = "";
		if (InOut.hasFile(pathXlsx) == false) {
			// WB.addLog2("Xlsx2csv.get(String):String, not exist pathXlsx=" + pathXlsx, "",
			// "Xlsx2csv");
			return res;
		}
		res = pathXlsx + ".csv";
		try {
			List<String> command = new ArrayList<>();
			command.add("cmd.exe");
			command.add("/c");
			command.add("xlsx2csv");
			command.add("-d");
			command.add(";"); // command.add("|");
			command.add(pathXlsx);
			command.add(res);

			// String command2 = "cmd.exe" + "/c" + "xlsx2csv" + "-d | " + pathXlsx + " " +
			// res;

			ProcessBuilder pb = new ProcessBuilder(command);
			pb.redirectErrorStream(true); // Объединяем поток ошибок с обычным выводом
			java.lang.Process process = pb.start();

			int exitCode = process.waitFor();
			if (exitCode == 0) {
				// System.out.println("✅ Конвертация успешно завершена!");
			} else {
				// System.out.println("❌ Ошибка при конвертации. Код выхода: " + exitCode);
				WB.addLog("Xlsx2csv.get():String, Ошибка при конвертации. Код выхода: =" + exitCode, "", "Xlsx2csv");
				WB.addLog("Xlsx2csv.get():String, check -- pip install xlsx2csv", "", "Xlsx2csv");
			}
		} catch (Exception ex) {
			WB.addLog("Xlsx2csv.get(String):String, ex=" + ex.getMessage(), "", "Xlsx2csv");
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 10.08.2026, last edit - 11.08.2026
		try {

//			WB.addLog2("Xlsx2csv.test.get(String):String", "", "Xlsx2csv");
//			for (var tmp1 : new String[] { "111.xlsx", "222.xlsx", "tralala.xlsx" }) {
//				var tmp2 = InOut.getStrPathFileByFileNameInAppDir(tmp1);
//				var tmp3 = Xlsx2csv.get(tmp2);
//				WB.addLog2("Xlsx2csv.test.get(String):String, res=" + tmp3 + ", tmp1=" + tmp1, "", "Xlsx2csv");
//			}

		} catch (Exception ex) {
			WB.addLog("Xlsx2csv.test():void, ex=" + ex.getMessage(), "", "Xlsx2csv");
		}
	}
}