import java.io.File;
import java.util.ArrayList;
import java.util.List;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;

public class Xls97Reader {
	// origin - 09.08.2026, last edit - 09.08.2026

	public static List<List<String>> get(String path, int index) throws Exception {
		// origin - 09.08.2026, last edit - 09.08.2026
		List<List<String>> res = new ArrayList<>();
		try {
			if (InOut.hasFile(path) == false) {
				// WB.addLog2("Xls97Reader.get(String):List<List<String>>, not exist path=" +
				// path, "", "Xls97Reader");
				return res;
			}

			File xlsxFile = new File(path);
			if (index == 0) {
				res = Xls97Reader.readFirstSheet(xlsxFile);
			}
			if (index != 0) {
				res = Xls97Reader.readSheetByIndex(xlsxFile, index);
			}
		} catch (Exception ex) {
			WB.addLog("Xls97Reader.get(String):List<List<String>>, ex=" + ex.getMessage(), "", "Xls97Reader");
		}
		return res;
	}

	public static List<List<String>> readSheetByIndex(File xlsFile, int sheetIndex) throws Exception {
		// origin - 09.08.2026, last edit - 09.08.2026
		List<List<String>> sheetData = new ArrayList<>();
		Workbook workbook = null;
		try {
			workbook = Workbook.getWorkbook(xlsFile);
			Sheet sheet = workbook.getSheet(sheetIndex - 1);
			int rows = sheet.getRows();
			int columns = sheet.getColumns();
			List<String> tmp = new ArrayList<>();
			for (int r = 0; r < rows; r++) {
				tmp.clear();
				for (int c = 0; c < columns; c++) {
					// В jxl сначала указывается СТОЛБЕЦ, затем СТРОКА
					Cell cell = sheet.getCell(c, r);
					String content = cell.getContents();
					tmp.add(content);
				}
				sheetData.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("Xls97Reader.readSheetByIndex(File,int):List<List<String>>, ex=" + ex.getMessage(), "",
					"Xls97Reader");
		} finally {
			if (workbook != null) {
				workbook.close();
			}
		}
		return sheetData;
	}

	public static List<List<String>> readFirstSheet(File file) throws Exception {
		List<List<String>> sheetData = new ArrayList<>();
		try {
			sheetData = Xls97Reader.readSheetByIndex(file, 1);
		} catch (Exception ex) {
			WB.addLog("Xls97Reader.readFirstSheet(File):List<List<String>>, ex=" + ex.getMessage(), "", "Xls97Reader");
		}
		return sheetData;
	}

	public static void test() throws Exception {
		// origin - 09.08.2026, last edit - 10.08.2026
		try {

//			WB.addLog2("Xls97Reader.test.get(String; int):List<List<String>>", "", "Xls97Reader");
//			for (var tmp1 : new String[] { "111.xls" }) {
//				for (var tmp2 : new int[] { 1, 2 }) {
//					var tmp3 = InOut.getStrPathFileByFileNameInAppDir(tmp1);
//					var tmp4 = Xls97Reader.get(tmp3, tmp2);
//					WB.addLog2("Xls97Reader.test.get(String,int):List<List<String>>, res.size=" + tmp4.size()
//							+ ", tmp1=" + tmp1 + ", tmp2=" + tmp2, "", "Xls97Reader");
//					WB.log3Str(tmp4, "Xls97Reader");
//				}
//			}

//			WB.addLog2("Xls97Reader.test.get(String; int=0):List<List<String>>", "", "Xls97Reader");
//			for (var tmp1 : new String[] { "111.xls", "222.xls" }) {
//				var tmp2 = InOut.getStrPathFileByFileNameInAppDir(tmp1);
//				var tmp3 = Xls97Reader.get(tmp2, 0);
//				WB.addLog2("Xls97Reader.test.get(String,int=0):List<List<String>>, res.size=" + tmp3.size() + ", tmp1="
//						+ tmp1, "", "Xls97Reader");
//				WB.log3Str(tmp3, "XlsxReader");
//			}

		} catch (Exception ex) {
			WB.addLog("Xls97Reader.test():void, ex=" + ex.getMessage(), "", "Xls97Reader");
		}
	}
}