import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class CSV {
	// origin - 30.07.2023, last edit - 29.01.2026
	public static List<String> expectedDir;
	public static String delimiter;

	static {
		try {
			CSV.expectedDir = List.of(WB.commonDocDir, WB.inputOutputDir, WB.startDir);
			CSV.delimiter = "|";
		} catch (Exception ex) {
			WB.addLog("CSV.static ctor, ex=" + ex.getMessage(), "", "CSV");
		}
	}

	public static List<String> load() throws Exception { // TODO
		// origin - 31.01.2026, last edit - 02.02.2026
		List<String> res = new ArrayList<String>();
		try {
//			var tableList = DAL.getTableList(WB.lastConnWork);
//			for (var dir : CSV.expectedDir) {
//				if (Files.notExists(Paths.get(dir))) {
//					continue;
//				}
//
//				File file = Paths.get(dir).toFile();
//				String currFileName = "";
//				for (File currFile : file.listFiles()) {
//					for (var currTable : tableList) {
//					}
//				}
//
//			}
		} catch (Exception ex) {
			WB.addLog("CSV.load():String, ex=" + ex.getMessage(), "", "CSV");
		}
		return res;
	}

	public static List<String> writeByAllTable() throws Exception {
		// origin - 31.01.2026, last edit - 31.01.2026
		List<String> res = new ArrayList<String>();
		try {
			for (var table : DAL.getTableList(WB.lastConnWork)) {
				CSV.writeByTable(table);
			}
			res = DAL.getTableList(WB.lastConnWork);
		} catch (Exception ex) {
			WB.addLog("CSV.writeByAllTable():String, ex=" + ex.getMessage(), "", "CSV");
		}
		return res;
	}

	public static String writeByTable(String table) throws Exception {
		// origin - 29.01.2026, last edit - 30.01.2026
		String res = "";
		try {
			var strBld = CSV.setByTable(table);
			if (strBld.toString().lines().count() != 0) {
				res = WB.inputOutputDir + File.separator + Etc.getFileName(WB.lastConnWork) + "_" + table + "_"
						+ DateTool.getLabelDateTimeForFileName() + ".csv";
				WB.writeFile(res, strBld.toString());
			}
		} catch (Exception ex) {
			WB.addLog("CSV.writeByTable(String):String, ex=" + ex.getMessage() + ", table=" + table, "", "CSV");
		}
		return res;
	}

	public static StringBuilder setByTable(String table) throws Exception {
		// origin - 29.01.2026, last edit - 31.01.2026
		StringBuilder res = new StringBuilder("");
		try {
			if (table.isEmpty() == false) {
				var file = CSV.getByTable(table);
				String strLine = "";
				int countField = 0;
				for (var line : file) {
					countField = 0;
					for (var field : line) {
						countField = countField + 1;
						if (countField == 1) {
							strLine = strLine + Etc.fixTrim(field);
						}
						if (countField != 1) {
							strLine = strLine + CSV.delimiter + Etc.fixTrim(field);
						}
					}
					res = res.append(strLine + WB.sysLineSep);
					strLine = "";
				}
			}
		} catch (Exception ex) {
			WB.addLog("CSV.setByTable(String):StringBuilder, ex=" + ex.getMessage() + ", table=" + table, "", "CSV");
		}
		return res;
	}

	public static List<List<String>> getByTable(String table) throws Exception {
		// origin - 29.01.2026, last edit - 31.01.2026
		List<List<String>> res = new ArrayList<List<String>>();
		try {
			var listDto = DAL.getTable(WB.lastConnWork, Qry.getText(WB.lastConnWork, table, ""));
			for (var dto : listDto) {
				// res.add(DAL.getColumnList(table));
				switch (table) {
				case "Account" -> res.add(Account.getByTable(dto));
				case "Asset" -> res.add(Asset.getByTable(dto));
				case "Deal" -> res.add(Deal.getByTable(dto));
				case "Debt" -> res.add(Debt.getByTable(dto));
				case "Face" -> res.add(Face.getByTable(dto));
				case "Geo" -> res.add(Geo.getByTable(dto));
				case "Info" -> res.add(Info.getByTable(dto));
				case "Item" -> res.add(Item.getByTable(dto));
				case "Mark" -> res.add(Mark.getByTable(dto));
				case "Meter" -> res.add(Meter.getByTable(dto));
				case "Price" -> res.add(Price.getByTable(dto));
				case "Process" -> res.add(Process.getByTable(dto));
				case "Role" -> res.add(Role.getByTable(dto));
				case "Sign" -> res.add(Sign.getByTable(dto));
				case "Slice" -> res.add(Slice.getByTable(dto));
				case "Unit" -> res.add(Unit.getByTable(dto));
				case "Workbook" -> res.add(Workbook.getByTable(dto));

				default -> res.add(ModelDto.getData(dto));
				}

			}
		} catch (Exception ex) {
			WB.addLog("CSV.getByTable(String):List<List<String>>, ex=" + ex.getMessage() + ", table=" + table, "",
					"CSV");
		}
		return res;
	}

	public static List<String> getHeader(String table) throws Exception {
		// origin - 31.01.2026, last edit - 31.01.2026
		List<String> res = new ArrayList<String>();
		try {
//			var csv = CSV.get(fileName);
//			if (csv.size() != 0) {
//				res = csv.getFirst();
//			}
		} catch (Exception ex) {
			WB.addLog("CSV.getHeader(String):List<String>, ex=" + ex.getMessage() + ", table=" + table, "", "CSV");
		}
		return res;
	}

//	public static List<String> getTitle(String fileName) throws Exception {
//		// origin - 29.01.2026, last edit - 29.01.2026
//		List<String> res = new ArrayList<String>();
//		try {
//			var csv = CSV.get(fileName);
//			if (csv.size() != 0) {
//				res = csv.getFirst();
//			}
//		} catch (Exception ex) {
//			WB.addLog("CSV.getTitle(String):List<String>, ex=" + ex.getMessage() + ", fileName=" + fileName, "", "CSV");
//		}
//		return res;
//	}

	public static List<List<String>> get(String fileName) throws Exception {
		// origin - 29.01.2026, last edit - 29.01.2026
		List<List<String>> res = new ArrayList<List<String>>();
		try {
			var source = CSV.getSource(fileName);
			if (source.toString().isEmpty() == false) {
				try (BufferedReader br = Files.newBufferedReader(source, StandardCharsets.UTF_8)) {
					String line = "";
					while ((line = br.readLine()) != null) {
						String[] values = line.split(CSV.delimiter);
						res.add(Arrays.asList(values));
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("CSV.get(String):List<List<String>>, ex=" + ex.getMessage() + ", fileName=" + fileName, "",
					"CSV");
		}
		return res;
	}

	public static Path getSource(String fileName) throws Exception {
		// origin - 31.07.2024, last edit - 29.01.2026
		Path res = Paths.get("");
		try {
			if (fileName.isEmpty() == false) {
				for (var dir : CSV.expectedDir) {
					if (WB.hasFile(dir, fileName)) {
						res = Paths.get(dir + File.separator + fileName);
						break;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("CSV.getSource(String):Path, ex=" + ex.getMessage() + ", fileName=" + fileName, "", "CSV");
		}
		return res;
	}

	public static List<String> getContains(String file, String pattern) throws Exception {
		// origin - 31.07.2024, last edit - 29.01.2026
		List<String> res = new ArrayList<String>();
		int countRow = 0;
		try {
			try (BufferedReader br = new BufferedReader(new FileReader(file, StandardCharsets.UTF_8))) {
				String line;
				while ((line = br.readLine()) != null) {
					countRow = countRow + 1;
					if (Etc.strContains(line, pattern)) {
						res.add(String.valueOf(countRow));
						// WB.addLog2("CSV.getContains, res=" + countRow, "", "CSV");
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("CSV.getContains(2String):List<String>, ex=" + ex.getMessage(), "", "CSV");
		}
		WB.addLog2("CSV.getContains, res=" + res + ", file=" + file + ", pattern=" + pattern + ", countRow=" + countRow,
				"", "CSV");
		return res;
	}

	private CSV() throws Exception {
		// origin - 30.07.2024, last edit - 29.01.2026
	}

	public static void test() throws Exception {
		// origin - 30.07.2024, last edit - 02.02.2026
		try {

//			{
//				WB.addLog2("CSV.test.writeByAllTable()", "", "CSV");
//				var tmp1 = CSV.writeByAllTable();
//				WB.addLog2("CSV.test.writeByTable(), res=" + tmp1, "", "CSV");
//			}

//			WB.addLog2("CSV.test.writeByTable(String)", "", "CSV");
//			for (var tmp1 : new String[] { "", "Slice", "Geo" }) {
//				var tmp2 = CSV.writeByTable(tmp1);
//				WB.addLog2("CSV.test.writeByTable(String), res=" + tmp2 + ", tmp1=" + tmp1, "", "CSV");
//				// WB.openFile(tmp2);
//			}

//			WB.addLog2("CSV.test.setByTable(String)", "", "CSV");
//			for (var tmp1 : new String[] { "", "Slice", "Geo" }) {
//				var tmp2 = CSV.setByTable(tmp1);
//				WB.addLog2("CSV.test.setTable(String), res.toString().lines().count()="
//						+ tmp2.toString().lines().count() + ", tmp1=" + tmp1, "", "CSV");
//			}

//			{
//				WB.addLog2("CSV.test.getByTable(String)", "", "CSV");
//				var tmp1 = "Slice";
//				var tmp2 = CSV.getByTable(tmp1);
//				WB.addLog2("CSV.test.getTable(String), size=" + tmp2.size() + ", tmp1=" + tmp1, "", "CSV");
//				WB.log(tmp2, "CSV");
//			}

//			WB.addLog2("CSV.test.getTitle(String)", "", "CSV");
//			for (var tmp1 : new String[] { "", "test", "csv", ".csv", "test1.csv", "test.csv" }) {
//				WB.addLog2("CSV.test.getTitle(String), res=" + CSV.getTitle(tmp1) + ", tmp1=" + tmp1, "", "CSV");
//			}

//			WB.addLog2("CSV.test.get(String)", "", "CSV");
//			for (var tmp1 : new String[] { "", "test", "csv", ".csv", "test1.csv", "test.csv" }) {
//				var tmp2 = CSV.get(tmp1);
//				WB.addLog2("CSV.test.get(String), size=" + tmp2.size() + ", tmp1=" + tmp1, "", "CSV");
//				WB.log(tmp2, "CSV");
//			}

//			WB.addLog2("CSV.test.getSource(String)", "", "CSV");
//			for (var tmp1 : new String[] { "", "test", "csv", ".csv", "test1.csv", "test.csv" }) {
//				WB.addLog2("CSV.test.getSource(String)=" + CSV.getSource(tmp1) + ", tmp1=" + tmp1, "", "CSV");
//			}

		} catch (Exception ex) {
			WB.addLog("CSV.test():void, ex=" + ex.getMessage(), "", "CSV");
		}
	}
}