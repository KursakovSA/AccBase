import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public final class CSV {
	// origin - 30.07.2023, last edit - 27.02.2026
	public static String delimiterForSplit, delimiterForWrite;

	static {
		try {
			CSV.delimiterForSplit = "\\|"; // "\\" this is protective shielding
			CSV.delimiterForWrite = "|";
		} catch (Exception ex) {
			WB.addLog("CSV.static ctor, ex=" + ex.getMessage(), "", "CSV");
		}
	}

	public static String unload(String pathFile) throws Exception { // TODO
		// origin - 02.03.2026, last edit - 02.03.2026
		String res = ""; // unloaded table name
		try {

		} catch (Exception ex) {
			WB.addLog("CSV.unload(String):String, ex=" + ex.getMessage(), "", "CSV");
		}
		return res;
	}

	public static List<String> loadByDir(String dir) throws Exception {
		// origin - 26.02.2026, last edit - 01.03.2026
		List<String> res = new ArrayList<String>(); // loaded tableNames
		try {
			var pathFileList = InOut.getPathFileByDir(dir);
			for (var curr : pathFileList) {
				res.add(CSV.load(curr));
			}
		} catch (Exception ex) {
			WB.addLog("CSV.loadByDir(String):List<String>, ex=" + ex.getMessage(), "", "CSV");
		}
		return res;
	}

	public static String load(String pathFile) throws Exception {
		// origin - 31.01.2026, last edit - 20.07.2026
		String res = ""; // loaded tableName
		try {
			if (InOut.hasFile(pathFile) == false) {
				WB.addLog2("CSV.load(String):String, not exist pathFile=" + pathFile, "", "CSV");
				return "";
			}

			if (pathFile.endsWith(".zip")) {
				pathFile = ZIP.getUnzip(pathFile);
			}

			var tableName = CSV.getTableNameByPathFile(pathFile);
			if (tableName.isEmpty() == false) {
				var updateDto = CSV.getFullDtoList(pathFile);
				if (updateDto.size() != 0) {
					DAL.getReplaceInto(Conn.work, updateDto);
					res = tableName;
					InOut.delFile(pathFile); // remove source file because not need it next
				}
			}
		} catch (Exception ex) {
			WB.addLog("CSV.load(String):String, ex=" + ex.getMessage(), "", "CSV");
		}
		return res;
	}

	private static String getTableNameByPathFile(String pathFile) throws Exception {
		// origin - 26.02.2026, last edit - 26.02.2026
		String res = "";
		try {
			var tableList = DAL.getTableList(WB.lastConnWork);
			for (var curr : tableList) {
				if (Etc.strContains(pathFile, curr)) {
					res = curr;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("CSV.getTableNameByPathFile(String):String, ex=" + ex.getMessage(), "", "CSV");
		}
		return res;
	}

	public static List<String> writeAllTable() throws Exception {
		// origin - 31.01.2026, last edit - 01.03.2026
		List<String> res = new ArrayList<String>();
		try {
			var tableList = DAL.getTableList(WB.lastConnWork);
			for (var table : tableList) {
				res.add(CSV.writeTable(table));
			}
		} catch (Exception ex) {
			WB.addLog("CSV.writeAllTable():String, ex=" + ex.getMessage(), "", "CSV");
		}
		return res;
	}

	public static String writeTable(String table) throws Exception {
		// origin - 29.01.2026, last edit - 02.03.2026
		String res = "";
		try {
			var strBld = CSV.getTable(table);
			if (strBld.toString().lines().count() != 0) {
				res = WB.tempDir + File.separator + Etc.getFileName(WB.lastConnWork) + "_" + table + "_"
						+ DateTool.getLabelDateTimeForFileName() + ".csv";
				WB.writeFile(res, strBld.toString());
				// ZIP.getZip(res);
			}
		} catch (Exception ex) {
			WB.addLog("CSV.writeTable(String):String, ex=" + ex.getMessage() + ", table=" + table, "", "CSV");
		}
		return res;
	}

	public static StringBuilder getTable(String table) throws Exception {
		// origin - 29.01.2026, last edit - 01.03.2026
		StringBuilder res = new StringBuilder("");
		try {
			if (table.isEmpty()) {
				WB.addLog2("CSV.getTable(String):StringBuilder, empty table=" + table, "", "CSV");
				return res;
			}

			if (DAL.hasTableByTableList(table) == false) {
				WB.addLog2("CSV.getTable(String):StringBuilder, not such table=" + table, "", "CSV");
				return res;
			}

			if (table.isEmpty() == false) {
				var file = CSV.getListByTable(table);
				String strLine = "";
				int countField = 0;
				for (var line : file) {
					countField = 0;
					for (var field : line) {
						countField = countField + 1;
						if (countField == 1) {
							// strLine = strLine + Etc.fixTrim(field);
							strLine = strLine + field;
						}
						if (countField != 1) {
							// strLine = strLine + CSV.delimiterForWrite + Etc.fixTrim(field);
							strLine = strLine + CSV.delimiterForWrite + field;
						}
					}
					res = res.append(strLine + WB.sysLineSep);
					strLine = "";
				}
			}
		} catch (Exception ex) {
			WB.addLog("CSV.getTable(String):StringBuilder, ex=" + ex.getMessage(), "", "CSV");
		}
		return res;
	}

	public static FullDto getFullDtoByList(String table, List<String> csvList) throws Exception { // TODO
		// origin - 26.02.2026, last edit - 20.07.2026
		FullDto res = new FullDto();

		if (table.isEmpty()) {
			WB.addLog2("CSV.getFullDtoByList(String):List<FullDto>, empty table=" + table, "", "CSV");
			return res;
		}

		if (DAL.hasTableByTableList(table) == false) {
			WB.addLog2("CSV.getFullDtoByList(String):List<FullDto>, not such table=" + table, "", "CSV");
			return res;
		}

		try {
			switch (table) {
			case "Account" -> res = Account.getFullDtoByList(csvList);
			case "Asset" -> res = Asset.getFullDtoByList(csvList);
			case "Deal" -> res = Deal.getFullDtoByList(csvList);
			case "Debt" -> res = Debt.getFullDtoByList(csvList);
			case "Face" -> res = Face.getFullDtoByList(csvList);
			case "Geo" -> res = Geo.getFullDtoByList(csvList);
			case "Info" -> res = Info.getFullDtoByList(csvList);
			case "Item" -> res = Item.getFullDtoByList(csvList);
			case "Mark" -> res = Mark.getFullDtoByList(csvList);
			case "Meter" -> res = Meter.getFullDtoByList(csvList);
			case "Price" -> res = Price.getFullDtoByList(csvList);
			case "Process" -> res = Process.getFullDtoByList(csvList);
			case "Role" -> res = Role.getFullDtoByList(csvList);
			case "Sign" -> res = Sign.getFullDtoByList(csvList);
			case "Slice" -> res = Slice.getFullDtoByList(csvList);
			case "Unit" -> res = Unit.getFullDtoByList(csvList);
			case "Workbook" -> res = Workbook.getFullDtoByList(csvList);
			// default -> res = FullDto.getByList(csvList);
			}
		} catch (Exception ex) {
			WB.addLog("CSV.getFullDtoByTable(String):FullDto, ex=" + ex.getMessage() + ", table=" + table, "", "CSV");
		}
		return res;
	}

	public static List<String> getListByPath(String pathFile) throws Exception {
		// origin - 17.06.2026, last edit - 17.06.2026
		List<String> res = new ArrayList<String>();
		try {
			var path = Paths.get(pathFile);
			if (path.getFileName().toString().isEmpty()) {
				WB.addLog2("CSV.getListByPath(String):List<String>, pathFile is empty=" + pathFile, "", "CSV");
				return res;
			}

			if (InOut.hasFile(pathFile) == false) {
				WB.addLog2("CSV.getListByPath(String):List<String>, not exist pathFile=" + pathFile, "", "CSV");
				return res;
			}

			try (BufferedReader br = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
				String line = "";
				while ((line = br.readLine()) != null) {
					var tmp1 = line;
					res.add(tmp1);
				}
			}
		} catch (Exception ex) {
			WB.addLog("CSV.getListByPath(String):List<String>, ex=" + ex.getMessage() + ", pathFile=" + pathFile, "",
					"CSV");
		}
		return res;
	}

	public static List<List<String>> getListByTable(String table) throws Exception {
		// origin - 29.01.2026, last edit - 20.07.2026
		List<List<String>> res = new ArrayList<List<String>>();
		try {
			var listDto = DAL.getTable(WB.lastConnWork, Qry.getText(WB.lastConnWork, table, ""));
			for (var dto : listDto) {
				switch (table) {
				case "Account" -> res.add(Account.getListByFullDto(dto));
				case "Asset" -> res.add(Asset.getListByFullDto(dto));
				case "Deal" -> res.add(Deal.getListByFullDto(dto));
				case "Debt" -> res.add(Debt.getListByFullDto(dto));
				case "Face" -> res.add(Face.getListByFullDto(dto));
				case "Geo" -> res.add(Geo.getListByFullDto(dto));
				case "Info" -> res.add(Info.getListByFullDto(dto));
				case "Item" -> res.add(Item.getListByFullDto(dto));
				case "Mark" -> res.add(Mark.getListByFullDto(dto));
				case "Meter" -> res.add(Meter.getListByFullDto(dto));
				case "Price" -> res.add(Price.getListByFullDto(dto));
				case "Process" -> res.add(Process.getListByFullDto(dto));
				case "Role" -> res.add(Role.getListByFullDto(dto));
				case "Sign" -> res.add(Sign.getListByFullDto(dto));
				case "Slice" -> res.add(Slice.getListByFullDto(dto));
				case "Unit" -> res.add(Unit.getListByFullDto(dto));
				case "Workbook" -> res.add(Workbook.getListByFullDto(dto));
				// default -> res.add(FullDto.getList(dto));
				}
			}
		} catch (Exception ex) {
			WB.addLog("CSV.getListByTable(String):List<List<String>>, ex=" + ex.getMessage() + ", table=" + table, "",
					"CSV");
		}
		return res;
	}

	public static List<FullDto> getFullDtoList(String pathFile) throws Exception {
		// origin - 29.01.2026, last edit - 20.07.2026
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			var path = Paths.get(pathFile);
			if (path.getFileName().toString().isEmpty()) {
				WB.addLog2("CSV.getFullDtoList(String):List<FullDto>, pathFile.FileName is empty=" + pathFile, "",
						"CSV");
				return res;
			}

			if (InOut.hasFile(pathFile) == false) {
				WB.addLog2("CSV.getFullDtoList(String):List<FullDto>, not exist pathFile=" + pathFile, "", "CSV");
				return res;
			}

			var table = CSV.getTableNameByPathFile(pathFile);

			if (table.isEmpty()) {
				WB.addLog2("CSV.getFullDtoList(String):List<FullDto>, not exist table=" + table, "", "CSV");
				return res;
			}

			try (BufferedReader br = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
				String line = "";
				while ((line = br.readLine()) != null) {
					var tmp1 = List.of(line.split(CSV.delimiterForSplit));
					var tmp2 = CSV.getFullDtoByList(table, tmp1);
					res.add(tmp2);
				}
			}
		} catch (Exception ex) {
			WB.addLog("CSV.getFullDtoList(String):List<FullDto>, ex=" + ex.getMessage(), "", "CSV");
		}
		return res;
	}

	public static boolean contains(String file, String pattern) throws Exception {
		// origin - 16.04.2026, last edit - 16.04.2026
		boolean res = false;
		try {
			if (CSV.getContains(file, pattern).size() > 0) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("CSV.contains(2String):boolean, ex=" + ex.getMessage(), "", "CSV");
		}
		return res;
	}

	private static List<String> getContains(String file, String pattern) throws Exception {
		// origin - 31.07.2024, last edit - 29.01.2026
		List<String> res = new ArrayList<String>();
		int countRow = 0;
		try {
			try (BufferedReader br = new BufferedReader(new FileReader(file, StandardCharsets.UTF_8))) {
				String line;
				while ((line = br.readLine()) != null) {
					countRow = countRow + 1;
					if (Etc.strContains(line, pattern)) {
						res.add(String.valueOf(countRow));
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("CSV.getContains(2String):List<String>, ex=" + ex.getMessage(), "", "CSV");
		}
		return res;
	}

	private CSV() throws Exception {
		// origin - 30.07.2024, last edit - 26.02.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 26.02.2026, last edit - 26.02.2026
		try {
		} catch (Exception ex) {
			WB.addLog("CSV.clear():void, ex=" + ex.getMessage(), "", "CSV");
		}
	}

	public static void test() throws Exception {
		// origin - 30.07.2024, last edit - 17.06.2026
		try {

//			WB.addLog2("CSV.test.getListByPath(String):List<String>", "", "CSV");
//			for (var tmp1 : new String[] { "AccountPlan.csv", "tralala.csv" }) {
//				var tmp2 = WB.commonDocDir + File.separator + tmp1;
//				var tmp3 = CSV.getListByPath(tmp2);
//				WB.addLog2("CSV.test.getListByPath(String):List<String>, res.size=" + tmp3.size() + ", tmp2=" + tmp2,
//						"", "CSV");
//				// WB.log(tmp3, "CSV");
//			}

//			WB.addLog2("CSV.test.loadByDir(String):List<String>", "", "CSV");
//			WB.addLog2(
//					"CSV.test.loadByDir(String):List<String>, res=" + CSV.loadByDir(WB.tempDir) + ", dir=" + WB.tempDir,
//					"", "CSV");

//			WB.addLog2("CSV.test.load(String):String", "", "CSV");
//			for (var tmp1 : new String[] { "NotExistTable.csv", "Geo.csv", "Slice.csv" }) {
//				var tmp2 = WB.tempDir + File.separator + tmp1;
//				var tmp3 = CSV.load(tmp2);
//				WB.addLog2("CSV.test.load(String):String, res=" + tmp3 + ", tmp1=" + tmp1, "", "CSV");
//			}

//			{
//				WB.addLog2("CSV.test.writeAllTable()", "", "CSV");
//				var tmp1 = CSV.writeAllTable();
//				WB.addLog2("CSV.test.writeAllTable(), res=" + tmp1, "", "CSV");
//			}

//			WB.addLog2("CSV.test.writeTable(String):String", "", "CSV");
//			for (var tmp1 : new String[] { "NotExistTable", "Slice", "Geo" }) {
//				var tmp2 = CSV.writeTable(tmp1);
//				WB.addLog2("CSV.test.writeTable(String):String, res=" + tmp2 + ", tmp1=" + tmp1, "", "CSV");
//				// WB.openFile(tmp2);
//			}

//			WB.addLog2("CSV.test.getTable(String):StringBuilder", "", "CSV");
//			for (var tmp1 : new String[] { "NotExistTable", "Slice", "Geo" }) {
//				var tmp2 = CSV.getTable(tmp1);
//				WB.addLog2("CSV.test.getTable(String):StringBuilder, res.toString().lines().count()="
//						+ tmp2.toString().lines().count() + ", tmp1=" + tmp1, "", "CSV");
//			}

//			WB.addLog2("CSV.test.getFullDtoList(String):List<FullDto>", "", "CSV");
//			for (var tmp1 : new String[] { "NotExistTable.csv", "Geo.csv", "Slice.csv" }) {
//				var tmp2 = WB.tempDir + File.separator + tmp1;
//				var tmp3 = CSV.getFullDtoList(tmp2);
//				WB.addLog2(
//						"CSV.test.getFullDtoList(String):List<FullDto>, res.size=" + tmp3.size() + ", tmp1=" + tmp1,
//						"", "CSV");
//				WB.log(tmp3, "CSV");
//			}

		} catch (Exception ex) {
			WB.addLog("CSV.test():void, ex=" + ex.getMessage(), "", "CSV");
		}
	}
}