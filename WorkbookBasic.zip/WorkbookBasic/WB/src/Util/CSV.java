import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unused")
public class CSV {
	// origin - 30.07.2023, last edit - 18.09.2025
	public static String expectedDir;

	static {
		try {
			CSV.expectedDir = WB.commonDocDir;
		} catch (Exception ex) {
			WB.addLog("CSV.static ctor, ex=" + ex.getMessage(), "", "CSV");
		}
	}

	private static String getSource(String fileName) throws Exception {
		// origin - 31.07.2024, last edit - 13.06.2025
		String res = "";
		try {
			res = CSV.expectedDir + File.separator + fileName;
		} catch (Exception ex) {
			WB.addLog("CSV.getSource(String fileName):String, ex=" + ex.getMessage() + ", fileName=" + fileName, "",
					"CSV");
		}
		return res;
	}

	public static List<String> getMatch(String file, String pattern) throws Exception {
		// origin - 31.07.2024, last edit - 13.06.2025
		LocalDateTime localStart = WB.getLocalStart();
		List<String> res = new ArrayList<String>();
		int countRow = 0;
		try {
			try (BufferedReader br = new BufferedReader(new FileReader(file, StandardCharsets.UTF_8))) {
				String line;
				while ((line = br.readLine()) != null) {
					countRow = countRow + 1;
					if (Etc.strContains(line, pattern)) {
						res.add(String.valueOf(countRow));
						// WB.addLog2("CSV.getMatch, res=" + countRow, "", "CSV");
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("CSV.getMatch(String file, String pattern):List<String>, ex=" + ex.getMessage(), "", "CSV");
		}
		WB.getLocalEnd("CSV.getMatch, res=" + res + ",file=" + file + ", pattern=" + pattern + ", countRow=" + countRow,
				localStart);
		WB.addLog2("CSV.getMatch, res=" + res + ", file=" + file + ", pattern=" + pattern + ", countRow=" + countRow,
				"", "CSV");
		return res;
	}

	public CSV() throws Exception {
		// origin - 30.07.2024, last edit - 31.07.2024
	}

	public static void test() throws Exception {
		// origin - 30.07.2024, last edit - 13.06.2025
		String podft1 = CSV.getSource("podft1.csv");
		String podft2 = CSV.getSource("podft2.csv");
		try {

//			// getMatch
//			CSV.getMatch(podft1, "7777777777");
//			CSV.getMatch(podft1, "8888888888");
//			CSV.getMatch(podft1, "9999999999");
//			CSV.getMatch(podft2, "720321350468");
//			CSV.getMatch(podft2, "831119300805");
//			CSV.getMatch(podft2, "830622350417");

		} catch (Exception ex) {
			WB.addLog("CSV.test():void, ex=" + ex.getMessage(), "", "CSV");
		}
	}
}