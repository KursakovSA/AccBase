import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public final class SpanDate {
	// origin - 17.03.2025, last edit - 12.10.2025
	public String id, src, src1, src2;
	private List<String> val1, val2;
	public List<String> date1, date2;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("SpanDate.static ctor, ex=" + ex.getMessage(), "", "SpanDate");
		}
	}

	private void getId() throws Exception {
		// origin - 16.06.2025, last edit - 19.06.2025
		try {
			this.id = this.val1 + "--" + this.val2;
			if ((this.val1.size() == 0) & (this.val2.size() == 0)) {
				this.id = "";
			}
		} catch (Exception ex) {
			WB.addLog("SpanDate.getId():void, ex=" + ex.getMessage(), "", "SpanDate");
		}
	}

	public static SpanDate getQuarter(String intoDate) throws Exception {
		// origin - 07.10.2025, last edit - 07.10.2025
		SpanDate res = new SpanDate();
		try {
			LocalDate currDate = DateTool.getLocalDate(intoDate);
			LocalDate spanDate1 = DateTool.getStartQuarter(currDate);
			LocalDate spanDate2 = DateTool.getEndQuarter(currDate);
			res = new SpanDate(DateTool.formatter5(spanDate1), DateTool.formatter5(spanDate2));
		} catch (Exception ex) {
			WB.addLog("SpanDate.getQuarter(String):SpanDate, ex=" + ex.getMessage(), "", "SpanDate");
		}
		return res;
	}

	public static SpanDate getMonth(String intoDate) throws Exception {
		// origin - 09.05.2025, last edit - 14.06.2025
		SpanDate res = new SpanDate();
		try {
			LocalDate currDate = DateTool.getLocalDate(intoDate);
			LocalDate spanDate1 = DateTool.getStartMonth(currDate);
			LocalDate spanDate2 = DateTool.getEndMonth(currDate);
			res = new SpanDate(DateTool.formatter5(spanDate1), DateTool.formatter5(spanDate2));
		} catch (Exception ex) {
			WB.addLog("SpanDate.getMonth(String):SpanDate, ex=" + ex.getMessage(), "", "SpanDate");
		}
		return res;
	}

	private void correctLogic() throws Exception {// TODO
		// origin - 23.03.2025, last edit - 16.08.2025
		try {
			var currDate1 = "";
			var currDate2 = "";
			var tmpDate1 = DateTool.getNow();
			var tmpDate2 = DateTool.getNow();

			for (int i = 0; i < this.date1.size(); i++) {
				currDate1 = this.date1.get(i);
				currDate2 = this.date2.get(i);
				tmpDate1 = DateTool.getLocalDate(currDate1);
				tmpDate2 = DateTool.getLocalDate(currDate2);
				tmpDate2 = DateTool.getLocalDate(currDate2);
				if (tmpDate2.isBefore(tmpDate1)) { // check if date1 > date2
					this.date1.set(i, currDate2);
					this.date2.set(i, currDate1);
				}

			}
		} catch (Exception ex) {
			WB.addLog("SpanDate.correctLogic():void, ex=" + ex.getMessage(), "", "SpanDate");
		}
	}

	private void correctData(int sizeVal1, int sizeVal2) throws Exception {
		// origin - 21.03.2025, last edit - 14.06.2025
		try {
			if ((sizeVal1 == 0) && (sizeVal2 == 0)) {// both date1 and date2 empty
				this.date1.add(DateTool.formatter5(WB.minDateSupported));
				this.date2.add(DateTool.formatter5(WB.maxDateSupported));
				return;
			}

			if ((sizeVal1 == 0) && (sizeVal2 == 1)) {// date1 empty, date2.size=1
				this.date2 = this.val2;
				this.date1.add(DateTool.formatter5(WB.minDateSupported));
				return;
			}

			if ((sizeVal1 == 0) && (sizeVal2 > 1)) {// date1 empty, date2.size>1
				this.date2 = this.val2;
				for (int i = 1; i <= sizeVal2; i++) {// aline date1,2
					this.date1.add(this.date2.get(i - 1));
				}
				return;
			}

			if ((sizeVal1 == 1) && (sizeVal2 == 0)) {// date1.size=1, date2 empty
				this.date1 = this.val1;
				this.date2.add(DateTool.formatter5(WB.maxDateSupported));
				return;
			}

			if ((sizeVal1 > 1) && (sizeVal2 == 0)) {// date1.size>1, date2 empty
				this.date1 = this.val1;
				for (int i = 1; i <= sizeVal1; i++) {// aline date1,2
					this.date2.add(this.date1.get(i - 1));
				}
				return;
			}

			if ((sizeVal1 >= 1) && (sizeVal2 >= 1) && (sizeVal1 != sizeVal2)) {// date1 and date2 sizes not equals
				this.date1 = this.val1;
				this.date2 = this.val2;
				if (sizeVal1 > sizeVal2) {
					for (int i = this.date2.size() + 1; i <= this.date1.size(); i++) {// aline date1,2
						this.date2.add(this.date1.get(i - 1));
					}
				}
				if (sizeVal1 < sizeVal2) {
					for (int i = this.date1.size() + 1; i <= this.date2.size(); i++) {// aline date1,2
						this.date1.add(this.date2.get(i - 1));
					}
				}
				return;
			}
		} catch (Exception ex) {
			WB.addLog("SpanDate.correctData(2int):void, ex=" + ex.getMessage(), "", "SpanDate");
		}
	}

	private void getDate() throws Exception {
		// origin - 17.03.2025, last edit - 14.06.2025
		try {
			if ((this.val1.size() != 0) && (this.val1.size() == this.val2.size())) {
				this.date1 = this.val1;
				this.date2 = this.val2;
			} else {
				this.correctData(this.val1.size(), this.val2.size());
			}
		} catch (Exception ex) {
			WB.addLog("SpanDate.getDate():void, ex=" + ex.getMessage(), "", "SpanDate");
		}
	}

	private void clear() throws Exception {
		// origin - 17.03.2025, last edit - 17.06.2025
		try {
			this.id = this.src = this.src1 = this.src2 = "";
			this.val1 = new ArrayList<String>();
			this.val2 = new ArrayList<String>();
			this.date1 = new ArrayList<String>();
			this.date2 = new ArrayList<String>();
		} catch (Exception ex) {
			WB.addLog("SpanDate.clear():void, ex=" + ex.getMessage(), "", "SpanDate");
		}
	}

	public SpanDate(String Src1, String Src2) throws Exception {
		// origin - 17.03.2025, last edit - 17.06.2025
		this.clear();
		this.src1 = Src1;
		this.src2 = Src2;
		this.src = Src1 + " - " + Src2;
		this.val1 = Fmtr.listVal(this.src1, ":");
		this.val2 = Fmtr.listVal(this.src2, ":");
		this.getDate();
		this.correctLogic();
		this.getId();
	}

	public SpanDate(String Src) throws Exception {
		// origin - 16.06.2025, last edit - 16.06.2025
		this.clear();
		this.src = Etc.fixTrim(Src);
		var tmp = List.of(this.src1.split(" - "));
		this.src1 = tmp.getFirst();
		this.src2 = tmp.getLast();
		this.val1 = Fmtr.listVal(this.src1, ":");
		this.val2 = Fmtr.listVal(this.src2, ":");
		this.getDate();
		this.correctLogic();
		this.getId();
	}

	public SpanDate() throws Exception {
		// origin - 17.03.2025, last edit - 09.05.2025
		this.clear();
	}

	public String toString() {
		// origin - 17.03.2025, last edit - 15.08.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("id ", this.id);
			res = res + Fmtr.addIfNotEmpty(" src ", this.src);
			res = res + Fmtr.addIfNotEmpty(" src1 ", this.src1);
			res = res + Fmtr.addIfNotEmpty(" src2 ", this.src2);

			res = res + Fmtr.addIfNotEmpty(" date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(" date2 ", this.date2);
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 17.03.2025, last edit - 24.09.2025
		try {

//			WB.addLog2("SpanDate.test.ctor(String)", "", "SpanDate");
//			for (var tmp1 : new String[] { "", "2025-02-01 - 2025-02-14", "2025-01-23: - 2025-02-14:" }) {
//				WB.addLog2("SpanDate.test.ctor(String)=" + new SpanDate(tmp1), "", "SpanDate");
//			}

//			{
//				WB.addLog2("SpanDate.test.ctor(2String).correctLogic", "", "SpanDate");
//				var tmp1 = new String[] { "2025-02-01:", "2025-05-18", "2025-01-23: 2025-08-14:" };
//				var tmp2 = new String[] { "2025-07-03:", "2020-01-25", "2025-05-18: 2025-02-01:" };
//				for (int i = 0; i < tmp1.length; i++) {
//					WB.addLog2("SpanDate.test.ctor(2String).correctLogic=" + new SpanDate(tmp1[i], tmp2[i]), "",
//							"SpanDate");
//				}
//			}

//			{
//				WB.addLog2("SpanDate.test.ctor(2String).correctData", "", "SpanDate");
//				var tmp1 = new String[] { "", "2025-02-01:" };
//				var tmp2 = new String[] { "2025-07-03:", "2025-05-18: 2025-08-24:" };
//				for (int i = 0; i < tmp1.length; i++) {
//					WB.addLog2("SpanDate.test.ctor(2String).correctData=" + new SpanDate(tmp1[i], tmp2[i]), "",
//							"SpanDate");
//				}
//			}

//			{
//				WB.addLog2("SpanDate.test.ctor(2String)", "", "SpanDate");
//				var tmp1 = new String[] { "", "2025-02-01:", "2025-01-23: 2025-02-14:", "2025-04-18: 2025-06-30:", "2025-01-01: 2025-02-01:" };
//				var tmp2 = new String[] { "", "2025-07-03:", "2025-05-18: 2025-08-24:",
//						"2025-04-04: 2025-06-16:2025-05-21:", "2025-01-31:" };
//				for (int i = 0; i < tmp1.length; i++) {
//					WB.addLog2("SpanDate.test.ctor(2String)=" + new SpanDate(tmp1[i], tmp2[i]), "", "SpanDate");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("SpanDate.test():void, ex=" + ex.getMessage(), "", "SpanDate");
		}
	}
}