import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

public final class LocInt {
	// origin - 02.07.2024, last edit - 12.10.2025
	private static LinkedHashMap<String, String> langMap = new LinkedHashMap<String, String>();
	public static String emergencyStrLang = "[RU]";

	static {
		try {
			LocInt.langMap.put("[Қаз]", "[Qaz]");// 1-local main, 2-substitution
			LocInt.langMap.put("[Qaz]", "[Қаз]");
			LocInt.langMap.put("[RU]", "[EN]");
			LocInt.langMap.put("[EN]", "[RU]");
		} catch (Exception ex) {
			WB.addLog("LocInt.static ctor, ex=" + ex.getMessage(), "", "LocInt");
		}
	}

	private static boolean isAnyLang(String initStr) throws Exception {// ex. "8-701-111-11-11", "PANASONIC", etc.
		// origin - 24.07.2024, last edit - 13.06.2025
		boolean res = false;
		try {
			if ((Etc.strContains(initStr, "[") == false) && (Etc.strContains(initStr, "]") == false)) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("LocInt.isAnyLang(String):boolean, ex=" + ex.getMessage(), "", "LocInt");
		}
		return res;
	}

	private static String setLocal(List<String> initListStrLocal, String strLocal) throws Exception {
		// origin - 08.07.2024, last edit - 13.06.2025
		String res = "";
		try {
			for (var currStr : initListStrLocal) {

				// case AnyLang
				if ((res.isEmpty()) && (LocInt.isAnyLang(currStr))) {
					res = Etc.fixTrim(currStr.toString());
					break;
				}

				// usual case
				if ((res.isEmpty()) && (Etc.strContains(currStr, strLocal))) {
					res = Etc.fixTrim(currStr.toString());
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("LocInt.setLocal(List<String>, String):String, ex=" + ex.getMessage(), "", "LocInt");
		}
		return res;
	}

	public static String getLocal(String initStrLocal, String strLocal) throws Exception {
		// origin - 27.07.2024, last edit - 13.06.2025
		String res = "";
		try {
			res = LocInt.getLocal(LocInt.getListStrLocal(initStrLocal), strLocal);
		} catch (Exception ex) {
			WB.addLog("LocInt.getLocal(2String):String, ex=" + ex.getMessage(), "", "LocInt");
		}
		return res;
	}

	private static String getLocal(List<String> initListStrLocal, String strLocal) throws Exception {
		// origin - 03.07.2024, last edit - 13.06.2025
		String res = "";
		try {
			// case usual
			res = LocInt.setLocal(initListStrLocal, strLocal);

			// case subst
			if (res.isEmpty()) {
				res = LocInt.setLocal(initListStrLocal, LocInt.langMap.get(strLocal)); // substLocal);
			}

			// emergency case
			if (res.isEmpty()) {
				res = LocInt.setLocal(initListStrLocal, LocInt.emergencyStrLang);
			}

			res = LocInt.delStrLang(res);
		} catch (Exception ex) {
			WB.addLog("LocInt.getLocal(List<String>, String):String, ex=" + ex.getMessage(), "", "LocInt");
		}
		return res;
	}

	private static List<String> getListStrLocal(String initStr) throws Exception {
		// origin - 02.07.2024, last edit - 13.06.2025
		List<String> res = new ArrayList<String>();
		try {
			initStr = Etc.fixTrim(initStr);
			String[] tmp = initStr.split("]");
			String currTmp = "";
			for (var currArr : tmp) {
				currTmp = "";
				currTmp = Etc.fixTrim(currArr);
				if ((Etc.strContains(currArr, "[")) && //// if has "anyword["
						(Etc.strContains(currArr, "]") == false)) { //// if not has "]" then add
																	//// "]"
					currTmp = currTmp + "]";
				}
				res.add(currTmp);
			}

		} catch (Exception ex) {
			WB.addLog("LocInt.getListStrLocal(String):List<String>, ex=" + ex.getMessage(), "", "LocInt");
		}
		return res;
	}

	private static String delStrLang(String initStr) throws Exception {
		// origin - 30.06.2024, last edit - 13.06.2025
		String res = Etc.fixTrim(initStr);
		try {
			if (Etc.strContains(initStr, "[")) {
				int posLocalSplitLeft = initStr.indexOf("["); // pos "["
				if (posLocalSplitLeft > 0) {
					res = initStr.substring(0, posLocalSplitLeft); // ex. "Profit[En]" --> "Profit"
				}
			}
		} catch (Exception ex) {
			WB.addLog("LocInt.delStrLang(String):String, ex=" + ex.getMessage(), "", "Etc");
		}
		return res;
	}

	private LocInt() throws Exception {
		// origin - 04.11.2024, last edit - 08.03.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 03.03.2026, last edit - 03.03.2026
		try {
		} catch (Exception ex) {
			WB.addLog("LocInt.clear():void, ex=" + ex.getMessage(), "", "LocInt");
		}
	}

	public static void test() throws Exception {
		// origin - 02.07.2024, last edit - 16.03.2026
		try {

//			WB.addLog2("LocInt.test.getLocal(List<String>):String", "", "LocInt");
//			for (var tmp1 : new String[] { "8-701-111-11-11", "Доходы", "Доходы[RU]", "Доходы[Ru]",
//					"Доходы[RU]Tабыстар[Қаз]", "Доходы[RU]Profit[EN]", "Доходы[RU]Profit[En]", "Доходы[RU]Revenu[FR]",
//					"Доходы[RU]Tabystar[Qaz]", "Доходы[RU]Tabystar[QAZ]" }) {
//				for (var tmp2 : LocInt.langMap.entrySet()) {
//					String key = tmp2.getKey();
//					WB.addLog2("LocInt.test.getLocal, res=" + LocInt.getLocal(tmp1, key) + ", tmp1=" + tmp1
//							+ ", tmp2.key=" + key, "", "LocInt");
//				}
//			}

//			WB.addLog2("LocInt.test.isAnyLang(String):boolean", "", "LocInt");
//			for (var tmp1 : new String[] { "8-701-111-11-11", "Доходы", "Доходы[RU]", "Доходы[Ru]",
//					"Доходы[RU]Tабыстар[Қаз]", "Доходы[RU]Profit[EN]", "Доходы[RU]Profit[En]", "Доходы[RU]Revenu[FR]",
//					"Доходы[RU]Tabystar[Qaz]", "Доходы[RU]Tabystar[QAZ]" }) {
//				WB.addLog2("LocInt.test.isAnyLang(String):boolean, res=" + LocInt.isAnyLang(tmp1) + ", tmp1=" + tmp1, "","LocInt");
//			}

//			WB.addLog2("LocInt.test.getListStrLocal(String):List<String>", "", "LocInt");
//			for (var tmp1 : new String[] { "8-701-111-11-11", "Доходы", "Доходы[RU]", "Доходы[Ru]",
//					"Доходы[RU]Tабыстар[Қаз]", "Доходы[RU]Profit[EN]", "Доходы[RU]Profit[En]", "Доходы[RU]Revenu[FR]",
//					"Доходы[RU]Tabystar[Qaz]", "Доходы[RU]Tabystar[QAZ]" }) {
//				var tmp2 = LocInt.getListStrLocal(tmp1);
//				WB.addLog2(
//						"LocInt.test.getListStrLocal(String):List<String>, res.size=" + tmp2.size() + ", tmp1=" + tmp1,
//						"", "LocInt");
//				WB.log(tmp2, "LocInt");
//			}

//			WB.addLog2("LocInt.test.delStrLang(String):String", "", "LocInt");
//			for (var tmp1 : new String[] { "8-701-111-11-11", "Доходы", "Доходы[RU]", "Доходы[Ru]",
//					"Доходы[RU]Tабыстар[Қаз]", "Доходы[RU]Profit[EN]", "Доходы[RU]Profit[En]", "Доходы[RU]Revenu[FR]",
//					"Доходы[RU]Tabystar[Qaz]", "Доходы[RU]Tabystar[QAZ]" }) {
//				WB.addLog2("LocInt.test.delStrLang(String):String, res=" + LocInt.delStrLang(tmp1) + ", tmp1=" + tmp1, "", "LocInt");
//			}

		} catch (Exception ex) {
			WB.addLog("LocInt.test():void, ex=" + ex.getMessage(), "", "LocInt");
		}
	}
}