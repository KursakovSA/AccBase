import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public final class SPL {
	// origin - 17.10.2024, last edit - 25.03.2026
	public String context, src, asWord;
	public List<String> groupList;
	public double valDbl;
	public static List<String> innerGroupNameList, hundredList, tenList, unitList;
	public static SawListVal secondThirdList, groupName, groupNameDefault, correctGroupName, integerPartName,
			fractionPartName, shiftList;
	public static String contextDefault, tenSkip;

	static {
		try {
			SPL.groupNameDefault = new SawListVal(
					"hundred; |thousand;тысяча|million;миллион|billion;миллиард|trillion;триллион|");

			SPL.groupName = new SawListVal("1;thousand;тысяча|2;3;4;thousand;тысячи|5;6;7;8;9;thousand;тысяч|"
					+ "1;million;миллион|2;3;4;million;миллиона|5;6;7;8;9;million;миллионов|1;billion;миллиард|"
					+ "2;3;4;billion;миллиарда|5;6;7;8;9;billion;миллиардов|1;trillion;триллион|2;3;4;trillion;триллиона|"
					+ "5;6;7;8;9;trillion;триллионов|");

			SPL.correctGroupName = new SawListVal(SPL.getCorrectGroupNameStr());

			SPL.innerGroupNameList = List.of((";hundred;thousand;million;billion;trillion").split(";"));

			SPL.hundredList = List
					.of((";сто;двести;триста;четыреста;пятьсот;шестьсот;семьсот;восемьсот;девятьсот").split(";"));

			SPL.tenList = List
					.of((";десять;двадцать;тридцать;сорок;пятьдесят;шестьдесят;семьдесят;восемьдесят;девяносто")
							.split(";"));

			SPL.unitList = List.of((";один;два;три;четыре;пять;шесть;семь;восемь;девять;").split(";"));

			SPL.secondThirdList = new SawListVal(
					"10;десять|11;одиннадцать|12;двенадцать|13;тринадцать|14;четырнадцать|15;пятнадцать|"
							+ "16;шестнадцать|17;семнадцать|18;восемнадцать|19;девятнадцать|20;двадцать|30;тридцать|40;сорок|"
							+ "50;пятьдесят|60;шестьдесят|70;семьдесят|80;восемьдесят|90;девяносто|");

			SPL.integerPartName = new SawListVal("amount;00;тенге|quantity;1;целых|");

			SPL.fractionPartName = new SawListVal(
					"amount;0;тиын|amount;1;тиын|amount;2;тиын|amount;3;тиын|amount;4;тиын|quantity;1;десятых|quantity;2;сотых|quantity;3;тысячных|quantity;4;десятитысячных|");

			SPL.contextDefault = "amount";

			SPL.shiftList = new SawListVal("один тысяча;одна тысяча|один тысячи;одна тысяча|"
					+ "два тысяча;две тысячи|два тысячи;две тысячи|три тысяча;три тысячи|"
					+ "четыре тысяча;четыре тысячи|пять тысяча;пять тысяч|пять тысячи;пять тысяч|"
					+ "шесть тысяча;шесть тысяч|шесть тысячи;шесть тысяч|"
					+ "семь тысяча;семь тысяч|семь тысячи;семь тысяч|"
					+ "восемь тысяча;восемь тысяч|восемь тысячи;восемь тысяч|"
					+ "девять тысяча;девять тысяч|девять тысячи;девять тысяч|");

			SPL.tenSkip = "00;10;11;12;13;14;15;16;17;18;19;20;30;40;50;60;70;80;90;";

		} catch (Exception ex) {
			WB.addLog("SPL.static ctor, ex=" + ex.getMessage(), "", "SPL");
		}
	}

	public static String get(List<String> arg) throws Exception {
		// origin - 25.03.2026, last edit - 26.03.2026
		String res = "";
		try {
			if (arg.size() == 1) { // ex. "14 000"
				res = new SPL(arg.getFirst()).asWord;
			}
			if (arg.size() == 2) { // ex. "14 000; quautity"
				res = new SPL(arg.getFirst(), arg.getLast()).asWord;
			}
			if (arg.size() > 2) { // ex. "14 000; ...... quautity"
				res = new SPL(arg.getFirst(), arg.getLast()).asWord;
			}
		} catch (Exception ex) {
			WB.addLog("SPL.get(List<String>):String, ex=" + ex.getMessage(), "", "SPL");
		}
		return res;
	}

	private static String getCorrectGroupNameStr() throws Exception {
		// origin - 13.03.2026, last edit - 23.03.2026
		String res = "";
		try {
			String common = "100;200;300;400;500;600;700;800;900"; // that not repeat
			res = res + common + ";thousand;тысяч|" + common + ";million;миллионов|" + common + ";billion;миллиардов|"
					+ common + ";trillion;триллионов|";

			common = "010;011;012;013;014;015;016;017;018;019;020;030;040;050;060;070;080;090"; // that not repeat
			res = res + common + ";thousand;тысяч|" + common + ";million;миллионов|" + common + ";billion;миллиардов|"
					+ common + ";trillion;триллионов|";

			res = res + "001;thousand;тысяча|" + "002;003;004;thousand;тысячи|" + "005;006;007;008;009;thousand;тысяч|"
					+ "001;million;миллион|" + "002;003;004;million;миллиона|"
					+ "005;006;007;008;009;million;миллионов|" + "001;billion;миллиард|"
					+ "002;003;004;billion;миллиарда|" + "005;006;007;008;009;billion;миллиардов|"
					+ "001;trillion;триллион|" + "002;003;004;trillion;триллиона|"
					+ "005;006;007;008;009;trillion;триллионов|";
		} catch (Exception ex) {
			WB.addLog("SPL.getCorrectGroupNameStr():String, ex=" + ex.getMessage(), "", "SPL");
		}
		return res;
	}

	private void getGroupList() throws Exception {
		// origin - 10.03.2026, last edit - 16.03.2026
		List<String> groupList1 = new ArrayList<String>();
		List<String> groupList2 = new ArrayList<String>();
		try {
			// prepare list ex. groupList2=[007, 155, 674] for 7 155 674
			DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.US);
			symbols.setGroupingSeparator(' ');
			DecimalFormat df = new DecimalFormat("#,###", symbols);
			double integerPart = this.valDbl - (this.valDbl % 1);
			groupList1 = Arrays.asList(df.format(integerPart).split(" "));

			if (groupList1.size() == 0) {
				groupList1.add("0");
			}

			// processing list ex. groupList2=[015;thousand, 674;hundred] for 15 674
			Collections.reverse(groupList1);
			var count = 0;
			var tmp = "";
			for (var curr : groupList1) {
				tmp = "";
				count = count + 1;
				tmp = curr + ";" + SPL.innerGroupNameList.get(count);
				groupList2.add(tmp);
			}

			Collections.reverse(groupList1);
			Collections.reverse(groupList2);

			this.groupList.addAll(groupList2);
		} catch (Exception ex) {
			WB.addLog("SPL.getGroupList():void, ex=" + ex.getMessage(), "", "SPL");
		}
	}

	private static String getHundredGroup(String firstNumberGroup) throws Exception {
		// origin - 16.03.2026, last edit - 16.03.2026
		String res = "";
		try {
			res = SPL.hundredList.get(Integer.valueOf(firstNumberGroup));
			res = Etc.addLeaderPlaceholder(res, " ");
		} catch (Exception ex) {
			WB.addLog("SPL.getHundredGroup(String):String, ex=" + ex.getMessage(), "", "SPL");
		}
		return res;
	}

	private static String getTenGroup(String secondNumberGroup, String thirdNumberGroup) throws Exception {
		// origin - 11.03.2026, last edit - 16.03.2026
		String res = "";
		try {
			var tmp1 = SPL.tenList.get(Integer.valueOf(secondNumberGroup));
			if (tmp1.isEmpty() == false) {
				res = tmp1;
			}

			var secondThird = secondNumberGroup + thirdNumberGroup;
			var tmp2 = SPL.secondThirdList.getVal(secondThird);
			if (tmp2.isEmpty() == false) {
				res = tmp2;
			}

			res = Etc.addLeaderPlaceholder(res, " ");
		} catch (Exception ex) {
			WB.addLog("SPL.getTenGroup(2String):String, ex=" + ex.getMessage(), "", "SPL");
		}
		return res;
	}

	private static String getUnitGroup(String secondNumberGroup, String thirdNumberGroup) throws Exception {
		// origin - 11.03.2026, last edit - 25.03.2026
		String res = "";
		try {
			res = SPL.unitList.get(Integer.valueOf(thirdNumberGroup)); // ex. "один", "два"....for "1","2"....

			var secondThird = secondNumberGroup + thirdNumberGroup + ";"; // ex. "50;" from "250"
			// String tenSkip = "00;10;11;12;13;14;15;16;17;18;19;20;30;40;50;60;70;80;90;";
			if (Etc.strContains(SPL.tenSkip, secondThird)) {
				res = "";
			}

			res = Etc.addLeaderPlaceholder(res, " ");
		} catch (Exception ex) {
			WB.addLog("SPL.getUnitGroup(2String):String, ex=" + ex.getMessage(), "", "SPL");
		}
		return res;
	}

	private static String getGroupName(String number, String numberRank) throws Exception {
		// origin - 11.03.2026, last edit - 23.03.2026
		String res = "";
		try {
			var lastNumberGroup = number.substring(number.length() - 1) + ";"; // ex. "3;" for "413", etc.
			res = SPL.groupName.getVal(lastNumberGroup, numberRank);

			var tmp = SPL.correctGroupName.getVal(number, numberRank);
			if (tmp.isEmpty() == false) {
				res = tmp;
			}

			res = Etc.addLeaderPlaceholder(res, " ");
		} catch (Exception ex) {
			WB.addLog("SPL.getGroupName(2String):String, ex=" + ex.getMessage(), "", "SPL");
		}
		return res;
	}

	private void getAsWord() throws Exception {
		// origin - 11.03.2026, last edit - 23.03.2026
		String tmp = "";
		try {
			var firstNumberGroup = "";
			var secondNumberGroup = "";
			var thirdNumberGroup = "";
			var number = ""; // ex. "163", "96", "4", etc.
			var rankGroup = ""; // ex. ";hundred", ";thousand", etc.

			for (var curr : this.groupList) { // ex. groupList=[7;million, 156;thousand, 674;hundred] for 7156674
				curr = Etc.fixTrim(curr);
				number = List.of(curr.split(";")).get(0); // ex. "156" from "156;thousand"
				number = ("000" + number);
				number = number.substring(number.length() - 3);
				rankGroup = List.of(curr.split(";")).get(1); // ex. "thousand" from "156;thousand"

				firstNumberGroup = number.substring(0, 1); // ex. "1" from "156", "0" from "067"
				tmp = tmp + SPL.getHundredGroup(firstNumberGroup);

				secondNumberGroup = number.substring(1, 2); // ex. "5" from "156", "0" from "004"
				thirdNumberGroup = number.substring(2, 3); // ex. "6" from "156"
				tmp = tmp + SPL.getTenGroup(secondNumberGroup, thirdNumberGroup);

				tmp = tmp + SPL.getUnitGroup(secondNumberGroup, thirdNumberGroup);
				if (tmp.isEmpty()) { // spec case ex. "0.34"
					tmp = "0";
				}
				tmp = tmp + SPL.getGroupName(number, rankGroup);
			}

			// shift, ex. "два тысяча" -> "две тысячи", etc.
			for (var curr : SPL.shiftList.val) {
				tmp = tmp.replace(List.of(curr.split(";")).getFirst(), SPL.shiftList.getVal(curr));
			}

			tmp = tmp + this.getIntegerPartName();
			tmp = tmp + this.getFraction();

			this.asWord = Etc.fixTrim(tmp);
		} catch (Exception ex) {
			WB.addLog("SPL.getAsWord():void, ex=" + ex.getMessage(), "", "SPL");
		}
	}

	private String getIntegerPartName() throws Exception {
		// origin - 15.03.2026, last edit - 16.03.2026
		String res = "";
		try {
			res = SPL.integerPartName.getVal(this.context);

			if (res.isEmpty()) {
				res = SPL.integerPartName.getVal(SPL.contextDefault + ";");
			}

			res = Etc.addLeaderPlaceholder(res, " ");
		} catch (Exception ex) {
			WB.addLog("SPL.getIntegerPartName():String, ex=" + ex.getMessage(), "", "SPL");
		}
		return res;
	}

	private String getFractionName(String fractionPart) throws Exception {
		// origin - 15.03.2026, last edit - 22.03.2026
		String res = "";
		try {
			res = SPL.fractionPartName.getVal(this.context, String.valueOf(fractionPart.length()));

			if (res.isEmpty()) {
				res = SPL.fractionPartName.getVal(SPL.contextDefault + ";");
			}

			res = Etc.addLeaderPlaceholder(res, " ");
		} catch (Exception ex) {
			WB.addLog("SPL.getFractionName():String, ex=" + ex.getMessage(), "", "SPL");
		}
		return res;
	}

	private String getFraction() throws Exception {
		// origin - 15.03.2026, last edit - 16.03.2026
		String res = "";
		try {
			if (Etc.strContains(this.src, ".") == false) {
				return res = "";
			}

			double tmp = Etc.roundCustom((this.valDbl % 1), 2);
			res = String.valueOf(tmp).replace(".", "");
			res = Etc.delLeaderPlaceholder(res, "0");

			if (res.length() < 2) {
				res = (res + "00").substring(0, 2);
			}

			res = " " + res + " " + Etc.fixTrim(this.getFractionName(res));
		} catch (Exception ex) {
			WB.addLog("SPL.getFraction():String, ex=" + ex.getMessage(), "", "SPL");
		}
		return res;
	}

	public SPL(String Src, String Context) throws Exception {
		// origin - 19.10.2024, last edit - 05.08.2026
		this.clear();
		this.src = Etc.fixTrim(Src);
		this.context = DefVal.set(Context, SPL.contextDefault);
		this.valDbl = Etc.getDoubleByStr(this.src);
		this.getGroupList();
		this.getAsWord();
	}

	public SPL(String Src) throws Exception {
		// origin - 17.10.2024, last edit - 05.08.2026
		this.clear();
		this.src = Etc.fixTrim(Src);
		this.context = SPL.contextDefault;
		var tmp = Etc.delStr(this.src, " ");
		this.valDbl = Etc.getDoubleByStr(tmp);
		this.getGroupList();
		this.getAsWord();
	}

	private void clear() throws Exception {
		// origin - 10.03.2026, last edit - 15.03.2026
		try {
			this.context = this.src = this.asWord = "";
			this.valDbl = 0.0;
			this.groupList = new ArrayList<String>();
		} catch (Exception ex) {
			WB.addLog("SPL.clear():void, ex=" + ex.getMessage(), "", "SPL");
		}
	}

	public String toString() {
		// origin - 17.10.2024, last edit - 23.03.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(", context ", this.context);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", asWord ", this.asWord);
			// res = res + Fmtr.addIfNotEmpty(", valDbl ", this.valDbl);
			// res = res + Fmtr.addIfNotEmpty(", groupList ", this.groupList);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 17.10.2024, last edit - 26.03.2026
		try {

//			WB.addLog2("SPL.test.get(List<String>):String", "", "SPL");
//			for (var tmp1 : new String[] { "13 000", "45 000;quantity", "60 000;", "147 849;tralala;quantity" }) {
//				var tmp2 = List.of(tmp1.split(";"));
//				WB.addLog2(
//						"SPL.test.get(List<String>):String, res=" + SPL.get(tmp2) + ", tmp1=" + tmp1 + ", tmp2=" + tmp2,
//						"", "SPL");
//			}

//			WB.addLog2("SPL.test.ctor(String)", "", "SPL");
//			for (var tmp1 : new String[] { "0.13", "1", "2", "03", "7", "10", "11", "12", "21", "22", "16", "316", "45",
//					"60", "91", "92", "93", "345", "360", "564.20", "713", "1 100", "1 101", "1 102", "2 100", "5 100",
//					"7 894.1356", "13 000", "45 000", "60 000", "147 849", "341 883", "342 883", "7 155 674.89",
//					"11 090 965", "12 090 965", "19 090 965", "101 090 965", "102 090 965", "109 090 965",
//					"51 109 090 965", "52 209 090 965", "571 109 090 965", "57 109 090 965", "4 578 109 090 965" }) {
//				WB.addLog2("SPL.test.ctor(String), SPL=" + new SPL(tmp1), "", "SPL");
//			}

//			WB.addLog2("SPL.test.ctor(2String)", "", "SPL");
//			for (var tmp1 : new String[] { "0.13", "7", "16", "316", "45", "345", "60", "360", "93", "713", "13000",
//					"45000", "60000", "147849", "341883", "7894.1356", "564.20", "7155674.89", "109090965",
//					"4578109090965", "03", "5100" }) {
//				for (var tmp2 : new String[] { SPL.contextDefault, "quantity", "tralala" }) {
//					WB.addLog2("SPL.test.ctor(2String), SPL.asWord=" + new SPL(tmp1, tmp2).asWord + ", src=" + tmp1
//							+ ", context=" + tmp2, "", "SPL");
//				}
//			}

//			WB.addLog2("SPL.test.correctGroupName.getVal(2String):String", "", "SPL");
//			for (var tmp1 : List.of(("001;002;003;004;005;006;007;008;009;010;011;012;100;155").split(";"))) {
//				for (var tmp2 : List.of(("thousand;million;billion").split(";"))) {
//					var tmp3 = SPL.correctGroupName.getVal(tmp1, tmp2);
//					WB.addLog2("SPL.test.correctGroupName.getVal(2String):String, res=" + tmp3 + ", tmp1=" + tmp1
//							+ ", tmp2=" + tmp2, "", "SPL");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("SPL.test():void, ex=" + ex.getMessage(), "", "SPL");
		}
	}
}