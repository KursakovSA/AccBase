import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public final class ZIP {
	// origin - 18.09.2025, last edit - 26.02.2026

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("ZIP.static ctor, ex=" + ex.getMessage(), "", "ZIP");
		}
	}

	public static List<String> getUnzipByDir(String dir) throws Exception {
		// origin - 25.02.2026, last edit - 02.03.2026
		List<String> res = new ArrayList<String>();
		try {
			var pathFileList = InOut.getPathFileByDir(dir);
			for (var curr : pathFileList) {
				res.add(ZIP.getUnzip(curr));
			}
		} catch (Exception ex) {
			WB.addLog("ZIP.getUnzipByDir(String):List<String>, ex=" + ex.getMessage(), "", "ZIP");
		}
		return res;
	}

	public static List<String> getUnzip(List<String> pathFileList) throws Exception {
		// origin - 25.02.2026, last edit - 02.03.2026
		List<String> res = new ArrayList<String>();
		try {
			for (var curr : pathFileList) {
				if (curr.endsWith(".zip") == false) {
					continue;
				}
				res.add(ZIP.getZip(curr));
			}
		} catch (Exception ex) {
			WB.addLog("ZIP.getUnzip(List<String>):List<String>, ex=" + ex.getMessage(), "", "ZIP");
		}
		return res;
	}

	public static String getUnzip(String pathFile) throws Exception {
		// origin - 23.02.2026, last edit - 26.02.2026
		String res = "";
		try {
			if (InOut.hasFile(pathFile) == false) {
				WB.addLog2("ZIP.getUnzip(String):String, not exist pathFile=" + pathFile, "", "ZIP");
				return "";
			}

			if (pathFile.endsWith(".zip") == false) {
				WB.addLog2("ZIP.getUnzip(String):String, not zip file=" + pathFile, "", "ZIP");
				return "";
			}

			boolean isUnziped = false;
			try (ZipInputStream zis = new ZipInputStream(new FileInputStream(pathFile))) {
				ZipEntry entry = zis.getNextEntry();
				while (entry != null) {
					File newFile = new File(Paths.get(pathFile).getParent().toString(), entry.getName());
					try (FileOutputStream fos = new FileOutputStream(newFile)) {
						byte[] buffer = new byte[1024];
						int len;
						while ((len = zis.read(buffer)) > 0) {
							fos.write(buffer, 0, len);
						}
						res = newFile.getPath();
					}
					entry = zis.getNextEntry();
				}
				zis.closeEntry();
				isUnziped = true;
			} catch (Exception ex) {
				WB.addLog("ZIP.getUnzip(String):String, ex=" + ex.getMessage(), "", "ZIP");
			}
			if (isUnziped) {
				InOut.delFile(pathFile); // remove source file because not need it next
			}
		} catch (Exception ex) {
			WB.addLog("ZIP.getUnzip(String):String, ex=" + ex.getMessage(), "", "ZIP");
		}
		return res;
	}

	public static List<String> getZipByDir(String dir) throws Exception {
		// origin - 23.02.2026, last edit - 02.03.2026
		List<String> res = new ArrayList<String>();
		try {
			var pathFileList = InOut.getPathFileByDir(dir);
			for (var curr : pathFileList) {
				res.add(ZIP.getZip(curr));
			}
		} catch (Exception ex) {
			WB.addLog("ZIP.getZipByDir(String):List<String>, ex=" + ex.getMessage(), "", "ZIP");
		}
		return res;
	}

	public static List<String> getSingleZip(List<String> pathFileList, String pathOutputFile) throws Exception {
		List<String> res = new ArrayList<String>();
		// origin - 03.03.2026, last edit - 25.03.2026
		try {
			try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(pathOutputFile))) {
				for (var srcFile : pathFileList) {
					File fileToZip = new File(srcFile);
					if (!fileToZip.exists()) {
						WB.addLog2("ZIP.getSingleZip(List<String>, String):String, not exist file=" + fileToZip, "",
								"ZIP");
						continue;
					}

					try (FileInputStream fis = new FileInputStream(fileToZip)) {
						ZipEntry zipEntry = new ZipEntry(fileToZip.getName());
						zos.putNextEntry(zipEntry);
						byte[] buffer = new byte[1024];
						int length;
						while ((length = fis.read(buffer)) >= 0) {
							zos.write(buffer, 0, length);
						}
						zos.closeEntry();
						res.add(srcFile);
					}
				}
			}
			InOut.delFile(res); // remove source files because not need it next
		} catch (Exception ex) {
			WB.addLog("ZIP.getSingleZip(List<String>, String):List<String>, ex=" + ex.getMessage(), "", "ZIP");
		}
		return res;
	}

	public static List<String> getZip(List<String> pathFileList) throws Exception {
		List<String> res = new ArrayList<String>();
		// origin - 23.02.2026, last edit - 26.02.2026
		try {
			for (var curr : pathFileList) {
				res.add(ZIP.getZip(curr));
			}
		} catch (Exception ex) {
			WB.addLog("ZIP.getZip(List<String>):List<String>, ex=" + ex.getMessage(), "", "ZIP");
		}
		return res;
	}

	public static String getZip(String pathFile) throws Exception {
		// origin - 23.02.2026, last edit - 26.02.2026
		String res = "";
		try {
			if (InOut.hasFile(pathFile) == false) {
				WB.addLog2("ZIP.getZip(String):String, not exist pathFile=" + pathFile, "", "ZIP");
				return "";
			}

			boolean isZiped = false;
			var outputFile = pathFile + ".zip";
			try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(outputFile))) {
				File fileToZip = new File(pathFile);
				try (FileInputStream fis = new FileInputStream(fileToZip)) {

					// create entry in zip
					ZipEntry zipEntry = new ZipEntry(fileToZip.getName());
					zos.putNextEntry(zipEntry);

					// copy file into zip
					byte[] buffer = new byte[1024];
					int length;
					while ((length = fis.read(buffer)) >= 0) {
						zos.write(buffer, 0, length);
					}
					zos.closeEntry();
					isZiped = true;
				}
				if (isZiped) {
					res = outputFile;
					InOut.delFile(pathFile); // remove source file because not need it next
				}
			}
		} catch (Exception ex) {
			WB.addLog("ZIP.getZip(String):String, ex=" + ex.getMessage(), "", "ZIP");
		}
		return res;
	}

	private ZIP() throws Exception {
		// origin - 18.09.2025, last edit - 18.09.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 18.09.2025, last edit - 18.09.2025
		try {
		} catch (Exception ex) {
			WB.addLog("ZIP.clear():void, ex=" + ex.getMessage(), "", "ZIP");
		}
	}

	public static void test() throws Exception {
		// origin - 18.09.2025, last edit - 25.03.2026
		try {

//			{
//				WB.addLog2("ZIP.test.getSingleZip(List<String>;String):String", "", "ZIP");
//				var tmp1 = WB.tempDir;
//				var tmp2 = InOut.getPathFileListByDir(List.of("Face.csv", "Geo.csv", "Slice.csv"), tmp1);
//				var tmp3 = tmp1 + File.separator + "output.zip";
//				WB.addLog2("ZIP.test.getSingleZip(List<String>,String):String, res=" + ZIP.getSingleZip(tmp2, tmp3)
//						+ ", tmp2=" + tmp2 + ", tmp3=" + tmp3, "", "ZIP");
//			}

//			WB.addLog2("ZIP.test.getUnzipByDir(String):List<String>", "", "ZIP");
//			for (var tmp1 : new String[] { WB.tempDir, WB.inputOutputDir }) {
//				WB.addLog2("ZIP.test.getUnzipByDir(String):List<String>, res=" + ZIP.getUnzipByDir(tmp1) + ", tmp1="
//						+ tmp1, "", "ZIP");
//			}

//			{
//				WB.addLog2("ZIP.test.getUnzip(String):String", "", "ZIP");
//				var tmp1 = List.of("Face.csv.zip", "Slice.csv.zip", "Geo.csv.zip");
//				var tmp2 = InOut.getPathFileListByDir(tmp1, WB.tempDir);
//				for (var tmp3 : tmp2) {
//					WB.addLog2("ZIP.test.getUnzip(String):String, res=" + ZIP.getUnzip(tmp3) + ", tmp3=" + tmp3, "",
//							"ZIP");
//				}
//			}

//			WB.addLog2("ZIP.test.getZipByDir(String):List<String>", "", "ZIP");
//			for (var tmp1 : new String[] { WB.tempDir, WB.inputOutputDir }) {
//				WB.addLog2("ZIP.test.getZipByDir(String):List<String>, res=" + ZIP.getZipByDir(tmp1) + ", tmp1=" + tmp1,
//						"", "ZIP");
//			}

//			{
//				WB.addLog2("ZIP.test.getZip(List<String>):List<String>", "", "ZIP");
//				var tmp1 = List.of("Face.csv", "Slice.csv", "Geo.csv");
//				var tmp2 = InOut.getPathFileListByDir(tmp1, WB.tempDir);
//				WB.addLog2("ZIP.test.getZip(List<String>):List<String>, res=" + ZIP.getZip(tmp2) + ", tmp2=" + tmp2, "",
//						"ZIP");
//			}

//			WB.addLog2("ZIP.test.getZip(String):String", "", "ZIP");
//			for (var tmp1 : new String[] { "Face.csv", "Slice.csv", "Geo.csv" }) {
//				var tmp2 = WB.tempDir + File.separator + tmp1;
//				WB.addLog2("ZIP.test.getZip(String):String, res=" + ZIP.getZip(tmp2) + ", tmp2=" + tmp2, "", "ZIP");
//			}

		} catch (Exception ex) {
			WB.addLog("ZIP.test():void, ex=" + ex.getMessage(), "", "ZIP");
		}
	}
}