import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.concurrent.ThreadLocalRandom;

public final class Num {
	// origin - 15.09.2026, last edit - 15.09.2026
	public static int round0, round2, roundDefault, round4, initRndDefault;

	static {
		try {
			Num.round0 = Num.initRndDefault = 0;
			Num.round2 = Num.roundDefault = 2;
			Num.round4 = 4;
		} catch (Exception ex) {
			WB.addLog("Num.static ctor, ex=" + ex.getMessage(), "", "Num");
		}
	}

	public static double divide(double divide1, double divide2) throws Exception {
		// origin - 01.09.2026, last edit - 01.09.2026
		double res = 0.0;
		try {
			if (divide2 == 0.0) {
				divide2 = 1.0;
			}
			// BigDecimal tmp1 = new BigDecimal(String.valueOf(divide1));
			// BigDecimal tmp2 = new BigDecimal(String.valueOf(divide2));
			BigDecimal tmp1 = BigDecimal.valueOf(divide1);
			BigDecimal tmp2 = BigDecimal.valueOf(divide2);
			BigDecimal tmp3 = tmp1.divide(tmp2, new MathContext(5, RoundingMode.HALF_UP));
			res = tmp3.doubleValue();
		} catch (Exception ex) {
			WB.addLog("Num.divide(2double):double, ex=" + ex.getMessage(), "", "Num");
		}
		return res;
	}

	public static double multiply(double multiply1, double multiply2) throws Exception {
		// origin - 15.02.2025, last edit - 01.09.2026
		double res = 0.0;
		try {
			// BigDecimal tmp1 = new BigDecimal(String.valueOf(multiply1));
			// BigDecimal tmp2 = new BigDecimal(String.valueOf(multiply2));
			BigDecimal tmp1 = BigDecimal.valueOf(multiply1);
			BigDecimal tmp2 = BigDecimal.valueOf(multiply2);
			BigDecimal tmp3 = tmp1.multiply(tmp2);
			res = tmp3.doubleValue();
		} catch (Exception ex) {
			WB.addLog("Num.multiply(2double):double, ex=" + ex.getMessage(), "", "Num");
		}
		return res;
	}

	public static double add(double add1, double add2) throws Exception {
		// origin - 15.02.2025, last edit - 13.06.2025
		double res = 0.0;
		try {
			BigDecimal tmp1 = new BigDecimal(String.valueOf(add1));
			BigDecimal tmp2 = new BigDecimal(String.valueOf(add2));
			BigDecimal tmp3 = tmp1.add(tmp2);
			res = tmp3.doubleValue();
		} catch (Exception ex) {
			WB.addLog("Num.add(2double):double, ex=" + ex.getMessage(), "", "Num");
		}
		return res;
	}

	public static int getIntByStr(String initValue) throws Exception {
		// origin - 03.09.2024, last edit - 05.08.2026
		int res = 0;
		initValue = Fmtr.fixForDoubleByStr(initValue);
		try {
			if ((initValue != null) && (initValue.isEmpty() == false)) {
				res = Integer.parseInt(initValue);
			} else {
				res = 0;
			}
		} catch (Exception ex) {
			WB.addLog("Num.getIntByStr(String):int, ex=" + ex.getMessage(), "", "Num");
			res = 0;
		}
		return res;
	}

	public static double getDoubleByStr(String initVal) throws Exception {
		// origin - 07.01.2024, last edit - 05.08.2026
		double res = 0.0;
		initVal = Fmtr.fixForDoubleByStr(initVal);

		try {
			if (initVal.isEmpty() == false) {
				res = Double.parseDouble(initVal);
			} else {
				res = 0.0;
			}
		} catch (Exception ex) {
			WB.addLog("Num.getDoubleByStr(String):double, ex=" + ex.getMessage() + ", initVal=" + initVal, "", "Num");
			res = 0.0;
		}
		return res;
	}

	public static String getStrIntRnd(int lenghtStrIntRnd) throws Exception {// sectoral pawnshop
		// origin - 26.06.2024, last edit - 15.09.2026
		String res = "";
		try {
			for (int i = 0; i < lenghtStrIntRnd; i++) {
				res = res + Num.getIntRnd(9);
			}
		} catch (Exception ex) {
			WB.addLog("Num.getStrIntRnd(int):String, ex=" + ex.getMessage(), "", "Num");
		}
		return res;
	}

	public static int getIntRnd(int initVal) throws Exception {
		// origin - 16.02.2024, last edit - 13.06.2025
		int res = 0;
		try {
			if (initVal == 0) {
				initVal = 100000;
			}
			// Random random = new Random();
			// res = random.nextInt(initVal);
			res = ThreadLocalRandom.current().nextInt(initVal);
		} catch (Exception ex) {
			WB.addLog("Num.getIntRnd(int):int, ex=" + ex.getMessage(), "", "Num");
		}
		return res;
	}

	public static double reverseRatio(double numb) throws Exception {
		// origin - 30.01.2025, last edit - 13.06.2025
		double res = 0.0;
		try {
			if (numb != 0.0) {
				res = 1.0 / numb;
			}
		} catch (Exception ex) {
			WB.addLog("Num.reverseRatio(double):double, ex=" + ex.getMessage(), "", "Num");
		}
		return res;
	}

	public static double ratio100(double ratePercent) throws Exception {
		// origin - 17.10.2023, last edit - 13.06.2025
		double res = 0.0;
		try {
			res = ratePercent / 100.0;
		} catch (Exception ex) {
			WB.addLog("Num.ratio100(double):double, ex=" + ex.getMessage(), "", "Num");
		}
		return res;
	}

	public static double roundDebt(double sum, String context) throws Exception {
		// origin - 16.01.2024, last edit - 15.09.2026
		double res = sum;
		try {
			if (context.isEmpty()) {
				res = roundCustom(sum, Num.round2); // with cents
			}

			if (Etc.strContains(context, Debt.contextSalaryTaxQazaqstan)) { // no cents
				res = roundCustom(sum, Num.round0);
			}
		} catch (Exception ex) {
			WB.addLog("Num.roundDebt(double, String):double, ex=" + ex.getMessage(), "", "Num");
		}
		res = DefVal.set(res);// set 0, if < 0
		return res;
	}

	public static double roundCustom(double sum) throws Exception {
		// origin - 17.10.2023, last edit - 15.09.2026
		// variant round less number fractional digit as argument, take him = 2
		double res = sum;
		try {
			res = roundCustom(sum, Num.roundDefault); // default round
		} catch (Exception ex) {
			WB.addLog("Num.roundCustom(double):double, ex=" + ex.getMessage(), "", "Num");
		}
		return res;
	}

	public static double roundCustom(double sum, int numberFractionalDigit) throws Exception {
		// origin - 16.10.2023, last edit - 13.06.2025
		double res = sum;
		try {
			int power10 = (int) Math.pow(10, numberFractionalDigit);
			res = sum * power10;
			res = Math.round(res);
			res = res / power10;
		} catch (Exception ex) {
			WB.addLog("Num.roundCustom(double, int):double, ex=" + ex.getMessage(), "", "Num");
		}
		return res;
	}

	private Num() {
		// origin - 17.09.2026, last edit - 17.09.2026
	}

	public static void test() throws Exception {
		// origin - 15.09.2026, last edit - 15.09.2026
		try {

		} catch (Exception ex) {
			WB.addLog("Num.test():void, ex=" + ex.getMessage(), "", "Num");
		}
	}
}