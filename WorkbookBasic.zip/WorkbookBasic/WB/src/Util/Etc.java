import java.io.File;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@SuppressWarnings("unused")
public final class Etc {
	// origin - 01.10.2023, last edit - 15.09.2026

	public static int strMatch(String inStr, String findStr) throws Exception {// lenght findStr is any, so !!!
		// origin - 14.09.2024, last edit - 13.06.2025
		int res = 0;

		// inStr = Etc.fixTrim(inStr); //sometimes find strings contains spaces
		// findStr = Etc.fixTrim(findStr); //sometimes find strings contains spaces

		try {
			int beginIndex = 0;
			int endIndex = beginIndex + findStr.length();
			String tmp = "";
			if (endIndex <= inStr.length()) {
				tmp = inStr.substring(beginIndex, endIndex);
			}
			// WB.addLog2("Etc.matchStr, tmp1=" + tmp + ", inStr=" + inStr + ", findStr="
			// +findStr, "", "Etc");
			while (tmp.length() == findStr.length()) {
				if (Etc.strEquals(tmp, findStr)) {
					res = res + 1;
				}
				beginIndex = beginIndex + 1;
				endIndex = beginIndex + findStr.length();
				tmp = "";
				if (endIndex <= inStr.length()) {
					tmp = inStr.substring(beginIndex, endIndex);
				}
				// WB.addLog2("Etc.matchStr, tmp2=" + tmp + ", inStr=" + inStr + ", findStr="
				// +findStr, "","Etc");
			}

		} catch (Exception ex) {
			WB.addLog("Etc.strMatch(2String):int, ex=" + ex.getMessage(), "", "Etc");
		}
		return res;
	}

	public static String getItemListStringIfExist(List<String> listStr, int itemIndex) throws Exception {
		// origin - 29.07.2026, last edit - 29.07.2026
		String res = "";
		try {
			if (listStr.size() == 0) {
				return res;
			}
			if (listStr.size() >= itemIndex + 1) {
				res = listStr.get(itemIndex);
			}
		} catch (Exception ex) {
			WB.addLog("Etc.getItemListStringIfExist(List<String>,int):String, ex=" + ex.getMessage(), "", "Etc");
		}
		return res;
	}

	public static String delTailPlaceholder(String inStr, String placeholder) throws Exception {
		// del all tail placeholder
		// origin - 02.02.2026, last edit - 02.02.2026
		if (inStr == null) {
			return "";
		}
		String res = Etc.fixTrim(inStr);
		try {
			res = res.replaceAll(placeholder + "+$", "");
		} catch (Exception ex) {
			WB.addLog("Etc.delTailPlaceholder(2String):String, ex=" + ex.getMessage(), "", "Etc");
		}
		return res;
	}

	public static String delLeaderPlaceholder(String inStr, String placeholder) throws Exception {
		// del all leader placeholder
		// origin - 26.08.2024, last edit - 14.09.2026
		if (inStr == null) {
			return "";
		}
		String res = Etc.fixTrim(inStr);
		try {
			if (inStr.isEmpty()) {
				return res = "";
			}

			if (placeholder.isEmpty()) {
				return res;
			}

			res = res.replaceAll("^" + placeholder + "+", "");
		} catch (Exception ex) {
			WB.addLog("Etc.delLeaderPlaceholder(2String):String, ex=" + ex.getMessage(), "", "Etc");
		}
		return res;
	}

	public static String addLeaderPlaceholder(String inStr, String placeholder) throws Exception {
		// origin - 16.03.2026, last edit - 16.03.2026
		String res = Etc.fixTrim(inStr);
		try {
			if (res.isEmpty() == false) {
				res = placeholder + res;
			}
		} catch (Exception ex) {
			WB.addLog("Etc.addLeaderPlaceholder(2String):String, ex=" + ex.getMessage(), "", "Etc");
		}
		return res;
	}

	public static String addLeaderPlaceholder(String inStr, int normLenght, String placeholder) throws Exception {
		// origin - 16.08.2024, last edit - 13.06.2025
		String res = Etc.fixTrim(inStr);
		try {
			if (placeholder.isEmpty() == false) {
				// res = Etc.clonePlaceholder(normLenght, placeholder) + res;

				String tmp = "";
				for (int i = 1; i <= normLenght; i++) {
					tmp = tmp + placeholder;
				}
				res = tmp + res;

				res = res.substring(res.length() - normLenght);
			}
		} catch (Exception ex) {
			WB.addLog("Etc.addLeaderPlaceholder(String, int, String):String, ex=" + ex.getMessage(), "", "Etc");
		}
		return res;
	}

	public static boolean isLetterOrDigitAll(String testString) throws Exception {
		// origin - 24.06.2024, last edit - 13.06.2025
		Boolean res = false;
		try {
			testString = Etc.fixTrim(testString);
			int countLetterOrDigit = 0;
			// char[] charArray = testString.toCharArray();

			for (char currChar : testString.toCharArray()) {
				if (Character.isLetterOrDigit(currChar)) {
					countLetterOrDigit = countLetterOrDigit + 1;
				}
			}

			if ((countLetterOrDigit != 0) && (countLetterOrDigit == testString.length())) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("Etc.isLetterOrDigitAll(String):boolean, ex=" + ex.getMessage(), "", "Etc");
		}
		return res;
	}

	public static boolean isDigitAll(String testString) throws Exception {
		// origin - 20.06.2024, last edit - 13.06.2025
		Boolean res = false;
		try {
			testString = Etc.fixTrim(testString);
			// testString = testString.replaceAll(".", "");
			int countDigit = 0;
			// char[] charArray = testString.toCharArray();

			for (char currChar : testString.toCharArray()) {
				if (Character.isDigit(currChar)) {
					countDigit = countDigit + 1;
				}
			}

			if ((countDigit != 0) && (countDigit == testString.length())) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("Etc.isDigitAll(String):boolean, ex=" + ex.getMessage(), "", "Etc");
		}
		return res;
	}

	public static String getFileName(String urlFrom) throws Exception {
		// origin - 25.12.2023, last edit - 13.06.2025
		String res = "";
		try {
			File file = new File(urlFrom);
			res = fixTrim(file.getName());
		} catch (Exception ex) {
			WB.addLog("Etc.getFileName(String):String, ex=" + ex.getMessage(), "", "Etc");
		}
		return res;
	}

	public static void doNothing() {
		// origin - 23.12.2023, last edit - 23.12.2023
	}

	public static List<String> replaceStrInList(List<String> listString, String replaceStr, String targetStr)
			throws Exception {
		// origin - 01.08.2026, last edit - 01.08.2026
		List<String> res = new ArrayList<String>();
		try {
			replaceStr = Etc.fixTrim(replaceStr);
			for (var curr : listString) {
				res.add(curr.replace(replaceStr, targetStr));
			}
		} catch (Exception ex) {
			WB.addLog("Etc.replaceStrInList(List<String>, 2String):List<String>, ex=" + ex.getMessage(), "", "Etc");
		}
		return res;
	}

	public static String delStr(String viewName, List<String> listDelWord) throws Exception {
		// origin - 30.09.2024, last edit - 13.06.2025
		String res = "";
		try {
			res = Etc.fixTrim(viewName); // delete all space
			for (var currDelWord : listDelWord) {
				res = res.replace(currDelWord, ""); // delete word if it exist
			}
			res = Etc.fixTrim(res); // delete all space
		} catch (Exception ex) {
			WB.addLog("Etc.delStr(String, List<String>):String, ex=" + ex.getMessage(), "", "Etc");
		}
		return res;
	}

	public static String delTailStr(String srcStr, String delStr) throws Exception {
		// origin - 18.02.2026, last edit - 18.02.2026
		String res = srcStr;
		try {
			if (srcStr.endsWith(delStr)) {
				int posDelStr = srcStr.lastIndexOf(delStr); // last match in src str for find substr
				if (posDelStr > 0) {
					res = Etc.fixTrim(srcStr.substring(0, posDelStr));
				}
			}
		} catch (Exception ex) {
			WB.addLog("Etc.delTailStr(2String):String, ex=" + ex.getMessage(), "", "Etc");
		}
		return res;
	}

	public static String delStr(String viewName, String delWord) throws Exception {
		// origin - 30.10.2023, last edit - 13.06.2025
		String res = "";
		try {
			res = Etc.fixTrim(viewName); // delete all space
			res = res.replace(delWord, ""); // delete word if it exist
			res = Etc.fixTrim(res); // delete all space
		} catch (Exception ex) {
			WB.addLog("Etc.delStr(2String):String, ex=" + ex.getMessage(), "", "Etc");
		}
		return res;
	}

	public static boolean strEquals(String str1, String str2) throws Exception {
		// origin - 18.10.2023, last edit - 13.06.2025
		boolean res = false;
		try {
			if ((str1 != null) && (str1.isEmpty() == false)) {
				str1 = fixTrim(str1.toLowerCase());
				str2 = fixTrim(str2.toLowerCase());
				res = str1.equalsIgnoreCase(str2) == true ? true : res;
			}

		} catch (Exception ex) {
			WB.addLog("Etc.strEquals(2String):boolean, ex=" + ex.getMessage(), "", "Etc");
		}
		return res;
	}

	public static boolean strContains(String str1, List<String> str2) throws Exception { // TODO
		// origin - 26.03.2026, last edit - 26.03.2026
		boolean res = false;
		try {
			int countContains = 0;
			for (var curr : str2) {
				if (Etc.strContains(str1, curr)) {
					countContains = countContains + 1;
				}
			}
			if (countContains == str2.size()) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("Etc.strContains(String,List<String>):boolean, ex=" + ex.getMessage(), "", "Etc");
		}
		return res;
	}

	public static boolean strContains(String str1, String str2) throws Exception {
		// origin - 19.02.2024, last edit - 13.06.2025
		boolean res = false;
		try {
			str1 = fixTrim(str1.toLowerCase());
			str2 = fixTrim(str2.toLowerCase());
			res = str1.contains(str2) == true ? true : res;
		} catch (Exception ex) {
			WB.addLog("Etc.strContains(2String):boolean, ex=" + ex.getMessage(), "", "Etc");
		}
		return res;
	}

	public static String fixString(Object fixObj) throws Exception {
		// origin - 12.11.2023, last edit - 13.06.2025
		String res = "";
		try {
			res = fixObj.toString();
		} catch (Exception ex) {
			res = "";
			// WB.addLog("Etc.fixString(Object fixObj):String, ex=" + ex.getMessage(), "",
			// "Etc");
		} finally {
			res = Etc.fixTrim(res);
		}
		return res;
	}

	public static List<String> fixTrim(List<String> in) throws Exception {
		// origin - 19.08.2026, last edit - 19.08.2026
		List<String> res = new ArrayList<String>();
		try {
			for (var curr : in) {
				res.add(Etc.fixTrim(curr));
			}
		} catch (Exception ex) {
			WB.addLog("Etc.fixTrim(List<String>):List<String>, ex=" + ex.getMessage(), "", "Etc");
		}
		return res;
	}

	public static String fixTrim(String fixStr) throws Exception {
		// origin - 02.10.2023, last edit - 13.06.2025
		String res = "";
		try {
			// if (fixStr != null) {// added 12.03.2025
			res = fixStr.strip();
			// } // added 12.03.2025
		} catch (Exception ex) {
			res = "";
			WB.addLog("Etc.fixTrim(String):String, ex=" + ex.getMessage(), "", "Etc");
		}
		return res;
	}

	private Etc() {
		// origin - 04.11.2024, last edit - 04.11.2024
	}

	public static void test() throws Exception {
		// origin - 01.10.2023, last edit - 12.09.2026
		try {

//			WB.addLog2("Etc.test.multiply(2double):double", "", "Etc");
//			for (var tmp1 : new double[] { 2.0, 0.0, 4.00, 60.0, 150.2, 600.2 }) {
//				for (var tmp2 : new double[] { 2.0, 0.0, 4.00, 60.0, 150.2, 600.2 }) {
//					WB.addLog2("Etc.test.multiply(2double):double, res=" + Etc.multiply(tmp1, tmp2) + ", tmp1=" + tmp1
//							+ ", tmp2=" + tmp2, "", "Etc");
//				}
//			}

//			WB.addLog2("Etc.test.divide(2double):double", "", "Etc");
//			for (var tmp1 : new double[] { 2.0, 0.0, 4.00, 60.0, 150.2, 600.2 }) {
//				for (var tmp2 : new double[] { 2.0, 0.0, 4.00, 60.0, 150.2, 600.2 }) {
//					WB.addLog2("Etc.test.divide(2double):double, res=" + Etc.divide(tmp1, tmp2) + ", tmp1=" + tmp1
//							+ ", tmp2=" + tmp2, "", "Etc");
//				}
//			}

//			// getDoubleByStr
//			for (String tmp1 : new String[] { "17420", "17 420", "17420.0", "17420.00", "17420,0", "17420,00",
//					"17420,000", "17420,0000", "17 420.00", "-17420", "17420 - 18560", "34.152562", "34,152562",
//					"153,600.2", "153 600.2", "34153600.2" }) {
//				WB.addLog2("Etc.test.getDoubleByStr, res=" + Etc.getDoubleByStr(tmp1) + ", tmp1=" + tmp1,
//						"", "Etc");
//			}

//			WB.addLog2("Etc.test.replaceStrInList(List<String>;String):List<String>", "", "Etc");
//			var tmp1 = new String[] { "mama", "myla", "ramy" };
//			var tmp2 = List.of(tmp1);
//			var tmp3 = "ma";
//			var tmp4 = "pa";
//			WB.addLog2("Etc.test.replaceStrInList(List<String>,String):List<String>, res="
//					+ Etc.replaceStrInList(tmp2, tmp3, tmp4) + ", tmp2=" + tmp2+", tmp3="+tmp3+", tmp4="+tmp4, "", "Etc");

//			WB.addLog2("Etc.test.getItemListStringIfExist(List<String>,int):String", "", "Etc");
//			var tmp1 = "0;1;2;3;4;5;6";
//			for (var tmp2 : new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8 }) {
//				var tmp3 = List.of(tmp1.split(";"));
//				WB.addLog2(
//						"Etc.test.getItemListStringIfExist(List<String>,int):String, res="
//								+ Etc.getItemListStringIfExist(tmp3, tmp2) + ", tmp3=" + tmp3 + ", tmp2=" + tmp2,
//						"", "Etc");
//			}

//			WB.addLog2("Etc.test.strContains(String,List<String>):boolean", "", "Etc");
//			for (String tmp1 : new String[] { "test1(", "test1()", "test22" }) {
//				var tmp2 = List.of("(", ")");
//				WB.addLog2("Etc.test.strContains(String,List<String>):boolean, res=" + Etc.strContains(tmp1, tmp2)
//						+ ", tmp1=" + tmp1 + ", tmp2=" + tmp2, "", "Etc");
//			}

//			WB.addLog2("Etc.test.isZero(String):boolean", "", "Etc");
//			for (var tmp1 : new String[] { "04444000", "10", "000333", "0", "Альфа", null }) {
//				WB.addLog2("Etc.test.isZero(String):boolean, res=" + Etc.isZero(tmp1) + ", tmp1=" + tmp1, "", "Etc");
//			}

//			WB.addLog2("Etc.test.delTailStr(2String)", "", "Etc");
//			for (var tmp1 : new String[] { "Face;Weight;Unit;1;2;", "Face;Weight;Unit ;1;2 ;", "Face;Weight;Unit;4;5",
//					"Unit;1" }) {
//				WB.addLog2("Etc.test.delTailStr(2String), res=" + Etc.delTailStr(tmp1, ";") + " src=" + tmp1
//						+ " delStr=" + ";", "", "Etc");
//			}

//			// reverseRatio
//			for (double testArg1 : new double[] { 100.9, 57.4363, 3.0078, 21.212, 3478458787.0 }) {
//				WB.addLog2("Etc.test.reverseRatio, res=" + Etc.reverseRatio(testArg1) + " testArg1=" + testArg,"", "Etc");
//			}

//			// delStr(str, ListDelWord)
//			List<String> listDelWord = List.of("(", ")");
//			var arg1 = new String[] { "(0015567453", "10(09090)965)", "(003)", "((00)Fkmaf))))" };
//			for (var testArg1 : arg1) {
//				WB.addLog2("Etc.test.delStr(inStr, listDelWord), res=" + Etc.delStr(testArg1, listDelWord)
//						+ " testArg1=" + testArg1, "", "Etc");
//			}

//			// strMatch
//			var arg1 = new String[] { "715567453", "1009090965", "03", "5100" };
//			for (var testArg1 : arg1) {
//				WB.addLog2("Etc.test.strMatch, res=" + Etc.strMatch(testArg1, "0") + ", testArg1=" + testArg1
//						+ " findStr=0", "", "Etc");
//				WB.addLog2("Etc.test.strMatch, res=" + Etc.strMatch(testArg1, "00") + ", testArg1=" + testArg1
//						+ " findStr=00", "", "Etc");
//			}

//			// delTailPlaceholder
//			WB.addLog2("Etc.test.delTailPlaceholder", "", "Etc");
//			for (var tmp1 : new String[] { "04444000", "1009095", "00033333", "588000", "\"Альфа\"", null }) {
//				for (var tmp2 : new String[] { "0", "\"" }) {
//					WB.addLog2("Etc.test.delTailPlaceholder, res=" + Etc.delTailPlaceholder(tmp1, tmp2) + " tmp1="
//							+ tmp1 + " tmp2=" + tmp2, "", "Etc");
//				}
//			}

//			WB.addLog2("Etc.test.delLeaderPlaceholder", "", "Etc");
//			for (var tmp1 : new String[] { "000067153", "1009095", "04444000", "5000", ";Альфа;", ";;Альфа;", ";Альфа;;", null }) {
//				for (var tmp2 : new String[] { "0", ";" }) {
//					WB.addLog2("Etc.test.delLeaderPlaceholder, res=" + Etc.delLeaderPlaceholder(tmp1, tmp2) + ", tmp1="
//							+ tmp1 + ", tmp2=" + tmp2, "", "Etc");
//				}
//			}

//			// addLeaderZero
//			var arg1 = new String[] { "671125567453", "1", "3", "5", "Fkmaf", null };
//			for (var testArg1 : arg1) {
//				WB.addLog2("Etc.test.addLeaderZero, res=" + addLeaderZero(testArg1, 6) + " testArg1=" + testArg1,"", "Etc");
//			}

//			// cleanLeaderZero
//			var arg1 = new String[] { "671125567453", "0001", "003", "05", "Fkmaf", null };
//			for (var testArg1 : arg1) {
//				WB.addLog2("Etc.test.cleanLeaderZero, res=" + cleanLeaderZero(testArg1) + " testArg1=" + testArg1,"", "Etc");
//			}

//			// setDefault
//			var arg1 = new String[] { "671125567453", "", " ", null };
//			for (var testArg1 : arg1) {
//				WB.addLog2("Etc.test.setDefault, res=" + setDefault(testArg1, "defaultVal") + " testArg1=" + testArg1,"", "Etc");
//			}

//		// isLetterOrDigitAll
//		var arg1 = new String[] { "671125567453", "87112567676776767676", "87664gfgf", "3611.25,567453",
//				"97%511)25567453", "021125567453", "231125567453", null };
//		for (var testArg1 : arg1) {
//			WB.addLog2("Etc.test.isLetterOrDigitAll, res=" + isLetterOrDigitAll(testArg1) + " testArg1=" + testArg1,"", "Etc");
//		}

//		// isDigitAll
//		var arg11 = new String[] { "671125567453", "87112567676776767676", "87664gfgf", "361125567453", "971125567453",
//				"021125567453", "2311255674.53", null };
//		for (var testArg1 : arg11) {
//			WB.addLog2("Etc.test.isDigitAll, res=" + isDigitAll(testArg1) + " testArg1=" + testArg1, "","Etc");
//		}

//			// getFileName
//			var testUrl = new String[] { "https://lom-bard.kz/static/reports/2022/otchet_ff.pdf",
//					"C:\\testDir\\testFile.txt" };
//			for (var testArg1 : testUrl) {
//				WB.addLog2("Etc.test.getFileName, res=" + getFileName(testArg1) + " testArg1=" + testArg1, "","Etc");
//			}

//		// fixString
//		for (var testArg1 : new Object[] { "test1", 12.45, new Asset(), null }) {
//			WB.addLog2("Etc.test.fixString, res=" + fixString(testArg1) + ", testArg1=" + testArg1, "", "Etc");
//		}

//		// strContains
//		String str0 = "test1";
//		for (String testArg1 : new String[] { "test1", "test1 ", " tEst1", "TEST1", "test22" }) {
//			WB.addLog2("Etc.test.strContains, res=" + strContains(testArg1, str0) + ", testArg1=" + testArg1 + ", str2="
//					+ str0, "", "Etc");
//		}

//		// strEquals
//		String str2 = "test1";
//		for (String testArg1 : new String[] { "test1", "test1 ", " tEst1", "TEST1", "test22" }) {
//			WB.addLog2("Etc.test.strEquals, res=" + strEquals(testArg1, str2) + ", testArg1=" + testArg1 + ", str2="
//					+ str2, "", "Etc");
//		}

//			// roundDebt
//			for (double testArg1 : new double[] { 100.0, 57.4363, 43.0078, 21.212, 34.7845 }) {
//				for (String testArg2 : new String[] { "", Debt.salaryTaxQazaqstan }) {
//					WB.addLog2("Etc.test.roundDebt, res=" + Etc.roundDebt(testArg1, testArg2) + ", testArg1=" + testArg1
//							+ ", testArg2=" + testArg2, "", "Etc");
//				}
//			}

//			// roundCustom - round2
//			for (double testArg1 : new double[] { 100.0, 57.4363, 43.0078, 21.212, 34.7845 }) {
//				WB.addLog2("Etc.test.roundCustom, res=" + roundCustom(testArg1, round2) + ", testArg1=" + testArg1
//						+ ", numberFractionalDigit=" + round2, "", "Etc");
//			}

//			// roundCustom - round0
//			for (double testArg1 : new double[] { 100.0, 57.4363, 43.0078, 21.212, 34.7845 }) {
//				WB.addLog2("Etc.test.roundCustom, res=" + roundCustom(testArg1, round0) + ", testArg1=" + testArg1
//						+ ", numberFractionalDigit=" + round0, "", "Etc");
//			}

//		// fixTrim
//		for (String testArg1 : new String[] { "test1", "test2 ", " test3", " test4 " }) {
//			WB.addLog2("Etc.test.fixTrim, res=" + fixTrim(testArg1) + ", testArg1=" + testArg1, "", "Etc");
//		}

		} catch (Exception ex) {
			WB.addLog("Etc.test():void, ex=" + ex.getMessage(), "", "Etc");
		}
	}
}