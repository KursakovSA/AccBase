import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

public class Conv {
	// origin - 15.07.2024, last edit - 20.03.2025
	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Conv.static ctor, ex=" + ex.getMessage(), "", "Conv");
		}
	}

	public static String formatterDouble(String initVal) throws Exception {
		// origin - 11.07.2024, last edit - 13.06.2025
		String res = "";
		try {
			res = Conv.formatterDouble(initVal, '.', ' ');
		} catch (Exception ex) {
			WB.addLog("Conv.formatterDouble(String initVal):String, ex=" + ex.getMessage(), "", "Conv");
		}
		return res;
	}

	public static String formatterDouble(String initVal, char decimalSeparator, char groupingSeparator)
			throws Exception {
		// origin - 11.07.2024, last edit - 13.06.2025
		String res = "";
		try {
			initVal = Conv.fixDouble(initVal);
			double tmp = Conv.getDouble(initVal);
			// res = String.format("%1$,.2f", tmp);
			DecimalFormatSymbols symbols = new DecimalFormatSymbols();
			symbols.setDecimalSeparator(decimalSeparator);
			symbols.setGroupingSeparator(groupingSeparator);
			DecimalFormat decimalFormat = new DecimalFormat("#,##0.00", symbols);
			res = decimalFormat.format(tmp);
		} catch (Exception ex) {
			WB.addLog("Conv.formatterDouble(String initVal, char decimalSeparator, char groupingSeparator):String, ex="
					+ ex.getMessage(), "", "Conv");
		}
		return res;
	}

	public static String fixDouble(String strFix) throws Exception {
		// origin - 10.01.2024, last edit - 13.06.2025
		String res = "";
		try {
			strFix = Etc.fixTrim(strFix);

			if (strFix.indexOf(",") == strFix.lastIndexOf(",")) {// if substr contain one char "," ex.
				// "14,8464554" that doing = "14.8464554"
				strFix = strFix.replace(",", ".");
			}

			if (strFix.endsWith(",0")) {// fix fraction separator
				strFix = strFix.substring(0, strFix.length() - 2) + ".0"; // ???magic numbers and strings ???
			}

			if (strFix.endsWith(",00")) {// fix fraction separator
				strFix = strFix.substring(0, strFix.length() - 3) + ".0"; // ???magic numbers and strings ???
			}

			if (strFix.endsWith(",000")) {// fix fraction separator
				strFix = strFix.substring(0, strFix.length() - 4) + ".0"; // ???magic numbers and strings ???
			}

			if (strFix.endsWith(",0000")) {// fix fraction separator
				strFix = strFix.substring(0, strFix.length() - 5) + ".0"; // ???magic numbers and strings ???
			}

			if (strFix.endsWith(",00000")) {// fix fraction separator
				strFix = strFix.substring(0, strFix.length() - 6) + ".0"; // ???magic numbers and strings ???
			}

			if (strFix.indexOf(",") == strFix.lastIndexOf(",")) {// if substr contain one char "," ex.
																	// "14,8464554"
				strFix = strFix.replace(",", "");
			}

			strFix = strFix.replaceAll(",", "");
			strFix = strFix.replaceAll(" ", "");// del space, because spaces not need for double number
			res = strFix;
		} catch (Exception ex) {
			WB.addLog("Conv.fixDouble(String strFix):String, ex=" + ex.getMessage(), "", "Conv");
		}
		return res;
	}

//	public static Object get(String initVal, String context) throws Exception {
//		// origin - 09.11.2024, last edit - 16.06.2025
//		Object res = null;
//		initVal = Etc.fixTrim(initVal);
//
//		try {
////			if ((initVal.endsWith(".0")) | (Etc.strContains(context, "ExpectedDouble"))) {
////				return res = Conv.getDouble(initVal);
////			}
//			
//			if (initVal.endsWith(".0")) {
//				return res = Conv.getDouble(initVal);
//			}
//			
//			if (Etc.strContains(context, "ExpectedDouble")) {
//				return res = Conv.getDouble(initVal);
//			}
//
//			if (Etc.strContains(context, "ExpectedString")) {
//				return res = Etc.fixTrim(initVal);
//			}
//
//			if (Etc.isDigitAll(initVal)) {// if int val
//				return res = Conv.getInt(initVal);
//			}
//
//			if ((Etc.strMatch(initVal, "T") == 0) && (Etc.strMatch(initVal, ":") == 0)
//					&& (Etc.strMatch(initVal, "-") == 2)) {// if localdate
//				return res = LocalDate.parse(initVal);
//			}
//
//			if ((Etc.strMatch(initVal, "T") == 1) && (Etc.strMatch(initVal, ":") == 2)
//					&& (Etc.strMatch(initVal, "-") == 2)) {// if localdatetime
//				return res = LocalDateTime.parse(initVal);
//			}
//
//		} catch (Exception ex) {
//			WB.addLog("Conv.get(String initVal, String context):Object, ex=" + ex.getMessage(), "", "Conv");
//		}
//		return res;
//	}

	public static int getInt(String initValue) throws Exception {
		// origin - 03.09.2024, last edit - 13.06.2025
		int res = 0;
		initValue = Conv.fixDouble(initValue);
		try {
			if ((initValue != null) && (initValue.isEmpty() == false)) {
				res = Integer.parseInt(initValue);
			} else {
				res = 0;
			}
		} catch (Exception ex) {
			WB.addLog("Conv.getInt(String initValue):int, ex=" + ex.getMessage(), "", "Conv");
			res = 0;
		}
		return res;
	}

	public static double getDouble(String initValue) throws Exception {
		// origin - 07.01.2024, last edit - 13.06.2025
		double res = 0.0;
		initValue = Conv.fixDouble(initValue);

		try {
			if (initValue.isEmpty() == false) {
				res = Double.parseDouble(initValue);
			} else {
				res = 0.0;
			}
		} catch (Exception ex) {
			// WB.addLog("Conv.getDouble(String initValue):double, ex=" + ex.getMessage(),
			// "", "Conv");
			res = 0.0;
		}
		return res;
	}

	private Conv() {
		// origin - 04.11.2024, last edit - 04.11.2024
	}

	public static void test() throws Exception {
		// origin - 15.07.2024, last edit - 13.06.2025
		try {

//			// formatterDouble
//			for (String formatterDoubleArg1 : new String[] { "0.2", "0.20", "0.24", "0.293", "0.298", "0.00", "0.0",
//					"0025.463", "0025.46300", "0025.468", "0025.46800", "002 5,468 00", "12345678.06745",
//					"12045078.06745" }) {
//				WB.addLog2("Conv.test.formatterDouble, res=" + Conv.formatterDouble(formatterDoubleArg1) + ", arg1="
//						+ formatterDoubleArg1, "", "Conv");
//			}

//			// getDouble
//			for (String testArg1 : new String[] { "17420", "17 420", "17420.0", "17420.00", "17420,0", "17420,00",
//					"17420,000", "17420,0000", "17 420.00", "-17420", "17420 - 18560", "34.152562", "34,152562",
//					"153,600.2", "153 600.2", "34153600.2" }) {
//				WB.addLog2("Conv.test.getDouble, res=" + Conv.getDouble(testArg1) + ", testArg1=" + testArg1,
//						"", "Conv");
//			}

//			// fixDouble
//			for (String testArg1 : new String[] { "1,5", "1.5", "17420", "17 420", "17420.0", "17420.00", "17420,0",
//					"17420,00", "17420,000", "17420,0000", "17 420.00", "-17420", "17420 - 18560", "34.152562",
//					"34,152562", "34,153,600.2", "34 153 600.2", "34153600.2" }) {
//				WB.addLog2("Conv.test.fixDouble, res=" + fixDouble(testArg1) + ", testArg1=" + testArg1, "",
//						"Etc");
//			}

		} catch (Exception ex) {
			WB.addLog("Conv.test():void, ex=" + ex.getMessage(), "", "Conv");
		}
	}
}