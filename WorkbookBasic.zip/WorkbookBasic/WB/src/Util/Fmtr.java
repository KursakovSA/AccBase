import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public final class Fmtr {
	// origin - 24.08.2024, last edit - 12.10.2025

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Fmtr.static ctor, ex=" + ex.getMessage(), "", "Fmtr");
		}
	}

	public static String fixForDoubleByStr(String strFix) throws Exception {
		// origin - 10.01.2024, last edit - 05.08.2026
		String res = "";
		try {
			strFix = Etc.fixTrim(strFix);

			if (strFix.endsWith("()")) {// delete empty brackets by unit
				strFix = strFix.substring(0, strFix.length() - 2);
			}

			if (strFix.indexOf(",") == strFix.lastIndexOf(",")) {// if substr contain one char "," ex.
				// "14,8464554" that doing = "14.8464554"
				strFix = strFix.replace(",", ".");
			}

			if (strFix.endsWith(",0")) {// fix fraction separator
				strFix = strFix.substring(0, strFix.length() - 2) + ".0"; // ???magic numbers and strings ???
			}

			if (strFix.endsWith(",00")) {// fix fraction separator
				strFix = strFix.substring(0, strFix.length() - 3) + ".0"; // ???magic numbers and strings ???
			}

			if (strFix.endsWith(",000")) {// fix fraction separator
				strFix = strFix.substring(0, strFix.length() - 4) + ".0"; // ???magic numbers and strings ???
			}

			if (strFix.endsWith(",0000")) {// fix fraction separator
				strFix = strFix.substring(0, strFix.length() - 5) + ".0"; // ???magic numbers and strings ???
			}

			if (strFix.endsWith(",00000")) {// fix fraction separator
				strFix = strFix.substring(0, strFix.length() - 6) + ".0"; // ???magic numbers and strings ???
			}

			if (strFix.indexOf(",") == strFix.lastIndexOf(",")) {// if substr contain one char "," ex.
																	// "14,8464554"
				strFix = strFix.replace(",", "");
			}

			strFix = strFix.replaceAll(",", "");
			strFix = strFix.replaceAll(" ", "");// del space, because spaces not need for double number
			res = strFix;
		} catch (Exception ex) {
			WB.addLog("Fmtr.fixForDoubleByStr(String):String, ex=" + ex.getMessage(), "", "Fmtr");
		}
		return res;
	}

	public static String strForDoubleByStr(String initVal) throws Exception {
		// origin - 11.07.2024, last edit - 05.08.2026
		String res = "";
		try {
			res = Fmtr.strForDoubleByStr(initVal, '.', ' ');
		} catch (Exception ex) {
			WB.addLog("Fmtr.strForDoubleByStr(String):String, ex=" + ex.getMessage(), "", "Fmtr");
		}
		return res;
	}

	public static String strForDoubleByStr(String initVal, char decimalSeparator, char groupingSeparator)
			throws Exception {
		// origin - 11.07.2024, last edit - 05.08.2026
		String res = "";
		try {
			initVal = Fmtr.fixForDoubleByStr(initVal);
			double tmp = Etc.getDoubleByStr(initVal);
			DecimalFormatSymbols symbols = new DecimalFormatSymbols();
			symbols.setDecimalSeparator(decimalSeparator);
			symbols.setGroupingSeparator(groupingSeparator);
			DecimalFormat decimalFormat = new DecimalFormat("#,##0.00", symbols);
			res = decimalFormat.format(tmp);
		} catch (Exception ex) {
			WB.addLog("Fmtr.strForDoubleByStr(String, 2char):String, ex=" + ex.getMessage(), "", "Fmtr");
		}
		return res;
	}

	public static List<LocalDate> listStr(List<String> inLst) throws Exception {
		// origin - 10.09.2024, last edit - 13.06.2025
		List<LocalDate> res = new ArrayList<LocalDate>();
		try {
			for (var curr : inLst) {
				if (curr.isEmpty() == false) {
					res.add(DateTool.getLocalDate(curr));
				}
			}
		} catch (Exception ex) {
			WB.addLog("Fmtr.listStr(List<String> inLst):List<LocalDate>, ex=" + ex.getMessage(), "", "Fmtr");
		}
		return res;
	}

	public static List<String> listVal(String initStr, String strSplit) throws Exception {
		// origin - 16.07.2024, last edit - 13.06.2025
		List<String> res = new ArrayList<String>();
		try {
			initStr = Etc.fixTrim(initStr);
			String[] tmp = initStr.split(strSplit);
			String currTmp = "";
			for (var currArr : tmp) {
				currTmp = "";
				// currTmp = currArr.toString();
				currTmp = Etc.fixTrim(currArr.toString());
				// currTmp = currTmp.replace(ListVal.strSplit, "");
				if (currTmp.isEmpty() == false) {
					res.add(currTmp);
				}
			}
		} catch (Exception ex) {
			WB.addLog("Fmtr.listVal(String initStr, String strSplit):List<String>, ex=" + ex.getMessage(), "", "Fmtr");
		}
		return res;
	}

	public static <T> String listIter(List<T> initIter, String context) throws Exception {
		// origin - 25.08.2024, last edit - 21.05.2026
		String res = "";
		String currRes = "";
		try {
			for (var currIter : initIter) {
				currRes = currIter.toString();
				currRes = currRes.replaceAll(";", ", "); // del ; ins , for correct csv
				// WB.addLog2("Fmtr.listIter, res=" + currRes + ", context=" + context, "",
				// "Fmtr");
				res = res + currRes;
			}
		} catch (Exception ex) {
			WB.addLog("Fmtr.listIter(List<T>, String):String, ex=" + ex.getMessage(), "", "Fmtr");
		}
		return res;
	}

	public static String listVal2(List<LocalDate> initList, String context) throws Exception {
		// origin - 10.09.2024, last edit - 13.06.2025
		String res = "";
		try {
			for (var currList : initList) {
				res = res + currList.toString() + ", ";
			}
		} catch (Exception ex) {
			WB.addLog("Fmtr.listVal2(List<LocalDate>, String):String, ex=" + ex.getMessage(), "", "Fmtr");
		}
		return res;
	}

	public static String listVal(int[] in) throws Exception {
		// origin - 22.08.2026, last edit - 23.08.2025
		String res = "";
		try {
			res = res + "[";
			int count = 0;
			for (var curr : in) {
				count = count + 1;
				res = res + String.valueOf(curr);
				if (count != in.length) {
					res = res + ",";
				}
			}
			res = res + "]";
		} catch (Exception ex) {
			WB.addLog("Fmtr.listVal(int[]):String, ex=" + ex.getMessage(), "", "Fmtr");
		}
		return res;
	}

	public static String listVal(String[] initList, String context) throws Exception {
		// origin - 14.02.2025, last edit - 13.06.2025
		String res = "";
		try {
			for (var currList : initList) {
				res = res + currList.toString() + ", ";
			}
		} catch (Exception ex) {
			WB.addLog("Fmtr.listVal(String[], String):String, ex=" + ex.getMessage(), "", "Fmtr");
		}
		return res;
	}

	public static String listVal(List<String> initList, String context) throws Exception {
		// origin - 24.08.2024, last edit - 13.06.2025
		String res = "";
		try {
			for (var currList : initList) {
				res = res + currList.toString() + ", ";
			}
		} catch (Exception ex) {
			WB.addLog("Fmtr.listVal(List<String>, String):String, ex=" + ex.getMessage(), "", "Fmtr");
		}
		return res;
	}

	public static String addAnyway(String name, Object objAdd) throws Exception {// for toString
		// origin - 12.12.2024, last edit - 13.06.2025
		String res = "";
		String fixStrAdd = Etc.fixTrim(objAdd.toString());
		fixStrAdd = fixStrAdd.replaceAll(";", ","); // del ";" that not do wrap for csv-file field
		try {
			res = res + Etc.fixTrim(name) + " " + fixStrAdd + "  "; // + ", ";
		} catch (Exception ex) {
			WB.addLog2("Fmtr.addAnyway(String, Object):String, ex=" + ex.getMessage(), "", "Fmtr");
		}
		return res;
	}

	public static String addIfNotZeroSize(String name, List<FullDto> objAdd) throws Exception {// for toString
		// origin - 18.12.2024, last edit - 13.06.2025
		String res = "";
		try {
			if (objAdd.size() != 0) {
				res = res + Etc.fixTrim(name) + " " + objAdd.size() + "  "; // + ", ";
			}
		} catch (Exception ex) {
			WB.addLog2("Fmtr.addIfNotZeroSize(String, List<FullDto>):String, ex=" + ex.getMessage(), "", "Fmtr");
		}
		return res;
	}

	public static String addIfNotEmptyUnitVal(String name, UnitVal uvAdd) throws Exception {// CHECK think todo
		// origin - 11.06.2025, last edit - 13.06.2025
		String res = "";
		try {
			if (uvAdd.partVal.isEmpty()) {
				return res;
			}
			res = res + Etc.fixTrim(name) + " " + uvAdd.id + "  ";
		} catch (Exception ex) {
			WB.addLog2("Fmtr.addIfNotZeroUnitVal(String, UnitVal):String, ex=" + ex.getMessage(), "", "Fmtr");
		}
		return res;
	}

	public static String addIfNotZeroUnitVal(String name, UnitVal uvAdd) throws Exception {
		// origin - 11.06.2025, last edit - 13.06.2025
		String res = "";
		try {
			if (uvAdd.val == 0.00) {
				return res;
			}
			res = res + Etc.fixTrim(name) + " " + uvAdd.id + "  ";
		} catch (Exception ex) {
			WB.addLog2("Fmtr.addIfNotZeroUnitVal(String, UnitVal):String, ex=" + ex.getMessage(), "", "Fmtr");
		}
		return res;
	}

	public static String addIfStrEmpty(String strTo, String strFrom, String addStr) throws Exception {
		// origin - 23.05.2026, last edit - 23.05.2026
		String res = strTo;
		try {
			if (strFrom.isEmpty()) {
				res = res + addStr;
			}
		} catch (Exception ex) {
			WB.addLog2("Fmtr.addIfStrEmpty(3String):String, ex=" + ex.getMessage(), "", "Fmtr");
		}
		return res;
	}

	public static String addIfStrNotEmpty(String strTo, String strFrom, String splitter) throws Exception {
		// origin - 23.05.2026, last edit - 23.05.2026
		String res = strTo;
		try {
			if (strFrom.isEmpty() == false) {
				res = res + splitter + strFrom;
			}
		} catch (Exception ex) {
			WB.addLog2("Fmtr.addIfStrNotEmpty(3String):String, ex=" + ex.getMessage(), "", "Fmtr");
		}
		return res;
	}

	public static String addIfNotEmpty(String name, Object objAdd) throws Exception {
		// origin - 21.08.2024, last edit - 13.06.2025
		String res = "";
		String fixStrAdd = Etc.fixTrim(objAdd.toString());
		fixStrAdd = fixStrAdd.replaceAll(";", ","); // del ";" that not do wrap for csv-file field
		try {

			if (Etc.strEquals(fixStrAdd, "0")) {// added 26.03.2025
				return res;
			}

			if (Etc.strEquals(fixStrAdd, "0.00")) {// added 26.03.2025
				return res;
			}

			if (Etc.strEquals(fixStrAdd, "")) {// added 26.03.2025
				return res;
			}

			if (fixStrAdd.isEmpty() == false) {
				res = res + Etc.fixTrim(name) + " " + fixStrAdd + "  "; // + ", ";
			}

		} catch (Exception ex) {
			WB.addLog2("Fmtr.addIfNotEmpty(String, Object):String, ex=" + ex.getMessage(), "", "Fmtr");
		}
		return res;
	}

	private Fmtr() throws Exception {
		// origin - 24.08.2024, last edit - 05.03.2025
	}

	public static void test() throws Exception {
		// origin - 24.08.2024, last edit - 05.08.2026
		try {

//			// fixForDoubleByStr
//			for (String tmp1 : new String[] { "1,5", "1.5", "17420", "17 420", "17420.0", "17420.00", "17420,0",
//					"17420,00", "17420,000", "17420,0000", "17 420.00", "-17420", "17420 - 18560", "34.152562",
//					"34,152562", "34,153,600.2", "34 153 600.2", "34153600.2" }) {
//				WB.addLog2("Fmtr.test.fixDouble, res=" + Fmtr.fixForDoubleByStr(tmp1) + ", tmp1=" + tmp1, "",
//						"Fmtr");
//			}

//			// strForDoubleByStr
//			for (String tmp1 : new String[] { "0.2", "0.20", "0.24", "0.293", "0.298", "0.00", "0.0",
//					"0025.463", "0025.46300", "0025.468", "0025.46800", "002 5,468 00", "12345678.06745",
//					"12045078.06745" }) {
//				WB.addLog2("Fmtr.test.strForDoubleByStr, res=" + Conv.strForDoubleByStr(tmp1) + ", tmp1="
//						+ tmp1, "", "Fmtr");
//			}

//			WB.addLog2("Fmtr.test.addIfStrNotEmpty(3String)", "", "Fmtr");
//			for (var tmp1 : new String[] { "Unit.Packet", "Unit.T" }) {
//				for (var tmp2 : new String[] { "", "3", "3,5" }) {
//					WB.addLog2("Fmtr.test.addIfStrNotEmpty(String), res=" + Fmtr.addIfStrNotEmpty(tmp1, tmp2, ",")
//							+ " , tmp1=" + tmp1 + " , tmp2=" + tmp2, "", "Fmtr");
//				}
//			}

//			// listIter
//			List<FullDto> newListIter = FullDto.getSubsetByMore(WB.abcLast.basic, "AbcCodePay");
//			Fmtr.listIter(newListIter, "Fmtr");

		} catch (Exception ex) {
			WB.addLog("Fmtr.test():void, ex=" + ex.getMessage(), "", "Fmtr");
		}
	}
}