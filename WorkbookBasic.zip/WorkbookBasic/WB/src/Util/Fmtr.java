import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Fmtr {
	// origin - 24.08.2024, last edit - 29.06.2025

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Fmtr.static ctor, ex=" + ex.getMessage(), "", "Fmtr");
		}
	}

	public static List<LocalDate> listStr(List<String> inLst) throws Exception {
		// origin - 10.09.2024, last edit - 13.06.2025
		List<LocalDate> res = new ArrayList<LocalDate>();
		try {
			for (var curr : inLst) {
				if (curr.isEmpty() == false) {
					res.add(DateTool.getLocalDate(curr));
				}
			}
		} catch (Exception ex) {
			WB.addLog("Fmtr.listStr(List<String> inLst):List<LocalDate>, ex=" + ex.getMessage(), "", "Fmtr");
		}
		return res;
	}

	public static List<String> listVal(String initStr, String strSplit) throws Exception {
		// origin - 16.07.2024, last edit - 13.06.2025
		List<String> res = new ArrayList<String>();
		try {
			initStr = Etc.fixTrim(initStr);
			String[] tmp = initStr.split(strSplit);
			String currTmp = "";
			for (var currArr : tmp) {
				currTmp = "";
				// currTmp = currArr.toString();
				currTmp = Etc.fixTrim(currArr.toString());
				// currTmp = currTmp.replace(ListVal.strSplit, "");
				if (currTmp.isEmpty() == false) {
					res.add(currTmp);
				}
			}
		} catch (Exception ex) {
			WB.addLog("Fmtr.listVal(String initStr, String strSplit):List<String>, ex=" + ex.getMessage(), "", "Fmtr");
		}
		return res;
	}

//	public static String reflect(Object obRef) throws Exception {
//		// origin - 26.08.2024, last edit - 29.06.2025
//		String res = "";
//		try {
//			Field[] fields = obRef.getClass().getFields();
//			for (var currField : fields) {
//				currField.setAccessible(true);
//
//				if (currField.get(obRef) == null) { // skip null
//					continue;
//				}
//
//				String strFieldValue = currField.get(obRef).toString();
//
//				switch (strFieldValue) { // skip empty vals
//				case "0", "0.0", "[]", "{}", "" -> {
//					continue;
//				}
//				default -> Etc.doNothing();
//				}
//				res = res + Fmtr.addIfNotEmpty(currField.getName(), strFieldValue);
//			}
//		} catch (Exception ex) {
//			WB.addLog("Fmtr.reflect(Object obRef):String, ex=" + ex.getMessage(), "", "Fmtr");
//		}
//		return res;
//	}

//	public static String listModelDto(List<ModelDto> initList, String context) throws Exception {
//		// origin - 02.02.2025, last edit - 11.05.2025
//		String res = "";
//		try {
//			for (var currList : initList) {
//				res = res + currList.id + ", ";
//			}
//		} catch (Exception ex) {
//			WB.addLog("Fmtr.listModelDto, ex=" + ex.getMessage(), "", "Fmtr");
//		}
//		return res;
//	}

	public static <T> String listIter(List<T> initIter, String context) throws Exception {
		// origin - 25.08.2024, last edit - 13.06.2025
		String res = "";
		String currRes = "";
		try {
			for (var currIter : initIter) {
				currRes = currIter.toString();
				currRes = currRes.replaceAll(";", ", "); // del ; ins , for correct csv
				WB.addLog2("Fmtr.listIter, res=" + currRes + ", context=" + context, "", "Fmtr");
				res = res + currRes;
			}
		} catch (Exception ex) {
			WB.addLog("Fmtr.listIter(List<T> initIter, String context):String, ex=" + ex.getMessage(), "", "Fmtr");
		}
		return res;
	}

	public static String listVal2(List<LocalDate> initList, String context) throws Exception {
		// origin - 10.09.2024, last edit - 13.06.2025
		String res = "";
		try {
			for (var currList : initList) {
				res = res + currList.toString() + ", ";
			}
		} catch (Exception ex) {
			WB.addLog("Fmtr.listVal2(List<LocalDate> initList, String context):String, ex=" + ex.getMessage(), "",
					"Fmtr");
		}
		return res;
	}

	public static String listVal(String[] initList, String context) throws Exception {
		// origin - 14.02.2025, last edit - 13.06.2025
		String res = "";
		try {
			for (var currList : initList) {
				res = res + currList.toString() + ", ";
			}
		} catch (Exception ex) {
			WB.addLog("Fmtr.listVal(String[] initList, String context):String, ex=" + ex.getMessage(), "", "Fmtr");
		}
		return res;
	}

	public static String listVal(List<String> initList, String context) throws Exception {
		// origin - 24.08.2024, last edit - 13.06.2025
		String res = "";
		try {
			for (var currList : initList) {
				res = res + currList.toString() + ", ";
			}
		} catch (Exception ex) {
			WB.addLog("Fmtr.listVal(List<String> initList, String context):String, ex=" + ex.getMessage(), "", "Fmtr");
		}
		return res;
	}

//	public static String id(String currRes, String objAdd) throws Exception {// for toString
//		// origin - 21.08.2024, last edit - 30.06.2025
//		String res = Etc.fixTrim(currRes);
//		String fixStrAdd = Etc.fixTrim(objAdd.toString());
//		try {
//			if (fixStrAdd.isEmpty() == false) {
//				res = res + "[" + fixStrAdd + "]";
//			}
//		} catch (Exception ex) {
//			WB.addLog2("Fmtr.id(String currRes, String objAdd):String, ex=" + ex.getMessage(), "", "Fmtr");
//		}
//		return res;
//	}

	public static String addAnyway(String name, Object objAdd) throws Exception {// for toString
		// origin - 12.12.2024, last edit - 13.06.2025
		String res = "";
		String fixStrAdd = Etc.fixTrim(objAdd.toString());
		fixStrAdd = fixStrAdd.replaceAll(";", ","); // del ";" that not do wrap for csv-file field
		try {
			res = res + Etc.fixTrim(name) + " " + fixStrAdd + "  "; // + ", ";
		} catch (Exception ex) {
			WB.addLog2("Fmtr.addAnyway(String name, Object objAdd):String, ex=" + ex.getMessage(), "", "Fmtr");
		}
		return res;
	}

	public static String addIfNotZeroSize(String name, List<ModelDto> objAdd) throws Exception {// for toString
		// origin - 18.12.2024, last edit - 13.06.2025
		String res = "";
		try {
			if (objAdd.size() != 0) {
				res = res + Etc.fixTrim(name) + " " + objAdd.size() + "  "; // + ", ";
			}
		} catch (Exception ex) {
			WB.addLog2("Fmtr.addIfNotZeroSize(String name, List<ModelDto> objAdd):String, ex=" + ex.getMessage(), "",
					"Fmtr");
		}
		return res;
	}

	public static String addIfNotEmptyUnitVal(String name, UnitVal uvAdd) throws Exception {// CHECK think todo
		// origin - 11.06.2025, last edit - 13.06.2025
		String res = "";
		try {
			if (uvAdd.partVal.isEmpty()) {
				return res;
			}
			res = res + Etc.fixTrim(name) + " " + uvAdd.id + "  ";
		} catch (Exception ex) {
			WB.addLog2("Fmtr.addIfNotZeroUnitVal(String name, UnitVal uvAdd):String, ex=" + ex.getMessage(), "",
					"Fmtr");
		}
		return res;
	}

	public static String addIfNotZeroUnitVal(String name, UnitVal uvAdd) throws Exception {
		// origin - 11.06.2025, last edit - 13.06.2025
		String res = "";
		try {
			if (uvAdd.val == 0.00) {
				return res;
			}
			res = res + Etc.fixTrim(name) + " " + uvAdd.id + "  ";
		} catch (Exception ex) {
			WB.addLog2("Fmtr.addIfNotZeroUnitVal(String name, UnitVal uvAdd):String, ex=" + ex.getMessage(), "",
					"Fmtr");
		}
		return res;
	}

	public static String addIfNotEmpty(String name, Object objAdd) throws Exception {
		// origin - 21.08.2024, last edit - 13.06.2025
		String res = "";
		String fixStrAdd = Etc.fixTrim(objAdd.toString());
		fixStrAdd = fixStrAdd.replaceAll(";", ","); // del ";" that not do wrap for csv-file field
		try {

			if (Etc.strEquals(fixStrAdd, "0")) {// added 26.03.2025
				return res;
			}

			if (Etc.strEquals(fixStrAdd, "0.00")) {// added 26.03.2025
				return res;
			}

			if (Etc.strEquals(fixStrAdd, "")) {// added 26.03.2025
				return res;
			}

			if (fixStrAdd.isEmpty() == false) {
				res = res + Etc.fixTrim(name) + " " + fixStrAdd + "  "; // + ", ";
			}

		} catch (Exception ex) {
			WB.addLog2("Fmtr.addIfNotEmpty(String name, Object objAdd):String, ex=" + ex.getMessage(), "", "Fmtr");
		}
		return res;
	}

	private Fmtr() throws Exception {
		// origin - 24.08.2024, last edit - 05.03.2025
	}

	public static void test() throws Exception {
		// origin - 24.08.2024, last edit - 13.06.2025
		try {

//			// listIter
//			List<ModelDto> newListIter = ModelDto.getSubsetByMore(WB.abcLast.basic, "AbcCodePay");
//			Fmtr.listIter(newListIter, "Fmtr");

		} catch (Exception ex) {
			WB.addLog("Fmtr.test():void, ex=" + ex.getMessage(), "", "Fmtr");
		}
	}
}