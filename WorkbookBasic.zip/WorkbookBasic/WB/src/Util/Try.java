public final class Try {
	// origin - 06.08.2026, last edit - 26.08.2026

//	private static void testByMVEL() throws Exception {
//		// origin - 08.08.2026, last edit - 08.08.2026
//		try {
//			String code = "XlsxReader.test();TemplateDoc.test();TemplateDocEngine.test();TemplateDocPattern.test();";
//			// Передаем контекст: связываем имена в строке с реальными объектами/классами
//			Map<String, Object> context = new HashMap<>();
//			context.put("XlsxReader", XlsxReader.class); // Если методы статические
//			context.put("TemplateDoc", TemplateDoc.class);
//			context.put("TemplateDocEngine", TemplateDocEngine.class);
//			context.put("TemplateDocPattern", TemplateDocPattern.class);
//			// context.put("FIO", new FIO()); // Если методы вызываются у экземпляра
//			// Выполнение строки
//			MVEL.eval(code, context);
//		} catch (Exception ex) {
//			WB.addLog("WB.testByMVEL():void, ex=" + ex.getMessage(), "", "WB");
//		}
//	}

	public static void test() throws Exception {
		// origin - 08.08.2026, last edit - 08.08.2026
		try {

//			WB.addLog2("Try.testByMVEL():void", "", "Try");
//			Try.testByMVEL();

		} catch (Exception ex) {
			WB.addLog("Try.test():void, ex=" + ex.getMessage(), "", "Try");
		}
	}
}