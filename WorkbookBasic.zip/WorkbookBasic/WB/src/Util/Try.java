import javax.smartcardio.*;
import java.util.List;

public final class Try {
	// origin - 06.08.2026, last edit - 02.11.2026
	public static void SimCardReaderExample() {
		try {
			// 1. Получаем экземпляр фабрики терминалов (PC/SC)
			TerminalFactory factory = TerminalFactory.getDefault();
			CardTerminals terminals = factory.terminals();

			// 2. Получаем список доступных ридеров (терминалов)
			List<CardTerminal> terminalList = terminals.list();
			if (terminalList.isEmpty()) {
				System.out.println("Нет доступных ридеров смарт-карт.");
				return;
			}

			System.out.println("Найдены ридеры: " + terminalList);

			// Берем первый попавшийся ридер
			CardTerminal terminal = terminalList.get(0);

			// 3. Ждем карту в ридере (опционально) или проверяем её наличие
			if (!terminal.isCardPresent()) {
				System.out.println("Вставьте SIM-карту в ридер...");
				terminal.waitForCardPresent(0); // 0 = ждать бесконечно
			}

			// 4. Подключаемся к карте (протокол "T=0", "T=1" или "="*" для автоопределения)
			Card card = terminal.connect("*");
			System.out.println("Подключено к карте: " + card);

			// 5. Получаем канал обмена (обычно базовый канал 0)
			CardChannel channel = card.getBasicChannel();

			// 6. Пример отправки APDU-команды (например, выбор GSM Application или запрос
			// SELECT)
			// Команда SELECT (AID или файл): 00 A4 04 00 [длина] [AID]
			byte[] selectApdu = new byte[] { (byte) 0x00, (byte) 0xA4, (byte) 0x04, (byte) 0x00, (byte) 0x0A,
					(byte) 0xA0, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x87, (byte) 0x10, (byte) 0x02,
					(byte) 0xFF, (byte) 0x49, (byte) 0xFF };

			ResponseAPDU response = channel.transmit(new CommandAPDU(selectApdu));
			System.out.println(
					"Ответ карты (SW1 SW2): " + String.format("%02X %02X", response.getSW1(), response.getSW2()));

			// 7. Отключаемся от карты
			card.disconnect(true); // true = сбросить карту при отключении

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

//	private static void testByMVEL() throws Exception {
//		// origin - 08.08.2026, last edit - 08.08.2026
//		try {
//			String code = "XlsxReader.test();TemplateDoc.test();TemplateDocEngine.test();TemplateDocPattern.test();";
//			// Передаем контекст: связываем имена в строке с реальными объектами/классами
//			Map<String, Object> context = new HashMap<>();
//			context.put("XlsxReader", XlsxReader.class); // Если методы статические
//			context.put("TemplateDoc", TemplateDoc.class);
//			context.put("TemplateDocEngine", TemplateDocEngine.class);
//			context.put("TemplateDocPattern", TemplateDocPattern.class);
//			// context.put("FIO", new FIO()); // Если методы вызываются у экземпляра
//			// Выполнение строки
//			MVEL.eval(code, context);
//		} catch (Exception ex) {
//			WB.addLog("WB.testByMVEL():void, ex=" + ex.getMessage(), "", "WB");
//		}
//	}

	public static void test() throws Exception {
		// origin - 08.08.2026, last edit - 02.11.2026
		try {

//			WB.addLog2("Try.SimCardReaderExample():void", "", "Try");
//			Try.SimCardReaderExample();

//			WB.addLog2("Try.testByMVEL():void", "", "Try");
//			Try.testByMVEL();

		} catch (Exception ex) {
			WB.addLog("Try.test():void, ex=" + ex.getMessage(), "", "Try");
		}
	}
}