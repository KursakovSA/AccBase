import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

public class XlsxReader {
	// origin - 04.08.2026, last edit - 04.08.2026

	public static List<List<String>> get(String path, int index) {
		// origin - 04.08.2026, last edit - 08.08.2026
		List<List<String>> res = new ArrayList<>();
		try {
			if (InOut.hasFile(path) == false) {
				// WB.addLog2("XlsxReader.get(String):List<List<String>>, not exist path=" +
				// path, "", "XlsxReader");
				return res;
			}

			File xlsxFile = new File(path);
			if (index == 0) {
				res = XlsxReader.readFirstSheet(xlsxFile);
			}
			if (index != 0) {
				res = XlsxReader.readSheetByIndex(xlsxFile, index);
			}
		} catch (Exception ex) {
			WB.addLog("XlsxReader.get(String):List<List<String>>, ex=" + ex.getMessage(), "", "XlsxReader");
		}
		return res;
	}

	public static List<List<String>> readSheetByIndex(File file, int sheetIndex) {
		// origin - 08.08.2026, last edit - 08.08.2026
		// sheetIndex передается как 1 для первого листа, 2 для второго и т.д.
		List<List<String>> sheetData = new ArrayList<>();
		try (ZipFile zipFile = new ZipFile(file)) {
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser saxParser = factory.newSAXParser();
			List<String> sharedStrings = new ArrayList<>();

			// ШАГ 1: Парсим sharedStrings.xml (словарь строк)
			ZipEntry sharedStringsEntry = zipFile.getEntry("xl/sharedStrings.xml");
			if (sharedStringsEntry != null) {
				try (InputStream is = zipFile.getInputStream(sharedStringsEntry)) {
					SharedStringsHandler sstHandler = new SharedStringsHandler(sharedStrings);
					saxParser.parse(is, sstHandler);
				}
			}

			// ШАГ 2: Динамически формируем путь к нужному листу
			String sheetPath = "xl/worksheets/sheet" + sheetIndex + ".xml";
			ZipEntry sheetEntry = zipFile.getEntry(sheetPath);

			if (sheetEntry != null) {
				try (InputStream is = zipFile.getInputStream(sheetEntry)) {
					// Передаем ссылку на sheetData внутрь обработчика
					SheetHandler sheetHandler = new SheetHandler(sharedStrings, sheetData);
					saxParser.parse(is, sheetHandler);
				}
			} else {
				WB.addLog("XlsxReader: Лист №" + sheetIndex + " не найден в файле.", "", "XlsxReader");
			}
		} catch (Exception ex) {
			WB.addLog("XlsxReader.readSheetByIndex(File, int), ex=" + ex.getMessage(), "", "XlsxReader");
		}
		return sheetData;
	}

	public static List<List<String>> readFirstSheet(File file) {
		// origin - 04.08.2026, last edit - 05.08.2026
		List<List<String>> sheetData = new ArrayList<>();

		try (ZipFile zipFile = new ZipFile(file)) {
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser saxParser = factory.newSAXParser();

			List<String> sharedStrings = new ArrayList<>();

			// ШАГ 1: Парсим sharedStrings.xml (словарь строк)
			ZipEntry sharedStringsEntry = zipFile.getEntry("xl/sharedStrings.xml");
			if (sharedStringsEntry != null) {
				try (InputStream is = zipFile.getInputStream(sharedStringsEntry)) {
					SharedStringsHandler sstHandler = new SharedStringsHandler(sharedStrings);
					saxParser.parse(is, sstHandler);
				}
			}

			// ШАГ 2: Парсим лист и наполняем коллекцию sheetData
			ZipEntry sheetEntry = zipFile.getEntry("xl/worksheets/sheet1.xml");
			if (sheetEntry != null) {
				try (InputStream is = zipFile.getInputStream(sheetEntry)) {
					// Передаем ссылку на sheetData внутрь обработчика
					SheetHandler sheetHandler = new SheetHandler(sharedStrings, sheetData);
					saxParser.parse(is, sheetHandler);
				}
			}

		} catch (Exception ex) {
			WB.addLog("XlsxReader.readFirstSheet(File):List<List<String>>, ex=" + ex.getMessage(), "", "XlsxReader");
		}
		return sheetData;
	}

	private static class SharedStringsHandler extends DefaultHandler {
		// origin - 04.08.2026, last edit - 04.08.2026
		private final List<String> sharedStrings;
		private final StringBuilder textBuffer = new StringBuilder();
		private boolean isTextTag = false;

		public SharedStringsHandler(List<String> sharedStrings) {
			this.sharedStrings = sharedStrings;
		}

		@Override
		public void startElement(String uri, String localName, String qName, Attributes attributes) {
			// origin - 04.08.2026, last edit - 04.08.2026
			if ("t".equalsIgnoreCase(qName)) {
				isTextTag = true;
				textBuffer.setLength(0);
			}
		}

		@Override
		public void characters(char[] ch, int start, int length) {
			// origin - 04.08.2026, last edit - 04.08.2026
			if (isTextTag) {
				textBuffer.append(ch, start, length);
			}
		}

		@Override
		public void endElement(String uri, String localName, String qName) {
			// origin - 04.08.2026, last edit - 04.08.2026
			if ("t".equalsIgnoreCase(qName)) {
				isTextTag = false;
				sharedStrings.add(textBuffer.toString());
			}
		}
	}

	private static class SheetHandler extends DefaultHandler {
		// origin - 04.08.2026, last edit - 04.08.2026
		private final List<String> sharedStrings;
		private final List<List<String>> outputResultList; // Ссылка на итоговый список из основной программы
		private final StringBuilder cellContent = new StringBuilder();

		private List<String> currentRowData = null;
		private boolean isCellValue = false;
		private boolean isSharedString = false;
		private int currentColumnIndex = -1;

		// Принимаем outputResultList через конструктор
		public SheetHandler(List<String> sharedStrings, List<List<String>> outputResultList) {
			this.sharedStrings = sharedStrings;
			this.outputResultList = outputResultList;
		}

		@Override
		public void startElement(String uri, String localName, String qName, Attributes attributes) {
			// origin - 04.08.2026, last edit - 04.08.2026
			if ("row".equalsIgnoreCase(qName)) {
				currentRowData = new ArrayList<>();
			}

			if ("c".equalsIgnoreCase(qName)) {
				String cellRef = attributes.getValue("r");
				currentColumnIndex = nameToColumn(cellRef);

				String cellType = attributes.getValue("t");
				isSharedString = "s".equalsIgnoreCase(cellType);
			}

			if ("v".equalsIgnoreCase(qName)) {
				isCellValue = true;
				cellContent.setLength(0);
			}
		}

		@Override
		public void characters(char[] ch, int start, int length) {
			// origin - 04.08.2026, last edit - 04.08.2026
			if (isCellValue) {
				cellContent.append(ch, start, length);
			}
		}

		@Override
		public void endElement(String uri, String localName, String qName) {
			// origin - 04.08.2026, last edit - 04.08.2026
			if ("v".equalsIgnoreCase(qName)) {
				isCellValue = false;
				String value = cellContent.toString();

				if (isSharedString) {
					try {
						int idx = Integer.parseInt(value);
						if (idx >= 0 && idx < sharedStrings.size()) {
							value = sharedStrings.get(idx);
						}
					} catch (NumberFormatException e) {
						// Ошибка парсинга индекса
					}
				}

				if (currentRowData != null && currentColumnIndex >= 0) {
					while (currentRowData.size() < currentColumnIndex) {
						currentRowData.add("");
					}
					currentRowData.add(value);
				}
			}

			if ("row".equalsIgnoreCase(qName)) {
				if (currentRowData != null) {
					// Вместо вывода в консоль, добавляем собранную строку в итоговый список
					outputResultList.add(currentRowData);
					currentRowData = null;
				}
			}
		}

		private int nameToColumn(String cellRef) {
			// origin - 04.08.2026, last edit - 04.08.2026
			if (cellRef == null)
				return -1;
			int column = 0;
			for (int i = 0; i < cellRef.length(); i++) {
				char c = cellRef.charAt(i);
				if (Character.isDigit(c)) {
					break;
				}
				column = column * 26 + (c - 'A' + 1);
			}
			return column - 1;
		}
	}

	public static void test() throws Exception {
		// origin - 04.08.2026, last edit - 11.08.2026
		try {

//			WB.addLog2("XlsxReader.test.get(String; int):List<List<String>>", "", "XlsxReader");
//			for (var tmp1 : new String[] { "price.xlsx" }) {
//				for (var tmp2 : new int[] { 1, 2, 3, 4, 5, 6, 7 }) {
//					var tmp3 = InOut.getStrPathFileByFileNameInAppDir(tmp1);
//					var tmp4 = XlsxReader.get(tmp3, tmp2);
//					WB.addLog2("XlsxReader.test.get(String,int):List<List<String>>, res.size=" + tmp4.size() + ", tmp1="
//							+ tmp1 + ", tmp2=" + tmp2, "", "XlsxReader");
//					WB.log3Str(tmp4, "XlsxReader");
//					// WB.log(tmp4, "XlsxReader");
//				}
//			}

//			WB.addLog2("XlsxReader.test.get(String; int=0):List<List<String>>", "", "XlsxReader");
//			for (var tmp1 : new String[] { "111.xlsx", "222.xlsx", "test.xlsx", "CurrAccountPlan.xlsx", "KPVED.xlsx",
//					"KPVED_TNVED_GTIN.xlsx", "tralala.xlsx" }) {
//				var tmp2 = InOut.getStrPathFileByFileNameInAppDir(tmp1);
//				var tmp3 = XlsxReader.get(tmp2, 0);
//				WB.addLog2("XlsxReader.test.get(String,int=0):List<List<String>>, res.size=" + tmp3.size() + ", tmp1="
//						+ tmp1, "", "XlsxReader");
//				WB.log3Str(tmp3, "XlsxReader");
//			}

		} catch (Exception ex) {
			WB.addLog("XlsxReader.test():void, ex=" + ex.getMessage(), "", "XlsxReader");
		}
	}
}