import java.time.DayOfWeek;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.OffsetDateTime;
import java.time.Period;
import java.time.YearMonth;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unused")
public final class DateTool {
	// origin - 17.01.2024, last edit - 12.10.2025
	public static int defaultCountDayYear = 365;
	private static String defaultPredCentury = "19";
	private static String defaultCurrCentury = "20"; // ??? get this string for WB.maxDateSupported ??? or currDate ??
	private static int fullLenghtYear = 4;
	private static int shortLenghtYear = 2;
	public static int maxAgePerson = 120;
	public static int minAgePersonGettingPawnLoan = 18; // sectoral pawnshop
	public static String contextGettingPawnLoan = "Pawnshop.GettingPawnLoan"; // sectoral pawnshop

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("DateTool.static ctor, ex=" + ex.getMessage(), "", "DateTool");
		}
	}

	public static List<String> getRangeNowBackward(int step, int once) throws Exception {
		// origin - 20.02.2025, last edit - 14.06.2025
		List<String> res = new ArrayList<String>();
		String startDate = DateTool.formatter5(DateTool.getNow());
		try {
			var tmp1 = DateTool.getLocalDate(startDate);
			String tmp2 = DateTool.formatter5(tmp1);
			res.add(tmp2);
			for (int i = 1; i < once; i++) {
				tmp1 = tmp1.minusDays(step);
				tmp2 = DateTool.formatter5(tmp1);
				res.add(tmp2);
			}
		} catch (Exception ex) {
			WB.addLog("DateTool.getRangeNowBackward(2int):List<String>, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	private static boolean isValidDateBirth(LocalDate initDateBirth, String context) throws Exception {// TOTHINK
		// origin - 22.06.2024, last edit - 14.06.2025
		Boolean res = true;
		try {
			LocalDate dateNow = DateTool.getNow();

			if (initDateBirth.isAfter(dateNow)) {
				res = false;
			}

			if (DateTool.getAgeByDateBirth(initDateBirth) > DateTool.maxAgePerson) {
				res = false;
			}

			if (Etc.strEquals(context, DateTool.contextGettingPawnLoan)) {
				if (DateTool.getAgeByDateBirth(initDateBirth) < DateTool.minAgePersonGettingPawnLoan) {
					res = false;
				}
			}
		} catch (Exception ex) {
			WB.addLog("DateTool.isValidDateBirth(LocalDate, String):boolean, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	private static int getAgeByDateBirth(LocalDate initDateBirth) throws Exception {
		// origin - 22.06.2024, last edit - 14.06.2025
		int res = 0;
		try {
			LocalDate dateNow = DateTool.getNow();
			Period period = initDateBirth.until(dateNow);
			res = period.getYears();
		} catch (Exception ex) {
			WB.addLog("DateTool.getAgeByDateBirth(LocalDate):int, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static LocalDate getNow() throws Exception {
		// origin - 22.06.2024, last edit - 14.06.2025
		LocalDate res = null;
		try {
			res = LocalDate.now();
		} catch (Exception ex) {
			WB.addLog("DateTool.getNow():LocalDate, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static LocalDateTime getNow2() throws Exception {
		// origin - 18.12.2023, last edit - 14.06.2025
		LocalDateTime res = null;
		try {
			res = LocalDateTime.now(ZoneOffset.systemDefault().getRules().getOffset(Instant.now()));
		} catch (Exception ex) {
			WB.addLog("DateTool.getNow2():LocalDateTime, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static LocalTime getNow3() throws Exception {
		// origin - 28.06.2024, last edit - 14.06.2025
		LocalTime res = null;
		try {
			res = LocalTime.now(ZoneOffset.systemDefault().getRules().getOffset(Instant.now()));
		} catch (Exception ex) {
			WB.addLog("DateTool.getNow3():LocalTime, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	private static String getDefaultCentury(String initCentury) throws Exception {
		// origin - 22.06.2024, last edit - 14.06.2025
		String res = Etc.fixTrim(initCentury);
		try {
			if (Etc.strEquals(res, defaultPredCentury) == false) {
				if (Etc.strEquals(res, defaultCurrCentury) == false) {
					res = DateTool.defaultCurrCentury;
				}
			}
		} catch (Exception ex) {
			WB.addLog("DateTool.getDefaultCentury(String):String, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	private static String fixCentury(String initCentury) throws Exception {
		// origin - 21.06.2024, last edit - 14.06.2025
		String res = Etc.fixTrim(initCentury);
		try {
			res = DateTool.getDefaultCentury(res);
		} catch (Exception ex) {
			WB.addLog("DateTool.fixCentury(String):String, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static String getDay(LocalDate initDate) throws Exception {
		// origin - 21.06.2024, last edit - 14.06.2025
		String res = "";
		try {
			res = String.valueOf(initDate.getDayOfMonth());
			res = "00" + res; // ???magic string ???
			res = res.substring(res.length() - 2);
		} catch (Exception ex) {
			WB.addLog("DateTool.getDay(LocalDate):String, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static String getDay(String initKZIIN) throws Exception {
		// origin - 21.06.2024, last edit - 04.12.2025
		String res = "";
		initKZIIN = Etc.fixTrim(initKZIIN);
		try {
			if (initKZIIN.length() == FaceGovId.lenghtIIN) {
				res = initKZIIN.substring(4, 6);
			} else {
				res = "";
			}
		} catch (Exception ex) {
			WB.addLog("DateTool.getDay(String):String, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static String getValidDay(String day) throws Exception { // TODO
		// origin - 05.12.2025, last edit - 05.08.2026
		String res = day;
		try {
			var tmp = Etc.getIntByStr(day);
			if (tmp > 31) {
				res = "??";
			}
			if (tmp < 1) {
				res = "??";
			}
		} catch (Exception ex) {
			WB.addLog("DateTool.getValidDay(String):String, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static String getMonth(LocalDate initDate) throws Exception {
		// origin - 21.06.2024, last edit - 14.06.2025
		String res = "";
		try {
			res = String.valueOf(initDate.getMonthValue());
			res = "00" + res;
			res = res.substring(res.length() - 2);
		} catch (Exception ex) {
			WB.addLog("DateTool.getMonth(LocalDate):String, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static String getMonth(String initKZIIN) throws Exception {
		// origin - 21.06.2024, last edit - 04.11.2025
		String res = "";
		initKZIIN = Etc.fixTrim(initKZIIN);
		try {
			if (initKZIIN.length() == FaceGovId.lenghtIIN) {
				res = initKZIIN.substring(2, 4);
			} else {
				res = "";
			}
		} catch (Exception ex) {
			WB.addLog("DateTool.getMonth(String):String, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static String getValidMonth(String month) throws Exception { // TODO
		// origin - 05.11.2025, last edit - 05.08.2026
		String res = month;
		try {
			var tmp = Etc.getIntByStr(month);
			// WB.addLog2("DateTool.getValidMonth(String):String, tmp=" + tmp + ", month=" +
			// month, "", "DateTool");
			if (tmp > 12) {
				res = "??";
			}
			if (tmp < 1) {
				res = "??";
			}
		} catch (Exception ex) {
			WB.addLog("DateTool.getValidMonth(String):String, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static String getValidCentury(String initCentury, String initYear) throws Exception {
		// origin - 20.06.2024, last edit - 14.06.2025
		String res = "";
		try {
			initCentury = Etc.fixTrim(initCentury);

			String yearCurrDate = DateTool.getYear(String.valueOf(DateTool.getNow().getYear()));
			// WB.addLog2("DateTool.getValidCentury, yearCurrDate=" +yearCurrDate, "",
			// "DateTool");
			// WB.addLog2("DateTool.getValidCentury, initCentury=" +initCentury, "",
			// "DateTool");
			int numberYearCurrDate = Integer.parseInt(yearCurrDate);// ex. for 20-06-2024 this is = 24
			int numberInitYear = Integer.parseInt(initYear);// ex. for 25-11-1967 this is = 67
			if (numberYearCurrDate < numberInitYear) {// ex. 24 < 67
				res = DateTool.defaultPredCentury;
			}

			res = DateTool.fixCentury(res);
		} catch (Exception ex) {
			WB.addLog("DateTool.getValidCentury(2String):String, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static String getYear(LocalDate initDate) throws Exception {
		// origin - 21.06.2024, last edit - 14.06.2025
		String res = "";
		try {
			res = DateTool.getYear(String.valueOf(initDate.getYear()));
		} catch (Exception ex) {
			WB.addLog("DateTool.getYear(LocalDate):String, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static String getYear(String initYear) throws Exception {
		// origin - 20.06.2024, last edit - 04.11.2025
		String res = "";
		try {
			initYear = Etc.fixTrim(initYear);

			if (initYear.length() == DateTool.shortLenghtYear) {
				res = initYear; // if initYear = 2 simbols, ex. "24"
			}

			if (initYear.length() == DateTool.fullLenghtYear) {
				res = initYear.substring(2, 4);
			}

			if (initYear.length() == FaceGovId.lenghtIIN) {
				res = initYear.substring(0, 2);
			}
		} catch (Exception ex) {
			WB.addLog("DateTool.getYear(String):String, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static String getCentury(LocalDate initDate) throws Exception {
		// origin - 21.06.2024, last edit - 14.06.2025
		String res = "";
		try {
			res = DateTool.getCentury(getYear(initDate));
		} catch (Exception ex) {
			WB.addLog("DateTool.getCentury(LocalDate):String, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static String getCentury(String initYear) throws Exception {
		// origin - 20.06.2024, last edit - 14.06.2025
		String res = "";
		try {
			initYear = Etc.fixTrim(initYear);

			if (initYear.length() == DateTool.fullLenghtYear) {
				res = initYear.substring(0, 2);
			} else {
				res = DateTool.fixCentury("");
			}
		} catch (Exception ex) {
			WB.addLog("DateTool.getCentury(String):String, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static String getDateBirthFromKZIIN(String initKZIIN, String context) throws Exception {// sectoral pawnshop
		// origin - 19.06.2024, last edit - 05.11.2025
		String res = "";
		initKZIIN = Etc.fixTrim(initKZIIN);
		try {
			if (initKZIIN.length() != FaceGovId.lenghtIIN) {
				return res;
			}

			if (Etc.isDigitAll(initKZIIN) == false) {
				return res;
			}

			String day = DateTool.getDay(initKZIIN);
			day = DateTool.getValidDay(day);
			String month = DateTool.getMonth(initKZIIN);
			month = DateTool.getValidMonth(month);
			String year2 = DateTool.getYear(initKZIIN);
			String century = DateTool.getValidCentury(DateTool.getCentury(year2), year2);
			res = DateTool.formatter4(day, month, century, year2);
		} catch (Exception ex) {
			WB.addLog2("DateTool.getDateBirthFromKZIIN(2String):String, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static List<String> getDateList(String date1, String date2) throws Exception {
		// origin - 10.05.2025, last edit - 07.03.2026
		List<String> res = new ArrayList<String>();
		LocalDate dateStart = DateTool.getLocalDate(date1);
		LocalDate dateEnd = DateTool.getLocalDate(date2);
		try {
			for (; !dateStart.isAfter(dateEnd); dateStart = dateStart.plusDays(1)) {
				res.add(dateStart.toString());
			}
		} catch (Exception ex) {
			WB.addLog2("DateTool.getDateList(2String):List<String>, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

//	public static List<LocalDate> getListLocalDate(LocalDate date1, LocalDate date2) throws Exception {
//		// origin - 25.05.2024, last edit - 07.03.2026
//		List<LocalDate> res = new ArrayList<LocalDate>();
//		try {
//			for (; !dateStart.isAfter(dateEnd); dateStart = dateStart.plusDays(1)) {
//				res.add(dateStart);
//			}
//		} catch (Exception ex) {
//			WB.addLog2("DateTool.getListLocalDate(2LocalDate):List<LocalDate>, ex=" + ex.getMessage(), "", "DateTool");
//		}
//		return res;
//	}

	public static List<String> getStrYearList(String yearStart, String yearEnd) throws Exception {
		// origin - 22.03.2026, last edit - 22.03.2026
		List<String> res = new ArrayList<String>();
		try {
			var year1 = Integer.valueOf(yearStart);
			var year2 = Integer.valueOf(yearEnd);
			for (int i = year1; i <= year2; i++) {
				res.add(String.valueOf(i));
			}
		} catch (Exception ex) {
			WB.addLog2("DateTool.getStrYearList(2String):List<String>, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static List<String> getStrMonthList() throws Exception {
		// origin - 07.03.2026, last edit - 08.03.2026
		List<String> res = new ArrayList<String>(); // ex. "01", "02"..."11", "12"
		try {
			var month = "";
			for (int i = 1; i < 13; i++) {
				month = DateTool.getStrMonth(String.valueOf(i));
//				if (i < 10) {
//					month = "0" + String.valueOf(i);
//				}
				res.add(month);
			}
		} catch (Exception ex) {
			WB.addLog2("DateTool.getStrMonthList():List<String>, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static String getStrMonth(String month) throws Exception {
		// origin - 07.03.2026, last edit - 08.03.2026
		String res = "";
		try {
			var numberMonth = Integer.valueOf(month);
			res = String.valueOf(numberMonth); // ex. "11"
			if (numberMonth < 10) {
				res = "0" + String.valueOf(numberMonth); // ex. "04"
			}
		} catch (Exception ex) {
			WB.addLog("DateTool.getStrMonth(String):String, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static List<String> getListStartMonth(String year) throws Exception {
		// origin - 18.02.2024, last edit - 07.03.2026
		List<String> res = new ArrayList<String>(); // ex. "2026-0101", "2026-02-01"..."2026-12-01"
		year = Etc.fixTrim(year);
		var month = "0";
		try {
			for (int i = 1; i < 13; i++) {
				if (i < 10) {
					month = "0" + String.valueOf(i);
				}
				res.add(year + "-" + month + "-01");
			}
		} catch (Exception ex) {
			WB.addLog2("DateTool.getListStartMonth(String):List<String>, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static LocalDate getLocalDate(String expectedDate) throws Exception {
		// origin - 24.11.2023, last edit - 29.06.2026
		LocalDate res = DateTool.getNow();// null;

		expectedDate = Etc.fixTrim(expectedDate);
		expectedDate = expectedDate.replaceAll("--", "-");
		expectedDate = expectedDate.replaceAll("--", "-");
		if (expectedDate.length() > 10) { // need "2025-12-26", not need "2025-12-26 03:50:22"
			expectedDate = expectedDate.substring(0, 10);
		}
		if (expectedDate.isEmpty()) {
			res = DateTool.getNow();
			return res;
		}

		try {
			var tmp = new StrDate(expectedDate);
			expectedDate = tmp.id;
			res = LocalDate.parse(expectedDate);
		} catch (Exception ex) {
			WB.addLog("DateTool.getLocalDate(String):LocalDate, ex=" + ex.getMessage(), "", "DateTool");
			res = DateTool.getNow();
		}
		return res;
	}

	public static LocalTime getLocalTime(String expectedTime) throws Exception {
		// origin - 24.11.2023, last edit - 14.06.2025
		LocalTime res = LocalTime.MIN;
		expectedTime = Etc.fixTrim(expectedTime);
		try {
//			if (Etc.strMatch(expectedTime, ":") != 0) { // ex. "09:00:00", "07:00"
//				res = LocalTime.parse(expectedTime);
//			}

			if (expectedTime.length() == 1) { // ex. "9", "7"
				expectedTime = "0" + expectedTime; // fix to "09", "07"
			}

			if (expectedTime.length() > 5) { // ex. "2025-05-08" mistake
				return res;
			}

			if (Etc.strMatch(expectedTime, ":") == 0) { // ex. "09", "07"
				expectedTime = expectedTime + ":00";
				// res = LocalTime.parse(expectedTime);
			}

			res = LocalTime.parse(expectedTime);
		} catch (Exception ex) {
			WB.addLog("DateTool.getLocalTime(String):LocalTime, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

//	public static LocalDate fixLocalDate(LocalDate fixDate) throws Exception {
//		// origin - 02.10.2023, last edit - 02.05.2026
//		LocalDate res = fixDate;
//		try {
//			if (fixDate.isBefore(WB.minDateSupported)) {
//				res = WB.minDateSupported;
//			}
//			if (fixDate.isAfter(WB.maxDateSupported)) {
//				res = WB.maxDateSupported;
//			}
//		} catch (Exception ex) {
//			WB.addLog("DateTool.fixLocalDate(LocalDate):LocalDate, ex=" + ex.getMessage(), "", "DateTool");
//		}
//		return res;
//	}

	public static LocalDate getStartQuarter(LocalDate currDate) throws Exception {
		// origin - 21.02.2024, last edit - 07.10.2025
		LocalDate res = DateTool.getStartMonth(currDate);
		try {
			Month currMonth = currDate.getMonth();
			int currYear = currDate.getYear();

			if ((currMonth.equals(Month.JANUARY)) || (currMonth.equals(Month.FEBRUARY))
					|| (currMonth.equals(Month.MARCH))) {
				res = LocalDate.of(currYear, Month.JANUARY, 1);
			}

			if ((currMonth.equals(Month.APRIL)) || (currMonth.equals(Month.MAY)) || (currMonth.equals(Month.JUNE))) {
				res = LocalDate.of(currYear, Month.APRIL, 1);
			}

			if ((currMonth.equals(Month.JULY)) || (currMonth.equals(Month.AUGUST))
					|| (currMonth.equals(Month.SEPTEMBER))) {
				res = LocalDate.of(currYear, Month.JULY, 1);
			}

			if ((currMonth.equals(Month.OCTOBER)) || (currMonth.equals(Month.NOVEMBER))
					|| (currMonth.equals(Month.DECEMBER))) {
				res = LocalDate.of(currYear, Month.OCTOBER, 1);
			}
		} catch (Exception ex) {
			res = null;
			WB.addLog("DateTool.getStartQuarter(LocalDate):LocalDate, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static LocalDate getEndQuarter(LocalDate currDate) throws Exception {
		// origin - 21.02.2024, last edit - 07.10.2025
		LocalDate res = DateTool.getEndMonth(currDate);
		try {
			Month currMonth = currDate.getMonth();
			int currYear = currDate.getYear();

			if ((currMonth.equals(Month.JANUARY)) || (currMonth.equals(Month.FEBRUARY))
					|| (currMonth.equals(Month.MARCH))) {
				res = LocalDate.of(currYear, Month.MARCH, 31);
			}

			if ((currMonth.equals(Month.APRIL)) || (currMonth.equals(Month.MAY)) || (currMonth.equals(Month.JUNE))) {
				res = LocalDate.of(currYear, Month.JUNE, 30);
			}

			if ((currMonth.equals(Month.JULY)) || (currMonth.equals(Month.AUGUST))
					|| (currMonth.equals(Month.SEPTEMBER))) {
				res = LocalDate.of(currYear, Month.SEPTEMBER, 30);
			}

			if ((currMonth.equals(Month.OCTOBER)) || (currMonth.equals(Month.NOVEMBER))
					|| (currMonth.equals(Month.DECEMBER))) {
				res = LocalDate.of(currYear, Month.DECEMBER, 31);
			}
		} catch (Exception ex) {
			res = null;
			WB.addLog("DateTool.getEndQuarter(LocalDate):LocalDate, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static LocalDate getStartYear(LocalDate currDate) throws Exception {
		// origin - 22.01.2024, last edit - 14.06.2025
		LocalDate res = null;
		try {
			res = LocalDate.of(currDate.getYear(), 1, 1);
		} catch (Exception ex) {
			res = null;
			WB.addLog("DateTool.getStartYear(LocalDate):LocalDate, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static LocalDate getStartSecondHalfYear(LocalDate currDate) throws Exception {
		// origin - 26.01.2024, last edit - 14.06.2025
		LocalDate res = null;
		try {
			res = LocalDate.of(currDate.getYear(), 7, 1);
		} catch (Exception ex) {
			res = null;
			WB.addLog("DateTool.getStartFirstHalfYear(LocalDate):LocalDate, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static LocalDate getEndFirstHalfYear(LocalDate currDate) throws Exception {
		// origin - 26.01.2024, last edit - 14.06.2025
		LocalDate res = null;
		try {
			res = LocalDate.of(currDate.getYear(), 6, 30);
		} catch (Exception ex) {
			res = null;
			WB.addLog("DateTool.getEndFirstHalfYear(LocalDate):LocalDate, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static LocalDate getStartHalfYear(LocalDate currDate) throws Exception {
		// origin - 26.07.2024, last edit - 14.06.2025
		LocalDate res = null;
		try {
			if (currDate.isBefore(DateTool.getEndFirstHalfYear(currDate))) {
				res = DateTool.getStartYear(currDate);
			}
			if (currDate.isAfter(DateTool.getEndFirstHalfYear(currDate))) {
				res = DateTool.getStartSecondHalfYear(currDate);
			}
		} catch (Exception ex) {
			res = null;
			WB.addLog("DateTool.getstartHalfYear(LocalDate):LocalDate, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static LocalDate getEndHalfYear(LocalDate currDate) throws Exception {
		// origin - 26.07.2024, last edit - 14.06.2025
		LocalDate res = null;
		try {
			if (currDate.isBefore(DateTool.getEndFirstHalfYear(currDate))) {
				res = DateTool.getEndFirstHalfYear(currDate);
			}
			if (currDate.isAfter(DateTool.getEndFirstHalfYear(currDate))) {
				res = DateTool.getEndYear(currDate);
			}
		} catch (Exception ex) {
			res = null;
			WB.addLog("DateTool.getEndHalfYear(LocalDate):LocalDate, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static LocalDate getEndYear(LocalDate currDate) throws Exception {
		// origin - 22.01.2024, last edit - 14.06.2025
		LocalDate res = null;
		try {
			res = LocalDate.of(currDate.getYear(), 12, 31);
		} catch (Exception ex) {
			res = null;
			WB.addLog("DateTool.getEndYear(LocalDate):LocalDate, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static LocalDate getStartMonth(LocalDate currDate) throws Exception {
		// origin - 22.01.2024, last edit - 14.06.2025
		LocalDate res = null;
		try {
			res = YearMonth.of(currDate.getYear(), currDate.getMonth()).atDay(1);
		} catch (Exception ex) {
			res = null;
			WB.addLog("DateTool.getStartMonth(LocalDate):LocalDate, ex=" + ex.getMessage(), "", "DateTool");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static LocalDate getEndMonth(LocalDate currDate) throws Exception {
		// origin - 22.01.2024, last edit - 14.06.2025
		LocalDate res = null;
		try {
			res = YearMonth.of(currDate.getYear(), currDate.getMonth()).atEndOfMonth();
		} catch (Exception ex) {
			res = null;
			WB.addLog("DateTool.getEndMonth(LocalDate):LocalDate, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	private static LocalDate getStartWeek(LocalDate currDate) throws Exception {
		// origin - 26.05.2024, last edit - 14.06.2025
		LocalDate res = null;
		try {
			res = currDate.with(DayOfWeek.MONDAY);
		} catch (Exception ex) {
			WB.addLog("DateTool.getStartWeek(LocalDate):LocalDate, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	private static LocalDate getEndWeek(LocalDate currDate) throws Exception {
		// origin - 26.05.2024, last edit - 14.06.2025
		LocalDate res = null;
		try {
			res = currDate.with(DayOfWeek.SUNDAY);
		} catch (Exception ex) {
			WB.addLog("DateTool.getEndWeek(LocalDate):LocalDate, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static String getLabelDateTimeForFileName() throws Exception {
		// origin - 27.12.2023, last edit - 14.06.2025
		String res = Etc.fixTrim(formatter(getNow2()));
		try {
			res = res.replaceAll("-", "_");
			res = res.replaceAll(":", "_");
			res = res + "_";
		} catch (Exception ex) {
			WB.addLog("DateTool.getLabelDateTimeForFileName():String, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static LocalDate getEndDateFromDuration(LocalDate date1, int duration) throws Exception {
		// origin - 10.09.2024, last edit - 14.06.2025
		LocalDate res = date1;
		try {
			// res = (int)java.time.temporal.ChronoUnit.DAYS.between(date1, date2);
			// res = ChronoUnit.DAYS.between(date1.plusDays(duration), date1);
			res = date1.plusDays(duration);
		} catch (Exception ex) {
			WB.addLog("DateTool.getEndDateFromDuration(LocalDate, int):LocalDate, ex=" + ex.getMessage(), "",
					"DateTool");
		}
		return res;
	}

	public static int getDuration(LocalDateTime date1, LocalDateTime date2) throws Exception {// in ms
		// origin - 21.05.2024, last edit - 14.06.2025
		int res = 0;
		try {
			res = Math.abs((int) Etc.roundCustom(Duration.between(date2, date1).toMillis(), Etc.round0));
		} catch (Exception ex) {
			WB.addLog("DateTool.getDuration(2LocalDateTime):int, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	public static int getDuration(OffsetDateTime date1, OffsetDateTime date2) throws Exception {// in ms
		// origin - 21.10.2023, last edit - 14.06.2025
		int res = 0;
		try {
			res = Math.abs((int) Etc.roundCustom(Duration.between(date2, date1).toMillis(), Etc.round0));
		} catch (Exception ex) {
			WB.addLog("DateTool.getDuration(2OffsetDateTime):int, ex=" + ex.getMessage(), "",
					"DateTool");
		}
		return res;
	}

	// ex. "2024-12-31"
	public static String formatter5(LocalDate formatterLocalDate) throws Exception {
		// origin - 28.06.2024, last edit - 14.06.2025
		String res = "";
		try {
			res = formatterLocalDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")).toString();
		} catch (Exception ex) {
			WB.addLog("DateTool.formatter5(LocalDate):String, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	// ex. "25.12.2006"
	private static String formatter4(String day, String month, String century, String year2) throws Exception {
		// origin - 22.06.2024, last edit - 14.06.2025
		String res = "";
		try {
			res = day + "." + month + "." + century + year2;
		} catch (Exception ex) {
			WB.addLog("DateTool.formatter4(4String):String, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	// ex. "2006-12-25"
	public static String formatter3(String day, String month, String century, String year2) throws Exception {
		// origin - 22.06.2024, last edit - 14.06.2025
		String res = "";
		try {
			res = century + year2 + "-" + month + "-" + day;
		} catch (Exception ex) {
			WB.addLog("DateTool.formatter3(4String):String, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	// ex. "2006-12-25T12:45:54"
	public static String formatter2(LocalDateTime formatterLocalDateTime) throws Exception {
		// origin - 21.05.2024, last edit - 14.06.2025
		String res = "";
		try {
			res = formatterLocalDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss")).toString();
		} catch (Exception ex) {
			WB.addLog("DateTool.formatter2(LocalDateTime):String, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	// ex. "2006-12-25T12:45:54.8796"
	public static String formatter(LocalDateTime formatterLocalDateTime) throws Exception {
		// origin - 21.05.2024, last edit - 14.06.2025
		String res = "";
		try {
			res = formatterLocalDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSS")).toString();
		} catch (Exception ex) {
			WB.addLog("DateTool.formatter(LocalDateTime):String, ex=" + ex.getMessage(), "", "DateTool");
		}
		return res;
	}

	private DateTool() {
		// origin - 04.11.2024, last edit - 04.11.2024
	}

	public static void test() throws Exception {
		// origin - 17.01.2024, last edit - 02.05.2026
		try {

//			WB.addLog2("DateTool.test.getStrYearList(2String):List<String>", "", "DateTool");
//			for (var tmp1 : List.of("2021", "2022")) {
//				for (var tmp2 : List.of("2027", "2028")) {
//					WB.addLog2(
//							"DateTool.test.getStrYearList(2String):List<String>, res="
//									+ DateTool.getStrYearList(tmp1, tmp2) + ", tmp1=" + tmp1 + ", tmp2=" + tmp2,
//							"", "DateTool");
//				}
//			}

//			WB.addLog2("DateTool.test.getListStartMonth(String):List<String>", "", "DateTool");
//			for (var tmp1 : List.of("2021", "2022", "2023", "2024", "2025", "2026", "2027", "2028")) {
//				WB.addLog2("DateTool.test.getListStartMonth(String):List<String>, res="
//						+ DateTool.getListStartMonth(tmp1) + ", tmp1=" + tmp1, "", "DateTool");
//			}

//			// getEndDateFromDuration() LocalDate, int
//			WB.addLog2("DateTool.test.getEndDateFromDuration(LocalDate, int), res="
//					+ DateTool.getEndDateFromDuration(DateTool.getNow(), 10) + ", testDate=" + DateTool.getNow()
//					+ ", duration=10", "", "DateTool");

//			// getDuration() LocalDate
//			for (var testDate : testLocalDate) {
//				WB.addLog2("DateTool.test.getDuration(LocalDate), res=" + DateTool.getDuration(DateTool.getNow(), testDate) + ", testDate="
//						+ testDate, "", "DateTool");
//			}

//			WB.addLog2("DateTool.test.getDateBirthFromKZIIN(2String)", "", "DateTool");
//			var arg1 = new String[] { "671125567453", "87112567676776767676", "87664gfgf", "361125567453",
//					"971125567453", "021125567453", "231125567453", null };
//			for (var testArg1 : arg1) {
//				WB.addLog2("DateTool.test.getDateBirthFromKZIIN(2String), res="
//						+ DateTool.getDateBirthFromKZIIN(testArg1, DateTool.contextGettingPawnLoan) + ", testArg1=" + testArg1,
//						"", "DateTool");
//			}

		} catch (Exception ex) {
			WB.addLog("DateTool.test():void, ex=" + ex.getMessage(), "", "DateTool");
		}
	}
}