import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public final class InOut { // TODO
	// origin - 30.09.2023, last edit - 26.02.2026

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("InOut.static ctor, ex=" + ex.getMessage(), "", "InOut");
		}
	}

	public static boolean hasFile(String pathFile) throws Exception {
		// origin - 23.02.2026, last edit - 15.10.2026
		boolean res = false;
		try {
			if (Etc.strNotValid(pathFile)) {
				return res;
			}

			Path checkFilePath = Paths.get(pathFile);
			if (Files.exists(checkFilePath)) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("InOut.hasFile(String):boolean, ex=" + ex.getMessage(), "", "InOut");
		}
		return res;
	}

	public static boolean hasFile(String dir, String file) throws Exception {
		// origin - 07.12.2023, last edit - 19.10.2026
		boolean res = false;
		try {
			if (Etc.strNotValid(dir, file)) {
				return res;
			}

			Path checkFilePath = Paths.get(dir + File.separator + file);
			if (Files.exists(checkFilePath)) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("InOut.hasFile(2String):boolean, ex=" + ex.getMessage(), "", "InOut");
		}
		return res;
	}

	public static String getStrPathFileByFileNameInAppDir(String fileName) throws Exception {
		// origin - 08.08.2026, last edit - 15.10.2026
		String res = "";
		try {
			if (Etc.strNotValid(fileName)) {
				return res;
			}
			for (var curr : WB.appDir) {
				var tmp = curr + File.separator + fileName;
				if (InOut.hasFile(tmp)) {
					res = tmp;
					return res;
				}
			}

			if (res.isEmpty()) {
				WB.addLog2("Xlsx2csv.getStrPathFileByFileNameInAppDir(String):String, not exist in WB.appDir fileName="
						+ fileName, "", "Xlsx2csv");
			}
		} catch (Exception ex) {
			WB.addLog("InOut.getStrPathFileByFileNameInAppDir(String):String, ex=" + ex.getMessage() + ", fileName="
					+ fileName, "", "InOut");
		}
		return res;
	}

	public static List<String> getPathFileByDir(String dir) throws Exception {
		// origin - 02.03.2026, last edit - 15.10.2026
		List<String> res = new ArrayList<String>();
		try {
			if (Etc.strNotValid(dir)) {
				return res;
			}
			try (Stream<Path> paths = Files.walk(Paths.get(dir))) {
				paths.filter(Files::isRegularFile).forEach(path -> res.add(path.toString())); // only files less dirs
			} catch (Exception ex) {
				WB.addLog("InOut.getPathFileByDir(String):List<String>, stream, ex=" + ex.getMessage(), "", "InOut");
			}
		} catch (Exception ex) {
			WB.addLog("InOut.getPathFileByDir(String):List<String>, ex=" + ex.getMessage(), "", "InOut");
		}
		return res;
	}

	public static String getFileName(String pathFile) throws Exception {
		// origin - 03.06.2024, last edit - 15.10.2025
		String res = "";
		try {
			if (Etc.strNotValid(pathFile)) {
				return res;
			}
			pathFile = Etc.delStr(pathFile, Conn.prefixJdbcSqlite);// clean prefix JDBC if pathFile = conn
			Path p = Paths.get(pathFile);
			File f = p.toFile();
			res = Etc.fixTrim(f.getName());
		} catch (Exception ex) {
			WB.addLog("InOut.getFileName(String):String, ex=" + ex.getMessage(), "", "InOut");
		}
		return res;
	}

	public static List<String> getPathFileListByDir(List<String> pathFileList, String dir) throws Exception {
		// origin - 04.03.2026, last edit - 04.03.2026
		List<String> res = new ArrayList<String>();
		try {
			var tmp = "";
			for (var curr : pathFileList) {
				tmp = dir + File.separator + curr;
				res.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("InOut.getPathFileListByDir(List<String>,String):List<String>, ex=" + ex.getMessage(), "",
					"InOut");
		}
		return res;
	}

	public static List<String> delFile(List<String> pathFileList) throws Exception {
		// origin - 04.03.2026, last edit - 04.03.2026
		List<String> res = new ArrayList<String>();
		try {
			for (var curr : pathFileList) {
				res.add(InOut.delFile(curr));
			}
			res = pathFileList;
		} catch (Exception ex) {
			WB.addLog("InOut.delfile(List<String>):List<String>, ex=" + ex.getMessage(), "", "InOut");
		}
		return res;
	}

	public static String delFile(String pathFile) throws Exception {
		// origin - 23.02.2026, last edit - 15.10.2026
		String res = "";
		try {
			if (Etc.strNotValid(pathFile)) {
				return res;
			}
			var tmp = Files.deleteIfExists(Path.of(pathFile));
			if (tmp) {
				res = pathFile;
				WB.addLog2("InOut.delFile(String):String>, res=" + res + ", pathFile=" + pathFile, "", "InOut");
			}
		} catch (Exception ex) {
			WB.addLog("InOut.delfile(String):String, ex=" + ex.getMessage(), "", "InOut");
		}
		return res;
	}

	public static String delFile(File file) throws Exception {
		// origin - 29.05.2024, last edit - 04.03.2026
		String res = "";
		try {
			var tmp = Files.deleteIfExists(file.toPath());
			if (tmp) {
				res = file.toString();
				WB.addLog2("InOut.delFile(File):String>, res=" + res + ", file=" + file, "", "InOut");
			}
		} catch (Exception ex) {
			WB.addLog("InOut.delfile(File):String, ex=" + ex.getMessage(), "", "InOut");
		}
		return res;
	}

	public static StringBuilder addHeader(StringBuilder txtSwift) throws Exception {// TOTHINK
		// origin - 19.10.2023, last edit - 14.06.2025
		StringBuilder addTxtSwift = new StringBuilder(txtSwift);
		try {
		} catch (Exception ex) {
			WB.addLog("InOut.addHeader(StringBuilder):StringBuilder, ex=" + ex.getMessage(), "", "InOut");
		}
		return addTxtSwift;
	}

	public static StringBuilder addDetail(StringBuilder txtSwift) throws Exception {// TOTHINK
		// origin - 19.10.2023, last edit - 14.06.2025
		StringBuilder addTxtSwift = new StringBuilder(txtSwift);
		try {
		} catch (Exception ex) {
			WB.addLog("InOut.addDetail(StringBuilder):StringBuilder, ex=" + ex.getMessage(), "", "InOut");
		}
		return addTxtSwift;
	}

	public static StringBuilder addFooter(StringBuilder txtSwift) throws Exception {// TOTHINK
		// origin - 19.10.2023, last edit - 14.06.2025
		StringBuilder addTxtSwift = new StringBuilder(txtSwift);
		try {
		} catch (Exception ex) {
			WB.addLog("InOut.addFooter(StringBuilder):StringBuilder, ex=" + ex.getMessage(), "", "InOut");
		}
		return addTxtSwift;
	}

//	public static StringBuilder getSwiftOPV(Workbook WorkbookSalary) throws Exception {// TOTHINK
//		// origin - 30.09.2023, last edit - 20.03.2025
//		InOut currOut = new InOut();
//		currOut.file = "swift_OPV.txt";
//		currOut.path = dir + File.separator + currOut.file;
//		WB.addLog("InOut.getSwiftOPV, currOut.outputPath=" + currOut.path, "", "InOut");
//		StringBuilder txtSwift = new StringBuilder("");
//		try {
//			addHeader(txtSwift);
//			addDetail(txtSwift);
//			addFooter(txtSwift);
//		} catch (Exception ex) {
//			WB.addLog("InOut.getSwiftOPV, ex=" + ex.getMessage(), "", "InOut");
//		}
//		return txtSwift;
//	}

//	public static void getOut() throws Exception {// TOTHINK
//		// origin - 19.10.2023, last edit - 20.03.2025
//		try {
//			StringBuilder textSwift = getSwiftOPV(null);
//			InOut currOut = new InOut();
//			currOut.file = "swift_OPV.txt";
//			currOut.path = dir + File.separator + currOut.file;
//			Path pf = Paths.get(currOut.path);
//			WB.addLog("getOut, currOut.outputPath=" + currOut.path, "", "Output");
//			WB.writeReplace(pf, textSwift.toString());
//			WB.openFile(currOut.file);
//		} catch (Exception ex) {
//			WB.addLog("InOut.getOut, ex=" + ex.getMessage(), "", "InOut");
//		}
//	}

	private InOut() throws Exception {
		// origin - 04.12.2023, last edit - 26.02.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 26.02.2026, last edit - 26.02.2026
		try {
		} catch (Exception ex) {
			WB.addLog("InOut.clear():void, ex=" + ex.getMessage(), "", "InOut");
		}
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 02.03.2026
		try {

//			WB.addLog2("InOut.test.getPathFileByDir(String):List<String>", "", "InOut");
//			for (var tmp1 : new String[] { WB.tempDir, WB.inputOutputDir }) {
//				var tmp2 = InOut.getPathFileByDir(tmp1);
//				WB.addLog2(
//						"InOut.test.getPathFileByDir(String):List<String>, res.size=" + tmp2.size() + ", tmp1=" + tmp1,
//						"", "InOut");
//				WB.log(tmp2, "InOut");
//			}

		} catch (Exception ex) {
			WB.addLog("InOut.test():void, ex=" + ex.getMessage(), "", "InOut");
		}
	}
}
