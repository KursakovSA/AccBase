import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.net.URI;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class DocxReplacer {
	// origin - 11.09.2026, last edit - 11.09.2026
	private static final String DOCUMENT_XML_PATH = "word/document.xml";

	public static String get(String fileTemplate, String fileOutput, Map<String, String> replacements)
			throws Exception {
		// origin - 11.09.2026, last edit - 11.09.2026
		String res = "";
		try {
			if (fileTemplate == null) {
				return res;
			}
			if (fileTemplate.isEmpty()) {
				return res;
			}
			var tmp1 = InOut.getStrPathFileByFileNameInAppDir(fileTemplate);
			if (tmp1.isEmpty()) {
				return res;
			}

			File template = new File(tmp1);
			var tmp2 = WB.tempDir + File.separator + Etc.fixTrim(fileOutput);
			if (tmp2.isEmpty()) {
				return res;
			}
			File output = new File(tmp2);

			if (replacements.isEmpty()) {
				return res;
			}

			DocxReplacer replacer = new DocxReplacer();
			replacer.replacePatterns(template, output, replacements);
			res = output.toString();
		} catch (Exception ex) {
			WB.addLog("DocxReplacer.get(2String, Map):void, ex=" + ex.getMessage(), "", "DocxReplacer");
		}
		return res;
	}

	private void replacePatterns(File srcPath, File destPath, Map<String, String> replacements) throws Exception {
		// origin - 11.09.2026, last edit - 12.09.2026
		try {
			Files.copy(srcPath.toPath(), destPath.toPath(), StandardCopyOption.REPLACE_EXISTING);

			Map<String, String> env = new HashMap<>();
			env.put("create", "false");

			URI uri = URI.create("jar:" + destPath.toURI());
			try (FileSystem fs = FileSystems.newFileSystem(uri, env)) {
				Path xmlPath = fs.getPath(DOCUMENT_XML_PATH);

				DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
				dbf.setNamespaceAware(true);
				DocumentBuilder db = dbf.newDocumentBuilder();

				Document doc;
				try (InputStream is = Files.newInputStream(xmlPath)) {
					doc = db.parse(is);
				}

				boolean wasModified = this.processDocumentXml(doc, replacements);

				if (wasModified) {
					TransformerFactory tf = TransformerFactory.newInstance();
					Transformer transformer = tf.newTransformer();
					transformer.setOutputProperty(OutputKeys.INDENT, "no");
					transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");

					try (OutputStream os = Files.newOutputStream(xmlPath, StandardOpenOption.TRUNCATE_EXISTING)) {
						transformer.transform(new DOMSource(doc), new StreamResult(os));
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("DocxReplacer.replacePatterns(2File,Map):void, ex=" + ex.getMessage(), "", "DocxReplacer");
		}
	}

	private boolean processDocumentXml(Document doc, Map<String, String> replacements) throws Exception {
		// origin - 11.09.2026, last edit - 12.09.2026
		// Ищем все параграфы. Текст в таблицах Word тоже состоит из параграфов <w:p>,
		// метод покроет и их.
		NodeList paragraphs = doc.getElementsByTagName("w:p");
		boolean isChanged = false;
		try {
			for (int i = 0; i < paragraphs.getLength(); i++) {
				Element pElement = (Element) paragraphs.item(i);
				if (this.processParagraph(pElement, replacements)) {
					isChanged = true;
					// Сбрасываем счетчик цикла назад на 1 шаг, так как структура параграфа
					// изменилась,
					// и в нем могут быть еще метки, требующие повторного прохода
					i--;
				}
			}
		} catch (Exception ex) {
			WB.addLog("DocxReplacer.processDocumentXml(Document,Map):void, ex=" + ex.getMessage(), "", "DocxReplacer");
		}
		return isChanged;
	}

	private boolean processParagraph(Element pElement, Map<String, String> replacements) throws Exception {
		// origin - 11.09.2026, last edit - 12.09.2026
		// Находим все текстовые узлы <w:t> в текущем параграфе
		NodeList tNodes = pElement.getElementsByTagName("w:t");
		if (tNodes.getLength() == 0)
			return false;

		StringBuilder paragraphText = new StringBuilder();
		// Списки для маппинга каждого символа строки на конкретный XML-узел <w:t>
		List<Element> charToTextElementMap = new ArrayList<>();
		List<Integer> charToOffsetInElementMap = new ArrayList<>();

		// Шаг 1: Сканируем параграф и строим карту индексов
		for (int i = 0; i < tNodes.getLength(); i++) {
			Element tElem = (Element) tNodes.item(i);
			String text = tElem.getTextContent();
			for (int j = 0; j < text.length(); j++) {
				paragraphText.append(text.charAt(j));
				charToTextElementMap.add(tElem);
				charToOffsetInElementMap.add(j);
			}
		}

		String fullText = paragraphText.toString();

		// Шаг 2: Поиск паттернов в собранном тексте
		for (Map.Entry<String, String> entry : replacements.entrySet()) {
			String pattern = entry.getKey();
			String replacement = entry.getValue();

			int startIdx = fullText.indexOf(pattern);
			if (startIdx != -1) {
				int endIdx = startIdx + pattern.length() - 1;

				// Находим элементы <w:t>, где начинается и заканчивается паттерн
				Element startTElem = charToTextElementMap.get(startIdx);
				Element endTElem = charToTextElementMap.get(endIdx);

				// Находим родительские элементы <w:r> (runs), которые хранят стили оформления
				// букв
				Element startRElem = (Element) startTElem.getParentNode();
				Element endRElem = (Element) endTElem.getParentNode();

				int offsetInStartIdx = charToOffsetInElementMap.get(startIdx);

				// Шаг 3: Корректируем текст в первом элементе <w:t>
				String startText = startTElem.getTextContent();
				// Сохраняем то, что было до начала нашей метки в этом же узле
				String prefixText = startText.substring(0, offsetInStartIdx);

				// Если метка начинается и заканчивается в одном и том же узле <w:t>
				if (startTElem == endTElem) {
					int offsetInEndIdx = charToOffsetInElementMap.get(endIdx);
					String suffixText = startText.substring(offsetInEndIdx + 1);

					startTElem.setTextContent(prefixText + replacement + suffixText);
					startTElem.setAttribute("xml:space", "preserve");
				} else {
					// Если метка размазана по разным узлам, пишем в первый узел префикс + значение
					startTElem.setTextContent(prefixText + replacement);
					startTElem.setAttribute("xml:space", "preserve");

					// Корректируем последний элемент <w:t> — оставляем там только суффикс
					int offsetInEndIdx = charToOffsetInElementMap.get(endIdx);
					String endText = endTElem.getTextContent();
					String suffixText = endText.substring(offsetInEndIdx + 1);
					endTElem.setTextContent(suffixText);
					endTElem.setAttribute("xml:space", "preserve");

					// Шаг 4: Удаляем промежуточные узлы <w:r>, которые находились между стартовым и
					// конечным и полностью состояли из кусков нашей метки
					List<Element> runsToRemove = new ArrayList<>();
					Node current = startRElem.getNextSibling();
					while (current != null && current != endRElem) {
						if (current instanceof Element && "w:r".equals(current.getNodeName())) {
							runsToRemove.add((Element) current);
						}
						current = current.getNextSibling();
					}

					// Физическое удаление промежуточных элементов
					for (Element r : runsToRemove) {
						pElement.removeChild(r);
					}

					// Если в конечном элементе <w:t> после отсечения метки вообще не осталось
					// текста, удаляем весь этот run <w:r>
					if (suffixText.isEmpty()) {
						pElement.removeChild(endRElem);
					}
				}
				// Сигнализируем, что структура изменена. Перезапустим сканирование этого
				// параграфа.
				return true;
			}
		}
		return false;
	}

	public static void test() throws Exception {
		// origin - 11.09.2026, last edit - 12.09.2026
		try {

//			{
//				WB.addLog2("DocxReplacer.test.get(2String;Map):String", "", "DocxReplacer");
//				var tmp1 = "DocxReplacerTest.docx";
//				String tmp2 = "DocxReplacerTest_tmp.docx";
//				Map<String, String> tmp3 = new HashMap<>();
//				tmp3.put("[NumberDeal]", "1234567");
//				tmp3.put("[DateDeal]", DateTool.formatter(DateTool.getNow2()));
//				tmp3.put("[NumberPoint]", "Point1");
//				var tmp4 = DocxReplacer.get(tmp1, tmp2, tmp3);
//				WB.addLog2(
//						"DocxReplacer.test.get(2String,Map):String, res=" + tmp4 + ", tmp1=" + tmp1 + ", tmp2=" + tmp2,
//						"", "DocxReplacer");
//			}

		} catch (Exception ex) {
			WB.addLog("DocxReplacer.test():void, ex=" + ex.getMessage(), "", "DocxReplacer");
		}
	}
}