import java.util.ArrayList;
import java.util.List;

public final class User {
	// origin - 11.03.2025, last edit - 18.11.2025
	public String table, src, id, parent, date1, date2, code, description, geo, role, info, mark, more;
	public String staffTableId, pointId, fullName, comment, access, password, grant, defect;
	public static FaceDto currUser;

	static {
		try {
			User.currUser = User.get("Face.FA1", "Face.FA1.User1");
			// WB.addLog2("User.currUser=" + User.currUser, "", "User");
		} catch (Exception ex) {
			WB.addLog("User.static ctor, ex=" + ex.getMessage(), "", "User");
		}
	}

	// full list user positions
	public static List<FaceDto> get() throws Exception {
		// origin - 26.10.2025, last edit - 26.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var listModelDto = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter("Role.Face.User"), "Face");
			if (listModelDto.size() != 0) {
				for (var currFace : listModelDto) {
					if (currFace.id.isEmpty() == false) {
						var tmp = new FaceDto(currFace);
						res.add(tmp);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("User.get():List<FaceDto>, ex=" + ex.getMessage(), "", "User");
		}
		return res;
	}

	// full list user positions for parentId
	public static List<FaceDto> get(String parentId) throws Exception {
		// origin - 04.05.2025, last edit - 24.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var listModelDto = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, "Role.Face.User"),
					"Face");
			if (listModelDto.size() != 0) {
				for (var currFace : listModelDto) {
					if (currFace.id.isEmpty() == false) {
						var tmp = new FaceDto(currFace);
						res.add(tmp);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("User.get(String):List<FaceDto>, ex=" + ex.getMessage(), "", "User");
		}
		return res;
	}

	// full list user positions for parentId, faceUserId
	public static FaceDto get(String parentId, String faceUserId) throws Exception {
		// origin - 27.10.2025, last edit - 27.10.2025
		FaceDto res = new FaceDto();
		try {
			var listModelDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentCodeRoleFilter(parentId, faceUserId, "Role.Face.User"), "Face");
			if (listModelDto.size() != 0) {
				for (var currFace : listModelDto) {
					if (currFace.id.isEmpty() == false) {
						res = new FaceDto(currFace);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("User.get(2String):List<FaceDto>, ex=" + ex.getMessage(), "", "User");
		}
		return res;
	}

	// full list user positions on date1
	public static List<FaceDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 11.03.2025, last edit - 24.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var listFaceDto = User.get(parentId);
			if (listFaceDto.size() != 0) {
				res = FaceDto.getChrono(DateTool.getLocalDate(date1), listFaceDto);
			}
		} catch (Exception ex) {
			WB.addLog("User.getCurr(2String):List<FaceDto>, ex=" + ex.getMessage(), "", "User");
		}
		return res;
	}

	// item user position on date1
	public static FaceDto getCurr(String date1, String faceParentId, String faceUserId) throws Exception {
		// origin - 11.03.2025, last edit - 27.10.2025
		FaceDto res = new FaceDto();
		try {
			var listFaceDto = List.of(User.get(faceParentId, faceUserId));
			if (listFaceDto.size() != 0) {
				res = FaceDto.getChrono(DateTool.getLocalDate(date1), listFaceDto, "");
			}
		} catch (Exception ex) {
			WB.addLog("User.getCurr(3String):FaceDto, ex=" + ex.getMessage(), "", "User");
		}
		return res;
	}
	
	private void validate() throws Exception { //TODO
		// origin - 18.11.2025, last edit - 18.11.2025
		try {
			if (this.access.isEmpty()) {
				this.defect = this.defect + "empty access; ";
			}
		} catch (Exception ex) {
			WB.addLog("User.validate():void, ex=" + ex.getMessage(), "", "User");
		}
	}

	private void getId() throws Exception {
		// origin - 15.10.2025, last edit - 24.10.2025
		try {
			this.id = this.code + ", " + this.description;
			if (this.grant.isEmpty() == false) {
				this.id = this.id + ", for grant " + this.grant;
			}
		} catch (Exception ex) {
			WB.addLog("User.getId():void, ex=" + ex.getMessage(), "", "User");
		}
	}

	private void isExist() throws Exception {
		// origin - 11.03.2025, last edit - 18.11.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentCodeRoleFilter(this.parent, this.code, "Role.Face.User"), "Face");
			if (listDto.size() != 0) {
				var currDto = listDto.getFirst();
				this.date1 = DefVal.setCustom(this.date1, currDto.date1);
				this.date2 = DefVal.setCustom(this.date2, currDto.date2);
				this.id = DefVal.setCustom(this.id, currDto.id);
				this.parent = DefVal.setCustom(this.parent, currDto.parent);
				this.code = DefVal.setCustom(this.code, currDto.code);
				this.description = DefVal.setCustom(this.description, currDto.description);
				this.geo = DefVal.setCustom(this.geo, currDto.geo);
				this.role = DefVal.setCustom(this.role, currDto.role);
				this.info = DefVal.setCustom(this.info, currDto.info);
				this.more = DefVal.setCustom(this.more, currDto.more);
				this.mark = DefVal.setCustom(this.mark, currDto.mark);
				this.getFieldFromMore();
				this.correct();
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("User.isExist():void, ex=" + ex.getMessage(), "", "User");
		}
	}

	private void correct() throws Exception { // TODO
		// origin - 10.10.2025, last edit - 23.10.2025
		try {
			// this.staffTableId = MoreVal.getFieldByKey(this.more, "StaffTableId");
			// this.pointId = MoreVal.getFieldByKey(this.more, "PointId");
		} catch (Exception ex) {
			WB.addLog("User.correct():void, ex=" + ex.getMessage(), "", "User");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 12.08.2025, last edit - 24.10.2025
		try {
			this.staffTableId = MoreVal.getFieldByKey(this.more, "StaffTableId");
			this.pointId = MoreVal.getFieldByKey(this.more, "PointId");
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.access = MoreVal.getFieldByKey(this.more, "Access");
			this.password = MoreVal.getFieldByKey(this.more, "Password");
			this.grant = MoreVal.getFieldByKey(this.more, "Grant");
		} catch (Exception ex) {
			WB.addLog("User.getFieldFromMore():void, ex=" + ex.getMessage(), "", "User");
		}
	}

	public User(String ParentId, String FaceUserId) throws Exception {
		// origin - 24.03.2025, last edit - 18.11.2025
		this.clear();
		this.src = ParentId + "," + FaceUserId;
		this.parent = ParentId;
		this.code = FaceUserId;
		this.isExist();
		this.getId();
		this.validate();
	}

	public User(String ParentIdFaceUserId) throws Exception { // ParentIdFaceUserId = "ParentId , FaceUserId"
		// origin - 09.10.2025, last edit - 18.11.2025
		this.clear();
		this.src = ParentIdFaceUserId;
		var tmp = new TwoVal(ParentIdFaceUserId);
		this.parent = tmp.val1;
		this.code = tmp.val2;
		this.isExist();
		this.getId();
		this.validate();
	}

	public User() throws Exception {
		// origin - 11.03.2025, last edit - 11.03.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 11.03.2025, last edit - 18.11.2025
		try {
			this.table = "Face";
			this.src = this.id = this.parent = this.date1 = this.date2 = this.code = this.description = "";
			this.geo = this.role = this.info = this.more = this.mark = "";
			this.staffTableId = this.pointId = this.fullName = this.comment = this.password = this.access = this.grant = this.defect = "";
		} catch (Exception ex) {
			WB.addLog("User.clear():void, ex=" + ex.getMessage(), "", "User");
		}
	}

	public String toString() {
		// origin - 11.03.2025, last edit - 18.11.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addAnyway(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", staffTableId ", this.staffTableId);
			res = res + Fmtr.addIfNotEmpty(", pointId ", this.pointId);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", access ", this.access);
			res = res + Fmtr.addIfNotEmpty(", password ", this.password);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", grant ", this.grant);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 11.03.2025, last edit - 18.11.2025
		try {

//			WB.addLog2("User.test.get():List<FaceDto>", "", "User");
//			var tmp = User.get();
//			WB.addLog2("User.test.get():List<FaceDto>, res.size=" + tmp.size(), "", "User");
//			WB.log(tmp, "User");

//			WB.addLog2("User.test.get(String):List<FaceDto>", "", "User");
//			for (var tmp1 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
//				var tmp2 = User.get(tmp1);
//				WB.addLog2("User.test.get(String):List<FaceDto>, res.size=" + tmp2.size() + ", parentId=" + tmp1, "",
//						"User");
//				WB.log(tmp2, "User");
//			}

//			WB.addLog2("User.test.get(2String):FaceDto", "", "User");
//			for (var tmp1 : new String[] { "Face.FA1 , Face.FA1.User1", "Face.FA1 , Face.FA1.User2",
//					"Face.kgd, Face.kgd.User1", "Face.Tralala , Face.Tralala.User1" }) {
//				var tmp2 = new TwoVal(tmp1);
//				WB.addLog2("User.test.getCurr(2String):FaceDto, res=" + User.get(tmp2.val1, tmp2.val2)
//						+ ", faceParentId=" + tmp2.val1 + ", faceUserId=" + tmp2.val2, "", "User");
//			}

//			WB.addLog2("User.test.getCurr(2String):List<FaceDto>", "", "User");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-31", "2025-02-20", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
//					var tmp3 = User.getCurr(tmp1, tmp2);
//					WB.addLog2("User.test.getCurr(2String):List<FaceDto>, res.size=" + tmp3.size() + ", date1=" + tmp1
//							+ ", parentId=" + tmp2, "", "User");
//					WB.log(tmp3, "User");
//				}
//			}

//			WB.addLog2("User.test.getCurr(3String):FaceDto", "", "User");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-20",
//					"2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1 , Face.FA1.User1", "Face.FA1 , Face.FA1.User2",
//						"Face.kgd, Face.kgd.User1", "Face.Tralala , Face.Tralala.User1" }) {
//					var tmp3 = new TwoVal(tmp2);
//					WB.addLog2(
//							"User.test.getCurr(3String):FaceDto, res=" + User.getCurr(tmp1, tmp3.val1, tmp3.val2)
//									+ ", date1=" + tmp1 + ", faceParentId=" + tmp3.val1 + ", faceUserId=" + tmp3.val2,
//							"", "User");
//				}
//			}

//			WB.addLog2("User.test.ctor(2String)", "", "User");
//			for (var tmp1 : new String[] { "", "Face.FA1 , Face.FA1.User1", "Face.kgd , Face.kgd.User1",
//					"Face.Tralala , Face.Tralala.User1" }) {
//				var tmp2 = new TwoVal(tmp1);
//				var tmp3 = new User(tmp2.val1, tmp2.val2);
//				WB.addLog2("User.test.ctor(2String)=" + tmp3, "", "User");
//			}

//			WB.addLog2("User.test.ctor(String)", "", "User");
//			for (var tmp1 : new String[] { "", "Face.FA1 , Face.FA1.User1", "Face.kgd , Face.kgd.User1",
//					"Face.Tralala , Face.Tralala.User1" }) {
//				var tmp2 = new User(tmp1);
//				WB.addLog2("User.test.ctor(String)=" + tmp2, "", "User");
//			}

		} catch (Exception ex) {
			WB.addLog("User.test():void, ex=" + ex.getMessage(), "", "User");
		}
	}
}