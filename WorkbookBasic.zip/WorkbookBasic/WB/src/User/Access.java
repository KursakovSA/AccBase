public final class Access {
	// origin - 02.11.2024, last edit - 12.10.2025
	public String src, id, parent, date1, date2, code, description, geo, role, info, mark, more;
	public String fullName, comment;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Access.static ctor, ex=" + ex.getMessage(), "", "Access");
		}
	}

	public static boolean get(String userId, String actionId, String context) throws Exception {
		// origin - 27.10.2025, last edit - 15.12.2025
		boolean res = true;
		try {
			var userAccount = UserAccount.getByParentAndFaceCode(Face.currFA.code, userId);
			if (userAccount.id.isEmpty()) { // user not exist
				return false;
			}
			res = Access.getByDetail(userAccount, actionId, context);
		} catch (Exception ex) {
			WB.addLog("Access.get(3String):boolean, ex=" + ex.getMessage(), "", "Access");
		}
		return res;
	}

	public static boolean getCurr(String date1, String userId, String actionId, String context) throws Exception {
		// origin - 09.10.2025, last edit - 15.12.2025
		boolean res = true;
		try {
			var userAccount = UserAccount.getCurr(date1, Face.currFA.code, userId);
			if (userAccount.id.isEmpty()) { // user not exist on date1
				return false;
			}
			res = Access.getByDetail(userAccount, actionId, context);
		} catch (Exception ex) {
			WB.addLog("Access.getCurr(4String):boolean, ex=" + ex.getMessage(), "", "Access");
		}
		return res;
	}

	private static boolean getByDetail(UserAccount userAccount, String actionId, String context) throws Exception {
		// origin - 27.10.2025, last edit - 12.12.2025
		boolean res = true; // by default all allowed
		try {
			var credential = Access.getCredential(userAccount, actionId, context);

			// access forbidden
			switch (credential) {
			case "FullAccess,NoRestriction,Write,PawnshopContext" -> res = false;

//			case "OnLyRead,OnLyRead,Write,BasicContext" -> res = false;
//			case "OnLyRead,OnLyRead,Write,PawnshopContext" -> res = false;
//			case "OnLyRead,OnLyRead,Write,SaleContext" -> res = false;

			case "Paymaster,Paymaster,Write,BasicContext" -> res = false;
			case "Paymaster,Paymaster,Write,SaleContext" -> res = false;

			case "Manager,Manager,Write,BasicContext" -> res = false;
			case "Manager,Manager,Write,PawnshopContext" -> res = false;
			}

			// special case - only read, write, any context
			// var userActionOnlyRead = Access.getUserAction(userFaceDto, actionId);
			// if (Etc.strEquals(userActionOnlyRead, "OnLyRead,OnLyRead,Write")) {
			if (Etc.strContains(credential, "OnLyRead,OnLyRead,Write")) {
				res = false;
			}
		} catch (Exception ex) {
			WB.addLog("Access.getByDetail(FaceDto, 2String):boolean, ex=" + ex.getMessage(), "", "Access");
		}
		return res;
	}

	private static String getCredential(UserAccount userAccount, String actionId, String context) throws Exception {
		// origin - 28.10.2025, last edit - 12.12.2025
		String res = "";
		try {
			var userAccess = userAccount.access;
			res = Etc.fixTrim(userAccess.code) + "," + Etc.fixTrim(userAccess.description) + "," + Etc.fixTrim(actionId)
					+ "," + Etc.fixTrim(context);
		} catch (Exception ex) {
			WB.addLog("Access.getCredential(UserAccount, 2String):String, ex=" + ex.getMessage(), "", "Access");
		}
		return res;
	}

	private void correct() throws Exception {
		// origin - 10.10.2025, last edit - 15.10.2025
		try {
			if (this.code.isEmpty()) {
				this.code = "FullAccess";
				// WB.addLog2("Access.correct(), this.code=" + this.code, "", "Access");
			}

			if ((Etc.strEquals(this.code, "FullAccess")) & (this.description.isEmpty())) {
				this.description = "NoRestriction";
				// WB.addLog2("Access.correct(), this.description=" + this.description, "",
				// "Access");
			}

			if ((Etc.strEquals(this.code, "FullAccess") == false) & (this.description.isEmpty())) {
				this.description = this.code;
			}
		} catch (Exception ex) {
			WB.addLog("Access.correct():void, ex=" + ex.getMessage(), "", "Access");
		}
	}

	public Access(String Code, String Description) throws Exception {
		// origin - 09.10.2025, last edit - 14.12.2025
		this.clear();
		this.src = Code + "," + Description;
		this.code = Code;
		this.description = Description;
		this.correct();
		this.id = this.code + "," + this.description;
	}

	public Access(String CodeDescription) throws Exception {
		// origin - 09.10.2025, last edit - 14.12.2025
		this.clear();
		this.src = CodeDescription;
		var tmp = new TwoVal(CodeDescription);
		this.code = tmp.val1;
		this.description = tmp.val2;
		this.correct();
		this.id = this.code + "," + this.description;
	}

	public Access() throws Exception {
		// origin - 09.10.2025, last edit - 09.10.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 09.10.2025, last edit - 10.10.2025
		try {
			this.src = this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.geo = this.role = "";
			this.info = this.more = this.mark = "";
			this.fullName = this.comment = "";
		} catch (Exception ex) {
			WB.addLog("Access.clear():void, ex=" + ex.getMessage(), "", "Access");
		}
	}

	public String toString() {
		// origin - 09.10.2025, last edit - 15.10.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 02.11.2024, last edit - 18.11.2025
		try {

//			WB.addLog2("Access.test.getCurr(4String):boolean", "", "Access");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-01", "2025-01-15", "2025-01-31", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1.User1", "Face.FA1.User2", "Face.FA1.User3", "Face.FA1.User4",
//						"Face.FA1.User5" }) {
//					for (var tmp3 : new String[] { "Write", "Read" }) {
//						for (var tmp4 : new String[] { "BasicContext", "PawnshopContext", "SaleContext" }) {
//							var userFaceDto = User.getCurr(tmp1, Face.currFA.code, tmp2);
//							WB.addLog2("Access.test.getCurr(4String):boolean, res="
//									+ Access.getCurr(tmp1, tmp2, tmp3, tmp4) + ", date1=" + tmp1 + ", userId=" + tmp2
//									+ ", user.id=" + userFaceDto.id + ", credential="
//									+ Access.getCredential(userFaceDto, tmp3, tmp4), "", "Access");
//						}
//					}
//				}
//			}

//			WB.addLog2("Access.test.get(3String):boolean", "", "Access");
//			for (var tmp1 : new String[] { "Face.FA1.User1", "Face.FA1.User2", "Face.FA1.User3", "Face.FA1.User4" }) {
//				for (var tmp2 : new String[] { "Write", "Read" }) {
//					for (var tmp3 : new String[] { "", "BasicContext", "PawnshopContext", "SaleContext" }) {
//						var userFaceDto = User.get(Face.currFA.code, tmp2);
//						WB.addLog2("Access.test.get(3String):boolean, res=" + Access.get(tmp1, tmp2, tmp3) + ", userId="
//								+ tmp1 + ", user.id=" + userFaceDto.id + ", actionId=" + tmp2 + ", context=" + tmp3, "",
//								"Access");
//					}
//				}
//			}

//			WB.addLog2("Access.test.ctor(2String)", "", "Access");
//			for (var tmp1 : new String[] { "FullAccess , NoRestriction", "OnlyRead , OnlyRead", "FullAccess",
//					"OnlyRead" }) {
//				var tmp2 = new TwoVal(tmp1);
//				WB.addLog2("Access.test.ctor(2String)=" + new Access(tmp2.val1, tmp2.val2), "", "Access");
//			}

//			WB.addLog2("Access.test.ctor(String)", "", "Access");
//			for (var tmp1 : new String[] { "FullAccess , NoRestriction", "OnlyRead , OnlyRead", "FullAccess",
//					"OnlyRead" }) {
//				WB.addLog2("Access.test.ctor(String)=" + new Access(tmp1), "", "Access");
//			}

		} catch (Exception ex) {
			WB.addLog("Access.test():void, ex=" + ex.getMessage(), "", "Access");
		}
	}
}