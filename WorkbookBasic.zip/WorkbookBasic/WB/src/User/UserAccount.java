import java.util.ArrayList;
import java.util.List;

public final class UserAccount {
	// origin - 11.12.2025, last edit - 15.12.2025
	// common fields
	public String src, id, context, defect;
	// special fields
	public Access access;
	public String grant, userId, staffTableId, password, pointId, fullName, comment;
	public static UserAccount curr;

	static {
		try {
			UserAccount.curr = UserAccount.getByParentAndFaceCode("Face.FA1", "Face.FA1.User1");
			// WB.addLog2("UserAccount.currUser=" + UserAccount.curr, "", "User");
		} catch (Exception ex) {
			WB.addLog("UserAccount.static ctor, ex=" + ex.getMessage(), "", "UserAccount");
		}
	}

	public static UserAccount getByUserId(String userId) throws Exception {
		// origin - 15.12.2025, last edit - 15.12.2025
		UserAccount res = new UserAccount();
		try {
			var userAccount = UserAccount.get();
			for (var curr : userAccount) {
				if (Etc.strEquals(curr.userId, userId)) {
					res = curr;
				}
			}
		} catch (Exception ex) {
			WB.addLog("UserAccount.getByUserId(String):UserAccount, ex=" + ex.getMessage(), "", "UserAccount");
		}
		return res;
	}

	public static UserAccount getById(String faceId) throws Exception {
		// origin - 15.12.2025, last edit - 15.12.2025
		UserAccount res = new UserAccount();
		try {
			var faceDto = new FaceDto(faceId);
			res = new UserAccount(faceDto.userAccount, "");
		} catch (Exception ex) {
			WB.addLog("UserAccount.getById(String):UserAccount, ex=" + ex.getMessage(), "", "UserAccount");
		}
		return res;
	}

	// full list userAccount positions
	public static List<UserAccount> get() throws Exception {
		// origin - 15.12.2025, last edit - 15.12.2025
		List<UserAccount> res = new ArrayList<UserAccount>();
		try {
			var listModelDto = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter("Role.Face.User"), "Face");
			if (listModelDto.size() != 0) {
				for (var currFace : listModelDto) {
					if (currFace.id.isEmpty() == false) {
						var tmp1 = new FaceDto(currFace);
						var tmp2 = new UserAccount(tmp1.userAccount, "");
						res.add(tmp2);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("UserAccount.get():List<UserAccount>, ex=" + ex.getMessage(), "", "UserAccount");
		}
		return res;
	}

	public static List<UserAccount> getByParent(String parentId) throws Exception {
		// origin - 12.12.2025, last edit - 15.12.2025
		List<UserAccount> res = new ArrayList<UserAccount>();
		try {
			var listModelDto = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, "Role.Face.User"),
					"Face");
			if (listModelDto.size() != 0) {
				for (var currFace : listModelDto) {
					if (currFace.id.isEmpty() == false) {
						var tmp1 = new FaceDto(currFace);
						var tmp2 = new UserAccount(tmp1.userAccount, "");
						res.add(tmp2);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("UserAccount.get(String):List<UserAccount>, ex=" + ex.getMessage(), "", "UserAccount");
		}
		return res;
	}

	public static UserAccount getByParentAndFaceCode(String parentId, String faceUserId) throws Exception {
		// origin - 15.12.2025, last edit - 15.12.2025
		UserAccount res = new UserAccount();
		try {
			var listModelDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentCodeRoleFilter(parentId, faceUserId, "Role.Face.User"), "Face");
			if (listModelDto.size() != 0) {
				var currFaceDto = new FaceDto(listModelDto.getFirst());
				res = new UserAccount(currFaceDto.userAccount, "");
			}
		} catch (Exception ex) {
			WB.addLog("UserAccount.get(2String):UserAccount, ex=" + ex.getMessage(), "", "UserAccount");
		}
		return res;
	}

	// full list userAccount positions on date1
	public static List<UserAccount> getCurr(String date1, String parentId) throws Exception {
		// origin - 15.12.2025, last edit - 15.12.2025
		List<UserAccount> res = new ArrayList<UserAccount>();
		try {
			var listModelDto = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, "Role.Face.User"),
					"Face");
			var listFaceDto = FaceDto.get(listModelDto);
			if (listFaceDto.size() != 0) {
				var tmp1 = FaceDto.getChrono(DateTool.getLocalDate(date1), listFaceDto);
				if (tmp1.size() != 0) {
					for (var curr : tmp1) {
						var tmp2 = new UserAccount(curr.userAccount, "");
						res.add(tmp2);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("UserAccount.getCurr(2String):List<UserAccount>, ex=" + ex.getMessage(), "", "UserAccount");
		}
		return res;
	}

	// item userAccount position on date1
	public static UserAccount getCurr(String date1, String faceParentId, String faceUserId) throws Exception {
		// origin - 15.12.2025, last edit - 15.12.2025
		UserAccount res = new UserAccount();
		try {
			var listModelDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentCodeRoleFilter(faceParentId, faceUserId, "Role.Face.User"), "Face");
			var listFaceDto = FaceDto.get(listModelDto);
			if (listFaceDto.size() != 0) {
				var tmp = FaceDto.getChrono(DateTool.getLocalDate(date1), listFaceDto, "");
				res = new UserAccount(tmp.userAccount, "");
			}
		} catch (Exception ex) {
			WB.addLog("UserAccount.getCurr(3String):UserAccount, ex=" + ex.getMessage(), "", "UserAccount");
		}
		return res;
	}

	private void correct() throws Exception { // TODO
		// origin - 14.12.2025, last edit - 14.12.2025
		try {
			if (this.userId.isEmpty()) {
				this.userId = "1";
			}
			if (this.access.id.isEmpty()) {
				this.access = new Access("FullAccess");
			}
		} catch (Exception ex) {
			WB.addLog("UserAccount.correct():void, ex=" + ex.getMessage(), "", "UserAccount");
		}
	}

	private void validate() throws Exception {
		// origin - 11.12.2025, last edit - 15.12.2025
		try {
			if (this.userId.isEmpty()) {
				this.defect = this.defect + "empty userId; ";
			}
			if (this.access.id.isEmpty()) {
				this.defect = this.defect + "empty access; ";
			}
		} catch (Exception ex) {
			WB.addLog("UserAccount.validate():void, ex=" + ex.getMessage(), "", "UserAccount");
		}
	}

	private void clear() throws Exception {
		// origin - 11.12.2025, last edit - 14.12.2025
		try {
			this.src = this.id = this.context = this.defect = this.password = this.fullName = this.comment = "";
			this.userId = this.staffTableId = this.pointId = this.grant = "";
			this.access = new Access();
		} catch (Exception ex) {
			WB.addLog("UserAccount.clear():void, ex=" + ex.getMessage(), "", "UserAccount");
		}
	}

	public UserAccount(String Src, String Grant) throws Exception {
		// origin - 11.12.2025, last edit - 15.12.2025
		this.clear();
		this.src = this.id = Etc.fixTrim(Src);
		if (this.src.isEmpty() == false) {
			var tmp1 = new FourVal(Src);
			this.userId = Etc.fixTrim(tmp1.val1);
			this.access = new Access(tmp1.val2);
			this.staffTableId = Etc.fixTrim(tmp1.val3);
			if (this.staffTableId.isEmpty() == false) {
				var tmp2 = new StaffTable(Face.currFA.id, this.staffTableId);
				this.pointId = tmp2.pointId;
			}
			this.password = Etc.fixTrim(tmp1.val4);
			this.grant = Etc.fixTrim(Grant);
		}
		this.correct();
		this.validate();
	}

	public UserAccount() throws Exception {
		// origin - 11.12.2025, last edit - 11.12.2025
		this.clear();
	}

	public String toString() {
		// origin - 11.12.2025, last edit - 14.12.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway(", src ", this.src);
			// res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", userId ", this.userId);
			res = res + Fmtr.addIfNotEmpty(", access ", this.access.id);
			res = res + Fmtr.addIfNotEmpty(", staffTableId ", this.staffTableId);
			res = res + Fmtr.addIfNotEmpty(", password ", this.password);
			res = res + Fmtr.addIfNotEmpty(", pointId ", this.pointId);
			res = res + Fmtr.addIfNotEmpty(", grant ", this.grant);
			res = res + Fmtr.addIfNotEmpty(", context ", this.context);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 11.12.2025, last edit - 15.12.2025
		try {

//			WB.addLog2("UserAccount.test.getByUserId(String):UserAccount", "", "UserAccount");
//			for (var tmp1 : new String[] { "1", "2", "3", "4", "5" }) {
//				WB.addLog2("UserAccount.test.getById(String):UserAccount, res=" + UserAccount.getByUserId(tmp1)
//						+ ", userId=" + tmp1, "", "UserAccount");
//			}

//			WB.addLog2("UserAccount.test.getById(String):UserAccount", "", "UserAccount");
//			for (var tmp1 : new String[] { "Face.FA1.User1", "Face.FA1", "Face.Enterprise.Template",
//					"Face.Person.Template", "Face.Tralala" }) {
//				WB.addLog2("UserAccount.test.getById(String):UserAccount, res=" + UserAccount.getById(tmp1)
//						+ ", faceId=" + tmp1, "", "UserAccount");
//			}

//			WB.addLog2("UserAccount.test.get():List<UserAccount>", "", "UserAccount");
//			var tmp = UserAccount.get();
//			WB.addLog2("UserAccount.test.get():List<UserAccount>, res.size=" + tmp.size(), "", "UserAccount");
//			WB.log(tmp, "UserAccount");

//			WB.addLog2("UserAccount.test.getByParent(String):List<UserAccount>", "", "UserAccount");
//			for (var tmp1 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
//				var tmp2 = UserAccount.getByParent(tmp1);
//				WB.addLog2("UserAccount.test.getByParent(String):List<UserAccount>, res.size=" + tmp2.size()
//						+ ", parentId=" + tmp1, "", "UserAccount");
//				WB.log(tmp2, "UserAccount");
//			}

//			WB.addLog2("UserAccount.test.getByParentAndFaceCode(2String):UserAccount", "", "UserAccount");
//			for (var tmp1 : new String[] { "Face.FA1 , Face.FA1.User1", "Face.FA1 , Face.FA1.User2",
//					"Face.kgd, Face.kgd.User1", "Face.Tralala , Face.Tralala.User1" }) {
//				var tmp2 = new TwoVal(tmp1);
//				WB.addLog2("UserAccount.test.getByParentAndFaceCode(2String):UserAccount, res="
//						+ UserAccount.getByParentAndFaceCode(tmp2.val1, tmp2.val2) + ", faceParentId=" + tmp2.val1
//						+ ", faceUserId=" + tmp2.val2, "", "UserAccount");
//			}

//			WB.addLog2("UserAccount.test.getCurr(2String):List<UserAccount>", "", "UserAccount");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-31", "2025-02-20", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
//					var tmp3 = UserAccount.getCurr(tmp1, tmp2);
//					WB.addLog2("UserAccount.test.getCurr(2String):List<UserAccount>, res.size=" + tmp3.size()
//							+ ", date1=" + tmp1 + ", parentId=" + tmp2, "", "UserAccount");
//					WB.log(tmp3, "UserAccount");
//				}
//			}

//			WB.addLog2("UserAccount.test.getCurr(3String):UserAccount", "", "UserAccount");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-31", "2025-02-20", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1 , Face.FA1.User1", "Face.FA1 , Face.FA1.User2",
//						"Face.kgd, Face.kgd.User1", "Face.Tralala , Face.Tralala.User1" }) {
//					var tmp3 = new TwoVal(tmp2);
//					var tmp4 = UserAccount.getCurr(tmp1, tmp3.val1, tmp3.val2);
//					WB.addLog2("UserAccount.test.getCurr(3String):UserAccount, res=" + tmp4 + ", date1=" + tmp1
//							+ ", faceParentId=" + tmp3.val1 + ", faceUserId=" + tmp3.val2, "", "UserAccount");
//				}
//			}

//			WB.addLog2("UserAccount.test.ctor(String)", "", "UserAccount");
//			for (var tmp : new String[] { "", "1", "1 , FullAccess", "1 , FullAccess , Face.FA1.StaffTable1.Boss",
//					"1 , FullAccess , Face.FA1.StaffTable1.Boss , 12345678" }) {
//				WB.addLog2("UserAccount.test.ctor(String), res=" + new UserAccount(tmp, ""), "", "UserAccount");
//			}

		} catch (Exception ex) {
			WB.addLog("UserAccount.test():void, ex=" + ex.getMessage(), "", "UserAccount");
		}
	}
}