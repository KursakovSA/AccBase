public final class UserAccount {
	// origin - 11.12.2025, last edit - 12.12.2025
	// common fields
	public String src, id, context, defect;
	// special fields
	public Access access;
	public String userId, staffTableId, pointId, password, grant, fullName, comment;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("UserAccount.static ctor, ex=" + ex.getMessage(), "", "UserAccount");
		}
	}

	public static UserAccount getById(String faceId) throws Exception {
		// origin - 11.12.2025, last edit - 11.12.2025
		UserAccount res = new UserAccount();
		try {
			var faceDto = new FaceDto(faceId);
			res = new UserAccount(faceDto.userAccount);
		} catch (Exception ex) {
			WB.addLog("UserAccount.getById(String):UserAccount, ex=" + ex.getMessage(), "", "UserAccount");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 11.12.2025, last edit - 11.12.2025
		try {
//			if (this.IBAN.length() < 3) {
//				this.defect = this.defect + "empty BIC; ";
//			}
//			if (this.bankId.defect.isEmpty() == false) {
//				this.defect = this.defect + "defect bankId; ";
//			}
		} catch (Exception ex) {
			WB.addLog("UserAccount.validate():void, ex=" + ex.getMessage(), "", "UserAccount");
		}
	}

	private void clear() throws Exception {
		// origin - 11.12.2025, last edit - 12.12.2025
		try {
			this.src = this.id = this.context = this.defect = this.grant = this.password = this.fullName = this.comment = "";
			this.userId = this.staffTableId = this.pointId = "";
			this.access = new Access();
		} catch (Exception ex) {
			WB.addLog("UserAccount.clear():void, ex=" + ex.getMessage(), "", "UserAccount");
		}
	}

	public UserAccount(String Src, String Grant) throws Exception { //TODO
		// origin - 11.12.2025, last edit - 11.12.2025
		this.clear();
		this.src = this.id = Src;
		if (this.src.isEmpty() == false) {
//			var tmp = new ThreeVal(Src);
//			this.IBAN = Etc.fixTrim(tmp.val1);
//			this.bankId = new BankId(tmp.val2, tmp.val3);
			this.grant = Grant;
			this.validate();
		}
	}
	
	public UserAccount(FaceDto faceDto) throws Exception { //TODO
		// origin - 12.12.2025, last edit - 12.12.2025
		this.clear();
		//this.src = this.id = Src;
		if (this.src.isEmpty() == false) {
//			var tmp = new ThreeVal(Src);
//			this.IBAN = Etc.fixTrim(tmp.val1);
//			this.bankId = new BankId(tmp.val2, tmp.val3);
			this.validate();
		}
	}

	public UserAccount(String Src) throws Exception { //TODO
		// origin - 11.12.2025, last edit - 11.12.2025
		this.clear();
		this.src = this.id = Src;
		if (this.src.isEmpty() == false) {
//			var tmp = new ThreeVal(Src);
//			this.IBAN = Etc.fixTrim(tmp.val1);
//			this.bankId = new BankId(tmp.val2, tmp.val3);
			this.validate();
		}
	}

	public UserAccount() throws Exception {
		// origin - 11.12.2025, last edit - 11.12.2025
		this.clear();
	}

	public String toString() {
		// origin - 11.12.2025, last edit - 12.12.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway(", access ", this.access.id);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", userId ", this.userId);
			res = res + Fmtr.addIfNotEmpty(", staffTableId ", this.staffTableId);
			res = res + Fmtr.addIfNotEmpty(", pointId ", this.pointId);
			res = res + Fmtr.addIfNotEmpty(", context ", this.context);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 11.12.2025, last edit - 11.12.2025
		try {

//			WB.addLog2("UserAccount.test.getById(String):UserAccount", "", "UserAccount");
//			for (var tmp1 : new String[] { "Face.FA1", "Face.Enterprise.Template", "Face.Person.Template",
//					"Face.Tralala" }) {
//				WB.addLog2("UserAccount.test.getById(String):UserAccount, res=" + BankInfo.getById(tmp1) + ", faceId=" + tmp1,
//						"", "UserAccount");
//			}

		} catch (Exception ex) {
			WB.addLog("UserAccount.test():void, ex=" + ex.getMessage(), "", "UserAccount");
		}
	}
}