import java.time.LocalDateTime;
import java.util.List;

@SuppressWarnings("unused")
public class RangeVal extends ModelVal {
	// origin - 01.11.2024, last edit - 09.11.2024
	// ex. "120.0 - 140.0", "66781 - 66783", "2024-11-04T09:00:00 -
	// 2024-11-04T20:00:00", etc.

	public String partVal1 = WB.strEmpty;
	public String partVal2 = WB.strEmpty;
	public static final String strSplit = WB.strSpace + WB.strDash + WB.strSpace; // split = " - "
	private static final List<String> listDelStr = List.of(RangeVal.strSplit, WB.strDash + WB.strSpace);

	public Object val1 = null;
	public Object val2 = null;
	private static String expectedVal = WB.strEmpty; // TOTHINK

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("RangeVal.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "RangeVal");
		} finally {
			Etc.doNothing();
		}
	}

	private void getVal() throws Exception {
		// origin - 08.11.2024, last edit - 09.11.2024
		try {
			this.id = this.partVal1 + WB.strComma + WB.strSpace + this.partVal2;
			this.val1 = Conv.get(this.partVal1);
			this.val2 = Conv.get(this.partVal2);
			// WB.addLog2("RangeVal.getVal, this.val1=" + this.val1 + ", this.val2=" +
			// this.val2, WB.strEmpty, "RangeVal");
		} catch (Exception ex) {
			WB.addLog("RangeVal.getVal, ex=" + ex.getMessage(), WB.strEmpty, "RangeVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("RangeVal.getUnitVal, this.unit=" + this.unit, WB.strEmpty,
		// "RangeVal");
	}

	private void getPart() throws Exception {
		// origin - 01.11.2024, last edit - 09.11.2024
		try {
			if (this.isRangeVal()) {
				int posLocalSplit = this.src.indexOf(RangeVal.strSplit); // pos " - "
//				WB.addLog2("RangeVal.posLocalSplit=" + posLocalSplit + ", this.src=" + this.src, WB.strEmpty,
//						"RangeVal");
				if (posLocalSplit > 0) {
					// this is res
					this.partVal1 = Etc.fixTrim(this.src.substring(0, posLocalSplit));
					this.partVal1 = Etc.delStr(this.partVal1, RangeVal.listDelStr);
					
					this.partVal2 = Etc.fixTrim(this.src.substring(posLocalSplit));
					this.partVal2 = Etc.delStr(this.partVal2, RangeVal.listDelStr);
				}
			}
		} catch (Exception ex) {
			WB.addLog("RangeVal.getPart, ex=" + ex.getMessage(), WB.strEmpty, "RangeVal");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("RangeVal.getPart, this.partVal1=" + this.partVal1 + ", this.partVal2=" + this.partVal2
//				+ ", this.src=" + this.src, WB.strEmpty, "RangeVal");
	}

	public RangeVal(String Src) throws Exception {
		// origin - 01.11.2024, last edit - 08.11.2024
		this();
		this.src = Etc.fixTrim(Src);
		this.getPart();
		this.getVal();
	}

	public RangeVal() throws Exception {
		// origin - 01.11.2024, last edit - 08.11.2024
		super();
	}

	public static void test() throws Exception {
		// origin - 01.11.2024, last edit - 09.11.2024
		try {

//			// ctor
//			var arg1 = new String[] { "120.0 - 140.0", "66206781 - 66206783",
//					"2024-11-04T09:00:00 - 2024-11-04T20:00:00" };
//			for (var testArg1 : arg1) {
//				RangeVal rangeVal1 = new RangeVal(testArg1);
//				WB.addLog2("RangeVal.test.ctor, rangeVal1.id=" + rangeVal1.id + ", testArg1=" + testArg1, WB.strEmpty,
//						"RangeVal");
//			}

		} catch (Exception ex) {
			WB.addLog("RangeVal.test, ex=" + ex.getMessage(), WB.strEmpty, "RangeVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("RangeVal.test end ", WB.strEmpty, "RangeVal");
	}
}