import java.util.List;

public class RangeVal extends ModelVal {
	// origin - 01.11.2024, last edit - 24.11.2024
	// ex. "Price = 120.0 - 140.0 (Unit.KZT)", "66781 - 66783",
	// "2024-11-04T09:00:00 - 2024-11-04T20:00:00", etc.

	private String partVal1, partVal2;
	private static List<String> listDelStr;
	public Object val1, val2;

	static {
		try {
			RangeVal.listDelStr = List.of(WB.strEquals, WB.strSplit, WB.strDash + WB.strSpace, WB.strSpace + WB.strDash,
					WB.strParenthesisLeft, WB.strParenthesisRight);
		} catch (Exception ex) {
			WB.addLog("RangeVal.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "RangeVal");
		} finally {
			Etc.doNothing();
		}
	}

	private void getId() throws Exception {
		// origin - 05.01.2025, last edit - 06.01.2025
		try {
			this.id = this.name + WB.strSpace + this.val1 + WB.strDash + WB.strDash + this.val2;
			if (this.partUnit.isEmpty() == false) {
				this.id = this.id + WB.strSpace + this.unit.code + WB.strCommaSpace + this.unit.description;
			}
			if (this.partVal1.isEmpty() & this.partVal2.isEmpty()) {
				this.id = WB.strEmpty;
			}
		} catch (Exception ex) {
			WB.addLog("RangeVal.getId, ex=" + ex.getMessage(), WB.strEmpty, "RangeVal");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("RangeVal.getId, this.id=" + this.id, this.src=" + this.src, WB.strEmpty, "RangeVal");
	}

	private void getVal() throws Exception {
		// origin - 08.11.2024, last edit - 06.01.2025
		try {
			this.name = this.partName;
			this.getUnit();
			if (this.unit != null) {
				this.val1 = Conv.get(this.partVal1, this.unit.expectedValue);
				this.val2 = Conv.get(this.partVal2, this.unit.expectedValue);
			} else {
				this.val1 = Conv.get(this.partVal1, WB.strEmpty);
				this.val2 = Conv.get(this.partVal2, WB.strEmpty);
			}
		} catch (Exception ex) {
			WB.addLog("RangeVal.getVal, ex=" + ex.getMessage(), WB.strEmpty, "RangeVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("RangeVal.getVal, this.unit=" + this.unit, WB.strEmpty,
		// "RangeVal");
	}

	private void getPart() throws Exception {
		// origin - 01.11.2024, last edit - 04.01.2025
		try {
			// WB.addLog2("RangeVal.getPart, isType(this.src)=" + ModelVal.isType(this.src),
			// WB.strEmpty, "RangeVal");
			if (ModelVal.isType(this.src) == "RangeVal") {
				String tmp = this.src;

				// get partUnit
				int posLocalStrMiddleParenthesisLeft = 0;
				posLocalStrMiddleParenthesisLeft = tmp.indexOf(ModelVal.strStartUnit); // pos "(Unit."
				if (posLocalStrMiddleParenthesisLeft > 0) {
					int posLocalStrMiddleParenthesisRight = 0;
					posLocalStrMiddleParenthesisRight = tmp.indexOf(WB.strParenthesisRight); // pos ")"
					if (posLocalStrMiddleParenthesisRight > 0) {
						this.partUnit = Etc.fixTrim(
								tmp.substring(posLocalStrMiddleParenthesisLeft, posLocalStrMiddleParenthesisRight));
						this.partUnit = Etc.delStr(this.partUnit, RangeVal.listDelStr);
						tmp = Etc.delStr(tmp, this.partUnit);
						tmp = Etc.delStr(tmp, WB.strParenthesisLeft);
						tmp = Etc.delStr(tmp, WB.strParenthesisRight);
					}
				}

				// get partName
				int posLocalStrMiddleEquation = 0;
				posLocalStrMiddleEquation = tmp.indexOf(WB.strEquals); // pos "="
				if (posLocalStrMiddleEquation > 0) {
					this.partName = Etc.fixTrim(tmp.substring(0, posLocalStrMiddleEquation));
					this.partName = Etc.delStr(this.partName, RangeVal.listDelStr);
					// tmp = tmp.substring(posLocalStrMiddleEquation);
					tmp = Etc.delStr(tmp, this.partName);
					tmp = Etc.delStr(tmp, WB.strEquals);
				}

				// get partVal1,2
				int posLocalSplit = tmp.indexOf(WB.strSplit); // pos " - "
				if (posLocalSplit > 0) {
					// this is res
					this.partVal1 = Etc.fixTrim(tmp.substring(0, posLocalSplit));
					this.partVal1 = Etc.delStr(this.partVal1, RangeVal.listDelStr);

					this.partVal2 = Etc.fixTrim(tmp.substring(posLocalSplit));
					this.partVal2 = Etc.delStr(this.partVal2, RangeVal.listDelStr);
//					WB.addLog2("RangeVal.getPart, this.partVal2=" + this.partVal2 + ", this.src=" + this.src,
//							WB.strEmpty, "RangeVal");
				}
			}
		} catch (Exception ex) {
			WB.addLog("RangeVal.getPart, ex=" + ex.getMessage(), WB.strEmpty, "RangeVal");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("RangeVal.getPart, this.partVal1=" + this.partVal1 + ", this.partVal2=" + this.partVal2
//				+ ", this.partName=" + this.partName + ", this.src=" + this.src, WB.strEmpty, "RangeVal");
	}

	public RangeVal(String Src) throws Exception {
		// origin - 01.11.2024, last edit - 05.01.2025
		this();
		this.src = Etc.fixTrim(Src);
		this.getPart();
		this.getVal();
		this.getId();
	}

	public RangeVal() throws Exception {
		// origin - 01.11.2024, last edit - 31.12.2024
		super();
		this.id = this.partVal1 = this.partVal2 = this.partUnit = WB.strEmpty;
	}

	public String toString() {
		// origin - 05.01.2025, last edit - 09.01.2025
		String res = WB.strEmpty;
		try {
			res = this.id + WB.strSpace + ", src " + this.src + ", context " + this.context;
		} catch (Exception ex) {
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 01.11.2024, last edit - 09.01.2025
		try {

//			// ctor
//			for (var tmp : new String[] { "Price = 20.0 - 40.0 (Unit.KZT)", "120.0 - 140.0 (Unit.tralala)",
//					"66206781 - 66206783", "2024-11-04T09:00:00 - 2024-11-04T20:00:00", "2024-11-04T09:00:00 - ?",
//					"2024-11-04 - ?", "TotalPenaltyAccrualLimit=0.0 - 0.1(Unit.MainDebt)" }) {
//				// for (var testArg1 : new String[] { "TotalPenaltyAccrualLimit=0.0 -
//				// 0.1(Unit.MainDebt)" }) {
//				WB.addLog2("RangeVal.test.ctor, tmp=" + new RangeVal(tmp), WB.strEmpty, "RangeVal");
//			}

		} catch (Exception ex) {
			WB.addLog("RangeVal.test, ex=" + ex.getMessage(), WB.strEmpty, "RangeVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("RangeVal.test end ", WB.strEmpty, "RangeVal");
	}
}