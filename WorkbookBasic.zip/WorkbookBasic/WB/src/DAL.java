import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

public class DAL {
	// origin - 23.10.2023, last edit - 06.03.2025

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("DAL.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "DAL");
		}
	}

//	public static List<ModelDto> removeDuplicate2(List<ModelDto> dtoBase, List<ModelDto> dtoAdd) throws Exception {
//	// origin - 12.06.2024, last edit - 06.03.2025
//	//LocalDateTime localStart = WB.getLocalStart();
//	List<ModelDto> res = new ArrayList<ModelDto>();
//	String strCurrDtoRes = WB.strEmpty;
//	String strCurrDtoAdd = WB.strEmpty;
//	boolean hasEqualsBaseAdd = false;
//	try {
//
//		if (dtoBase.isEmpty()) {
//			res.addAll(dtoAdd);
//
//		} else {
//			for (var currDtoAdd : dtoAdd) {
//				strCurrDtoAdd = currDtoAdd.toString();// strCurrDtoAdd = currDtoAdd.id;
//				for (var currDtoBase : dtoBase) {
//					strCurrDtoRes = currDtoBase.toString();// strCurrDtoRes = currDtoBase.id;
//					hasEqualsBaseAdd = false;
//					if (strCurrDtoRes.equals(strCurrDtoAdd)) {
//						hasEqualsBaseAdd = true;
//						break;
//					}
//				}
//				if (hasEqualsBaseAdd == false) {
//					res.add(new ModelDto(currDtoAdd));
//				}
//			}
//		}
//
//	} catch (Exception ex) {
//		WB.addLog("ModelDto.removeDuplicate2, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
//	}
////	WB.getLocalEnd("ModelDto.removeDuplicate2 for List<ModelDto> dtoBase.size=" + dtoBase.size()
////			+ ", dtoAdd.size=" + dtoAdd.size(), localStart);
////	WB.addLog2("ModelDto.removeDuplicate2, res.size=" + res.size() + ", dtoBase.size=" + dtoBase.size()
////			+ ", dtoAdd.size=" + dtoAdd.size(), WB.strEmpty, "ModelDto");
//	return res;
//}

	public static List<ModelDto> removeDuplicate(List<ModelDto> dtoCollector, List<ModelDto> dtoAdd) throws Exception {
		// origin - 03.06.2024, last edit - 06.03.2025
		LocalDateTime localStart = WB.getLocalStart();
		List<ModelDto> res = new ArrayList<ModelDto>();
		WB.addLog2("DAL.removeDuplicate, before work, res.size=" + res.size() + ", dtoCollector.size="
				+ dtoCollector.size() + ", dtoAdd.size=" + dtoAdd.size(), WB.strEmpty, "DAL");
		String strCurrDtoRes = WB.strEmpty;
		String strCurrDtoAdd = WB.strEmpty;
		boolean hasEqualsCollectorAdd = false;
		try {

			if (dtoCollector.isEmpty()) {
				res.addAll(dtoAdd);

			} else {
				for (var currDtoAdd : dtoAdd) {
					strCurrDtoAdd = currDtoAdd.toString();// strCurrDtoAdd = currDtoAdd.id;
					for (var currDtoRes : dtoCollector) {
						strCurrDtoRes = currDtoRes.toString();// strCurrDtoRes = currDtoRes.id;
						hasEqualsCollectorAdd = false;
						if (strCurrDtoRes.equals(strCurrDtoAdd)) {
							hasEqualsCollectorAdd = true;
							break;
						}
					}
					if (hasEqualsCollectorAdd == false) {
						res.add(new ModelDto(currDtoAdd));
					}
				}
			}
			res.addAll(dtoCollector);

		} catch (Exception ex) {
			WB.addLog("DAL.removeDuplicate, ex=" + ex.getMessage(), WB.strEmpty, "DAL");
		}
		WB.getLocalEnd("DAL.removeDuplicate for List<ModelDto> dtoCollector.size=" + dtoCollector.size()
				+ ", dtoAdd.size=" + dtoAdd.size(), localStart);
		WB.addLog2("DAL.removeDuplicate, after work, res.size=" + res.size() + ", dtoCollector.size="
				+ dtoCollector.size() + ", dtoAdd.size=" + dtoAdd.size(), WB.strEmpty, "DAL");
		return res;
	}

	public static void getReplaceInto(TreeSet<String> setConn, List<ModelDto> set) throws Exception {
		// origin - 09.02.2024, last edit - 06.03.2025
		try {
			for (var currConn : setConn) {
				DAL.setReplaceInto(currConn, set);
			}
		} catch (Exception ex) {
			WB.addLog("DAL.getReplaceInto, ex=" + ex.getMessage(), WB.strEmpty, "DAL");
		}
	}

	@SuppressWarnings("unused")
	private static void setReplaceInto(String currConn, List<ModelDto> set) throws Exception {
		// origin - 02.02.2024, last edit - 06.03.2025
		LocalDateTime localStart = WB.getLocalStart();
		try {
			currConn = Conn.getText(currConn);
			WB.lastConn = currConn;
			Connection conn = DriverManager.getConnection(currConn);
			conn.setAutoCommit(false);

			PreparedStatement qry = null;

//			//// check dublicate in currConn and remove duplicate in input set
//			WB.addLog2("DAL.setReplaceInto, currConn=" + currConn + ", before remove duplicate2 set.size=" + set.size(),
//					WB.strEmpty, "DAL");
//			List<ModelDto> currConnSet = new ArrayList<ModelDto>();
//			currConnSet = DAL.getByTemplate(currConn, WB.strEmpty);
//			set = ModelDto.removeDuplicate2(currConnSet, set);
//			WB.addLog2("DAL.setReplaceInto, currConn=" + currConn + ", after remove duplicate2 set.size=" + set.size(),
//					WB.strEmpty, "DAL");

			for (var currDto : set) {
				// PreparedStatement qry = conn.prepareStatement(Qry.getReplaceInto(currDto));
				qry = conn.prepareStatement(Qry.getReplaceInto(currDto));
				qry.executeUpdate();
				qry.close();
			}
			qry = null;
			conn.commit();
			conn.setAutoCommit(true);
			conn.close();
			conn = null;
		} catch (Exception ex) {
			WB.addLog("DAL.setReplaceInto, ex=" + ex.getMessage() + ", currConn=" + currConn, WB.strEmpty, "DAL");
		}

//		 WB.getLocalEnd("DAL.setReplaceInto for List<ModelDto> set.size=" + set.size()
//		 + ", currConn=" + currConn, localStart);
//		 WB.addLog2("DAL.setReplaceInto, currConn=" + currConn + ", set.size=" +
//		 set.size(), WB.strEmpty, "DAL");
	}

	public static void getVacuum(TreeSet<String> setConn) throws Exception {
		// origin - 19.12.2023, last edit - 06.03.2025
		for (var currConn : setConn) {
			currConn = Conn.getText(currConn);
			try {
				Connection conn = DriverManager.getConnection(currConn);
				WB.lastConn = currConn;
				java.sql.Statement qry = conn.createStatement();
				qry.execute(Qry.vacuumCmdSQLite);// getVacuum(currConn));
				conn.close();
			} catch (Exception ex) {
				WB.addLog("DAL.getVacuum, ex=" + ex.getMessage(), WB.strEmpty, "DAL");
			}
		}
	}

	public static void getReindex(TreeSet<String> setConn) throws Exception {
		// origin - 19.12.2023, last edit - 06.03.2025
		for (var currConn : setConn) {
			currConn = Conn.getText(currConn);
			try {
				Connection conn = DriverManager.getConnection(currConn);
				WB.lastConn = currConn;
				java.sql.Statement qry = conn.createStatement();
				qry.execute(Qry.reindexCmdSQLite);// getReindex(currConn));
				conn.close();
			} catch (Exception ex) {
				WB.addLog("DAL.getReindex, ex=" + ex.getMessage(), WB.strEmpty, "DAL");
			}
		}
	}

	public static void getIntegrityCheck(TreeSet<String> setConn) throws Exception {
		// origin - 19.12.2023, last edit - 06.03.2025
		for (var currConn : setConn) {
			currConn = Conn.getText(currConn);
			try {
				Connection conn = DriverManager.getConnection(currConn);
				WB.lastConn = currConn;
				java.sql.Statement qry = conn.createStatement();
				qry.execute(Qry.integrityCheckCmdSQLite);// getIntegrityCheck(currConn));

				qry.close();
				qry = null;
				conn.close();
				conn = null;
			} catch (Exception ex) {
				WB.addLog("DAL.getIntegrityCheck, ex=" + ex.getMessage(), WB.strEmpty, "DAL");
			}
		}
	}

	public static void getOutputBackup(TreeSet<String> setConn) throws Exception {
		// origin - 28.05.2024, last edit - 06.03.2025
		for (var currConn : setConn) {
			currConn = Conn.getText(currConn);
			// WB.addLog2("DAL.getOutputBackup, currConn=" + currConn, WB.strEmpty, "DAL");
			try {
				Connection conn = DriverManager.getConnection(currConn);
				// WB.addLog2("DAL.getOutputBackup, Conn=" + conn.toString(), WB.strEmpty,
				// "DAL");
				WB.lastConn = currConn;
				java.sql.Statement qry = conn.createStatement();

				// String tmp = Qry.getOutputBackup(currConn);
				// WB.addLog2("DAL.getOutputBackup, Qry.getOutputBackup(currConn)=" + tmp,
				// WB.strEmpty,
				// "DAL");
				qry.execute(Qry.getOutputBackup(currConn));

				qry.close();
				qry = null;
				conn.close();
				conn = null;
			} catch (Exception ex) {
				WB.addLog("DAL.getOutputBackup, ex=" + ex.getMessage(), WB.strEmpty, "DAL");
			}
		}
	}

	public static void getBackup(TreeSet<String> setConn) throws Exception {
		// origin - 18.12.2023, last edit - 06.03.2025
		for (var currConn : setConn) {
			currConn = Conn.getText(currConn);
			try {
				Connection conn = DriverManager.getConnection(currConn);
				WB.lastConn = currConn;
				java.sql.Statement qry = conn.createStatement();
				qry.execute(Qry.getBackup(currConn));

				qry.close();
				qry = null;
				conn.close();
				conn = null;
			} catch (Exception ex) {
				WB.addLog("DAL.getBackup, ex=" + ex.getMessage(), WB.strEmpty, "DAL");
			}
		}
	}

	public static List<ModelDto> setByTemplate(TreeSet<String> setConn, String templateMore) throws Exception {
		// TOTHINK - add other template - asset, face, etc.
		// origin - 30.05.2024, last edit - 06.03.2025
		// get common ModelDto what consist all tables all conn from multiply conn
		List<ModelDto> res = new ArrayList<ModelDto>();
		List<ModelDto> tmp = new ArrayList<ModelDto>();
		// boolean resRemoveAll = false;
		try {
			for (var currConn : setConn) {
				if (DAL.existFile(currConn) == false) {
					WB.addLog("DAL.setByTemplate(), not exist=" + currConn, WB.strEmpty, "DAL");
					return res;
				}

				tmp.clear();
				tmp = DAL.getByTemplate(currConn, templateMore);
				if (tmp.isEmpty() == false) {
					res.addAll(tmp); // res = ModelDto.removeDuplicate(res, tmp);
					tmp.clear();
				}
			}
		} catch (Exception ex) {
			WB.addLog("DAL.setByTemplate, ex=" + ex.getMessage(), WB.strEmpty, "DAL");
		}
		return res;
	}

	private static boolean isSkip(String currConn, String templateMore, String currTable) throws Exception {
		// origin - 18.06.2024, last edit - 06.03.2025
		// this method skip very big table Workbook in that bases where its not need for
		// read metadata
		Boolean res = false;
		try {
			if (Etc.strContains(currTable, "Workbook")) {
				if (Etc.strContains(templateMore, "AbcBasic")) {
					res = true;
				}
				if (Etc.strContains(currConn, Conn.globalDbPattern)) {// exception for "DatabaseGlobal"
					res = false;
				}
				if (Etc.strContains(currConn, Conn.templateDbPattern)) {// exception for "DatabaseTemplate"
					res = false;
				}
				if (Etc.strContains(currConn, Conn.localDbPattern)) {// exception for "DatabaseLocal"
					res = false;
				}
			}
		} catch (Exception ex) {
			WB.addLog("DAL.isSkip, ex=" + ex.getMessage(), WB.strEmpty, "DAL");
		}
		return res;
	}

	public static List<ModelDto> getByTemplate(String currConn, String templateMore, String table) throws Exception {
		// origin - 12.08.2024, last edit - 06.03.2025
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			if (DAL.existFile(currConn) == false) {
				WB.addLog("DAL.getByTemplate(), not exist=" + currConn, WB.strEmpty, "DAL");
				return res;
			}
			res = DAL.getTable(currConn, Qry.getText(currConn, table, templateMore));
		} catch (Exception ex) {
			WB.addLog("DAL.getByTemplate, ex=" + ex.getMessage(), WB.strEmpty, "DAL");
		}
		return res;
	}

	public static List<ModelDto> getByTemplate(String currConn, String templateMore) throws Exception {
		// origin - 13.11.2023, last edit - 06.03.2025
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			if (DAL.existFile(currConn) == false) {
				WB.addLog("DAL.getByTemplate(), not exist=" + currConn, WB.strEmpty, "DAL");
				return res;
			}

			List<ModelDto> tmp = new ArrayList<ModelDto>();
			List<String> tableList = DAL.getTableList(currConn);
			for (var currTable : tableList) {

				// skip table Workbook for abc, in Workbook no basic
				if (DAL.isSkip(currConn, templateMore, currTable)) {
//				WB.addLog2("DAL.getByTemplate, skip table=" + currTable + ", currConn=" + currConn + ", templateMore="
//						+ templateMore, WB.strEmpty, "DAL");
					continue;
				}

				tmp.clear();
				tmp = DAL.getTable(currConn, Qry.getText(currConn, currTable, templateMore));
				if (tmp.isEmpty() != true) {
					res.addAll(tmp);
					tmp.clear();
				}
			}
		} catch (Exception ex) {
			WB.addLog("DAL.getByTemplate, ex=" + ex.getMessage(), WB.strEmpty, "DAL");
		}
		return res;
	}

	public static List<String> getTableList(String currConn) throws Exception {
		// origin - 13.11.2023, last edit - 06.03.2025
		List<String> res = new ArrayList<String>();

		if (DAL.existFile(currConn) == false) {
			WB.addLog("DAL.getTableList, not exist=" + currConn, "getTableList()", "DAL");
			return res;
		}

		currConn = Conn.getText(currConn);
		try {
			Connection conn = DriverManager.getConnection(currConn);
			WB.lastConn = currConn;
			java.sql.Statement qry = conn.createStatement();
			ResultSet rs;
			rs = qry.executeQuery(Qry.getTableListSQLite);
			while (rs.next()) {
				res.add(rs.getString("name"));
			}
			rs.close();
			rs = null;
			qry.close();
			qry = null;
			conn.close();
			conn = null;

		} catch (Exception ex) {
			WB.addLog("DAL.getTableList, ex=" + ex.getMessage(), WB.strEmpty, "DAL");
		}
		return res;
	}

	public static List<ModelDto> getTable(String dbStr, String preparedQryText) throws Exception {
		// origin - 28.10.2023, last edit - 06.03.2025
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			String currConn = Conn.getText(dbStr);

			if (DAL.existFile(currConn) == false) {
				WB.addLog("DAL.getTable, not exist=" + dbStr, "currConn=" + currConn, "DAL");
				return res;
			}

			res = DAL.getModelDto(currConn, preparedQryText);
//		 WB.addLog2("DAL.getTable, Db=" + Etc.getFileName(dbStr) + ", qry=" + preparedQryText + ", cardinality=" + res.size(), WB.strEmpty, "DAL()");
		} catch (Exception ex) {
			WB.addLog("DAL.getTable, ex=" + ex.getMessage(), WB.strEmpty, "DAL");
		}
		return res;
	}

	private static List<ModelDto> getModelDto(String currConn, String preparedQryText) throws Exception {
		// origin - 31.10.2023, last edit - 06.03.2025
		List<ModelDto> res = new ArrayList<ModelDto>();

		if (DAL.existFile(currConn) == false) {
			WB.addLog("DAL.getModelDto, not exist=" + currConn, WB.strEmpty, "DAL");
			return res;
		}

		currConn = Conn.getText(currConn);
		try {
			Connection conn = DriverManager.getConnection(currConn);
			WB.lastConn = currConn;
			java.sql.Statement qry = conn.createStatement();

			ResultSet rs;
			// WB.addLog("getModelDto, preparedQryText=" + preparedQryText, "currConn=" +
			// currConn, "DAL()");
			rs = qry.executeQuery(preparedQryText);

			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			String nameDbColumn = WB.strEmpty;
			Class<ModelDto> ModelDtoClassObject = ModelDto.class;
			Field field = null;
			ModelDto currDto = new ModelDto();

			while (rs.next()) {
				currDto.clear();
				currDto.table = rsmd.getTableName(1);

				for (int i = 1; i <= columnCount; i++) {
					nameDbColumn = rsmd.getColumnName(i);
					// for each nameDbColumn example"Deal" match field ModelDto example "deal"
					field = ModelDtoClassObject.getField(DAL.getDtoFieldName(nameDbColumn));
					field.set(currDto, Etc.fixString(rs.getString(nameDbColumn)));
				}
				if (currDto.id.isEmpty() != true) {
					res.add(new ModelDto(currDto));
					// WB.addLog2("getModelDto, currDto=" + currDto.toString() + ", currConn="+
					// currConn, WB.strEmpty, "DAL");
				}
			}
			rs.close();
			rs = null;
			qry.close();
			qry = null;
			conn.close();
			conn = null;
			// WB.addLog("getModelDto, preparedQryText=" + preparedQryText, "res.size=" +
			// res.size(), "DAL()");

		} catch (Exception ex) {
			WB.addLog("DAL.getModelDto, ex=" + ex.getMessage(), WB.strEmpty, "DAL");
		}
		return res;
	}

	private static String getDtoFieldName(String nameDbColumn) throws Exception {
		// origin - 06.11.2023, last edit - 06.03.2025
		String res = WB.strEmpty;
		try {
			res = res + nameDbColumn.charAt(0);
			res = res.toLowerCase(); // only first letter transform into LowerCase, that was right example
										// "MeterValue to
										// "meterValue"
			res = res + nameDbColumn.substring(1, nameDbColumn.length());
		} catch (Exception ex) {
			WB.addLog("DAL.getDtoFieldName, ex=" + ex.getMessage(), WB.strEmpty, "DAL");
		}
		return res;
	}

	private static boolean existFile(String file) throws Exception {
		// origin - 20.11.2023, last edit - 06.03.2025
		boolean res = true;
		try {
			// WB.addLog("DAL.existFile, file before=" + file, WB.strEmpty, "DAL");
			file = Etc.delStr(file, Conn.prefixJdbcSqlite);
			// WB.addLog("DAL.existFile, file after=" + file, WB.strEmpty, "DAL");
			if (Files.notExists(Paths.get(file))) {
				res = false;
				// WB.addLog("not exist=" + file, "existFile()", "WB");
			}
		} catch (Exception ex) {
			WB.addLog("DAL.existFile, ex=" + ex.getMessage(), WB.strEmpty, "WB.main");
		}
		return res;
	}

	private DAL() {
		// origin - 04.11.2024, last edit - 04.11.2024
	}

	public static void test() throws Exception {
		// origin - 21.10.2023, last edit - 06.03.2025
		try {

		} catch (Exception ex) {
			WB.addLog("DAL.test, ex=" + ex.getMessage(), WB.strEmpty, "DAL");
		}
	}
}