import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.List;

public class DAL {
	// origin - 23.10.2023, last edit - 02.01.2024
	
	public static String getVacuum(String currConn) {
		// origin - 19.12.2023, last edit - 23.12.2023
		String res = currConn;
		try {
			Connection conn = DriverManager.getConnection(currConn);
			WB.lastConn = currConn;
			java.sql.Statement qry = conn.createStatement();
			qry.execute(Qry.getVacuum(currConn));
			conn.close();
		} catch (Exception ex) {
			Logger.add("DAL.getVacuum, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace() + ", res=" + res ,"", "DAL");
		} finally {
			Etc.doNothing();
		}
		//Logger.add("DAL.getVacuum, res=" + res, "", "DAL");
		return res;
	}
	
	public static String getReindex(String currConn) {
		// origin - 19.12.2023, last edit - 23.12.2023
		String res = currConn;
		try {
			Connection conn = DriverManager.getConnection(currConn);
			WB.lastConn = currConn;
			java.sql.Statement qry = conn.createStatement();
			qry.execute(Qry.getReindex(currConn));
			conn.close();
		} catch (Exception ex) {
			Logger.add("DAL.getReindex, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace() + ", res=" + res ,"", "DAL");
		} finally {
			Etc.doNothing();
		}
		//Logger.add("DAL.getReindex, res=" + res, "", "DAL");
		return res;
	}

	public static String getIntegrityCheck(String currConn) {
		// origin - 19.12.2023, last edit - 23.12.2023
		String res = currConn;
		try {
			Connection conn = DriverManager.getConnection(currConn);
			WB.lastConn = currConn;
			java.sql.Statement qry = conn.createStatement();
			qry.execute(Qry.getIntegrityCheck(currConn));
			conn.close();
		} catch (Exception ex) {
			Logger.add("DAL.getIntegrityCheck, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace() + ", res=" + res ,"", "DAL");
		} finally {
			Etc.doNothing();
		}
		//Logger.add("DAL.getIntegrityCheck, res=" + res, "", "DAL");
		return res;
	}
	
	public static String getBackup(String backupConn) {
		// origin - 18.12.2023, last edit - 23.12.2023
		String res = backupConn;
		try {
			Connection conn = DriverManager.getConnection(backupConn);
			WB.lastConn = backupConn;
			java.sql.Statement qry = conn.createStatement();
			qry.execute(Qry.getBackup(backupConn));
			conn.close();
		} catch (Exception ex) {
			Logger.add("DAL.getBackup, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace() + ", res=" + res ,"", "DAL");
		} finally {
			Etc.doNothing();
		}
		//Logger.add("DAL.getBackup, res=" + res, "", "DAL");
		return res;
	}

	public static List<ModelDto> getTemplateMore(String currConn, String templateMore) throws Exception {
		// origin - 13.11.2023, last edit - 06.01.2024
		List<ModelDto> res = new ArrayList<ModelDto>();

		if (existFile(currConn) == false) {
			Logger.add("DAL.getTemplateMore(), not exist=" + currConn, "", "DAL");
			return res;
		}

		List<ModelDto> tmp = new ArrayList<ModelDto>();
		List<String> tableList = getTableList(currConn);
		for (var currTable : tableList) {
			tmp.clear();
			tmp = getTable(currConn, Qry.getText(currConn, currTable, templateMore));
			if (tmp.isEmpty() != true) {
				res.addAll(tmp);
				tmp.clear();
			}
		}
		// Logger.add("getTemplateMore.res.size=" + res.size(), "currConn="+currConn, "DAL");
		return res;
	}

	public static List<String> getTableList(String currConn) throws Exception {
		// origin - 13.11.2023, last edit - 30.12.2023
		List<String> res = new ArrayList<String>();

		if (existFile(currConn) == false) {
			Logger.add("DAL.getTableList, not exist=" + currConn, "getTableList()", "DAL");
			return res;
		}

		currConn = Conn.getText(currConn);
		try {
			Connection conn = DriverManager.getConnection(currConn);
			WB.lastConn = currConn;
			java.sql.Statement qry = conn.createStatement();
			ResultSet rs;
			rs = qry.executeQuery(Qry.getTableListSQLite);
			while (rs.next()) {
				res.add(rs.getString("name"));
			}
			rs.close();

		} catch (Exception ex) {
			Logger.add("DAL.getTableList, ex=" + ex.getMessage(), "StackTrace=" + ex.getStackTrace(), "DAL");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static List<ModelDto> getTable(String dbStr, String preparedQryText) throws Exception {
		// origin - 28.10.2023, last edit - 31.12.2023
		List<ModelDto> res = new ArrayList<ModelDto>();
		String currConn = Conn.getText(dbStr);

		if (existFile(currConn) == false) {
			Logger.add("DAL.getTable, not exist=" + dbStr, "currConn=" + currConn, "DAL");
			return res;
		}

		res = getModelDto(currConn, preparedQryText);
		 //Logger.add("DAL.getTable, Db=" + Etc.getFileName(dbStr) + ", qry=" + preparedQryText + ", cardinality=" +
		 //res.size(), "", "DAL()");
		return res;
	}

	private static List<ModelDto> getModelDto(String currConn, String preparedQryText) throws Exception {
		// origin - 31.10.2023, last edit 02.01.2024
		List<ModelDto> res = new ArrayList<ModelDto>();

		if (existFile(currConn) == false) {
			Logger.add("DAL.getModelDto, not exist=" + currConn, "", "DAL");
			return res;
		}

		currConn = Conn.getText(currConn);
		try {
			Connection conn = DriverManager.getConnection(currConn);
			WB.lastConn = currConn;
			java.sql.Statement qry = conn.createStatement();

			ResultSet rs;
			// Logger.add("getModelDto, preparedQryText=" + preparedQryText, "currConn=" +
			// currConn, "DAL()");
			rs = qry.executeQuery(preparedQryText);

			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			String nameDbColumn = "";
			Class<ModelDto> ModelDtoClassObject = ModelDto.class;
			Field field = null;
			ModelDto currDto = new ModelDto();

			while (rs.next()) {
				currDto.clear();
				currDto.table = rsmd.getTableName(1);

				for (int i = 1; i <= columnCount; i++) {
					nameDbColumn = rsmd.getColumnName(i);
					// for each nameDbColumn example"Deal" match field ModelDto example "deal"
					field = ModelDtoClassObject.getField(getDtoFieldName(nameDbColumn));
					field.set(currDto, Etc.fixString(rs.getString(nameDbColumn)));
				}
				if (currDto.id.isEmpty() != true) {
					//res.add(currDto);
					
//					res.add(new ModelDto(currDto.table, currDto.id, currDto.parent, currDto.face1, currDto.face2, currDto.face, currDto.slice,
//							currDto.date1, currDto.date2, currDto.code, currDto.description, currDto.sign, currDto.account, currDto.geo,
//							currDto.role, currDto.info, currDto.meter, currDto.meterValue, currDto.unit, currDto.more, currDto.mark,
//							currDto.process, currDto.asset, currDto.deal, currDto.item, currDto.debt, currDto.price));
					res.add(new ModelDto(currDto));
					//Logger.add2("getModelDto, currDto=" + currDto.toString() + ", currConn="+ currConn, "", "DAL");
				}
			}
			rs.close();
			// Logger.add("getModelDto, preparedQryText=" + preparedQryText, "res.size=" +
			// res.size(), "DAL()");

		} catch (Exception ex) {
			Logger.add("DAL.getModelDto, ex=" + ex.getMessage(), ", StackTrace=" + ex.getStackTrace(), "DAL");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	private static String getDtoFieldName(String nameDbColumn) {
		// origin - 06.11.2023, last edit - 25.11.2023
		String res = "";
		res = res + nameDbColumn.charAt(0);
		res = res.toLowerCase(); // only first letter transform into LowerCase, that was right example
									// "MeterValue to
									// "meterValue"
		res = res + nameDbColumn.substring(1, nameDbColumn.length());
		return res;
	}

	private static boolean existFile(String file) throws Exception {
		// origin - 20.11.2023, last edit - 23.12.2023
		boolean res = true;
		try {
			// Logger.add("DAL.existFile, file before=" + file, "", "DAL");
			file = Etc.delStr(file, Conn.prefixJdbcSqlite);
			// Logger.add("DAL.existFile, file after=" + file, "", "DAL");
			if (Files.notExists(Paths.get(file))) {
				res = false;
				// Logger.add("not exist=" + file, "existFile()", "WB");
			}
		} catch (Exception ex) {
			Logger.add("DAL.existFile, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "WB.main");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 21.10.2023, last edit - 31.12.2023
		
//		getTable(largePath, "SELECT [T1].[Face1], [T1].[Slice], [T1].[Sign], [T1].[Account], [T1].[Asset], [T1].[Meter], [T1].[Unit], [T1].[Mark],\r\n"
//				+ "SUM(CAST([T1].[MeterValue] AS REAL)) AS MeterValue\r\n"
//				+ "\r\n"
//				+ "FROM [Workbook] AS [T1]                            \r\n"
//				+ "\r\n"
//				+ "WHERE \r\n"
//				+ "[T1].[Slice] = 'Slice.Accounting' AND\r\n"
//				+ "[T1].[Mark] = 'Mark.CD' AND\r\n"
//				+ "[T1].[Meter] = 'Meter.Quantity' AND\r\n"
//				+ "[T1].[Unit] = 'Unit.KZT' AND\r\n"
//				+ "[T1].[Account] IS NOT NUll AND\r\n"
//				+ "[T1].[Sign] IS NOT NULL AND\r\n"
//				+ "\r\n"
//				+ "[T1].[Asset] = 532 \r\n"
//				+ "\r\n"
//				+ "GROUP BY [T1].[Face1], [T1].[Slice], [T1].[Asset], [T1].[Sign], [T1].[Account], [T1].[Meter], [T1].[Unit], [T1].[Mark]");
	}
}
