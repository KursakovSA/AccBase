import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

public class DAL {
	// origin - 23.10.2023, last edit - 14.06.2024

	public static void getReplaceInto(TreeSet<String> setConn, List<ModelDto> set) throws Exception {
		// origin - 09.02.2024, last edit - 05.06.2024
		try {
			for (var currConn : setConn) {
				setReplaceInto(currConn, set);
			}
		} catch (Exception ex) {
			WB.addLog("DAL.getReplaceInto, ex=" + ex.getMessage(), "", "DAL");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DAL.getReplaceInto, setConn.size=" + setConn.size() + ",
		// set.size=" + set.size(), "", "DAL");
	}

	@SuppressWarnings("unused")
	private static void setReplaceInto(String currConn, List<ModelDto> set) throws Exception {
		// origin - 02.02.2024, last edit - 14.06.2024
		LocalDateTime localStart = WB.getLocalStart();
		try {
			currConn = Conn.getText(currConn);
			WB.lastConn = currConn;
			Connection conn = DriverManager.getConnection(currConn);
			conn.setAutoCommit(false);

			PreparedStatement qry = null;
			
//			//// check dublicate in currConn and remove duplicate in input set
//			WB.addLog2("DAL.setReplaceInto, currConn=" + currConn + ", before remove duplicate2 set.size=" + set.size(),
//					"", "DAL");
//			List<ModelDto> currConnSet = new ArrayList<ModelDto>();
//			currConnSet = DAL.getByTemplate(currConn, "");
//			set = ModelDto.removeDuplicate2(currConnSet, set);
//			WB.addLog2("DAL.setReplaceInto, currConn=" + currConn + ", after remove duplicate2 set.size=" + set.size(),
//					"", "DAL");
			
			for (var currDto : set) {
				// PreparedStatement qry = conn.prepareStatement(Qry.getReplaceInto(currDto));
				qry = conn.prepareStatement(Qry.getReplaceInto(currDto));
				qry.executeUpdate();
				qry.close();
			}
			qry = null;
			conn.commit();
			conn.setAutoCommit(true);
			conn.close();
			conn = null;
		} catch (Exception ex) {
			WB.addLog("DAL.setReplaceInto, ex=" + ex.getMessage() + ", currConn=" + currConn, "", "DAL");
		} finally {
			Etc.doNothing();
		}

//		 WB.getLocalEnd("DAL.setReplaceInto for List<ModelDto> set.size=" + set.size()
//		 + ", currConn=" + currConn, localStart);
//		 WB.addLog2("DAL.setReplaceInto, currConn=" + currConn + ", set.size=" +
//		 set.size(), "", "DAL");
	}

	public static void getVacuum(TreeSet<String> setConn) throws Exception {
		// origin - 19.12.2023, last edit - 05.06.2024
		for (var currConn : setConn) {
			currConn = Conn.getText(currConn);
			try {
				Connection conn = DriverManager.getConnection(currConn);
				WB.lastConn = currConn;
				java.sql.Statement qry = conn.createStatement();
				qry.execute(Qry.getVacuum(currConn));
				conn.close();
			} catch (Exception ex) {
				WB.addLog("DAL.getVacuum, ex=" + ex.getMessage(), "", "DAL");
			} finally {
				Etc.doNothing();
			}
		}
		// WB.addLog2("DAL.getVacuum, setConn.size=" + setConn.size(), "", "DAL");
	}

	public static void getReindex(TreeSet<String> setConn) throws Exception {
		// origin - 19.12.2023, last edit - 05.06.2024
		for (var currConn : setConn) {
			currConn = Conn.getText(currConn);
			try {
				Connection conn = DriverManager.getConnection(currConn);
				WB.lastConn = currConn;
				java.sql.Statement qry = conn.createStatement();
				qry.execute(Qry.getReindex(currConn));
				conn.close();
			} catch (Exception ex) {
				WB.addLog("DAL.getReindex, ex=" + ex.getMessage(), "", "DAL");
			} finally {
				Etc.doNothing();
			}
		}
		// WB.addLog2("DAL.getReindex, setConn.size=" + setConn.size(), "", "DAL");
	}

	public static void getIntegrityCheck(TreeSet<String> setConn) throws Exception {
		// origin - 19.12.2023, last edit - 14.06.2024
		for (var currConn : setConn) {
			currConn = Conn.getText(currConn);
			try {
				Connection conn = DriverManager.getConnection(currConn);
				WB.lastConn = currConn;
				java.sql.Statement qry = conn.createStatement();
				qry.execute(Qry.getIntegrityCheck(currConn));
				
				qry.close();
				qry = null;
				conn.close();
				conn = null;
			} catch (Exception ex) {
				WB.addLog("DAL.getIntegrityCheck, ex=" + ex.getMessage(), "", "DAL");
			} finally {
				Etc.doNothing();
			}
			// WB.addLog2("DAL.getIntegrityCheck, setConn.size=" + setConn.size(), "",
			// "DAL");
		}
	}

	public static void getOutputBackup(TreeSet<String> setConn) throws Exception {
		// origin - 28.05.2024, last edit - 14.06.2024
		for (var currConn : setConn) {
			currConn = Conn.getText(currConn);
			// WB.addLog2("DAL.getOutputBackup, currConn=" + currConn, "", "DAL");
			try {
				Connection conn = DriverManager.getConnection(currConn);
				// WB.addLog2("DAL.getOutputBackup, Conn=" + conn.toString(), "", "DAL");
				WB.lastConn = currConn;
				java.sql.Statement qry = conn.createStatement();

				// String tmp = Qry.getOutputBackup(currConn);
				// WB.addLog2("DAL.getOutputBackup, Qry.getOutputBackup(currConn)=" + tmp, "",
				// "DAL");
				qry.execute(Qry.getOutputBackup(currConn));
				
				qry.close();
				qry = null;
				conn.close();
				conn = null;
			} catch (Exception ex) {
				WB.addLog("DAL.getOutputBackup, ex=" + ex.getMessage(), "", "DAL");
			} finally {
				Etc.doNothing();
			}
		}
		// WB.addLog2("DAL.getOutputBackup, setConn.size=" + setConn.size(), "", "DAL");
	}

	public static void getBackup(TreeSet<String> setConn) throws Exception {
		// origin - 18.12.2023, last edit - 14.06.2024
		for (var currConn : setConn) {
			currConn = Conn.getText(currConn);
			try {
				Connection conn = DriverManager.getConnection(currConn);
				WB.lastConn = currConn;
				java.sql.Statement qry = conn.createStatement();
				qry.execute(Qry.getBackup(currConn));
				
				qry.close();
				qry = null;
				conn.close();
				conn = null;
			} catch (Exception ex) {
				WB.addLog("DAL.getBackup, ex=" + ex.getMessage(), "", "DAL");
			} finally {
				Etc.doNothing();
			}
		}
		// WB.addLog2("DAL.getBackup, setConn.size=" + setConn.size(), "", "DAL");
	}

	public static List<ModelDto> setByTemplate(TreeSet<String> setConn, String templateMore) throws Exception {
		// TOTHINK - add other template - asset, face, etc.
		// origin - 30.05.2024, last edit - 14.06.2024
		// get common ModelDto what consist all tables all conn from multiply conn
		List<ModelDto> res = new ArrayList<ModelDto>();
		List<ModelDto> tmp = new ArrayList<ModelDto>();
		// boolean resRemoveAll = false;
		try {
			for (var currConn : setConn) {
				if (existFile(currConn) == false) {
					WB.addLog("DAL.setByTemplate(), not exist=" + currConn, "", "DAL");
					return res;
				}

				tmp.clear();
				tmp = getByTemplate(currConn, templateMore);
				if (tmp.isEmpty() == false) {
					res.addAll(tmp); //res = ModelDto.removeDuplicate(res, tmp);
					tmp.clear();
				}
			}
		} catch (Exception ex) {
			WB.addLog("DAL.getTableList, ex=" + ex.getMessage(), "", "DAL");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DAL.setByTemplate, res.size=" + res.size() + ", setConn.size=" +
		// setConn.size(), "", "DAL");
		return res;
	}

	public static List<ModelDto> getByTemplate(String currConn, String templateMore) throws Exception {// TOTHINK - add
																										// other
																										// template -
																										// asset, face,
																										// etc.
		// origin - 13.11.2023, last edit - 01.06.2024
		List<ModelDto> res = new ArrayList<ModelDto>();

		if (existFile(currConn) == false) {
			WB.addLog("DAL.getByTemplate(), not exist=" + currConn, "", "DAL");
			return res;
		}

		List<ModelDto> tmp = new ArrayList<ModelDto>();
		List<String> tableList = getTableList(currConn);
		for (var currTable : tableList) {
			tmp.clear();
			tmp = getTable(currConn, Qry.getText(currConn, currTable, templateMore));
			if (tmp.isEmpty() != true) {
				res.addAll(tmp);
				tmp.clear();
			}
		}
		// WB.addLog2("DAL.getByTemplate, res.size=" + res.size() + ",
		// currConn="+currConn, "", "DAL");
		return res;
	}

	public static List<String> getTableList(String currConn) throws Exception {
		// origin - 13.11.2023, last edit - 14.06.2024
		List<String> res = new ArrayList<String>();

		if (existFile(currConn) == false) {
			WB.addLog("DAL.getTableList, not exist=" + currConn, "getTableList()", "DAL");
			return res;
		}

		currConn = Conn.getText(currConn);
		try {
			Connection conn = DriverManager.getConnection(currConn);
			WB.lastConn = currConn;
			java.sql.Statement qry = conn.createStatement();
			ResultSet rs;
			rs = qry.executeQuery(Qry.getTableListSQLite);
			while (rs.next()) {
				res.add(rs.getString("name"));
			}
			rs.close();
			rs = null;
			qry.close();
			qry = null;
			conn.close();
			conn = null;

		} catch (Exception ex) {
			WB.addLog("DAL.getTableList, ex=" + ex.getMessage(), "", "DAL");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DAL.getTableList, res=" + res, "currConn="+currConn, "DAL");
		return res;
	}

	public static List<ModelDto> getTable(String dbStr, String preparedQryText) throws Exception {
		// origin - 28.10.2023, last edit - 28.05.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		String currConn = Conn.getText(dbStr);

		if (existFile(currConn) == false) {
			WB.addLog("DAL.getTable, not exist=" + dbStr, "currConn=" + currConn, "DAL");
			return res;
		}

		res = getModelDto(currConn, preparedQryText);
//		 WB.addLog2("DAL.getTable, Db=" + Etc.getFileName(dbStr) + ", qry=" +
//		 preparedQryText + ", cardinality=" +
//		 res.size(), "", "DAL()");
		return res;
	}

	private static List<ModelDto> getModelDto(String currConn, String preparedQryText) throws Exception {
		// origin - 31.10.2023, last edit - 14.06.2024
		List<ModelDto> res = new ArrayList<ModelDto>();

		if (existFile(currConn) == false) {
			WB.addLog("DAL.getModelDto, not exist=" + currConn, "", "DAL");
			return res;
		}

		currConn = Conn.getText(currConn);
		try {
			Connection conn = DriverManager.getConnection(currConn);
			WB.lastConn = currConn;
			java.sql.Statement qry = conn.createStatement();

			ResultSet rs;
			// WB.addLog("getModelDto, preparedQryText=" + preparedQryText, "currConn=" +
			// currConn, "DAL()");
			rs = qry.executeQuery(preparedQryText);

			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			String nameDbColumn = "";
			Class<ModelDto> ModelDtoClassObject = ModelDto.class;
			Field field = null;
			ModelDto currDto = new ModelDto();

			while (rs.next()) {
				currDto.clear();
				currDto.table = rsmd.getTableName(1);

				for (int i = 1; i <= columnCount; i++) {
					nameDbColumn = rsmd.getColumnName(i);
					// for each nameDbColumn example"Deal" match field ModelDto example "deal"
					field = ModelDtoClassObject.getField(getDtoFieldName(nameDbColumn));
					field.set(currDto, Etc.fixString(rs.getString(nameDbColumn)));
				}
				if (currDto.id.isEmpty() != true) {
					res.add(new ModelDto(currDto));
					// WB.addLog2("getModelDto, currDto=" + currDto.toString() + ", currConn="+
					// currConn, "", "DAL");
				}
			}
			rs.close();
			rs= null;
			qry.close();
			qry = null;
			conn.close();
			conn = null;
			// WB.addLog("getModelDto, preparedQryText=" + preparedQryText, "res.size=" +
			// res.size(), "DAL()");

		} catch (Exception ex) {
			WB.addLog("DAL.getModelDto, ex=" + ex.getMessage(), "", "DAL");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	private static String getDtoFieldName(String nameDbColumn) throws Exception {
		// origin - 06.11.2023, last edit - 05.06.2024
		String res = "";
		res = res + nameDbColumn.charAt(0);
		res = res.toLowerCase(); // only first letter transform into LowerCase, that was right example
									// "MeterValue to
									// "meterValue"
		res = res + nameDbColumn.substring(1, nameDbColumn.length());
		return res;
	}

	private static boolean existFile(String file) throws Exception {
		// origin - 20.11.2023, last edit - 23.05.2024
		boolean res = true;
		try {
			// WB.addLog("DAL.existFile, file before=" + file, "", "DAL");
			file = Etc.delStr(file, Conn.prefixJdbcSqlite);
			// WB.addLog("DAL.existFile, file after=" + file, "", "DAL");
			if (Files.notExists(Paths.get(file))) {
				res = false;
				// WB.addLog("not exist=" + file, "existFile()", "WB");
			}
		} catch (Exception ex) {
			WB.addLog("DAL.existFile, ex=" + ex.getMessage(), "", "WB.main");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 21.10.2023, last edit - 09.02.2024
		// getTableList(WB.lastConn);
		// setReplaceInto(WB.lastConn, ModelDto.getTestSubset());
		// getReplaceInto(Conn.work, ModelDto.getTestSubset());

//		getTable(largePath, "SELECT [T1].[Face1], [T1].[Slice], [T1].[Sign], [T1].[Account], [T1].[Asset], [T1].[Meter], [T1].[Unit], [T1].[Mark],\r\n"
//				+ "SUM(CAST([T1].[MeterValue] AS REAL)) AS MeterValue\r\n"
//				+ "\r\n"
//				+ "FROM [Workbook] AS [T1]                            \r\n"
//				+ "\r\n"
//				+ "WHERE \r\n"
//				+ "[T1].[Slice] = 'Slice.Accounting' AND\r\n"
//				+ "[T1].[Mark] = 'Mark.CD' AND\r\n"
//				+ "[T1].[Meter] = 'Meter.Quantity' AND\r\n"
//				+ "[T1].[Unit] = 'Unit.KZT' AND\r\n"
//				+ "[T1].[Account] IS NOT NUll AND\r\n"
//				+ "[T1].[Sign] IS NOT NULL AND\r\n"
//				+ "\r\n"
//				+ "[T1].[Asset] = 532 \r\n"
//				+ "\r\n"
//				+ "GROUP BY [T1].[Face1], [T1].[Slice], [T1].[Asset], [T1].[Sign], [T1].[Account], [T1].[Meter], [T1].[Unit], [T1].[Mark]");
	}
}
