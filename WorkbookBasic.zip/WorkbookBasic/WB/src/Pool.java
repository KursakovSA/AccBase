import java.util.ArrayList;
import java.util.List;

public class Pool extends ModelDto { // sectoralPawnshop
	// origin - 25.01.2025, last edit - 19.03.2025
	public UnitVal firstItemLimit;
	public RangeVal countLimit, nextItemLimit;
	public static String strPool;

	static {
		try {
			Pool.strPool = "Pool";
		} catch (Exception ex) {
			WB.addLog("Pool.static ctor, ex=" + ex.getMessage(), "", "Pool");
		}
	}

	public void isExist() throws Exception {
		// origin - 25.01.2025, last edit - 19.03.2025
		super.isExist();
		try {
			List<ModelDto> srcDto = new ArrayList<ModelDto>();

			srcDto = WB.abcLast.template;
			var tmp1 = ReadSet.getEqualsByCode(srcDto, this.id);
			if (tmp1.size() != 0) {
				var currDto = tmp1.getFirst();
				this.code = currDto.code;
				this.parent = currDto.parent;
				this.face1 = currDto.face1;
				this.face2 = currDto.face2;
				this.face = currDto.face;
				this.description = currDto.description;
				this.geo = currDto.geo;
				this.role = currDto.role;
				this.info = currDto.info;
				this.more = currDto.more;

				this.countLimit = new RangeVal(MoreVal.getFieldByKey(this.more, "CountLimit"));
				this.firstItemLimit = new UnitVal(MoreVal.getFieldByKey(this.more, "FirstItemLimit"));
				this.nextItemLimit = new RangeVal(MoreVal.getFieldByKey(this.more, "NextItemLimit"));

				this.isExist = true;
			}

		} catch (Exception ex) {
			WB.addLog("Pool.isExist, ex=" + ex.getMessage(), "", "Pool");
		}
	}

	public void fix() throws Exception {// TOTHINK
		// origin - 25.01.2025, last edit - 19.03.2025
		try {
			super.fix();
		} catch (Exception ex) {
			WB.addLog("Pool.fix, ex=" + ex.getMessage(), "", "Pool");
		}
	}

	public void isValid() throws Exception {// TOTHINK
		// origin - 25.01.2025, last edit - 19.03.2025
		super.isValid();
		try {

		} catch (Exception ex) {
			WB.addLog("Pool.isValid, ex=" + ex.getMessage(), "", "Pool");
		}
	}

	public Pool(String Id) throws Exception {
		// origin - 25.01.2025, last edit - 25.01.2025
		this.clear();
		this.src = this.id = this.code = Id;
		this.isExist();
		this.isValid();
		this.fix();
	}

	public Pool() throws Exception {
		// origin - 25.01.2025, last edit - 25.01.2025
		this.clear();
	}

	public String toString() {
		// origin - 25.01.2025, last edit - 19.03.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src.length());
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code.length());
			res = res + Fmtr.addIfNotEmpty(", description ", this.description.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addAnyway(", countLimit ", this.countLimit.id);
			res = res + Fmtr.addAnyway(", firstItemLimit ", this.firstItemLimit.id);
			res = res + Fmtr.addAnyway(", nextItemLimit ", this.nextItemLimit.id);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public void clear() throws Exception {
		// origin - 25.01.2025, last edit - 19.03.2025
		try {
			super.clear();
			this.table = "Deal"; // ??magic string ??
			this.firstItemLimit = new UnitVal();
			this.countLimit = this.nextItemLimit = new RangeVal();
		} catch (Exception ex) {
			WB.addLog("Pool.clear, ex=" + ex.getMessage(), "", "Pool");
		}
	}

	public static void test() throws Exception {
		// origin - 25.01.2025, last edit - 19.03.2025
		try {

//			// ctor()
//			WB.addLog2("Pool.test.ctor()=" + new Pool(), "", "Pool");

//			// ctor(string)
//			for (var ctorStringArg1 : new String[] { "", "PawnDoc.Template1.V1.Term1.Pool" }) {
//				WB.addLog2("Pool.test.ctor(string)=" + new Pool(ctorStringArg1), "", "Pool");
//			}

		} catch (Exception ex) {
			WB.addLog("Pool.test, ex=" + ex.getMessage(), "", "Pool");
		}
	}
}