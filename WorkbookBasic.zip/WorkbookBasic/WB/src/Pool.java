import java.util.ArrayList;
import java.util.List;

public class Pool extends ModelDto { // sectoralPawnshop
	// origin - 25.01.2025, last edit - 26.01.2025
	public RangeVal countLimit, anyPawnDocPoolLimit;
	public static String strPool;

	static {
		try {
			Pool.strPool = "Pool"; // ??magic string??
		} catch (Exception ex) {
			WB.addLog("Pool.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Pool");
		} finally {
			Etc.doNothing();
		}
	}

	public void isExist() throws Exception {
		// origin - 25.01.2025, last edit - 25.01.2025
		super.isExist();
		try {
			List<ModelDto> srcDto = new ArrayList<ModelDto>();

			srcDto = WB.abcLast.template;
			var tmp1 = ReadSet.getEqualsByCode(srcDto, this.id);
			if (tmp1.size() != 0) {
				var currDto = tmp1.getFirst();
				this.code = currDto.code;
				this.parent = currDto.parent;
				this.face1 = currDto.face1;
				this.face2 = currDto.face2;
				this.face = currDto.face;
				this.description = currDto.description;
				this.geo = currDto.geo;
				this.role = currDto.role;
				this.info = currDto.info;
				this.more = currDto.more;

				this.countLimit = new RangeVal(MoreVal.getFieldByKey(this.more, "CountLimit"));
				this.anyPawnDocPoolLimit = new RangeVal(MoreVal.getFieldByKey(this.more, "AnyPawnDocPoolLimit"));

				this.isExist = true;
			}

		} catch (Exception ex) {
			WB.addLog("Pool.isExist, ex=" + ex.getMessage(), WB.strEmpty, "Pool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Pool.isExist=" + this.isExist, WB.strEmpty,"Pool");
	}

	public void fix() throws Exception {// TOTHINK
		// origin - 25.01.2025, last edit - 25.01.2025
		try {
			super.fix();
		} catch (Exception ex) {
			WB.addLog("Pool.fix, ex=" + ex.getMessage(), WB.strEmpty, "Pool");
		} finally {
			Etc.doNothing();
		}
	}

	public void isValid() throws Exception {// TOTHINK
		// origin - 25.01.2025, last edit - 25.01.2025
		super.isValid();
		try {

		} catch (Exception ex) {
			WB.addLog("Pool.isValid, ex=" + ex.getMessage(), WB.strEmpty, "Pool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Pool.isValid=" + this.isValid,WB.strEmpty,"Pool");
	}

	public Pool(String Id) throws Exception {
		// origin - 25.01.2025, last edit - 25.01.2025
		this.clear();
		this.src = this.id = this.code = Id;
		this.isExist();
		this.isValid();
		this.fix();
	}

	public Pool() throws Exception {
		// origin - 25.01.2025, last edit - 25.01.2025
		this.clear();
	}

	public String toString() {
		// origin - 25.01.2025, last edit - 25.01.2025
		String res = WB.strEmpty;
		try {
			res = res + Fmtr.addAnyway("src ", this.src.length());
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code.length());
			res = res + Fmtr.addIfNotEmpty(", description ", this.description.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addAnyway(", countLimit ", this.countLimit.id);
			res = res + Fmtr.addAnyway(", anyPawnDocPoolLimit ", this.anyPawnDocPoolLimit.id);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public void clear() throws Exception {
		// origin - 25.01.2025, last edit - 25.01.2025
		try {
			super.clear();
			this.table = "Deal"; // ??magic string ??
			this.countLimit = this.anyPawnDocPoolLimit = new RangeVal();
		} catch (Exception ex) {
			WB.addLog("Pawn.clear, ex=" + ex.getMessage(), WB.strEmpty, "Pawn");
		} finally {
			Etc.doNothing();
		}
	}

	public static void test() throws Exception {
		// origin - 25.01.2025, last edit - 25.01.2025
		try {

//			// ctor()
//			WB.addLog2("Pool.test.ctor()=" + new Pool(), WB.strEmpty, "Pool");

//			// ctor(string)
//			for (var ctorStringArg1 : new String[] { WB.strEmpty,
//					"Deal.Face.Pawnshop.Template1.2024-11-08.Term1.Pool" }) {
//				WB.addLog2("Pool.test.ctor(string)=" + new Pool(ctorStringArg1), WB.strEmpty, "Pool");
//			}

		} catch (Exception ex) {
			WB.addLog("Pool.test, ex=" + ex.getMessage(), WB.strEmpty, "Pool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Pool.test end ", WB.strEmpty, "Pool");
	}
}