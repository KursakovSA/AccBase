import java.io.File;
import java.util.Arrays;
import java.util.TreeSet;

public class Input extends Model {
	// origin - 23.11.2023, last edit - 06.12.2023
	public String dir = new String();
	public String file = new String();
	public String path = new String();
	
	static{
		standard = new TreeSet<String>(Arrays.asList("EsfXML", "PkbXLSX"));
	}

	{
		dir = WB.docDir;
		file="";
	}
	
	public Input() {
		// origin - 04.12.2023, last edit - 04.12.2023
		path = dir + File.separator + file;
	}

	public static void test() {
		// origin - 23.11.2023, last edit - 06.12.2023
	}
}
