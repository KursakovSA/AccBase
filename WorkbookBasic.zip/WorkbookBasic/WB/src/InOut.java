import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.TreeSet;

public class InOut extends ModelDto {
	// origin - 30.09.2023, last edit - 09.09.2024
	public static TreeSet<String> standard = new TreeSet<String>();
	public static TreeSet<String> sectoral = new TreeSet<String>();
	public static TreeSet<String> custom = new TreeSet<String>();

	static {
		try {
			// dir = WB.commonDocDir;
			InOut.standard = new TreeSet<String>(
					List.of("EsfXML", "MT100", "MT102", "SwiftOPV", "SwiftGFSS", "SwiftOSMS, SwiftOPVR"));
			// standard = new TreeSet<String>(List.of("EsfXML", "PkbXLSX",
			// "ExtFile"));//TODO
			InOut.sectoral = new TreeSet<String>(List.of(WB.strEmpty, WB.strEmpty, WB.strEmpty));// TODO
			InOut.custom = new TreeSet<String>(List.of(WB.strEmpty, WB.strEmpty, WB.strEmpty));// TODO
		} catch (Exception ex) {
			WB.addLog("InOut.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "InOut");
		} finally {
			Etc.doNothing();
		}
	}

	public static String getFileName(String pathFile) throws Exception {
		// origin - 03.06.2024, last edit - 27.06.2024
		String res = WB.strEmpty;
		try {
			pathFile = Etc.delStr(pathFile, Conn.prefixJdbcSqlite);// clean prefix JDBC if pathFile = conn
			Path p = Paths.get(pathFile);
			File f = p.toFile();
			res = Etc.fixTrim(f.getName());
		} catch (Exception ex) {
			WB.addLog("InOut.getFileName, ex=" + ex.getMessage() + ", pathFile=" + pathFile, WB.strEmpty, "InOut");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("InOut.getFileName, res=" + res + ", pathFile=" + pathFile,
		// WB.strEmpty, "InOut");
		return res;
	}

	public static boolean delFile(File fileDel) throws Exception {
		// origin - 29.05.2024, last edit - 27.06.2024
		boolean res = false;
		try {
			res = Files.deleteIfExists(fileDel.toPath());
		} catch (Exception ex) {
			WB.addLog("InOut.delfile, ex=" + ex.getMessage(), WB.strEmpty, "InOut");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("InOut.delFile, res=" + res + ", fileDel = " + fileDel,
		// WB.strEmpty, "InOut");
		return res;
	}

	public static void getDelFile(String dirPath, String patternInOut, String patternTo, String patternExtension)
			throws Exception {
		// origin - 29.05.2024, last edit - 13.11.2024
		try {
			int count = 0;
			if (Files.notExists(Paths.get(dirPath))) {
				WB.addLog("InOut.getDelFile, Files.notExists in=" + Paths.get(dirPath), WB.strEmpty, "InOut");
				return;
			}

			File file = Paths.get(dirPath).toFile();
			String currFileName = WB.strEmpty;
			for (File currFile : file.listFiles()) {
				if (currFile.isFile() == false) {
					continue;
				}

				currFileName = currFile.getName().toString();
				// WB.addLog2("InOut.getDelFile, select currFileName=" + currFileName,
				// WB.strEmpty, "InOut");

				// in future will be new versions SQLite, example "sqlite3, sqlite4" etc.
				if ((patternExtension.isEmpty() == false)
						& (Etc.strContains(currFileName, patternExtension) == false)) {
					continue;
				}

				// example, patternInOut="Input", "Output", "input", "output", "INPUT",
				// "OUTPUT",
				// etc.
				if ((patternInOut.isEmpty() == false) & (Etc.strContains(currFileName, patternInOut) == false)) {
					continue;
				}

				// example patternTo="toAll", "TOALL", "ToAll", etc.
				if ((patternTo.isEmpty() == false) & (Etc.strContains(currFileName, patternTo) == false)) {
					continue;
				}

				if (delFile(currFile)) {
					count = count + 1;
				}
			}
		} catch (Exception ex) {
			WB.addLog("InOut.delDelfile, ex=" + ex.getMessage(), WB.strEmpty, "InOut");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("InOut.getDelFile, count=" + count + ", patternInOut=" +
		// patternInOut + ", patternTo=" + patternTo, WB.strEmpty, "InOut");
	}

//	public static String formatter(String name, String strAdd) throws Exception {// TOTHINK
//		// origin - 05.12.2023, last edit - 24.08.2024
//		String res = WB.strEmpty;
//		try {
//			strAdd = Etc.fixTrim(strAdd);
//			res = res + Etc.fixTrim(name) + WB.strEquals + strAdd + WB.strCommaSpace;
//		} catch (Exception ex) {
//			WB.addLog("InOut.formatter, ex=" + ex.getMessage(), WB.strEmpty, "InOut");
//		} finally {
//			Etc.doNothing();
//		}
//		return res;
//	}

	public static StringBuilder addHeader(StringBuilder txtSwift) throws Exception {// TOTHINK
		// origin - 19.10.2023, last edit - 05.07.2024
		StringBuilder addTxtSwift = new StringBuilder(txtSwift);
		try {
		} catch (Exception ex) {
			WB.addLog("InOut.addHeader, ex=" + ex.getMessage(), WB.strEmpty, "InOut");
		} finally {
			Etc.doNothing();
		}
		return addTxtSwift;
	}

	public static StringBuilder addDetail(StringBuilder txtSwift) throws Exception {// TOTHINK
		// origin - 19.10.2023, last edit - 05.07.2024
		StringBuilder addTxtSwift = new StringBuilder(txtSwift);
		try {
		} catch (Exception ex) {
			WB.addLog("InOut.addDetail, ex=" + ex.getMessage(), WB.strEmpty, "InOut");
		} finally {
			Etc.doNothing();
		}
		return addTxtSwift;
	}

	public static StringBuilder addFooter(StringBuilder txtSwift) throws Exception {// TOTHINK
		// origin - 19.10.2023, last edit - 05.07.2024
		StringBuilder addTxtSwift = new StringBuilder(txtSwift);
		try {
		} catch (Exception ex) {
			WB.addLog("InOut.addFooter, ex=" + ex.getMessage(), WB.strEmpty, "InOut");
		} finally {
			Etc.doNothing();
		}
		return addTxtSwift;
	}

//	public static StringBuilder getSwiftOPV(Workbook WorkbookSalary) throws Exception {// TOTHINK
//		// origin - 30.09.2023, last edit - 29.07.2024
//		InOut currOut = new InOut();
//		currOut.file = "swift_OPV.txt";
//		currOut.path = dir + File.separator + currOut.file;
//		WB.addLog("getSwiftOPV, currOut.outputPath=" + currOut.path, WB.strEmpty, "Output");
//		StringBuilder txtSwift = new StringBuilder(WB.strEmpty);
//		try {
//			addHeader(txtSwift);
//			addDetail(txtSwift);
//			addFooter(txtSwift);
//		} catch (Exception ex) {
//			WB.addLog("InOut.addFooter, ex=" + ex.getMessage(), WB.strEmpty, "InOut");
//		} finally {
//			Etc.doNothing();
//		}
//		WB.addLog(txtSwift.length(), "txtSwift.length()", "Out.SwiftOPV()");
//		return txtSwift;
//	}

//	public static void getOut() throws Exception {// TOTHINK
//		// origin - 19.10.2023, last edit - 29.07.2024
//		try {
//			StringBuilder textSwift = getSwiftOPV(null);
//			InOut currOut = new InOut();
//			currOut.file = "swift_OPV.txt";
//			currOut.path = dir + File.separator + currOut.file;
//			Path pf = Paths.get(currOut.path);
//			WB.addLog("getOut, currOut.outputPath=" + currOut.path, WB.strEmpty, "Output");
//			WB.writeReplace(pf, textSwift.toString());
//			WB.openFile(currOut.file);
//		} catch (Exception ex) {
//			WB.addLog("InOut.getOut, ex=" + ex.getMessage(), WB.strEmpty, "InOut");
//		} finally {
//			Etc.doNothing();
//		}
//	}

	public InOut() throws Exception {
		// origin - 04.12.2023, last edit - 04.08.2024
		super();
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 16.09.2024
		try {

		} catch (Exception ex) {
			WB.addLog("InOut.test, ex=" + ex.getMessage(), WB.strEmpty, "InOut");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("InOut.test end ", WB.strEmpty, "InOut");
	}
}
