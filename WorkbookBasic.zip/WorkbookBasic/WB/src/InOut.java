import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.TreeSet;

public class InOut extends Model {
	// origin - 30.09.2023, last edit - 27.06.2024
	private static String dir = new String();
	private String file = new String();
	private String path = new String();

	static {
		dir = WB.commonDocDir;
		standard = new TreeSet<String>(
				Arrays.asList("EsfXML", "MT100", "MT102", "SwiftOPV", "SwiftGFSS", "SwiftOSMS, SwiftOPVR"));
		//standard = new TreeSet<String>(Arrays.asList("EsfXML", "PkbXLSX", "ExtFile"));//TODO
		sectoral = new TreeSet<String>(Arrays.asList(WB.strEmpty, WB.strEmpty, WB.strEmpty));// TODO
		custom = new TreeSet<String>(Arrays.asList(WB.strEmpty, WB.strEmpty, WB.strEmpty));// TODO
	}
	
	public static String getFileName(String pathFile) throws Exception {
		// origin - 03.06.2024, last edit - 27.06.2024
		String res = WB.strEmpty;
		try {
			pathFile = Etc.delStr(pathFile, Conn.prefixJdbcSqlite);// clean prefix JDBC if pathFile = conn
			Path p = Paths.get(pathFile);
			File f = p.toFile();
			res = Etc.fixTrim(f.getName());
		} catch (Exception ex) {
			WB.addLog("InOut.getFileName, ex=" + ex.getMessage() + ", pathFile=" + pathFile, WB.strEmpty, "InOut");
		} finally {
			Etc.doNothing();
		}
		//WB.addLog2("InOut.getFileName, res=" + res + ", pathFile=" + pathFile, WB.strEmpty, "InOut");
		return res;
	}
	
	public static boolean delFile(File fileDel) throws Exception {
		// origin - 29.05.2024, last edit - 27.06.2024
		boolean res = false;
		try {
			res = Files.deleteIfExists(fileDel.toPath());
		} catch (Exception ex) {
			WB.addLog("InOut.delfile, ex=" + ex.getMessage(), WB.strEmpty, "InOut");
		} finally {
			Etc.doNothing();
		}
		//WB.addLog2("InOut.delFile, res=" + res + ", fileDel = " + fileDel, WB.strEmpty, "InOut");
		return res;
	}
	
	public static void getDelFile(String dirPath, String patternInOut, String patternTo, String patternExtension) throws Exception {
		// origin - 29.05.2024, last edit - 27.06.2024
		int count = 0;
		if (Files.notExists(Paths.get(dirPath))) {
			WB.addLog("InOut.getDelFile, Files.notExists in=" + Paths.get(dirPath), WB.strEmpty, "InOut");
			return;
		}

		File file = Paths.get(dirPath).toFile();
		String currFileName = WB.strEmpty;
		for (File currFile : file.listFiles()) {
			if (currFile.isFile() == false) {
				continue;
			}
			
			currFileName = currFile.getName().toString();
			//WB.addLog2("InOut.getDelFile, select currFileName=" + currFileName, WB.strEmpty, "InOut");

			// in future will be new versions SQLite, example "sqlite3, sqlite4" etc.
			if (patternExtension.isEmpty() == false) {
				if (Etc.strContains(currFileName, patternExtension) == false) {
					continue;
				}
			}
			
			// example, patternInOut="Input", "Output", "input", "output", "INPUT", "OUTPUT",
			// etc.
			if (patternInOut.isEmpty() == false) {
				if (Etc.strContains(currFileName, patternInOut) == false) {
					continue;
				}
			}

			// example patternTo="toAll", "TOALL", "ToAll", etc.
			if (patternTo.isEmpty() == false) {
				if (Etc.strContains(currFileName, patternTo) == false) {
					continue;
				}
			}
			
			if (delFile(currFile)) {
				count = count + 1;
			}
		}
		
		//WB.addLog2("InOut.getDelFile, count=" + count + ", patternInOut=" + patternInOut + ", patternTo=" + patternTo, WB.strEmpty, "InOut");
	}


	public static String formatter(String name, String strAdd) {// TOTHINK
		// origin - 05.12.2023, last edit - 27.06.2024
		String res = WB.strEmpty;
		strAdd = Etc.fixTrim(strAdd);
		res = res + Etc.fixTrim(name) + "=" + strAdd + ", ";
		return res;
	}

	public static String appender(String strRes, String strAdd) {// TOTHINK
		// origin - 05.12.2023, last edit - 14.06.2024
		String res = strRes;
		res = res + strAdd;
		return res;
	}

	public static StringBuilder addHeader(StringBuilder txtSwift) {// TOTHINK
		// origin - 19.10.2023, last edit - 14.06.2024
		StringBuilder addTxtSwift = new StringBuilder(txtSwift);
		// TODO
		return addTxtSwift;
	}

	public static StringBuilder addDetail(StringBuilder txtSwift) {// TOTHINK
		// origin - 19.10.2023, last edit - 14.06.2024
		StringBuilder addTxtSwift = new StringBuilder(txtSwift);
		// TODO
		return addTxtSwift;
	}

	public static StringBuilder addFooter(StringBuilder txtSwift) {// TOTHINK
		// origin - 19.10.2023, last edit - 14.06.2024
		StringBuilder addTxtSwift = new StringBuilder(txtSwift);
		// TODO
		return addTxtSwift;
	}

	public static StringBuilder getSwiftOPV(Workbook WorkbookSalary) {// TOTHINK
		// origin - 30.09.2023, last edit - 27.06.2024
		InOut currOut = new InOut();
		currOut.file = "swift_OPV.txt";
		currOut.path = dir + File.separator + currOut.file;
		WB.addLog("getSwiftOPV, currOut.outputPath=" + currOut.path, WB.strEmpty, "Output");
		StringBuilder txtSwift = new StringBuilder(WB.strEmpty);
		addHeader(txtSwift);
		addDetail(txtSwift);
		addFooter(txtSwift);

		WB.addLog(txtSwift.length(), "txtSwift.length()", "Out.SwiftOPV()");
		return txtSwift;
	}

	public static void getOut() throws Exception {// TOTHINK
		// origin - 19.10.2023, last edit - 27.06.2024
		StringBuilder textSwift = getSwiftOPV(null); 
		InOut currOut = new InOut();
		currOut.file = "swift_OPV.txt";
		currOut.path = dir + File.separator + currOut.file;
		Path pf = Paths.get(currOut.path);
		WB.addLog("getOut, currOut.outputPath=" + currOut.path, WB.strEmpty, "Output");
		WB.writeReplace(pf, textSwift.toString());
		WB.openFile(currOut.file);
	}

	public InOut() {// TOTHINK
		// origin - 04.12.2023, last edit - 14.06.2024
		path = dir + File.separator + file;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 27.06.2024
	}
}
