import java.time.OffsetDateTime;
import java.util.TreeSet;

public class Model {
	// origin - 26.09.2023, last edit - 13.06.2024
	public static TreeSet<String> standard;
	public static TreeSet<String> sectoral;
	public static TreeSet<String> custom;
	public String id;
	public OffsetDateTime date1;
	public String date2;
	public String code;
	public String description;
	public String more;
	public String shortDescription;
	public String fullDescription;
	public String shortName;
	public String fullName;
	public String abbreviation;//TOTHINK
	public String standardVal;//TOTHINK
	public String sectoralVal;//TOTHINK
	public String customVal;//TOTHINK
	
//	public static String getId(String id, Face store) throws Exception {
//		// origin - 14.02.2024, last edit - 01.06.2024
//		String res = Etc.fixTrim(id);
//		if (res.isEmpty()) {
//			try {
//				res = DateTool.formatter2(DateTool.getLocalDateTimeNow());
//				res = "[" + Abc.getInfoBaseId(WB.lastConnWork) + "]" + res;
//				res = res + "#";//number object in USA
//				res = res + Etc.getIntRnd(100000);
//
//			} catch (Exception ex) {
//				WB.addLog("Model.getId, ex=" + ex.getMessage(), "", "Model");
//			} finally {
//				Etc.doNothing();
//			}
//		}
//		WB.addLog2("Model.getId, res=" + res, "", "Model");
//		return res;
//	}
	
	public Model() {
		// origin - 08.11.2023, last edit - 05.12.2023
	}

	public String toString() {
		// origin - 27.09.2023, last edit - 14.01.2024
		String res = "";
		res = ModelDto.appender(res, ModelDto.formatter("id", this.id));
		res = ModelDto.appender(res, ModelDto.formatter("code", this.code));
		res = ModelDto.appender(res, ModelDto.formatter("date1", this.date2));
		res = ModelDto.appender(res, ModelDto.formatter("date2", this.date2));
		res = ModelDto.appender(res, ModelDto.formatter("code", this.code));
		res = ModelDto.appender(res, ModelDto.formatter("description", this.description));
		res = ModelDto.appender(res, ModelDto.formatter("more", this.more));
		res = "{" + res + "}";
		return res;
	}
	
	public static void test() throws Exception {
		// origin - 27.11.2023, last edit - 13.06.2024
//		for (int i = 0; i <= 10; i++) {
//			getId("", Face.root);
//		}
	}
}
