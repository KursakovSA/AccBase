import java.time.OffsetDateTime;
import java.util.Arrays;
import java.util.TreeSet;

public class Model {
	// origin - 26.09.2023, last edit - 06.07.2024
	public static TreeSet<String> standard;
	public static TreeSet<String> sectoral;
	public static TreeSet<String> custom;
	public String id;
	public OffsetDateTime date1;
	public String date2;
	public String code;
	public String description;
	public String more;
	public String shortDescription;
	public String fullDescription;
	public String shortName;
	public String fullName;
	public String abbreviation;// TOTHINK
	public String standardVal;// TOTHINK
	public String sectoralVal;// TOTHINK
	public String customVal;// TOTHINK

	static {
		try {
			sectoral = new TreeSet<String>(Arrays.asList(WB.strEmpty, WB.strEmpty, WB.strEmpty));
			custom = new TreeSet<String>(Arrays.asList(WB.strEmpty, WB.strEmpty, WB.strEmpty));
		} catch (Exception ex) {
			WB.addLog("Model.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Model");
		} finally {
			Etc.doNothing();
		}
	}

//	public static String getId(String id, Face store) throws Exception {
//		// origin - 14.02.2024, last edit - 27.06.2024
//		String res = Etc.fixTrim(id);
//		if (res.isEmpty()) {
//			try {
//				res = DateTool.formatter2(DateTool.getLocalDateTimeNow());
//				res = "[" + Abc.getInfoBaseId(WB.lastConnWork) + "]" + res;
//				res = res + "#";//number object in USA
//				res = res + Etc.getIntRnd(100000);
//
//			} catch (Exception ex) {
//				WB.addLog("Model.getId, ex=" + ex.getMessage(), WB.strEmpty, "Model");
//			} finally {
//				Etc.doNothing();
//			}
//		}
//		WB.addLog2("Model.getId, res=" + res, WB.strEmpty, "Model");
//		return res;
//	}

	public Model() throws Exception {
		// origin - 08.11.2023, last edit - 07.07.2024
		try {
		} catch (Exception ex) {
			WB.addLog("Model.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Meter");
		} finally {
			Etc.doNothing();
		}
	}

	public String toString() {
		// origin - 27.09.2023, last edit - 27.06.2024
		String res = WB.strEmpty;
		try {
			res = ModelDto.appender(res, ModelDto.formatter("id", this.id));
			res = ModelDto.appender(res, ModelDto.formatter("code", this.code));
			res = ModelDto.appender(res, ModelDto.formatter("date1", this.date2));
			res = ModelDto.appender(res, ModelDto.formatter("date2", this.date2));
			res = ModelDto.appender(res, ModelDto.formatter("code", this.code));
			res = ModelDto.appender(res, ModelDto.formatter("description", this.description));
			res = ModelDto.appender(res, ModelDto.formatter("more", this.more));
			res = "{" + res + "}";
		} catch (Exception ex) {
			res = WB.strEmpty;
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 27.11.2023, last edit - 06.07.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Model.test, ex=" + ex.getMessage(), WB.strEmpty, "Model");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Model.test end ", WB.strEmpty, "Model");
	}
}
