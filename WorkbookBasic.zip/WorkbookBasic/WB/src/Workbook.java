import java.time.LocalDate;

public class Workbook extends ModelDto {
	// origin - 28.09.2023, last edit - 19.11.2024
	public String docId, outsideDocId; // TODO //this is not dto.id
	// public String outsideDocId; //TODO //ex. [IB1][2024-09-27T06:56:36][#85021],

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Workbook.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Workbook");
		} finally {
			Etc.doNothing();
		}
	}

	public void fix() throws Exception {
		// origin - 29.12.2024, last edit - 01.01.2025
		try {
			super.fix();
			this.mark = DefVal.set(this.mark, Mark.DD);
			this.slice = DefVal.set(this.slice, Slice.Accounting);
		} catch (Exception ex) {
			WB.addLog("Workbook.fix, ex=" + ex.getMessage(), WB.strEmpty, "Workbook");
		} finally {
			Etc.doNothing();
		}
	}

	public static double getTurn(LocalDate date1, LocalDate date2, ModelDto filter) throws Exception {// TODO
		// origin - 18.10.2023, last edit - 10.01.2024
		// find turn Debt at period from date1 to date2
		// currContext may be equals -- "VAT.Sum", "VAT.Base.Sum", "VAT.Base.MaxLimit",
		// "IncomePersonTax.Dediction".... etc.
		double res = 0.0;
		// TODO - here need do get processRateVAT from WorkDatabase.sqlite3
		res = Etc.roundCustom(res);
		return res;
	}

	public static double getRest(LocalDate date1, LocalDate date2, ModelDto filter) throws Exception {// TODO
		// origin - 18.10.2023, last edit - 10.01.2024
		// find rest Debt on currDate
		// currContext may be equals -- "VAT.Sum", "VAT.Base.Sum", "VAT.Base.MaxLimit",
		// "IncomePersonTax.Dediction".... etc.
		double res = 0.0;
		// TODO - here need do get processRateVAT from WorkDatabase.sqlite3
		res = Etc.roundCustom(res);
		return res;
	}

	public Workbook(String Id) throws Exception {
		// origin - 05.12.2023, last edit - 29.12.2024
		this.clear();
		this.src = this.id = Id;
		this.isExist();// TOTHINK
		this.isValid();// TOTHINK
		this.fix();
	}

	public Workbook() throws Exception {
		// origin - 05.12.2023, last edit - 29.12.2024
		super();
		this.table = this.getClass().getName();
		this.fix();
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 16.09.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Workbook.test, ex=" + ex.getMessage(), WB.strEmpty, "Workbook");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Workbook.test end ", WB.strEmpty, "Workbook");
	}
}
