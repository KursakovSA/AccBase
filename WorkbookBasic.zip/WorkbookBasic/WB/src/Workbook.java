public class Workbook extends Model {
	// origin - 28.09.2023, last edit - 07.01.2024
	public static Workbook root;
	public Workbook parent;
	public Face face1;
	public Face face2;
	public Face face;
	public Slice slice;
	public Geo geo;
	public Model sign;
	public Account account;
	public Process process;
	public Asset asset;
	public Deal deal;
	public Model item;
	public Debt debt;
	public Price price;
	public Model role;
	public Model info;
	public Meter meter;
	public String meterValue;
	public Unit unit;
	public Mark mark;

	static {
		root = new Workbook("Workbook", "Workbook", "WorkbookData");
	}

	public static double getMeterValue(String fieldMeterValue) throws Exception {
		// origin - 07.01.2024, last edit - 07.01.2024
		double res = 0.0;
		fieldMeterValue = Etc.fixTrim(fieldMeterValue);
		fieldMeterValue = fieldMeterValue.replaceAll(" ", "");//del space, because spaces not need for double number
		try {
			if (fieldMeterValue.isEmpty() == false) {
				res = Double.parseDouble(fieldMeterValue);
			} else {
				res = 0.0;
			}
		} catch (Exception ex) {
			Logger.add("Workbook.getMeterValue, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "",
					"Workbook");
			res = 0.0;
		} finally {
			Etc.doNothing();
		}
		// Logger.add2("Workbook.getMeterValue, res=" + res + ", fieldMeterValue=" +
		// fieldMeterValue, "", "Workbook");
		return res;
	}

	public Workbook(String Id, String Code, String Description) {
		// origin - 05.12.2023, last edit - 05.12.2023
		this.id = Id;
		this.code = Code;
		this.description = Description;
	}

	public Workbook() {
		// origin - 05.12.2023, last edit - 05.12.2023
	}

	public static void test() {
		// origin - 28.10.2023, last edit - 07.01.2024

		// getMeterValue
		for (String testArg1 : new String[] { "17420", "17 420", "17420.0", "17420.00", "17420,00", "17 420.00",
				"-17420", "17420 - 18560" }) {
			try {
				Logger.add("Workbook.test.getMeterValue, res=" + getMeterValue(testArg1) + ", testArg1=" + testArg1, "",
						"Workbook");
			} catch (Exception ex) {
				Logger.add("Workbook.test.getMeterValue, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(),
						"", "Workbook");
			} finally {
				Etc.doNothing();
			}
		}
	}
}
