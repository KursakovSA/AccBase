public class Workbook extends Model {
	// origin - 28.09.2023, last edit - 06.12.2023
	public static Workbook root;
	public Workbook parent;
	public Face face1;
    public Face face2;
    public Face face;
    public Slice slice;
    public Geo geo;
    public Model sign;
    public Account account;
    public Process process;
    public Asset asset;
    public Deal deal;
    public Model item;
    public Debt debt;
    public Price price;
    public Model role;
    public Model info;
    public Meter meter;
    public String meterValue;
    public Unit unit;
    public Mark mark;
    
    static {
		root = new Workbook("Workbook","Workbook","WorkbookData");
	}
    
    public Workbook(String Id, String Code, String Description) {
		// origin - 05.12.2023, last edit - 05.12.2023
		this.id = Id;
		this.code = Code;
		this.description = Description;
	}
    
    public Workbook() {
		// origin - 05.12.2023, last edit - 05.12.2023
	}
    
    public static void test() {
		// origin - 28.10.2023, last edit - 05.12.2023
    	Logger.add("Workbook.test, Workbook.root=" + Workbook.root, "", "Workbook");
	}
}
