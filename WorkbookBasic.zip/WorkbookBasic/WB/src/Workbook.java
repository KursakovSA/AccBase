import java.time.LocalDate;
import java.util.List;

public class Workbook extends Model {
	// origin - 28.09.2023, last edit - 25.01.2024
	public static Workbook root;
	public Workbook parent;
	public Face face1;
	public Face face2;
	public Face face;
	public Slice slice;
	public Geo geo;
	public Model sign;
	public Account account;
	public Process process;
	public Asset asset;
	public Deal deal;
	public Model item;
	public Debt debt;
	public Price price;
	public Model role;
	public Model info;
	public Meter meter;
	public String meterValue;
	public Unit unit;
	public Mark mark;

	static {
		root = new Workbook("Workbook", "Workbook", "WorkbookData");
	}

	public static double getTurn(LocalDate date1, LocalDate date2, ModelDto filter) {// TODO
		// origin - 18.10.2023, last edit - 10.01.2024
		// find turn Debt at period from date1 to date2
		// currContext may be equals -- "VAT.Sum", "VAT.Base.Sum", "VAT.Base.MaxLimit",
		// "IncomePersonTax.Dediction".... etc.
		double res = 0.0;
		// TODO - here need do get processRateVAT from WorkDatabase.sqlite3
		res = Etc.roundCustom(res);
		return res;
	}

	public static double getRest(LocalDate date1, LocalDate date2, ModelDto filter) {// TODO
		// origin - 18.10.2023, last edit - 10.01.2024
		// find rest Debt on currDate
		// currContext may be equals -- "VAT.Sum", "VAT.Base.Sum", "VAT.Base.MaxLimit",
		// "IncomePersonTax.Dediction".... etc.
		double res = 0.0;
		// TODO - here need do get processRateVAT from WorkDatabase.sqlite3
		res = Etc.roundCustom(res);
		return res;
	}

//	public static String getChronoMeterValueString(LocalDate calcDate, List<ModelDto> subsetGlobalBasic)
//			throws Exception {
//		// origin - 22.01.2024, last edit - 25.01.2024
//		String res = "";
//		LocalDate currDate1;
//		LocalDate currDate2;
////		WB.addLog2("Workbook.getChronoMeterValueString, subsetGlobalBasic.size=" + subsetGlobalBasic.size() + ", calcDate=" +
////				calcDate, "", "Workbook");
//		try {
//			for (var currSubset : subsetGlobalBasic) {
////				WB.addLog2("Workbook.getChronoMeterValueString, currSubset=" + currSubset + ", calcDate=" +
////						calcDate, "", "Workbook");
//				currDate1 = DateCalendar.getLocalDate(currSubset.date1);// left border in data
//				currDate2 = DateCalendar.getLocalDate(currSubset.date2);// right border in data
//
//				if (currDate1.isAfter(calcDate)) {
//					continue;
//				}
//
//				if (currDate1.isBefore(calcDate)) {// because for curr year may be not be actual data
//					res = getMeterValueString(currSubset.meterValue);
//				}
//
//				if (currDate1 == calcDate) {// left border hit
//					res = getMeterValueString(currSubset.meterValue);
//					break;
//				}
//				if (currDate2 == calcDate) {// right border hit
//					res = getMeterValueString(currSubset.meterValue);
//					break;
//				}
//
//				if (currDate1.isBefore(calcDate)) {// range from left border to right border hit
//					if (currDate2.isAfter(calcDate)) {
//						res = getMeterValueString(currSubset.meterValue);
//						break;
//					}
//				}
//			}
//		} catch (Exception ex) {
//			WB.addLog(
//					"Workbook.getChronoMeterValueString, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(),
//					"", "Workbook");
//			res = "";
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("Workbook.getChronoMeterValueString, res=" + res + ", calcDate=" +
//		// calcDate, "", "Workbook");
//		return res;
//	}

	public static double getChronoMeterValueDouble(LocalDate calcDate, List<ModelDto> subsetGlobalBasic)
			throws Exception {
		// origin - 09.01.2024, last edit - 22.01.2024
		double res = 0.0;
		LocalDate currDate1;
		LocalDate currDate2;
		try {
			for (var currSubset : subsetGlobalBasic) {
				currDate1 = DateCalendar.getLocalDate(currSubset.date1);// left border in data
				currDate2 = DateCalendar.getLocalDate(currSubset.date2);// right border in data

				if (currDate1.isAfter(calcDate)) {
					continue;
				}

				if (currDate1.isBefore(calcDate)) {// because for curr year may be not be actual data
					res = getMeterValueDouble(currSubset.meterValue);
				}

				if (currDate1 == calcDate) {// left border hit
					res = getMeterValueDouble(currSubset.meterValue);
					break;
				}
				if (currDate2 == calcDate) {// right border hit
					res = getMeterValueDouble(currSubset.meterValue);
					break;
				}

				if (currDate1.isBefore(calcDate)) {// range from left border to right border hit
					if (currDate2.isAfter(calcDate)) {
						res = getMeterValueDouble(currSubset.meterValue);
						break;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog(
					"Workbook.getChronoMeterValueDouble, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(),
					"", "Workbook");
			res = 0.0;
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Workbook.getChronoMeterValueDouble, res=" + res + ", calcDate=" +
		// calcDate, "", "Workbook");
		return res;
	}

	public static String getMeterValueString(String fieldMeterValue) throws Exception {
		// origin - 21.01.2024, last edit - 22.01.2024
		String res = "";
		res = Etc.fixString(fieldMeterValue);
		// WB.addLog2("Workbook.getMeterValueString, res=" + res + ", fieldMeterValue="
		// + fieldMeterValue, "", "Workbook");
		return res;
	}

	public static double getMeterValueDouble(String fieldMeterValue) throws Exception {
		// origin - 07.01.2024, last edit - 21.01.2024
		double res = 0.0;
		fieldMeterValue = Etc.fixDouble(fieldMeterValue);
		try {
			if (fieldMeterValue.isEmpty() == false) {
				res = Double.parseDouble(fieldMeterValue);
			} else {
				res = 0.0;
			}
		} catch (Exception ex) {
			WB.addLog("Workbook.getMeterValueDouble, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "",
					"Workbook");
			res = 0.0;
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Workbook.getMeterValueDouble, res=" + res + ", fieldMeterValue="
		// +
		// fieldMeterValue, "", "Workbook");
		return res;
	}

	public Workbook(String Id, String Code, String Description) {
		// origin - 05.12.2023, last edit - 05.12.2023
		this.id = Id;
		this.code = Code;
		this.description = Description;
	}

	public Workbook() {
		// origin - 05.12.2023, last edit - 05.12.2023
	}

	public static void test() {
		// origin - 28.10.2023, last edit - 18.01.2024

		// getMeterValue
		for (String testArg1 : new String[] { "17420", "17 420", "17420.0", "17420.00", "17420,0", "17420,00",
				"17420,000", "17420,0000", "17 420.00", "-17420", "17420 - 18560", "34.152562", "34,152562",
				"34,153,600.2", "34 153 600.2", "34153600.2" }) {
			try {
				WB.addLog2(
						"Workbook.test.getMeterValue, res=" + getMeterValueDouble(testArg1) + ", testArg1=" + testArg1,
						"", "Workbook");
			} catch (Exception ex) {
				WB.addLog("Workbook.test.getMeterValue, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(),
						"", "Workbook");
			} finally {
				Etc.doNothing();
			}
		}
	}
}
