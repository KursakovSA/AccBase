import java.time.LocalDate;

public class Workbook extends Model {
	// origin - 28.09.2023, last edit - 15.07.2024
	public Workbook parent;
	public Face face1;
	public Face face2;
	public Face face;
	public Slice slice;
	public Geo geo;
	public Model sign;
	public Account account;
	public Process process;
	public Asset asset;
	public Deal deal;
	public Model item;
	public Debt debt;
	public Price price;
	public Model role;
	public Model info;
	public Meter meter;
	public String meterValue;
	public Unit unit;
	public Mark mark;

	public static double getTurn(LocalDate date1, LocalDate date2, ModelDto filter) throws Exception {// TODO
		// origin - 18.10.2023, last edit - 10.01.2024
		// find turn Debt at period from date1 to date2
		// currContext may be equals -- "VAT.Sum", "VAT.Base.Sum", "VAT.Base.MaxLimit",
		// "IncomePersonTax.Dediction".... etc.
		double res = 0.0;
		// TODO - here need do get processRateVAT from WorkDatabase.sqlite3
		res = Etc.roundCustom(res);
		return res;
	}

	public static double getRest(LocalDate date1, LocalDate date2, ModelDto filter) throws Exception {// TODO
		// origin - 18.10.2023, last edit - 10.01.2024
		// find rest Debt on currDate
		// currContext may be equals -- "VAT.Sum", "VAT.Base.Sum", "VAT.Base.MaxLimit",
		// "IncomePersonTax.Dediction".... etc.
		double res = 0.0;
		// TODO - here need do get processRateVAT from WorkDatabase.sqlite3
		res = Etc.roundCustom(res);
		return res;
	}

//	public static String getChronoMeterValueString(LocalDate calcDate, List<ModelDto> subsetGlobalBasic)
//			throws Exception {
//		// origin - 22.01.2024, last edit - 27.06.2024
//		String res = WB.strEmpty;
//		LocalDate currDate1;
//		LocalDate currDate2;
////		WB.addLog2("Workbook.getChronoMeterValueString, subsetGlobalBasic.size=" + subsetGlobalBasic.size() + ", calcDate=" +
////				calcDate, WB.strEmpty, "Workbook");
//		try {
//			for (var currSubset : subsetGlobalBasic) {
////				WB.addLog2("Workbook.getChronoMeterValueString, currSubset=" + currSubset + ", calcDate=" +
////						calcDate, WB.strEmpty, "Workbook");
//				currDate1 = DateCalendar.getLocalDate(currSubset.date1);// left border in data
//				currDate2 = DateCalendar.getLocalDate(currSubset.date2);// right border in data
//
//				if (currDate1.isAfter(calcDate)) {
//					continue;
//				}
//
//				if (currDate1.isBefore(calcDate)) {// because for curr year may be not be actual data
//					res = getMeterValueString(currSubset.meterValue);
//				}
//
//				if (currDate1 == calcDate) {// left border hit
//					res = getMeterValueString(currSubset.meterValue);
//					break;
//				}
//				if (currDate2 == calcDate) {// right border hit
//					res = getMeterValueString(currSubset.meterValue);
//					break;
//				}
//
//				if (currDate1.isBefore(calcDate)) {// range from left border to right border hit
//					if (currDate2.isAfter(calcDate)) {
//						res = getMeterValueString(currSubset.meterValue);
//						break;
//					}
//				}
//			}
//		} catch (Exception ex) {
//			WB.addLog(
//					"Workbook.getChronoMeterValueString, ex=" + ex.getMessage(), WB.strEmpty, "Workbook");
//			res = WB.strEmpty;
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("Workbook.getChronoMeterValueString, res=" + res + ", calcDate=" +
//		// calcDate, WB.strEmpty, "Workbook");
//		return res;
//	}

//	public static String getString(String initValue) throws Exception {
//		// origin - 21.01.2024, last edit - 11.07.2024
//		String res = WB.strEmpty;
//		res = Etc.fixString(initValue);
//		// WB.addLog2("Workbook.getString, res=" + res + ", initValue="
//		// + fieldMeterValue, WB.strEmpty, "Workbook");
//		return res;
//	}

	public Workbook(String Id, String Code, String Description) throws Exception {
		// origin - 05.12.2023, last edit - 05.07.2024
		try {
			this.id = Id;
			this.code = Code;
			this.description = Description;
		} catch (Exception ex) {
			WB.addLog("Workbook(String Id, String Code, String Description).ctor, ex=" + ex.getMessage(), WB.strEmpty,
					"Workbook");
		} finally {
			Etc.doNothing();
		}
	}

	public Workbook() throws Exception {
		// origin - 05.12.2023, last edit - 07.07.2024
		try {
		} catch (Exception ex) {
			WB.addLog("Workbook.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Workbook");
		} finally {
			Etc.doNothing();
		}
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 15.07.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Workbook.test, ex=" + ex.getMessage(), WB.strEmpty, "Workbook");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Workbook.test end ", WB.strEmpty, "Workbook");
	}
}
