import java.time.LocalDate;

public class Workbook extends ModelDto {
	// origin - 28.09.2023, last edit - 04.08.2024

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Workbook.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Workbook");
		} finally {
			Etc.doNothing();
		}
	}

	public static double getTurn(LocalDate date1, LocalDate date2, ModelDto filter) throws Exception {// TODO
		// origin - 18.10.2023, last edit - 10.01.2024
		// find turn Debt at period from date1 to date2
		// currContext may be equals -- "VAT.Sum", "VAT.Base.Sum", "VAT.Base.MaxLimit",
		// "IncomePersonTax.Dediction".... etc.
		double res = 0.0;
		// TODO - here need do get processRateVAT from WorkDatabase.sqlite3
		res = Etc.roundCustom(res);
		return res;
	}

	public static double getRest(LocalDate date1, LocalDate date2, ModelDto filter) throws Exception {// TODO
		// origin - 18.10.2023, last edit - 10.01.2024
		// find rest Debt on currDate
		// currContext may be equals -- "VAT.Sum", "VAT.Base.Sum", "VAT.Base.MaxLimit",
		// "IncomePersonTax.Dediction".... etc.
		double res = 0.0;
		// TODO - here need do get processRateVAT from WorkDatabase.sqlite3
		res = Etc.roundCustom(res);
		return res;
	}

	public Workbook(String Id, String Code, String Description) throws Exception {
		// origin - 05.12.2023, last edit - 04.08.2024
		super(Id, Code, Description);
	}

	public Workbook() throws Exception {
		// origin - 05.12.2023, last edit - 04.08.2024
		super();
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 15.07.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Workbook.test, ex=" + ex.getMessage(), WB.strEmpty, "Workbook");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Workbook.test end ", WB.strEmpty, "Workbook");
	}
}
