public class Movement extends ModelDto {
	// origin - 06.10.2023, last edit - 31.10.2024

	public String consignee; // TODO

	public Movement() throws Exception { // TODO
		// origin - 06.10.2024, last edit - 06.10.2024
		super();
	}

	public static void test() throws Exception { // TODO
		// origin - 06.10.2024, last edit - 31.10.2024
		try {

//			// ctor ("date1", "date2") different variants
//			Deal newDeal1 = new Deal(WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					"2024-09-01", "2024-09-11", WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					WB.strEmpty);
//			WB.addLog2("Deal.test.ctor(dto), newDeal1=" + newDeal1, WB.strEmpty, "Deal");
//			Deal newDeal2 = new Deal(WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					"2024-09-01;2024-09-06", "2024-09-11;2024-09-16", WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					WB.strEmpty, WB.strEmpty, WB.strEmpty);
//			WB.addLog2("Deal.test.ctor(dto), newDeal2=" + newDeal2, WB.strEmpty, "Deal");
//			Deal newDeal3 = new Deal(WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					"2024-09-01;2024-09-06;", "2024-09-11;2024-09-16;", WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					WB.strEmpty, WB.strEmpty, WB.strEmpty);
//			WB.addLog2("Deal.test.ctor(dto), newDeal3=" + newDeal3, WB.strEmpty, "Deal");
//			// test correctByDuration
//			Deal newDeal4 = new Deal(WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					"2024-09-01", "2024-09-11;2025-09-16;", WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					WB.strEmpty, WB.strEmpty);
//			WB.addLog2("Deal.test.ctor(dto), newDeal4=" + newDeal4, WB.strEmpty, "Deal");

		} catch (Exception ex) {
			WB.addLog("Movement.test, ex=" + ex.getMessage(), WB.strEmpty, "Movement");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Movement.test end ", WB.strEmpty, "Movement");
	}

}