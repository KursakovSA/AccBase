public class Movement extends ModelDto {
	// origin - 06.10.2023, last edit - 20.03.2025

	public String consignee; // TODO

	public Movement() throws Exception { // TODO
		// origin - 06.10.2024, last edit - 06.10.2024
		super();
	}

	public static void test() throws Exception { // TODO
		// origin - 06.10.2024, last edit - 05.03.2025
		try {

		} catch (Exception ex) {
			WB.addLog("Movement.test, ex=" + ex.getMessage(), "", "Movement");
		}
	}

}