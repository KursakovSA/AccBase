import java.awt.Desktop;
import java.io.File;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

import javax.swing.JOptionPane;

public class Command {
	// origin - 13.12.2023, last edit - 08.06.2024
	
	public static void cleanFolderProgram() throws Exception {
		// origin - 30.05.2024, last edit - 08.06.2024
		TreeSet<String> fileToDel = new TreeSet<String>();
		try {
			fileToDel.add(WB.eventLogPath);
			for (var currFileToDel : fileToDel) {
				WB.addLog2("Command.cleanFolderProgram, currFileToDel=" + currFileToDel, "", "Command");
				InOut.delFile(Paths.get(currFileToDel).toFile());
			}
			
//			String patternInOut = Conn.outputDbPattern;
//			String patternTo = Conn.toAllPattern;
//			InOut.getDelFile(WB.inputOutputDir, patternInOut, patternTo);
			
		} catch (Exception ex) {
			WB.addLog("Command.cleanFolderProgram, ex=" + ex.getMessage(), "", "DAL");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("Command.cleanFolderProgram, patternInOut=" + patternInOut + ", patternTo=" + patternTo, "",
//				"Command");
	}
	
	public static void cleanInputOutput(String patternInOut, String patternTo) throws Exception {
		// origin - 29.05.2024, last edit - 29.05.2024
		InOut.getDelFile(WB.inputOutputDir, patternInOut, patternTo);
//		WB.addLog2("Command.cleanInputOutput, patternInOut=" + patternInOut + ", patternTo=" + patternTo, "",
//				"Command");
	}

	public static void replaceInto(TreeSet<String> setConn) throws Exception {
		// origin - 24.05.2024, last edit - 24.05.2024
		WB.getLocalStart();
		List<ModelDto> updateDto = new ArrayList<ModelDto>();
		updateDto = ModelDto.getTestSubset();
		DAL.getReplaceInto(setConn, updateDto);
		WB.getLocalEnd("Command.replaceInto, updateDto.size=" + updateDto.size() + ", setConn=" + setConn);
	}

	public static void openUserManualLocal() throws Exception {
		// origin - 23.05.2023, last edit - 06.06.2024
		String userManualLocalNameFile = "";
		String pathFileToOpen = "";
		Conn.getLocal(WB.localDir); // reread DatabaseLocal
		Abc abcLocal = WB.abcLocal;

		for (var currUserManualLocal : abcLocal.userManualLocal) {
			userManualLocalNameFile = Etc.fixTrim(currUserManualLocal.description.toString());
			pathFileToOpen = getFileToExtFile(userManualLocalNameFile);

			try {
				Desktop.getDesktop().open(new File(pathFileToOpen));
				//java.lang.Process process = Runtime.getRuntime().exec(pathFileToOpen.toString());
			} catch (Exception ex) {
				System.out.println("WB.openFile, ex=" + ex.getMessage() + ", pathFile=" + pathFileToOpen);
			} finally {
				Etc.doNothing();
			}

			// WB.addLog2("Command.openUserManualLocal, currUserManualLocal=" +
			// currUserManualLocal + ", Id=" + currUserManualLocal.id, "", "Command");
		}
	}

	public static void getLastRecord(TreeSet<String> setConn) throws Exception {
		// origin - 31.12.2023, last edit - 05.06.2024
		WB.getLocalStart();
		TreeSet<String> resConn = Conn.getSetOrDefault(setConn);
		List<ModelDto> dtoLast = new ArrayList<ModelDto>();
		for (var currConn : resConn) {
			dtoLast = DAL.getTable(currConn, Qry.getWorkbookLastRecord());
			WB.addLog2("Command.getLastRecord, dtoLast.size=" + dtoLast.size() + ", currConn=" + currConn, "", "Command");
			WB.getLocalEnd("Command.getLastRecord" + ", " + currConn);
		}
	}

	public static void updateBases(TreeSet<String> setConn) throws Exception {
		// origin - 24.12.2023, last edit - 04.06.2024
		WB.getLocalStart();
		setConn = Conn.getSetOrDefault(setConn);
		List<ModelDto> updateDto = new ArrayList<ModelDto>();
		updateDto = WB.abcTemplate.update;
		DAL.getReplaceInto(setConn, updateDto);
		WB.getLocalEnd("Command.updateBases, updateDto.size=" + updateDto.size() + ", setConn=" + setConn);
	}

	public static void updateExtFiles() throws Exception {
		// origin - 24.12.2023, last edit - 29.05.2024
		WB.getLocalStart();
		String sourceExtFile = "";
		String fileTo = "";
		Conn.getLocal(WB.localDir); // reread DatabaseLocal
		Abc abcLocal = WB.abcLocal;

		for (var currLocal : abcLocal.sourceExtFile) {
			sourceExtFile = currLocal.description.toString();// TODO ??? or take currLocal.code ???
			fileTo = getFileToExtFile(sourceExtFile);
			Conn.copyExtFile(sourceExtFile, fileTo);

			// if find new DatabaseLocal file
			if (Conn.isDbNameContainsStr(Etc.getFileName(sourceExtFile), Conn.localDbPattern)) {
				// reread DatabaseLocal
				Conn.getLocal(WB.localDir);
			}

			//WB.addLog2("Command.updateExtFiles, sourceExtFile=" + sourceExtFile + ", Id=" + currLocal.id, "", "Command");
		}
		WB.getLocalEnd("Command.updateExtFiles" + ", " + abcLocal.local.size());
	}

	private static String getFileToExtFile(String sourceExtFile) throws Exception {
		// origin - 01.01.2024, last edit - 07.01.2024
		String res = WB.commonDocDir + File.separator + Etc.getFileName(sourceExtFile);
		String destinationExtFile = "";

		// if find new DatabaseLocal file
		if (Conn.isDbNameContainsStr(Etc.getFileName(sourceExtFile), Conn.localDbPattern)) {
			destinationExtFile = Etc.getFileName(sourceExtFile).replace(Conn.localDbPattern,
					Conn.localDbPattern + "_" + DateTool.getLabelDateTimeForFileName());
			res = WB.localDir + File.separator + destinationExtFile;
		}

		return res;
	}

	public static void vacuum(TreeSet<String> setConn) throws Exception {
		// origin - 19.12.2023, last edit - 04.06.2024
		WB.getLocalStart();
		setConn = Conn.getSetOrDefault(setConn);
		DAL.getVacuum(setConn);
		WB.getLocalEnd("Command.vacuum for setConn.size=" + setConn.size() + ", setConn=" + setConn);
	}

	public static void reindex(TreeSet<String> setConn) throws Exception {
		// origin - 19.12.2023, last edit - 04.06.2024
		WB.getLocalStart();
		setConn = Conn.getSetOrDefault(setConn);
		DAL.getReindex(setConn);
		WB.getLocalEnd("Command.reindex for setConn.size=" + setConn.size() + ", setConn=" + setConn);
	}

	public static void integrityCheck(TreeSet<String> setConn) throws Exception {
		// origin - 19.12.2023, last edit - 04.06.2024
		WB.getLocalStart();
		setConn = Conn.getSetOrDefault(setConn);
		DAL.getIntegrityCheck(setConn);
		WB.getLocalEnd("Command.integrityCheck for setConn.size=" + setConn.size() + ", setConn=" + setConn);
	}
	
	public static void input(TreeSet<String> setConnFrom, TreeSet<String> setConnTo, String patternInOut,
			String patternTo) throws Exception {
		// origin - 28.05.2024, last edit - 05.06.2024
		WB.getLocalStart();
		List<ModelDto> dtoInput = new ArrayList<ModelDto>();
		dtoInput = DAL.setByTemplate(setConnFrom, "");
		DAL.getReplaceInto(setConnTo, dtoInput);
		WB.getLocalEnd("Command.input for setConnFrom.size=" + setConnFrom.size());
		WB.addLog2(
				"Command.input, setConnFrom.size=" + setConnFrom.size() + ", dtoInput.size=" + dtoInput.size()
						+ ", setConnTo=" + setConnTo + ", patternInOut=" + patternInOut + ", patternTo=" + patternTo,
				"", "Command");
	}

	public static void outputBackup(TreeSet<String> setConn) throws Exception {
		// origin - 28.05.2024, last edit - 04.06.2024
		WB.getLocalStart();
		setConn = Conn.getSetOrDefault(setConn);
		DAL.getOutputBackup(setConn);
		WB.getLocalEnd("Command.outputBackup for setConn.size=" + setConn.size() + ", setConn=" + setConn);
	}

	public static void backup(TreeSet<String> setConn) throws Exception {
		// origin - 18.12.2023, last edit - 04.06.2024
		WB.getLocalStart();
		setConn = Conn.getSetOrDefault(setConn);
		DAL.getBackup(setConn);
		WB.getLocalEnd("Command.backup for setConn.size=" + setConn.size() + ", setConn=" + setConn);
	}

	public static void exit() throws Exception {
		// origin - 11.12.2023, last edit - 18.01.2024
		int selection = JOptionPane.showConfirmDialog(WB.frameBasic, "Do you want to leave the program ?",
				"Exit question", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		if (selection == JOptionPane.OK_OPTION) {
			WB.addLog2("Command.exit", "", "Command");
			WB.getFinish();
			System.exit(0);
		}
	}

	public static void test() throws Exception {
		// origin - 28.05.2024, last edit - 28.05.2024
	}
}
