import java.awt.Desktop;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

import javax.swing.JOptionPane;

public class Command {
	// origin - 13.12.2023, last edit - 24.05.2024
	
	public static void replaceInto(TreeSet<String> setConn) throws Exception {
		// origin - 24.05.2024, last edit - 24.05.2024
		WB.getLocalStart();
		List<ModelDto> updateDto = new ArrayList<ModelDto>();
		updateDto = ModelDto.getTestSubset();
		DAL.getReplaceInto(setConn, updateDto);
		WB.getLocalEnd("Command.replaceInto, updateDto.size=" + updateDto.size()+", setConn="+setConn);
	}
	
	public static void openUserManualLocal() throws Exception {
		// origin - 23.05.2023, last edit - 23.05.2024
		String userManualLocalNameFile = "";
		String pathFileToOpen = "";
		Conn.getLocal(WB.localDir); // reread DatabaseLocal
		Abc abcLocal = WB.abcLocal;

		for (var currUserManualLocal : abcLocal.userManualLocal) {
			userManualLocalNameFile = Etc.fixTrim(currUserManualLocal.description.toString());
			pathFileToOpen = getFileToExtFile(userManualLocalNameFile);
			
			try {
				Desktop.getDesktop().open(new File(pathFileToOpen));
			} catch (Exception ex) {
				System.out.println("WB.openFile, ex=" + ex.getMessage() + ", pathFile=" + pathFileToOpen);
			} finally {
				Etc.doNothing();
			}

			//WB.addLog2("Command.openUserManualLocal, currUserManualLocal=" + currUserManualLocal + ", Id=" + currUserManualLocal.id, "", "Command");
		}
	}

	public static void getLastRecord(TreeSet<String> setConn) throws Exception {
		// origin - 31.12.2023, last edit - 20.05.2024
		WB.getLocalStart();
		TreeSet<String> resConn = getSetConnOrDefault(setConn);
		System.out.println("Command.getLastRecord, resConn.cardinality=" +resConn.size());
		for (var currConn : resConn) {
			DAL.getTable(currConn, Qry.getWorkbookLastRecord());
			WB.getLocalEnd("Command.getLastRecord" + ", " + currConn);
		}
	}
	
	public static void updateBases(TreeSet<String> setConn) throws Exception {
		// origin - 24.12.2023, last edit - 12.02.2024
		WB.getLocalStart();
		setConn = getSetConnOrDefault(setConn);
		List<ModelDto> updateDto = new ArrayList<ModelDto>();
		updateDto = WB.abcTemplate.update;
		DAL.getReplaceInto(setConn, updateDto);
		WB.getLocalEnd("Command.updateBases, updateDto.size=" + updateDto.size()+", setConn="+setConn);
	}

	public static void updateExtFiles() throws Exception {
		// origin - 24.12.2023, last edit - 16.02.2024
		WB.getLocalStart();
		String sourceExtFile = "";
		String fileTo = "";
		Conn.getLocal(WB.localDir); // reread DatabaseLocal
		Abc abcLocal = WB.abcLocal;

		for (var currLocal : abcLocal.sourceExtFile) {
			sourceExtFile = currLocal.description.toString();// TODO ??? or take currLocal.code ???
			fileTo = getFileToExtFile(sourceExtFile);
			Conn.copyExtFile(sourceExtFile, fileTo);

			// if find new DatabaseLocal file
			if (Conn.isDbType(Etc.getFileName(sourceExtFile), Conn.localDbPattern)) {
				// reread DatabaseLocal
				Conn.getLocal(WB.localDir);
			}

			WB.addLog("Command.updateExtFiles, sourceExtFile=" + sourceExtFile + ", Id=" + currLocal.id, "", "Command");
		}
		WB.getLocalEnd("Command.updateExtFiles" + ", " + abcLocal.local.size());
	}

	private static String getFileToExtFile(String sourceExtFile) throws Exception {
		// origin - 01.01.2024, last edit - 07.01.2024
		String res = WB.commonDocDir + File.separator + Etc.getFileName(sourceExtFile);
		String destinationExtFile = "";

		// if find new DatabaseLocal file
		if (Conn.isDbType(Etc.getFileName(sourceExtFile), Conn.localDbPattern)) {
			destinationExtFile = Etc.getFileName(sourceExtFile).replace(Conn.localDbPattern,
					Conn.localDbPattern + "_" + DateTool.getLabelDateTimeForFileName());
			res = WB.localDir + File.separator + destinationExtFile;
		}

		return res;
	}

	public static void vacuum(TreeSet<String> setConn) throws Exception {
		// origin - 19.12.2023, last edit - 14.02.2024
		WB.getLocalStart();
		setConn = getSetConnOrDefault(setConn);
		DAL.getVacuum(setConn);
		WB.getLocalEnd("Command.vacuum for setConn.size=" + setConn.size() + ", setConn=" + setConn);
	}

	public static void reindex(TreeSet<String> setConn) throws Exception {
		// origin - 19.12.2023, last edit - 14.02.2024
		WB.getLocalStart();
		setConn = getSetConnOrDefault(setConn);
		DAL.getReindex(setConn);
		WB.getLocalEnd("Command.reindex for setConn.size=" + setConn.size()+", setConn="+setConn);
	}

	public static void integrityCheck(TreeSet<String> setConn) throws Exception {
		// origin - 19.12.2023, last edit - 14.02.2024
		WB.getLocalStart();
		setConn = getSetConnOrDefault(setConn);
		DAL.getIntegrityCheck(setConn);
		WB.getLocalEnd("Command.integrityCheck for setConn.size=" + setConn.size()+", setConn="+setConn);
	}

	public static void backup(TreeSet<String> setConn) throws Exception {
		// origin - 18.12.2023, last edit - 14.02.2024
		WB.getLocalStart();
		setConn = getSetConnOrDefault(setConn);
		DAL.getBackup(setConn);
		WB.getLocalEnd("Command.backup for setConn.size=" + setConn.size()+", setConn="+setConn);
	}

	private static TreeSet<String> getSetConnOrDefault(TreeSet<String> setConn) {
		// origin - 12.02.2024, last edit - 20.05.2024
		TreeSet<String> res = new TreeSet<String>();
		// if (res.isEmpty()) {
		if (setConn.size() == 0) {
			res = Conn.work;
		} else {
			res = setConn;
		}
		WB.addLog("Command.getSetConnOrDefault, res=" + res, "", "Command");
		return setConn;
	}

	public static void exit() throws Exception {
		// origin - 11.12.2023, last edit - 18.01.2024
		int selection = JOptionPane.showConfirmDialog(WB.frameBasic, "Do you want to leave the program ?",
				"Exit question", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		if (selection == JOptionPane.OK_OPTION) {
			WB.addLog2("Command.exit", "", "Command");
			WB.getFinish();
			System.exit(0);
		}
	}
}
