import java.io.File;
import javax.swing.JOptionPane;

public class Command {
	// origin - 13.12.2023, last edit - 18.01.2024

	public static void testLastRecord(String conn) throws Exception {
		// origin - 31.12.2023, last edit - 18.01.2024
		WB.getLocalStart();
		DAL.getTable(conn, Qry.getWorkbookLastRecord());
		WB.getLocalEnd("Command.testLastRecord" + ", " + conn);
	}

	public static void updateExtFile() throws Exception {
		// origin - 24.12.2023, last edit - 18.01.2024
		WB.getLocalStart();
		String sourceExtFile = "";
		String fileTo = "";

		for (var currLocal : WB.abcLocal.sourceExtFile) {
			sourceExtFile = currLocal.description.toString();// TODO ??? or take currLocal.code ???
			fileTo = getFileToExtFile(sourceExtFile);
			Conn.copyExtFile(sourceExtFile, fileTo);
			
			//if find new DatabaseLocal file
			if (Conn.isDbType(Etc.getFileName(sourceExtFile), Conn.localDbPattern)) {
				//reinstallation DatabaseLocal
				Conn.getLocal(WB.localDir);
			}
			
			WB.addLog("Command.updateExtFile, sourceExtFile=" + sourceExtFile + ", Id=" + currLocal.id, "", "Command");
		}
		WB.getLocalEnd("Command.updateExtFile" + ", " + WB.abcLocal.local.size());
	}

	private static String getFileToExtFile(String sourceExtFile) throws Exception {
		// origin - 01.01.2024, last edit - 07.01.2024
		String res = WB.docDir + File.separator + Etc.getFileName(sourceExtFile);
		String destinationExtFile = "";

		// if find new DatabaseLocal file
		if (Conn.isDbType(Etc.getFileName(sourceExtFile), Conn.localDbPattern)) {
			destinationExtFile = Etc.getFileName(sourceExtFile).replace(Conn.localDbPattern,
					Conn.localDbPattern + "_" + DateCalendar.getLabelDateTimeForFileName());
			res = WB.localDir + File.separator + destinationExtFile;
		}

		return res;
	}

	public static void vacuum(String conn) throws Exception {
		// origin - 19.12.2023, last edit - 18.01.2024
		WB.getLocalStart();
		DAL.getVacuum(conn);
		WB.getLocalEnd("Command.vacuum" + ", " + conn);
	}

	public static void reindex(String conn) throws Exception {
		// origin - 19.12.2023, last edit - 18.01.2024
		WB.getLocalStart();
		DAL.getReindex(conn);
		WB.getLocalEnd("Command.reindex" + ", " + conn);
	}

	public static void integrityCheck(String conn) throws Exception {
		// origin - 19.12.2023, last edit - 18.01.2024
		WB.getLocalStart();
		DAL.getIntegrityCheck(conn);
		WB.getLocalEnd("Command.integrityCheck" + ", " + conn);
	}

	public static void backupConn(String conn) throws Exception {
		// origin - 18.12.2023, last edit - 18.01.2024
		WB.getLocalStart();
		DAL.getBackup(conn);
		WB.getLocalEnd("Command.backupConn" + ", " + conn);
	}

	public static void exit() throws Exception {
		// origin - 11.12.2023, last edit - 18.01.2024
		int selection = JOptionPane.showConfirmDialog(WB.frameBasic, "Do you want to leave the program ?",
				"Exit question", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		if (selection == JOptionPane.OK_OPTION) {
			WB.addLog2("Command.exit", "", "Command");
			WB.getFinish();
			System.exit(0);
		}
	}
}
