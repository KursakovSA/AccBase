import java.io.File;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

import javax.swing.JOptionPane;

public class Command {
	// origin - 13.12.2023, last edit - 09.09.2024

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Command.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Command");
		} finally {
			Etc.doNothing();
		}
	}

	@SuppressWarnings("deprecation")
	public static void clearSpoolerPrinters() throws Exception {// not work
		// origin - 20.06.2024, last edit - 21.08.2024
		try {
			Runtime.getRuntime().exec("net stop spooler");
			Runtime.getRuntime().exec("cmd.exe del /f /q %systemroot%\\system32\\spool\\printers\\*.shd");
			Runtime.getRuntime().exec("cmd.exe del /f /q %systemroot%\\system32\\spool\\printers\\*.spl");
			Runtime.getRuntime().exec("net start spooler");
		} catch (Exception ex) {
			WB.addLog("Command.clearControlPrinters, ex=" + ex.getMessage(), WB.strEmpty, "DAL");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Command.ClearSpoolerPrinters",WB.strEmpty,"Command");
	}

	@SuppressWarnings("deprecation")
	public static void openControlPrinters() throws Exception {
		// origin - 19.06.2024, last edit - 21.08.2024
		try {
			Runtime.getRuntime().exec("control printers");
		} catch (Exception ex) {
			WB.addLog("Command.openControlPrinters, ex=" + ex.getMessage(), WB.strEmpty, "Command");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Command.OpenControlPrinters",WB.strEmpty,"Command");
	}

	public static void cleanFolderProgram() throws Exception {
		// origin - 30.05.2024, last edit - 27.06.2024
		LocalDateTime localStart = WB.getLocalStart();
		TreeSet<String> fileToDel = new TreeSet<String>();
		try {
			// clean log
			fileToDel.add(WB.eventLogPath);
			for (var currFileToDel : fileToDel) {
				// WB.addLog2("Command.cleanFolderProgram, currFileToDel=" + currFileToDel,
				// WB.strEmpty,
				// "Command");
				InOut.delFile(Paths.get(currFileToDel).toFile());
			}

			// Command.cleanInputOutput(Conn.outputDbPattern, Conn.toAllPattern);

		} catch (Exception ex) {
			WB.addLog("Command.cleanFolderProgram, ex=" + ex.getMessage(), WB.strEmpty, "DAL");
		} finally {
			Etc.doNothing();
		}
		WB.getLocalEnd("Command.cleanFolderProgram, fileToDel.size=" + fileToDel.size(), localStart);
		// WB.addLog2("Command.cleanFolderProgram, fileToDel.size=" + fileToDel.size(),
		// WB.strEmpty, "Command");
	}

	public static void cleanInputOutput(String patternInOut, String patternTo) throws Exception {
		// origin - 29.05.2024, last edit - 03.07.2024
		try {
			InOut.getDelFile(WB.inputOutputDir, patternInOut, patternTo, Conn.patternExtensionSqlite);
		} catch (Exception ex) {
			WB.addLog("Command.cleanInputOutput, ex=" + ex.getMessage(), WB.strEmpty, "DAL");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Command.cleanInputOutput, patternInOut=" + patternInOut + ", patternTo=" + patternTo, WB.strEmpty,
				"Command");
	}

	public static void replaceInto(TreeSet<String> setConn) throws Exception {
		// origin - 24.05.2024, last edit - 05.10.2024
		LocalDateTime localStart = WB.getLocalStart();
		List<ModelDto> updateDto = new ArrayList<ModelDto>();
		try {
			// new records in table for day
			List<List<String>> testTable = List.of(List.of("Asset", "1"), List.of("Face", "1"), List.of("Deal", "1"),
					List.of("Workbook", "1")); // ??magic strings and numbers

			// int numberPoint = 8; //??
			// int numberCenter = 1; //??

			updateDto = WriteSet.getTest(testTable);
			DAL.getReplaceInto(setConn, updateDto);
		} catch (Exception ex) {
			WB.addLog("Command.replaceInto, ex=" + ex.getMessage(), WB.strEmpty, "DAL");
		} finally {
			Etc.doNothing();
		}
		WB.getLocalEnd("Command.replaceInto, updateDto.size=" + updateDto.size() + ", setConn=" + setConn, localStart);
	}

	@SuppressWarnings({ "deprecation", "unused" })
	public static void openUserManualLocal() throws Exception {
		// origin - 23.05.2023, last edit - 16.09.2024
		String userManualLocalNameFile = WB.strEmpty;
		String pathFileToOpen = WB.strEmpty;
		try {
			Conn.readDatabaseLocal();// Conn.getLocal(WB.localDir); // reread DatabaseLocal
			Abc abcLocal = WB.abcLocal;

			for (var currUserManualLocal : abcLocal.userManualLocal) {
				userManualLocalNameFile = Etc.fixTrim(currUserManualLocal.description.toString());
				pathFileToOpen = Command.getFileToExtFile(userManualLocalNameFile);
				// java.awt.Desktop.getDesktop().open(new File(pathFileToOpen));

				// Runtime.getRuntime().exec("explorer.exe " + pathFile); //it is work, too
				java.lang.Process process = Runtime.getRuntime().exec("explorer.exe " + pathFileToOpen.toString(),
						null);

			}
		} catch (Exception ex) {
			WB.addLog("Command.openUserManualLocal, ex=" + ex.getMessage(), WB.strEmpty, "DAL");
		} finally {
			Etc.doNothing();
		}
	}

	public static void getLastRecord(TreeSet<String> setConn) throws Exception {
		// origin - 31.12.2023, last edit - 24.08.2024
		try {
			LocalDateTime localStart = WB.getLocalStart();
			TreeSet<String> resConn = DefVal.set(setConn, Conn.work); // Conn.getSetOrDefault(setConn);
			List<ModelDto> dtoLast = new ArrayList<ModelDto>();
			for (var currConn : resConn) {
				localStart = WB.getLocalStart();
				dtoLast = DAL.getTable(currConn, Qry.getWorkbookLastRecordSQLite);// Qry.getWorkbookLastRecord());
				WB.addLog2("Command.getLastRecord, dtoLast.size=" + dtoLast.size() + ", currConn=" + currConn,
						WB.strEmpty, "Command");
				WB.getLocalEnd("Command.getLastRecord" + WB.strCommaSpace + currConn, localStart);
			}
		} catch (Exception ex) {
			WB.addLog("Command.getLastRecord, ex=" + ex.getMessage(), WB.strEmpty, "DAL");
		} finally {
			Etc.doNothing();
		}
	}

	public static void updateBases(TreeSet<String> setConn) throws Exception {
		// origin - 24.12.2023, last edit - 23.08.2024
		try {
			LocalDateTime localStart = WB.getLocalStart();
			setConn = DefVal.set(setConn, Conn.work);// Conn.getSetOrDefault(setConn);
			List<ModelDto> updateDto = new ArrayList<ModelDto>();
			updateDto = WB.abcTemplate.update;
			DAL.getReplaceInto(setConn, updateDto);
			WB.getLocalEnd("Command.updateBases, updateDto.size=" + updateDto.size() + ", setConn=" + setConn,
					localStart);
		} catch (Exception ex) {
			WB.addLog("Command.updateBases, ex=" + ex.getMessage(), WB.strEmpty, "DAL");
		} finally {
			Etc.doNothing();
		}
	}

	public static void updateExtFiles() throws Exception {
		// origin - 24.12.2023, last edit - 28.08.2024
		try {
			LocalDateTime localStart = WB.getLocalStart();
			String sourceExtFile = WB.strEmpty;
			String fileTo = WB.strEmpty;
			Conn.readDatabaseLocal();// Conn.getLocal(WB.localDir);
			Abc abcLocal = WB.abcLocal;

			for (var currLocal : abcLocal.sourceExtFile) {
				sourceExtFile = currLocal.description.toString();// TODO ??? or take currLocal.code ???
				fileTo = Command.getFileToExtFile(sourceExtFile);
				Conn.copyExtFile(sourceExtFile, fileTo);

				// if find new DatabaseLocal file
				if (Etc.strContains(Etc.getFileName(sourceExtFile), Conn.localDbPattern)) {
					Conn.readDatabaseLocal();// Conn.getLocal(WB.localDir);
				}
				// WB.addLog2("Command.updateExtFiles, sourceExtFile=" + sourceExtFile + ", Id="
				// + currLocal.id, WB.strEmpty, "Command");
			}
			WB.getLocalEnd("Command.updateExtFiles" + WB.strCommaSpace + abcLocal.basic.size(), localStart);
		} catch (Exception ex) {
			WB.addLog("Command.updateExtFiles, ex=" + ex.getMessage(), WB.strEmpty, "DAL");
		} finally {
			Etc.doNothing();
		}
	}

	private static String getFileToExtFile(String sourceExtFile) throws Exception {
		// origin - 01.01.2024, last edit - 03.07.2024
		String res = WB.commonDocDir + File.separator + Etc.getFileName(sourceExtFile);
		try {
			String destinationExtFile = WB.strEmpty;

			// if find new DatabaseLocal file
			if (Etc.strContains(Etc.getFileName(sourceExtFile), Conn.localDbPattern)) {
				destinationExtFile = Etc.getFileName(sourceExtFile).replace(Conn.localDbPattern,
						Conn.localDbPattern + "_" + DateTool.getLabelDateTimeForFileName());
				res = WB.localDir + File.separator + destinationExtFile;
			}
		} catch (Exception ex) {
			WB.addLog("Command.getFileToExtFile, ex=" + ex.getMessage(), WB.strEmpty, "DAL");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void vacuum(TreeSet<String> setConn) throws Exception {
		// origin - 19.12.2023, last edit - 23.08.2024
		try {
			LocalDateTime localStart = WB.getLocalStart();
			setConn = DefVal.set(setConn, Conn.work);// Conn.getSetOrDefault(setConn);
			DAL.getVacuum(setConn);
			WB.getLocalEnd("Command.vacuum for setConn.size=" + setConn.size() + ", setConn=" + setConn, localStart);
		} catch (Exception ex) {
			WB.addLog("Command.vacuum, ex=" + ex.getMessage(), WB.strEmpty, "DAL");
		} finally {
			Etc.doNothing();
		}
	}

	public static void reindex(TreeSet<String> setConn) throws Exception {
		// origin - 19.12.2023, last edit - 23.08.2024
		try {
			LocalDateTime localStart = WB.getLocalStart();
			setConn = DefVal.set(setConn, Conn.work);// Conn.getSetOrDefault(setConn);
			DAL.getReindex(setConn);
			WB.getLocalEnd("Command.reindex for setConn.size=" + setConn.size() + ", setConn=" + setConn, localStart);
		} catch (Exception ex) {
			WB.addLog("Command.reindex, ex=" + ex.getMessage(), WB.strEmpty, "DAL");
		} finally {
			Etc.doNothing();
		}
	}

	public static void integrityCheck(TreeSet<String> setConn) throws Exception {
		// origin - 19.12.2023, last edit - 23.08.2024
		try {
			LocalDateTime localStart = WB.getLocalStart();
			setConn = DefVal.set(setConn, Conn.work);// Conn.getSetOrDefault(setConn);
			DAL.getIntegrityCheck(setConn);
			WB.getLocalEnd("Command.integrityCheck for setConn.size=" + setConn.size() + ", setConn=" + setConn,
					localStart);
		} catch (Exception ex) {
			WB.addLog("Command.integrityCheck, ex=" + ex.getMessage(), WB.strEmpty, "DAL");
		} finally {
			Etc.doNothing();
		}
	}

	public static void input(TreeSet<String> setConnFrom, TreeSet<String> setConnTo, String patternInOut,
			String patternTo) throws Exception {
		// origin - 28.05.2024, last edit - 27.06.2024
		try {
			LocalDateTime localStart = WB.getLocalStart();
			List<ModelDto> dtoInput = new ArrayList<ModelDto>();
			dtoInput = DAL.setByTemplate(setConnFrom, WB.strEmpty);
			DAL.getReplaceInto(setConnTo, dtoInput);
			WB.getLocalEnd("Command.input for setConnFrom.size=" + setConnFrom.size(), localStart);
			WB.addLog2("Command.input, setConnFrom.size=" + setConnFrom.size() + ", dtoInput.size=" + dtoInput.size()
					+ ", setConnTo=" + setConnTo + ", patternInOut=" + patternInOut + ", patternTo=" + patternTo,
					WB.strEmpty, "Command");
		} catch (Exception ex) {
			WB.addLog("Command.input, ex=" + ex.getMessage(), WB.strEmpty, "Command");
		} finally {
			Etc.doNothing();
		}
	}

	public static void outputBackup(TreeSet<String> setConn) throws Exception {
		// origin - 28.05.2024, last edit - 23.08.2024
		try {
			LocalDateTime localStart = WB.getLocalStart();
			setConn = DefVal.set(setConn, Conn.work);// Conn.getSetOrDefault(setConn);
			DAL.getOutputBackup(setConn);
			WB.getLocalEnd("Command.outputBackup for setConn.size=" + setConn.size() + ", setConn=" + setConn,
					localStart);
		} catch (Exception ex) {
			WB.addLog("Command.outputBackup, ex=" + ex.getMessage(), WB.strEmpty, "Command");
		} finally {
			Etc.doNothing();
		}
	}

	public static void backup(TreeSet<String> setConn) throws Exception {
		// origin - 18.12.2023, last edit - 23.08.2024
		try {
			LocalDateTime localStart = WB.getLocalStart();
			setConn = DefVal.set(setConn, Conn.work);// Conn.getSetOrDefault(setConn);
			DAL.getBackup(setConn);
			WB.getLocalEnd("Command.backup for setConn.size=" + setConn.size() + ", setConn=" + setConn, localStart);
		} catch (Exception ex) {
			WB.addLog("Command.backup, ex=" + ex.getMessage(), WB.strEmpty, "Command");
		} finally {
			Etc.doNothing();
		}
	}

	public static void exit() throws Exception {
		// origin - 11.12.2023, last edit - 03.07.2024
		try {
			int selection = JOptionPane.showConfirmDialog(WB.frameBasic, "Do you want to leave the program ?",
					"Exit question", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
			if (selection == JOptionPane.OK_OPTION) {
				WB.addLog2("Command.exit", WB.strEmpty, "Command");
				WB.getFinish();
				System.exit(0);
			}
		} catch (Exception ex) {
			WB.addLog("Command.exit, ex=" + ex.getMessage(), WB.strEmpty, "Command");
		} finally {
			Etc.doNothing();
		}
	}

	private Command() {
		// origin - 04.11.2024, last edit - 04.11.2024
	}

	public static void test() throws Exception {
		// origin - 28.05.2024, last edit - 16.09.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Command.test, ex=" + ex.getMessage(), WB.strEmpty, "Command");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Command.test end ", WB.strEmpty, "Command");
	}
}