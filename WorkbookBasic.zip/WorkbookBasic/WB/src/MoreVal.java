import java.util.ArrayList;
import java.util.List;

public class MoreVal { //work with vals into field More, ex. "IIN=123456789012;Sex=male;", etc.
	// origin - 05.10.2024, last edit - 01.11.2024
	
	public String id = WB.strEmpty;
	public String context = WB.strEmpty;
	public String src = WB.strEmpty;
	public final static String defVal = WB.strEmpty;
	
	public List<String> name = new ArrayList<String>();
	public List<ModelVal> val = new ArrayList<ModelVal>();

	public static boolean isRequiredFill(String initVal) throws Exception {
		// origin - 19.06.2024, last edit - 09.10.2024
		boolean res = false;
		try {
			initVal = Etc.fixTrim(initVal);
			if (initVal.endsWith("=?")) { // ?? magic string ??
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("MoreVal.isRequiredFill, ex=" + ex.getMessage(), WB.strEmpty, "MoreVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("MoreVal.isRequiredFill, res=" + res + ", initVal=" + initVal,
		// WB.strEmpty, "MoreVal");
		return res;
	}

	public static String getFromEquation(String[] equation, String key) throws Exception {
		// origin - 16.06.2024, last edit - 09.10.2024
		String res = WB.strEmpty;
		try {
			int indexSignEquals = 0;
			String strKey = WB.strEmpty;
			String splitEquation = WB.strEquals;
			for (var currEquation : equation) {
				indexSignEquals = 0;
				indexSignEquals = currEquation.lastIndexOf(splitEquation);
				if (indexSignEquals > 0) {
					strKey = WB.strEmpty;
					strKey = currEquation.substring(0, indexSignEquals);
					if (strKey.isEmpty() == false) {
						if (Etc.strEquals(key, strKey)) {
							res = currEquation.substring(indexSignEquals + 1, currEquation.length());
						}
					}
				}

			}
		} catch (Exception ex) {
			WB.addLog("MoreVal.getFromEquation, ex=" + ex.getMessage(), WB.strEmpty, "MoreVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("MoreVal.getFromEquation, res=" + res + ", key=" + key,
		// WB.strEmpty, "MoreVal");
		return res;
	}

	public static String getByKey(List<ModelDto> dto, String key, String code) throws Exception {
		// origin - 17.06.2024, last edit - 09.10.2024
		// ex. call --- somestring =
		// ReadVal.getByKey(WB.abcLast.infoBaseId, "infoBaseId", "Face.FA1");
		String res = WB.strEmpty;
		try {
			String[] items = {};
			String splitValueInMore = WB.strSemiColon;
			for (var currDto : dto) {

				// filter by code (optional)
				if (code.isEmpty() == false) {// code may be empty
					if (Etc.strEquals(currDto.code, code) == false) {
						continue;
					}
				}

				// items = Etc.getArrayFromStrSplit(currDto.more, splitValueInMore); // if value
				// are diffferent in list ???
				items = currDto.more.split(splitValueInMore); // if value are diffferent in list ???
				res = MoreVal.getFromEquation(items, key);
			}
		} catch (Exception ex) {
			WB.addLog("MoreVal.getByKey, ex=" + ex.getMessage(), WB.strEmpty, "MoreVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("MoreVal.getByKey, res=" + res, WB.strEmpty, "MoreVal");
		return res;
	}

	public static String getFieldByKey(String initMore, String key) throws Exception {
		// origin - 08.10.2024, last edit - 09.10.2024
		String res = WB.strEmpty;
		initMore = Etc.fixTrim(initMore);

		try {
			String[] items = initMore.split(WB.strSemiColon); // if value are diffferent in list ???
			res = MoreVal.getFromEquation(items, key);

		} catch (Exception ex) {
			WB.addLog("MoreVal.getFieldByKey, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "MoreVal");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("MoreVal.getFieldByKey, res=" + res + ", initMore=" + initMore + ", key=" + key, WB.strEmpty,
//				"MoreVal");
		return res;
	}

	public static String lastEdit(String initRes) throws Exception {
		// origin - 25.06.2024, last edit - 07.10.2024
		String res = Etc.fixTrim(initRes);
		try {
			res = MoreVal.delFieldByKey(res, "LastEdit"); // ??? magic string
			res = res + "LastEdit=" + DateTool.formatter2(DateTool.getNow2()) + WB.strSemiColon;
		} catch (Exception ex) {
			WB.addLog("MoreVal.lastEdit, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "MoreVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("MoreVal.lastEdit, res=" + res, WB.strEmpty, "MoreVal");
		return res;
	}

	public static String delFieldByKey(String initMore, String delField) throws Exception {
		// origin - 25.06.2024, last edit - 08.10.2024
		String res = WB.strEmpty;
		initMore = Etc.fixTrim(initMore);
		try {
			String[] items = {};
			// items = Etc.getArrayFromStrSplit(initMore, WB.strSemiColon); // if value are
			// diffferent in list ???
			items = initMore.split(WB.strSemiColon); // if value are diffferent in list ???
			for (var item : items) {
				if (Etc.strContains(item, delField)) {// skip deleting field //?? delField + equation = ??
					continue;
				}
				res = res + item;
			}
		} catch (Exception ex) {
			WB.addLog("MoreVal.delFieldByKey, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "MoreVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("MoreVal.delFieldByKey, res=" + res + ", initMore=" +
		// initMore, WB.strEmpty, "MoreVal");
		return res;
	}

	public MoreVal() throws Exception {
		// origin - 05.10.2024, last edit - 07.10.2024
	}

	public static void test() throws Exception {
		// origin - 05.10.2024, last edit - 09.10.2024
		try {

//			// isRequiredFill
//			for (String testArg1 : new String[] { "KZ?", "IBAN=?", "Description=;", "?Surname=;" }) {
//				WB.addLog2("MoreVal.test.isRequiredFill, res=" + isRequiredFill(testArg1) + ", testArg1=" + testArg1,
//						WB.strEmpty, "MoreVal");
//			}

//			// getFieldByKey(initMore, key)
//			String initMore = "AbcBasic=Meter.Basic;AbcExpectedValue=Meter.ExpectedDouble;";
//			String key = "AbcExpectedValue";
//			WB.addLog2(
//					"MoreVal.test.getFieldByKey, res=" + MoreVal.getFieldByKey(initMore, key) + ", initMore="
//							+ Formatter.replaceAll(initMore, WB.strSemiColon, WB.strSpace) + ", key=" + key,
//					WB.strEmpty, "MoreVal");

		} catch (

		Exception ex) {
			WB.addLog("MoreVal.test, ex=" + ex.getMessage(), WB.strEmpty, "MoreVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("MoreVal.test end ", WB.strEmpty, "MoreVal");
	}
}
