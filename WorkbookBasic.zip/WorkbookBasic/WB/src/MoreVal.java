import java.util.ArrayList;
import java.util.List;

public class MoreVal { // work with vals into field More, ex. "IIN=123456789012;Sex=male;", etc.
	// origin - 05.10.2024, last edit - 05.03.2025

	public String id = WB.strEmpty;
	public String context = WB.strEmpty;
	public String src = WB.strEmpty;
	public final static String defVal = WB.strEmpty;
	public List<ModelVal> val = new ArrayList<ModelVal>();

	public static boolean isRequiredFill(String initVal) throws Exception {
		// origin - 19.06.2024, last edit - 05.03.2025
		boolean res = false;
		try {
			initVal = Etc.fixTrim(initVal);
			if (initVal.endsWith("=?")) { // ?? magic string ??
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("MoreVal.isRequiredFill, ex=" + ex.getMessage(), WB.strEmpty, "MoreVal");
		}
		return res;
	}

	public static String getFromEquation(String[] equation, String key) throws Exception {
		// origin - 16.06.2024, last edit - 05.03.2025
		String res = WB.strEmpty;
		try {
			int indexSignEquals = 0;
			String strKey = WB.strEmpty;
			String splitEquation = WB.strEquals;
			for (var currEquation : equation) {
				indexSignEquals = 0;
				indexSignEquals = currEquation.lastIndexOf(splitEquation);
				if (indexSignEquals > 0) {
					strKey = WB.strEmpty;
					strKey = currEquation.substring(0, indexSignEquals);
					strKey = Etc.fixTrim(strKey);
					if ((strKey.isEmpty() == false) & (Etc.strEquals(key, strKey))) {
						res = currEquation.substring(indexSignEquals + 1, currEquation.length());
						res = Etc.fixTrim(res);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("MoreVal.getFromEquation, ex=" + ex.getMessage(), WB.strEmpty, "MoreVal");
		}
		return res;
	}

	public static String getByKey(List<ModelDto> dto, String key, String code) throws Exception {
		// origin - 17.06.2024, last edit - 05.03.2025
		// ex. call --- somestring =
		// ReadVal.getByKey(WB.abcLast.infoBaseId, "infoBaseId", "Face.FA1");
		String res = WB.strEmpty;
		try {
			String[] items = {};
			String splitValueInMore = WB.strSemiColon;
			for (var currDto : dto) {

				// filter by code (optional)
				if ((code.isEmpty() == false) & // code may be empty
						(Etc.strEquals(currDto.code, code) == false)) {
					continue;
				}

				// items = Etc.getArrayFromStrSplit(currDto.more, splitValueInMore); // if value
				// are diffferent in list ???
				items = currDto.more.split(splitValueInMore); // if value are diffferent in list ???
				res = MoreVal.getFromEquation(items, key);
			}
		} catch (Exception ex) {
			WB.addLog("MoreVal.getByKey, ex=" + ex.getMessage(), WB.strEmpty, "MoreVal");
		}
		return res;
	}

	public static String getFieldByKey(String initMore, String key) throws Exception {
		// origin - 08.10.2024, last edit - 05.03.2025
		String res = WB.strEmpty;
		initMore = Etc.fixTrim(initMore);
		try {
			String[] items = initMore.split(WB.strSemiColon); // if value are diffferent in list ???
			res = MoreVal.getFromEquation(items, key);
		} catch (Exception ex) {
			WB.addLog("MoreVal.getFieldByKey, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "MoreVal");
		}
		return res;
	}

	public static String lastEdit(String initRes) throws Exception {
		// origin - 25.06.2024, last edit - 05.03.2025
		String res = Etc.fixTrim(initRes);
		try {
			res = MoreVal.delFieldByKey(res, "LastEdit"); // ??? magic string
			res = res + "LastEdit=" + DateTool.formatter2(DateTool.getNow2()) + WB.strSemiColon;
		} catch (Exception ex) {
			WB.addLog("MoreVal.lastEdit, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "MoreVal");
		}
		return res;
	}

	public static String delFieldByKey(String initMore, String delField) throws Exception {
		// origin - 25.06.2024, last edit - 05.03.2025
		String res = WB.strEmpty;
		initMore = Etc.fixTrim(initMore);
		try {
			String[] items = {};
			// items = Etc.getArrayFromStrSplit(initMore, WB.strSemiColon); // if value are
			// diffferent in list ???
			items = initMore.split(WB.strSemiColon); // if value are diffferent in list ???
			for (var item : items) {
				if (Etc.strContains(item, delField)) {// skip deleting field //?? delField + equation = ??
					continue;
				}
				res = res + item;
			}
		} catch (Exception ex) {
			WB.addLog("MoreVal.delFieldByKey, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "MoreVal");
		}
		return res;
	}

	public MoreVal(String Src) throws Exception {
		// origin - 14.11.2024, last edit - 05.03.2025
		this.src = Src;
		try {
			this.id = Src;
			String[] items = Src.split(WB.strSemiColon);
			for (var item : items) {
				this.val.add(new SimplexVal(item));// ?? find type, ex. SimplexVal, or UninVal, etc...
			}
		} catch (Exception ex) {
			WB.addLog("MoreVal.ctor(String Src), ex=" + ex.getMessage(), WB.strEmpty, "MoreVal");
		}
	}

	public MoreVal() throws Exception {
		// origin - 05.10.2024, last edit - 07.10.2024
	}

	public String toString() {
		// origin - 14.11.2024, last edit - 05.03.2025
		String res = WB.strEmpty;
		try {
			// res = Formatter.listIter(this.val, "MoreVal");
			res = this.id;
		} catch (Exception ex) {
			// WB.addLog("MoreVal.toString, ex=" + ex.getMessage(), WB.strEmpty,
			// "MoreVal");
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 05.10.2024, last edit - 10.03.2025
		try {

//			// ctor1
//			MoreVal mv1 = new MoreVal("IIN=123456789012;Sex=male;");
//			WB.addLog2("MoreVal.test.ctor1, mv1=" + mv1 + ", mv1.val.size=" + mv1.val.size() + ", mv1.src=" + mv1.src,
//					WB.strEmpty, "MoreVal");

//			// isRequiredFill
//			for (String testArg1 : new String[] { "KZ?", "IBAN=?", "Description=;", "?Surname=;" }) {
//				WB.addLog2("MoreVal.test.isRequiredFill, res=" + isRequiredFill(testArg1) + ", testArg1=" + testArg1,
//						WB.strEmpty, "MoreVal");
//			}

//			// getFieldByKey(initMore, key)
//			// String initMore =
//			// "AbcBasic=Meter.Basic;AbcExpectedValue=Meter.ExpectedDouble;";
//			// String key = "AbcExpectedValue";
//			String initMore = "EmpId=001;AbcBasic=Face.Basic;Comment=;Fullname=;Salary=220000.0:245000.0:;";
//			String key = "Salary";
//			WB.addLog2(
//					"MoreVal.test.getFieldByKey, res=" + MoreVal.getFieldByKey(initMore, key) + ", initMore="
//							+ initMore.replaceAll(WB.strSemiColon, WB.strComma) + ", key=" + key,
//					WB.strEmpty, "MoreVal");

		} catch (

		Exception ex) {
			WB.addLog("MoreVal.test, ex=" + ex.getMessage(), WB.strEmpty, "MoreVal");
		}
	}
}