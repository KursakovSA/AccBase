import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class NameVar {
	// origin - 11.09.2026, last edit - 18.10.2026
	static {
		try {
		} catch (Exception ex) {
			WB.addLog("NameVar.static ctor, ex=" + ex.getMessage(), "", "NameVar");
		}
	}

	public static List<String> getListMoreValByClass(String more, String cl) throws Exception {
		// origin - 20.10.2026, last edit - 20.10.2026
		List<String> res = new ArrayList<String>();
		try {
			if (Etc.strNotValid(more, cl)) {
				return res;
			}
			var tmp1 = NameVar.getListByClass(cl);
			res = NameVar.getListMoreVal(more, tmp1);
			res = Etc.removeDuplicate(res);
		} catch (Exception ex) {
			WB.addLog("NameVar.getListMoreValByClass(String,List<String>):List<String>, ex=" + ex.getMessage(), "",
					"NameVar");
		}
		return res;
	}

	public static List<String> getListMoreVal(String more, List<String> partList) throws Exception {
		// origin - 20.10.2026, last edit - 22.10.2026
		List<String> res = new ArrayList<String>();
		try {
			if (Etc.strNotValid(more)) {
				return res;
			}

			var tmp = Fmtr.getListStrBySplit(more, ";");
			for (var currPartMore : tmp) {
				for (var currPartList : partList) {
					if (currPartMore.startsWith(currPartList)) {
						res.add(currPartMore);
					}
				}
			}
			res = Etc.removeDuplicate(res);
		} catch (Exception ex) {
			WB.addLog("NameVar.getListMoreVal(String,List<String>):List<String>, ex=" + ex.getMessage(), "", "NameVar");
		}
		return res;
	}

	public static boolean hasNotByClass(String cl) throws Exception {
		// origin - 19.10.2026, last edit - 19.10.2026
		boolean res = true;
		try {
			if (Etc.strNotValid(cl)) {
				return res;
			}
			var tmp = NameVar.getListByClass(cl);
			if (tmp.size() != 0) {
				res = false;
			}
		} catch (Exception ex) {
			WB.addLog("NameVar.hasNotByClass(String):boolean, ex=" + ex.getMessage(), "", "NameVar");
		}
		return res;
	}

	public static String getValByClassInfo(String cl, String info) throws Exception {
		// origin - 20.10.2026, last edit - 20.10.2026
		String res = "";
		try {
			if (Etc.strNotValid(cl, info)) {
				return res;
			}

			for (var curr : WB.abcGlobal.name) {
				if (Etc.strEquals(curr.info, info)) {
					if (Etc.strContains(curr.code, cl)) {
						res = curr.meterValue;
						break;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("NameVar.getValByClassInfo(2String):String, ex=" + ex.getMessage(), "", "NameVar");
		}
		return res;
	}

	public static List<String> getListByClassInfo(String cl, String info) throws Exception {
		// origin - 17.10.2026, last edit - 19.10.2026
		List<String> res = new ArrayList<String>();
		try {
			if (Etc.strNotValid(cl, info)) {
				return res;
			}

			for (var curr : WB.abcGlobal.name) {
				if (Etc.strEquals(curr.info, info)) {
					if (Etc.strContains(curr.code, cl)) {
						var tmp = List.of(curr.meterValue.split(";"));
						if (tmp.size() != 0) {
							res.addAll(tmp);
						}
					}
				}
			}

			res = Etc.removeDuplicate(res);
		} catch (Exception ex) {
			WB.addLog("NameVar.getListByClassInfo(2String):List<String>, ex=" + ex.getMessage(), "", "NameVar");
		}
		return res;
	}

	public static List<String> getListByClass(String cl) throws Exception {
		// origin - 17.10.2026, last edit - 20.10.2026
		List<String> res = new ArrayList<String>();
		try {
			if (Etc.strNotValid(cl)) {
				return res;
			}

			for (var curr : WB.abcGlobal.name) {
				if (Etc.strContains(curr.code, cl)) {
					var tmp = List.of(curr.meterValue.split(";"));
					if (tmp.size() != 0) {
						res.addAll(tmp);
					}
				}
			}

			res = Etc.removeDuplicate(res);
		} catch (Exception ex) {
			WB.addLog("NameVar.getListByClass(String):List<String>, ex=" + ex.getMessage(), "", "NameVar");
		}
		return res;
	}

	public static List<String> getListBySectoral(String sectoral) throws Exception {
		// origin - 17.10.2026, last edit - 19.10.2026
		List<String> res = new ArrayList<String>();
		try {
			if (Etc.strNotValid(sectoral)) {
				return res;
			}

			for (var curr : WB.abcGlobal.name) {
				if (Etc.strContains(curr.more, sectoral)) {
					var tmp = List.of(curr.meterValue.split(";"));
					if (tmp.size() != 0) {
						res.addAll(tmp);
					}
				}
			}

			res = Etc.removeDuplicate(res);
		} catch (Exception ex) {
			WB.addLog("NameVar.getListBySectoral(String):List<String>, ex=" + ex.getMessage(), "", "NameVar");
		}
		return res;
	}

	private static List<String> getList() throws Exception {
		// origin - 17.10.2026, last edit - 20.10.2026
		List<String> res = new ArrayList<String>();
		try {
			for (var curr : WB.abcGlobal.name) {
				var tmp = List.of(curr.meterValue.split(";"));
				if (tmp.size() == 0) {
					continue;
				}
				res.addAll(tmp);
			}

			res = Etc.removeDuplicate(res);
		} catch (Exception ex) {
			WB.addLog("NameVar.getList():void, ex=" + ex.getMessage(), "", "NameVar");
		}
		return res;
	}

	public static Map<String, UnitVal> get(String initMore) throws Exception { // TOTHINK
		// origin - 17.09.2026, last edit - 18.10.2026
		Map<String, UnitVal> res = new HashMap<>();
		try {
			if (Etc.strNotValid(initMore)) {
				return res;
			}
			for (var curr : NameVar.getList()) {
				var tmp = NameVar.get(initMore, curr);
				if (tmp.id.isEmpty() == false) {
					res.put(curr, tmp);
				}
			}
		} catch (Exception ex) {
			WB.addLog("NameVar.get(String):Map<String, UnitVal>, ex=" + ex.getMessage(), "", "NameVar");
		}
		return res;
	}

	public static UnitVal get(String initMore, String key) throws Exception {
		// origin - 11.09.2026, last edit - 19.10.2026
		UnitVal res = new UnitVal();
		try {
			if (Etc.strNotValid(initMore, key)) {
				return res;
			}
			if (NameVar.getList().contains(key)) {
				var tmp = MoreVal.getFieldByKey(initMore, key);
				if (tmp.isEmpty() == false) {
					res = new UnitVal(tmp);
				}
			}
		} catch (Exception ex) {
			WB.addLog("NameVar.get(2String):UnitVal, ex=" + ex.getMessage() + ", key=" + key, "", "NameVar");
		}
		return res;
	}

	private NameVar() throws Exception {
		// origin - 11.09.2026, last edit - 11.09.2026
	}

	public static String mapToStr(Map<String, UnitVal> inMap) throws Exception {
		// origin - 17.09.2026, last edit - 17.09.2026
		String res = "";
		try {
			for (Map.Entry<String, UnitVal> entry : inMap.entrySet()) {
				String key = entry.getKey();
				UnitVal value = entry.getValue();
				res = res + key + "=" + value.id + ", ";
			}
			res = "[" + res + "]";
		} catch (Exception ex) {
			WB.addLog("NameVar.mapToStr (Map<String, UnitVal>):String, ex=" + ex.getMessage(), "", "NameVar");
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 11.09.2026, last edit - 22.10.2026
		try {

//			WB.addLog2("NameVar.test.getListMoreValByClass(2String):List<String>", "", "NameVar");
//			for (var tmp1 : new String[] { null, "", "PointId=111;", "CrewId=222;FullName=333;",
//					"CashId=444;FullName=555;", "FullName=666;EmpId=777;",
//					"StoreId=111;CashId=222;FullName=444;DeptId=555;" }) {
//				for (var tmp2 : new String[] { null, "", "Face" }) {
//					WB.addLog2(
//							"NameVar.test.getListMoreValByClass(2String):List<String>, res="
//									+ NameVar.getListMoreValByClass(tmp1, tmp2) + ", tmp1=" + tmp1 + ", tmp2=" + tmp2,
//							"", "NameVar");
//				}
//			}

//			WB.addLog2("NameVar.test.getListMoreVal(2String):List<String>", "", "NameVar");
//			for (var tmp1 : new String[] { null, "", "PointId=111;", "CrewId=222;FullName=333;",
//					"CashId=444;FullName=555;", "FullName=666;EmpId=777;",
//					"StoreId=111;CashId=222;FullName=444;DeptId=555;" }) {
//				for (var tmp2 : new String[] { null, "", "Face" }) {
//					var tmp3 = NameVar.getListByClass(tmp2);
//					WB.addLog2("NameVar.test.getListMoreVal(2String):List<String>, res="
//							+ NameVar.getListMoreVal(tmp1, tmp3) + ", tmp1=" + tmp1 + ", tmp2=" + tmp2 + ", tmp3="
//							+ tmp3, "", "NameVar");
//				}
//			}

//			WB.addLog2("NameVar.test.hasNotByClass(String):boolean", "", "NameVar");
//			for (var tmp1 : new String[] { null, "", "Asset", "Unit", "Face", "Move", "Salary", "Tralala" }) {
//				WB.addLog2("NameVar.test.hasNotByClass(String):boolean, res=" + NameVar.hasNotByClass(tmp1) + ", tmp1="
//						+ tmp1, "", "NameVar");
//			}

//			WB.addLog2("NameVar.test.getListByClassInfo(String):List<String>", "", "NameVar");
//			for (var tmp1 : new String[] { null, "", "Asset", "Unit", "Face", "Move", "Process", "Tralala" }) {
//				for (var tmp2 : new String[] { null, "", "Info.Generic.Dim", "Info.Generic.Name", "Info.Process.Var",
//						"Info.Generic.TemplateDocVar", "Info.Asset.Code", "Tralala" }) {
//					WB.addLog2(
//							"NameVar.test.getListByClassInfo(String):List<String>, res="
//									+ NameVar.getListByClassInfo(tmp1, tmp2) + ", tmp1=" + tmp1 + ", tmp2=" + tmp2,
//							"", "NameVar");
//				}
//			}

//			WB.addLog2("NameVar.test.getListByClass(String):List<String>", "", "NameVar");
//			for (var tmp1 : new String[] { null, "", "Asset", "Unit", "Face", "Move", "Tralala" }) {
//				WB.addLog2("NameVar.test.getListByClass(String):List<String>, res=" + NameVar.getListByClass(tmp1)
//						+ ", tmp1=" + tmp1, "", "NameVar");
//			}

//			WB.addLog2("NameVar.test.getListBySectoral(String):List<String>", "", "NameVar");
//			for (var tmp1 : new String[] { null, "", "Common", "MetalTrading", "Tralala" }) {
//				WB.addLog2("NameVar.test.getListBySectoral(String):List<String>, res=" + NameVar.getListBySectoral(tmp1)
//						+ ", tmp1=" + tmp1, "", "NameVar");
//			}

//			WB.addLog2("NameVar.test.get(String):Map", "", "NameVar");
//			for (var tmp1 : new String[] { "", "FullName=килограмм;", "Weight=1000.00(Unit.Gr);MKEI=166;",
//					"FullName=100 грамм;Weight=0.10(Unit.Kg);", "MKEI=8;Lenght=1000.00(Unit.Meter);",
//					"FullName=литр;Volume=1000.00(Unit.Ml);",
//					"FullName=метр;Lenght=100.00(Unit.Cm);Width=100.00(Unit.Cm);Height=100.00(Unit.Cm);",
//					"FullName=миллиметр;Lenght=1000.00(Unit.Mcm);" }) {
//				WB.addLog2("NameVar.test.get(String):Map, res=" + NameVar.mapToStr(Dim.get(tmp1)) + ", tmp1=" + tmp1, "", "NameVar");
//			}

//			WB.addLog2("NameVar.test.get(2String)", "", "NameVar");
//			for (var tmp1 : new String[] { "", "FullName=килограмм;", "Weight=1000.00(Unit.Gr);MKEI=166;",
//					"FullName=100 грамм;Weight=0.10(Unit.Kg);", "MKEI=8;Lenght=1000.00(Unit.Meter);",
//					"FullName=литр;Volume=1000.00(Unit.Ml);",
//					"FullName=метр;Lenght=100.00(Unit.Cm);Width=100.00(Unit.Cm);Height=100.00(Unit.Cm);",
//					"FullName=миллиметр;Lenght=1000.00(Unit.Mcm);" }) {
//				for (var tmp3 : NameVar.nameList) {
//					WB.addLog2("NameVar.test.get(2String), res.id=" + NameVar.get(tmp1, tmp3).id + ", tmp1=" + tmp1 + ", tmp3="
//							+ tmp3, "", "NameVar");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("NameVar.test():void, ex=" + ex.getMessage(), "", "NameVar");
		}
	}
}