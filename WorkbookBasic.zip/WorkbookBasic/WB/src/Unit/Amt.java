import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class Amt { // "amount"
	// origin - 12.11.2026, last edit - 12.11.2026
	public String src, srcUnit;
	public List<String> srcList;
	public List<UnitVal> val;
	public static String unitDefault;
	public static String strAmount;

	static {
		try {
			Amt.unitDefault = Unit.currCurrency.code;
			Amt.strAmount = "Amount";
		} catch (Exception ex) {
			WB.addLog("Amt.static ctor, ex=" + ex.getMessage(), "", "Amt");
		}
	}

	public static UnitVal getBySrcUnitName(String src, String unit, String name) throws Exception {
		// origin - 12.11.2026, last edit - 12.11.2026
		UnitVal res = new UnitVal();
		try {
			if (Etc.strNotValid(src, unit, name)) {
				return res;
			}
			var tmp1 = Amt.getMapBySrc(src, unit);
			for (Map.Entry<String, UnitVal> entry : tmp1.entrySet()) {
				String key = entry.getKey();
				if (Etc.strEquals(key, name)) {
					res = entry.getValue();
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Amt.getBySrcUnitName(3String):UnitVal, ex=" + ex.getMessage(), "", "Amt");
		}
		return res;
	}

	private static Map<String, UnitVal> getMapBySrc(String src, String unit) throws Exception {
		// origin - 12.11.2026, last edit - 13.11.2026
		Map<String, UnitVal> res = new LinkedHashMap<>();
		try {
			if (Etc.strNotValid(src)) {
				return res;
			}
			var tmp1 = NameVar.getListByNameStartWithInfo(Amt.strAmount, "Info.Generic.DocColumn");
			var tmp2 = new Qty(src, unit);
			int count = 0;
			for (var curr : tmp1) {
				if (count <= tmp2.val.size() - 1) {
					res.put(curr, tmp2.val.get(count));
				}
				count = count + 1;
			}
		} catch (Exception ex) {
			WB.addLog("Amt.getMapBySrc(2String):Map<String, UnitVal>, ex=" + ex.getMessage(), "", "Amt");
		}
		return res;
	}

	private void fix() throws Exception { // TODO
		// origin - 12.11.2026, last edit - 13.11.2026
		try {
		} catch (Exception ex) {
			WB.addLog("Amt.fix():void, ex=" + ex.getMessage(), "", "Amt");
		}
	}

	private void validate() throws Exception { // TODO
		// origin - 12.11.2026, last edit - 12.11.2026
		try {
		} catch (Exception ex) {
			WB.addLog("Amt.validate():void, ex=" + ex.getMessage(), "", "Amt");
		}
	}

	private void getVal() throws Exception {
		// origin - 12.11.2026, last edit - 13.11.2026
		try {
			if (Etc.strListValid(this.srcList)) {
				for (var curr : this.srcList) {
					curr = UnitVal.fixStrUnit(curr);
					var tmp = new UnitVal(curr);

					if (Etc.strValid(this.srcUnit)) {
						curr = UnitVal.cleanStrUnit(curr);
						tmp = new UnitVal(curr, this.srcUnit);
						this.val.add(tmp);
						continue;
					}

					if (Etc.strNotValid(tmp.partUnit)) {
						tmp = new UnitVal(curr, Amt.unitDefault);
						// this.val.add(tmp);
						// continue;
					}

					if (Etc.strNotValid(tmp.unit.id)) {
						tmp = new UnitVal(curr, Amt.unitDefault);
						// this.val.add(tmp);
						// continue;
					}
					this.val.add(tmp);
				}
			}
		} catch (Exception ex) {
			WB.addLog("Amt.getVal():void, ex=" + ex.getMessage(), "", "Amt");
		}
	}

	public Amt(String Src, String SrcUnit) throws Exception {
		// origin - 12.11.2026, last edit - 12.11.2026
		this.clear();
		this.src = Etc.fixTrim(Src);
		this.srcUnit = Etc.fixTrim(SrcUnit);
		this.srcList = List.of(this.src.split(";"));
		this.getVal();
		this.fix();
		this.validate();
	}

	public Amt() throws Exception {
		// origin - 12.11.2026, last edit - 12.11.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 12.11.2026, last edit - 12.11.2026
		try {
			this.src = this.srcUnit = "";
			this.srcList = new ArrayList<String>();
			this.val = new ArrayList<UnitVal>();
		} catch (Exception ex) {
			WB.addLog("Amt.clear():void, ex=" + ex.getMessage(), "", "Amt");
		}
	}

	public String toString() {
		// origin - 12.11.2026, last edit - 13.11.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", srcList ", this.srcList);
			res = res + Fmtr.addIfNotEmpty(", val ", UnitVal.toStringList(this.val));// this.val);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 12.11.2026, last edit - 13.11.2026
		try {

//			WB.addLog2("Amt.test.getMapBySrcUnitName(3String):UnitVal", "", "Amt");
//			WB.addLog2(
//					"Amt.test.NameVar.getListByNameStartWithInfo('Amount', 'Info.Generic.DocColumn'):List<String>, res="
//							+ NameVar.getListByNameStartWithInfo("Amount", "Info.Generic.DocColumn"),
//					"", "Amt");
//			for (var tmp1 : new String[] { null, "", "12.00", "12.00;1.7", "17,00;4;12.00", "3;5.00;6,00;7.0" }) {
//				for (var tmp2 : new String[] { "Unit.EUR" }) {
//					for (var tmp3 : NameVar.getListByNameStartWithInfo(Amt.strAmount, "Info.Generic.DocColumn")) {
//						WB.addLog2("Amt.test.getMapBySrcUnitName(3String):UnitVal, res="
//								+ Amt.getBySrcUnitName(tmp1, tmp2, tmp3).id + ", tmp1=" + tmp1 + ", tmp2=" + tmp2
//								+ ", tmp3=" + tmp3, "", "Amt");
//					}
//				}
//			}

//			WB.addLog2("Amt.test.getMapBySrc(String):Map<String; UnitVal>", "", "Amt");
//			for (var tmp1 : new String[] { null, "", "12.00", "12.00;1.7", "17,00;4;12.00", "3;5.00;6,00;7.0" }) {
//				WB.addLog2("Amt.test.getMapBySrc(String):Map<String, UnitVal>, res="
//						+ UnitVal.toStringMap(Amt.getMapBySrc(tmp1, "")) + ", tmp1=" + tmp1, "", "Amt");
//			}

//			WB.addLog2("Amt.test.ctor(2String)", "", "Amt");
//			for (var tmp1 : new String[] { null, "", "12.00", "12.00;1.7", "12.00;1.7(Unit.Kg)", "12.00(Unit.Kg);1.7",
//					"17,00;4;12.00", "3;5.00;6,00;7.0" }) {
//				for (var tmp2 : new String[] { "Unit.EUR" }) {
//					WB.addLog2(
//							"Amt.test.ctor(2String), res=" + new Amt(tmp1, tmp2) + ", tmp1=" + tmp1 + ", tmp2=" + tmp2,
//							"", "Amt");
//				}
//			}

//			WB.addLog2("Amt.test.ctor(String) by ctor(2String)", "", "Amt");
//			for (var tmp1 : new String[] { null, "", "12.00 (Unit.MinRate)", "12.00(Unit.MinRate)", "1.7", "17,00",
//					"4 Unit.MinRate", "4Unit.MinRate", "12.00", "5", "5.00", "5,00", "5.0", "5,0", "5,0;2.0",
//					"5,0(Unit.Kg);2.0(Unit.Tralala)", "5,0(Unit.Kg);2.0", "5,0;2.0(Unit.Tralala)",
//					"5,0;2.0Unit.Tralala" }) {
//				WB.addLog2("Amt.test.ctor(String) by ctor(2String), res=" + new Amt(tmp1, "") + ", tmp1=" + tmp1, "",
//						"Amt");
//			}

		} catch (Exception ex) {
			WB.addLog("Amt.test():void, ex=" + ex.getMessage(), "", "Amt");
		}
	}
}