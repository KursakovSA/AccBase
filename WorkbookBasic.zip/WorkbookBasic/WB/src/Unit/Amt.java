public final class Amt { // "amount"
	// origin - 21.10.2026, last edit - 21.10.2026
	public String src, src1, src2;
	public UnitVal amount;
	public static String unitDefault;

	static {
		try {
			Amt.unitDefault = Unit.currCurrency.code;
		} catch (Exception ex) {
			WB.addLog("Amt.static ctor, ex=" + ex.getMessage(), "", "Amt");
		}
	}

	private void fix() throws Exception {
		// origin - 21.10.2026, last edit - 21.10.2026
		try {
//			if (amount.val == 0) {
//				this.amount = new UnitVal(Amt.unitDefault);
//			}
		} catch (Exception ex) {
			WB.addLog("Amt.fix():void, ex=" + ex.getMessage(), "", "Amt");
		}
	}

	private void getSrc() throws Exception {
		// origin - 21.10.2026, last edit - 21.10.2026
		try {
			if (this.src.length() != 0) {
				String tmp = Etc.fixTrim(this.src); // "amount(unit)"

				int posSpace1 = tmp.indexOf("(");
				if (posSpace1 > 0) {
					this.src1 = Etc.fixTrim(tmp.substring(0, posSpace1)); // "amount"
					tmp = Etc.fixTrim(tmp.substring(posSpace1)); // "unit"

					if (tmp.length() != 0) {
						this.src2 = Etc.fixTrim(tmp); // "unit"
					}
				} else {
					this.src1 = tmp; // "amount"
				}
			}
		} catch (Exception ex) {
			WB.addLog("Amt.getSrc():void, ex=" + ex.getMessage(), "", "Amt");
		}
	}

	private void getPart() throws Exception {
		// origin - 21.10.2026, last edit - 21.10.2026
		try {
			if (this.src2.isEmpty()) {
				this.amount = new UnitVal(this.src1, PA.unitDefault);
			}
//			if (this.src2.isEmpty() == false) {
//				this.amount = new UnitVal(this.src1, this.src2);
//			}
		} catch (Exception ex) {
			WB.addLog("PA.getPart():void, ex=" + ex.getMessage(), "", "PA");
		}
	}

	public Amt(String Src) throws Exception {
		// origin - 21.10.2026, last edit - 21.10.2026
		this.clear();
		this.src = Etc.fixTrim(Src); // price amount
		this.getSrc();
		this.getPart();
		this.fix();
	}

	public Amt() throws Exception {
		// origin - 21.10.2026, last edit - 21.10.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 21.10.2026, last edit - 21.10.2026
		try {
			this.src = this.src1 = this.src2 = "";
			this.amount = new UnitVal(UnitVal.currCurrencyInit);
		} catch (Exception ex) {
			WB.addLog("Amt.clear():void, ex=" + ex.getMessage(), "", "Amt");
		}
	}

	public String toString() {
		// origin - 21.10.2026, last edit - 21.10.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addAnyway(", src1 ", this.src1);
			res = res + Fmtr.addAnyway(", src2 ", this.src2);
			res = res + Fmtr.addIfNotEmpty(", amount ", this.amount.id);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 21.10.2026, last edit - 21.10.2026
		try {

//			WB.addLog2("Amt.test.ctor(String)", "", "Amt");
//			for (var tmp1 : new String[] { null, "", " ", "15000.00", "19000,00", "12000.00(Unit.Kg)",
//					"12000.00 (Unit.Kg)" }) {
//				WB.addLog2("Amt.test.ctor(String)=" + new Amt(tmp1) + ", tmp1=" + tmp1, "", "Amt");
//			}

		} catch (Exception ex) {
			WB.addLog("Amt.test():void, ex=" + ex.getMessage(), "", "Amt");
		}
	}
}