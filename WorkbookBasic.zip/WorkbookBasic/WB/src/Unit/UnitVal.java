import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class UnitVal {// ex. AmountDeal = "12000.0(Unit.KZT)"
	// origin - 13.09.2024, last edit - 12.10.2025
	public String id, context, src, partName, name, partUnit;
	public Unit unit;
	private static List<String> listDelStr;
	public static String currCurrencyInit, calendarDayInit;
	public String partVal;
	public double val;

	static {
		UnitVal.listDelStr = List.of("(", ")", "=");
		try {
		} catch (Exception ex) {
			WB.addLog("UnitVal.static ctor, ex=" + ex.getMessage(), "", "UnitVal");
		}
	}

	public static String fixStrUnit(String src) throws Exception {
		// origin - 12.11.2026, last edit - 13.11.2026
		String res = "";
		try {
			if (Etc.strNotValid(src)) {
				return res;
			}
			var tmp = Etc.fixTrim(src);
			if (tmp.contains("Unit.") == false) {
				return src;
			}

			int pos2 = tmp.indexOf("Unit."); // pos "Unit."
			var tmp1 = Etc.fixTrim(tmp.substring(0, pos2));
			tmp1 = Etc.delTailStr(tmp1, "(");
			tmp1 = Etc.fixTrim(tmp1);
			var tmp2 = Etc.fixTrim(tmp.substring(pos2));
			tmp2 = Etc.delTailStr(tmp2, ")");

			if (Unit.isExist(tmp2) == false) {
				return res = tmp1;
			}

			tmp2 = Etc.delStr(tmp2, UnitVal.listDelStr);
			res = tmp1 + "(" + tmp2 + ")";
		} catch (Exception ex) {
			WB.addLog("UnitVal.fixStrUnit(String):String, ex=" + ex.getMessage(), "", "UnitVal");
		}
		return res;
	}

	public static String cleanStrUnit(String src) throws Exception {
		// origin - 11.11.2026, last edit - 11.11.2026
		String res = "";
		try {
			if (Etc.strNotValid(src)) {
				return res;
			}
			var tmp = Etc.fixTrim(src);
			int pos1 = tmp.indexOf("("); // pos "("
			if (pos1 > 0) {
				tmp = Etc.fixTrim(tmp.substring(0, pos1));
			}
			int pos2 = tmp.indexOf("Unit."); // pos "Unit."
			if (pos2 > 0) {
				tmp = Etc.fixTrim(tmp.substring(0, pos2));
			}
			res = tmp;
		} catch (Exception ex) {
			WB.addLog("UnitVal.cleanStrUnit(String):String, ex=" + ex.getMessage(), "", "UnitVal");
		}
		return res;
	}

	public static UnitVal divide(List<UnitVal> unitValList, String toUnit) throws Exception {
		// origin - 01.09.2026, last edit - 15.10.2026
		UnitVal res = new UnitVal();
		try {
			if (Etc.strNotValid(toUnit)) {
				return res;
			}
			if (unitValList.size() == 0) {
				return res;
			}

//			var tmp1 = new Unit(toUnit);
//			if (tmp1.code.isEmpty()) {
//				res = UnitVal.divide(unitValList);
//				return res;
//			}

			unitValList = UnitVal.getConvListForDivide(unitValList, toUnit);
			var tmp2 = UnitVal.divide(unitValList);
			// var tmp3 = UnitVal.getExistUnitCodeDivideByListUnitVal(unitValList);
			res = new UnitVal(tmp2.val, "Unit.Ratio");// tmp3);
		} catch (Exception ex) {
			WB.addLog("UnitVal.divide(List<UnitVal>, String):UnitVal, ex=" + ex.getMessage(), "", "UnitVal");
		}
		return res;
	}

	private static UnitVal divide(List<UnitVal> unitValList) throws Exception {
		// origin - 01.09.2026, last edit - 01.09.2026
		UnitVal res = new UnitVal();
		try {
			if (unitValList.size() == 0) {
				return res;
			}

			if (unitValList.size() == 1) {
				return res = unitValList.getFirst();
			}

			res = unitValList.getFirst();
			var tmp = new UnitVal();
			for (int i = 1; i < unitValList.size(); i++) {
				tmp = unitValList.get(i);
				res = UnitVal.getDivide(res, tmp);
			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.divide(List<UnitVal>):UnitVal, ex=" + ex.getMessage(), "", "UnitVal");
		}
		return res;
	}

	public static UnitVal multiply(List<UnitVal> unitValList, String toUnit) throws Exception {
		// origin - 15.02.2025, last edit - 15.10.2026
		UnitVal res = new UnitVal();
		try {
			if (Etc.strNotValid(toUnit)) {
				return res;
			}
			if (unitValList.size() == 0) {
				return res;
			}

			var tmp1 = new Unit(toUnit);
			if (tmp1.code.isEmpty()) {
				res = UnitVal.multiply(unitValList);
				return res;
			}

			unitValList = UnitVal.getConvListForMultiply(unitValList, toUnit);
			var tmp2 = UnitVal.multiply(unitValList);
			var tmp3 = UnitVal.getExistUnitCodeMultiplyByListUnitVal(unitValList);
			res = new UnitVal(tmp2.val, tmp3);
		} catch (Exception ex) {
			WB.addLog("UnitVal.multiply(List<UnitVal>, String):UnitVal, ex=" + ex.getMessage(), "", "UnitVal");
		}
		return res;
	}

	private static UnitVal multiply(List<UnitVal> unitValList) throws Exception {
		// origin - 14.02.2025, last edit - 24.07.2025
		UnitVal res = new UnitVal();
		try {
			if (unitValList.size() == 0) {
				return res;
			}

			if (unitValList.size() == 1) {
				return res = unitValList.getFirst();
			}

			res = unitValList.getFirst();
			var tmp = new UnitVal();
			for (int i = 1; i < unitValList.size(); i++) {
				tmp = unitValList.get(i);
				res = UnitVal.getMultiply(res, tmp);
			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.multiply(List<UnitVal>):UnitVal, ex=" + ex.getMessage(), "", "UnitVal");
		}
		return res;
	}

	private static List<UnitVal> getConvListForDivide(List<UnitVal> unitValList, String toUnit) throws Exception {
		// origin - 02.09.2026, last edit - 15.10.2026
		List<UnitVal> res = new ArrayList<UnitVal>();
		var tmp1 = new UnitVal();
		try {
			if (Etc.strNotValid(toUnit)) {
				return res;
			}

			var tmp2 = new Unit(toUnit); // not exist code=toUnit
			if (tmp2.code.isEmpty()) {
				return unitValList;
			}

			for (var curr : unitValList) {
				if (curr.unit != null) {
					if (Etc.strEquals(curr.unit.code, toUnit)) {
						res.add(curr);
						continue;
					}
				}

				tmp1 = UnitVal.conv(curr, toUnit, "");
				if (tmp1.val != 0) {
					res.add(tmp1);
					continue;
				}

				if (tmp1.val == 0) {
					res.add(new UnitVal(curr.val, ""));
					continue;
				}
			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.getConvListForDivide(List<UnitVal>):List<UnitVal>, ex=" + ex.getMessage(), "",
					"UnitVal");
		}
		return res;
	}

	private static List<UnitVal> getConvListForMultiply(List<UnitVal> unitValList, String toUnit) throws Exception {
		// origin - 23.07.2026, last edit - 15.10.2026
		List<UnitVal> res = new ArrayList<UnitVal>();
		var tmp1 = new UnitVal();
		try {
			if (Etc.strNotValid(toUnit)) {
				return res;
			}
			var tmp2 = new Unit(toUnit); // not exist code=toUnit
			if (tmp2.code.isEmpty()) {
				return unitValList;
			}

			for (var curr : unitValList) {
				if (curr.unit != null) {
					if (Etc.strEquals(curr.unit.code, toUnit)) {
						res.add(curr);
						continue;
					}
				}

				tmp1 = UnitVal.conv(curr, toUnit, "");
				if (tmp1.val != 0) {
					res.add(tmp1);
					continue;
				}

				if (tmp1.val == 0) {
					res.add(new UnitVal(curr.val, ""));
					continue;
				}
			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.getConvListForMultiply(List<UnitVal>):List<UnitVal>, ex=" + ex.getMessage(), "",
					"UnitVal");
		}
		return res;
	}

	private static UnitVal getDivide(UnitVal unitVal1, UnitVal unitVal2) throws Exception {
		// origin - 01.09.2026, last edit - 15.09.2026
		UnitVal res = new UnitVal();
		double res1 = 1.0;
		try {
			var toUnit = "";

			if (unitVal1.partUnit.isEmpty()) { // 1,2 less unit
				if (unitVal2.partUnit.isEmpty()) {
					res1 = Num.divide(unitVal1.val, unitVal2.val);
					res = new UnitVal(res1, toUnit);
					return res;
				}
			}

			if (unitVal1.partUnit.isEmpty() == false) { // 2 less unit
				if (unitVal2.partUnit.isEmpty()) {
					toUnit = UnitVal.getExistUnitCodeByUnitVal(unitVal1);
					res1 = Num.divide(unitVal1.val, unitVal2.val);
					res = new UnitVal(res1, toUnit);
					return res;
				}
			}

			if (unitVal1.partUnit.isEmpty()) { // 1 less unit
				if (unitVal2.partUnit.isEmpty() == false) {
					toUnit = UnitVal.getExistUnitCodeByUnitVal(unitVal2);
					res1 = Num.divide(unitVal1.val, unitVal2.val);
					res = new UnitVal(res1, toUnit);
					return res;
				}
			}

			if (Unit.isCurrency(unitVal1.partUnit)) { // 1,2 is currency
				if (Unit.isCurrency(unitVal2.partUnit)) {
					toUnit = UnitVal.getExistUnitCodeByUnitVal(unitVal2);
					res1 = Num.divide(unitVal1.val, unitVal2.val);
					res = new UnitVal(res1, toUnit);
					return res;
				}
			}

			if (Unit.isCurrency(unitVal1.partUnit)) { // 1 is currency
				if (Unit.isCurrency(unitVal2.partUnit) == false) {
					toUnit = UnitVal.getExistUnitCodeByUnitVal(unitVal1);
					res1 = Num.divide(unitVal1.val, unitVal2.val);
					res = new UnitVal(res1, toUnit);
					return res;
				}
			}

			if (Unit.isCurrency(unitVal2.partUnit)) { // 2 is currency
				if (Unit.isCurrency(unitVal1.partUnit) == false) {
					toUnit = UnitVal.getExistUnitCodeByUnitVal(unitVal2);
					res1 = Num.divide(unitVal1.val, unitVal2.val);
					res = new UnitVal(res1, toUnit);
					return res;
				}
			}

			if (unitVal1.partUnit.isEmpty() == false) { // 1,2 with unit
				if (unitVal2.partUnit.isEmpty() == false) {
					toUnit = UnitVal.getExistUnitCodeBy2UnitVal(unitVal1, unitVal2);
					var fromUnit = UnitVal.getExistUnitCodeByUnitVal(unitVal2);

					var tmp = unitVal2;
					if (toUnit.isEmpty() == false) {
						if (fromUnit.isEmpty() == false) {
							if (Etc.strEquals(toUnit, fromUnit) == false) {
								tmp = UnitVal.conv(unitVal2, toUnit, "");
							}

							if (tmp.val != 0.0) {
								res1 = Num.divide(unitVal1.val, tmp.val);
							}
							if (tmp.val == 0.0) {
								res1 = Num.divide(unitVal1.val, unitVal2.val);
							}
							res = new UnitVal(res1, toUnit);
							return res;
						}
					}

					if (toUnit.isEmpty()) {
						res1 = Num.divide(unitVal1.val, unitVal2.val);
						res = new UnitVal(res1, fromUnit);
						return res;
					}

					if (fromUnit.isEmpty()) {
						res1 = Num.divide(unitVal1.val, unitVal2.val);
						res = new UnitVal(res1, toUnit);
						return res;
					}
				}
			}

		} catch (Exception ex) {
			WB.addLog("UnitVal.getDivide(2UnitVal):UnitVal, ex=" + ex.getMessage(), "", "UnitVal");
		}
		return res;
	}

	private static UnitVal getMultiply(UnitVal unitVal1, UnitVal unitVal2) throws Exception {
		// origin - 20.07.2026, last edit - 16.09.2026
		UnitVal res = new UnitVal();
		double res1 = 1.0;
		try {
			var toUnit = "";

			if (unitVal1.partUnit.isEmpty()) { // 1,2 less unit
				if (unitVal2.partUnit.isEmpty()) {
					res1 = Num.multiply(unitVal1.val, unitVal2.val);
					res = new UnitVal(res1, toUnit);
					return res;
				}
			}

			if (unitVal1.partUnit.isEmpty() == false) { // 2 less unit
				if (unitVal2.partUnit.isEmpty()) {
					toUnit = UnitVal.getExistUnitCodeByUnitVal(unitVal1);
					res1 = Num.multiply(unitVal1.val, unitVal2.val);
					res = new UnitVal(res1, toUnit);
					return res;
				}
			}

			if (unitVal1.partUnit.isEmpty()) { // 1 less unit
				if (unitVal2.partUnit.isEmpty() == false) {
					toUnit = UnitVal.getExistUnitCodeByUnitVal(unitVal2);
					res1 = Num.multiply(unitVal1.val, unitVal2.val);
					res = new UnitVal(res1, toUnit);
					return res;
				}
			}

			if (Unit.isCurrency(unitVal1.partUnit)) { // 1,2 is currency
				if (Unit.isCurrency(unitVal2.partUnit)) {
					toUnit = UnitVal.getExistUnitCodeByUnitVal(unitVal2);
					res1 = Num.multiply(unitVal1.val, unitVal2.val);
					res = new UnitVal(res1, toUnit);
					return res;
				}
			}

			if (Unit.isCurrency(unitVal1.partUnit)) { // 1 is currency
				if (Unit.isCurrency(unitVal2.partUnit) == false) {
					toUnit = UnitVal.getExistUnitCodeByUnitVal(unitVal1);
					res1 = Num.multiply(unitVal1.val, unitVal2.val);
					res = new UnitVal(res1, toUnit);
					return res;
				}
			}

			if (Unit.isCurrency(unitVal2.partUnit)) { // 2 is currency
				if (Unit.isCurrency(unitVal1.partUnit) == false) {
					toUnit = UnitVal.getExistUnitCodeByUnitVal(unitVal2);
					res1 = Num.multiply(unitVal1.val, unitVal2.val);
					res = new UnitVal(res1, toUnit);
					return res;
				}
			}

			if (unitVal1.partUnit.isEmpty() == false) { // 1,2 with unit
				if (unitVal2.partUnit.isEmpty() == false) {
					toUnit = UnitVal.getExistUnitCodeBy2UnitVal(unitVal1, unitVal2);// UnitVal.getExistUnitCodeByUnitVal(unitVal1);
					var fromUnit = UnitVal.getExistUnitCodeByUnitVal(unitVal2);

					var tmp = unitVal2;
					if (toUnit.isEmpty() == false) {
						if (fromUnit.isEmpty() == false) {
							if (Etc.strEquals(toUnit, fromUnit) == false) {
								tmp = UnitVal.conv(unitVal2, toUnit, "");
							}

							// res1 = Etc.multiply(unitVal1.val, unitVal2.val);
							if (tmp.val != 0.0) {
								res1 = Num.multiply(unitVal1.val, tmp.val);
							}
							if (tmp.val == 0.0) {
								res1 = Num.multiply(unitVal1.val, unitVal2.val);
							}
							res = new UnitVal(res1, toUnit);
							return res;
						}
					}

					if (toUnit.isEmpty()) {
						res1 = Num.multiply(unitVal1.val, unitVal2.val);
						res = new UnitVal(res1, fromUnit);
						return res;
					}

					if (fromUnit.isEmpty()) {
						res1 = Num.multiply(unitVal1.val, unitVal2.val);
						res = new UnitVal(res1, toUnit);
						return res;
					}
				}
			}

		} catch (Exception ex) {
			WB.addLog("UnitVal.getMultiply(2UnitVal):UnitVal, ex=" + ex.getMessage(), "", "UnitVal");
		}
		return res;
	}

//	private static String getExistUnitCodeDivideByListUnitVal(List<UnitVal> listUnitVal) throws Exception {
//		// origin - 02.09.2026, last edit - 03.09.2026
//		String res = "";
//		try {
//			int count = 0;
//			String tmp1 = "";
//			for (var curr : listUnitVal) {
//				if (curr.unit == null) {
//					continue;
//				}
//				count = count + 1;
//				switch (count) {
//				case 1 -> {
//					tmp1 = curr.unit.code;
//					break;
//				}
//				case 2, 3, 4, 5 -> {
//					break;
//				}
//				}
//			}
//
//			var tmp2 = new Unit(tmp1);
//			if (tmp2.code.isEmpty() == false) {
//				res = tmp2.code;
//			}
//			if (tmp2.code.isEmpty()) {
//				res = "";
//			}
//		} catch (Exception ex) {
//			WB.addLog("UnitVal.getExistUnitCodeDivideByListUnitVal(List<UnitVal>):String, ex=" + ex.getMessage(), "",
//					"UnitVal");
//		}
//		return res;
//	}

	private static String getExistUnitCodeMultiplyByListUnitVal(List<UnitVal> listUnitVal) throws Exception {
		// origin - 23.07.2026, last edit - 10.09.2026
		String res = "";
		try {
			int count = 0;
			String tmp1 = "";
			for (var curr : listUnitVal) {
				if (curr.unit == null) {
					continue;
				}
				count = count + 1;
				switch (count) {
				case 1 -> {
					tmp1 = curr.unit.code;
					break;
				}
				case 2 -> {
					var tmp = MoreVal.getFieldByKey(curr.unit.more, "Squared");
					if (tmp.isEmpty() == false) {
						tmp1 = tmp; // 2X
					}
					break;
				}
				case 3 -> {
					var tmp = MoreVal.getFieldByKey(curr.unit.more, "Cubed");
					if (tmp.isEmpty() == false) {
						tmp1 = tmp; // 3X
					}
					break;
				}
				case 4 -> {
					tmp1 = curr.unit.code; // i dont know what unit be for 4X
					break;
				}
				case 5 -> {
					tmp1 = curr.unit.code; // i dont know what unit be for 4X
					break;
				}
//				default -> {
//					tmp1=curr.unit.code;
//				}
				}
			}

			var tmp2 = new Unit(tmp1);
			if (tmp2.code.isEmpty() == false) {
				res = tmp2.code;
			}
			if (tmp2.code.isEmpty()) {
				res = "";
			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.getExistUnitCodeMultiplyByListUnitVal(List<UnitVal>):String, ex=" + ex.getMessage(), "",
					"UnitVal");
		}
		return res;
	}

	public static String getExistUnitCodeByUnitVal(UnitVal uv) throws Exception {
		// origin - 20.07.2026, last edit - 25.07.2026
		String res = "";
		try {
			var tmp = new Unit();
			if (uv.partUnit.isEmpty() == false) {
				tmp = new Unit(uv.unit.code);
				if (tmp.code.isEmpty() == false) {
					res = tmp.code;
				}
			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.getExistUnitCodeByUnitVal(UnitVal):String, ex=" + ex.getMessage(), "", "UnitVal");
		}
		return res;
	}

	public static String getExistUnitCodeBy2UnitVal(UnitVal uv1, UnitVal uv2) throws Exception {
		// origin - 20.07.2026, last edit - 22.07.2026
		String res = "";
		try {
			res = UnitVal.getExistUnitCodeByUnitVal(uv1);

			if (res.isEmpty()) {// if (uv1.partUnit.isEmpty()) {
				if (uv2.partUnit.isEmpty() == false) {
					var tmp = new Unit(uv2.unit.code);
					if (tmp.code.isEmpty() == false) {
						res = tmp.code;
						return res;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.getExistUnitCodeBy2UnitVal(2UnitVal):String, ex=" + ex.getMessage(), "", "UnitVal");
		}
		return res;
	}

	public static UnitVal add(UnitVal add1, UnitVal add2) throws Exception {
		// origin - 18.08.2025, last edit - 15.09.2026
		UnitVal res = new UnitVal();
		double res1 = 0.0;
		UnitVal tmp = new UnitVal();
		String currToCode = add1.unit.code;
		try {
			if (add2.val != 0.0) {
				if (add2.unit.code.isEmpty() == false) {
					tmp = UnitVal.conv(add2, currToCode, "");
					res1 = Num.add(add1.val, tmp.val);
				}
			} else {
				res1 = add1.val;
			}
			res = new UnitVal(res1, currToCode);
		} catch (Exception ex) {
			WB.addLog("UnitVal.add(2UnitVal):UnitVal, ex=" + ex.getMessage(), "", "UnitVal");
		}
		return res;
	}

	public static UnitVal add(List<UnitVal> adds) throws Exception {// (same unit)
		// origin - 15.02.2025, last edit - 15.09.2026
		UnitVal res = new UnitVal();
		double res1 = 0.0;
		try {
			UnitVal tmp = new UnitVal();
			String currToCode = "";
			for (var curr : adds) {
				currToCode = curr.unit.code;
				tmp = UnitVal.conv(curr, currToCode, "");
				if (tmp.val != 0.0) {
					res1 = Num.add(res1, tmp.val);
				}
			}
			res = new UnitVal(res1, currToCode);
		} catch (Exception ex) {
			WB.addLog("UnitVal.add(List<UnitVal>):UnitVal, ex=" + ex.getMessage(), "", "UnitVal");
		}
		return res;
	}

	public static UnitVal add(List<UnitVal> adds, String toUnit) throws Exception {
		// origin - 14.02.2025, last edit - 15.10.2026
		UnitVal res = new UnitVal();
		double res1 = 0.0;
		try {
			if (Etc.strNotValid(toUnit)) {
				return res;
			}
			UnitVal tmp = new UnitVal();
			for (var curr : adds) {
				tmp = UnitVal.conv(curr, toUnit, "");
				res1 = Num.add(res1, tmp.val);
			}
			res = new UnitVal(res1, toUnit);
		} catch (Exception ex) {
			WB.addLog("UnitVal.add(List<UnitVal>, String):UnitVal, ex=" + ex.getMessage(), "", "UnitVal");
		}
		return res;
	}

	public static UnitVal conv(UnitVal fromUnitVal, String toUnit, String context) throws Exception {
		// origin - 29.01.2025, last edit - 15.10.2026
		UnitVal res = new UnitVal();
		try {
			if (Etc.strNotValid(toUnit)) {
				return res;
			}
			if (fromUnitVal.unit != null) {
				if (toUnit.isEmpty() == false) {
					UnitVal conv = Unit.сonv(fromUnitVal.unit.code, toUnit, context);
					res = new UnitVal(Num.multiply(conv.val, fromUnitVal.val), conv.unit.code);
				}
			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.conv(UnitVal, 2String):UnitVal, ex=" + ex.getMessage(), "", "UnitVal");
		}
		return res;
	}

	public static List<UnitVal> getList(List<String> in) throws Exception {
		// origin - 23.07.2026, last edit - 23.07.2026
		List<UnitVal> res = new ArrayList<UnitVal>();
		try {
			for (var curr : in) {
				res.add(new UnitVal(curr));
			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.getList(List<String>):List<UnitVal>, ex=" + ex.getMessage(), "", "UnitVal");
		}
		return res;
	}

	private void getId() throws Exception {
		// origin - 01.12.2024, last edit - 23.07.2026
		try {
			if (val != 0.0) {
				this.id = this.id + this.partName + " " + String.valueOf(val);
			}

			if ((val == 0.0) & (partVal.isEmpty() == false)) {
				this.id = this.id + this.partName + " " + partVal;
			}

			if (this.partUnit.isEmpty() == false) {
				// this.id = this.id + " " + this.unit.code + ", " + this.unit.description;
				this.id = this.id + " " + this.unit.code;
			}

			if (this.partUnit.isEmpty() && this.partVal.isEmpty()) {
				this.id = "";
			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.getId():void, ex=" + ex.getMessage(), "", "UnitVal");
		}
	}

	private void getPart() throws Exception {
		// origin - 14.09.2024, last edit - 15.10.2025
		try {
			String tmp = this.src;
			int posMiddleEquation = tmp.indexOf("="); // pos "="
			if (posMiddleEquation > 0) {
				this.partName = Etc.fixTrim(tmp.substring(0, posMiddleEquation));
				tmp = Etc.delStr(tmp, this.partName);
				tmp = Etc.delStr(tmp, "=");
			}

			int posLocalSplitValUnit = tmp.indexOf("(Unit.");
			if (posLocalSplitValUnit > 0) {
				this.partVal = Etc.fixTrim(tmp.substring(0, posLocalSplitValUnit));
				this.partUnit = Etc.fixTrim(tmp.substring(posLocalSplitValUnit));
				this.partUnit = Etc.delStr(this.partUnit, UnitVal.listDelStr);
			}

			if (this.partUnit.isEmpty()) {
				this.partVal = Etc.fixTrim(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.getPart():void, ex=" + ex.getMessage(), "", "UnitVal");
		}
	}

	public void getUnit() throws Exception {
		// origin - 02.06.2025, last edit - 10.09.2026
		try {
			if (this.partUnit.isEmpty() == false) {
				this.unit = new Unit(this.partUnit);
				this.context = MoreVal.getFieldByKey(this.unit.more, "ExpectedValue");
			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.getUnit():void, ex=" + ex.getMessage(), "", "UnitVal");
		}
	}

	private void getVal() throws Exception {
		// origin - 13.09.2024, last edit - 15.10.2026
		try {
			this.getUnit();
			if (Etc.strEquals(partVal, "?") == false) {// if "?" then not written double
				this.val = Num.getDoubleByStr(this.partVal);
			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.getVal():void, ex=" + ex.getMessage(), "", "UnitVal");
		}
	}

	public UnitVal(double Val, String Unit) throws Exception {
		// origin - 16.01.2025, last edit - 20.03.2025
		this();
		// clean, because may be alone chars "(" and\or ")" //??
		Unit = Etc.delStr(Unit, "(");
		Unit = Etc.delStr(Unit, ")");
		this.src = Etc.fixTrim(String.valueOf(Val)) + "(" + Unit + ")";
		this.getPart();
		this.getVal();
		this.getId();
	}

	public UnitVal(String Val, String Unit) throws Exception {
		// origin - 18.09.2024, last edit - 20.03.2025
		this();
		// clean, because may be alone chars "(" and\or ")" //??
		Unit = Etc.delStr(Unit, "(");
		Unit = Etc.delStr(Unit, ")");
		this.src = Etc.fixTrim(String.valueOf(Val)) + "(" + Unit + ")";
		this.getPart();
		this.getVal();
		this.getId();
	}

	public UnitVal(String Src) throws Exception {
		// origin - 13.09.2024, last edit - 01.12.2024
		this();
		this.src = Etc.fixTrim(Src);
		this.getPart();
		this.getVal();
		this.getId();
	}

	public UnitVal() throws Exception {
		// origin - 13.09.2024, last edit - 02.06.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 02.06.2025, last edit - 06.09.2025
		try {
			this.id = this.context = this.src = this.partName = this.name = this.partUnit = "";
			this.partVal = "";
			this.val = 0.0;
			this.unit = null;
		} catch (Exception ex) {
			WB.addLog("UnitVal.clear():void, ex=" + ex.getMessage(), "", "UnitVal");
		}
	}

	public static boolean listValid(List<UnitVal> inList) throws Exception {
		// origin - 11.11.2026, last edit - 11.11.2026
		boolean res = true;
		try {
			if (inList == null) {
				res = false;
			}
			if (inList.size() == 0) {
				res = false;
			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.listValid(List<UnitVal>):boolean, ex=" + ex.getMessage(), "", "UnitVal");
		}
		return res;
	}

	public static String toStringMap(Map<String, UnitVal> inMap) throws Exception {
		// origin - 11.11.2026, last edit - 11.11.2026
		String res = "";
		try {
			List<String> tmp = new ArrayList<String>();
			for (Map.Entry<String, UnitVal> entry : inMap.entrySet()) {
				String key = entry.getKey();
				String value = entry.getValue().id;
				tmp.add(key + " = " + value);
			}
			res = tmp.toString();
		} catch (Exception ex) {
			WB.addLog("UnitVal.toStringList(List<UnitVal>):String, ex=" + ex.getMessage(), "", "UnitVal");
		}
		return res;
	}

	public static String toStringList(List<UnitVal> inList) throws Exception {
		// origin - 17.09.2026, last edit - 11.11.2026
		String res = "";
		try {
			List<String> tmp = new ArrayList<String>();
			if (UnitVal.listValid(inList)) {
				for (var curr : inList) {
					tmp.add(curr.id);
				}
			}
			res = tmp.toString();
		} catch (Exception ex) {
			WB.addLog("UnitVal.toStringList(List<UnitVal>):String, ex=" + ex.getMessage(), "", "UnitVal");
		}
		return res;
	}

	public String toString() {
		// origin - 13.09.2024, last edit - 22.07.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", context ", this.context);
			res = res + Fmtr.addIfNotEmpty(", partName ", this.partName);
			res = res + Fmtr.addIfNotEmpty(", name ", this.name);
			res = res + Fmtr.addIfNotEmpty(", partUnit ", this.partUnit);
			res = res + Fmtr.addIfNotEmpty(", unit.id ", this.unit.id);
			res = res + Fmtr.addIfNotEmpty(", partVal ", this.partVal);
			res = res + Fmtr.addIfNotEmpty(", val ", this.val);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static String listToStr(List<UnitVal> inList, String context) throws Exception {
		// origin - 19.07.2026, last edit - 24.07.2026
		String res = "";
		try {
			for (var tmp : inList) {
				res = res + tmp.id;
				if (inList.getLast() != tmp) {
					res = res + ",";
				}
			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.listToStr (List<UnitVal>, String):String, ex=" + ex.getMessage(), "", "UnitVal");
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 13.09.2024, last edit - 13.11.2026
		try {

//			WB.addLog2("UnitVal.test.fixStrUnit(String)", "", "UnitVal");
//			for (var tmp1 : new String[] { null, "", "12.00(Unit.MinRate)", "12.00 (Unit.MinRate)",
//					"12.00 Unit.MinRate)", "12.00Unit.MinRate)", "1.7", "17,00", "4 Unit.MinRate", "4Unit.MinRate",
//					"2.0Unit.Tralala", "2.0 Unit.Tralala", "2.0 (Unit.Tralala)", "2.0(Unit.Tralala)" }) {
//				WB.addLog2("UnitVal.test.fixStrUnit(String), res=" + UnitVal.fixStrUnit(tmp1) + ", tmp1=" + tmp1, "",
//						"UnitVal");
//			}

//			WB.addLog2("UnitVal.test.cleanStrUnit(String)", "", "UnitVal");
//			for (var tmp1 : new String[] { null, "", "12.00 (Unit.MinRate)", "12.00(Unit.MinRate)", "1.7", "17,00",
//					"4 Unit.MinRate", "4Unit.MinRate", "2.0(Unit.Tralala)" }) {
//				WB.addLog2("UnitVal.test.cleanStrUnit(String), res=" + UnitVal.cleanStrUnit(tmp1) + ", tmp1=" + tmp1,
//						"", "UnitVal");
//			}

//			{
//				WB.addLog2("UnitVal.test.divide(List<UnitVal>;String)", "", "UnitVal");
//				var tmp1 = new SawListVal(
//						"3.0(Unit.Gr)|5.0(Unit.KZT)|5.0(Unit.EUR)|5.0(Unit.Mm)|5.0(Unit.Meter)|5.0(Unit.Tralala)|"
//								+ "3.0(Unit.Gr);5.0(Unit.KZT)|3.0(Unit.Gr);5.0(Unit.EUR)|5.0(Unit.EUR);5.0(Unit.KZT)|"
//								+ "3.0(Unit.Gr);5.0(Unit.Gr)|3.0(Unit.EUR);5.0(Unit.EUR)|3.0(Unit.KZT);5.0(Unit.KZT)|"
//								+ "3.0(Unit.Gr);5.0(Unit.Tralala)|3.0(Unit.EUR);5.0(Unit.Tralala)|3.0(Unit.KZT);5.0(Unit.Tralala)|"
//								+ "5.2(Unit.Mm);5.2(Unit.Mm)|6.999(Unit.Meter);5.2(Unit.Mm)|"
//								+ "3.0(Unit.KZT);5.0(Unit.KZT)|2.0(Unit.Tralala);5.0(Unit.Tralala)|"
//								+ "6.99(Unit.KZT);5.2(Unit.KZT)|5.2(Unit.Mm);6.999(Unit.Meter)|");
//				var count = 0;
//				for (var tmp2 : tmp1.val) {
//					count = count + 1;
//					var tmp3 = UnitVal.getList(List.of(tmp2.split(";")));
//					var tmp4 = List.of("Unit.Gr", "Unit.KZT", "Unit.EUR", "Unit.Mm", "Unit.Meter", "Unit.Tralala");
//					for (var tmp5 : tmp4) {
//						WB.addLog2("UnitVal.test.divide(List<UnitVal>,String), res=" + UnitVal.divide(tmp3, tmp5).id
//								+ ", tmp3=" + UnitVal.listToStr(tmp3, "") + ", tmp5=" + tmp5, "", "UnitVal");
//					}
//				}
//			}

//			{
//				WB.addLog2("UnitVal.test.multiply(List<UnitVal>;String)", "", "UnitVal");
//				var tmp1 = new SawListVal(
//						"3.0(Unit.Gr)|5.0(Unit.KZT)|5.0(Unit.EUR)|5.0(Unit.Mm)|5.0(Unit.Meter)|5.0(Unit.Tralala)|"
//								+ "3.0(Unit.Gr);5.0(Unit.KZT)|3.0(Unit.Gr);5.0(Unit.EUR)|5.0(Unit.EUR);5.0(Unit.KZT)|"
//								+ "3.0(Unit.Gr);5.0(Unit.Gr)|3.0(Unit.EUR);5.0(Unit.EUR)|3.0(Unit.KZT);5.0(Unit.KZT)|"
//								+ "3.0(Unit.Gr);5.0(Unit.Tralala)|3.0(Unit.EUR);5.0(Unit.Tralala)|3.0(Unit.KZT);5.0(Unit.Tralala)|"
//								+ "3.0(Unit.Tralala);2.0(Unit.Gr);5.0(Unit.EUR)|3.0(Unit.KZT);2.0(Unit.Gr);5.0(Unit.EUR)|"
//								+ "5.2(Unit.Mm);6.999(Unit.Meter);5.2(Unit.Mm)|5.2(Unit.Gr);6.999(Unit.Meter);5.2(Unit.Mm)|"
//								+ "3.0(Unit.KZT);5.0(Unit.KZT);4.0(Unit.KZT)|3.0(Unit.Gr);5.0(Unit.KZT);4.0(Unit.KZT)|"
//								+ "3.0(Unit.Tralala);2.0(Unit.Tralala);5.0(Unit.Tralala)|3.0(Unit.Mm);2.0(Unit.Mm);5.0(Unit.Mm)|"
//								+ "5.2(Unit.Mm);6.2(Unit.Mm);6.999(Unit.Meter);5.2(Unit.Mm)|"
//								+ "5.2(Unit.Mm);6.2(Unit.Mm);6.0(Unit.Mm);5.2(Unit.Mm)|"
//								+ "5.2(Unit.KZT);6.2(Unit.KZT);6.99(Unit.KZT);5.2(Unit.KZT)|"
//								+ "3.0(Unit.Gr);5.0(Unit.EUR);5.0(Unit.KZT);5.2(Unit.Mm);6.999(Unit.Meter)|"
//								+ "3.0(Unit.Gr);5.0(Unit.Gr);5.0(Unit.Gr);5.2(Unit.Gr);6.999(Unit.Gr)|"
//								+ "3.0(Unit.Mm);5.0(Unit.Mm);5.0(Unit.Mm);5.2(Unit.Mm);6.0(Unit.Mm)|"
//								+ "3.0(Unit.KZT;5.0(Unit.KZT);5.0(Unit.KZT);5.2(Unit.KZT);6.0(Unit.KZT)|"
//								+ "3.0(Unit.Tralala);3.0(Unit.Gr);5.0(Unit.EUR);5.0(Unit.KZT);4.2(Unit.Mm);7.999(Unit.Meter)|");
//				var count = 0;
//				for (var tmp2 : tmp1.val) {
//					count = count + 1;
//					var tmp3 = UnitVal.getList(List.of(tmp2.split(";")));
//					var tmp4 = List.of("Unit.Gr", "Unit.KZT", "Unit.EUR", "Unit.Mm", "Unit.Meter", "Unit.Tralala");
//					for (var tmp5 : tmp4) {
//						WB.addLog2(
//								"UnitVal.test.multiply(List<UnitVal>,String), res=" + UnitVal.multiply(tmp3, tmp5).id
//										+ ", tmp3=" + UnitVal.listToStr(tmp3, "") + ", tmp5=" + tmp5,
//								"", "UnitVal");
//					}
//				}
//			}

//			{
//				WB.addLog2("UnitVal.test.getConvListForMultiply(List<UnitVal>)", "", "UnitVal");
//				var tmp1 = new SawListVal(
//						"3.0(Unit.Gr);5.0(Unit.KZT)|3.0(Unit.Gr);5.0(Unit.EUR)|5.0(Unit.EUR);5.0(Unit.KZT)|"
//								+ "5.2(Unit.Mm);6.999(Unit.Meter)|3.0(Unit.Gr);5.0(Unit.EUR);5.0(Unit.KZT);5.2(Unit.Mm);6.999(Unit.Meter)|"
//								+ "3.0(Unit.Tralala);3.0(Unit.Gr);5.0(Unit.EUR);5.0(Unit.KZT);4.2(Unit.Mm);7.999(Unit.Meter)|");
//				for (var tmp2 : tmp1.val) {
//					var tmp3 = UnitVal.getList(List.of(tmp2.split(";")));
//					var tmp4 = List.of("Unit.Gr", "Unit.KZT", "Unit.EUR", "Unit.Mm", "Unit.Meter", "Unit.Tralala");
//					for (var tmp5 : tmp4) {
//						WB.addLog2("UnitVal.test.getConvListForMultiply(List<UnitVal>), res="
//								+ UnitVal.listToStr(UnitVal.getConvListForMultiply(tmp3, tmp5), "") + ", tmp3="
//								+ UnitVal.listToStr(tmp3, "") + ", tmp5=" + tmp5, "", "UnitVal");
//					}
//				}
//			}

//			{
//				WB.addLog2("UnitVal.test.getMultiply(2UnitVal)", "", "UnitVal");
//				var tmp1 = new String[] { "0.0", "6.0", "0.0(Unit.Tralala)", "3.0(Unit.Tralala)", "0.0(Unit.Gr)",
//						"3.0(Unit.Gr)", "5.0(Unit.EUR)", "5.0(Unit.KZT)", "4.2(Unit.Mm)", "7.999(Unit.Meter)" };
//				var tmp2 = new String[] { "0.0", "2.0", "0.0(Unit.Tralala)", "3.0(Unit.Tralala)", "0.0(Unit.Gr)",
//						"3.0(Unit.Gr)", "5.0(Unit.EUR)", "5.0(Unit.KZT)", "5.2(Unit.Mm)", "6.999(Unit.Meter)" };
//				for (var tmp11 : tmp1) {
//					for (var tmp22 : tmp2) {
//						WB.addLog2("UnitVal.test.getMultiply(2UnitVal), res="
//								+ UnitVal.getMultiply(new UnitVal(tmp11), new UnitVal(tmp22)).id + ", tmp11=" + tmp11
//								+ ", tmp22=" + tmp22, "", "UnitVal");
//					}
//				}
//			}

//			{
//				WB.addLog2("UnitVal.test.multiply(List<UnitVal>)", "", "UnitVal");
//				var tmp1 = new String[] { "6.0(Unit.Gr)", "3.0(Unit.Mm)", "4.2(Unit.Mm)", "7.999(Unit.Mm)" };
//				var tmp2 = new String[] { "2.0(Unit.Cm)", "3.0(Unit.Cm)", "5.2(Unit.Cm)", "6.999(Unit.Cm)" };
//				for (var tmp11 : tmp1) {
//					for (var tmp22 : tmp2) {
//						var tmp3 = List.of(new UnitVal(tmp11), new UnitVal(tmp22));
//						WB.addLog2("UnitVal.test.multiply (List<UnitVal>), res=" + UnitVal.multiply(tmp3).id + ", tmp3="
//								+ UnitVal.listToStr(tmp3, ""), "", "UnitVal");
//					}
//				}
//			}

//			// add (n time)
//			var adds = 1.99;
//			for (var addArg1 : new int[] { 10, 100, 1000, 10000, 100000, 1000000 }) {
//				var tmp = 0.0;
//				for (int i = 0; i < addArg1; i++) {
//					// tmp = tmp + adds; //its wrong
//					tmp = Etc.add(tmp, adds);
//				}
//				WB.addLog2("UnitVal.test.add (n time), res=" + new UnitVal(tmp, "(Unit.Mm)").id + ", adds=" + adds
//						+ ", time=" + addArg1, "", "UnitVal");
//			}

//			WB.addLog2("UnitVal.test.add(2UnitVal):UnitVal", "", "UnitVal");
//			var tmp1 = new UnitVal("5.0(Unit.Mm)");
//			var tmp2 = new String[] { "11.0(Unit.Mm)", "8.0(Unit.Cm)", "4.2(Unit.Meter)", "0.0(Unit.Cm)" };
//			var currRes = tmp1;
//			WB.addLog2("UnitVal.test.add(2UnitVal):UnitVal, currRes=" + currRes.id, "", "UnitVal");
//			for (var currAdd : tmp2) {
//				WB.addLog2(
//						"UnitVal.test.add(2UnitVal):UnitVal, currRes=" + UnitVal.add(currRes, new UnitVal(currAdd)).id
//								+ ", currRes=" + currRes.id + ", currAdd=" + currAdd,
//						"", "UnitVal");
//			}

//			// add (same unit)
//			var addSameUnitArg0 = new String[] { "3.0(Unit.Mm)", "6.0(Unit.Mm)", "5.0(Unit.Mm)", "4.2(Unit.Mm)",
//					"7.999(Unit.Mm)" };
//			var addSameUnitArg1 = UnitVal.build(addSameUnitArg0);
//			WB.addLog2("UnitVal.test.add (same unit), res=" + UnitVal.add(addSameUnitArg1).id + ", adds="
//					+ Fmtr.listVal(addSameUnitArg0, ""), "", "UnitVal");

//			// add (toUnit)
//			var addToUnitArg0 = new String[] { "6.0(Unit.Mcm)", "5.0(Unit.Mm)", "4.2(Unit.Cm)", "7.9(Unit.Meter)" };
//			var addToUnitArg1 = UnitVal.build(addToUnitArg0);
//			for (var addArg2 : new String[] { "Unit.Mcm", "Unit.Mm", "Unit.Cm", "Unit.Meter" }) {
//				WB.addLog2(
//						"UnitVal.test.add (toUnit), res=" + UnitVal.add(addToUnitArg1, addArg2).id + ", adds="
//								+ Fmtr.listVal(addToUnitArg0, "") + ", toUnit=" + addArg2,"", "UnitVal");
//			}

//			WB.addLog2("UnitVal.test.conv(UnitVal,2String):UnitVal", "", "UnitVal");
//			for (var tmp1 : new String[] { "3.0(Unit.Box)", "6.0(Unit.Mcm)", "5.0(Unit.Mm)", "4.2(Unit.Cm)",
//					"7.9(Unit.Meter)" }) {
//				for (var tmp2 : new String[] { "Unit.Mcm", "Unit.Mm", "Unit.Cm", "Unit.Meter" }) {
//					for (var tmp3 : new String[] { "" }) {// ", lenght" }) {
//						WB.addLog2("UnitVal.test.сonv, res=" + UnitVal.conv(new UnitVal(tmp1), tmp2, tmp3).id
//								+ ", from=" + tmp1 + ", to=" + tmp2 + ", context=" + tmp3, "", "UnitVal");
//					}
//				}
//			}

//			// ctor(String,String)
//			for (var tmp1 : new String[] { "0.293", "0.0" }) {
//				for (var tmp2 : new String[] { "(Unit.Percent)", "Unit.WorkHour" }) {
//					WB.addLog2("UnitVal.test.ctor(String,String)=" + new UnitVal(tmp1, tmp2), "", "UnitVal");
//				}
//			}

//			WB.addLog2("UnitVal.test.ctor(String)", "", "UnitVal");
//			for (var tmp1 : new String[] { "0.293(Unit.tralala)", "AmountDeal = 12000.0(Unit.KZT)",
//					"0.293(Unit.Percent)", "(Unit.Percent)" }) {
//				WB.addLog2("UnitVal.test.ctor(String)=" + new UnitVal(tmp1) + ", tmp1=" + tmp1, "", "UnitVal");
//			}

		} catch (Exception ex) {
			WB.addLog("UnitVal.test():void, ex=" + ex.getMessage(), "", "UnitVal");
		}
	}
}