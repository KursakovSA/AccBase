import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class Dim {
	// origin - 11.09.2026, last edit - 18.09.2026
	public static List<String> nameList;

	static {
		try {
			Dim.nameList = List.of("Weight", "Volume", "Lenght", "Width", "Height", "Duration", "Thickness",
					"WallThickness");
		} catch (Exception ex) {
			WB.addLog("Dim.static ctor, ex=" + ex.getMessage(), "", "Dim");
		}
	}

	public static Map<String, UnitVal> get(String initMore) throws Exception { // TODO
		// origin - 17.09.2026, last edit - 17.09.2026
		Map<String, UnitVal> res = new HashMap<>();
		try {
			if (initMore.isEmpty()) {
				return res;
			}
			for (var curr : Dim.nameList) {
				var tmp = Dim.get(initMore, curr);
				if (tmp.id.isEmpty() == false) {
					res.put(curr, tmp);
				}
			}
		} catch (Exception ex) {
			WB.addLog("Dim.get(String):Map<String, UnitVal>, ex=" + ex.getMessage(), "", "Dim");
		}
		return res;
	}

	public static UnitVal get(String initMore, String key) throws Exception {
		// origin - 11.09.2026, last edit - 15.09.2026
		UnitVal res = new UnitVal();
		try {
			if ((initMore.isEmpty()) || (key.isEmpty())) {
				return res;
			}
			if (Dim.nameList.contains(key)) {
				var tmp = MoreVal.getFieldByKey(initMore, key);
				if (tmp.isEmpty() == false) {
					res = new UnitVal(tmp);
				}
			}
		} catch (Exception ex) {
			WB.addLog("Dim.get(2String):UnitVal, ex=" + ex.getMessage() + ", key=" + key, "", "Dim");
		}
		return res;
	}

	private Dim() throws Exception {
		// origin - 11.09.2026, last edit - 11.09.2026
	}

	public static String mapToStr(Map<String, UnitVal> inMap) throws Exception {
		// origin - 17.09.2026, last edit - 17.09.2026
		String res = "";
		try {
			for (Map.Entry<String, UnitVal> entry : inMap.entrySet()) {
				String key = entry.getKey();
				UnitVal value = entry.getValue();
				res = res + key + "=" + value.id + ", ";
			}
			res = "[" + res + "]";
		} catch (Exception ex) {
			WB.addLog("Dim.mapToStr (Map<String, UnitVal>):String, ex=" + ex.getMessage(), "", "Dim");
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 11.09.2026, last edit - 17.09.2026
		try {

//			WB.addLog2("Dim.test.get(String)", "", "Dim");
//			for (var tmp1 : new String[] { "", "FullName=килограмм;", "Weight=1000.00(Unit.Gr);MKEI=166;",
//					"FullName=100 грамм;Weight=0.10(Unit.Kg);", "MKEI=8;Lenght=1000.00(Unit.Meter);",
//					"FullName=литр;Volume=1000.00(Unit.Ml);",
//					"FullName=метр;Lenght=100.00(Unit.Cm);Width=100.00(Unit.Cm);Height=100.00(Unit.Cm);",
//					"FullName=миллиметр;Lenght=1000.00(Unit.Mcm);" }) {
//				WB.addLog2("Dim.test.get(String), res=" + Dim.mapToStr(Dim.get(tmp1)) + ", tmp1=" + tmp1, "", "Dim");
//			}

//			WB.addLog2("Dim.test.get(2String)", "", "Dim");
//			for (var tmp1 : new String[] { "", "FullName=килограмм;", "Weight=1000.00(Unit.Gr);MKEI=166;",
//					"FullName=100 грамм;Weight=0.10(Unit.Kg);", "MKEI=8;Lenght=1000.00(Unit.Meter);",
//					"FullName=литр;Volume=1000.00(Unit.Ml);",
//					"FullName=метр;Lenght=100.00(Unit.Cm);Width=100.00(Unit.Cm);Height=100.00(Unit.Cm);",
//					"FullName=миллиметр;Lenght=1000.00(Unit.Mcm);" }) {
//				for (var tmp3 : Dim.name) {
//					WB.addLog2("Dim.test.get(2String), res.id=" + Dim.get(tmp1, tmp3).id + ", tmp1=" + tmp1 + ", tmp3="
//							+ tmp3, "", "Dim");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("Dim.test():void, ex=" + ex.getMessage(), "", "Dim");
		}
	}
}