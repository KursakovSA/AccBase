import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class Qty {
	// origin - 30.05.2025, last edit - 11.11.2026
	public String src, srcUnit;
	public List<String> srcList;
	public List<UnitVal> val;
	public static String unitDefault;
	public static String strQuantity;

	static {
		try {
			Qty.unitDefault = Unit.strPiece;
			Qty.strQuantity = "Quantity";
		} catch (Exception ex) {
			WB.addLog("Qty.static ctor, ex=" + ex.getMessage(), "", "Qty");
		}
	}

	public static UnitVal getBySrcUnitName(String src, String unit, String name) throws Exception {
		// origin - 11.11.2026, last edit - 11.11.2026
		UnitVal res = new UnitVal();
		try {
			if (Etc.strNotValid(src, unit, name)) {
				return res;
			}
			var tmp1 = Qty.getMapBySrc(src, unit);
			for (Map.Entry<String, UnitVal> entry : tmp1.entrySet()) {
				String key = entry.getKey();
				if (Etc.strEquals(key, name)) {
					res = entry.getValue();
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Qty.getBySrcUnitName(3String):UnitVal, ex=" + ex.getMessage(), "", "Qty");
		}
		return res;
	}

	private static Map<String, UnitVal> getMapBySrc(String src, String unit) throws Exception {
		// origin - 11.11.2026, last edit - 13.11.2026
		Map<String, UnitVal> res = new LinkedHashMap<>();
		try {
			if (Etc.strNotValid(src)) {
				return res;
			}
			var tmp1 = NameVar.getListByNameStartWithInfo(Qty.strQuantity, "Info.Generic.DocColumn");
			var tmp2 = new Qty(src, unit);
			int count = 0;
			for (var curr : tmp1) {
				if (count <= tmp2.val.size() - 1) {
					res.put(curr, tmp2.val.get(count));
				}
				count = count + 1;
			}
		} catch (Exception ex) {
			WB.addLog("Qty.getMapBySrc(2String):Map<String, UnitVal>, ex=" + ex.getMessage(), "", "Qty");
		}
		return res;
	}

	private void fix() throws Exception { // TODO
		// origin - 10.11.2026, last edit - 11.11.2026
		try {
		} catch (Exception ex) {
			WB.addLog("Qty.fix():void, ex=" + ex.getMessage(), "", "Qty");
		}
	}

	private void validate() throws Exception { // TODO
		// origin - 10.11.2026, last edit - 10.11.2026
		try {
		} catch (Exception ex) {
			WB.addLog("Qty.validate():void, ex=" + ex.getMessage(), "", "Qty");
		}
	}

	private void getVal() throws Exception {
		// origin - 30.05.2025, last edit - 13.11.2026
		try {
			if (Etc.strListValid(this.srcList)) {
				for (var curr : this.srcList) {
					curr = UnitVal.fixStrUnit(curr);
					var tmp = new UnitVal(curr);

					if (Etc.strValid(this.srcUnit)) {
						curr = UnitVal.cleanStrUnit(curr);
						tmp = new UnitVal(curr, this.srcUnit);
						this.val.add(tmp);
						continue;
					}

					if (Etc.strNotValid(tmp.partUnit)) {
						tmp = new UnitVal(curr, Qty.unitDefault);
						// this.val.add(tmp);
						// continue;
					}

					if (Etc.strNotValid(tmp.unit.id)) {
						tmp = new UnitVal(curr, Qty.unitDefault);
						// this.val.add(tmp);
						// continue;
					}
					this.val.add(tmp);
				}
			}
		} catch (Exception ex) {
			WB.addLog("Qty.getVal():void, ex=" + ex.getMessage(), "", "Qty");
		}
	}

	public Qty(String Src, String SrcUnit) throws Exception {
		// origin - 11.11.2026, last edit - 11.11.2026
		this.clear();
		this.src = Etc.fixTrim(Src);
		this.srcUnit = Etc.fixTrim(SrcUnit);
		this.srcList = List.of(this.src.split(";"));
		this.getVal();
		this.fix();
		this.validate();
	}

	public Qty() throws Exception {
		// origin - 30.05.2025, last edit - 10.11.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 30.05.2025, last edit - 11.11.2026
		try {
			this.src = this.srcUnit = "";
			this.srcList = new ArrayList<String>();
			this.val = new ArrayList<UnitVal>();
		} catch (Exception ex) {
			WB.addLog("Qty.clear():void, ex=" + ex.getMessage(), "", "Qty");
		}
	}

	public String toString() {
		// origin - 30.05.2025, last edit - 11.11.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", srcList ", this.srcList);
			res = res + Fmtr.addIfNotEmpty(", val ", UnitVal.toStringList(this.val));
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 30.05.2025, last edit - 13.11.2026
		try {

//			WB.addLog2("Qty.test.getMapBySrcUnitName(3String):UnitVal", "", "Qty");
//			WB.addLog2(
//					"Qty.test.NameVar.getListByNameStartWithInfo('Quantity', 'Info.Generic.DocColumn'):List<String>, res="
//							+ NameVar.getListByNameStartWithInfo("Quantity", "Info.Generic.DocColumn"),
//					"", "Qty");
//			for (var tmp1 : new String[] { null, "", "12.00", "12.00;1.7", "17,00;4;12.00", "3;5.00;6,00;7.0" }) {
//				for (var tmp2 : new String[] { "Unit.EUR" }) {
//					for (var tmp3 : NameVar.getListByNameStartWithInfo(Qty.strQuantity, "Info.Generic.DocColumn")) {
//						WB.addLog2("Qty.test.getMapBySrcUnitName(3String):UnitVal, res="
//								+ Qty.getBySrcUnitName(tmp1, tmp2, tmp3).id + ", tmp1=" + tmp1 + ", tmp2=" + tmp2
//								+ ", tmp3=" + tmp3, "", "Qty");
//					}
//				}
//			}

//			WB.addLog2("Qty.test.getMapBySrc(String):Map<String; UnitVal>", "", "Qty");
//			for (var tmp1 : new String[] { null, "", "12.00", "12.00;1.7", "17,00;4;12.00", "3;5.00;6,00;7.0" }) {
//				WB.addLog2("Qty.test.getMapBySrc(String):Map<String, UnitVal>, res="
//						+ UnitVal.toStringMap(Qty.getMapBySrc(tmp1, "")) + ", tmp1=" + tmp1, "", "Qty");
//			}

//			WB.addLog2("Qty.test.ctor(2String)", "", "Qty");
//			for (var tmp1 : new String[] { null, "", "12.00", "12.00;1.7", "12.00;1.7(Unit.Kg)", "12.00(Unit.Kg);1.7",
//					"17,00;4;12.00", "3;5.00;6,00;7.0" }) {
//				for (var tmp2 : new String[] { "Unit.EUR" }) {
//					WB.addLog2(
//							"Qty.test.ctor(2String), res=" + new Qty(tmp1, tmp2) + ", tmp1=" + tmp1 + ", tmp2=" + tmp2,
//							"", "Qty");
//				}
//			}

//			WB.addLog2("Qty.test.ctor(String) by ctor(2String)", "", "Qty");
//			for (var tmp1 : new String[] { null, "", "12.00 (Unit.MinRate)", "12.00(Unit.MinRate)", "1.7", "17,00",
//					"4 Unit.MinRate", "4Unit.MinRate", "12.00", "5", "5.00", "5,00", "5.0", "5,0", "5,0;2.0",
//					"5,0(Unit.Kg);2.0(Unit.Tralala)", "5,0(Unit.Kg);2.0", "5,0(Unit.Kg);2.0(Unit.Tralala)",
//					"5,0(Unit.Kg);2.0", "5,0;2.0(Unit.Tralala)", "5,0;2.0Unit.Tralala" }) {
//				WB.addLog2("Qty.test.ctor(String) by ctor(2String), res=" + new Qty(tmp1, "") + ", tmp1=" + tmp1, "",
//						"Qty");
//			}

		} catch (Exception ex) {
			WB.addLog("Qty.test():void, ex=" + ex.getMessage(), "", "Qty");
		}
	}
}