import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class Prc { // "price"
	// origin - 13.11.2026, last edit - 13.11.2026
	public String src, srcUnit;
	public List<String> srcList;
	public List<UnitVal> val;
	public static String unitDefault;
	public static String strPrice;

	static {
		try {
			Prc.unitDefault = Unit.currCurrency.code;
			Prc.strPrice = "Price";
		} catch (Exception ex) {
			WB.addLog("Prc.static ctor, ex=" + ex.getMessage(), "", "Prc");
		}
	}

	public static UnitVal getBySrcUnitName(String src, String unit, String name) throws Exception {
		// origin - 13.11.2026, last edit - 13.11.2026
		UnitVal res = new UnitVal();
		try {
			if (Etc.strNotValid(src, unit, name)) {
				return res;
			}
			var tmp1 = Prc.getMapBySrc(src, unit);
			for (Map.Entry<String, UnitVal> entry : tmp1.entrySet()) {
				String key = entry.getKey();
				if (Etc.strEquals(key, name)) {
					res = entry.getValue();
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Prc.getBySrcUnitName(3String):UnitVal, ex=" + ex.getMessage(), "", "Prc");
		}
		return res;
	}

	private static Map<String, UnitVal> getMapBySrc(String src, String unit) throws Exception {
		// origin - 13.11.2026, last edit - 13.11.2026
		Map<String, UnitVal> res = new LinkedHashMap<>();
		try {
			if (Etc.strNotValid(src)) {
				return res;
			}
			var tmp1 = NameVar.getListByNameStartWithInfo(Prc.strPrice, "Info.Generic.DocColumn");
			var tmp2 = new Qty(src, unit);
			int count = 0;
			for (var curr : tmp1) {
				if (count <= tmp2.val.size() - 1) {
					res.put(curr, tmp2.val.get(count));
				}
				count = count + 1;
			}
		} catch (Exception ex) {
			WB.addLog("Prc.getMapBySrc(2String):Map<String, UnitVal>, ex=" + ex.getMessage(), "", "Prc");
		}
		return res;
	}

	private void fix() throws Exception { // TODO
		// origin - 12.11.2026, last edit - 13.11.2026
		try {
		} catch (Exception ex) {
			WB.addLog("Prc.fix():void, ex=" + ex.getMessage(), "", "Prc");
		}
	}

	private void validate() throws Exception { // TODO
		// origin - 12.11.2026, last edit - 12.11.2026
		try {
		} catch (Exception ex) {
			WB.addLog("Prc.validate():void, ex=" + ex.getMessage(), "", "Prc");
		}
	}

	private void getVal() throws Exception {
		// origin - 13.11.2026, last edit - 13.11.2026
		try {
			if (Etc.strListValid(this.srcList)) {
				for (var curr : this.srcList) {
					curr = UnitVal.fixStrUnit(curr);
					var tmp = new UnitVal(curr);

					if (Etc.strValid(this.srcUnit)) {
						curr = UnitVal.cleanStrUnit(curr);
						tmp = new UnitVal(curr, this.srcUnit);
						this.val.add(tmp);
						continue;
					}

					if (Etc.strNotValid(tmp.partUnit)) {
						tmp = new UnitVal(curr, Prc.unitDefault);
						// this.val.add(tmp);
						// continue;
					}

					if (Etc.strNotValid(tmp.unit.id)) {
						tmp = new UnitVal(curr, Prc.unitDefault);
						// this.val.add(tmp);
						// continue;
					}
					this.val.add(tmp);
				}
			}
		} catch (Exception ex) {
			WB.addLog("Prc.getVal():void, ex=" + ex.getMessage(), "", "Prc");
		}
	}

	public Prc(String Src, String SrcUnit) throws Exception {
		// origin - 13.11.2026, last edit - 13.11.2026
		this.clear();
		this.src = Etc.fixTrim(Src);
		this.srcUnit = Etc.fixTrim(SrcUnit);
		this.srcList = List.of(this.src.split(";"));
		this.getVal();
		this.fix();
		this.validate();
	}

	public Prc() throws Exception {
		// origin - 13.11.2026, last edit - 13.11.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 13.11.2026, last edit - 13.11.2026
		try {
			this.src = this.srcUnit = "";
			this.srcList = new ArrayList<String>();
			this.val = new ArrayList<UnitVal>();
		} catch (Exception ex) {
			WB.addLog("Prc.clear():void, ex=" + ex.getMessage(), "", "Prc");
		}
	}

	public String toString() {
		// origin - 13.11.2026, last edit - 13.11.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", srcList ", this.srcList);
			res = res + Fmtr.addIfNotEmpty(", val ", UnitVal.toStringList(this.val));// this.val);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 13.11.2026, last edit - 13.11.2026
		try {

//			WB.addLog2("Prc.test.getMapBySrcUnitName(3String):UnitVal", "", "Prc");
//			WB.addLog2(
//					"Prc.test.NameVar.getListByNameStartWithInfo('Price', 'Info.Generic.DocColumn'):List<String>, res="
//							+ NameVar.getListByNameStartWithInfo("Price", "Info.Generic.DocColumn"),
//					"", "Prc");
//			for (var tmp1 : new String[] { null, "", "12.00", "12.00;1.7", "17,00;4;12.00", "3;5.00;6,00;7.0" }) {
//				for (var tmp2 : new String[] { "Unit.EUR" }) {
//					for (var tmp3 : NameVar.getListByNameStartWithInfo(Prc.strPrice, "Info.Generic.DocColumn")) {
//						WB.addLog2("Prc.test.getMapBySrcUnitName(3String):UnitVal, res="
//								+ Prc.getBySrcUnitName(tmp1, tmp2, tmp3).id + ", tmp1=" + tmp1 + ", tmp2=" + tmp2
//								+ ", tmp3=" + tmp3, "", "Prc");
//					}
//				}
//			}

//			WB.addLog2("Prc.test.getMapBySrc(String):Map<String; UnitVal>", "", "Prc");
//			for (var tmp1 : new String[] { null, "", "12.00", "12.00;1.7", "17,00;4;12.00", "3;5.00;6,00;7.0" }) {
//				WB.addLog2("Prc.test.getMapBySrc(String):Map<String, UnitVal>, res="
//						+ UnitVal.toStringMap(Prc.getMapBySrc(tmp1, "")) + ", tmp1=" + tmp1, "", "Prc");
//			}

//			WB.addLog2("Prc.test.ctor(2String)", "", "Prc");
//			for (var tmp1 : new String[] { null, "", "12.00", "12.00;1.7", "12.00;1.7(Unit.Kg)", "12.00(Unit.Kg);1.7",
//					"17,00;4;12.00", "3;5.00;6,00;7.0" }) {
//				for (var tmp2 : new String[] { "Unit.EUR" }) {
//					WB.addLog2(
//							"Prc.test.ctor(2String), res=" + new Prc(tmp1, tmp2) + ", tmp1=" + tmp1 + ", tmp2=" + tmp2,
//							"", "Prc");
//				}
//			}

//			WB.addLog2("Prc.test.ctor(String) by ctor(2String)", "", "Prc");
//			for (var tmp1 : new String[] { null, "", "12.00 (Unit.MinRate)", "12.00(Unit.MinRate)", "1.7", "17,00",
//					"4 Unit.MinRate", "4Unit.MinRate", "12.00", "5", "5.00", "5,00", "5.0", "5,0", "5,0;2.0",
//					"5,0(Unit.Kg);2.0(Unit.Tralala)", "5,0(Unit.Kg);2.0", "5,0;2.0(Unit.Tralala)",
//					"5,0;2.0Unit.Tralala" }) {
//				WB.addLog2("Prc.test.ctor(String) by ctor(2String), res=" + new Prc(tmp1, "") + ", tmp1=" + tmp1, "",
//						"Prc");
//			}

		} catch (Exception ex) {
			WB.addLog("Prc.test():void, ex=" + ex.getMessage(), "", "Prc");
		}
	}
}