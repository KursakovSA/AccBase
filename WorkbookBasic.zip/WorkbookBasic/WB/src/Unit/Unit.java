import java.util.ArrayList;
import java.util.List;

public final class Unit {
	// origin - 28.09.2023, last edit - 17.09.2026
	// common fields
	public String table, src, id, parent, date1, date2, code, description, role, more, defect;
	// special fields
	public String fullName, comment;
	public List<FullDto> lowerList, upperList;
	public static Unit currCurrency, minRate, minSalary, piece;
	public static String strPiece, strMinRate, strMinSalary, strGr, strCalendarDay;
	public static List<String> dimList;

	static {
		try {
			Unit.strPiece = "Unit.Piece";
			Unit.piece = new Unit("Unit.Piece");
			RangeVal.pieceInit = "0.0 - 0.0(" + Unit.strPiece + ")";
			Unit.strCalendarDay = "Unit.CalendarDay";
			UnitVal.calendarDayInit = "0.0(" + Unit.strCalendarDay + ")";
			RangeVal.calendarDayInit = "0.0 - 0.0(" + Unit.strCalendarDay + ")";
			Unit.strGr = "Unit.Gr";
			Unit.strMinRate = "Unit.MinRate";
			Unit.strMinSalary = "Unit.MinSalary";
			Unit.currCurrency = new Unit(MoreVal.getFieldByKey(Geo.currCountry.more, "Currency"));
			UnitVal.currCurrencyInit = "0.0(" + Unit.currCurrency.code + ")";
			RangeVal.currCurrencyInit = "0.0 - 0.0(" + Unit.currCurrency.code + ")";
			Unit.minRate = new Unit(Unit.strMinRate);
			Unit.minSalary = new Unit(Unit.strMinSalary);
			Unit.dimList = Dim.nameList;
		} catch (Exception ex) {
			WB.addLog("Unit.static ctor, ex=" + ex.getMessage(), "", "Unit");
		}
	}

	public static boolean isCurrency(String testUnit) throws Exception {
		// origin - 20.07.2026, last edit - 20.07.2026
		boolean res = false;
		try {
			Unit tmp = new Unit(testUnit);
			if (tmp.parent.isEmpty() == false) {
				if (Etc.strEquals(tmp.parent, "Unit.CurrCurrency")) {
					res = true;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Unit.isCurrency(String):boolean, ex=" + ex.getMessage(), "", "Unit");
		}
		return res;
	}

	public static FullDto getFullDtoByList(List<String> in) throws Exception {
		// origin - 02.03.2026, last edit - 20.07.2026
		FullDto res = new FullDto();
		try {
			res.table = "Unit";
			res.id = Etc.fixTrim(in.get(0));
			res.parent = Etc.fixTrim(in.get(1));
			res.date1 = Etc.fixTrim(in.get(2));
			res.date2 = Etc.fixTrim(in.get(3));
			res.code = Etc.fixTrim(in.get(4));
			res.description = Etc.fixTrim(in.get(5));
			res.role = Etc.fixTrim(in.get(6));
			res.more = Etc.fixTrim(in.get(7));
		} catch (Exception ex) {
			WB.addLog("Unit.getFullDtoByList(List<String>):FullDto, ex=" + ex.getMessage(), "", "Unit");
		}
		return res;
	}

	public static List<String> getListByFullDto(FullDto in) throws Exception {
		// origin - 31.01.2026, last edit - 20.07.2026
		List<String> res = new ArrayList<String>();
		try {
			res.add(in.id);
			res.add(in.parent);
			res.add(in.date1);
			res.add(in.date2);
			res.add(in.code);
			res.add(in.description);
			res.add(in.role);
			res.add(in.more);
		} catch (Exception ex) {
			WB.addLog("Unit.getByTable(FullDto):List<String>, ex=" + ex.getMessage(), "", "Unit");
		}
		return res;
	}

	public static Unit getExpectedByInfo(String infoSelect) throws Exception {
		// origin - 09.05.2025, last edit - 10.09.2026
		Unit res = new Unit();
		try {
			Info info = new Info(infoSelect);
			Unit unit = new Unit(MoreVal.getFieldByKey(info.more, "ExpectedUnit"));
			if (unit.code.isEmpty() == false) {
				res = unit;
			}
		} catch (Exception ex) {
			WB.addLog("Unit.getExpectedByInfo(String):Unit, ex=" + ex.getMessage(), "", "Unit");
		}
		return res;
	}

	public static double getTotalRatioConv(String fromCode, String toCode) throws Exception {
		// origin - 03.02.2025, last edit - 15.09.2026
		double res = 0.0;
		try {
			var tmpLinkConv = Unit.getLinkConv(fromCode, toCode);
			if (tmpLinkConv.size() != 0) {
				res = 1.0;
				for (var currRatioConv : tmpLinkConv) {
					res = Num.multiply(res, currRatioConv);
				}
			}
		} catch (Exception ex) {
			WB.addLog("Unit.getTotalRatioConv(2String):double, ex=" + ex.getMessage(), "", "Unit");
		}
		return res;
	}

	private static List<Double> checkRatioConv(String currToCode, String toCode, List<Double> linkRatioConv)
			throws Exception {
		// origin - 14.02.2025, last edit - 13.06.2025
		List<Double> res = linkRatioConv;
		try {
			if (res.size() != 0) {
				if (Etc.strEquals(currToCode, toCode) == false) {
					res.clear();
				}
			}
		} catch (Exception ex) {
			WB.addLog("Unit.checkRatioConv(2String, List<Double>):List<Double>, ex=" + ex.getMessage(), "", "Unit");
		}
		return res;
	}

	private static List<Double> getLinkConv(String fromCode, String toCode) throws Exception {
		// origin - 03.02.2025, last edit - 15.09.2026
		List<Double> res = new ArrayList<Double>();
		try {
			double currRatioConv = 0.0;
			String currToCode = "";

			// same fromCode and toCode
			if (Etc.strEquals(fromCode, toCode)) {
				res.add(1.0);
				return res;
			}

			// toCode is next level under fromCode
			// direct
			currRatioConv = Unit.getConv(fromCode, toCode, "").val;
			if (currRatioConv != 0.0) {
				res.add(currRatioConv);
				return res;
			}
			// search reverse
			if (currRatioConv == 0.0) {
				currRatioConv = Unit.getConv(toCode, fromCode, "").val;
				if (currRatioConv != 0.0) {
					res.add(Num.reverseRatio(currRatioConv));
					return res;
				}
			}

			// List<FullDto> tmpListUnit = DAL.getTable(WB.lastConnWork,
			// Qry.getText(WB.lastConnWork, "Unit", ""));// WB.abcLast.unit;
			List<FullDto> tmpListUnit = WB.abcLast.unit;
			String currFromCode = fromCode;

			// search lower ratioConv
			// tmpListUnit = WB.abcLast.unit;
			currRatioConv = 0.0;
			currToCode = "";
			// currFromCode = fromCode;
			for (;;) { // endless cycle
				currRatioConv = 0.0;

				// stop if currFromCode == toCode
				if (Etc.strEquals(currFromCode, toCode)) {
					break;
				}

				// search next ratioConv
				for (var currUnitDto : tmpListUnit) {
					currRatioConv = Unit.getConv(currFromCode, currUnitDto.code, "").val;
					if (currRatioConv != 0.0) {
						res.add(currRatioConv);
						currFromCode = currUnitDto.code;
						currToCode = currUnitDto.code;
						break;
					}
				}

				// stop if in link conv no ratioConv
				if (currRatioConv == 0.0) {
					break;
				}
			}
			res = Unit.checkRatioConv(currToCode, toCode, res);

			// if lower linkConv == 0 then search upper ratioConv
			if (res.size() == 0) {
				// tmpListUnit = DAL.getTable(WB.lastConnWork, Qry.getText(WB.lastConnWork,
				// "Unit", ""));// WB.abcLast.unit;
				currRatioConv = 0.0;
				currFromCode = fromCode;
				currToCode = "";
				for (;;) { // endless cycle
					currRatioConv = 0.0;

					// stop if currFromCode == toCode
					if (Etc.strEquals(currFromCode, toCode)) {
						break;
					}

					// search next ratioConv
					for (var currUnitDto : tmpListUnit) {
						currRatioConv = Unit.getConv(currUnitDto.code, currFromCode, "").val;
						if (currRatioConv != 0.0) {
							res.add(Num.reverseRatio(currRatioConv));
							currFromCode = currUnitDto.code;
							currToCode = currUnitDto.code;
							break;
						}
					}

					// stop if in link conv no ratioConv
					if (currRatioConv == 0.0) {
						break;
					}
				}
				res = Unit.checkRatioConv(currToCode, toCode, res);
			}

		} catch (Exception ex) {
			WB.addLog("Unit.getLinkConv(2String):List<Double>, ex=" + ex.getMessage(), "", "Unit");
		}
		return res;
	}

	private static UnitVal getConv(String fromCode, String toCode, String context) throws Exception {
		// origin - 30.01.2025, last edit - 11.09.2026
		UnitVal res = new UnitVal();
		try {
			List<FullDto> listDto = new ArrayList<FullDto>();

			listDto = ReadSet.getEqualsByCode(WB.abcLast.unit, fromCode);
			// listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getCodeFilter(fromCode),
			// "Unit");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				Unit tmp = new Unit(dto.code);

				// weight, width, height -- not must be for conv, by idea

				// lenght
				var lenght = Dim.get(tmp.more, "Lenght");
				if (lenght.src.isEmpty() == false) {
					if (Etc.strEquals(lenght.unit.code, toCode)) {
						UnitVal tmpUnitVal = new UnitVal(lenght.val, lenght.unit.code);
						return res = tmpUnitVal;
					}
				}

				// volume
				var volume = Dim.get(tmp.more, "Volume");
				if (volume.src.isEmpty() == false) {
					if (Etc.strEquals(volume.unit.code, toCode)) {
						UnitVal tmpUnitVal = new UnitVal(volume.val, volume.unit.code);
						return res = tmpUnitVal;
					}
				}

				// duration
				var duration = Dim.get(tmp.more, "Duration");
				if (duration.src.isEmpty() == false) {
					if (Etc.strEquals(duration.unit.code, toCode)) {
						UnitVal tmpUnitVal = new UnitVal(duration.val, duration.unit.code);
						return res = tmpUnitVal;
					}
				}
			}

		} catch (Exception ex) {
			WB.addLog("Unit.getConv(3String):UnitVal, ex=" + ex.getMessage(), "", "Unit");
		}
		return res;
	}

	public static UnitVal сonv(String fromCode, String toCode, String context) throws Exception {
		// origin - 29.01.2025, last edit - 19.03.2025
		UnitVal res = new UnitVal(0.0, toCode);

		if (Etc.strEquals(fromCode, toCode)) {
			res = new UnitVal(1.0, fromCode);
			return res;
		}

		try {
//			// direct conv
//			var directLinkConv = Unit.getLinkConv(fromCode, toCode);
//			if (directLinkConv.size() != 0) {
//				res = Unit.getConv(fromCode, toCode, context);
//			}
//
//			// reverse conv
//			if (res.src.isEmpty()) {
//				var reverseLinkConv = Unit.getLinkConv(toCode, fromCode);
//				if (reverseLinkConv.size() != 0) {
//					var tmp = Unit.getConv(toCode, fromCode, context);
//					// if (tmp.val != 0.0) {
//					res = new UnitVal(Etc.reverseRatio(tmp.val), tmp.unit.code);
//					// }
//				}
//			}
//
//			// cross conv
//			if (res.src.isEmpty()) {
//				var crossLinkConv = Unit.getLinkConv(toCode, fromCode);
//				if (crossLinkConv.size() != 0) {
//					var totalRatioConv = Unit.getTotalRatioConv(toCode, fromCode);
//					// if (totalRatioConv != 0.0) {
//					res = new UnitVal(totalRatioConv, toCode);
//					// }
//				}
//			}

			var totalRatioConv = Unit.getTotalRatioConv(fromCode, toCode);
			res = new UnitVal(totalRatioConv, toCode);

		} catch (Exception ex) {
			WB.addLog("Unit.сonv(3String):UnitVal, ex=" + ex.getMessage(), "", "Unit");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 20.11.2025, last edit - 20.11.2025
		try {
		} catch (Exception ex) {
			WB.addLog("Unit.validate():void, ex=" + ex.getMessage(), "", "Unit");
		}
	}

	private List<FullDto> getFastListDto() throws Exception {
		// origin - 09.08.2026, last edit - 09.08.2026
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			var tmp = WB.abcLast.unit;
			res = ReadSet.getEqualsByCode(tmp, this.code);
			if (res.size() == 0) {
				res = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.code), "Unit");
			}
		} catch (Exception ex) {
			WB.addLog("Unit.getFastListDto():void, ex=" + ex.getMessage(), "", "Unit");
		}
		return res;
	}

	private void isExist() throws Exception {
		// origin - 17.09.2024, last edit - 13.08.2026
		try {
			// var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.code),
			// "Unit");
			var listDto = this.getFastListDto();
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.code = dto.code;
				this.parent = dto.parent;
				this.description = dto.description;
				this.role = dto.role;
				this.more = dto.more;
				// this.upperList = FullDto.getUpper(this.table, this.parent);
				// this.lowerList = FullDto.getLower(this.table, this.id);
				this.upperList = Abc.getUpper(this.table, this.parent);
				this.lowerList = Abc.getLower(this.table, this.id);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.clear();
			}
		} catch (Exception ex) {
			WB.addLog("Unit.isExist():void, ex=" + ex.getMessage(), "", "Unit");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 09.08.2026, last edit - 11.09.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("Unit.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Unit");
		}
	}

	public Unit(String Id) throws Exception {
		// origin - 02.10.2024, last edit - 20.11.2025
		this.clear();
		this.src = Id;
		if (Id.isEmpty() == false) {
			this.id = this.code = Id;
		}
		this.isExist();
		this.validate();
	}

	public Unit() throws Exception {
		// origin - 05.12.2023, last edit - 19.05.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 25.11.2024, last edit - 11.09.2026
		try {
			this.table = "Unit";
			this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.role = this.more = "";
			this.fullName = this.comment = this.defect = "";
			this.lowerList = new ArrayList<FullDto>();
			this.upperList = new ArrayList<FullDto>();
		} catch (Exception ex) {
			WB.addLog("Unit.clear():void, ex=" + ex.getMessage(), "", "Unit");
		}
	}

	public String toString() {
		// origin - 25.11.2024, last edit - 11.09.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addAnyway(", upperList ", this.upperList.size());
			res = res + Fmtr.addAnyway(", lowerList ", this.lowerList.size());
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 11.08.2026
		try {

//			WB.addLog2("Unit.test.сonv(3String):UnitVal", "", "Unit");
//			for (var tmp1 : new String[] { "Unit.Box", "Unit.Mcm", "Unit.Mm", "Unit.Cm", "Unit.Meter" }) {
//				for (var tmp2 : new String[] { "Unit.Mcm", "Unit.Mm", "Unit.Cm", "Unit.Meter" }) {
//					for (var tmp3 : new String[] { "" }) {
//						WB.addLog2("Unit.test.сonv(3String):UnitVal, res=" + Unit.сonv(tmp1, tmp2, tmp3).id + ", tmp1="
//								+ tmp1 + ", tmp2=" + tmp2 + ", tmp3=" + tmp3, "", "Unit");
//					}
//				}
//			}

//			WB.addLog2("Unit.test.getTotalRatioConv(2String):double", "", "Unit");
//			for (var tmp1 : new String[] { "Unit.Box", "Unit.Mcm", "Unit.Mm", "Unit.Cm", "Unit.Meter" }) {
//				for (var tmp2 : new String[] { "Unit.Mcm", "Unit.Mm", "Unit.Cm", "Unit.Meter" }) {
//					WB.addLog2("Unit.test.getTotalRatioConv(2String):double, res=" + Unit.getTotalRatioConv(tmp1, tmp2)
//							+ ", fromCode=" + tmp1 + ", toCode=" + tmp2, "", "Unit");
//				}
//			}

//			WB.addLog2("Unit.test.getLinkConv(2String):List<Double>", "", "Unit");
//			for (var tmp1 : new String[] { "Unit.Box", "Unit.Mcm", "Unit.Mm", "Unit.Cm", "Unit.Meter" }) {
//				for (var tmp2 : new String[] { "Unit.Mcm", "Unit.Mm", "Unit.Cm", "Unit.Meter" }) {
//					WB.addLog2("Unit.test.getLinkConv(2String):List<Double>, res=" + Unit.getLinkConv(tmp1, tmp2)
//							+ ", fromCode=" + tmp1 + ", toCode=" + tmp2, "", "Unit");
//				}
//			}

//			WB.addLog2("Unit.test.ctor(String)", "", "Unit");
//			for (var tmp : new String[] { "Unit.Face", "Unit.KZT", "Unit.tralala", "Unit.ExactDate",
//					"Unit.Service/Login/Password", "Unit.EveryDayOnTime", "Unit.Month", "Unit.Meter" }) {
//				WB.addLog2("Unit.test.ctor(String), res=" + new Unit(tmp), "", "Unit");
//			}

		} catch (Exception ex) {
			WB.addLog("Unit.test():void, ex=" + ex.getMessage(), "", "Unit");
		}
	}
}