public class Unit extends Model {
	// origin - 28.09.2023, last edit - 06.12.2023
	public static Unit root;
	public Unit parent;
	public Role role;

	static {
		root = new Unit("Unit","Unit","UnitData");
	}
	
	public Unit(String Id, String Code, String Description) {
		// origin - 05.12.2023, last edit - 05.12.2023
		this.id = Id;
		this.code = Code;
		this.description = Description;
	}

	public Unit() {
		// origin - 05.12.2023, last edit - 05.12.2023
	}

	public static void test() {
		// origin - 28.10.2023, last edit - 05.12.2023
		Logger.add("Unit.test, Unit.root=" + Unit.root, "", "Unit");
	}
}
