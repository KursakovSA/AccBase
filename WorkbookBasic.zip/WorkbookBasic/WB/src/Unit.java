import java.util.List;

public class Unit extends ModelDto {
	// origin - 28.09.2023, last edit - 09.10.2024
	public List<UnitVal> weight; // TOTHINK
	public List<UnitVal> volume; // TOTHINK
	public List<UnitVal> lenght; // TOTHINK
	public List<UnitVal> width; // TOTHINK
	public List<UnitVal> height; // TOTHINK
	public String MKEIcode; // TOTHINK
	public String expectedValue = "ExpectedDouble"; // ?? magic string ??

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Unit.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
	}

	public boolean isValid() throws Exception {
		// origin - 17.09.2024, last edit - 09.10.2024
		boolean res = true;
		try {
			if (this.parent.isEmpty()) {
				res = false;
			}
			if (this.role.isEmpty()) {
				res = false;
			}
		} catch (Exception ex) {
			WB.addLog("Unit.isValid, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Unit.isValid, res=" + res + ", this=" + this, WB.strEmpty,
		// "Unit");
		return res;
	}

	public boolean isExist() throws Exception {
		// origin - 17.09.2024, last edit - 09.10.2024
		boolean res = false;
		try {
			for (var currUnit : WB.abcLast.unit) {
				if (Etc.strEquals(currUnit.id, this.id)) {
					if (Etc.strEquals(currUnit.code, this.code)) {
						this.parent = currUnit.parent;
						this.role = currUnit.role;
						this.more = currUnit.more;
						this.expectedValue = MoreVal.getFieldByKey(this.more, "AbcExpectedValue");
						// this.isValid();
						res = true;
						break;
					}
				}
			}

		} catch (Exception ex) {
			WB.addLog("Unit.isExist, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Unit.isExist, res=" + res + ", this=" + this, WB.strEmpty,
		// "Unit");
		return res;
	}

	public Unit(String Id, String Code, String Description) throws Exception {
		// origin - 05.12.2023, last edit - 09.10.2024
		super(Id, Code, Description);
		this.table = this.getClass().getName();
		this.id = Id;
		this.code = Code;
		this.description = Description;
		this.isExist();
		this.isValid();
	}

	public Unit(String Id) throws Exception {
		// origin - 02.10.2024, last edit - 09.10.2024
		// super();
		this.table = this.getClass().getName();
		this.id = Id;
		this.code = Id; // code = id for basic
//		if (this.isExist() == false) {
//			var root = Abc.getRoot(this.table); // get unit root from WB.abcLast
//			this.id = root.id;
//			this.code = root.code;
//			this.description = root.description;
//		}
		this.isExist();
		this.isValid();
	}

	public Unit() throws Exception {
		// origin - 05.12.2023, last edit - 09.10.2024
		this.table = this.getClass().getName();
		var root = Abc.getRoot(this.table); // get unit root from WB.abcLast
		this.id = root.id;
		this.code = root.code;
		this.description = root.description;
		this.isExist();
		this.isValid();
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 09.10.2024
		try {

			// ctor (String Id)
			Unit unit1 = new Unit("Unit.Account");
			WB.addLog2("Unit.test.ctor(String Id), unit1(Unit.Account)=" + unit1 + ", isExist=" + unit1.isExist()
					+ ", isValid=" + unit1.isValid(), WB.strEmpty, "Unit");
			Unit unit2 = new Unit("Unit.tralala");
			WB.addLog2("Unit.test.ctor(String Id), unit2(Unit.tralala)=" + unit2 + ", isExist=" + unit2.isExist()
					+ ", isValid=" + unit2.isValid(), WB.strEmpty, "Unit");

//			// ctor
//			Unit unit1 = new Unit("Unit.Account", "Unit.Piece", WB.strEmpty, WB.strEmpty, "Unit.Account", "бухсчет",
//					"Role.Generic.Variant", "FullName=бухсчет;AbcBasic=Unit.Basic;");
//			WB.addLog2(
//					"Unit.test.ctor, unit1=" + unit1 + ", isExist=" + unit1.isExist() + ", isValid=" + unit1.isValid(),
//					WB.strEmpty, "Unit");
//			Unit unit2 = new Unit("Unit.tralala", WB.strEmpty, WB.strEmpty, WB.strEmpty, "Unit.tralala", WB.strEmpty,
//					WB.strEmpty, WB.strEmpty);
//			WB.addLog2(
//					"Unit.test.ctor, unit2=" + unit2 + ", isExist=" + unit2.isExist() + ", isValid=" + unit2.isValid(),
//					WB.strEmpty, "Unit");

		} catch (Exception ex) {
			WB.addLog("Unit.test, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Unit.test end ", WB.strEmpty, "Unit");
	}
}
