import java.util.ArrayList;
import java.util.List;

public class Unit extends ModelDto {
	// origin - 28.09.2023, last edit - 25.11.2024
	public List<UnitVal> weight, volume, lenght, width, height;
	public String MKEIcode, expectedValue;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Unit.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
	}

//	public static Unit getCurr(ModelDto currFA) throws Exception {// TODO
//		// origin - 23.11.2024, last edit - 25.11.2024
//		Unit res = new Unit("Unit.CurrUnit"); // ?? magic string ??
//		try {
//			if (currFA.geo.isEmpty() == false) {
//				res = new Unit(currFA.geo);// TODO
//			}
//		} catch (Exception ex) {
//			WB.addLog("Unit.getCurr, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("Unit.getCurr, res=" + res, WB.strEmpty, "Unit");
//		return res;
//	}

	public boolean isValid() throws Exception {
		// origin - 17.09.2024, last edit - 09.10.2024
		boolean res = true;
		try {
			if (this.parent.isEmpty()) {
				res = false;
			}
			if (this.role.isEmpty()) {
				res = false;
			}
		} catch (Exception ex) {
			WB.addLog("Unit.isValid, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Unit.isValid, res=" + res + ", this=" + this, WB.strEmpty,
		// "Unit");
		return res;
	}

	public boolean isExist() throws Exception {
		// origin - 17.09.2024, last edit - 20.11.2024
		boolean res = false;
		try {
			for (var currUnit : WB.abcLast.unit) {
				if ((Etc.strEquals(currUnit.id, this.id)) & (Etc.strEquals(currUnit.code, this.code))) {
					this.parent = currUnit.parent;
					this.description = currUnit.description;
					this.role = currUnit.role;
					this.more = currUnit.more;
					this.expectedValue = MoreVal.getFieldByKey(this.more, "AbcExpectedValue");
					this.MKEIcode = MoreVal.getFieldByKey(this.more, "MKEI");
					res = true;
					break;
				}
			}

		} catch (Exception ex) {
			WB.addLog("Unit.isExist, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Unit.isExist, res=" + res + ", this=" + this, WB.strEmpty,
		// "Unit");
		return res;
	}

//	public Unit(String Id, String Code, String Description) throws Exception {
//		// origin - 05.12.2023, last edit - 20.11.2024
//		// super(Id, Code, Description);
//		// this.table = this.getClass().getName();
//		this(Id);
//		this.code = Code;
//		this.description = Description;
//		this.isExist();
//		// this.isValid();
//	}

	public Unit(String Id) throws Exception {
		// origin - 02.10.2024, last edit - 25.11.2024
		this();
		this.id = Id;
		this.code = Id; // code = id for basic
		this.isExist();
	}

	public Unit() throws Exception {
		// origin - 05.12.2023, last edit - 25.11.2024
		this.clear();
		this.isExist();
		var root = Abc.getRoot(this.table); // get root from WB.abcLast
		this.id = root.id;
		this.code = root.code;
		this.description = root.description;
	}

	public void clear() throws Exception {
		// origin - 25.11.2024, last edit - 25.11.2024
		try {
			super.clear();
			this.table = this.getClass().getName();
			weight = volume = lenght = width = height = new ArrayList<UnitVal>();
			MKEIcode = expectedValue = WB.strEmpty;
		} catch (Exception ex) {
			WB.addLog("ModelDto.clear, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
	}

	public String toString() {
		// origin - 25.11.2024, last edit - 25.11.2024
		String res = WB.strEmpty;
		try {
			res = WB.strBraceLeft + this.table + WB.strCommaSpace + this.id + WB.strCommaSpace + this.parent
					+ WB.strCommaSpace + this.date1 + WB.strCommaSpace + this.date2 + WB.strCommaSpace + this.code
					+ WB.strCommaSpace + this.description + WB.strCommaSpace + this.role + WB.strCommaSpace + this.more
					+ WB.strBraceRight;
		} catch (Exception ex) {
			// WB.addLog2("Face.toString, ex=" + ex.getMessage(), WB.strEmpty, "Face");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 25.11.2024
		try {

//			// getCurr()
//			for (var testArg1 : WB.abcLast.FA) {
//				WB.addLog2("Unit.test.getCurr()=" + Unit.getCurr(testArg1), WB.strEmpty, "Unit");
//			}

			// ctor()
			WB.addLog2("Unit.test.ctor()=" + new Unit() + ", isExist=" + new Unit().isExist() + ", isValid="
					+ new Unit().isValid(), WB.strEmpty, "Unit");
			// ctor (String Id)
			WB.addLog2(
					"Unit.test.ctor('Unit.tralala')=" + new Unit("Unit.tralala") + ", isExist="
							+ new Unit("Unit.tralala").isExist() + ", isValid=" + new Unit("Unit.tralala").isValid(),
					WB.strEmpty, "Unit");
			WB.addLog2("Unit.test.ctor('Unit.KZT')=" + new Unit("Unit.KZT") + ", isExist="
					+ new Unit("Unit.KZT").isExist() + ", isValid=" + new Unit("Unit.KZT").isValid(), WB.strEmpty,
					"Unit");

		} catch (Exception ex) {
			WB.addLog("Unit.test, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Unit.test end ", WB.strEmpty, "Unit");
	}
}
