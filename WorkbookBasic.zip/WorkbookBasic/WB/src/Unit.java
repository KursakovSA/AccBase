public class Unit extends ModelDto {
	// origin - 28.09.2023, last edit - 17.09.2024
	// public List<Role> role = new ArrayList<Role>(); // TOTHINK may be keep
	// string ??

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Unit.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
	}

	public boolean isValid() throws Exception {
		// origin - 17.09.2024, last edit - 17.09.2024
		boolean res = super.isValid();
		try {
			if (this.parent.isEmpty()) {
				res = false;
			}
			if (this.role.isEmpty()) {
				res = false;
			}
		} catch (Exception ex) {
			WB.addLog("Unit.isValid, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Unit.isValid, res=" + res + ", this=" + this, WB.strEmpty,
		// "Unit");
		return res;
	}

	public boolean isExist() throws Exception {
		// origin - 17.09.2024, last edit - 17.09.2024
		boolean res = false;
		try {
			for (var currUnit : WB.abcLast.unit) {
				if (Etc.strEquals(currUnit.id, this.id)) {
					if (Etc.strEquals(currUnit.code, this.code)) {
						res = true;
						break;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Unit.isExist, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Unit.isExist, res=" + res + ", this=" + this, WB.strEmpty,
		// "Unit");
		return res;
	}

	public Unit(String Id, String Parent, String Date1, String Date2, String Code, String Description, String Role,
			String More) throws Exception {
		// origin - 13.09.2024, last edit - 17.09.2024
		// super(Id, Code, Description);
		super(WB.strEmpty, Id, Parent, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, Date1, Date2, Code,
				Description, WB.strEmpty, WB.strEmpty, WB.strEmpty, Role, WB.strEmpty, WB.strEmpty, WB.strEmpty,
				WB.strEmpty, More, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
				WB.strEmpty);
		this.table = this.getClass().getName();
	}

	public Unit(String Id, String Code, String Description) throws Exception {
		// origin - 05.12.2023, last edit - 11.08.2024
		super(Id, Code, Description);
		this.table = this.getClass().getName();
	}

	public Unit() throws Exception {
		// origin - 05.12.2023, last edit - 23.09.2024
		this.table = this.getClass().getName();
		// this(WB.strEmpty,WB.strEmpty,WB.strEmpty);
		var root = ModelDto.getRoot(this.table); //get unit root from WB.abcLast
		this.date1 = root.id;
		this.code = root.code;
		this.description = root.description;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 19.09.2024
		try {

//			// ctor
//			Unit unit1 = new Unit("Unit.Account", "Unit.Piece", WB.strEmpty, WB.strEmpty, "Unit.Account", "бухсчет",
//					"Role.Generic.Variant", "FullName=бухсчет;AbcBasic=Unit.Basic;");
//			WB.addLog2(
//					"Unit.test.ctor, unit1=" + unit1 + ", isExist=" + unit1.isExist() + ", isValid=" + unit1.isValid(),
//					WB.strEmpty, "Unit");
//			Unit unit2 = new Unit("Unit.tralala", WB.strEmpty, WB.strEmpty, WB.strEmpty, "Unit.tralala", WB.strEmpty,
//					WB.strEmpty, WB.strEmpty);
//			WB.addLog2(
//					"Unit.test.ctor, unit2=" + unit2 + ", isExist=" + unit2.isExist() + ", isValid=" + unit2.isValid(),
//					WB.strEmpty, "Unit");

		} catch (Exception ex) {
			WB.addLog("Unit.test, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Unit.test end ", WB.strEmpty, "Unit");
	}
}
