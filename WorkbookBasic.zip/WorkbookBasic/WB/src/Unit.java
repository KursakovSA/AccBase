import java.util.ArrayList;
import java.util.List;

public class Unit extends ModelDto {
	// origin - 28.09.2023, last edit - 07.01.2025

	public static Unit currUnit;
	public static String piece;
	public UnitVal weight, volume, lenght, width, height, duration; // TOTHINK maybe string ??
	public String MKEIcode, expectedValue, nameCent;
	public List<String> part;

	static {
		try {
			Unit.currUnit = new Unit(Geo.currCountry.unit);
			Unit.piece = "Unit.Piece";
			// WB.addLog2("Unit.currUnit=" + Unit.currUnit, WB.strEmpty, "Unit");
		} catch (Exception ex) {
			WB.addLog("Unit.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
	}

	private void getPart() throws Exception {
		// origin - 07.01.2025, last edit - 07.01.2025
		try {
			if (Etc.strEquals(this.role, Role.genericComposite)) {
				String tmp = Etc.fixTrim(this.code);
				// if (Etc.strContains(tmp, WB.strSlash)) {
				tmp = Etc.delStr(tmp, "Unit.");
				// String[] items = tmp.split(WB.strSlash);
				this.part = List.of(tmp.split(WB.strSlash));// items);
				// }
			}
		} catch (Exception ex) {
			WB.addLog("Unit.getPart, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
	}

	public void fix() throws Exception {
		// origin - 29.12.2024, last edit - 07.01.2025
		try {
			super.fix();
			this.role = DefVal.set(this.role, Role.genericBasic);
		} catch (Exception ex) {
			WB.addLog("Unit.fix, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
	}

	public void isValid() throws Exception {
		// origin - 17.09.2024, last edit - 11.12.2024
		super.isValid();
		try {
			if (this.parent.isEmpty() | this.role.isEmpty()) {
				this.isValid = false;
			}
		} catch (Exception ex) {
			WB.addLog("Unit.isValid, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Unit.isValid=" + this,WB.strEmpty,"Unit");
	}

	public void isExist() throws Exception {
		// origin - 17.09.2024, last edit - 07.01.2025
		super.isExist();
		try {
			for (var currUnit : WB.abcLast.unit) {
				if (Etc.strEquals(currUnit.id, this.id)) {
					this.code = currUnit.code;
					this.parent = currUnit.parent;
					this.description = currUnit.description;
					this.role = currUnit.role;
					this.more = currUnit.more;
					this.getPart();

					this.expectedValue = MoreVal.getFieldByKey(this.more, "AbcExpectedValue");
					this.MKEIcode = MoreVal.getFieldByKey(this.more, "MKEI");
					this.nameCent = MoreVal.getFieldByKey(this.more, "NameCent");
					this.weight = new UnitVal(MoreVal.getFieldByKey(this.more, "Weight"));
					this.volume = new UnitVal(MoreVal.getFieldByKey(this.more, "Volume"));
					this.lenght = new UnitVal(MoreVal.getFieldByKey(this.more, "Lenght"));
					this.width = new UnitVal(MoreVal.getFieldByKey(this.more, "Width"));
					this.height = new UnitVal(MoreVal.getFieldByKey(this.more, "Height"));
					this.duration = new UnitVal(MoreVal.getFieldByKey(this.more, "Duration"));

					this.isExist = true;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Unit.isExist, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Unit.isExist=" + this.isExist, WB.strEmpty,"Unit");
	}

	public Unit(String Id) throws Exception {
		// origin - 02.10.2024, last edit - 07.01.2025
		this();
		this.src = Id;
		if (Id.isEmpty() == false) {
			this.id = this.code = Id;
		}
		this.isExist();
		this.isValid();
		this.getPart();
		this.fix();
	}

	public Unit() throws Exception {
		// origin - 05.12.2023, last edit - 07.01.2025
		this.clear();
		this.isExist();
		var root = Abc.getRoot(this.table); // get root from WB.abcLast
		this.id = root.id;
		this.parent = root.parent;
		this.date1 = root.date1;
		this.date2 = root.date2;
		this.code = root.code;
		this.description = root.description;
		this.role = root.role;
		this.more = root.more;
		this.fix();
	}

	public void clear() throws Exception {
		// origin - 25.11.2024, last edit - 07.01.2025
		try {
			super.clear();
			this.table = this.getClass().getName();
			this.weight = this.volume = this.lenght = this.width = this.height = this.duration = new UnitVal();
			this.MKEIcode = this.expectedValue = this.nameCent = WB.strEmpty;
			this.part = new ArrayList<String>();
		} catch (Exception ex) {
			WB.addLog("Unit.clear, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
	}

	public String toString() {
		// origin - 25.11.2024, last edit - 13.01.2025
		String res = WB.strEmpty;
		try {
			res = res + Fmtr.addIfNotEmpty("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());

			res = res + Fmtr.addIfNotEmpty(", weight ", this.weight);
			res = res + Fmtr.addIfNotEmpty(", volume ", this.volume);
			res = res + Fmtr.addIfNotEmpty(", lenght ", this.lenght);
			res = res + Fmtr.addIfNotEmpty(", width ", this.width);
			res = res + Fmtr.addIfNotEmpty(", height ", this.height);
			res = res + Fmtr.addIfNotEmpty(", duration ", this.duration);
			res = res + Fmtr.addIfNotEmpty(", MKEIcode ", this.MKEIcode);
			res = res + Fmtr.addAnyway(", expectedValue ", this.expectedValue);
			res = res + Fmtr.addIfNotEmpty(", nameCent ", this.nameCent);
			// res = res + Fmtr.addAnyway(", part.size ", this.part.size());
			res = res + Fmtr.addAnyway(", part ", Fmtr.listVal(this.part, WB.strEmpty));

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 13.01.2025
		try {

//			// ctor ()
//			WB.addLog2("Unit.test.ctor()=" + new Unit(), WB.strEmpty, "Unit");

			// ctor (String Id)
			for (var tmp : new String[] { "Unit.KZT", "Unit.tralala", "Unit.MainDebt", "Unit.ExactDate",
					"Unit.Service/Login/Password", "Unit.EveryDayOnTime", "Unit.Percent" }) {
				WB.addLog2("Unit.test.ctor(String Id)=" + new Unit(tmp), WB.strEmpty, "Unit");
			}

		} catch (Exception ex) {
			WB.addLog("Unit.test, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Unit.test end ", WB.strEmpty, "Unit");
	}
}
