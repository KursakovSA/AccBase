public class Unit extends ModelDto {
	// origin - 28.09.2023, last edit - 04.08.2024

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Unit.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
	}

	public Unit(String Id, String Code, String Description) throws Exception {
		// origin - 05.12.2023, last edit - 04.08.2024
		super(Id, Code, Description);
	}

	public Unit() throws Exception {
		// origin - 05.12.2023, last edit - 04.08.2024
		super();
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 06.07.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Unit.test, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Unit.test end ", WB.strEmpty, "Unit");
	}
}
