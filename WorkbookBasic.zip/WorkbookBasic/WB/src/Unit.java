import java.util.ArrayList;
import java.util.List;

public class Unit extends ModelDto {
	// origin - 28.09.2023, last edit - 20.02.2025

	public static Unit currCurrency, minRate, minSalary;
	public static String strPiece, strMinRate, strMinSalary;
	public UnitVal weight, volume, lenght, width, height, duration; // TOTHINK maybe string ??
	public String MKEIcode, expectedValue, nameCent;
	public List<String> part; // TOTHINK

	static {
		try {
			Unit.strPiece = "Unit.Piece";
			Unit.strMinRate = "Unit.MinRate";
			Unit.strMinSalary = "Unit.MinSalary";
			Unit.currCurrency = new Unit(Geo.currCountry.currency);
			Unit.minRate = new Unit(Unit.strMinRate);
			Unit.minSalary = new Unit(Unit.strMinSalary);
			// WB.addLog2("Unit.currUnit=" + Unit.currUnit, WB.strEmpty, "Unit");
		} catch (Exception ex) {
			WB.addLog("Unit.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
	}

	private static double getTotalRatioConv(String fromCode, String toCode) throws Exception {
		// origin - 03.02.2025, last edit - 15.02.2025
		double res = WB.dblZero;
		try {
			var tmpLinkConv = Unit.getLinkConv(fromCode, toCode);
			if (tmpLinkConv.size() != WB.intZero) {
				res = WB.dblOne;
				for (var currRatioConv : tmpLinkConv) {
					// res = res * currRatioConv;
					res = Etc.multiply(res, currRatioConv);
				}
			}

		} catch (Exception ex) {
			WB.addLog("Unit.getTotalRatioConv, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Unit.getTotalRatioConv, res=" + res + ", fromCode=" + fromCode
		// +", toCode=" + toCode, WB.strEmpty, "Unit");
		return res;
	}

	private static List<Double> checkRatioConv(String currToCode, String toCode, List<Double> linkRatioConv)
			throws Exception {
		// origin - 14.02.2025, last edit - 15.02.2025
		List<Double> res = linkRatioConv;
		try {
			if (res.size() != WB.intZero) {
				if (Etc.strEquals(currToCode, toCode) == false) {
					res.clear();
				}
			}

		} catch (Exception ex) {
			WB.addLog("Unit.checkRatioConv, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Unit.checkRatioConv, res=" + res + ", currToCode=" + currToCode
		// +", toCode=" + toCode, ", linkRatioConv" + linkRatioConv, WB.strEmpty,
		// "Unit");
		return res;
	}

	private static List<Double> getLinkConv(String fromCode, String toCode) throws Exception {
		// origin - 03.02.2025, last edit - 15.02.2025
		List<Double> res = new ArrayList<Double>();
		try {
			double currRatioConv = WB.dblZero;
			String currToCode = WB.strEmpty;

			// same fromCode and toCode
			if (Etc.strEquals(fromCode, toCode)) {
				res.add(WB.dblOne);
				return res;
			}

			// toCode is next level under fromCode
			// direct
			currRatioConv = Unit.getConv(fromCode, toCode, WB.strEmpty).val;
			if (currRatioConv != WB.dblZero) {
				res.add(currRatioConv);
				return res;
			}
			// search reverse
			if (currRatioConv == WB.dblZero) {
				currRatioConv = Unit.getConv(toCode, fromCode, WB.strEmpty).val;
				if (currRatioConv != WB.dblZero) {
					res.add(Etc.reverseRatio(currRatioConv));
					return res;
				}
			}

			List<ModelDto> tmpListUnit = WB.abcLast.unit;
			String currFromCode = fromCode;

			// search lower ratioConv
			// tmpListUnit = WB.abcLast.unit;
			currRatioConv = WB.dblZero;
			currToCode = WB.strEmpty;
			// currFromCode = fromCode;
			for (;;) { // endless cycle
				currRatioConv = WB.dblZero;

				// stop if currFromCode == toCode
				if (Etc.strEquals(currFromCode, toCode)) {
					break;
				}

				// search next ratioConv
				for (var currUnitDto : tmpListUnit) {
					currRatioConv = Unit.getConv(currFromCode, currUnitDto.code, WB.strEmpty).val;
					if (currRatioConv != WB.dblZero) {
						res.add(currRatioConv);
						currFromCode = currUnitDto.code;
						currToCode = currUnitDto.code;
						break;
					}
				}

				// stop if in link conv no ratioConv
				if (currRatioConv == WB.dblZero) {
					break;
				}
			}
			res = Unit.checkRatioConv(currToCode, toCode, res);

			// if lower linkConv == 0 then search upper ratioConv
			if (res.size() == WB.intZero) {
				tmpListUnit = WB.abcLast.unit;
				currRatioConv = WB.dblZero;
				currFromCode = fromCode;
				currToCode = WB.strEmpty;
				for (;;) { // endless cycle
					currRatioConv = WB.dblZero;

					// stop if currFromCode == toCode
					if (Etc.strEquals(currFromCode, toCode)) {
						break;
					}

					// search next ratioConv
					for (var currUnitDto : tmpListUnit) {
						currRatioConv = Unit.getConv(currUnitDto.code, currFromCode, WB.strEmpty).val;
						if (currRatioConv != WB.dblZero) {
							res.add(Etc.reverseRatio(currRatioConv));
							currFromCode = currUnitDto.code;
							currToCode = currUnitDto.code;
							break;
						}
					}

					// stop if in link conv no ratioConv
					if (currRatioConv == WB.dblZero) {
						break;
					}
				}
				res = Unit.checkRatioConv(currToCode, toCode, res);
			}

		} catch (Exception ex) {
			WB.addLog("Unit.getLinkConv, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Unit.getLinkConv, res=" + res + ", fromCode=" + fromCode + ",
		// toCode=" + toCode + ", context=" + context, WB.strEmpty, "Unit");
		return res;
	}

	private static UnitVal getConv(String fromCode, String toCode, String context) throws Exception {
		// origin - 30.01.2025, last edit - 15.02.2025
		UnitVal res = new UnitVal();
		try {
			List<ModelDto> listDto = new ArrayList<ModelDto>();

			listDto = ReadSet.getEqualsByCode(WB.abcLast.unit, fromCode);
			if (listDto.size() != WB.intZero) {
				var dto = listDto.getFirst();
				Unit tmp = new Unit(dto.code);

				// weight, width, height -- not must be for conv, by idea

				// lenght
				if (tmp.lenght.src.isEmpty() == false) {
					if (Etc.strEquals(tmp.lenght.unit.code, toCode)) {
						UnitVal tmpUnitVal = new UnitVal(tmp.lenght.val, tmp.lenght.unit.code);
						return res = tmpUnitVal;
					}
				}

				// volume
				if (tmp.volume.src.isEmpty() == false) {
					if (Etc.strEquals(tmp.volume.unit.code, toCode)) {
						UnitVal tmpUnitVal = new UnitVal(tmp.volume.val, tmp.volume.unit.code);
						return res = tmpUnitVal;
					}
				}

				// duration
				if (tmp.duration.src.isEmpty() == false) {
					if (Etc.strEquals(tmp.duration.unit.code, toCode)) {
						UnitVal tmpUnitVal = new UnitVal(tmp.duration.val, tmp.duration.unit.code);
						return res = tmpUnitVal;
					}
				}
			}

		} catch (Exception ex) {
			WB.addLog("Unit.getConv, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("Unit.getConv, res=" + res + ", fromCode=" + fromCode + ", toCode=" + toCode + ", context=" + context, WB.strEmpty, "Unit");
		return res;
	}

	public static UnitVal сonv(String fromCode, String toCode, String context) throws Exception {
		// origin - 29.01.2025, last edit - 23.02.2025
		UnitVal res = new UnitVal(WB.dblZero, toCode);

		if (Etc.strEquals(fromCode, toCode)) {
			res = new UnitVal(WB.dblOne, fromCode);
			return res;
		}

		try {
//			// direct conv
//			var directLinkConv = Unit.getLinkConv(fromCode, toCode);
//			if (directLinkConv.size() != WB.intZero) {
//				res = Unit.getConv(fromCode, toCode, context);
//			}
//
//			// reverse conv
//			if (res.src.isEmpty()) {
//				var reverseLinkConv = Unit.getLinkConv(toCode, fromCode);
//				if (reverseLinkConv.size() != WB.intZero) {
//					var tmp = Unit.getConv(toCode, fromCode, context);
//					// if (tmp.val != 0.0) {
//					res = new UnitVal(Etc.reverseRatio(tmp.val), tmp.unit.code);
//					// }
//				}
//			}
//
//			// cross conv
//			if (res.src.isEmpty()) {
//				var crossLinkConv = Unit.getLinkConv(toCode, fromCode);
//				if (crossLinkConv.size() != WV.intZero) {
//					var totalRatioConv = Unit.getTotalRatioConv(toCode, fromCode);
//					// if (totalRatioConv != WB.dblZero) {
//					res = new UnitVal(totalRatioConv, toCode);
//					// }
//				}
//			}

			var totalRatioConv = Unit.getTotalRatioConv(fromCode, toCode);
			res = new UnitVal(totalRatioConv, toCode);

		} catch (Exception ex) {
			WB.addLog("Unit.сonv, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("Unit.сonv, res=" + res.id + ", fromCode=" + fromCode + ", toCode=" + toCode + ", context=" + context, WB.strEmpty, "Unit");
		return res;
	}

	private void getPart() throws Exception {
		// origin - 07.01.2025, last edit - 07.01.2025
		try {
			if (Etc.strEquals(this.role, Role.genericComposite)) {
				String tmp = Etc.fixTrim(this.code);
				// if (Etc.strContains(tmp, WB.strSlash)) {
				tmp = Etc.delStr(tmp, "Unit.");
				// String[] items = tmp.split(WB.strSlash);
				this.part = List.of(tmp.split(WB.strSlash));// items);
				// }
			}
		} catch (Exception ex) {
			WB.addLog("Unit.getPart, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
	}

	public void fix() throws Exception {
		// origin - 29.12.2024, last edit - 07.01.2025
		try {
			super.fix();
			this.role = DefVal.set(this.role, Role.genericBasic);
		} catch (Exception ex) {
			WB.addLog("Unit.fix, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
	}

	public void isValid() throws Exception {
		// origin - 17.09.2024, last edit - 11.12.2024
		super.isValid();
		try {
			if (this.parent.isEmpty() | this.role.isEmpty()) {
				this.isValid = false;
			}
		} catch (Exception ex) {
			WB.addLog("Unit.isValid, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Unit.isValid=" + this,WB.strEmpty,"Unit");
	}

	public void isExist() throws Exception {
		// origin - 17.09.2024, last edit - 01.02.2025
		super.isExist();
		try {
			for (var currUnit : WB.abcLast.unit) {
				if (Etc.strEquals(currUnit.id, this.id)) {
					this.code = currUnit.code;
					this.parent = currUnit.parent;
					this.description = currUnit.description;
					this.role = currUnit.role;
					this.more = currUnit.more;
					this.getPart();

					this.upper = super.getUpper(WB.abcLast.unit);
					this.lower = super.getLower(WB.abcLast.unit);

					this.expectedValue = MoreVal.getFieldByKey(this.more, "AbcExpectedValue");
					this.MKEIcode = MoreVal.getFieldByKey(this.more, "MKEI");
					this.nameCent = MoreVal.getFieldByKey(this.more, "NameCent");
					this.weight = new UnitVal(MoreVal.getFieldByKey(this.more, "Weight"));
					this.volume = new UnitVal(MoreVal.getFieldByKey(this.more, "Volume"));
					this.lenght = new UnitVal(MoreVal.getFieldByKey(this.more, "Lenght"));
					this.width = new UnitVal(MoreVal.getFieldByKey(this.more, "Width"));
					this.height = new UnitVal(MoreVal.getFieldByKey(this.more, "Height"));
					this.duration = new UnitVal(MoreVal.getFieldByKey(this.more, "Duration"));

					this.isExist = true;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Unit.isExist, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Unit.isExist=" + this.isExist, WB.strEmpty,"Unit");
	}

	public Unit(String Id) throws Exception {
		// origin - 02.10.2024, last edit - 01.02.2025
		this();
		this.src = Id;
		if (Id.isEmpty() == false) {
			this.id = this.code = Id;
		}
		this.isExist();
		this.isValid();
		this.getPart();
		this.fix();
	}

	public Unit() throws Exception {
		// origin - 05.12.2023, last edit - 07.01.2025
		this.clear();
		this.isExist();
		var root = Abc.getRoot(this.table); // get root from WB.abcLast
		this.id = root.id;
		this.parent = root.parent;
		this.date1 = root.date1;
		this.date2 = root.date2;
		this.code = root.code;
		this.description = root.description;
		this.role = root.role;
		this.more = root.more;
		this.fix();
	}

	public void clear() throws Exception {
		// origin - 25.11.2024, last edit - 07.01.2025
		try {
			super.clear();
			this.table = this.getClass().getName();
			this.weight = this.volume = this.lenght = this.width = this.height = this.duration = new UnitVal();
			this.MKEIcode = this.expectedValue = this.nameCent = WB.strEmpty;
			this.part = new ArrayList<String>();
		} catch (Exception ex) {
			WB.addLog("Unit.clear, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
	}

	public String toString() {
		// origin - 25.11.2024, last edit - 19.02.2025
		String res = WB.strEmpty;
		try {
			res = res + Fmtr.addIfNotEmpty("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());

			res = res + Fmtr.addAnyway(", upper ", Fmtr.listModelDto(this.upper, WB.strEmpty).length());
			res = res + Fmtr.addAnyway(", lower ", Fmtr.listModelDto(this.lower, WB.strEmpty).length());

			res = res + Fmtr.addIfNotEmpty(", weight ", this.weight.id);
			res = res + Fmtr.addIfNotEmpty(", volume ", this.volume.id);
			res = res + Fmtr.addIfNotEmpty(", lenght ", this.lenght.id);
			res = res + Fmtr.addIfNotEmpty(", width ", this.width.id);
			res = res + Fmtr.addIfNotEmpty(", height ", this.height.id);
			res = res + Fmtr.addIfNotEmpty(", duration ", this.duration.id);
			res = res + Fmtr.addIfNotEmpty(", MKEIcode ", this.MKEIcode);
			res = res + Fmtr.addAnyway(", expectedValue ", this.expectedValue);
			res = res + Fmtr.addIfNotEmpty(", nameCent ", this.nameCent);
			res = res + Fmtr.addAnyway(", part ", Fmtr.listVal(this.part, WB.strEmpty).length());

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 15.02.2025
		try {

//			// сonv
//			for (var сonvArg1 : new String[] { "Unit.Box", "Unit.Mcm", "Unit.Mm", "Unit.Cm", "Unit.Meter" }) {
//				for (var сonvArg2 : new String[] { "Unit.Mcm", "Unit.Mm", "Unit.Cm", "Unit.Meter" }) {
//					for (var сonvArg3 : new String[] { WB.strEmpty }) {// ", lenght" }) {
//						WB.addLog2(
//								"Unit.test.сonv, res=" + Unit.сonv(сonvArg1, сonvArg2, сonvArg3).id + ", fromCode="
//										+ сonvArg1 + ", toCode=" + сonvArg2 + ", context=" + сonvArg3,
//								WB.strEmpty, "Unit");
//					}
//				}
//			}

//			// getTotalRatioConv
//			for (var getTotalRatioConvArg1 : new String[] { "Unit.Box", "Unit.Mcm", "Unit.Mm", "Unit.Cm", "Unit.Meter" }) {
//				for (var getTotalRatioConvArg2 : new String[] { "Unit.Mcm", "Unit.Mm", "Unit.Cm", "Unit.Meter" }) {
//					WB.addLog2(
//							"Unit.test.getTotalRatioConv, res="
//									+ Unit.getTotalRatioConv(getTotalRatioConvArg1, getTotalRatioConvArg2)
//									+ ", fromCode=" + getTotalRatioConvArg1 + ", toCode=" + getTotalRatioConvArg2,
//							WB.strEmpty, "Unit");
//				}
//			}

//			// getLinkConv
//			for (var getLinkConvArg1 : new String[] { "Unit.Box", "Unit.Mcm", "Unit.Mm", "Unit.Cm", "Unit.Meter" }) {
//				for (var getLinkConvArg2 : new String[] { "Unit.Mcm", "Unit.Mm", "Unit.Cm", "Unit.Meter" }) {
//					WB.addLog2(
//							"Unit.test.getLinkConv, res=" + Unit.getLinkConv(getLinkConvArg1, getLinkConvArg2)
//									+ ", fromCode=" + getLinkConvArg1 + ", toCode=" + getLinkConvArg2,
//							WB.strEmpty, "Unit");
//				}
//			}

//			// ctor ()
//			WB.addLog2("Unit.test.ctor()=" + new Unit(), WB.strEmpty, "Unit");

//			// ctor (String Id)
//			for (var tmp : new String[] { "Unit.Meter", "Unit.KZT", "Unit.tralala", "Unit.MainDebt", "Unit.ExactDate",
//					"Unit.Service/Login/Password", "Unit.EveryDayOnTime", "Unit.Percent", "Unit.Month" }) {
//				WB.addLog2("Unit.test.ctor(String Id)=" + new Unit(tmp), WB.strEmpty, "Unit");
//			}

		} catch (

		Exception ex) {
			WB.addLog("Unit.test, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Unit.test end ", WB.strEmpty, "Unit");
	}
}
