public class Unit extends Model {
	// origin - 28.09.2023, last edit - 06.07.2024
	public Unit parent;
	public Role role;

	public Unit(String Id, String Code, String Description) throws Exception {
		// origin - 05.12.2023, last edit - 05.07.2024
		this.id = Id;
		this.code = Code;
		this.description = Description;
	}

	public Unit() throws Exception {
		// origin - 05.12.2023, last edit - 07.07.2024
		try {
		} catch (Exception ex) {
			WB.addLog("Unit.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 06.07.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Unit.test, ex=" + ex.getMessage(), WB.strEmpty, "Unit");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Unit.test end ", WB.strEmpty, "Unit");
	}
}
