import java.util.ArrayList;
import java.util.List;

public class User {
	// origin - 11.03.2025, last edit - 14.03.2025
	public boolean isValid, isExist;
	public String table, src, id, parent, code, description, geo, role, info, mark, more, staffTableId, fullName,
			comment;
	public ListVal date1, date2, permission, restriction;// TODO - permission, restriction
	public List<FaceDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("User.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "User");
		}
	}

	// full list user positions on date1
	public static List<FaceDto> getCurr(String date1, String parentId, String context) throws Exception {// context for
																											// different
		// origin - 11.03.2025, last edit - 14.03.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceByParent = DAL.getByTemplate(WB.lastConnWork, Qry.getParentFilter(parentId), "Face");
			for (var currFace : faceByParent) {
				if (Etc.strEquals(currFace.role, Role.faceUser)) {
					var currFaceUserNote = new User(currFace.id);
					var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceUserNote.val, WB.strEmpty);
					if (curr.id.isEmpty() == false) {
						var tmp = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
								curr.geo, curr.role, curr.info, curr.more, curr.mark);
						res.add(tmp);
						// WB.addLog2("User.getCurr, add tmp=" + tmp, WB.strEmpty,"User");
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("User.getCurr(List<FaceDto>), ex=" + ex.getMessage(), WB.strEmpty, "User");
		}
		return res;
	}

	// item user position on date1
	public static FaceDto getCurr(String date1, String faceUserId) throws Exception {
		// origin - 11.03.2025, last edit - 14.03.2025
		FaceDto res = new FaceDto();
		try {
			var currFaceUserNote = new User(faceUserId);
			if (currFaceUserNote.val.size() != 0) {
				var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceUserNote.val, WB.strEmpty);
				if (curr.id.isEmpty() == false) {
					res = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
							curr.geo, curr.role, curr.info, curr.more, curr.mark);
				}
			}
		} catch (Exception ex) {
			WB.addLog("User.getCurr(FaceDto), ex=" + ex.getMessage(), WB.strEmpty, "User");
		}
		return res;
	}

	private void getVal() throws Exception {
		// origin - 11.03.2025, last edit - 14.03.2025
		try {
			String currDate1 = WB.strEmpty;
			String currDate2 = WB.strEmpty;
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description, this.geo,
						this.role, this.info, this.more, this.mark);
				this.val.add(tmp);
//					WB.addLog2("User.getVal, add tmp=" + tmp, WB.strEmpty,"User");
			}
		} catch (Exception ex) {
			WB.addLog("User.getVal, ex=" + ex.getMessage(), WB.strEmpty, "User");
		}
	}

	public void isExist() throws Exception {
		// origin - 11.03.2025, last edit - 14.03.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getCodeFilter(this.code), this.table);
			if (listDto.size() != WB.intZero) {
				for (var currDto : listDto) {
					if ((Etc.strEquals(currDto.role, Role.faceUser))) {
						this.date1 = new ListVal(currDto.date1, WB.strEmpty);
						this.date2 = new ListVal(currDto.date2, WB.strEmpty);

						this.id = DefVal.setCustom(this.id, currDto.id);
						this.parent = DefVal.setCustom(this.parent, currDto.parent);
						this.code = DefVal.setCustom(this.code, currDto.code);
						this.description = DefVal.setCustom(this.description, currDto.description);
						this.geo = DefVal.setCustom(this.geo, currDto.geo);
						this.role = DefVal.setCustom(this.role, currDto.role);
						this.info = DefVal.setCustom(this.info, currDto.info);
						this.more = DefVal.setCustom(this.more, currDto.more);

						this.staffTableId = MoreVal.getFieldByKey(currDto.more, "StaffTableId");
						this.fullName = MoreVal.getFieldByKey(currDto.more, "FullName");
						this.comment = MoreVal.getFieldByKey(currDto.more, "Comment");

						this.mark = DefVal.setCustom(this.mark, currDto.mark);

						this.restriction = new ListVal(MoreVal.getFieldByKey(currDto.more, "Restriction"), WB.strEmpty);
						this.permission = new ListVal(MoreVal.getFieldByKey(currDto.more, "Permission"), WB.strEmpty);

						this.isExist = true;
						break;
					}
				}
			}

		} catch (Exception ex) {
			WB.addLog("User.isExist, ex=" + ex.getMessage(), WB.strEmpty, "User");
		}
	}

	public User(String faceUserId) throws Exception {
		// origin - 11.03.2025, last edit - 12.03.2025
		this();
		this.table = "Face"; // ??magic string??
		this.src = faceUserId;
		this.code = faceUserId;
		this.isExist();
		this.getVal();
	}

	public void clear() throws Exception {
		// origin - 11.03.2025, last edit - 14.03.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.more = this.mark = WB.strEmpty;
			this.staffTableId = this.fullName = this.comment = WB.strEmpty;
			this.date1 = this.date2 = this.restriction = this.permission = new ListVal();
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("User.clear, ex=" + ex.getMessage(), WB.strEmpty, "User");
		}
	}

	public User() throws Exception {
		// origin - 11.03.2025, last edit - 11.03.2025
		this.clear();
	}

	public String toString() {
		// origin - 11.03.2025, last edit - 12.03.2025
		String res = WB.strEmpty;
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);

			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);

			res = res + Fmtr.addIfNotEmpty(", staffTableId ", this.staffTableId);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);

			res = res + Fmtr.addIfNotEmpty(", restriction ", this.restriction.id);
			res = res + Fmtr.addIfNotEmpty(", permission ", this.permission.id);

			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 11.03.2025, last edit - 14.03.2025
		try {

//			// getCurr(List<FaceDto>)
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-31", "2025-02-20", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
//					WB.addLog2("User.test.getCurr(List<FaceDto>), res.size="
//							+ User.getCurr(tmp1, tmp2, WB.strEmpty).size() + ", date1=" + tmp1 + ", parentId="
//							+ tmp2, WB.strEmpty, "User");
//				}
//			}

//			// getCurr(FaceDto)
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-31", "2025-02-20", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1.User1", "Face.FA1.User2", "Face.Tralala.User1" }) {
//					WB.addLog2("User.test.getCurr, res.id=" + User.getCurr(tmp1, tmp2).id + ", date1=" + tmp1
//							+ ", faceUserId=" + tmp2, WB.strEmpty, "User");
//				}
//			}

//			// ctor()
//			WB.addLog2("User.test.ctor()=" + new User(), WB.strEmpty, "User");

//			// ctor (String, String)
//			for (var tmp1 : new String[] { "Face.FA1.User1", "Face.FA1.User2", "Face.Tralala.User1" }) {
//				WB.addLog2("User.test.ctor(String,String)=" + new User(tmp1), WB.strEmpty, "User");
//			}

		} catch (Exception ex) {
			WB.addLog("User.test, ex=" + ex.getMessage(), WB.strEmpty, "User");
		}
	}
}