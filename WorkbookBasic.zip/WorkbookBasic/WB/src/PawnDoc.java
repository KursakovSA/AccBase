import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

//@SuppressWarnings("unused")
public class PawnDoc extends Deal { // sectoralPawnshop //TODO
	// origin - 28.09.2024, last edit - 22.12.2024
	public RangeVal mainDebtLogicalMinMax = new RangeVal("1000.0 - 10000000.0(Unit.KZT)");
	public String pawnDocId = WB.strEmpty; // TODO

	public UnitVal amountDealMinLimit = new UnitVal("0.0(Unit.MinRate)");
	public UnitVal amountDealMaxLimit = new UnitVal("45.0(Unit.MinRate)");
	public UnitVal durationWarranty = new UnitVal("30.0(Unit.CalendarDay)");
	public UnitVal interestRate = new UnitVal("0.293(Unit.PercentPerDay)");
	public UnitVal penaltyRate = new UnitVal("0.3(Unit.PercentPerDay)");
	public UnitVal penaltyMinMax = new UnitVal("0.1(Unit.MainDebt)");

	// prolongation
	public UnitVal countProlongationMaxLimit = new UnitVal("0.0(Unit.Prolongation)"); // ?? int ??
	public List<LocalDate> prolongation = new ArrayList<LocalDate>();

	// pawn
	public List<Pawn> pawn = new ArrayList<Pawn>();
	public int countPawn = 1;// TODO
	public UnitVal countPawnMaxLimit = new UnitVal("10.0(Unit.Piece)");// TODO

	public UnitVal totalEstimatedValue = new UnitVal("0.0(Unit.KZT)");
	public UnitVal totalAccrualInterest = new UnitVal("0.0(Unit.KZT)");
	public UnitVal restInterest = new UnitVal("0.0(Unit.KZT)");
	public UnitVal totalAccrualPenalty = new UnitVal("0.0(Unit.KZT)");
	public UnitVal restPenalty = new UnitVal("0.0(Unit.KZT)");

	public UnitVal mainDebt = new UnitVal("0.0(Unit.KZT)");
	public UnitVal restMainDebt = new UnitVal("0.0(Unit.KZT)");
	public List<String> additionalAgreement = new ArrayList<String>();

	public Accrual accrual = new Accrual(); // TODO

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("PawnDoc.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "PawnDoc");
		} finally {
			Etc.doNothing();
		}
	}

//	private void getDuration() throws Exception {
//		// origin - 18.09.2024, last edit - 20.09.2024
//		try {
//			var res1 = (double) ChronoUnit.DAYS.between(this.startDate, this.endDate);
//			var res2 = this.billingCycle.partUnit;
//			// this is res
//			this.duration = new UnitVal(Etc.fixTrim(Etc.fixString(res1)), Etc.fixTrim(Etc.fixString(res2)));
//			// WB.addLog2("Deal.getDuration, this.duration=" + this.duration, WB.strEmpty,
//			// "Deal");
//		} catch (Exception ex) {
//			WB.addLog("Deal.getDuration, ex=" + ex.getMessage(), WB.strEmpty, "Deal");
//		} finally {
//			Etc.doNothing();
//		}
//	}

//	public boolean isValid() throws Exception {
//		// origin - 18.09.2024, last edit - 18.09.2024
//		boolean res = super.isValid();
//		try {
//			if (this.parent.isEmpty()) {
//				res = false;
//			}
//			if (this.face1.isEmpty()) {
//				res = false;
//			}
//			if (this.geo.isEmpty()) {
//				res = false;
//			}
//			if (this.role.isEmpty()) {
//				res = false;
//			}
//			if (this.info.isEmpty()) {
//				res = false;
//			}
//		} catch (Exception ex) {
//			WB.addLog("Deal.isValid, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Deal");
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("Deal.isValid, res=" + res + ", this=" + this, WB.strEmpty,
//		// "Deal");
//		return res;
//	}

//	public boolean isExist() throws Exception {
//		// origin - 18.09.2024, last edit - 18.09.2024
//		boolean res = false;
//		try {
//			var tableDto = DAL.getByTemplate(WB.lastConnWork, Qry.getMoreFilter(this.table), this.table);
//			for (var currDto : tableDto) {
//				if (Etc.strEquals(currDto.id, this.src.id)) {
//					if (Etc.strEquals(currDto.code, this.src.code)) {
//						if (Etc.strEquals(currDto.description, this.src.description)) {
//							res = true;
//							break;
//						}
//					}
//				}
//				// res = this.isMatch(currDto);
//				// break;
//			}
//		} catch (Exception ex) {
//			WB.addLog("Deal.isExist, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Deal");
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("Deal.isExist, res=" + res + ", this=" + this, WB.strEmpty,
//		// "Deal");
//		return res;
//	}

//	private boolean isOutsideDefault() throws Exception {// TODO
//		// origin - 12.09.2024, last edit - 12.09.2024
//		boolean res = false;
//		try {
//		} catch (Exception ex) {
//			WB.addLog("Deal.isOutsideDefault, ex=" + ex.getMessage(), WB.strEmpty, "Deal");
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("Deal.isOutsideDefault, res=" + res, WB.strEmpty, "Deal");
//		return res;
//	}

//	private boolean isOutsideDuration() throws Exception {
//		// origin - 12.09.2024, last edit - 20.09.2024
//		boolean res = false;
//		try {
//			if (this.durationDealMaxLimit.val != 0.0) {
//				if (this.duration.val != 0.0) {
//					if (this.duration.val != this.durationDealMaxLimit.val) {
//						res = true;
//					}
//				}
//			}
//		} catch (Exception ex) {
//			WB.addLog("Deal.isOutsideDuration, ex=" + ex.getMessage(), WB.strEmpty, "Deal");
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("Deal.isOutsideDuration, res=" + res, WB.strEmpty, "Deal");
//		return res;
//	}

//	private void correctByDefault() throws Exception {// TODO
//		// origin - 12.09.2024, last edit - 12.09.2024
//		try {
//		} catch (Exception ex) {
//			WB.addLog("Deal.correctByDefault, ex=" + ex.getMessage(), WB.strEmpty, "Deal");
//		} finally {
//			Etc.doNothing();
//		}
////		WB.addLog2("Deal.correctByDefault, this.endDate=" + this.endDate
////				+ ", endDateBeforeCorrect = " + endDateBeforeCorrect, WB.strEmpty, "Deal");
//	}

//	private void correctByDuration() throws Exception {
//		// origin - 10.09.2024, last edit - 20.09.2024
//		try {
//			if (this.isOutsideDuration()) {
////						WB.addLog2("Deal.correctEndDateByDuration, before correct this.Date2=" + this.Date2,
////								WB.strEmpty, "Deal");
////						this.Date2.removeLast();
////						this.Date2.add(DateTool.getEndDateFromDuration(this.startDate, this.durationCreditMaxLimit)); // this
////																														// is
////																														// res
////						WB.addLog2("Deal.correctByDuration, after correct this.Date2=" + this.Date2, WB.strEmpty,
////								"Deal");
////						this.endDate = this.Date2.getLast(); // this is res
////						this.duration = DateTool.getDuration(this.endDate, this.startDate); // this is res
//
////						WB.addLog2("Deal.correctEndDateByDuration, before correct this.date2=" + this.date2,
////								WB.strEmpty, "Deal");
//
//				this.date2.removeLast();// ?? if find what last = enddate ??
//
//				this.date2.add(DateTool.getEndDateFromDuration(this.startDate, (int) this.durationDealMaxLimit.val)); // this
//				// is
//				// res
////						WB.addLog2("Deal.correctByDuration, after correct this.date2=" + this.date2, WB.strEmpty,
////								"Deal");
//				this.endDate = this.date2.getLast(); // this is res
//				this.getDuration(); // this is res
//			}
//			// }
//			// }
//		} catch (Exception ex) {
//			WB.addLog("Deal.correctByDuration, ex=" + ex.getMessage(), WB.strEmpty, "Deal");
//		} finally {
//			Etc.doNothing();
//		}
////		WB.addLog2("Deal.correctByDuration, this.endDate=" + this.endDate
////				+ ", endDateBeforeCorrect = " + endDateBeforeCorrect, WB.strEmpty, "Deal");
//	}

//	private void getDate() throws Exception {
//		// origin - 08.09.2024, last edit - 27.09.2024
//		try {
//			var lst1 = Formatter.listVal(this.src.date1, WB.strSemiColon);
//			this.date1 = Formatter.listStr(lst1); // this is res
//			this.startDate = this.date1.getFirst(); // this is res
//
//			if (this.startDate == null) {
//				this.startDate = DateTool.getNow();
//			}
//
//			var lst2 = Formatter.listVal(this.src.date2, WB.strSemiColon);
//			this.date2 = Formatter.listStr(lst2); // this is res
//			this.endDate = this.date2.getLast(); // this is res
//
//			if (this.endDate == null) {
//				this.endDate = DateTool.getNow();
//			}
//
//			this.getDuration(); // this is res
//			this.correctByDuration(); // ?? take outside ??
//		} catch (Exception ex) {
//			WB.addLog("Deal.getDate, ex=" + ex.getMessage(), WB.strEmpty, "Deal");
//		} finally {
//			Etc.doNothing();
//		}
////		WB.addLog2("Deal.getDate, this.startDate=" + this.startDate + ", this.endDate=" + this.endDate
////				+ ", this.duration=" + this.duration, WB.strEmpty, "Deal");
//	}

//	public void getTemplate() throws Exception { // TODO
//		// origin - 07.09.2024, last edit - 20.09.2024
//		if (this.src != null) {
//			this.template.add(this.src); // ?? first line template = src ??
//		}
//	}

	public PawnDoc(String Table, String Id, String Parent, String Face1, String Face2, String Face, String Date1,
			String Date2, String Code, String Description, String Geo, String Role, String Info, String More)
			throws Exception { // TOTHINK
		// origin - 28.09.2024, last edit - 28.09.2024
		super(Table, Id, Parent, Face1, Face2, Face, Date1, Date2, Code, Description, Geo, Role, Info, More);
//		this();
//		this.src.table = Table;
//		this.src.id = Id;
//		this.src.parent = Parent;
//		this.src.face1 = Face1;
//		this.src.face2 = Face2;
//		this.src.face = Face;
//
//		this.src.date1 = Date1;
//		if (Date1.isEmpty()) {
//			this.src.date1 = DateTool.getNow().toString();
//		}
//		this.src.date2 = Date2;
////		if (Date2.isEmpty()) {
////			this.src.date2 = DateTool.getNow().toString();
////		}
//		this.src.code = Code;
//		this.src.description = Description;
//		this.src.geo = Geo;
//		this.src.role = Role;
//		this.src.info = Info;
//		this.src.more = More;
//		this.getDate();
	}

	public PawnDoc(ModelDto dto) throws Exception { // TOTHINK
		// origin - 28.09.2024, last edit - 28.09.2024
		super(dto);
	}

	public PawnDoc() throws Exception {
		// origin - 28.09.2024, last edit - 28.09.2024
		super();
	}

	public static void test() throws Exception {
		// origin - 28.09.2024, last edit - 28.09.2024
		try {

//			// isValid, isExist
//			Deal deal1 = new Deal("Deal", "Deal.Face.FA1.boss", "Deal.enbek.staff", "Face.FA1", WB.strEmpty,
//					WB.strEmpty, WB.strEmpty, WB.strEmpty, "Deal.Face.FA1.boss", "директор", "Geo.Qazaqstan",
//					"Role.Deal.Frame", "Info.Deal.Staff", WB.strEmpty);
//			WB.addLog2(
//					"Deal.test.ctor, deal1=" + deal1 + ", isExist=" + deal1.isExist() + ", isValid=" + deal1.isValid(),
//					WB.strEmpty, "Deal");
//			Deal deal2 = new Deal("Deal", WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					"Deal.tralala", "Deal.tralala", WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty);
//			WB.addLog2(
//					"Deal.test.ctor, deal2=" + deal2 + ", isExist=" + deal2.isExist() + ", isValid=" + deal2.isValid(),
//					WB.strEmpty, "Unit");

//			// ctor ("date1", "date2") different variants
//			Deal newDeal1 = new Deal(WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					"2024-09-01", "2024-09-11", WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					WB.strEmpty);
//			WB.addLog2("Deal.test.ctor(dto), newDeal1=" + newDeal1, WB.strEmpty, "Deal");
//			Deal newDeal2 = new Deal(WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					"2024-09-01;2024-09-06", "2024-09-11;2024-09-16", WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					WB.strEmpty, WB.strEmpty, WB.strEmpty);
//			WB.addLog2("Deal.test.ctor(dto), newDeal2=" + newDeal2, WB.strEmpty, "Deal");
//			Deal newDeal3 = new Deal(WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					"2024-09-01;2024-09-06;", "2024-09-11;2024-09-16;", WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					WB.strEmpty, WB.strEmpty, WB.strEmpty);
//			WB.addLog2("Deal.test.ctor(dto), newDeal3=" + newDeal3, WB.strEmpty, "Deal");
//			// test correctByDuration
//			Deal newDeal4 = new Deal(WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					"2024-09-01", "2024-09-11;2025-09-16;", WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					WB.strEmpty, WB.strEmpty);
//			WB.addLog2("Deal.test.ctor(dto), newDeal4=" + newDeal4, WB.strEmpty, "Deal");

//			// getId
//			Deal newDeal = new Deal();
//			WB.addLog2("Deal.getId(), res=" + newDeal.getId(), WB.strEmpty, "Face");
//			WB.addLog2("Deal.getId('', ''), res=" + newDeal.getId("", ""), WB.strEmpty, "Face");
//			WB.addLog2("Deal.getId('DealId', ''), res=" + newDeal.getId("DealId", ""), WB.strEmpty, "Deal");
//			WB.addLog2("Deal.getId('DealId', 'idStringGrowingDigitalInfobase'), res="
//					+ newDeal.getId("DealId", "idStringGrowingDigitalInfobase"), WB.strEmpty, "Deal");
//			WB.addLog2("Deal.getId('DealId', 'idStringGrowingDigitalGlobal'), res="
//					+ newDeal.getId("DealId", "idStringGrowingDigitalGlobal"), WB.strEmpty, "Deal");
//			WB.addLog2("Deal.getId('DealId', 'idIntegerGrowingDigitalGlobal'), res="
//					+ newDeal.getId("DealId", "idIntegerGrowingDigitalGlobal"), WB.strEmpty, "Deal");
//			WB.addLog2("Deal.getId('PawnId', ''), res=" + newDeal.getId("PawnId", ""), WB.strEmpty, "Deal");
//			WB.addLog2("Deal.getId('PawnId', 'idStringGrowingDigitalInfobase'), res="
//					+ newDeal.getId("PawnId", "idStringGrowingDigitalInfobase"), WB.strEmpty, "Deal");
//			WB.addLog2("Deal.getId('PawnId', 'idStringGrowingDigitalGlobal'), res="
//					+ newDeal.getId("PawnId", "idStringGrowingDigitalGlobal"), WB.strEmpty, "Deal");
//			WB.addLog2("Deal.getId('PawnId', 'idIntegerGrowingDigitalGlobal'), res="
//					+ newDeal.getId("PawnId", "idIntegerGrowingDigitalGlobal"), WB.strEmpty, "Deal");

		} catch (Exception ex) {
			WB.addLog("PawnDoc.test, ex=" + ex.getMessage(), WB.strEmpty, "PawnDoc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("PawnDoc.test end ", WB.strEmpty, "PawnDoc");
	}
}