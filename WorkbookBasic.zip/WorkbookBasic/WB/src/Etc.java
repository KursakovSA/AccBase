import java.io.File;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;

public class Etc {
	// origin - 01.10.2023, last edit - 16.01.2024
	public static int round0;
	public static int round2;
	public static int roundDefault;
	public static int round4;

	static {
		round0 = 0;
		round2 = 2;
		roundDefault = round2;
		round4 = 4;
	}

	public static OffsetDateTime getOffsetDateTime(String expectedDate) {// TODO
		// origin - 24.11.2023, last edit - 08.01.2024
		OffsetDateTime res;
		expectedDate = fixTrim(expectedDate);
		try {
			res = OffsetDateTime.parse(expectedDate);
		} catch (Exception ex) {
			// res = OffsetDateTime.of(expectedDate, null, null);
			res = null;
			// Logger.add("getOffsetDateTime, ex=" + ex.getMessage(), ", StackTrace=" +
			// ex.getStackTrace(), "Etc");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static LocalDate getLocalDate(String expectedDate) {// TODO
		// origin - 24.11.2023, last edit - 08.01.2024
		LocalDate res = null;
		expectedDate = fixTrim(expectedDate);
		try {
			res = LocalDate.parse(expectedDate);
			res = fixLocalDate(res);
		} catch (Exception ex) {
			res = null;
			// Logger.add("getOffsetDateTime, ex=" + ex.getMessage(), ", StackTrace=" +
			// ex.getStackTrace(), "Etc");
		} finally {
			if (res == null) {
				res = LocalDate.now();
			}
		}
		return res;
	}

	public static LocalTime getLocalTime(String expectedDate) {// TODO
		// origin - 24.11.2023, last edit - 08.01.2024
		LocalTime res;
		expectedDate = fixTrim(expectedDate);
		try {
			res = LocalTime.parse(expectedDate);
		} catch (Exception ex) {
			res = null;
			// Logger.add("getOffsetDateTime, ex=" + ex.getMessage(), ", StackTrace=" +
			// ex.getStackTrace(), "Etc");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static String fixDouble(String strFix) {
		// origin - 10.01.2024, last edit - 10.01.2024
		strFix = fixTrim(strFix);

		if (strFix.endsWith(",0")) {//fix fraction separator
			strFix = strFix.substring(0, strFix.length() - 2) + ".0";
		}

		if (strFix.endsWith(",00")) {//fix fraction separator
			strFix = strFix.substring(0, strFix.length() - 3) + ".0";
		}

		if (strFix.endsWith(",000")) {//fix fraction separator
			strFix = strFix.substring(0, strFix.length() - 4) + ".0";
		}

		if (strFix.endsWith(",0000")) {//fix fraction separator
			strFix = strFix.substring(0, strFix.length() - 5) + ".0";
		}
		
		if (strFix.endsWith(",00000")) {//fix fraction separator
			strFix = strFix.substring(0, strFix.length() - 6) + ".0";
		}
		
		if (strFix.indexOf(",") == strFix.lastIndexOf(",")){//if substr contain one char "," ex. "14,8464554"
			strFix = strFix.replace(",", "");
		}
		
		strFix = strFix.replaceAll(",", "");
		strFix = strFix.replaceAll(" ", "");// del space, because spaces not need for double number
		return strFix;
	}

	public static String getLabelDateTimeForFileName() {
		// origin - 27.12.2023, last edit - 06.01.2024
		String res = fixTrim(getLocalDateTimeNow().toString());
		res = res.replaceAll("-", "_");
		res = res.replaceAll(":", "_");
		res = res + "_";
		return res;
	}

	public static String getSourceUrl(String source, String file) {
		// origin - 25.12.2023, last edit - 25.12.2023
		String res = fixTrim(source) + fixTrim(file);
		return res;
	}

	public static String getFileName(String urlFrom) {
		// origin - 25.12.2023, last edit - 25.12.2023
		String res = "";
		try {
			File file = new File(urlFrom);
			res = fixTrim(file.getName());
		} catch (Exception ex) {
			Logger.add("Etc.getFileName, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace() + ", res=" + res,
					"", "Etc");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void doNothing() {
		// origin - 23.12.2023, last edit - 23.12.2023
	}

	public static String delStr(String viewName, String delWord) {
		// origin - 30.10.2023, last edit - 24.11.2023
		String res = "";
		res = fixTrim(viewName); // delete all space
		res = res.replace(delWord, ""); // delete word if it exist
		res = fixTrim(res); // delete all space
		return res;
	}

	public static int getDuration(OffsetDateTime date1, OffsetDateTime date2) {// less test
		// origin - 21.10.2023, last edit - 09.11.2023
		return Math.abs((int) Etc.roundCustom(Duration.between(date2, date1).toMillis(), round0));
	}

	public static OffsetDateTime getOffsetDateTimeNow() {
		// origin - 21.10.2023, last edit - 24.11.2023
		return OffsetDateTime.now(ZoneOffset.systemDefault().getRules().getOffset(Instant.now()));
	}

	public static LocalDateTime getLocalDateTimeNow() {
		// origin - 18.12.2023, last edit - 18.12.2023
		return LocalDateTime.now(ZoneOffset.systemDefault().getRules().getOffset(Instant.now()));
	}

	public static double ratio100(double ratePercent) {
		// origin - 17.10.2023, last edit - 17.10.2023
		double res = 0.0;
		res = ratePercent / 100.0;
		res = roundCustom(res, round4);
		return res;
	}

	public static boolean strEqual(String str1, String str2) {
		// origin - 18.10.2023, last edit - 18.10.2023
		boolean res = false;
		str1 = fixTrim(str1);
		str2 = fixTrim(str2);
		res = str1.equalsIgnoreCase(str2) == true ? true : res;
		return res;
	}
	
	public static double roundTax(double sum, String codeTax) {
		// origin - 16.01.2024, last edit - 16.01.2024
		double res = sum;
		if (codeTax.toLowerCase().contains("VAT".toLowerCase())) {
			res = roundCustom(sum, round2);// for VAT round with cents
		} else {
			res = roundCustom(sum, 0);
		}
		return res;
	}

	public static double roundCustom(double sum) {
		// origin - 17.10.2023, last edit - 17.10.2023
		// variant round less number fractional digit as argument, take him = 2
		double res = sum;
		res = roundCustom(sum, roundDefault); // default round
		return res;
	}

	public static double roundCustom(double sum, int numberFractionalDigit) {
		// origin - 16.10.2023, last edit - 17.10.2023
		double res = sum;
		int power10 = (int) Math.pow(10, numberFractionalDigit);
		res = sum * power10;
		res = Math.round(res);
		res = res / power10;
		return res;
	}

	public static LocalDate fixLocalDate(LocalDate fixDate) {
		// origin - 02.10.2023, last edit - 20.11.2023
		// LocalDate not must be big maxDateSupported and least minDateSupported
		LocalDate res = fixDate;
		if (fixDate.isBefore(WB.minDateSupported)) {
			res = WB.minDateSupported;
		}
		if (fixDate.isAfter(WB.maxDateSupported)) {
			res = WB.maxDateSupported;
		}
		return res;
	}

	public static String fixString(Object fixObj) {
		// origin - 12.11.2023, last edit - 12.11.2023
		String res = "";
		try {
			res = fixObj.toString();
		} catch (Exception ex) {
			res = "";
		} finally {
			res = fixTrim(res);
		}
		return res;
	}

	public static String fixTrim(String fixStr) {
		// origin - 02.10.2023, last edit - 23.12.2023
		String res = "";
		try {
			res = fixStr.strip();
		} catch (Exception ex) {
			res = "";
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static double setZeroOnNeg(Number fixNumb) {
		// origin - 01.10.2023, last edit - 21.10.2023
		// for tax calculate and etc where not need be negative number
		double res = (double) fixNumb;
		res = res < 0 ? 0 : res;
		return (double) res;
	}

	public static void test() {
		// origin - 01.10.2023, last edit 16.01.2024
		var testUrl = new String[] { "https://lom-bard.kz/static/reports/2022/otchet_ff.pdf",
				"C:\\testDir\\testFile.txt" };
		var testDateTime1 = new String[] { "2023-11-24T06:46:16.907+06:00", "2023-11-08 02:15:09", "06:46:16.907+06:00",
				"2019-01-01", "test1", "12.45", null };

		// fixDouble
		for (String testArg1 : new String[] { "17420", "17 420", "17420.0", "17420.00", "17420,0", "17420,00",
				"17420,000", "17420,0000", "17 420.00", "-17420", "17420 - 18560", "34.152562", "34,152562", "34,153,600.2",
				"34 153 600.2", "34153600.2" }) {
			Logger.add2("Etc.test.fixDouble, res=" + fixDouble(testArg1) + ", testArg1=" + testArg1, "", "Etc");
		}

		// getFileName
		for (var testArg1 : testUrl) {
			Logger.add2("Etc.test.getFileName, res=" + getFileName(testArg1) + ", testArg1=" + testArg1, "", "Etc");
		}

		// getOffsetDateTime
		for (var testArg1 : testDateTime1) {
			Logger.add2("Etc.test.getOffsetDateTime, res=" + getOffsetDateTime(testArg1) + ", testArg1=" + testArg1, "",
					"Etc");
		}

		// getLocalDate
		for (var testArg1 : testDateTime1) {
			Logger.add2("Etc.test.getLocalDate, res=" + getLocalDate(testArg1) + ", testArg1=" + testArg1, "", "Etc");
		}

		// getLocalTime
		for (var testArg1 : testDateTime1) {
			Logger.add2("Etc.test.getLocalTime, res=" + getLocalTime(testArg1) + ", testArg1=" + testArg1, "", "Etc");
		}

		// subtract
		double testNum1 = 5000000.02;
		double testNum2 = 5000000.01;
		Logger.add2("Etc.test, roundCustom(testNum1 - testNum2)=" + roundCustom(testNum1 - testNum2) + ", testNum1="
				+ testNum1 + ", testNum2=" + testNum2, "", "Etc");

		// fixString
		for (var testArg1 : new Object[] { "test1", 12.45, new Asset(), null }) {
			Logger.add2("Etc.test.fixString, res=" + fixString(testArg1) + ", testArg1=" + testArg1, "", "Etc");
		}

		// strEqual
		String str2 = "test1";
		for (String testArg1 : new String[] { "test1", "test1 ", " tEst1", "TEST1", "test22" }) {
			Logger.add2(
					"Etc.test.strEqual, res=" + strEqual(testArg1, str2) + ", testArg1=" + testArg1 + ", str2=" + str2,
					"", "Etc");
		}

		// ratio100
		for (double testArg1 : new double[] { 100.0, 67.43, 0.00, 23.56452, 12.0, 234.65432 }) {
			Logger.add2("Etc.test.ratio100, res=" + ratio100(testArg1) + ", testArg1=" + testArg1, "", "Etc");
		}
		
		// roundTax
		for (double testArg1 : new double[] { 100.0, 57.4363, 43.0078, 21.212, 34.7845 }) {
			for (String testArg2 : new String[] { "Debt.VAT.Sell.RateBasic", "Debt.Pension.OPV.RateBasic" }) {
			Logger.add2("Etc.test.roundTax, res=" + roundTax(testArg1, testArg2) + ", testArg1=" + testArg1
					+ ", testArg2=" + testArg2, "", "Etc");
		}}

		// roundCustom - round2
		for (double testArg1 : new double[] { 100.0, 57.4363, 43.0078, 21.212, 34.7845 }) {
			Logger.add2("Etc.test.roundCustom, res=" + roundCustom(testArg1, round2) + ", testArg1=" + testArg1
					+ ", numberFractionalDigit=" + round2, "", "Etc");
		}

		// roundCustom - round0
		for (double testArg1 : new double[] { 100.0, 57.4363, 43.0078, 21.212, 34.7845 }) {
			Logger.add2("Etc.test.roundCustom, res=" + roundCustom(testArg1, round0) + ", testArg1=" + testArg1
					+ ", numberFractionalDigit=" + round0, "", "Etc");
		}

		// fixLocalDate
		for (LocalDate testArg1 : new LocalDate[] { LocalDate.of(2026, 4, 28), LocalDate.of(1967, 11, 25),
				LocalDate.of(2100, 5, 26) }) {
			Logger.add2("Etc.test.fixLocalDate, res=" + fixLocalDate(testArg1) + ", testArg1=" + testArg1, "", "Etc");
		}

		// fixTrim
		for (String testArg1 : new String[] { "test1", "test2 ", " test3", " test4 " }) {
			Logger.add2("Etc.test.fixTrim, res=" + fixTrim(testArg1) + ", testArg1=" + testArg1, "", "Etc");
		}

		// setZeroOnNeg
		for (double testArg1 : new double[] { 1.25, -41.2556, 0.0, 0.0002, -0.0002, 64.1278 }) {
			Logger.add2("Etc.test.setZeroOnNeg, res=" + setZeroOnNeg(testArg1) + ", testArg1=" + testArg1, "", "Etc");
		}
	}
}
