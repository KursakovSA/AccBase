import java.io.File;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@SuppressWarnings("unused")
public class Etc {
	// origin - 01.10.2023, last edit - 04.11.2024
	public static int round0;
	public static int round2;
	public static int roundDefault;
	public static int round4;
	public static int initRndDefault;

	static {
		try {
			Etc.round0 = 0;
			Etc.round2 = 2;
			Etc.roundDefault = round2;
			Etc.round4 = 4;
			Etc.initRndDefault = 0;
		} catch (Exception ex) {
			WB.addLog("Etc.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
	}

	public static int strMatch(String inStr, String findStr) throws Exception {// lenght findStr is any, so !!!
		// origin - 14.09.2024, last edit - 08.11.2024
		int res = 0;

		// inStr = Etc.fixTrim(inStr); //sometimes find strings contains spaces
		// findStr = Etc.fixTrim(findStr); //sometimes find strings contains spaces

		try {
			int beginIndex = 0;
			int endIndex = beginIndex + findStr.length();
			String tmp = WB.strEmpty;
			if (endIndex <= inStr.length()) {
				tmp = inStr.substring(beginIndex, endIndex);
			}
			// WB.addLog2("Etc.matchStr, tmp1=" + tmp + ", inStr=" + inStr + ", findStr=" +
			// findStr, WB.strEmpty, "Etc");
			while (tmp.length() == findStr.length()) {
				if (Etc.strEquals(tmp, findStr)) {
					res = res + 1;
				}
				beginIndex = beginIndex + 1;
				endIndex = beginIndex + findStr.length();
				tmp = WB.strEmpty;
				if (endIndex <= inStr.length()) {
					tmp = inStr.substring(beginIndex, endIndex);
				}
				// WB.addLog2("Etc.matchStr, tmp2=" + tmp + ", inStr=" + inStr + ", findStr=" +
				// findStr, WB.strEmpty,
				// "Etc");
			}

		} catch (Exception ex) {
			WB.addLog("Etc.strMatch, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Etc.strMatch, res=" + res + ", inStr=" + inStr + ", findStr=" +
		// findStr, WB.strEmpty, "Etc");
		return res;
	}

	public static String delLeaderPlaceholder(String inStr, String placeholder) throws Exception {// del all leader
																									// placeholder
		// origin - 26.08.2024, last edit - 26.08.2024
		String res = Etc.fixTrim(inStr);
		try {
			res = res.replaceAll("^" + placeholder + "+", "");
		} catch (Exception ex) {
			WB.addLog("Etc.delLeaderPlaceholder, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Etc.delLeaderPlaceholder, res=" + res + ", inStr=" + inStr,
		// WB.strEmpty, "Etc");
		return res;
	}

//	public static String clonePlaceholder(int normLenght, String placeholder) throws Exception {
//		// origin - 18.08.2024, last edit - 04.10.2024
//		String res = WB.strEmpty;
//		// placeholder = Etc.fixTrim(placeholder);
//		try {
//			if (placeholder.isEmpty() == false) {
//				for (int i = 1; i <= normLenght; i++) {
//					res = res + placeholder;
//				}
//			}
//		} catch (Exception ex) {
//			WB.addLog("Etc.clonePlaceholder, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
//		} finally {
//			Etc.doNothing();
//		}
////		WB.addLog2("Etc.clonePlaceholder, res=" + res + ", normLenght=" + normLenght + ", placeholder=" + placeholder,
////				WB.strEmpty, "Etc");
//		return res;
//	}

	public static String addLeaderPlaceholder(String inStr, int normLenght, String placeholder) throws Exception {
		// origin - 16.08.2024, last edit - 04.10.2024
		String res = Etc.fixTrim(inStr);
		try {
			if (placeholder.isEmpty() == false) {
				// res = Etc.clonePlaceholder(normLenght, placeholder) + res;

				String tmp = WB.strEmpty;
				for (int i = 1; i <= normLenght; i++) {
					tmp = tmp + placeholder;
				}
				res = tmp + res;

				res = res.substring(res.length() - normLenght);
			}
		} catch (Exception ex) {
			WB.addLog("Etc.addLeaderPlaceholder, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Etc.addLeaderPlaceholder, res=" + res + ", inStr=" + inStr,
		// WB.strEmpty, "Etc");
		return res;
	}

//	public static String[] getArrayFromStrSplit(String strSplit, String splitSign) throws Exception {
//		// origin - 16.06.2024, last edit - 03.10.2024
//		String[] res = {};
//		try {
//			res = strSplit.split(splitSign);
//		} catch (Exception ex) {
//			WB.addLog("Etc.getArrayFromStrSplit, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("Etc.getArrayFromStrSplit, res.lenght=" + res.length,
//		// WB.strEmpty,
//		// "Etc");
//		return res;
//	}

	public static Boolean isLetterOrDigitAll(String testString) throws Exception {
		// origin - 24.06.2024, last edit - 11.07.2024
		Boolean res = false;
		try {
			testString = Etc.fixTrim(testString);
			int countLetterOrDigit = 0;
			// char[] charArray = testString.toCharArray();

			for (char currChar : testString.toCharArray()) {
				if (Character.isLetterOrDigit(currChar)) {
					countLetterOrDigit = countLetterOrDigit + 1;
				}
			}

			if (countLetterOrDigit != 0) {
				if (countLetterOrDigit == testString.length()) {
					res = true;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Etc.isLetterOrDigitAll, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Etc.isLetterOrDigitAll, res=" + res + ", testString=" +
		// testString,
		// WB.strEmpty, "Etc");
		return res;
	}

	public static Boolean isDigitAll(String testString) throws Exception {
		// origin - 20.06.2024, last edit - 17.10.2024
		Boolean res = false;
		try {
			testString = Etc.fixTrim(testString);
			// testString = testString.replaceAll(WB.strDot, WB.strEmpty);
			int countDigit = 0;
			// char[] charArray = testString.toCharArray();

			for (char currChar : testString.toCharArray()) {
				if (Character.isDigit(currChar)) {
					countDigit = countDigit + 1;
				}
			}

			if (countDigit != 0) {
				if (countDigit == testString.length()) {
					res = true;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Etc.isDigitAll, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Etc.isDigitAll, res=" + res + ", testString=" + testString,
		// WB.strEmpty, "etc");
		return res;
	}

	public static String getStrIntRnd(int lenghtStrIntRnd) throws Exception {// sectoral pawnshop
		// origin - 26.06.2024, last edit - 11.07.2024
		String res = WB.strEmpty;
		try {
			for (int i = 0; i < lenghtStrIntRnd; i++) {
				res = res + Etc.getIntRnd(9);
			}
		} catch (Exception ex) {
			WB.addLog("Etc.getStrIntRnd, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Etc.getStrIntRnd, res=" + res + ", lenghtStrIntRnd=" +
		// lenghtStrIntRnd, WB.strEmpty, "Etc");
		return res;
	}

	public static int getIntRnd(int initVal) throws Exception {
		// origin - 16.02.2024, last edit - 03.07.2024
		int res = 0;
		try {
			if (initVal == 0) {
				initVal = 100000;
			}
			Random random = new Random();
			res = random.nextInt(initVal);
		} catch (Exception ex) {
			WB.addLog("Etc.getIntRnd, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static String getFileName(String urlFrom) throws Exception {
		// origin - 25.12.2023, last edit - 03.07.2024
		String res = WB.strEmpty;
		try {
			File file = new File(urlFrom);
			res = fixTrim(file.getName());
		} catch (Exception ex) {
			WB.addLog("Etc.getFileName, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void doNothing() {
		// origin - 23.12.2023, last edit - 23.12.2023
	}

	public static String delStr(String viewName, List<String> listDelWord) throws Exception {
		// origin - 30.09.2024, last edit - 30.09.2024
		String res = WB.strEmpty;
		try {
			res = fixTrim(viewName); // delete all space
			for (var currDelWord : listDelWord) {
				res = res.replace(currDelWord, WB.strEmpty); // delete word if it exist
			}
			res = fixTrim(res); // delete all space
		} catch (Exception ex) {
			WB.addLog("Etc.delStr, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Etc.delStr, res=" + res + ", viewName=" + viewName, WB.strEmpty,
		// "Etc");
		return res;
	}

	public static String delStr(String viewName, String delWord) throws Exception {
		// origin - 30.10.2023, last edit - 03.07.2024
		String res = WB.strEmpty;
		try {
			res = fixTrim(viewName); // delete all space
			res = res.replace(delWord, WB.strEmpty); // delete word if it exist
			res = fixTrim(res); // delete all space
		} catch (Exception ex) {
			WB.addLog("Etc.delStr, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static double ratio100(double ratePercent) throws Exception {
		// origin - 17.10.2023, last edit - 03.07.2024
		double res = 0.0;
		try {
			res = ratePercent / 100.0;
			res = roundCustom(res, round4);
		} catch (Exception ex) {
			WB.addLog("Etc.ratio100, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static boolean strEquals(String str1, String str2) throws Exception {
		// origin - 18.10.2023, last edit - 09.11.2024
		boolean res = false;
		try {
			if (str1 != null) {
				if (str1.isEmpty() == false) {
					str1 = fixTrim(str1.toLowerCase());
					str2 = fixTrim(str2.toLowerCase());
					res = str1.equalsIgnoreCase(str2) == true ? true : res;
				}
			}

		} catch (Exception ex) {
			WB.addLog("Etc.strEquals, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static boolean strContains(String str1, String str2) throws Exception {
		// origin - 19.02.2024, last edit - 03.07.2024
		boolean res = false;
		try {
			str1 = fixTrim(str1.toLowerCase());
			str2 = fixTrim(str2.toLowerCase());
			res = str1.contains(str2) == true ? true : res;
		} catch (Exception ex) {
			WB.addLog("Etc.strContains, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static double roundTax(double sum, String codeTax) throws Exception {
		// origin - 16.01.2024, last edit - 24.08.2024
		double res = sum;
		try {
			if (Etc.strContains(codeTax, "VAT")) {
				res = roundCustom(sum, round2);// for VAT round with cents
			} else {
				res = roundCustom(sum, 0);
			}
		} catch (Exception ex) {
			WB.addLog("Etc.roundTax, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		res = DefVal.set(res);// set 0, if < 0
		return res;
	}

	public static double roundCustom(double sum) throws Exception {
		// origin - 17.10.2023, last edit - 03.07.2024
		// variant round less number fractional digit as argument, take him = 2
		double res = sum;
		try {
			res = roundCustom(sum, roundDefault); // default round
		} catch (Exception ex) {
			WB.addLog("Etc.roundCustom, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static double roundCustom(double sum, int numberFractionalDigit) throws Exception {
		// origin - 16.10.2023, last edit - 03.07.2024
		double res = sum;
		try {
			int power10 = (int) Math.pow(10, numberFractionalDigit);
			res = sum * power10;
			res = Math.round(res);
			res = res / power10;
		} catch (Exception ex) {
			WB.addLog("Etc.roundCustom, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static String fixString(Object fixObj) throws Exception {
		// origin - 12.11.2023, last edit - 03.07.2024
		String res = WB.strEmpty;
		try {
			res = fixObj.toString();
		} catch (Exception ex) {
			res = WB.strEmpty;
			// WB.addLog("Etc.fixString, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			res = fixTrim(res);
		}
		return res;
	}

	public static String fixTrim(String fixStr) throws Exception {
		// origin - 02.10.2023, last edit - 03.07.2024
		String res = WB.strEmpty;
		try {
			res = fixStr.strip();
		} catch (Exception ex) {
			res = WB.strEmpty;
			WB.addLog("Etc.fixTrim, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	private Etc() {
		// origin - 04.11.2024, last edit - 04.11.2024
	}

	public static void test() throws Exception {
		// origin - 01.10.2023, last edit - 17.10.2024
		try {

//			// delStr(str, ListDelWord)
//			List<String> listDelWord = List.of("(", ")");
//			var arg1 = new String[] { "(0015567453", "10(09090)965)", "(003)", "((00)Fkmaf))))" };
//			for (var testArg1 : arg1) {
//				WB.addLog2("Etc.test.delStr(inStr, listDelWord), res=" + Etc.delStr(testArg1, listDelWord)
//						+ ", testArg1=" + testArg1, WB.strEmpty, "Etc");
//			}

//			// strMatch
//			var arg1 = new String[] { "715567453", "1009090965", "03", "5100", "00Fkmaf" };
//			for (var testArg1 : arg1) {
//				WB.addLog2("Etc.test.strMatch, res=" + Etc.strMatch(testArg1, "0") + ", testArg1=" + testArg1
//						+ ", findStr=0", WB.strEmpty, "Etc");
//				WB.addLog2("Etc.test.strMatch, res=" + Etc.strMatch(testArg1, "00") + ", testArg1=" + testArg1
//						+ ", findStr=00", WB.strEmpty, "Etc");
//			}

//			// delLeaderPlaceholder
//			var arg1 = new String[] { "00006715567453", "1009090965", "003", "5000", "00Fkmaf", null };
//			for (var testArg1 : arg1) {
//				WB.addLog2("Etc.test.addLeaderZero, res=" + delLeaderPlaceholder(testArg1, "0") + ", testArg1=" + testArg1,
//						WB.strEmpty, "Etc");
//			}

//			// addLeaderZero
//			var arg1 = new String[] { "671125567453", "1", "3", "5", "Fkmaf", null };
//			for (var testArg1 : arg1) {
//				WB.addLog2("Etc.test.addLeaderZero, res=" + addLeaderZero(testArg1, 6) + ", testArg1=" + testArg1,
//						WB.strEmpty, "Etc");
//			}

//			// cleanLeaderZero
//			var arg1 = new String[] { "671125567453", "0001", "003", "05", "Fkmaf", null };
//			for (var testArg1 : arg1) {
//				WB.addLog2("Etc.test.cleanLeaderZero, res=" + cleanLeaderZero(testArg1) + ", testArg1=" + testArg1,
//						WB.strEmpty, "Etc");
//			}

//			// setDefault
//			var arg1 = new String[] { "671125567453", "", " ", null };
//			for (var testArg1 : arg1) {
//				WB.addLog2("Etc.test.setDefault, res=" + setDefault(testArg1, "defaultVal") + ", testArg1=" + testArg1,
//						WB.strEmpty, "Etc");
//			}

//		// isLetterOrDigitAll
//		var arg1 = new String[] { "671125567453", "87112567676776767676", "87664gfgf", "3611.25,567453",
//				"97%511)25567453", "021125567453", "231125567453", null };
//		for (var testArg1 : arg1) {
//			WB.addLog2("Etc.test.isLetterOrDigitAll, res=" + isLetterOrDigitAll(testArg1) + ", testArg1=" + testArg1,
//					WB.strEmpty, "Etc");
//		}

//		// isDigitAll
//		var arg11 = new String[] { "671125567453", "87112567676776767676", "87664gfgf", "361125567453", "971125567453",
//				"021125567453", "2311255674.53", null };
//		for (var testArg1 : arg11) {
//			WB.addLog2("Etc.test.isDigitAll, res=" + isDigitAll(testArg1) + ", testArg1=" + testArg1, WB.strEmpty,
//					"Etc");
//		}

//			// getFileName
//			var testUrl = new String[] { "https://lom-bard.kz/static/reports/2022/otchet_ff.pdf",
//					"C:\\testDir\\testFile.txt" };
//			for (var testArg1 : testUrl) {
//				WB.addLog2("Etc.test.getFileName, res=" + getFileName(testArg1) + ", testArg1=" + testArg1, WB.strEmpty,
//						"Etc");
//			}

//			// subtract
//			double testNum1 = 5000000.02;
//			double testNum2 = 5000000.01;
//			WB.addLog2("Etc.test, roundCustom(testNum1 - testNum2)=" + roundCustom(testNum1 - testNum2) + ", testNum1="
//					+ testNum1 + ", testNum2=" + testNum2, WB.strEmpty, "Etc");

//		// fixString
//		for (var testArg1 : new Object[] { "test1", 12.45, new Asset(), null }) {
//			WB.addLog2("Etc.test.fixString, res=" + fixString(testArg1) + ", testArg1=" + testArg1, WB.strEmpty, "Etc");
//		}

//		// strContains
//		String str0 = "test1";
//		for (String testArg1 : new String[] { "test1", "test1 ", " tEst1", "TEST1", "test22" }) {
//			WB.addLog2("Etc.test.strContains, res=" + strContains(testArg1, str0) + ", testArg1=" + testArg1 + ", str2="
//					+ str0, WB.strEmpty, "Etc");
//		}

//		// strEquals
//		String str2 = "test1";
//		for (String testArg1 : new String[] { "test1", "test1 ", " tEst1", "TEST1", "test22" }) {
//			WB.addLog2("Etc.test.strEquals, res=" + strEquals(testArg1, str2) + ", testArg1=" + testArg1 + ", str2="
//					+ str2, WB.strEmpty, "Etc");
//		}

//		// ratio100
//		for (double testArg1 : new double[] { 100.0, 67.43, 0.00, 23.56452, 12.0, 234.65432 }) {
//			WB.addLog2("Etc.test.ratio100, res=" + ratio100(testArg1) + ", testArg1=" + testArg1, WB.strEmpty, "Etc");
//		}

//		// roundTax
//		for (double testArg1 : new double[] { 100.0, 57.4363, 43.0078, 21.212, 34.7845 }) {
//			for (String testArg2 : new String[] { "Debt.VAT.Sell.RateBasic", "Debt.Pension.OPV.RateBasic" }) {
//				WB.addLog2("Etc.test.roundTax, res=" + roundTax(testArg1, testArg2) + ", testArg1=" + testArg1
//						+ ", testArg2=" + testArg2, WB.strEmpty, "Etc");
//			}
//		}

//		// roundCustom - round2
//		for (double testArg1 : new double[] { 100.0, 57.4363, 43.0078, 21.212, 34.7845 }) {
//			WB.addLog2("Etc.test.roundCustom, res=" + roundCustom(testArg1, round2) + ", testArg1=" + testArg1
//					+ ", numberFractionalDigit=" + round2, WB.strEmpty, "Etc");
//		}

//		// roundCustom - round0
//		for (double testArg1 : new double[] { 100.0, 57.4363, 43.0078, 21.212, 34.7845 }) {
//			WB.addLog2("Etc.test.roundCustom, res=" + roundCustom(testArg1, round0) + ", testArg1=" + testArg1
//					+ ", numberFractionalDigit=" + round0, WB.strEmpty, "Etc");
//		}

//		// fixTrim
//		for (String testArg1 : new String[] { "test1", "test2 ", " test3", " test4 " }) {
//			WB.addLog2("Etc.test.fixTrim, res=" + fixTrim(testArg1) + ", testArg1=" + testArg1, WB.strEmpty, "Etc");
//		}

//		// setDefault
//		for (double testArg1 : new double[] { 1.25, -41.2556, 0.0, 0.0002, -0.0002, 64.1278 }) {
//			WB.addLog2("Etc.test.setDefault, res=" + setDefault(testArg1) + ", testArg1=" + testArg1, WB.strEmpty, "Etc");
//		}

		} catch (Exception ex) {
			WB.addLog("Etc.test, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Etc.test end ", WB.strEmpty, "Etc");
	}
}
