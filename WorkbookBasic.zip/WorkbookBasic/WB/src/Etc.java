import java.io.File;
import java.util.List;
import java.util.Random;

public class Etc {
	// origin - 01.10.2023, last edit - 15.07.2024
	public static int round0;
	public static int round2;
	public static int roundDefault;
	public static int round4;
	public static int initRndDefault;

	static {
		try {
			round0 = 0;
			round2 = 2;
			roundDefault = round2;
			round4 = 4;
			initRndDefault = 0;
		} catch (Exception ex) {
			WB.addLog("Etc.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
	}

	public static String[] getArrayFromStrSplit(String strSplit, String splitSign) throws Exception {
		// origin - 16.06.2024, last edit - 15.07.2024
		String[] res = {};
		try {
			res = strSplit.split(splitSign);
		} catch (Exception ex) {
			WB.addLog("Etc.getArrayFromStrSplit, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Etc.getArrayFromStrSplit, res.lenght=" + res.length,
		// WB.strEmpty,
		// "Etc");
		return res;
	}

	public static String logList(List<String> initList) throws Exception {
		// origin - 02.07.2024, last edit - 02.07.2024
		String res = WB.strEmpty;
		try {
			for (var currList : initList) {
				res = res + currList.toString() + WB.strCommaSpace;
			}
		} catch (Exception ex) {
			WB.addLog("Etc.logList, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Etc.logList, res=" + res, WB.strEmpty, "Etc");
		return res;
	}

	public static String logArray(String[] initArray) throws Exception {
		// origin - 02.07.2024, last edit - 02.07.2024
		String res = WB.strEmpty;
		try {
			for (var currArr : initArray) {
				res = res + currArr.toString() + WB.strCommaSpace;
				// WB.addLog2("Etc.logArray, currArr=" + currArr, WB.strEmpty,
				// "Etc");
			}
		} catch (Exception ex) {
			WB.addLog("Etc.logArray, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Etc.logArray, res=" + res, WB.strEmpty, "Etc");
		return res;
	}

	public static Boolean isLetterOrDigitAll(String testString) throws Exception {
		// origin - 24.06.2024, last edit - 11.07.2024
		Boolean res = false;
		try {
			testString = Etc.fixTrim(testString);
			int countLetterOrDigit = 0;
			// char[] charArray = testString.toCharArray();

			for (char currChar : testString.toCharArray()) {
				if (Character.isLetterOrDigit(currChar)) {
					countLetterOrDigit = countLetterOrDigit + 1;
				}
			}

			if (countLetterOrDigit != 0) {
				if (countLetterOrDigit == testString.length()) {
					res = true;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Etc.isLetterOrDigitAll, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Etc.isLetterOrDigitAll, res=" + res + ", testString=" +
		// testString,
		// WB.strEmpty, "Etc");
		return res;
	}

	public static Boolean isDigitAll(String testString) throws Exception {
		// origin - 20.06.2024, last edit - 11.07.2024
		Boolean res = false;
		try {
			testString = Etc.fixTrim(testString);
			int countDigit = 0;
			// char[] charArray = testString.toCharArray();

			for (char currChar : testString.toCharArray()) {
				if (Character.isDigit(currChar)) {
					countDigit = countDigit + 1;
				}
			}

			if (countDigit != 0) {
				if (countDigit == testString.length()) {
					res = true;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Etc.isDigitAll, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Etc.isDigitAll, res=" + res + ", testString=" + testString,
		// WB.strEmpty, "etc");
		return res;
	}

	public static boolean isRequiredFill(String initVal) throws Exception {
		// origin - 19.06.2024, last edit - 15.07.2024
		boolean res = false;
		try {
			initVal = Etc.fixTrim(initVal);
			if (Etc.strContains(initVal, "?")) { // ??magic string ??
				if (initVal.indexOf("?") == initVal.length() - 1) {// sign "?" is last in string, ex. "IBAN=?",
																	// "Cell=?",
																	// etc.
					res = true;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Etc.isRequiredFill, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Etc.isRequiredFill, res=" + res + ", initVal=" + initVal,
		// WB.strEmpty, "Etc");
		return res;
	}

	public static String getStrIntRnd(int lenghtStrIntRnd) throws Exception {// sectoral pawnshop
		// origin - 26.06.2024, last edit - 11.07.2024
		String res = WB.strEmpty;
		try {
			for (int i = 0; i < lenghtStrIntRnd; i++) {
				res = res + Etc.getIntRnd(9);
			}
		} catch (Exception ex) {
			WB.addLog("Etc.getStrIntRnd, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Etc.getStrIntRnd, res=" + res + ", lenghtStrIntRnd=" +
		// lenghtStrIntRnd, WB.strEmpty, "Etc");
		return res;
	}

	public static int getIntRnd(int initVal) throws Exception {
		// origin - 16.02.2024, last edit - 03.07.2024
		int res = 0;
		try {
			if (initVal == 0) {
				initVal = 100000;
			}
			Random random = new Random();
			res = random.nextInt(initVal);
		} catch (Exception ex) {
			WB.addLog("Etc.getIntRnd, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static String getSourceUrl(String source, String file) throws Exception {
		// origin - 25.12.2023, last edit - 03.07.2024
		String res = WB.strEmpty;
		try {
			res = fixTrim(source) + fixTrim(file);
		} catch (Exception ex) {
			WB.addLog("Etc.getSourceUrl, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static String getFileName(String urlFrom) throws Exception {
		// origin - 25.12.2023, last edit - 03.07.2024
		String res = WB.strEmpty;
		try {
			File file = new File(urlFrom);
			res = fixTrim(file.getName());
		} catch (Exception ex) {
			WB.addLog("Etc.getFileName, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void doNothing() {
		// origin - 23.12.2023, last edit - 23.12.2023
	}

	public static String delStr(String viewName, String delWord) throws Exception {
		// origin - 30.10.2023, last edit - 03.07.2024
		String res = WB.strEmpty;
		try {
			res = fixTrim(viewName); // delete all space
			res = res.replace(delWord, WB.strEmpty); // delete word if it exist
			res = fixTrim(res); // delete all space
		} catch (Exception ex) {
			WB.addLog("Etc.delStr, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static double ratio100(double ratePercent) throws Exception {
		// origin - 17.10.2023, last edit - 03.07.2024
		double res = 0.0;
		try {
			res = ratePercent / 100.0;
			res = roundCustom(res, round4);
		} catch (Exception ex) {
			WB.addLog("Etc.ratio100, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static boolean strEquals(String str1, String str2) throws Exception {
		// origin - 18.10.2023, last edit - 03.07.2024
		boolean res = false;
		try {
			str1 = fixTrim(str1.toLowerCase());
			str2 = fixTrim(str2.toLowerCase());
			res = str1.equalsIgnoreCase(str2) == true ? true : res;
		} catch (Exception ex) {
			WB.addLog("Etc.strEquals, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static boolean strContains(String str1, String str2) throws Exception {
		// origin - 19.02.2024, last edit - 03.07.2024
		boolean res = false;
		try {
			str1 = fixTrim(str1.toLowerCase());
			str2 = fixTrim(str2.toLowerCase());
			res = str1.contains(str2) == true ? true : res;
		} catch (Exception ex) {
			WB.addLog("Etc.strContains, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static double roundTax(double sum, String codeTax) throws Exception {
		// origin - 16.01.2024, last edit - 03.07.2024
		double res = sum;
		try {
			if (Etc.strContains(codeTax, "VAT")) {
				res = roundCustom(sum, round2);// for VAT round with cents
			} else {
				res = roundCustom(sum, 0);
			}
		} catch (Exception ex) {
			WB.addLog("Etc.roundTax, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		res = Etc.setZeroOnNeg(res);
		return res;
	}

	public static double roundCustom(double sum) throws Exception {
		// origin - 17.10.2023, last edit - 03.07.2024
		// variant round less number fractional digit as argument, take him = 2
		double res = sum;
		try {
			res = roundCustom(sum, roundDefault); // default round
		} catch (Exception ex) {
			WB.addLog("Etc.roundCustom, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static double roundCustom(double sum, int numberFractionalDigit) throws Exception {
		// origin - 16.10.2023, last edit - 03.07.2024
		double res = sum;
		try {
			int power10 = (int) Math.pow(10, numberFractionalDigit);
			res = sum * power10;
			res = Math.round(res);
			res = res / power10;
		} catch (Exception ex) {
			WB.addLog("Etc.roundCustom, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static String fixString(Object fixObj) throws Exception {
		// origin - 12.11.2023, last edit - 03.07.2024
		String res = WB.strEmpty;
		try {
			res = fixObj.toString();
		} catch (Exception ex) {
			res = WB.strEmpty;
			// WB.addLog("Etc.fixString, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			res = fixTrim(res);
		}
		return res;
	}

	public static String fixTrim(String fixStr) throws Exception {
		// origin - 02.10.2023, last edit - 03.07.2024
		String res = WB.strEmpty;
		try {
			res = fixStr.strip();
		} catch (Exception ex) {
			res = WB.strEmpty;
			WB.addLog("Etc.fixTrim, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static double setZeroOnNeg(Number fixNumb) throws Exception {
		// origin - 01.10.2023, last edit - 03.07.2024
		// for tax calculate and etc where not need be negative number
		double res = (double) fixNumb;
		try {
			res = res < 0 ? 0 : res;
		} catch (Exception ex) {
			WB.addLog("Etc.setZeroOnNeg, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		return (double) res;
	}

	public static void test() throws Exception {
		// origin - 01.10.2023, last edit - 15.07.2024
		try {

//			// getArrayFromStrSplit
//			var arg2 = new String[] { "InfoBaseId=P1;", "InfoBaseId=P1;LastEdit=2024-06-25T07:52:43;", "87664gfgf",
//					"231125567453" };
//			for (var testArg1 : arg2) {
//				WB.addLog2(
//						"Etc.test.getArrayFromStrSplit, res="
//								+ Etc.logArray(getArrayFromStrSplit(testArg1, WB.strSemiColon)) + ", testArg1=" + testArg1,
//						WB.strEmpty, "ModelDto");
//			}

//		// isLetterOrDigitAll
//		var arg1 = new String[] { "671125567453", "87112567676776767676", "87664gfgf", "3611.25,567453",
//				"97%511)25567453", "021125567453", "231125567453", null };
//		for (var testArg1 : arg1) {
//			WB.addLog2("Etc.test.isLetterOrDigitAll, res=" + isLetterOrDigitAll(testArg1) + ", testArg1=" + testArg1,
//					WB.strEmpty, "Etc");
//		}

//		// isDigitAll
//		var arg11 = new String[] { "671125567453", "87112567676776767676", "87664gfgf", "361125567453", "971125567453",
//				"021125567453", "231125567453", null };
//		for (var testArg1 : arg11) {
//			WB.addLog2("Etc.test.isDigitAll, res=" + isDigitAll(testArg1) + ", testArg1=" + testArg1, WB.strEmpty,
//					"Etc");
//		}

//		// isRequiredFill
//		for (String testArg1 : new String[] { "KZ?", "IBAN=?", "Description=;", "?Surname=;" }) {
//			WB.addLog2("Etc.test.isRequiredFill, res=" + isRequiredFill(testArg1) + ", testArg1=" + testArg1,
//					WB.strEmpty, "Etc");
//		}

			// getFileName
			var testUrl = new String[] { "https://lom-bard.kz/static/reports/2022/otchet_ff.pdf",
					"C:\\testDir\\testFile.txt" };
			for (var testArg1 : testUrl) {
				WB.addLog2("Etc.test.getFileName, res=" + getFileName(testArg1) + ", testArg1=" + testArg1, WB.strEmpty,
						"Etc");
			}

			// subtract
			double testNum1 = 5000000.02;
			double testNum2 = 5000000.01;
			WB.addLog2("Etc.test, roundCustom(testNum1 - testNum2)=" + roundCustom(testNum1 - testNum2) + ", testNum1="
					+ testNum1 + ", testNum2=" + testNum2, WB.strEmpty, "Etc");

//		// fixString
//		for (var testArg1 : new Object[] { "test1", 12.45, new Asset(), null }) {
//			WB.addLog2("Etc.test.fixString, res=" + fixString(testArg1) + ", testArg1=" + testArg1, WB.strEmpty, "Etc");
//		}

//		// strContains
//		String str0 = "test1";
//		for (String testArg1 : new String[] { "test1", "test1 ", " tEst1", "TEST1", "test22" }) {
//			WB.addLog2("Etc.test.strContains, res=" + strContains(testArg1, str0) + ", testArg1=" + testArg1 + ", str2="
//					+ str0, WB.strEmpty, "Etc");
//		}

//		// strEquals
//		String str2 = "test1";
//		for (String testArg1 : new String[] { "test1", "test1 ", " tEst1", "TEST1", "test22" }) {
//			WB.addLog2("Etc.test.strEquals, res=" + strEquals(testArg1, str2) + ", testArg1=" + testArg1 + ", str2="
//					+ str2, WB.strEmpty, "Etc");
//		}

//		// ratio100
//		for (double testArg1 : new double[] { 100.0, 67.43, 0.00, 23.56452, 12.0, 234.65432 }) {
//			WB.addLog2("Etc.test.ratio100, res=" + ratio100(testArg1) + ", testArg1=" + testArg1, WB.strEmpty, "Etc");
//		}

//		// roundTax
//		for (double testArg1 : new double[] { 100.0, 57.4363, 43.0078, 21.212, 34.7845 }) {
//			for (String testArg2 : new String[] { "Debt.VAT.Sell.RateBasic", "Debt.Pension.OPV.RateBasic" }) {
//				WB.addLog2("Etc.test.roundTax, res=" + roundTax(testArg1, testArg2) + ", testArg1=" + testArg1
//						+ ", testArg2=" + testArg2, WB.strEmpty, "Etc");
//			}
//		}

//		// roundCustom - round2
//		for (double testArg1 : new double[] { 100.0, 57.4363, 43.0078, 21.212, 34.7845 }) {
//			WB.addLog2("Etc.test.roundCustom, res=" + roundCustom(testArg1, round2) + ", testArg1=" + testArg1
//					+ ", numberFractionalDigit=" + round2, WB.strEmpty, "Etc");
//		}

//		// roundCustom - round0
//		for (double testArg1 : new double[] { 100.0, 57.4363, 43.0078, 21.212, 34.7845 }) {
//			WB.addLog2("Etc.test.roundCustom, res=" + roundCustom(testArg1, round0) + ", testArg1=" + testArg1
//					+ ", numberFractionalDigit=" + round0, WB.strEmpty, "Etc");
//		}

//		// fixTrim
//		for (String testArg1 : new String[] { "test1", "test2 ", " test3", " test4 " }) {
//			WB.addLog2("Etc.test.fixTrim, res=" + fixTrim(testArg1) + ", testArg1=" + testArg1, WB.strEmpty, "Etc");
//		}

//		// setZeroOnNeg
//		for (double testArg1 : new double[] { 1.25, -41.2556, 0.0, 0.0002, -0.0002, 64.1278 }) {
//			WB.addLog2("Etc.test.setZeroOnNeg, res=" + setZeroOnNeg(testArg1) + ", testArg1=" + testArg1, WB.strEmpty, "Etc");
//		}
		} catch (Exception ex) {
			WB.addLog("Etc.test, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Etc.test end ", WB.strEmpty, "Etc");
	}
}
