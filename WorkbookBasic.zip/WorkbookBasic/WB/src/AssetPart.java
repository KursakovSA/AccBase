import java.util.ArrayList;
import java.util.List;

public class AssetPart {
	// origin - 25.02.2025, last edit - 14.03.2025
	public boolean isValid, isExist;
	public String table, src, id, parent, geo, role, info, unit, mark;
	public ListVal date1, date2, code, description, more;
	public List<AssetDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("AssetPart.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "AssetPart");
		}
	}

	private void getVal() throws Exception {
		// origin - 28.02.2025, last edit - 14.03.2025
		try {
			String currDate1 = WB.strEmpty;
			String currDate2 = WB.strEmpty;
			String currCode = WB.strEmpty;
			String currDescription = WB.strEmpty;
			String currMore = WB.strEmpty;
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currCode = this.code.getByIndex(i);
				currDescription = this.description.getByIndex(i);
				currMore = this.more.getByIndex(i);
				var tmp = new AssetDto(this.id, this.parent, currDate1, currDate2, currCode, currDescription, this.geo,
						this.role, this.info, this.unit, currMore, this.mark);
				this.val.add(tmp);
				// WB.addLog2("AssetPart.getVal, add tmp=" + tmp, WB.strEmpty,"AssetPart");
			}
		} catch (Exception ex) {
			WB.addLog("AssetPart.getVal, ex=" + ex.getMessage(), WB.strEmpty, "AssetPart");
		}
	}

	public void isExist() throws Exception {
		// origin - 25.02.2025, last edit - 14.03.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getParentFilter(this.parent), this.table);
			if (listDto.size() != WB.intZero) {
				for (var currDto : listDto) {
					if ((Etc.strEquals(currDto.info, Info.assetPart))) {
						this.date1 = new ListVal(currDto.date1, WB.strEmpty);
						this.date2 = new ListVal(currDto.date2, WB.strEmpty);

						this.id = DefVal.setCustom(this.id, currDto.id);

						this.code = new ListVal(currDto.code, WB.strEmpty);
						this.description = new ListVal(currDto.description, WB.strEmpty);

						this.geo = DefVal.setCustom(this.geo, currDto.geo);
						this.role = DefVal.setCustom(this.role, currDto.role);
						this.info = DefVal.setCustom(this.info, currDto.info);
						this.unit = DefVal.setCustom(this.unit, currDto.unit);
						this.more = new ListVal(currDto.more, WB.strEmpty);
						this.mark = DefVal.setCustom(this.mark, currDto.mark);
						this.isExist = true;
						break;
					}
				}
			}

		} catch (Exception ex) {
			WB.addLog("AssetPart.isExist, ex=" + ex.getMessage(), WB.strEmpty, "AssetPart");
		}
	}

	public AssetPart(String ParentId) throws Exception {
		// origin - 25.02.2025, last edit - 28.02.2025
		this();
		this.table = "Asset"; // ??magic string??
		this.src = this.parent = ParentId;
		this.isExist();
		this.getVal();
	}

	public void clear() throws Exception {
		// origin - 25.02.2025, last edit - 14.03.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = this.src = this.id = this.parent = this.geo = this.role = this.info = this.unit = this.mark = WB.strEmpty;
			this.date1 = this.date2 = this.code = this.description = this.more = new ListVal();
			this.val = new ArrayList<AssetDto>();
		} catch (Exception ex) {
			WB.addLog("AssetPart.clear, ex=" + ex.getMessage(), WB.strEmpty, "AssetPart");
		}
	}

	public AssetPart() throws Exception {
		// origin - 25.02.2025, last edit - 25.02.2025
		this.clear();
	}

	public String toString() {
		// origin - 25.02.2025, last edit - 07.03.2025
		String res = WB.strEmpty;
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);

			res = res + Fmtr.addIfNotEmpty(", code ", this.code.id);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description.id);

			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", ", this.unit);

			res = res + Fmtr.addIfNotEmpty(", more ", this.more.id);

			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 25.02.2025, last edit - 14.03.2025
		try {
//				// ctor()
//				WB.addLog2("AssetPart.test.ctor()=" + new AssetPart(), WB.strEmpty, "AssetPart");

//			// ctor (String)
//			for (var tmp1 : new String[] { "Asset.Test.1" }) {
//				WB.addLog2("AssetPart.test.ctor(String)=" + new AssetPart(tmp1), WB.strEmpty, "AssetPart");
//			}

		} catch (Exception ex) {
			WB.addLog("AssetPart.test, ex=" + ex.getMessage(), WB.strEmpty, "AssetPart");
		}
	}
}