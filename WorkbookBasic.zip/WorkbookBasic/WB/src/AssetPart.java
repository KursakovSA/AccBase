import java.util.ArrayList;
import java.util.List;

public class AssetPart {
	// origin - 25.02.2025, last edit - 30.03.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, geo, role, info, unit, mark;
	// special fields - no
	// special timestamp fields
	public ListVal date1, date2, code, description, more;
	//list common + specilal + timestamp fields in unified val
	public List<AssetDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("AssetPart.static ctor, ex=" + ex.getMessage(), "", "AssetPart");
		}
	}

	private void getVal() throws Exception {
		// origin - 28.02.2025, last edit - 19.03.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currCode = "";
			String currDescription = "";
			String currMore = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currCode = this.code.getByIndex(i);
				currDescription = this.description.getByIndex(i);
				currMore = this.more.getByIndex(i);
				var tmp = new AssetDto(this.id, this.parent, currDate1, currDate2, currCode, currDescription, this.geo,
						this.role, this.info, this.unit, currMore, this.mark);
				this.val.add(tmp);
				// WB.addLog2("AssetPart.getVal, add tmp=" + tmp, "","AssetPart");
			}
		} catch (Exception ex) {
			WB.addLog("AssetPart.getVal, ex=" + ex.getMessage(), "", "AssetPart");
		}
	}

	public void isExist() throws Exception {
		// origin - 25.02.2025, last edit - 19.03.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getParentFilter(this.parent), this.table);
			if (listDto.size() != 0) {
				for (var currDto : listDto) {
					if ((Etc.strEquals(currDto.info, Info.assetPart))) {
						this.date1 = new ListVal(currDto.date1, "");
						this.date2 = new ListVal(currDto.date2, "");

						this.id = DefVal.setCustom(this.id, currDto.id);

						this.code = new ListVal(currDto.code, "");
						this.description = new ListVal(currDto.description, "");

						this.geo = DefVal.setCustom(this.geo, currDto.geo);
						this.role = DefVal.setCustom(this.role, currDto.role);
						this.info = DefVal.setCustom(this.info, currDto.info);
						this.unit = DefVal.setCustom(this.unit, currDto.unit);
						this.more = new ListVal(currDto.more, "");
						this.mark = DefVal.setCustom(this.mark, currDto.mark);
						this.isExist = true;
						break;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("AssetPart.isExist, ex=" + ex.getMessage(), "", "AssetPart");
		}
	}

	public AssetPart(String ParentId) throws Exception {
		// origin - 25.02.2025, last edit - 28.02.2025
		this();
		this.table = "Asset"; // ??magic string??
		this.src = this.parent = ParentId;
		this.isExist();
		this.getVal();
	}

	public void clear() throws Exception {
		// origin - 25.02.2025, last edit - 20.03.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = this.src = this.id = this.parent = this.geo = this.role = this.info = this.unit = this.mark = "";
			this.date1 = this.date2 = this.code = this.description = this.more = new ListVal();
			this.val = new ArrayList<AssetDto>();
		} catch (Exception ex) {
			WB.addLog("AssetPart.clear, ex=" + ex.getMessage(), "", "AssetPart");
		}
	}

	public AssetPart() throws Exception {
		// origin - 25.02.2025, last edit - 25.02.2025
		this.clear();
	}

	public String toString() {
		// origin - 25.02.2025, last edit - 20.03.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);

			res = res + Fmtr.addIfNotEmpty(", code ", this.code.id);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description.id);

			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", ", this.unit);

			res = res + Fmtr.addIfNotEmpty(", more ", this.more.id);

			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 25.02.2025, last edit - 19.03.2025
		try {
//				// ctor()
//				WB.addLog2("AssetPart.test.ctor()=" + new AssetPart(), "", "AssetPart");

//			// ctor (String)
//			for (var tmp1 : new String[] { "Asset.Test.1" }) {
//				WB.addLog2("AssetPart.test.ctor(String)=" + new AssetPart(tmp1), "", "AssetPart");
//			}

		} catch (Exception ex) {
			WB.addLog("AssetPart.test, ex=" + ex.getMessage(), "", "AssetPart");
		}
	}
}