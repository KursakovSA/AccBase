import java.util.ArrayList;
import java.util.List;

public class SpanVal {
	// origin - 17.03.2025, last edit - 23.03.2025
	private String src1, src2;
	private List<String> val1, val2;
	public List<String> date1, date2;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("SpanVal.static ctor, ex=" + ex.getMessage(), "", "SpanVal");
		}
	}

	private void correctLogic() throws Exception {// TODO
		// origin - 23.03.2025, last edit - 23.03.2025
		try {
			for (int i = 0; i < this.date1.size(); i++) {
				// check if date1 > date2

			}
		} catch (Exception ex) {
			WB.addLog("SpanVal.correctLogic, ex=" + ex.getMessage(), "", "SpanVal");
		}
	}

	private void correctData(int sizeVal1, int sizeVal2) throws Exception {
		// origin - 21.03.2025, last edit - 23.03.2025
		try {
			if ((sizeVal1 == 0) && (sizeVal2 == 0)) {// both date1 and date2 empty
				this.date1.add(DateTool.formatter5(WB.minDateSupported));
				this.date2.add(DateTool.formatter5(WB.maxDateSupported));
				return;
			}

			if ((sizeVal1 == 0) && (sizeVal2 == 1)) {// date1 empty, date2.size=1
				this.date2 = this.val2;
				this.date1.add(DateTool.formatter5(WB.minDateSupported));
				return;
			}

			if ((sizeVal1 == 0) && (sizeVal2 > 1)) {// date1 empty, date2.size>1
				this.date2 = this.val2;
				for (int i = 1; i <= sizeVal2; i++) {// aline date1,2
					this.date1.add(this.date2.get(i - 1));
				}
				return;
			}

			if ((sizeVal1 == 1) && (sizeVal2 == 0)) {// date1.size=1, date2 empty
				this.date1 = this.val1;
				this.date2.add(DateTool.formatter5(WB.maxDateSupported));
				return;
			}

			if ((sizeVal1 > 1) && (sizeVal2 == 0)) {// date1.size>1, date2 empty
				this.date1 = this.val1;
				for (int i = 1; i <= sizeVal1; i++) {// aline date1,2
					this.date2.add(this.date1.get(i - 1));
				}
				return;
			}

			if ((sizeVal1 >= 1) && (sizeVal2 >= 1) && (sizeVal1 != sizeVal2)) {// date1 and date2 sizes not equals
				this.date1 = this.val1;
				this.date2 = this.val2;
				if (sizeVal1 > sizeVal2) {
					for (int i = this.date2.size() + 1; i <= this.date1.size(); i++) {// aline date1,2
						this.date2.add(this.date1.get(i - 1));
					}
				}
				if (sizeVal1 < sizeVal2) {
					for (int i = this.date1.size() + 1; i <= this.date2.size(); i++) {// aline date1,2
						this.date1.add(this.date2.get(i - 1));
					}
				}
				return;
			}
		} catch (Exception ex) {
			WB.addLog("SpanVal.correctData, ex=" + ex.getMessage(), "", "SpanVal");
		}
	}

	private void getDate() throws Exception {
		// origin - 17.03.2025, last edit - 22.03.2025
		try {
			if ((this.val1.size() != 0) && (this.val1.size() == this.val2.size())) {
				this.date1 = this.val1;
				this.date2 = this.val2;
			} else {
				this.correctData(this.val1.size(), this.val2.size());
			}
		} catch (Exception ex) {
			WB.addLog("SpanVal.getDate, ex=" + ex.getMessage(), "", "SpanVal");
		}
	}

	private void clear() throws Exception {
		// origin - 17.03.2025, last edit - 23.03.2025
		try {
			this.src1 = this.src2 = "";
			this.val1 = new ArrayList<String>();
			this.val2 = new ArrayList<String>();
			this.date1 = new ArrayList<String>();
			this.date2 = new ArrayList<String>();
		} catch (Exception ex) {
			WB.addLog("SpanVal.clear, ex=" + ex.getMessage(), "", "SpanVal");
		}
	}

	public SpanVal(String Src1, String Src2) throws Exception {
		// origin - 17.03.2025, last edit - 23.03.2025
		this();
		this.src1 = Src1;
		this.src2 = Src2;
		this.val1 = Fmtr.listVal(this.src1, ":");
		this.val2 = Fmtr.listVal(this.src2, ":");
		this.getDate();
		this.correctLogic();
	}

	public SpanVal() throws Exception {
		// origin - 17.03.2025, last edit - 17.03.2025
		this.clear();
	}

	public String toString() {
		// origin - 17.03.2025, last edit - 23.03.2025
		String res = "";
		try {
			res = "src1 " + this.src1 + ", src2 " + this.src2 + ", date1 " + this.date1 + ", date2 " + this.date2;
//			res = "src1 " + this.src1 + ", val1 " + this.val1.size() + ", src2 " + this.src2 + ", val2 "
//					+ this.val2.size() + ", date1 " + this.date1 + ", date2 " + this.date2;
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 17.03.2025, last edit - 24.03.2025
		try {

//			// ctor (String, String)
//			for (var tmp1 : new String[] { "", "2025-02-01:", "2025-01-23: 2025-02-14:", "2025-04-18: 2025-06-30:" }) {
//				for (var tmp2 : new String[] { "", "2025-07-03:", "2025-05-18: 2025-08-24:",
//						"2025-04-04: 2025-06-16:2025-05-21:" }) {
//					WB.addLog2("SpanVal.test.ctor(String,String)=" + new SpanVal(tmp1, tmp2), "", "SpanVal");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("SpanVal.test, ex=" + ex.getMessage(), "", "SpanVal");
		}
	}
}