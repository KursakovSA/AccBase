import java.io.File;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.TreeSet;

public class Conn {
	// origin - 17.11.2023, last edit - 27.06.2024
	public static String dbDir;

	public static String globalDbPattern;
	private static String global;
	public static String globalPath;

	public static String localDbPattern;
	public static String localPath;

	public static String templateDbPattern;
	public static String template;
	public static String templatePath;

	public static String largeDbPattern;
	private static String testDbPattern;
	private static String exampleDbPattern;

	public static String inputDbPattern;
	public static String outputDbPattern;
	public static String toAllPattern;

	private static String workAutoCreate;
	private static String workAutoCreatePath;

	public static TreeSet<String> systemFact = new TreeSet<String>();
	public static TreeSet<String> systemNorm;

	public static TreeSet<String> work = new TreeSet<String>();
	public static TreeSet<String> workOutside = new TreeSet<String>(); // TOTHINK

	public static TreeSet<String> largeDb = new TreeSet<String>();
	public static TreeSet<String> testDb = new TreeSet<String>();
	public static TreeSet<String> exampleDb = new TreeSet<String>();
	private static List<String> tableNorm;
	public static String prefixJdbcSqlite;
	public static String patternExtensionSqlite;

	static {
		try {
			dbDir = System.getProperty("user.dir");
			// global = getFile("DatabaseGlobal.sqlite");
			globalDbPattern = "DatabaseGlobal";
			global = getFile(globalDbPattern);// getFile("DatabaseGlobal");
			globalPath = getPath(global);
			// WB.addLog2("Conn.static ctor, globalPath=" + globalPath+ ", global=" +
			// global, WB.strEmpty, "Abc");
			templateDbPattern = "DatabaseTemplate";
			template = getFile(templateDbPattern);// getFile("DatabaseTemplate.sqlite");
			templatePath = getPath(template);
			// WB.addLog2("Conn.static ctor, templatePath=" + templatePath + ", template=" +
			// template, WB.strEmpty, "Abc");

			testDbPattern = "test";
			exampleDbPattern = "example";
			localDbPattern = "DatabaseLocal";
			largeDbPattern = "large";

			inputDbPattern = "input";
			outputDbPattern = "output";
			toAllPattern = "_to_all_";

			workAutoCreate = "MyWorkBase1.sqlite3";
			workAutoCreatePath = getPath(workAutoCreate);

			systemNorm = new TreeSet<String>(Arrays.asList(globalPath, templatePath));
			tableNorm = new ArrayList<String>(Arrays.asList("Account", "Asset", "Deal", "Debt", "Face", "Geo", "Info",
					"Item", "Mark", "Meter", "Price", "Process", "Role", "Sign", "Slice", "Unit", "Workbook"));

			prefixJdbcSqlite = "jdbc:sqlite:";
			patternExtensionSqlite = ".sqlite";
		} catch (Exception ex) {
			WB.addLog("Conn.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Conn");
		} finally {
			Etc.doNothing();
		}
	}

	public static TreeSet<String> getSetOrDefault(TreeSet<String> setConn) throws Exception {
		// origin - 12.02.2024, last edit - 03.07.2024
		TreeSet<String> res = new TreeSet<String>();
		try {
			if (setConn.size() == 0) {
				res = Conn.work;
			} else {
				res = setConn;
			}
		} catch (Exception ex) {
			WB.addLog("Conn.getSetOrDefault, ex=" + ex.getMessage(), WB.strEmpty, "Conn");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Conn.getSetConnOrDefault, res=" + res, WB.strEmpty, "Conn");
		return res;
	}

	public static String getFile(String subStrFileName) throws Exception {
		// origin - 30.11.2023, last edit - 03.07.2024
		subStrFileName = Etc.fixTrim(subStrFileName);
		String res = subStrFileName;
		try {
			String currFileName = WB.strEmpty;
			if (Files.notExists(Paths.get(dbDir))) {
				return res;
			}
			File file = Paths.get(dbDir).toFile();
			for (File currFile : file.listFiles()) {
				if (currFile.isFile() == false) {
					continue;
				}
				currFileName = currFile.getName().toString();
				if (Etc.strContains(currFileName, subStrFileName)) {
					res = currFileName;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Conn.getFile, ex=" + ex.getMessage(), WB.strEmpty, "Conn");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Conn.getFile, res=" + res + ", subStrFileName=" + subStrFileName,
		// WB.strEmpty, "Conn");
		return res;
	}

	private static String getPath(String file) throws Exception {
		// origin - 30.11.2023, last edit - 03.07.2024
		String res = WB.strEmpty;
		try {
			res = dbDir + File.separator + file;
		} catch (Exception ex) {
			WB.addLog2("Conn.getPath, ex=" + ex.getMessage(), WB.strEmpty, "Conn");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void init() throws Exception {
		// origin - 25.11.2023, last edit - 03.07.2024
		try {
			if (systemFact.isEmpty()) {
				getDbList(dbDir);
				cloneDbTemplate(dbDir);
			}
			getLast();
			readDatabaseLocal();
			// getLocal(WB.localDir);
			getWorkOutside();// TOTHINK
		} catch (Exception ex) {
			WB.addLog2("Conn.init, ex=" + ex.getMessage(), WB.strEmpty, "Conn");
		} finally {
			Etc.doNothing();
		}
	}

	public static void getWorkOutside() throws Exception {
		// origin - 10.01.2024, last edit - 03.07.2024
		try {
			setWorkOutside();
		} catch (Exception ex) {
			WB.addLog2("Conn.getWorkOutside, ex=" + ex.getMessage(), WB.strEmpty, "Conn");
		} finally {
			Etc.doNothing();
		}
	}

	private static boolean testLocal(String dirPath, File currFile) throws Exception {
		// origin - 15.06.2024, last edit - 03.07.2024
		boolean res = false;
		try {
			String testLocalPath = dirPath + File.separator + currFile.getName();
			Abc testAbcLocal = new Abc();
			testAbcLocal = new Abc(testLocalPath);

			if (testAbcLocal.basic.isEmpty() == false) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog2("Conn.testLocal, ex=" + ex.getMessage(), WB.strEmpty, "Conn");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Conn.testLocal, res=" + res + ", testCurrFile=" + currFile,
		// WB.strEmpty,
		// "Conn");
		return res;
	}

	public static void readDatabaseLocal() throws Exception {
		// origin - 19.06.2024, last edit - 03.07.2024
		try {
			getLocal(WB.localDir);
		} catch (Exception ex) {
			WB.addLog2("Conn.readDatabaseLocal, ex=" + ex.getMessage(), WB.strEmpty, "Conn");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Conn.readDatabaseLocal, res=" + res + ", testCurrFile=" +
		// currFile, WB.strEmpty, "Conn");
	}

	private static void getLocal(String dirPath) throws Exception {
		// origin - 06.01.2024, last edit - 27.06.2024
		try {
			if (Files.notExists(Paths.get(dirPath))) {
				WB.addLog("Conn.setLocal, Files.notExists in=" + Paths.get(dirPath), WB.strEmpty, "Conn");
				return;
			}

			Long maxLastModified = 2L;
			Long currLastModified;

			File file = Paths.get(dirPath).toFile();
			for (File currFile : file.listFiles()) {
				if (Etc.strContains(currFile.getName(), localDbPattern) == false) {
					continue;
				}

				if (testLocal(dirPath, currFile) == false) {
					continue;
				}

				currLastModified = currFile.lastModified();
				if (currLastModified > maxLastModified) {
					maxLastModified = currLastModified;
					setLocal(dirPath, currFile);
				}
			}
		} catch (Exception ex) {
			WB.addLog2("Conn.getLocal, ex=" + ex.getMessage(), WB.strEmpty, "Conn");
		} finally {
			Etc.doNothing();
		}
		WB.addLog("Conn.getLocal, finally localPath=" + localPath + ", finally WB.abcLocal=" + WB.abcLocal, WB.strEmpty,
				"Conn");
	}

	private static void setWorkOutside() throws Exception {// TOTHINK
		// origin - 10.01.2024, last edit - 03.07.2024
		try {
			// localPath = dirPath + File.separator + currFile.getName();
			// WB.abcLocal = new Abc(localPath);
			// WB.addLog2("Conn.setWorkOutside, abcLocal=" + WB.abcLocal + ", localPath=" +
			// localPath, WB.strEmpty, "Conn");
		} catch (Exception ex) {
			WB.addLog2("Conn.setWorkOutside, ex=" + ex.getMessage(), WB.strEmpty, "Conn");
		} finally {
			Etc.doNothing();
		}
	}

	private static void setLocal(String dirPath, File currFile) throws Exception {
		// origin - 06.01.2024, last edit - 03.07.2024
		try {
			localPath = dirPath + File.separator + currFile.getName();
			WB.abcLocal = new Abc(localPath);
			// WB.addLog2("Conn.setLocal, WB.abcLocal=" + WB.abcLocal + ", localPath=" +
			// localPath, WB.strEmpty, "Conn");
		} catch (Exception ex) {
			WB.addLog2("Conn.setLocal, ex=" + ex.getMessage(), WB.strEmpty, "Conn");
		} finally {
			Etc.doNothing();
		}
	}

	private static void getLast() throws Exception {
		// origin - 25.11.2023, last edit - 03.07.2024
		try {
			LocalDateTime localStart = WB.getLocalStart();
			if (work.isEmpty() == false) {// TODO after do find last conn in interface inputDbConnection
				WB.lastConn = work.first();
				// WB.addLog2("Conn.getLast, WB.lastConn=" + WB.lastConn, WB.strEmpty, "Conn");
				WB.abcLast = new Abc(WB.lastConn);
				// WB.addLog2("Conn.getLast, WB.abcLast=" + WB.abcLast + ", WB.lastConn=" +
				// WB.lastConn, WB.strEmpty, "Conn");
			}

			if (work.contains(WB.lastConn)) {
				WB.lastConnWork = WB.lastConn;
//			WB.addLog2("Conn.getLast, work.contains(WB.lastConn), WB.lastConnWork=" + WB.lastConnWork
//					+ ", WB.lastConn = " + WB.lastConn, WB.strEmpty, "Conn");
			}

			if (WB.lastConnWork.isEmpty()) {
				WB.lastConnWork = work.first();
//			WB.addLog2("Conn.getLast, WB.lastConnWork.isEmpty(), WB.lastConnWork=" + WB.lastConnWork
//					+ ", work.first() = " + work.first(), WB.strEmpty, "Conn");
			}
			WB.getLocalEnd("Conn.getLast, WB.abcLast=" + WB.abcLast, localStart);
		} catch (Exception ex) {
			WB.addLog2("Conn.getLast, ex=" + ex.getMessage(), WB.strEmpty, "Conn");
		} finally {
			Etc.doNothing();
		}
	}

	public static TreeSet<String> getDbList2(String dirPath, String patternInOut, String patternTo) throws Exception {
		// origin - 31.05.2024, last edit - 03.07.2024
		TreeSet<String> res = new TreeSet<String>();
		try {
			if (Files.notExists(Paths.get(dirPath))) {
				WB.addLog("Conn.getDbList, Files.notExists in=" + Paths.get(dirPath), WB.strEmpty, "Conn");
				return res;
			}

			File file = Paths.get(dirPath).toFile();
			String currFileName = WB.strEmpty;
			for (File currFile : file.listFiles()) {
//			WB.addLog2("Conn.getDbList, select file=" + currFile + ", dirPath=" + dirPath + ", patternInOut=" + patternInOut
//					+ ", patternTo=" + patternTo, WB.strEmpty, "Conn");
				if (currFile.isFile() == false) {
					continue;
				}

				currFileName = currFile.getName().toString();

				// in future will be new versions SQLite, example "sqlite4, sqlite5" etc.
				if (Etc.strContains(currFileName, Conn.patternExtensionSqlite) == false) {
					continue;
				}

				if (Etc.strContains(currFileName, patternInOut)) {
					if (Etc.strContains(currFileName, patternTo)) {
						addDbList(currFile, res);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog2("Conn.getDbList2, ex=" + ex.getMessage(), WB.strEmpty, "Conn");
		} finally {
			Etc.doNothing();
		}

//		WB.addLog2("Conn.getDbList2, res.size=" + res.size() + ", dirPath=" + dirPath + ", patternInOut=" + patternInOut
//				+ ", patternTo=" + patternTo, WB.strEmpty, "Conn");
		return res;
	}

	private static void getDbList(String dirPath) throws Exception {
		// origin - 22.10.2023, last edit - 03.07.2024
		try {
			if (Files.notExists(Paths.get(dirPath))) {
				WB.addLog("Conn.getDbList, Files.notExists in=" + Paths.get(dirPath), WB.strEmpty, "Conn");
				return;
			}

			File file = Paths.get(dirPath).toFile();
			String currFileName = WB.strEmpty;
			for (File currFile : file.listFiles()) {
				if (currFile.isFile() == false) {
					continue;
				}

				currFileName = currFile.getName().toString();

				// in future will be new versions SQLite, example ".sqlite4, .sqlite5", etc.
				if (Etc.strContains(currFileName, Conn.patternExtensionSqlite) == false) {
					continue;
				}

				if (Etc.strContains(currFileName, testDbPattern)) {
					addDbList(currFile, testDb);
				}

				if (Etc.strContains(currFileName, exampleDbPattern)) {
					addDbList(currFile, exampleDb);
				}

				if (Etc.strContains(currFileName, largeDbPattern)) {
					addDbList(currFile, largeDb);
					// WB.addLog2("Conn.getDbList, largePath=" + largePath, WB.strEmpty, "Conn");
				}

				// skip DatabaseLocal (earlier dbLocal was in user.dir)
				if (Etc.strContains(currFileName, localDbPattern)) {
					continue;
				}

				// if in current database no tables norm then skip this database file
				if (hasTableNormList(currFileName.toString()) == false) {
					continue;
				}
				// if in current database no tables then skip this database file
				if (existTableList(currFileName) == false) {
					continue;
				}

				if (isDbList(currFile, systemNorm)) {
					addDbList(currFile, systemFact);
				} else {
					addDbList(currFile, work);
				}
			}
			WB.addLog2("Conn.getDbList, Conn.work=" + work, WB.strEmpty, "Conn");
			WB.addLog2("Conn.getDbList, Conn.systemFact=" + systemFact, WB.strEmpty, "Conn");
			// WB.addLog2("Conn.getDbList, Conn.testDb=" + testDb, WB.strEmpty, "Conn");
			// WB.addLog2("Conn.getDbList, Conn.exampleDb=" + exampleDb, WB.strEmpty,
			// "Conn");
		} catch (Exception ex) {
			WB.addLog2("Conn.getDbList, ex=" + ex.getMessage(), WB.strEmpty, "Conn");
		} finally {
			Etc.doNothing();
		}
	}

	private static void addDbList(File currFile, TreeSet<String> dbList) throws Exception {
		// origin - 24.12.2023, last edit - 03.07.2024
		try {
			dbList.add(currFile.getPath().toString()); // ex. getPath = C:\WorkBookBasic\WB\MyWorkBase1.sqlite3
			// WB.addLog2("Conn.addDbList, currFile=" + currFile + ", dbList=" + dbList + ",
			// dbList.currSize=" + dbList.size(), WB.strEmpty, "Conn");
		} catch (Exception ex) {
			WB.addLog2("Conn.addDbList, ex=" + ex.getMessage(), WB.strEmpty, "Conn");
		} finally {
			Etc.doNothing();
		}
	}

	private static boolean isDbList(File dbFile, TreeSet<String> dbList) throws Exception {
		// origin - 01.01.2024, last edit - 03.07.2024
		boolean res = false;
		try {
			// dbName = Etc.fixTrim(dbName.toLowerCase());
			if (dbList.contains(dbFile.getPath().toString())) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog2("Conn.isDbList, ex=" + ex.getMessage(), WB.strEmpty, "Conn");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static String getText(String dbStr) throws Exception {
		// origin - 02.11.2023, last edit - 03.07.2024
		String res = Etc.fixTrim(dbStr);
		try {
			res = Etc.delStr(dbStr, prefixJdbcSqlite);
			res = prefixJdbcSqlite + res;
		} catch (Exception ex) {
			WB.addLog2("Conn.getText, ex=" + ex.getMessage(), WB.strEmpty, "Conn");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	private static void cloneDbTemplate(String dirPath) throws Exception {
		// origin - 22.10.2023, last edit - 03.07.2024
		try {
			if (work.size() > 0) {
				return;
			}
			Path fileTo = Paths.get(workAutoCreatePath);
			if (Files.exists(fileTo)) {
				return;
			}

			Path fileFrom = Paths.get(templatePath);
			if (Files.notExists(fileFrom)) {
				return;
			}

			if (existTableList(fileFrom.toString())) {
				if (hasTableNormList(fileFrom.toString())) {
					// try {
					copyFile(fileTo, fileFrom);
					work.add(fileTo.toString());
					// WB.addLog("Conn.cloneDbTemplate, dbWorkAutoCreatePath=" + workAutoCreatePath,
					// WB.strEmpty, "Conn()");
					WB.addLog("Conn.cloneDbTemplate, dbWork=" + work, WB.strEmpty, "Conn()");
				}
			}
		} catch (Exception ex) {
			WB.addLog2("Conn.cloneDbTemplate, ex=" + ex.getMessage(), WB.strEmpty, "Conn");
		} finally {
			Etc.doNothing();
		}
	}

	@SuppressWarnings("deprecation")
	public static void copyExtFile(String urlFrom, String fileTo) throws Exception {
		// origin - 24.12.2023, last edit - 03.07.2024
		try {
			URL url = new URL(urlFrom);
			Path outputDocPath = Path.of(fileTo);

			try (InputStream in = url.openStream()) {
				Files.copy(in, outputDocPath, StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (Exception ex) {
			WB.addLog("Conn.copyExtFile, ex=" + ex.getMessage() + ", urlFrom=" + urlFrom + ", file to=" + fileTo,
					WB.strEmpty, "Conn");
		} finally {
			Etc.doNothing();
		}
	}

	public static void copyFile(Path fileTo, Path fileFrom) throws Exception {
		// origin - 24.12.2023, last edit - 27.06.2024
		try {
			Files.copy(fileFrom, fileTo);
		} catch (Exception ex) {
			WB.addLog("Conn.copyFile, ex=" + ex.getMessage(), WB.strEmpty, "Conn");
		} finally {
			Etc.doNothing();
		}
	}

	public static boolean hasTableNormList(String currConn) throws Exception {
		// origin - 22.11.2023, last edit - 06.07.2024
		boolean res = false;
		try {
			List<String> dbHasTableFactList = DAL.getTableList(currConn);
			if (dbHasTableFactList.containsAll(Conn.tableNorm)) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("Conn.hasTableNormList, ex=" + ex.getMessage(), WB.strEmpty, "Conn");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Conn.hasTableNormList, res= " + res, WB.strEmpty, "Conn");
		return res;
	}

	public static boolean existTableList(String currConn) throws Exception {
		// origin - 16.11.2023, last edit - 06.07.2024
		boolean res = false;
		try {
			if (DAL.getTableList(currConn).isEmpty() != true) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("Conn.existTableList, ex=" + ex.getMessage(), WB.strEmpty, "Conn");
		} finally {
		}
		// WB.addLog2("Conn.existTableList end ", WB.strEmpty, "Conn");
		return res;
	}

	public static void test() throws Exception {
		// origin - 17.11.2023, last edit - 06.07.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Conn.test, ex=" + ex.getMessage(), WB.strEmpty, "Conn");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Conn.test end ", WB.strEmpty, "Conn");
	}
}
