import java.io.File;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.TreeSet;

public class Conn {
	// origin - 17.11.2023, last edit - 08.01.2024
	public static String dbDir;

	private static String global;
	public static String globalPath;

	public static String localDbPattern;
	public static String localPath;

	public static String template;
	private static String templatePath;

	public static String large;
	public static String largeDbPattern;
	public static String largePath;

	private static String testDbPattern;
	private static String exampleDbPattern;

	private static String workAutoCreate;
	private static String workAutoCreatePath;
	public static TreeSet<String> systemFact = new TreeSet<String>();
	public static TreeSet<String> work = new TreeSet<String>();
	public static TreeSet<String> workOut = new TreeSet<String>(); // TODO ????
	public static TreeSet<String> systemNorm;

	public static TreeSet<String> testDb;
	public static TreeSet<String> exampleDb;
	private static List<String> tableNorm;
	public static String prefixJdbcSqlite;

	static {
		dbDir = System.getProperty("user.dir");
		global = getFile("DatabaseGlobal.sqlite");
		globalPath = getPath(global);
		template = getFile("DatabaseTemplate.sqlite");
		templatePath = getPath(template);
		large = getFile("DatabaseLarge.sqlite");
		largePath = getPath(large);
		testDbPattern = "test";
		exampleDbPattern = "example";
		localDbPattern = "DatabaseLocal";
		largeDbPattern = "DatabaseLarge";
		workAutoCreate = "MyWorkBase1.sqlite3";
		workAutoCreatePath = getPath(workAutoCreate);
		systemNorm = new TreeSet<String>(Arrays.asList(globalPath, templatePath));
		tableNorm = new ArrayList<String>(Arrays.asList("Account", "Asset", "Deal", "Debt", "Face", "Geo", "Info",
				"Item", "Mark", "Meter", "Price", "Process", "Role", "Sign", "Slice", "Unit", "Workbook"));
		prefixJdbcSqlite = "jdbc:sqlite:";
	}

	public static String getFile(String subStrFileName) {
		// origin - 30.11.2023, last edit - 24.12.2023
		subStrFileName = Etc.fixTrim(subStrFileName);
		String res = subStrFileName;
		if (Files.notExists(Paths.get(dbDir))) {
			return res;
		}
		File file = Paths.get(dbDir).toFile();
		for (File currFile : file.listFiles()) {
			if (currFile.isFile() == false) {
				continue;
			}
			if (currFile.getName().contains(subStrFileName)) {
				res = currFile.getName().toString();
			}
		}
		// Logger.add2("Conn.getFile, res=" + res + ", subStrFileName=" +
		// subStrFileName, "", "Conn");
		return res;
	}

	private static String getPath(String file) {
		// origin - 30.11.2023, last edit - 30.11.2023
		String res = "";
		res = dbDir + File.separator + file;
		return res;
	}

	public static void init() throws Exception {
		// origin - 25.11.2023, last edit - 06.01.2024
		if (systemFact.isEmpty()) {
			getDbList(dbDir);
			cloneDbTemplate(dbDir);
		}
		getLast();
		getLocal(WB.localDir);
	}

	public static void getLocal(String dirPath) throws Exception {
		// origin - 06.01.2024, last edit - 07.01.2024
		if (Files.notExists(Paths.get(dirPath))) {
			Logger.add("Conn.setLocal, Files.notExists in=" + Paths.get(dirPath), "", "Conn");
			return;
		}

		Long maxLastModified = 2L;
		Long currLastModified;

		File file = Paths.get(dirPath).toFile();
		for (File currFile : file.listFiles()) {
			if (isDbType(currFile.getName(), localDbPattern) == false) {
			}

			currLastModified = currFile.lastModified();
			//Logger.add("Conn.getLocal, currFile=" + currFile + ", currLastModified=" + currLastModified, "", "Conn");
			if (currLastModified > maxLastModified) {
				maxLastModified = currLastModified;
				//Logger.add("Conn.getLocal, currFile=" + currFile + ", currLastModified=" + currLastModified, "", "Conn");
				setLocal(dirPath, currFile);
			}
		}
		Logger.add("Conn.getLocal, finally localPath=" + localPath + ", finally WB.abcLocal=" + WB.abcLocal, "", "Conn");
	}

	private static void setLocal(String dirPath, File currFile) throws Exception {
		// origin - 06.01.2024, last edit - 07.01.2024
		localPath = dirPath + File.separator + currFile.getName();
		WB.abcLocal = new Abc(localPath);
		//Logger.add("Conn.setLocal, abcLocal=" + WB.abcLocal + ", localPath=" + localPath, "", "Conn");
	}

	private static void getLast() throws Exception {
		// origin - 25.11.2023, last edit - 06.01.2024
		if (work.isEmpty() == false) {
			WB.lastConn = work.first();
			Logger.add2("Conn.setLast, WB.lastConn=" + WB.lastConn, "", "Conn");
			WB.abcLast = new Abc(WB.lastConn);
			Logger.add2("Conn.setLast, WB.abcLast=" + WB.abcLast + ", WB.lastConn=" + WB.lastConn, "", "Conn");
		}
	}

	private static void getDbList(String dirPath) throws Exception {
		// origin - 22.10.2023, last edit - 06.01.2024
		if (Files.notExists(Paths.get(dirPath))) {
			Logger.add("Conn.getDbList, Files.notExists in=" + Paths.get(dirPath), "", "Conn");
			return;
		}

		File file = Paths.get(dirPath).toFile();
		for (File currFile : file.listFiles()) {
			if (currFile.isFile() == false) {
				continue;
			}

			// in future will be new versions SQLite, example "sqlite3, sqlite4" etc.
			if (currFile.getName().toLowerCase().contains(".sqlite".toLowerCase()) == false) {
				continue;
			}

			// skip testDb,s
			if (isDbType(currFile.getName(), testDbPattern)) {
				addDbList(currFile, testDb);
				continue;
			}

			// skip exampleDb,s
			if (isDbType(currFile.getName(), exampleDbPattern)) {
				addDbList(currFile, exampleDb);
				continue;
			}

			// skip DatabaseLarge
			if (isDbType(currFile.getName(), largeDbPattern)) {
				Logger.add2("Conn.getDbList, largePath=" + largePath, "", "Conn");
				continue;
			}

			// skip DatabaseLocal (earlier dbLocal was in user.dir)
			if (isDbType(currFile.getName(), localDbPattern)) {
				continue;
			}

			// if in current database no tables norm then skip this database file
			if (hasTableNormList(currFile.toString()) == false) {
				continue;
			}
			// if in current database no tables then skip this database file
			if (existTableList(currFile.toString()) == false) {
				continue;
			}

			if (isDbList(currFile, systemNorm)) {
				addDbList(currFile, systemFact);
			} else {
				addDbList(currFile, work);
			}
		}
		Logger.add("Conn.getDbList, Conn.work=" + work, "", "Conn");
		Logger.add2("Conn.getDbList, Conn.systemFact=" + systemFact, "", "Conn");
		Logger.add2("Conn.getDbList, Conn.testDb=" + testDb, "", "Conn");
		Logger.add2("Conn.getDbList, Conn.exampleDb=" + exampleDb, "", "Conn");
	}

	private static void addDbList(File currFile, TreeSet<String> dbList) {
		// origin - 24.12.2023, last edit - 24.12.2023
		dbList.add(currFile.getName().toString());
	}

	private static boolean isDbList(File dbFile, TreeSet<String> dbList) throws Exception {
		// origin - 01.01.2024, last edit - 01.01.2024
		boolean res = false;
		// dbName = Etc.fixTrim(dbName.toLowerCase());
		if (dbList.contains(dbFile.getPath().toString())) {
			res = true;
		}
		return res;
	}

	public static boolean isDbType(String dbName, String dbTypeSubStr) throws Exception {
		// origin - 01.01.2024, last edit - 05.01.2024
		boolean res = false;
		dbName = Etc.fixTrim(dbName.toLowerCase());
		dbTypeSubStr = Etc.fixTrim(dbTypeSubStr.toLowerCase());
		if (dbName.contains(dbTypeSubStr)) {
			res = true;
		}
		return res;
	}

	public static String getText(String dbStr) {
		// origin - 02.11.2023, last edit - 25.11.2023
		String res = Etc.fixTrim(dbStr);
		res = Etc.delStr(dbStr, prefixJdbcSqlite);
		res = prefixJdbcSqlite + res;
		return res;
	}

	private static void cloneDbTemplate(String dirPath) throws Exception {
		// origin - 22.10.2023, last edit - 24.12.2023
		if (work.size() > 0) {
			return;
		}
		Path fileTo = Paths.get(workAutoCreatePath);
		if (Files.exists(fileTo)) {
			return;
		}

		Path fileFrom = Paths.get(templatePath);
		if (Files.notExists(fileFrom)) {
			return;
		}

		if (existTableList(fileFrom.toString())) {
			if (hasTableNormList(fileFrom.toString())) {
				// try {
				copyFile(fileTo, fileFrom);
//							} catch (Exception ex) {
//								Logger.add("Conn.cloneDbTemplate, ex=" + ex.getMessage(),
//										", StackTrace=" + ex.getStackTrace(), "Conn");
//							} finally {
//							}
				work.add(fileTo.toString());
				Logger.add("Conn.cloneDbTemplate, dbWorkAutoCreatePath=" + workAutoCreatePath, "", "Conn()");
				Logger.add("Conn.cloneDbTemplate, dbWork=" + work, "", "Conn()");
			}
		}
	}

	public static void copyExtFile(String urlFrom, String fileTo) throws Exception {
		// origin - 24.12.2023, last edit - 01.01.2024
		try {
			URL url = new URL(urlFrom);
			Path outputDocPath = Path.of(fileTo);

			try (InputStream in = url.openStream()) {
				Files.copy(in, outputDocPath, StandardCopyOption.REPLACE_EXISTING);
				// Logger.add("Conn.copyExtFile, outputDocPath=" + outputDocPath, "", "Conn");
			}
		} catch (Exception ex) {
			Logger.add("Conn.copyExtFile, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace() + ", file to="
					+ fileTo, "", "Conn");
		} finally {
			Etc.doNothing();
		}
	}

	public static void copyFile(Path fileTo, Path fileFrom) throws Exception {
		// origin - 24.12.2023, last edit - 31.12.2023
		try {
			Files.copy(fileFrom, fileTo);
			// Logger.add("Conn.copyFile, fileTo=" + fileTo, "", "Conn");
		} catch (Exception ex) {
			Logger.add("Conn.copyFile, ex=" + ex.getMessage(), ", StackTrace=" + ex.getStackTrace(), "Conn");
		} finally {
			Etc.doNothing();
		}
	}

	private static boolean hasTableNormList(String currConn) throws Exception {
		// origin - 22.11.2023, last edit - 25.11.2023
		boolean res = false;
		List<String> dbHasTableFactList = DAL.getTableList(currConn);
		if (dbHasTableFactList.containsAll(Conn.tableNorm)) {
			res = true;
		}
		return res;
	}

	private static boolean existTableList(String currConn) {
		// origin - 16.11.2023, last edit - 18.12.2023
		boolean res = false;
		try {
			if (DAL.getTableList(currConn).isEmpty() != true) {
				res = true;
			}
		} catch (Exception ex) {
			Logger.add("Conn.existTableList, ex=" + ex.getMessage() + "StackTrace=" + ex.getStackTrace(), "", "DAL");
		} finally {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 17.11.2023, last edit - 17.10.2023
	}
}
