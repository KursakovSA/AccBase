import java.util.ArrayList;
import java.util.List;

public class Cash {
	// origin - 15.03.2025, last edit - 15.03.2025
	public boolean isValid, isExist;
	public String table, src, id, parent, code, description, geo, role, info, mark, more, cashId;
	public ListVal date1, date2;
	public List<FaceDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Cash.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Cash");
		}
	}

	// full list cash on date1
	public static List<FaceDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 15.03.2025, last edit - 15.03.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceByParent = DAL.getByTemplate(WB.lastConnWork, Qry.getParentFilter(parentId), "Face");
			for (var currFace : faceByParent) {
				if (Etc.strEquals(currFace.role, Role.storeCash)) {
					var currFaceCash = new Cash(currFace.parent, currFace.code);
					var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceCash.val, WB.strEmpty);
					if (curr.id.isEmpty() == false) {
						var tmp = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
								curr.geo, curr.role, curr.info, curr.more, curr.mark);
						res.add(tmp);
						// WB.addLog2("Cash.getCurr, add tmp=" + tmp, WB.strEmpty,"Cash");
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Cash.getCurr(List<FaceDto>), ex=" + ex.getMessage(), WB.strEmpty, "Cash");
		}
		return res;
	}

	// item cash on date1
	public static FaceDto getCurr(String date1, String faceParentId, String faceCashId) throws Exception {
		// origin - 15.03.2025, last edit - 15.03.2025
		FaceDto res = new FaceDto();
		try {
			var currFaceCash = new Cash(faceParentId, faceCashId);
			if (currFaceCash.val.size() != 0) {
				var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceCash.val, WB.strEmpty);
				if (curr.id.isEmpty() == false) {
					res = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
							curr.geo, curr.role, curr.info, curr.more, curr.mark);
				}
			}
		} catch (Exception ex) {
			WB.addLog("Cash.getCurr(FaceDto), ex=" + ex.getMessage(), WB.strEmpty, "Cash");
		}
		return res;
	}

	private void getVal() throws Exception {
		// origin - 15.03.2025, last edit - 15.03.2025
		try {
			String currDate1 = WB.strEmpty;
			String currDate2 = WB.strEmpty;

			// if date1 != empty and date2 may be empty or null
			if (this.date1.val.size() != 0) {
				for (int i = 0; i < this.date1.val.size(); i++) {
					currDate1 = this.date1.getByIndex(i);
					currDate2 = this.date2.getByIndex(i);

					// if this.date1 != empty, but this.date2 = empty
					if (currDate2.isEmpty()) {
						currDate2 = DateTool.formatter5(WB.maxDateSupported);
						this.date2 = new ListVal(currDate2, WB.strEmpty);
					}

					var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description,
							this.geo, this.role, this.info, this.more, this.mark);
					this.val.add(tmp);
					// WB.addLog2("Cash.getVal, add tmp=" + tmp, WB.strEmpty,"Cash");
				}
			}

			// if date1 = empty and date2 != empty or null
			if ((this.date1.val.size() == 0) & (this.date2.val.size() != 0)) {
				for (int i = 0; i < this.date2.val.size(); i++) {
					currDate1 = this.date1.getByIndex(i);
					currDate2 = this.date2.getByIndex(i);

					// if this.date2 != empty, but this.date1 = empty
					if (currDate1.isEmpty()) {
						currDate1 = DateTool.formatter5(WB.minDateSupported);
						this.date1 = new ListVal(currDate1, WB.strEmpty);
					}

					var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description,
							this.geo, this.role, this.info, this.more, this.mark);
					this.val.add(tmp);
					// WB.addLog2("Cash.getVal, add tmp=" + tmp, WB.strEmpty,"Cash");
				}
			}

			// if date1 = date2 = empty or null
			if ((this.date1.val.size() == 0) & (this.date2.val.size() == 0)) {
				if (this.description.isEmpty() == false) {
					currDate1 = DateTool.formatter5(WB.minDateSupported);
					this.date1 = new ListVal(currDate1, WB.strEmpty);
					currDate2 = DateTool.formatter5(WB.maxDateSupported);
					this.date2 = new ListVal(currDate2, WB.strEmpty);
					var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description,
							this.geo, this.role, this.info, this.more, this.mark);
					this.val.add(tmp);
					// WB.addLog2("Cash.getVal, add tmp=" + tmp, WB.strEmpty,"Cash");

				}
			}
		} catch (Exception ex) {
			WB.addLog("Cash.getVal, ex=" + ex.getMessage(), WB.strEmpty, "Cash");
		}
	}

	public void isExist() throws Exception {
		// origin - 15.03.2025, last edit - 15.03.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getParentFilter(this.parent), this.table);
			if (listDto.size() != WB.intZero) {
				for (var currDto : listDto) {
					if ((Etc.strEquals(currDto.role, Role.storeCash))) {
						if ((Etc.strEquals(currDto.code, this.code))) {
							this.date1 = new ListVal(currDto.date1, WB.strEmpty);
							this.date2 = new ListVal(currDto.date2, WB.strEmpty);

							this.id = DefVal.setCustom(this.id, currDto.id);
							this.parent = DefVal.setCustom(this.parent, currDto.parent);
							this.code = DefVal.setCustom(this.code, currDto.code);
							this.description = DefVal.setCustom(this.description, currDto.description);
							this.geo = DefVal.setCustom(this.geo, currDto.geo);
							this.role = DefVal.setCustom(this.role, currDto.role);
							this.info = DefVal.setCustom(this.info, currDto.info);
							this.more = DefVal.setCustom(this.more, currDto.more);
							this.mark = DefVal.setCustom(this.mark, currDto.mark);

							this.cashId = MoreVal.getFieldByKey(currDto.more, "CashId");

							this.isExist = true;
							break;
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Cash.isExist, ex=" + ex.getMessage(), WB.strEmpty, "Cash");
		}
	}

	public Cash(String ParentId, String CashId) throws Exception {
		// origin - 15.03.2025, last edit - 15.03.2025
		this();
		this.table = "Face"; // ??magic string??
		this.src = ParentId + WB.strComma + CashId;
		this.parent = ParentId;
		this.code = CashId;
		this.isExist();
		this.getVal();
	}

	public void clear() throws Exception {
		// origin - 15.03.2025, last edit - 15.03.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.more = this.mark = WB.strEmpty;
			this.cashId = WB.strEmpty;
			this.date1 = this.date2 = new ListVal();
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("Cash.clear, ex=" + ex.getMessage(), WB.strEmpty, "Cash");
		}
	}

	public Cash() throws Exception {
		// origin - 15.03.2025, last edit - 15.03.2025
		this.clear();
	}

	public String toString() {
		// origin - 15.03.2025, last edit - 15.03.2025
		String res = WB.strEmpty;
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);

			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addIfNotEmpty(", cashId ", this.cashId);

			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 15.03.2025, last edit - 15.03.2025
		try {

			// getCurr(List<FaceDto>)
			for (var tmp1 : new String[] { "2023-04-05", "2025-01-31", "2025-08-15" }) {
				for (var tmp2 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
					WB.addLog2("Cash.test.getCurr(List<FaceDto>), res.size=" + Cash.getCurr(tmp1, tmp2).size()
							+ ", date1=" + tmp1 + ", parentId=" + tmp2, WB.strEmpty, "Cash");
				}
			}

			// getCurr(FaceDto)
			for (var tmp1 : new String[] { "2023-04-05", "2025-01-31", "2025-08-15" }) {
				for (var tmp2 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
					for (var tmp3 : new String[] { "Face.FA1.Cash1", "Face.Tralala.Cash1" }) {
						WB.addLog2("Cash.test.getCurr, res.code=" + Cash.getCurr(tmp1, tmp2, tmp3).code + ", date1="
								+ tmp1 + ", faceParentId=" + tmp2 + ", faceCashId=" + tmp3, WB.strEmpty, "Cash");
					}
				}
			}

//			// ctor()
//			WB.addLog2("Cash.test.ctor()=" + new Cash(), WB.strEmpty, "Cash");

//			// ctor (String, String)
//			for (var tmp1 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
//				for (var tmp2 : new String[] { "Face.FA1.Cash1", "Face.Tralala.Cash1" }) {
//					WB.addLog2("Cash.test.ctor(String,String)=" + new Cash(tmp1, tmp2), WB.strEmpty, "Cash");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("Cash.test, ex=" + ex.getMessage(), WB.strEmpty, "Cash");
		}
	}
}