import java.util.List;

public class PersonFullName {
	// origin - 26.03.2025, last edit - 26.03.2025
	public String src, src1, src2, src3, code, description;
	private static final List<String> listDelStr = List.of(".");

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("PersonFullName.static ctor, ex=" + ex.getMessage(), "", "PersonFullName");
		}
	}

	private void getSrc() throws Exception {
		// origin - 26.03.2025, last edit - 26.03.2025
		try {
			if (this.src.length() != 0) {
				String tmp = Etc.fixTrim(this.src); // "Smith John Oakland"

				int posSpace1 = tmp.indexOf(" ");
				if (posSpace1 > 0) {
					this.src1 = Etc.fixTrim(tmp.substring(0, posSpace1)); // "Smith"
					tmp = Etc.fixTrim(tmp.substring(posSpace1)); // "John Oakland"
					// WB.addLog2("PersonFullName.getSrc, tmp after src1=" + tmp, "",
					// "PersonFullName");

					int posSpace2 = tmp.indexOf(" ");
					// WB.addLog2("PersonFullName.getSrc, posSpace2=" + posSpace2, "",
					// "PersonFullName");
					if (posSpace2 > 0) {
						this.src2 = Etc.fixTrim(tmp.substring(0, posSpace2)); // "John"
						tmp = Etc.fixTrim(tmp.substring(posSpace2)); // "Oakland"
					}

					if (tmp.length() != 0) {
						this.src3 = Etc.fixTrim(tmp); // "Oakland"
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("PersonFullName.getSrc, ex=" + ex.getMessage(), "", "PersonFullName");
		}
	}

	private void getPart() throws Exception {
		// origin - 26.03.2025, last edit - 26.03.2025
		try {
			String letter1Src1 = "";
			String restSrc1 = "";
			if (this.src1.length() != 0) {
				letter1Src1 = this.src1.substring(0, 1).toUpperCase();
				restSrc1 = this.src1.substring(1).toLowerCase();
			}

			String letter1Src2 = "";
			String restSrc2 = "";
			if (this.src2.length() != 0) {
				letter1Src2 = this.src2.substring(0, 1).toUpperCase();
				restSrc2 = this.src2.substring(1).toLowerCase();
			}

			String letter1Src3 = "";
			String restSrc3 = "";
			if (this.src3.length() != 0) {
				letter1Src3 = this.src3.substring(0, 1).toUpperCase();
				restSrc3 = this.src3.substring(1).toLowerCase();
			}

			// ex. code = "Smith J.O."
			this.code = letter1Src1 + restSrc1;
			if (this.src2.isEmpty() == false) {
				this.code = this.code + " " + letter1Src2 + ".";
			}
			if (this.src3.isEmpty() == false) {
				this.code = this.code + " " + letter1Src3 + ".";
			}

			// ex. description = "Smith John Oakland"
			this.description = letter1Src1 + restSrc1;
			if (this.src2.isEmpty() == false) {
				this.description = this.description + " " + letter1Src2 + restSrc2;
			}
			if (this.src3.isEmpty() == false) {
				this.description = this.description + " " + letter1Src3 + restSrc3;
			}

		} catch (Exception ex) {
			WB.addLog("PersonFullName.getPart, ex=" + ex.getMessage(), "", "PersonFullName");
		}
	}

	public PersonFullName(String Src) throws Exception {
		// origin - 26.03.2025, last edit - 26.03.2025
		this();
		this.src = Etc.fixTrim(Src); // name surname patronymic name
		this.src = Etc.delStr(this.src, PersonFullName.listDelStr);
		this.getSrc();
		this.getPart();
	}

	public PersonFullName(String Src1, String Src2, String Src3) throws Exception {
		// origin - 26.03.2025, last edit - 26.03.2025
		this();
		this.src1 = Etc.fixTrim(Src1); // name
		this.src1 = Etc.delStr(this.src1, PersonFullName.listDelStr);
		this.src2 = Etc.fixTrim(Src2); // surname
		this.src2 = Etc.delStr(this.src2, PersonFullName.listDelStr);
		this.src3 = Etc.fixTrim(Src3); // patronymic name
		this.src3 = Etc.delStr(this.src3, PersonFullName.listDelStr);
		this.getPart();
	}

	public void clear() throws Exception {
		// origin - 26.03.2025, last edit - 26.03.2025
		try {
			this.src = src1 = this.src2 = this.src3 = this.code = this.description = "";
		} catch (Exception ex) {
			WB.addLog("PersonFullName.clear, ex=" + ex.getMessage(), "", "PersonFullName");
		}
	}

	public PersonFullName() throws Exception {
		// origin - 26.03.2025, last edit - 26.03.2025
		this.clear();
	}

	public String toString() {
		// origin - 26.03.2025, last edit - 26.03.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway(", src ", this.src);
			res = res + Fmtr.addAnyway(", src1 ", this.src1);
			res = res + Fmtr.addAnyway(", src2 ", this.src2);
			res = res + Fmtr.addAnyway(", src3 ", this.src3);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 26.03.2025, last edit - 26.03.2025
		try {

//			// ctor()
//			WB.addLog2("Crew.test.ctor()=" + new Staff(), "", "Crew");

//			// ctor (String)
//			for (var tmp1 : new String[] { "Иванов Иван Иванович", "ИВАНОВ. ИВАН. ИВАНОВИЧ", "ИвАнОв ИвАн ИвАнОвИч" }) {
//				WB.addLog2("PersonFullName.test.ctor(String)=" + new PersonFullName(tmp1), "", "PersonFullName");
//			}

//			// ctor (String, String, String)
//			for (var tmp1 : new String[] { "Иванов", "ИВАНОВ.", "ИвАнОв" }) {
//				for (var tmp2 : new String[] { "", "Иван", "ИВАН.", "ИвАн" }) {
//					for (var tmp3 : new String[] { "", "Иванович.", "ИВАНОВИЧ", "ИвАнОвИч" }) {
//						WB.addLog2("PersonFullName.test.ctor(String,String, String)="
//								+ new PersonFullName(tmp1, tmp2, tmp3), "", "PersonFullName");
//					}
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("PersonFullName.test, ex=" + ex.getMessage(), "", "PersonFullName");
		}
	}
}