import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

public final class AssetCodeId {
	// origin - 11.01.2026, last edit - 11.01.2026
	public String context, src;
	public static List<String> kind;
	public static String defaultKind;
	public LinkedHashMap<String, String> val;

	static {
		try {
			AssetCodeId.kind = AssetCodeId.getKind();
			AssetCodeId.defaultKind = AssetCodeId.kind.getFirst();
		} catch (Exception ex) {
			WB.addLog("AssetCodeId.static ctor, ex=" + ex.getMessage(), "", "AssetCodeId");
		}
	}

	public static String set(List<String> val, List<String> kindFaceGovId) throws Exception {
		// origin - 11.01.2026, last edit - 12.01.2026
		String res = ""; // ex. "123456789012 (ТНВЭД):5678901234 (ГСВС)"
		try {
			var currVal = "";
			var currKey = "";
			for (int i = 0; i < val.size(); i++) {
				currVal = val.get(i);
				if (currVal.isEmpty() == false) {
					res = res + Etc.fixTrim(currVal);
					currKey = kindFaceGovId.get(i);
					res = res + " (" + Etc.fixTrim(currKey) + ")";
				}
				res = res + ":";
			}
		} catch (Exception ex) {
			WB.addLog("AssetCodeId.set(2List<String>):String, ex=" + ex.getMessage(), "", "AssetCodeId");
		}
		return res;
	}

	public static String getByKind(LinkedHashMap<String, String> val, String assetCodeId) throws Exception {
		// origin - 11.01.2026, last edit - 12.01.2026
		String res = "";
		try {
			for (var curr : val.entrySet()) {
				// ex. kindFaceGovId="ТНВЭД[RU]TNVED[EN]", curr.getKey()="ТНВЭД",
				if (Etc.strContains(assetCodeId, curr.getKey())) {
					res = Etc.fixTrim(curr.getValue());
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("AssetCodeId.getByKind(LinkedHashMap<2String>,String):String, ex=" + ex.getMessage(), "",
					"AssetCodeId");
		}
		return res;
	}

	private static List<String> getKind() throws Exception {
		// origin - 11.01.2026, last edit - 11.01.2026
		List<String> res = new ArrayList<String>();
		try {
			for (var curr : WB.abcLast.assetCodeId) {
				res.add(Etc.fixTrim(curr.description));
			}
		} catch (Exception ex) {
			WB.addLog("AssetCodeId.getKind():List<String>, ex=" + ex.getMessage(), "", "AssetCodeId");
		}
		return res;
	}

	private void getVal() throws Exception {
		// origin - 11.01.2026, last edit - 12.01.2026
		try {
			var tmp1 = new ListVal(this.src, "");
			for (var curr : tmp1.val) {

				if (Etc.strContains(curr, "(") == false) {
					if (Etc.strContains(curr, ")") == false) {
						curr = curr + "(" + Etc.fixTrim(AssetCodeId.defaultKind) + ")";
					}
				}

				if (curr.endsWith("()")) {
					curr = curr.replace("()", "(" + AssetCodeId.defaultKind + ")");
				}

				var tmp2 = new AnnoVal(curr);
				// ex. key="ТНВЭД", value="111"
				this.val.put(tmp2.anno.getFirst().toString(), tmp2.val);
			}
		} catch (Exception ex) {
			WB.addLog("AssetCodeId.getVal():void, ex=" + ex.getMessage(), "", "AssetCodeId");
		}
	}

	public AssetCodeId(String Src) throws Exception {
		// origin - 11.01.2026, last edit - 11.01.2026
		this.clear();
		this.src = Etc.fixTrim(Src);
		this.getVal();
	}

	public AssetCodeId() throws Exception {
		// origin - 11.01.2026, last edit - 11.01.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 11.01.2026, last edit - 11.01.2026
		try {
			this.context = this.src = "";
			this.val = new LinkedHashMap<String, String>();
		} catch (Exception ex) {
			WB.addLog("AssetCodeId.clear():void, ex=" + ex.getMessage(), "", "AssetCodeId");
		}
	}

	public String toString() {
		// origin - 11.01.2026, last edit - 11.01.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway(" src ", this.src);
			res = res + Fmtr.addAnyway(" val ", this.val);
			res = res + Fmtr.addIfNotEmpty(" context ", this.context);
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 11.01.2026, last edit - 12.01.2026
		try {

//			{
//				WB.addLog2("AssetCodeId.test.set(2List<String>):String", "", "AssetCodeId");
//				var tmp1 = List.of("111", "222");
//				var tmp2 = List.of("ТНВЭД", "ГСВС");
//				var tmp3 = AssetCodeId.set(tmp1, tmp2);
//				WB.addLog2(
//						"AssetCodeId.test.set(2List<String>):String, res=" + tmp3 + ", tmp1=" + tmp1 + ", tmp2=" + tmp2,
//						"", "AssetCodeId");
//				WB.addLog2("AssetCodeId.test.ctor(src=FaceGovId.set(2List<String>)), res=" + new AssetCodeId(tmp3), "",
//						"AssetCodeId");
//			}

//			WB.addLog2("AssetCodeId.test.getByKind(LinkedHashMap<2String>,String):String", "", "AssetCodeId");
//			for (var tmp1 : new String[] { "111 (ТНВЭД)", "222 (ГСВС)", "111 (ТНВЭД):222 (ГСВС)",
//					"111 (TNVED):222 (GSVS)", "111:222 (GSVS)", "111():222 (GSVS)" }) {
//				for (var tmp2 : List.of("ТНВЭД[RU]TNVED[EN]", "ГСВС[RU]GSVS[EN]", "VIN[RU]VIN[EN]")) {
//					var tmp3 = new AssetCodeId(tmp1);
//					WB.addLog2(
//							"AssetCodeId.test.getByKind(LinkedHashMap<2String>,String):String, res="
//									+ AssetCodeId.getByKind(tmp3.val, tmp2) + ", src=" + tmp3 + ", assetCodeId=" + tmp2,
//							"", "AssetCodeId");
//				}
//			}

//			WB.addLog2("AssetCodeId.test.ctor(String)", "", "AssetCodeId");
//			for (var tmp : new String[] { "1111 (TNVED)", "1111 (TNVED):222 (GSVS)", "111:333 (PLU)",
//					"111():444 (SKU)" }) {
//				WB.addLog2("AssetCodeId.test.ctor(String), res=" + new AssetCodeId(tmp), "", "AssetCodeId");
//			}

		} catch (Exception ex) {
			WB.addLog("AssetCodeId.test():void, ex=" + ex.getMessage(), "", "AssetCodeId");
		}
	}
}