import java.util.ArrayList;
import java.util.List;

public final class AssetVar {
	// origin - 22.10.2026, last edit - 22.10.2026
	public static List<String> infoList;

	static {
		try {
			AssetVar.infoList = List.of("Info.Generic.Name", "Info.Asset.Code", "Info.Asset.Spec");
		} catch (Exception ex) {
			WB.addLog("AssetVar.static ctor, ex=" + ex.getMessage(), "", "AssetVar");
		}
	}

	public static List<String> getListMoreVal(String more) throws Exception {
		// origin - 22.10.2026, last edit - 22.10.2026
		List<String> res = new ArrayList<String>();
		try {
			res = NameVar.getListMoreVal(more, AssetVar.getList());
			res = Etc.removeDuplicate(res);
		} catch (Exception ex) {
			WB.addLog("AssetVar.getListMoreVal(String):List<String>, ex=" + ex.getMessage(), "", "AssetVar");
		}
		return res;
	}

	private static List<String> getList() throws Exception {
		// origin - 22.10.2026, last edit - 22.10.2026
		List<String> res = new ArrayList<String>();
		try {
			for (var curr : AssetVar.infoList) {
				res.addAll(NameVar.getListByClassInfo("Asset", curr));
			}
			res = Etc.removeDuplicate(res);
		} catch (Exception ex) {
			WB.addLog("AssetVar.getList():List<String>, ex=" + ex.getMessage(), "", "AssetVar");
		}
		return res;
	}

//	public static String getByKind(LinkedHashMap<String, String> val, String assetCodeId) throws Exception {
//		// origin - 11.01.2026, last edit - 18.10.2026
//		String res = "";
//		try {
//			if (Etc.strNotValid(assetCodeId)) {
//				return res;
//			}
//			for (var curr : val.entrySet()) {
//				// ex. kindFaceGovId="ТНВЭД[RU]TNVED[EN]", curr.getKey()="ТНВЭД",
//				if (Etc.strContains(assetCodeId, curr.getKey())) {
//					res = Etc.fixTrim(curr.getValue());
//					break;
//				}
//			}
//		} catch (Exception ex) {
//			WB.addLog("AssetCodeId.getByKind(LinkedHashMap<2String>,String):String, ex=" + ex.getMessage(), "",
//					"AssetCodeId");
//		}
//		return res;
//	}

	private AssetVar() throws Exception {
		// origin - 22.10.2026, last edit - 22.10.2026
	}

	public static void test() throws Exception {
		// origin - 22.10.2026, last edit - 22.10.2026
		try {

//			WB.addLog2("AssetVar.test.getListMoreVal(String):List<String>", "", "AssetVar");
//			for (var tmp1 : new String[] { null, "", "AssetCatId=111;", "AssetCatId=222;FullName=333;",
//					"CashId=444;FullName=555;", "FullName=666;ServiceCode=777;",
//					"StoreId=111;TNVED=222;FullName=444;PassportNumber=555;" }) {
//				WB.addLog2("AssetVar.test.getListMoreVal(String):List<String>, res=" + AssetVar.getListMoreVal(tmp1)
//						+ ", tmp1=" + tmp1, "", "AssetVar");
//			}

//			WB.addLog2("AssetVar.test.getList():List<String", "", "AssetVar");
//			WB.addLog2("AssetVar.test.getList():List<String, res=" + AssetVar.getList(), "", "AssetVar");

		} catch (Exception ex) {
			WB.addLog("AssetVar.test():void, ex=" + ex.getMessage(), "", "AssetVar");
		}
	}
}