public final class AssetReg {
	// origin - 01.10.2025, last edit - 12.10.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, date1, date2, code, description, geo, role, info, unit, more, mark;
	// special fields
	public String vendorCode, PLUCode, SKUCode, TNVEDCode, GSVSCode, serialNumber, inventoryNumber, passport, VINCode,
			IMEICode, color, producer, groupFixedAssetId, dateMFG, dateEXP, productCondition;
	public UnitVal liquidationValue, estimatedValue, depreciationRate, usefulLife, standardUsefulLife;
	public SpanDate isNew;
	public String fullName, comment;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("AssetReg.static ctor, ex=" + ex.getMessage(), "", "AssetReg");
		}
	}

	private void isExist() throws Exception {
		// origin - 01.10.2025, last edit - 01.10.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(this.parent, "Role.Asset.Reg"),
					"Asset");
			if (listDto.size() != 0) {
				var currDto = listDto.getFirst();
				this.date1 = DefVal.setCustom(this.date1, currDto.date1);
				this.date2 = DefVal.setCustom(this.date2, currDto.date2);
				this.id = DefVal.setCustom(this.id, currDto.id);
				this.parent = DefVal.setCustom(this.parent, currDto.parent);
				this.code = DefVal.setCustom(this.code, currDto.code);
				this.description = DefVal.setCustom(this.description, currDto.description);
				this.geo = DefVal.setCustom(this.geo, currDto.geo);
				this.role = DefVal.setCustom(this.role, currDto.role);
				this.info = DefVal.setCustom(this.info, currDto.info);
				this.more = DefVal.setCustom(this.more, currDto.more);
				this.mark = DefVal.setCustom(this.mark, currDto.mark);
				this.getFieldFromMore();
				this.isExist = true;
				this.isValid = true;
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("AssetReg.isExist():void, ex=" + ex.getMessage(), "", "AssetReg");
		}
	}

	@SuppressWarnings("unused")
	private String getMoreFromField() throws Exception {
		// origin - 01.10.2025, last edit - 01.10.2025
		String res = "";
		try {
			res = res + MoreVal.setPartMore("FullName", this.fullName);
			res = res + MoreVal.setPartMore("Comment", this.comment);
			res = res + MoreVal.setPartMore("VendorCode", this.vendorCode);
			res = res + MoreVal.setPartMore("PLUCode", this.PLUCode);
			res = res + MoreVal.setPartMore("SKUCode", this.SKUCode);
			res = res + MoreVal.setPartMore("SerialNumber", this.serialNumber);
			res = res + MoreVal.setPartMore("InventoryNumber", this.inventoryNumber);
			res = res + MoreVal.setPartMore("Passport", this.passport);
			res = res + MoreVal.setPartMore("VINCode", this.VINCode);
			res = res + MoreVal.setPartMore("IMEICode", this.IMEICode);
			res = res + MoreVal.setPartMore("TNVEDCode", this.TNVEDCode);
			res = res + MoreVal.setPartMore("GSVSCode", this.GSVSCode);
			res = res + MoreVal.setPartMore("Color", this.color);
			res = res + MoreVal.setPartMore("Producer", this.producer);
			res = res + MoreVal.setPartMore("GroupFixedAssetId", this.groupFixedAssetId);
			res = res + MoreVal.setPartMore("dateMFG", this.dateMFG);
			res = res + MoreVal.setPartMore("dateEXP", this.dateEXP);
			res = res + MoreVal.setPartMore("ProductCondition", this.productCondition);
			res = res + MoreVal.setPartMore("LiquidationValue", this.liquidationValue.src);
			res = res + MoreVal.setPartMore("EstimatedValue", this.estimatedValue.src);
			res = res + MoreVal.setPartMore("DepreciationRate", this.depreciationRate.src);
			res = res + MoreVal.setPartMore("UsefulLife", this.usefulLife.src);
			res = res + MoreVal.setPartMore("StandardUsefulLife", this.standardUsefulLife.src);
			res = res + MoreVal.setPartMore("IsNew", this.isNew.src);
		} catch (Exception ex) {
			WB.addLog("AssetReg.getMoreFromField():String, ex=" + ex.getMessage(), "", "AssetReg");
		}
		return res;
	}

	private void getFieldFromMore() throws Exception {
		// origin - 01.10.2025, last edit - 01.10.2025
		try {
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.vendorCode = MoreVal.getFieldByKey(this.more, "VendorCode");
			this.PLUCode = MoreVal.getFieldByKey(this.more, "PLUCode");
			this.SKUCode = MoreVal.getFieldByKey(this.more, "SKUCode");
			this.serialNumber = MoreVal.getFieldByKey(this.more, "SerialNumber");
			this.inventoryNumber = MoreVal.getFieldByKey(this.more, "InventoryNumber");
			this.passport = MoreVal.getFieldByKey(this.more, "Passport");
			this.VINCode = MoreVal.getFieldByKey(this.more, "VINCode");
			this.IMEICode = MoreVal.getFieldByKey(this.more, "IMEICode");
			this.TNVEDCode = MoreVal.getFieldByKey(this.more, "TNVEDCode");
			this.GSVSCode = MoreVal.getFieldByKey(this.more, "GSVSCode");
			this.color = MoreVal.getFieldByKey(this.more, "Color");
			this.producer = MoreVal.getFieldByKey(this.more, "Producer");
			this.groupFixedAssetId = MoreVal.getFieldByKey(this.more, "GroupFixedAssetId");
			this.dateMFG = MoreVal.getFieldByKey(this.more, "dateMFG");
			this.dateEXP = MoreVal.getFieldByKey(this.more, "dateEXP");
			this.productCondition = MoreVal.getFieldByKey(this.more, "ProductCondition");
			this.liquidationValue = new UnitVal(MoreVal.getFieldByKey(this.more, "LiquidationValue"));
			this.estimatedValue = new UnitVal(MoreVal.getFieldByKey(this.more, "EstimatedValue"));
			this.depreciationRate = new UnitVal(MoreVal.getFieldByKey(this.more, "DepreciationRate"));
			this.usefulLife = new UnitVal(MoreVal.getFieldByKey(this.more, "UsefulLife"));
			this.standardUsefulLife = new UnitVal(MoreVal.getFieldByKey(this.more, "StandardUsefulLife"));
			this.isNew = new SpanDate(MoreVal.getFieldByKey(this.more, "IsNew"));
		} catch (Exception ex) {
			WB.addLog("AssetReg.getFieldFromMore():void, ex=" + ex.getMessage(), "", "AssetReg");
		}
	}

	public AssetReg(String ParentId) throws Exception {
		// origin - 01.10.2025, last edit - 01.10.2025
		this.clear();
		this.table = "Face";
		this.src = ParentId;
		this.parent = ParentId;
		this.isExist();
	}

	private void clear() throws Exception {
		// origin - 01.10.2025, last edit - 01.10.2025
		try {
			this.isValid = false;
			this.isExist = false;
			this.table = "Asset";
			this.src = this.id = this.parent = this.date1 = this.date2 = this.code = this.description = "";
			this.geo = this.role = this.info = this.unit = this.more = this.mark = "";
			this.comment = this.fullName = "";
			this.vendorCode = this.PLUCode = this.SKUCode = this.serialNumber = this.TNVEDCode = "";
			this.inventoryNumber = this.passport = this.VINCode = this.IMEICode = this.GSVSCode = this.color = "";
			this.producer = this.groupFixedAssetId = this.dateMFG = this.dateEXP = this.productCondition = "";
			this.liquidationValue = this.estimatedValue = new UnitVal(UnitVal.currCurrencyInit);
			this.depreciationRate = new UnitVal("0.0(Unit.Percent)");
			this.usefulLife = this.standardUsefulLife = new UnitVal("0.0(Unit.Year)");
			this.isNew = new SpanDate();
		} catch (Exception ex) {
			WB.addLog("AssetReg.clear():void, ex=" + ex.getMessage(), "", "AssetReg");
		}
	}

	public AssetReg() throws Exception {
		// origin - 01.10.2025, last edit - 01.10.2025
		this.clear();
	}

	public String toString() {
		// origin - 01.10.2025, last edit - 01.10.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(" vendorCode ", this.vendorCode);
			res = res + Fmtr.addIfNotEmpty(" PLUCode", this.PLUCode);
			res = res + Fmtr.addIfNotEmpty(" SKUCode ", this.SKUCode);
			res = res + Fmtr.addIfNotEmpty(" serialNumber ", this.serialNumber);
			res = res + Fmtr.addIfNotEmpty(" inventoryNumber ", this.inventoryNumber);
			res = res + Fmtr.addIfNotEmpty(" passport ", this.passport);
			res = res + Fmtr.addIfNotEmpty(" VINCode ", this.VINCode);
			res = res + Fmtr.addIfNotEmpty(" IMEICode ", this.IMEICode);
			res = res + Fmtr.addIfNotEmpty(" TNVEDCode ", this.TNVEDCode);
			res = res + Fmtr.addIfNotEmpty(" GSVSCode ", this.GSVSCode);
			res = res + Fmtr.addIfNotEmpty(" color ", this.color);
			res = res + Fmtr.addIfNotEmpty(" producer ", this.producer);
			res = res + Fmtr.addIfNotEmpty(" groupFixedAssetId ", this.groupFixedAssetId);
			res = res + Fmtr.addIfNotEmpty(" dateMFG ", this.dateMFG);
			res = res + Fmtr.addIfNotEmpty(" dateEXP ", this.dateEXP);
			res = res + Fmtr.addIfNotEmpty(" productCondition ", this.productCondition);
			res = res + Fmtr.addIfNotZeroUnitVal(" liquidationValue ", this.liquidationValue);
			res = res + Fmtr.addIfNotZeroUnitVal(" estimatedValue ", this.estimatedValue);
			res = res + Fmtr.addIfNotZeroUnitVal(" depreciationRate ", this.depreciationRate);
			res = res + Fmtr.addIfNotZeroUnitVal(" usefulLife ", this.usefulLife);
			res = res + Fmtr.addIfNotZeroUnitVal(" standardUsefulLife ", this.standardUsefulLife);
			res = res + Fmtr.addIfNotEmpty(" isNew ", this.isNew.id);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 01.10.2025, last edit - 01.10.2025
		try {

//			WB.addLog2("AssetReg.test.ctor(String)", "", "AssetReg");
//			for (var tmp1 : new String[] { "Asset.Good.Template", "Asset.Service.Template", "Asset.Test.1" }) {
//				WB.addLog2("AssetReg.test.ctor(String)=" + new AssetReg(tmp1), "", "AssetReg");
//			}

		} catch (Exception ex) {
			WB.addLog("AssetReg.test():void, ex=" + ex.getMessage(), "", "AssetReg");
		}
	}
}