import java.util.ArrayList;
import java.util.List;

public final class AssetPart {
	// origin - 25.02.2025, last edit - 02.11.2026
	// common fields
	public String table, src, id, parent, geo, role, info, unit, mark, more, defect;
	// special fields
	// special timestamp fields
	public ListVal date1, date2, code, description, qty, amt;
	// list common + special + timestamp fields in unified val
	public List<AssetDto> val;
	public static List<String> roleList;

	static {
		try {
			AssetPart.roleList = List.of("Role.Asset.Part");
		} catch (Exception ex) {
			WB.addLog("AssetPart.static ctor, ex=" + ex.getMessage(), "", "AssetPart");
		}
	}

	// full list asset part items
	public static List<AssetDto> get(String parentId) throws Exception {
		// origin - 04.05.2025, last edit - 02.11.2026
		List<AssetDto> res = new ArrayList<AssetDto>();
		try {
			if (Etc.strNotValid(parentId)) {
				return res;
			}

			var assetPartList = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleFilter(parentId, AssetPart.roleList.getFirst()), "Asset");
			if (assetPartList.size() == 0) {
				return res;
			}
			var currAssetPart = assetPartList.getFirst();
			for (var curr : new AssetPart(currAssetPart.parent).val) {
				var tmp1 = new AssetDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
						curr.geo, curr.role, curr.info, curr.unit, curr.more, curr.mark);
				if (tmp1.code.isEmpty() == false) {
					res.add(tmp1);
				}
			}
		} catch (Exception ex) {
			WB.addLog("AssetPart.get(String):List<AssetDto>, ex=" + ex.getMessage(), "", "AssetPart");
		}
		return res;
	}

	// full list asset part items on date1
	public static List<AssetDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 07.04.2025, last edit - 19.10.2026
		List<AssetDto> res = new ArrayList<AssetDto>();
		try {
			if (Etc.strNotValid(date1, parentId)) {
				return res;
			}
			var currAssetPart = new AssetPart(parentId);
			res = AssetDto.getChrono(DateTool.getLocalDate(date1), currAssetPart.val);
		} catch (Exception ex) {
			WB.addLog("AssetPart.getCurr(2String):List<AssetDto>, ex=" + ex.getMessage(), "", "AssetPart");
		}
		return res;
	}

	// item asset part position on date1
	public static AssetDto getCurr(String date1, String parentId, String assetPartCode) throws Exception {
		// origin - 07.04.2025, last edit - 19.10.2026
		AssetDto res = new AssetDto();
		try {
			if (Etc.strNotValid(date1, parentId, assetPartCode)) {
				return res;
			}

			var assetPart = new AssetPart(parentId);
			for (var currAssetPart : assetPart.val) {
				if (Etc.strEquals(currAssetPart.code, assetPartCode)) {
					var curr = AssetDto.getChronoByUnit(DateTool.getLocalDate(date1), List.of(currAssetPart), "");
					if (curr.code.isEmpty() == false) {
						res = new AssetDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
								curr.geo, curr.role, curr.info, curr.unit, curr.more, curr.mark);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("AssetPart.getCurr(3String):AssetDto, ex=" + ex.getMessage(), "", "AssetPart");
		}
		return res;
	}

	private void validate() throws Exception {
		// origin - 19.11.2025, last edit - 10.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}
		} catch (Exception ex) {
			WB.addLog("AssetPart.validate():void, ex=" + ex.getMessage(), "", "AssetPart");
		}
	}

	private void getVal() throws Exception {
		// origin - 28.02.2025, last edit - 02.11.2026
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currCode = "";
			String currDescription = "";
			String currQty = "";
			String currAmt = "";
			String currMore = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currCode = this.code.getByIndex(i);
				currDescription = this.description.getByIndex(i);
				currQty = this.qty.getByIndex(i);
				currAmt = this.amt.getByIndex(i);
				currMore = "";
				currMore = currMore + MoreVal.setPart("Qty", currQty);
				currMore = currMore + MoreVal.setPart("Amt", currAmt);
				var tmp = new AssetDto(this.id, this.parent, currDate1, currDate2, currCode, currDescription, this.geo,
						this.role, this.info, this.unit, currMore, this.mark);
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("AssetPart.getVal():void, ex=" + ex.getMessage(), "", "AssetPart");
		}
	}

	private void isExist() throws Exception {
		// origin - 25.02.2025, last edit - 02.11.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleFilter(this.parent, AssetPart.roleList.getFirst()), this.table);
			if (listDto.size() != 0) {
				var currDto = listDto.getFirst();
				var tmp = new SpanDate(currDto.date1, currDto.date2);
				this.date1 = new ListVal(tmp.date1);
				this.date2 = new ListVal(tmp.date2);
				this.id = DefVal.setCustom(this.id, currDto.id);
				this.code = new ListVal(currDto.code, "");
				this.description = new ListVal(currDto.description, "");
				this.geo = DefVal.setCustom(this.geo, currDto.geo);
				this.role = DefVal.setCustom(this.role, currDto.role);
				this.info = DefVal.setCustom(this.info, currDto.info);
				this.unit = DefVal.setCustom(this.unit, currDto.unit);
				this.more = DefVal.setCustom(this.more, currDto.more);
				this.mark = DefVal.setCustom(this.mark, currDto.mark);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.clear();
			}
		} catch (Exception ex) {
			WB.addLog("AssetPart.isExist():void, ex=" + ex.getMessage(), "", "AssetPart");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 04.10.2025, last edit - 02.11.2026
		try {
			this.qty = new ListVal(MoreVal.getFieldByKey(this.more, "Qty"), "");
			this.amt = new ListVal(MoreVal.getFieldByKey(this.more, "Amt"), "");
		} catch (Exception ex) {
			WB.addLog("AssetPart.getFieldFromMore():void, ex=" + ex.getMessage(), "", "AssetPart");
		}
	}

	public AssetPart(String ParentId) throws Exception {
		// origin - 25.02.2025, last edit - 19.11.2025
		this();
		this.src = this.parent = ParentId;
		this.isExist();
		this.getVal();
		this.validate();
	}

	private void clear() throws Exception {
		// origin - 25.02.2025, last edit - 02.11.2026
		try {
			this.table = "Asset";
			this.src = this.id = this.parent = this.geo = this.role = this.info = this.unit = this.mark = this.more = "";
			this.date1 = this.date2 = this.code = this.description = this.qty = this.amt = new ListVal();
			this.defect = "";
			this.val = new ArrayList<AssetDto>();
		} catch (Exception ex) {
			WB.addLog("AssetPart.clear():void, ex=" + ex.getMessage(), "", "AssetPart");
		}
	}

	public AssetPart() throws Exception {
		// origin - 25.02.2025, last edit - 25.02.2025
		this.clear();
	}

	public String toString() {
		// origin - 25.02.2025, last edit - 02.11.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code.id);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description.id);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", ", this.unit);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", qty ", this.qty.id);
			res = res + Fmtr.addIfNotEmpty(", amt ", this.amt.id);
			res = res + Fmtr.addIfNotEmpty(", val.size ", this.val.size());
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 25.02.2025, last edit - 24.08.2026
		try {

//			WB.addLog2("AssetPart.test.get(List<AssetDto>)", "", "AssetPart");
//			for (var tmp1 : new String[] { "Asset.Test.1" }) {
//				var tmp2 = AssetPart.get(tmp1);
//				WB.addLog2("AssetPart.test.get(List<AssetDto>), res.size=" + tmp2.size() + ", parentId=" + tmp1, "",
//						"AssetPart");
//				WB.log(tmp2, "AssetPart");
//			}

//			WB.addLog2("AssetPart.test.getCurr(3String):List<AssetDto>", "", "AssetPart");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Asset.Test.1" }) {
//					var tmp3 = AssetPart.getCurr(tmp1, tmp2);
//					WB.addLog2("AssetPart.test.getCurr(3String):List<AssetDto>, res.size=" + tmp3.size() + ", date1="
//							+ tmp1 + ", parentId=" + tmp2, "", "AssetPart");
//					WB.log(tmp3, "AssetPart");
//				}
//			}

//			WB.addLog2("AssetPart.test.getCurr(3String):AssetDto", "", "AssetPart");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-08-15" }) {
//				var tmp2 = new NVal("Asset.Test.1 , Asset.Test.1.Part1");
//				WB.addLog2(
//						"AssetPart.test.getCurr(3String):AssetDto, res=" + AssetPart.getCurr(tmp1, tmp2.getVal(1), tmp2.getVal(2))
//								+ ", date1=" + tmp1 + ", parentId=" + tmp2.getVal(1) + ", assetPartCode=" + tmp2.getVal(2),
//						"", "AssetPart");
//			}

//			WB.addLog2("AssetPart.test.ctor(String)", "", "AssetPart");
//			for (var tmp1 : new String[] { "Asset.Test.1", "Asset.Test.2" }) {
//				var tmp2 = new AssetPart(tmp1);
//				WB.addLog2("AssetPart.test.ctor(String)=" + tmp2, "", "AssetPart");
//				WB.log(tmp2.val, "AssetPart");
//			}

		} catch (Exception ex) {
			WB.addLog("AssetPart.test():void, ex=" + ex.getMessage(), "", "AssetPart");
		}
	}
}