import java.util.ArrayList;
import java.util.List;

public class AssetPart {
	// origin - 25.02.2025, last edit - 07.04.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, geo, role, info, unit, mark, more;
	// special fields
	public String fullName, comment;
	// special timestamp fields
	public ListVal date1, date2, code, description, quantity, amount;
	// list common + special + timestamp fields in unified val
	public List<AssetDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("AssetPart.static ctor, ex=" + ex.getMessage(), "", "AssetPart");
		}
	}

	// full list asset part items
	public static List<AssetDto> get(String parentId) throws Exception {
		// origin - 04.05.2025, last edit - 13.06.2025
		List<AssetDto> res = new ArrayList<AssetDto>();
		try {
			var assetPartList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentInfoFilter(parentId, Info.assetPart),
					"Asset");
			if (assetPartList.size() != 0) {
				var currAssetPart = assetPartList.getFirst();
				for (var curr : new AssetPart(currAssetPart.parent).val) {
					var tmp1 = new AssetDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
							curr.geo, curr.role, curr.info, curr.unit, curr.more, curr.mark);
					tmp1.fullName = curr.fullName;
					tmp1.comment = curr.comment;
					tmp1.quantity = curr.quantity;
					tmp1.amount = curr.amount;
					if (tmp1.code.isEmpty() == false) {
						res.add(tmp1);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("AssetPart.get(String parentId):List<AssetDto>, ex=" + ex.getMessage(), "", "AssetPart");
		}
		return res;
	}

	// full list asset part items on date1
	public static List<AssetDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 07.04.2025, last edit - 13.06.2025
		List<AssetDto> res = new ArrayList<AssetDto>();
		try {
			var currAssetPart = new AssetPart(parentId);
			res = AssetDto.getChrono(DateTool.getLocalDate(date1), currAssetPart.val);
		} catch (Exception ex) {
			WB.addLog("AssetPart.getCurr(String date1, String parentId):List<AssetDto>, ex=" + ex.getMessage(), "",
					"AssetPart");
		}
		return res;
	}

	// item asset part position on date1
	public static AssetDto getCurr(String date1, String parentId, String assetPartCode) throws Exception {
		// origin - 07.04.2025, last edit - 13.06.2025
		AssetDto res = new AssetDto();
		try {
			var assetPart = new AssetPart(parentId);
			for (var currAssetPart : assetPart.val) {
				if (Etc.strEquals(currAssetPart.code, assetPartCode)) {
					var curr = AssetDto.getChrono(DateTool.getLocalDate(date1), List.of(currAssetPart), "");
					if (curr.code.isEmpty() == false) {
						res = new AssetDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
								curr.geo, curr.role, curr.info, curr.unit, curr.more, curr.mark);
						res.quantity = curr.quantity;
						res.amount = curr.amount;
						res.comment = curr.comment;
						res.fullName = curr.fullName;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("AssetPart.getCurr(String date1, String parentId, String assetPartCode):AssetDto, ex="
					+ ex.getMessage(), "", "AssetPart");
		}
		return res;
	}

	private void getVal() throws Exception {
		// origin - 28.02.2025, last edit - 13.06.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currCode = "";
			String currDescription = "";
			String currQuantity = "";
			String currAmount = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currCode = this.code.getByIndex(i);
				currDescription = this.description.getByIndex(i);
				currQuantity = this.quantity.getByIndex(i);
				currAmount = this.amount.getByIndex(i);
				var tmp = new AssetDto(this.id, this.parent, currDate1, currDate2, currCode, currDescription, this.geo,
						this.role, this.info, this.unit, this.more, this.mark);
				tmp.quantity = currQuantity;
				tmp.amount = currAmount;
				tmp.comment = this.comment;
				tmp.fullName = this.fullName;
				this.val.add(tmp);
				// WB.addLog2("AssetPart.getVal, add tmp=" + tmp, "","AssetPart");
			}
		} catch (Exception ex) {
			WB.addLog("AssetPart.getVal():void, ex=" + ex.getMessage(), "", "AssetPart");
		}
	}

	public void isExist() throws Exception {
		// origin - 25.02.2025, last edit - 13.06.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getParentInfoFilter(this.parent, Info.assetPart),
					this.table);
			if (listDto.size() != 0) {
				for (var currDto : listDto) {
					var tmp = new SpanDate(currDto.date1, currDto.date2);
					this.date1 = new ListVal(tmp.date1);
					this.date2 = new ListVal(tmp.date2);

					this.id = DefVal.setCustom(this.id, currDto.id);

					this.code = new ListVal(currDto.code, "");
					this.description = new ListVal(currDto.description, "");

					this.geo = DefVal.setCustom(this.geo, currDto.geo);
					this.role = DefVal.setCustom(this.role, currDto.role);
					this.info = DefVal.setCustom(this.info, currDto.info);
					this.unit = DefVal.setCustom(this.unit, currDto.unit);
					this.more = DefVal.setCustom(this.more, currDto.more);
					this.mark = DefVal.setCustom(this.mark, currDto.mark);

					this.fullName = MoreVal.getFieldByKey(currDto.more, "FullName");
					this.comment = MoreVal.getFieldByKey(currDto.more, "Comment");
					this.quantity = new ListVal(MoreVal.getFieldByKey(currDto.more, "Quantity"), "");
					this.amount = new ListVal(MoreVal.getFieldByKey(currDto.more, "Amount"), "");

					this.isExist = true;
					break;
				}
			}

			if (listDto.size() == 0) {
				this.parent = "";
			}
		} catch (Exception ex) {
			WB.addLog("AssetPart.isExist():void, ex=" + ex.getMessage(), "", "AssetPart");
		}
	}

	public AssetPart(String ParentId) throws Exception {
		// origin - 25.02.2025, last edit - 07.04.2025
		this();
		this.table = "Asset";
		this.src = this.parent = ParentId;
		this.isExist();
		this.getVal();
	}

	public void clear() throws Exception {
		// origin - 25.02.2025, last edit - 13.06.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = this.src = this.id = this.parent = this.geo = this.role = this.info = this.unit = this.mark = this.more = "";
			this.date1 = this.date2 = this.code = this.description = this.quantity = this.amount = new ListVal();
			this.fullName = this.comment = "";
			this.val = new ArrayList<AssetDto>();
		} catch (Exception ex) {
			WB.addLog("AssetPart.clear():void, ex=" + ex.getMessage(), "", "AssetPart");
		}
	}

	public AssetPart() throws Exception {
		// origin - 25.02.2025, last edit - 25.02.2025
		this.clear();
	}

	public String toString() {
		// origin - 25.02.2025, last edit - 07.04.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);

			res = res + Fmtr.addIfNotEmpty(", code ", this.code.id);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description.id);

			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", ", this.unit);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);

			res = res + Fmtr.addIfNotEmpty(", quantity ", this.quantity.id);
			res = res + Fmtr.addIfNotEmpty(", amount ", this.amount.id);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 25.02.2025, last edit - 13.06.2025
		try {

//			// get(List<AssetDto>)
//			WB.addLog2("AssetPart.test.get(List<AssetDto>)", "", "AssetPart");
//			for (var tmp1 : new String[] { "Asset.Test.1" }) {
//				WB.addLog2("AssetPart.test.get(List<AssetDto>), res.size=" + AssetPart.get(tmp1).size() + ", parentId="
//						+ tmp1, "", "AssetPart");
//				WB.log(AssetPart.get(tmp1), "AssetPart");
//			}

//			// getCurr(List<AssetDto>)
//			WB.addLog2("AssetPart.test.getCurr(List<AssetDto>)", "", "AssetPart");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Asset.Test.1" }) {
//					WB.addLog2("AssetPart.test.getCurr(List<AssetDto>), res.size="
//							+ AssetPart.getCurr(tmp1, tmp2).size() + ", date1=" + tmp1 + ", parentId=" + tmp2, "",
//							"AssetPart");
//					WB.log(AssetPart.getCurr(tmp1, tmp2), "AssetPart");
//				}
//			}

//			// getCurr(AssetDto)
//			WB.addLog2("AssetPart.test.getCurr(AssetDto)", "", "AssetPart");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Asset.Test.1" }) {
//					for (var tmp3 : new String[] { "Asset.Test.1.Part1" }) {
//						WB.addLog2(
//								"AssetPart.test.getCurr(AssetDto), res=" + AssetPart.getCurr(tmp1, tmp2, tmp3)
//										+ ", date1=" + tmp1 + ", parentId=" + tmp2 + ", assetPartCode=" + tmp3,
//								"", "AssetPart");
//					}
//				}
//			}

//			// ctor (String)
//			WB.addLog2("AssetPart.test.ctor(String)", "", "AssetPart");
//			for (var tmp1 : new String[] { "Asset.Test.1", "Asset.Test.2" }) {
//				WB.addLog2("AssetPart.test.ctor(String)=" + new AssetPart(tmp1), "", "AssetPart");
//			}

		} catch (Exception ex) {
			WB.addLog("AssetPart.test():void, ex=" + ex.getMessage(), "", "AssetPart");
		}
	}
}