import java.util.ArrayList;
import java.util.List;

public class AssetDefectCat {
	// origin - 28.05.2025, last edit - 28.05.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, date1, date2, code, description, geo, role, info, unit, mark, more;
	// special fields
	public String assetDefectCatId;
	public String fullName, comment;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("AssetDefectCat.static ctor, ex=" + ex.getMessage(), "", "AssetDefectCat");
		}
	}

	// full list asset cat for parent
	public static List<AssetDefectCat> get(String parentId) throws Exception {
		// origin - 28.05.2025, last edit - 13.06.2025
		List<AssetDefectCat> res = new ArrayList<AssetDefectCat>();
		try {
//			var assetList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentInfoFilter(parentId, Info.assetCatalog),
//					"Asset");
			var asset = new Asset(parentId);
			var assetList = asset.lower;
			if (assetList.size() != 0) {
				for (var curr : assetList) {
					if ((curr.id.isEmpty() == false) & (Etc.strEquals(curr.role, Role.assetDefect))) {
						var tmp = new AssetDefectCat(
								new AssetDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
										curr.geo, curr.role, curr.info, curr.unit, curr.more, curr.mark));
						res.add(tmp);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("AssetCat.get(String parentId):List<AssetDefectCat>, ex=" + ex.getMessage(), "", "AssetCat");
		}
		return res;
	}

	public void isExist() throws Exception {
		// origin - 28.05.2025, last edit - 13.06.2025
		try {
			List<ModelDto> listDto = new ArrayList<ModelDto>();

			if (this.id.isEmpty() == false) {
				listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdRoleInfoFilter(this.id, this.role, this.info),
						this.table);
			}

			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.date1 = DefVal.setCustom(this.date1, dto.date1);
				this.date2 = DefVal.setCustom(this.date2, dto.date2);

				this.code = DefVal.setCustom(this.code, dto.code);
				this.id = DefVal.setCustom(this.id, dto.id);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.geo = DefVal.setCustom(this.geo, dto.geo);
				this.role = DefVal.setCustom(this.role, dto.role);
				this.info = DefVal.setCustom(this.info, dto.info);
				this.unit = DefVal.setCustom(this.unit, dto.unit);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.mark = DefVal.setCustom(this.mark, dto.mark);

				this.assetDefectCatId = MoreVal.getFieldByKey(dto.more, "AssetDefectCatId");

				this.fullName = MoreVal.getFieldByKey(dto.more, "FullName");
				this.comment = MoreVal.getFieldByKey(dto.more, "Comment");

				this.isExist = true;
			}

			if (listDto.size() == 0) {
				this.parent = this.id = this.code = this.description = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("AssetDefectCat.isExist():void, ex=" + ex.getMessage(), "", "AssetDefectCat");
		}
	}

	public AssetDefectCat(AssetDto aDto) throws Exception {
		// origin - 28.05.2025, last edit - 28.05.2025
		this.clear();
		this.table = "Asset";
		this.date1 = aDto.date1;
		this.date2 = aDto.date2;
		this.code = aDto.code;
		this.id = aDto.id;
		this.description = aDto.description;
		this.geo = aDto.geo;
		this.role = aDto.role;
		this.info = aDto.info;
		this.unit = aDto.unit;
		this.more = aDto.more;
		this.mark = aDto.mark;

		this.assetDefectCatId = MoreVal.getFieldByKey(this.more, "AssetDefectCatId");

		this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
		this.comment = MoreVal.getFieldByKey(this.more, "Comment");
	}

	public AssetDefectCat(String Id) throws Exception {
		// origin - 28.05.2025, last edit - 28.05.2025
		this.clear();
		this.table = "Asset";
		this.src = Id + "," + Role.assetDefect;
		this.id = Id;
		this.role = Role.assetDefect;
		this.info = Info.assetCatalog;
		this.isExist();
	}

	public void clear() throws Exception {
		// origin - 28.05.2025, last edit - 13.06.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = this.src = this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.geo = this.role = this.info = this.unit = this.mark = this.more = "";
			this.assetDefectCatId = "";
			this.fullName = this.comment = "";
		} catch (Exception ex) {
			WB.addLog("AssetCat.clear():void, ex=" + ex.getMessage(), "", "AssetCat");
		}
	}

	public AssetDefectCat() throws Exception {
		// origin - 28.05.2025, last edit - 27.05.2025
		this.clear();
	}

	public String toString() {
		// origin - 28.05.2025, last edit - 28.05.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("table ", this.table);
			res = res + Fmtr.addIfNotEmpty(" src ", this.src);
			res = res + Fmtr.addIfNotEmpty(" id ", this.id);
			res = res + Fmtr.addIfNotEmpty(" parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(" date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(" date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(" code ", this.code);
			res = res + Fmtr.addIfNotEmpty(" description ", this.description);
			res = res + Fmtr.addIfNotEmpty(" ", this.geo);
			res = res + Fmtr.addIfNotEmpty(" ", this.role);
			res = res + Fmtr.addIfNotEmpty(" ", this.info);
			res = res + Fmtr.addIfNotEmpty(" ", this.unit);
			res = res + Fmtr.addIfNotEmpty(" more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addIfNotEmpty(" assetDefectCatId ", this.assetDefectCatId);

			res = res + Fmtr.addIfNotEmpty(" fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(" comment ", this.comment);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.05.2025, last edit - 13.06.2025
		try {

//			// test get(List<AssetDefectCat>)
//			WB.addLog2("AssetDefectCat.test.get(List<AssetCat>)", "", "AssetDefectCat");
//			for (var tmp1 : new String[] { "Asset.PM.Catalog", "Asset.PS.Catalog" }) {
//				var tmp = AssetDefectCat.get(tmp1);
//				WB.addLog2(
//						"AssetDefectCat.test.get(List<AssetDefectCat>), res.size=" + tmp.size() + ", parentId=" + tmp1,
//						"", "AssetDefectCat");
//				WB.log(tmp, "AssetDefectCat");
//			}

//			// test ctor (String)
//			WB.addLog2("AssetDefectCat.test.ctor(String)", "", "AssetDefectCat");
//			for (var tmp1 : new String[] { "Asset.PS.Defect.Catalog.1", "Asset.Tralala.Catalog.1",
//					"Asset.PS.Catalog.1" }) {
//				WB.addLog2("AssetDefectCat.test.ctor(String)=" + new AssetDefectCat(tmp1), "", "AssetDefectCat");
//			}

		} catch (Exception ex) {
			WB.addLog("AssetDefectCat():void.test, ex=" + ex.getMessage(), "", "AssetDefectCat");
		}
	}
}