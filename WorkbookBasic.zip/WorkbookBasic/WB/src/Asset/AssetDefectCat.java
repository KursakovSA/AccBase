import java.util.ArrayList;
import java.util.List;

public final class AssetDefectCat {
	// origin - 28.05.2025, last edit - 15.09.2026
	// common fields
	public String table, src, id, parent, date1, date2, code, description, geo, role, info, unit, mark, more, defect;
	// special fields
	public String fullName, comment;
	public static List<String> nameList;

	static {
		AssetDefectCat.nameList = List.of("AssetDefectCatId");
		try {
		} catch (Exception ex) {
			WB.addLog("AssetDefectCat.static ctor, ex=" + ex.getMessage(), "", "AssetDefectCat");
		}
	}

	// full list AssetDefectCat
	public static List<AssetDefectCat> get() throws Exception {
		// origin - 29.09.2025, last edit - 29.09.2025
		List<AssetDefectCat> res = new ArrayList<AssetDefectCat>();
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getRoleInfoFilter("Role.Asset.Defect", "Info.Asset.Catalog"), "Asset");
			if (listDto.size() != 0) {
				for (var currDto : listDto) {
					res.add(new AssetDefectCat(currDto));
				}
			}
		} catch (Exception ex) {
			WB.addLog("AssetDefectCat.get():List<AssetDefectCat>, ex=" + ex.getMessage(), "", "AssetDefectCat");
		}
		return res;
	}

	// common list AssetDefectCat, for them ParentId = rootAssetCatalogId
	public static List<AssetDefectCat> getCommon(String rootAssetCatalogId) throws Exception {
		// origin - 29.09.2025, last edit - 30.09.2025
		List<AssetDefectCat> res = new ArrayList<AssetDefectCat>();
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleInfoFilter(rootAssetCatalogId, "Role.Asset.Defect", "Info.Asset.Catalog"),
					"Asset");
			if (listDto.size() != 0) {
				for (var currDto : listDto) {
					res.add(new AssetDefectCat(currDto));
				}
			}
		} catch (Exception ex) {
			WB.addLog("AssetDefectCat.getCommon(String):List<AssetDefectCat>, ex=" + ex.getMessage(), "",
					"AssetDefectCat");
		}
		return res;
	}

	// full list AssetDefectCat for parent
	public static List<AssetDefectCat> getByParent(String parentId, String rootAssetCatalogId) throws Exception {
		// origin - 28.05.2025, last edit - 04.01.2026
		List<AssetDefectCat> res = new ArrayList<AssetDefectCat>();
		try {
			var asset = new Asset(parentId);
			var assetList = asset.lowerList;
			if (assetList.size() != 0) {
				for (var curr : assetList) {
					if ((curr.id.isEmpty() == false) & (Etc.strEquals(curr.role, "Role.Asset.Defect"))) {
						var tmp = new AssetDefectCat(curr);
						res.add(tmp);
					}
				}
			}

			// add common asset defect cat from rootAssetCatalogId
			if (res.size() != 0) {
				res.addAll(AssetDefectCat.getCommon(rootAssetCatalogId));
				// ?? how find automatically RootAssetCatalogId from ParentId ??
			}
		} catch (Exception ex) {
			WB.addLog("AssetDefectCat.getByParent(2String):List<AssetDefectCat>, ex=" + ex.getMessage(), "",
					"AssetDefectCat");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 19.11.2025, last edit - 15.09.2026
		try {
			this.defect = Fmtr.addIfStrEmpty(this.defect, MoreVal.getFieldByKey(this.more, "AssetDefectCatId"),
					"empty assetDefectCatId; ");
		} catch (Exception ex) {
			WB.addLog("AssetDefectCat.validate():void, ex=" + ex.getMessage(), "", "AssetDefectCat");
		}
	}

	private void isExist() throws Exception {
		// origin - 28.05.2025, last edit - 19.11.2025
		try {
			List<FullDto> listDto = new ArrayList<FullDto>();

			if (this.id.isEmpty() == false) {
				listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdRoleInfoFilter(this.id, this.role, this.info),
						"Asset");
			}

			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.date1 = DefVal.setCustom(this.date1, dto.date1);
				this.date2 = DefVal.setCustom(this.date2, dto.date2);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.id = DefVal.setCustom(this.id, dto.id);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.geo = DefVal.setCustom(this.geo, dto.geo);
				// this.role = DefVal.setCustom(this.role, dto.role);
				// this.info = DefVal.setCustom(this.info, dto.info);
				this.unit = DefVal.setCustom(this.unit, dto.unit);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.mark = DefVal.setCustom(this.mark, dto.mark);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.unit = "";
			}
		} catch (Exception ex) {
			WB.addLog("AssetDefectCat.isExist():void, ex=" + ex.getMessage(), "", "AssetDefectCat");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 29.09.2025, last edit - 15.09.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("AssetDefectCat.getFieldFromMore():void, ex=" + ex.getMessage(), "", "AssetDefectCat");
		}
	}

	public AssetDefectCat(AssetDto aDto) throws Exception {
		// origin - 28.05.2025, last edit - 19.11.2025
		this.clear();
		this.date1 = aDto.date1;
		this.date2 = aDto.date2;
		this.code = aDto.code;
		this.id = aDto.id;
		this.description = aDto.description;
		this.geo = aDto.geo;
		this.role = aDto.role;
		this.info = aDto.info;
		this.unit = aDto.unit;
		this.more = aDto.more;
		this.mark = aDto.mark;
		this.getFieldFromMore();
		this.validate();
	}

	public AssetDefectCat(FullDto mDto) throws Exception {
		// origin - 29.09.2025, last edit - 29.09.2025
		this.clear();
		this.date1 = mDto.date1;
		this.date2 = mDto.date2;
		this.code = mDto.code;
		this.id = mDto.id;
		this.description = mDto.description;
		this.geo = mDto.geo;
		this.role = mDto.role;
		this.info = mDto.info;
		this.unit = mDto.unit;
		this.more = mDto.more;
		this.mark = mDto.mark;
		this.getFieldFromMore();
		this.validate();
	}

	public AssetDefectCat(String Id) throws Exception {
		// origin - 28.05.2025, last edit - 19.11.2025
		this.clear();
		this.src = Id + "," + "Role.Asset.Defect";
		this.id = Id;
		this.role = "Role.Asset.Defect";
		this.info = "Info.Asset.Catalog";
		this.isExist();
		this.getFieldFromMore();
		this.validate();
	}

	private void clear() throws Exception {
		// origin - 28.05.2025, last edit - 15.09.2026
		try {
			this.table = "Asset";
			this.src = this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.geo = this.role = this.info = this.unit = this.mark = this.more = "";
			this.defect = "";
			this.fullName = this.comment = "";
		} catch (Exception ex) {
			WB.addLog("AssetCat.clear():void, ex=" + ex.getMessage(), "", "AssetCat");
		}
	}

	public AssetDefectCat() throws Exception {
		// origin - 28.05.2025, last edit - 27.05.2025
		this.clear();
	}

	public String toString() {
		// origin - 28.05.2025, last edit - 15.09.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("table ", this.table);
			res = res + Fmtr.addIfNotEmpty(" src ", this.src);
			res = res + Fmtr.addIfNotEmpty(" id ", this.id);
			res = res + Fmtr.addIfNotEmpty(" parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(" date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(" date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(" code ", this.code);
			res = res + Fmtr.addIfNotEmpty(" description ", this.description);
			res = res + Fmtr.addIfNotEmpty(" ", this.geo);
			res = res + Fmtr.addIfNotEmpty(" ", this.role);
			res = res + Fmtr.addIfNotEmpty(" ", this.info);
			res = res + Fmtr.addIfNotEmpty(" ", this.unit);
			res = res + Fmtr.addIfNotEmpty(" more ", this.more);
			res = res + Fmtr.addIfNotEmpty(" defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(" fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(" comment ", this.comment);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.05.2025, last edit - 30.09.2025
		try {

//			{
//				WB.addLog2("AssetDefectCat.test.get():List<AssetDefectCat>", "", "AssetDefectCat");
//				var tmp = AssetDefectCat.get();
//				WB.addLog2("AssetDefectCat.test.get():List<AssetDefectCat>, res.size=" + tmp.size(), "",
//						"AssetDefectCat");
//				WB.log(tmp, "AssetDefectCat");
//			}

//			WB.addLog2("AssetDefectCat.test.getCommon(String):List<AssetDefectCat>", "", "AssetDefectCat");
//			for (var tmp1 : new String[] { "Asset.PS.Catalog", "Asset.PM.Catalog" }) {
//				var tmp = AssetDefectCat.getCommon(tmp1);
//				WB.addLog2("AssetDefectCat.test.getCommon(String):List<AssetDefectCat>, res.size=" + tmp.size()
//						+ ", parentId=" + tmp1, "", "AssetDefectCat");
//				WB.log(tmp, "AssetDefectCat");
//			}

//			WB.addLog2("AssetDefectCat.test.getByParent(2String):List<AssetDefectCat>", "", "AssetDefectCat");
//			for (var tmp1 : new String[] { "Asset.PS.Catalog.1", "Asset.PS.Catalog.Tralala" }) {
//				var tmp = AssetDefectCat.getByParent(tmp1, "Asset.PS.Catalog");
//				WB.addLog2("AssetDefectCat.test.getByParent(2String):List<AssetDefectCat>, res.size=" + tmp.size()
//						+ ", parentId=" + tmp1, "", "AssetDefectCat");
//				WB.log(tmp, "AssetDefectCat");
//			}

//			WB.addLog2("AssetDefectCat.test.ctor(String)", "", "AssetDefectCat");
//			for (var tmp1 : new String[] { "Asset.PS.Defect.Catalog.1", "Asset.Tralala.Catalog.1",
//					"Asset.PS.Catalog.1" }) {
//				WB.addLog2("AssetDefectCat.test.ctor(String)=" + new AssetDefectCat(tmp1), "", "AssetDefectCat");
//			}

		} catch (Exception ex) {
			WB.addLog("AssetDefectCat():void.test, ex=" + ex.getMessage(), "", "AssetDefectCat");
		}
	}
}