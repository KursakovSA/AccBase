import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public final class AssetDto {
	// origin - 25.02.2025, last edit - 10.09.2026
	// common fields
	public String id, parent, date1, date2, code, description, geo, role, info, unit, mark, more;
	// special fields
	// public String quantity, amount, fullName, comment;
	public String fullName, comment;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("AssetDto.static ctor, ex=" + ex.getMessage(), "", "AssetDto");
		}
	}

	private void fix() throws Exception { // TODO
		// origin - 02.05.2026, last edit - 02.05.2026
		try {
			this.date1 = DefVal.set(this.date1, WB.minDateSupported.toString());
			this.date2 = DefVal.set(this.date2, WB.maxDateSupported.toString());
			this.mark = DefVal.set(this.mark, "Mark.DD");
		} catch (Exception ex) {
			WB.addLog("AssetDto.fix():void, ex=" + ex.getMessage(), "", "AssetDto");
		}
	}

	public static List<AssetDto> getChrono(LocalDate calcDate, List<AssetDto> listAssetDto) throws Exception {
		// origin - 29.04.2025, last edit - 02.05.2026
		List<AssetDto> res = new ArrayList<AssetDto>();
		LocalDate currDate1;
		LocalDate currDate2;
		try {
			for (var currDto : listAssetDto) {
				currDto.fix();
				currDate1 = DateTool.getLocalDate(currDto.date1);// left border in data
				currDate2 = DateTool.getLocalDate(currDto.date2);// right border in data

				// left border hit or right border hit
				if ((Etc.strEquals(currDate1.toString(), calcDate.toString()))
						|| (Etc.strEquals(currDate2.toString(), calcDate.toString()))) {
					res.add(currDto);
					continue;
				}

				// range from left border to right border hit
				if ((currDate1.isBefore(calcDate)) && (currDate2.isAfter(calcDate))) {
					res.add(currDto);
					continue;
				}
			}
		} catch (Exception ex) {
			WB.addLog("AssetDto.getChrono(LocalDate, List<AssetDto>):List<AssetDto>, ex=" + ex.getMessage(), "",
					"AssetDto");
		}
		return res;
	}

	public static AssetDto getChrono(LocalDate calcDate, List<AssetDto> listAssetDto, String currency)
			throws Exception {
		// origin - 26.02.2025, last edit - 02.05.2026
		AssetDto res = new AssetDto();
		LocalDate currDate1;
		LocalDate currDate2;
		try {
			for (var currDto : listAssetDto) {
				currDto.fix();
				if ((currency.isEmpty() == false) && (Etc.strEquals(currDto.unit, currency) == false)) {
					continue;
				}

				currDate1 = DateTool.getLocalDate(currDto.date1);// left border in data
				currDate2 = DateTool.getLocalDate(currDto.date2);// right border in data

				// left border hit or right border hit
				if ((Etc.strEquals(currDate1.toString(), calcDate.toString()))
						|| (Etc.strEquals(currDate2.toString(), calcDate.toString()))) {
					res = currDto;
					break;
				}

				// range from left border to right border hit
				if ((currDate1.isBefore(calcDate)) && (currDate2.isAfter(calcDate))) {
					res = currDto;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("AssetDto.getChrono(LocalDate, List<AssetDto>, String):AssetDto, ex=" + ex.getMessage(), "",
					"AssetDto");
		}
		return res;
	}

	private void getFieldFromMore() throws Exception {
		// origin - 04.10.2025, last edit - 10.09.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("AssetDto.getFieldFromMore():void, ex=" + ex.getMessage(), "", "AssetDto");
		}
	}

	public AssetDto(String Id, String Parent, String Date1, String Date2, String Code, String Description, String Geo,
			String Role, String Info, String Unit, String More, String Mark) throws Exception {
		// origin - 25.02.2025, last edit - 02.05.2026
		this();
		this.id = Id;
		this.parent = Parent;
		this.date1 = Date1;
		this.date2 = Date2;
		this.code = Code;
		this.description = Description;
		this.geo = Geo;
		this.role = Role;
		this.info = Info;
		this.unit = Unit;
		this.more = More;
		this.mark = Mark;
		this.getFieldFromMore();
		this.fix();
	}

	private void clear() throws Exception {
		// origin - 25.02.2025, last edit - 10.09.2026
		try {
			this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.more = "";
			this.geo = this.role = this.info = this.unit = this.mark = this.fullName = this.comment = "";
		} catch (Exception ex) {
			WB.addLog("AssetDto.clear():void, ex=" + ex.getMessage(), "", "AssetDto");
		}
	}

	public AssetDto() throws Exception {
		// origin - 25.02.2025, last edit - 25.02.2025
		this.clear();
	}

	public String toString() {
		// origin - 25.02.2025, last edit - 10.09.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", ", this.unit);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 25.02.2025, last edit - 13.06.2025
		try {

		} catch (Exception ex) {
			WB.addLog("AssetDto.test():void, ex=" + ex.getMessage(), "", "AssetDto");
		}
	}
}