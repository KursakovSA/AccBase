import java.util.ArrayList;
import java.util.List;

public final class AssetPrice {
	// origin - 23.02.2025, last edit - 19.11.2025
	// common fields
	public String table, src, id, parent, code, description, geo, role, info, unit, mark, more, defect;
	// special fields
	public String fullName, comment;
	// special timestamp fields
	public ListVal date1, date2, quantity, amount;
	// list common + special + timestamp fields in unified val
	public List<AssetDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("AssetPrice.static ctor, ex=" + ex.getMessage(), "", "AssetPrice");
		}
	}

	// full list asset price items
	public static List<AssetDto> get(String parentId) throws Exception {
		// origin - 04.05.2025, last edit - 04.10.2025
		List<AssetDto> res = new ArrayList<AssetDto>();
		try {
			var assetPriceList = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentInfoFilter(parentId, "Info.Asset.Price"), "Asset");
			if (assetPriceList.size() != 0) {
				for (var currAssetPrice : assetPriceList) {
					var curr = new AssetPrice(currAssetPrice.parent, currAssetPrice.unit);
					for (var curr2 : curr.val) {
						var tmp1 = new AssetDto(curr2.id, curr2.parent, curr2.date1, curr2.date2, curr2.code,
								curr2.description, curr2.geo, curr2.role, curr2.info, curr2.unit, curr2.more,
								curr2.mark);
						if (tmp1.code.isEmpty() == false) {
							res.add(tmp1);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("AssetPrice.get(String):List<AssetDto>, ex=" + ex.getMessage(), "", "AssetPrice");
		}
		return res;
	}

	public static UnitVal getCurr(String date1, String parentAssetId, String unitCurrencyDescription) throws Exception {
		// origin - 01.03.2025, last edit - 04.10.2025
		UnitVal res = new UnitVal();
		try {
			String unitCurrencyCode = "Unit." + Etc.delStr(unitCurrencyDescription, "Unit.");
			var listAssetDto = new AssetPrice(parentAssetId, unitCurrencyCode).val;
			var dto = AssetDto.getChrono(DateTool.getLocalDate(date1), listAssetDto, unitCurrencyCode);
			res = new UnitVal(dto.amount, unitCurrencyCode);
		} catch (Exception ex) {
			WB.addLog("AssetPrice.get(3String):UnitVal, ex=" + ex.getMessage(), "", "AssetPrice");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 19.11.2025, last edit - 19.11.2025
		try {
		} catch (Exception ex) {
			WB.addLog("AssetPrice.validate():void, ex=" + ex.getMessage(), "", "AssetPrice");
		}
	}

	private void getVal() throws Exception {
		// origin - 25.02.2025, last edit - 04.10.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currQuantity = "";
			String currAmount = "";
			String currMore = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currQuantity = this.quantity.getByIndex(i);
				currAmount = this.amount.getByIndex(i);
				currMore = "";
				currMore = currMore + MoreVal.setPartMore("Quantity", currQuantity);
				currMore = currMore + MoreVal.setPartMore("Amount", currAmount);
				currMore = currMore + MoreVal.setPartMore("FullName", this.fullName);
				currMore = currMore + MoreVal.setPartMore("Comment", this.comment);
				var tmp = new AssetDto(this.id, this.parent, currDate1, currDate2, this.code, this.description,
						this.geo, this.role, this.info, this.unit, currMore, this.mark);
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("AssetPrice.getVal():void, ex=" + ex.getMessage(), "", "AssetPrice");
		}
	}

	private void isExist() throws Exception {
		// origin - 23.02.2025, last edit - 19.11.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleUnitFilter(this.parent, "Role.Asset.Price", this.unit), "Asset");
			if (listDto.size() != 0) {
				var currDto = listDto.getFirst();
				var tmp = new SpanDate(currDto.date1, currDto.date2);
				this.date1 = new ListVal(tmp.date1);
				this.date2 = new ListVal(tmp.date2);
				this.code = DefVal.setCustom(this.code, currDto.code);
				this.id = DefVal.setCustom(this.id, currDto.id);
				this.description = DefVal.setCustom(this.description, currDto.description);
				this.geo = DefVal.setCustom(this.geo, currDto.geo);
				this.role = DefVal.setCustom(this.role, currDto.role);
				this.info = DefVal.setCustom(this.info, currDto.info);
				this.unit = DefVal.setCustom(this.unit, currDto.unit);
				this.more = DefVal.setCustom(this.more, currDto.more);
				this.mark = DefVal.setCustom(this.mark, currDto.mark);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.unit = "";
			}
		} catch (Exception ex) {
			WB.addLog("AssetPrice.isExist():void, ex=" + ex.getMessage(), "", "AssetPrice");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 04.10.2025, last edit - 04.10.2025
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.quantity = new ListVal(MoreVal.getFieldByKey(this.more, "Quantity"), "");
			this.amount = new ListVal(MoreVal.getFieldByKey(this.more, "Amount"), "");
		} catch (Exception ex) {
			WB.addLog("AssetPrice.getFieldFromMore():void, ex=" + ex.getMessage(), "", "AssetPrice");
		}
	}

	public AssetPrice(String ParentId) throws Exception {
		// origin - 01.03.2025, last edit - 01.03.2025
		this(ParentId, Unit.currCurrency.code);
	}

	public AssetPrice(String ParentId, String UnitCode) throws Exception {
		// origin - 23.02.2025, last edit - 19.11.2025
		this();
		this.src = this.parent = ParentId;

		if (UnitCode.isEmpty() == false) {
			this.unit = UnitCode; // this is currency, ex. "Unit.KZT", "Unit.USD", etc.
		}

		if (UnitCode.isEmpty()) {
			this.unit = Unit.currCurrency.code; // this is currency, ex. "Unit.KZT", "Unit.USD", etc.
		}

		this.isExist();
		this.getVal();
		this.validate();
	}

	private void clear() throws Exception {
		// origin - 23.02.2025, last edit - 19.11.2025
		try {
			this.table = "Asset";
			this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.unit = this.mark = this.more = "";
			this.date1 = this.date2 = this.quantity = this.amount = new ListVal();
			this.fullName = this.comment = this.defect = "";
			this.val = new ArrayList<AssetDto>();
		} catch (Exception ex) {
			WB.addLog("AssetPrice.clear():void, ex=" + ex.getMessage(), "", "AssetPrice");
		}
	}

	public AssetPrice() throws Exception {
		// origin - 23.02.2025, last edit - 25.02.2025
		this.clear();
	}

	public String toString() {
		// origin - 23.02.2025, last edit - 19.11.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", ", this.unit);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", quantity ", this.quantity.id);
			res = res + Fmtr.addIfNotEmpty(", amount ", this.amount.id);
			res = res + Fmtr.addAnyway(", val.size ", this.val.size());
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 23.02.2025, last edit - 04.10.2025
		try {

//			WB.addLog2("AssetPrice.test.get(String):List<AssetDto>", "", "AssetPrice");
//			for (var tmp1 : new String[] { "Asset.Test.1" }) {
//				WB.addLog2("AssetPrice.test.get(String):List<AssetDto>, res.size=" + AssetPrice.get(tmp1).size()
//						+ ", parentId=" + tmp1, "", "AssetPrice");
//				WB.log(AssetPrice.get(tmp1), "AssetPrice");
//			}

//			WB.addLog2("AssetPrice.test.getCurr(3String):UnitVal", "", "AssetPrice");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Asset.Test.1" }) {
//					for (var tmp3 : Price.currency) {
//						WB.addLog2(
//								"AssetPrice.test.getCurr(3String):UnitVal=" + AssetPrice.getCurr(tmp1, tmp2, tmp3).id
//										+ ", date1=" + tmp1 + ", parentId=" + tmp2 + ", currency=" + tmp3,
//								"", "AssetPrice");
//					}
//				}
//			}

//			WB.addLog2("AssetPrice.test.ctor(String)", "", "AssetPrice");
//			for (var tmp1 : new String[] { "Asset.Test.1" }) {
//				var tmp2 = new AssetPrice(tmp1);
//				WB.addLog2("AssetPrice.test.ctor(String)=" + tmp2, "", "AssetPrice");
//				WB.log(tmp2.val, "AssetPrice");
//			}

		} catch (Exception ex) {
			WB.addLog("AssetPrice():void.test, ex=" + ex.getMessage(), "", "AssetPrice");
		}
	}
}