import java.util.ArrayList;
import java.util.List;

public final class AssetPrice {
	// origin - 23.02.2025, last edit - 21.10.2026
	// common fields
	public String table, src, id, parent, code, description, geo, role, info, unit, mark, more, defect;
	// special fields
	public String fullName, comment;
	// special timestamp fields
	public ListVal date1, date2, qty, amt;
	// list common + special + timestamp fields in unified val
	public List<AssetDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("AssetPrice.static ctor, ex=" + ex.getMessage(), "", "AssetPrice");
		}
	}

	private static String getCurrency(String maybeCurrencyId) throws Exception {
		// origin - 05.10.2026, last edit - 18.10.2026
		String res = "";
		try {
			if (maybeCurrencyId == null) {
				return res = Unit.currCurrency.id;
			}

			if (maybeCurrencyId.isEmpty()) {
				return res = Unit.currCurrency.id;
			}

			maybeCurrencyId = Etc.delTableNameStr(maybeCurrencyId);
			maybeCurrencyId = "Unit." + maybeCurrencyId;

			var testUnit = new Unit(maybeCurrencyId);
			if (testUnit.id.isEmpty()) {
				return res = Unit.currCurrency.id;
			}

			if (Etc.strContainsOneTime(maybeCurrencyId, Geo.getCurrency())) {
				return res = maybeCurrencyId;
			}

			res = maybeCurrencyId; // ex. currency may be "tobacco", "whiskey", etc.
		} catch (Exception ex) {
			WB.addLog("AssetPrice.getCurrency(String):String, ex=" + ex.getMessage(), "", "AssetPrice");
		}
		return res;
	}

	// for property mgmt - where geo is addresse, ex. "Geo.SaryArka.Майлина,789"
	public static UnitVal getCurrByGeo(String date1, String parentId, String geoId) throws Exception {
		// origin - 05.10.2026, last edit - 19.10.2026
		UnitVal res = new UnitVal();
		try {
			if (Etc.strNotValid(date1, parentId, geoId)) {
				return res;
			}

			List<AssetDto> listAssetDto1 = AssetPrice.getByGeo(parentId, geoId);
			var listAssetDto2 = AssetDto.getChrono(DateTool.getLocalDate(date1), listAssetDto1);
			AssetDto dto = listAssetDto2.getFirst();
			String currencyId = AssetPrice.getCurrency(dto.unit);
			var priceNumber = AssetPrice.getPriceNumber(dto.more);
			res = new UnitVal(priceNumber, currencyId);
		} catch (Exception ex) {
			WB.addLog("AssetPrice.getCurrByGeo(3String):UnitVal, ex=" + ex.getMessage(), "", "AssetPrice");
		}
		return res;
	}

	// for property mgmt - where geo is addresse, ex. "Geo.SaryArka.Майлина,789"
	private static List<AssetDto> getByGeo(String parentId, String geoId) throws Exception {
		// origin - 05.10.2026, last edit - 19.10.2026
		List<AssetDto> res = new ArrayList<AssetDto>();
		try {
			if (Etc.strNotValid(parentId, geoId)) {
				return res;
			}
			var assetPriceList = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleGeoFilter(parentId, "Role.Asset.Price", geoId), "Asset");
			for (var currAssetPrice : assetPriceList) {
				var curr = new AssetPrice(currAssetPrice.id);
				res.addAll(curr.val);
			}
		} catch (Exception ex) {
			WB.addLog("AssetPrice.getByGeo(2String):List<AssetDto>, ex=" + ex.getMessage(), "", "AssetPrice");
		}
		return res;
	}

	public static List<AssetDto> get(String parentId) throws Exception {
		// origin - 04.05.2025, last edit - 18.10.2026
		List<AssetDto> res = new ArrayList<AssetDto>();
		try {
			if (Etc.strNotValid(parentId)) {
				return res;
			}
			var assetPriceList = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleFilter(parentId, "Role.Asset.Price"), "Asset");
			for (var currAssetPrice : assetPriceList) {
				var curr = new AssetPrice(currAssetPrice.id);
				res.addAll(curr.val);
			}
		} catch (Exception ex) {
			WB.addLog("AssetPrice.get(String):List<AssetDto>, ex=" + ex.getMessage(), "", "AssetPrice");
		}
		return res;
	}

	private static String getPriceNumber(String more) throws Exception {
		// origin - 06.10.2026, last edit - 06.10.2026
		String res = "";
		try {
			var priceNumber = MoreVal.getFieldByKey(more, "Amount");
			if (priceNumber.isEmpty()) {
				priceNumber = "0.0";
			}
			return res = priceNumber;
		} catch (Exception ex) {
			WB.addLog("AssetPrice.getPriceNumber(String):String, ex=" + ex.getMessage(), "", "AssetPrice");
		}
		return res;
	}

	public static UnitVal getCurrByUnit(String date1, String parentId, String unitCurrency) throws Exception {
		// origin - 01.03.2025, last edit - 19.10.2026
		UnitVal res = new UnitVal();
		try {
			if (Etc.strNotValid(date1, parentId, unitCurrency)) {
				return res;
			}
			String currencyId = AssetPrice.getCurrency(unitCurrency); // ex. unitCurrencyCode="Unit.KZT"
			var listDto = AssetPrice.get(parentId);
			var dto = AssetDto.getChronoByUnit(DateTool.getLocalDate(date1), listDto, currencyId);
			var priceNumber = AssetPrice.getPriceNumber(dto.more);
			res = new UnitVal(priceNumber, currencyId);
		} catch (Exception ex) {
			WB.addLog("AssetPrice.getCurrByUnit(3String):UnitVal, ex=" + ex.getMessage(), "", "AssetPrice");
		}
		return res;
	}

	private void fix() throws Exception {
		// origin - 06.10.2026, last edit - 06.10.2026
		try {
			this.unit = DefVal.set(this.unit, Unit.currCurrency.id);
			this.mark = DefVal.set(this.mark, "Mark.DD");
		} catch (Exception ex) {
			WB.addLog("AssetPrice.fix():void, ex=" + ex.getMessage(), "", "AssetPrice");
		}
	}

	private void validate() throws Exception {
		// origin - 19.11.2025, last edit - 10.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}
		} catch (Exception ex) {
			WB.addLog("AssetPrice.validate():void, ex=" + ex.getMessage(), "", "AssetPrice");
		}
	}

	private void getVal() throws Exception {
		// origin - 25.02.2025, last edit - 21.10.2026
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currQty = "";
			String currAmt = "";
			String currMore = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currQty = this.qty.getByIndex(i);
				currAmt = this.amt.getByIndex(i);
				currMore = "";
				currMore = currMore + MoreVal.setPart("Qty", currQty);
				currMore = currMore + MoreVal.setPart("Amt", currAmt);
				currMore = currMore + MoreVal.setPart("FullName", this.fullName);
				currMore = currMore + MoreVal.setPart("Comment", this.comment);
				var tmp = new AssetDto(this.id, this.parent, currDate1, currDate2, this.code, this.description,
						this.geo, this.role, this.info, this.unit, currMore, this.mark);
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("AssetPrice.getVal():void, ex=" + ex.getMessage(), "", "AssetPrice");
		}
	}

	private void isExist() throws Exception {
		// origin - 23.02.2025, last edit - 07.10.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdRoleFilter(this.id, "Role.Asset.Price"), "Asset");
			if (listDto.size() != 0) {
				var currDto = listDto.getFirst();
				var tmp = new SpanDate(currDto.date1, currDto.date2);
				this.date1 = new ListVal(tmp.date1);
				this.date2 = new ListVal(tmp.date2);
				this.code = DefVal.setCustom(this.code, currDto.code);
				this.id = DefVal.setCustom(this.id, currDto.id);
				this.description = DefVal.setCustom(this.description, currDto.description);
				this.geo = DefVal.setCustom(this.geo, currDto.geo);
				this.role = DefVal.setCustom(this.role, currDto.role);
				this.info = DefVal.setCustom(this.info, currDto.info);
				this.unit = DefVal.setCustom(this.unit, currDto.unit);
				this.more = DefVal.setCustom(this.more, currDto.more);
				this.mark = DefVal.setCustom(this.mark, currDto.mark);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.clear();
			}
		} catch (Exception ex) {
			WB.addLog("AssetPrice.isExist():void, ex=" + ex.getMessage(), "", "AssetPrice");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 04.10.2025, last edit - 21.10.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.qty = new ListVal(MoreVal.getFieldByKey(this.more, "Qty"), "");
			this.amt = new ListVal(MoreVal.getFieldByKey(this.more, "Amt"), "");
		} catch (Exception ex) {
			WB.addLog("AssetPrice.getFieldFromMore():void, ex=" + ex.getMessage(), "", "AssetPrice");
		}
	}

	private AssetPrice(String Id) throws Exception {
		// origin - 07.10.2026, last edit - 07.10.2026
		this.clear();
		this.src = this.id = Id;
		this.isExist();
		this.fix();
		this.getVal();
		this.validate();
	}

	private void clear() throws Exception {
		// origin - 23.02.2025, last edit - 21.10.2026
		try {
			this.table = "Asset";
			this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.unit = this.mark = this.more = "";
			this.date1 = this.date2 = this.qty = this.amt = new ListVal();
			this.fullName = this.comment = this.defect = "";
			this.val = new ArrayList<AssetDto>();
		} catch (Exception ex) {
			WB.addLog("AssetPrice.clear():void, ex=" + ex.getMessage(), "", "AssetPrice");
		}
	}

	public AssetPrice() throws Exception {
		// origin - 23.02.2025, last edit - 25.02.2025
		this.clear();
	}

	public String toString() {
		// origin - 23.02.2025, last edit - 21.10.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("table ", this.table);
			res = res + Fmtr.addAnyway(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", ", this.unit);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", qty ", this.qty.id);
			res = res + Fmtr.addIfNotEmpty(", amt ", this.amt.id);
			res = res + Fmtr.addAnyway(", val.size ", this.val.size());
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 23.02.2025, last edit - 07.10.2025
		try {

//			WB.addLog2("AssetPrice.test.getCurrency(String):List<AssetDto>", "", "AssetPrice");
//			for (var tmp1 : new String[] { null, "", "Unit.KZT", "Unit.USD", "Unit.Kg", "KZT", "Asset.Tralala",
//					"Tralala" }) {
//				WB.addLog2("AssetPrice.test.getCurrency(String):String, res=" + AssetPrice.getCurrency(tmp1) + ", tmp1="
//						+ tmp1, "", "AssetPrice");
//			}

//			WB.addLog2("AssetPrice.test.getCurrByGeo(3String):UnitVal", "", "AssetPrice");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Asset.PM.Catalog.1.ЭР" }) {
//					for (var tmp3 : new String[] { "Geo.Qazaqstan", "Geo.SaryArka.Майлина,789" }) {
//						WB.addLog2("AssetPrice.test.getCurrByGeo(3String):UnitVal="
//								+ AssetPrice.getCurrByGeo(tmp1, tmp2, tmp3).id + ", tmp1=" + tmp1 + ", tmp2=" + tmp2
//								+ ", tmp3=" + tmp3, "", "AssetPrice");
//					}
//				}
//			}

//			WB.addLog2("AssetPrice.test.getByGeo(2String):List<AssetDto>", "", "AssetPrice");
//			for (var tmp1 : new String[] { "", "Asset.Test.1", "Asset.PM.Catalog.1.ЭР", "Asset.PM.Catalog.2.НВ" }) {
//				for (var tmp2 : new String[] { "", "Geo.Somewhere", "Geo.Qazaqstan", "Geo.SaryArka.Майлина,789" }) {
//					var tmp3 = AssetPrice.getByGeo(tmp1, tmp2);
//					WB.addLog2("AssetPrice.test.getByGeo(2String):List<AssetDto>, res.size=" + tmp3.size() + ", tmp1="
//							+ tmp1 + ", tmp2=" + tmp2, "", "AssetPrice");
//					WB.log(tmp3, "AssetPrice");
//				}
//			}

//			WB.addLog2("AssetPrice.test.get(String):List<AssetDto>", "", "AssetPrice");
//			for (var tmp1 : new String[] { "", "Asset.Test.1", "Asset.PM.Catalog.1.ЭР" }) {
//				var tmp2 = AssetPrice.get(tmp1);
//				WB.addLog2("AssetPrice.test.get(String):List<AssetDto>, res.size=" + tmp2.size() + ", tmp1=" + tmp1, "",
//						"AssetPrice");
//				WB.log(tmp2, "AssetPrice");
//			}

//			WB.addLog2("AssetPrice.test.getCurrByUnit(3String):UnitVal", "", "AssetPrice");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "", "Asset.Test.1", "Asset.PM.Catalog.1.ЭР", "Asset.PM.Catalog.2.НВ" }) {
//					for (var tmp3 : List.of("Unit.KZT", "Unit.USD")) {// Price.currency) {
//						WB.addLog2("AssetPrice.test.getCurrByUnit(3String):UnitVal="
//								+ AssetPrice.getCurrByUnit(tmp1, tmp2, tmp3).id + ", tmp1=" + tmp1 + ", tmp2=" + tmp2
//								+ ", tmp3=" + tmp3, "", "AssetPrice");
//					}
//				}
//			}

//			WB.addLog2("AssetPrice.test.ctor(String)", "", "AssetPrice");
//			for (var tmp1 : new String[] { "", "Asset.Test.1.Price.1", "Asset.Test.1.Price.2",
//					"Asset.PM.Catalog.1.ЭР.Price.Geo.SaryArka.Майлина,789", "Asset.Tralala" }) {
//				var tmp2 = new AssetPrice(tmp1);
//				WB.addLog2("AssetPrice.test.ctor(String)=" + tmp2 + ", tmp1=" + tmp1, "", "AssetPrice");
//				WB.log(tmp2.val, "AssetPrice");
//			}

		} catch (Exception ex) {
			WB.addLog("AssetPrice():void.test, ex=" + ex.getMessage(), "", "AssetPrice");
		}
	}
}