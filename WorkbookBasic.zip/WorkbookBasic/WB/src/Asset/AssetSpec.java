public final class AssetSpec {
	// origin - 30.05.2025, last edit - 12.01.2026
	public String src, src1, src2, src3, src4;
	public String color, producer, dateMFG, dateEXP;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("AssetSpec.static ctor, ex=" + ex.getMessage(), "", "AssetSpec");
		}
	}

	private void getSrc() throws Exception {
		// origin - 30.05.2025, last edit - 12.01.2026
		try {
			if (this.src.length() != 0) {
				String tmp = Etc.fixTrim(this.src); // "color, producer, dateMFG, dateEXP"

				int posSpace1 = tmp.indexOf(" ");
				if (posSpace1 > 0) {
					this.src1 = Etc.fixTrim(tmp.substring(0, posSpace1)); // "color"
					tmp = Etc.fixTrim(tmp.substring(posSpace1)); // "producer, dateMFG, dateEXP"

					int posSpace2 = tmp.indexOf(" ");
					if (posSpace2 > 0) {
						this.src2 = Etc.fixTrim(tmp.substring(0, posSpace2)); // "producer"
						tmp = Etc.fixTrim(tmp.substring(posSpace2)); // "dateMFG, dateEXP"
					} else {
						this.src2 = tmp;
						tmp = "";
					}

					int posSpace3 = tmp.indexOf(" ");
					if (posSpace3 > 0) {
						this.src3 = Etc.fixTrim(tmp.substring(0, posSpace3)); // "dateMFG"
						tmp = Etc.fixTrim(tmp.substring(posSpace3)); // "dateEXP"
					} else {
						this.src3 = tmp;
						tmp = "";
					}

					if (tmp.length() != 0) {
						this.src4 = Etc.fixTrim(tmp); // "dateEXP"
					}
				} else { // only "color"
					this.src1 = tmp;
				}
			}
		} catch (Exception ex) {
			WB.addLog("AssetSpec.getSrc():void, ex=" + ex.getMessage(), "", "AssetSpec");
		}
	}

	private void getPart() throws Exception {
		// origin - 30.05.2025, last edit - 12.01.2026
		try {
			this.color = src1;
			this.producer = src2;
			this.dateMFG = src3;
			this.dateEXP = src4;
		} catch (Exception ex) {
			WB.addLog("AssetSpec.getPart():void, ex=" + ex.getMessage(), "", "AssetSpec");
		}
	}

	public AssetSpec(String Src) throws Exception {
		// origin - 30.05.2025, last edit - 08.01.2026
		this.clear();
		this.src = Etc.fixTrim(Src); // "color, producer, dateMFG, dateEXP"
		this.getSrc();
		this.getPart();
	}

	public AssetSpec() throws Exception {
		// origin - 30.05.2025, last edit - 30.05.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 30.05.2025, last edit - 12.01.2026
		try {
			this.src = this.src1 = this.src2 = this.src3 = this.src4 = "";
			this.color = this.producer = this.dateMFG = this.dateEXP = "";
		} catch (Exception ex) {
			WB.addLog("AssetSpec.clear():void, ex=" + ex.getMessage(), "", "AssetSpec");
		}
	}

	public String toString() {
		// origin - 30.05.2025, last edit - 12.01.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway(" src ", this.src);
			res = res + Fmtr.addIfNotEmpty(" src1 ", this.src1);
			res = res + Fmtr.addIfNotEmpty(" src2 ", this.src2);
			res = res + Fmtr.addIfNotEmpty(" src3 ", this.src3);
			res = res + Fmtr.addIfNotEmpty(" src4 ", this.src4);
			res = res + Fmtr.addIfNotEmpty(" color ", this.color);
			res = res + Fmtr.addIfNotEmpty(" producer ", this.producer);
			res = res + Fmtr.addIfNotEmpty(" dateMFG ", this.dateMFG);
			res = res + Fmtr.addIfNotEmpty(" dateEXP ", this.dateEXP);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 30.05.2025, last edit - 12.01.2026
		try {

//			WB.addLog2("AssetSpec.test.ctor(String)", "", "AssetSpec");
//			for (var tmp1 : new String[] { "красный Самсунг 12.11.2005 12.11.2010", "красный Самсунг 12.11.2005",
//					"красный Самсунг", "красный" }) {
//				WB.addLog2("AssetSpec.test.ctor(String)=" + new AssetSpec(tmp1), "", "AssetSpec");
//			}

		} catch (Exception ex) {
			WB.addLog("AssetSpec.test():void, ex=" + ex.getMessage(), "", "AssetSpec");
		}
	}
}