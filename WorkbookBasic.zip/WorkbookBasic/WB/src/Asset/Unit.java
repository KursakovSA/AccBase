import java.util.ArrayList;
import java.util.List;

public class Unit {
	// origin - 28.09.2023, last edit - 30.05.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, date1, date2, code, description, role, more;
	// special fields
	public List<ModelDto> lower, upper;
	public static Unit currCurrency, minRate, minSalary;
	public static String strPiece, strMinRate, strMinSalary, strGr;
	public UnitVal weight, volume, lenght, width, height, duration;
	public String MKEIcode, expectedValue, nameCent;

	static {
		try {
			Unit.strPiece = "Unit.Piece";
			Unit.strGr = "Unit.Gr";

			Unit.strMinRate = "Unit.MinRate";
			Unit.strMinSalary = "Unit.MinSalary";

			Unit.currCurrency = new Unit(Geo.currCountry.currency);
			Unit.minRate = new Unit(Unit.strMinRate);
			Unit.minSalary = new Unit(Unit.strMinSalary);
			// WB.addLog2("Unit.currCurrency=" + Unit.currCurrency, "", "Unit");
		} catch (Exception ex) {
			WB.addLog("Unit.static ctor, ex=" + ex.getMessage(), "", "Unit");
		}
	}

	public static Unit getExpectedFromInfo(String infoSelect) throws Exception {
		// origin - 09.05.2025, last edit - 13.06.2025
		Unit res = new Unit();
		try {
			Info info = new Info(infoSelect);
			Unit unit = new Unit(info.expectedUnit);
			if (unit.code.isEmpty() == false) {
				res = unit;
			}
		} catch (Exception ex) {
			WB.addLog("Unit.getExpectedFromInfo(String infoSelect):Unit, ex=" + ex.getMessage(), "", "Unit");
		}
		return res;
	}

	private static double getTotalRatioConv(String fromCode, String toCode) throws Exception {
		// origin - 03.02.2025, last edit - 13.06.2025
		double res = 0.0;
		try {
			var tmpLinkConv = Unit.getLinkConv(fromCode, toCode);
			if (tmpLinkConv.size() != 0) {
				res = 1.0;
				for (var currRatioConv : tmpLinkConv) {
					res = Etc.multiply(res, currRatioConv);
				}
			}
		} catch (Exception ex) {
			WB.addLog("Unit.getTotalRatioConv(String fromCode, String toCode):double, ex=" + ex.getMessage(), "",
					"Unit");
		}
		return res;
	}

	private static List<Double> checkRatioConv(String currToCode, String toCode, List<Double> linkRatioConv)
			throws Exception {
		// origin - 14.02.2025, last edit - 13.06.2025
		List<Double> res = linkRatioConv;
		try {
			if (res.size() != 0) {
				if (Etc.strEquals(currToCode, toCode) == false) {
					res.clear();
				}
			}
		} catch (Exception ex) {
			WB.addLog(
					"Unit.checkRatioConv(String currToCode, String toCode, List<Double> linkRatioConv):List<Double>, ex="
							+ ex.getMessage(),
					"", "Unit");
		}
		return res;
	}

	private static List<Double> getLinkConv(String fromCode, String toCode) throws Exception {
		// origin - 03.02.2025, last edit - 13.06.2025
		List<Double> res = new ArrayList<Double>();
		try {
			double currRatioConv = 0.0;
			String currToCode = "";

			// same fromCode and toCode
			if (Etc.strEquals(fromCode, toCode)) {
				res.add(1.0);
				return res;
			}

			// toCode is next level under fromCode
			// direct
			currRatioConv = Unit.getConv(fromCode, toCode, "").val;
			if (currRatioConv != 0.0) {
				res.add(currRatioConv);
				return res;
			}
			// search reverse
			if (currRatioConv == 0.0) {
				currRatioConv = Unit.getConv(toCode, fromCode, "").val;
				if (currRatioConv != 0.0) {
					res.add(Etc.reverseRatio(currRatioConv));
					return res;
				}
			}

			List<ModelDto> tmpListUnit = DAL.getTable(WB.lastConnWork, Qry.getText(WB.lastConnWork, "Unit", ""));// WB.abcLast.unit;
			String currFromCode = fromCode;

			// search lower ratioConv
			// tmpListUnit = WB.abcLast.unit;
			currRatioConv = 0.0;
			currToCode = "";
			// currFromCode = fromCode;
			for (;;) { // endless cycle
				currRatioConv = 0.0;

				// stop if currFromCode == toCode
				if (Etc.strEquals(currFromCode, toCode)) {
					break;
				}

				// search next ratioConv
				for (var currUnitDto : tmpListUnit) {
					currRatioConv = Unit.getConv(currFromCode, currUnitDto.code, "").val;
					if (currRatioConv != 0.0) {
						res.add(currRatioConv);
						currFromCode = currUnitDto.code;
						currToCode = currUnitDto.code;
						break;
					}
				}

				// stop if in link conv no ratioConv
				if (currRatioConv == 0.0) {
					break;
				}
			}
			res = Unit.checkRatioConv(currToCode, toCode, res);

			// if lower linkConv == 0 then search upper ratioConv
			if (res.size() == 0) {
				// tmpListUnit = DAL.getTable(WB.lastConnWork, Qry.getText(WB.lastConnWork,
				// "Unit", ""));// WB.abcLast.unit;
				currRatioConv = 0.0;
				currFromCode = fromCode;
				currToCode = "";
				for (;;) { // endless cycle
					currRatioConv = 0.0;

					// stop if currFromCode == toCode
					if (Etc.strEquals(currFromCode, toCode)) {
						break;
					}

					// search next ratioConv
					for (var currUnitDto : tmpListUnit) {
						currRatioConv = Unit.getConv(currUnitDto.code, currFromCode, "").val;
						if (currRatioConv != 0.0) {
							res.add(Etc.reverseRatio(currRatioConv));
							currFromCode = currUnitDto.code;
							currToCode = currUnitDto.code;
							break;
						}
					}

					// stop if in link conv no ratioConv
					if (currRatioConv == 0.0) {
						break;
					}
				}
				res = Unit.checkRatioConv(currToCode, toCode, res);
			}

		} catch (Exception ex) {
			WB.addLog("Unit.getLinkConv(String fromCode, String toCode):List<Double>, ex=" + ex.getMessage(), "",
					"Unit");
		}
		return res;
	}

	private static UnitVal getConv(String fromCode, String toCode, String context) throws Exception {
		// origin - 30.01.2025, last edit - 13.06.2025
		UnitVal res = new UnitVal();
		try {
			List<ModelDto> listDto = new ArrayList<ModelDto>();

			// listDto = ReadSet.getEqualsByCode(WB.abcLast.unit, fromCode);
			listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getCodeFilter(fromCode), "Unit");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				Unit tmp = new Unit(dto.code);

				// weight, width, height -- not must be for conv, by idea

				// lenght
				if (tmp.lenght.src.isEmpty() == false) {
					if (Etc.strEquals(tmp.lenght.unit.code, toCode)) {
						UnitVal tmpUnitVal = new UnitVal(tmp.lenght.val, tmp.lenght.unit.code);
						return res = tmpUnitVal;
					}
				}

				// volume
				if (tmp.volume.src.isEmpty() == false) {
					if (Etc.strEquals(tmp.volume.unit.code, toCode)) {
						UnitVal tmpUnitVal = new UnitVal(tmp.volume.val, tmp.volume.unit.code);
						return res = tmpUnitVal;
					}
				}

				// duration
				if (tmp.duration.src.isEmpty() == false) {
					if (Etc.strEquals(tmp.duration.unit.code, toCode)) {
						UnitVal tmpUnitVal = new UnitVal(tmp.duration.val, tmp.duration.unit.code);
						return res = tmpUnitVal;
					}
				}
			}

		} catch (Exception ex) {
			WB.addLog("Unit.getConv(String fromCode, String toCode, String context):UnitVal, ex=" + ex.getMessage(), "",
					"Unit");
		}
		return res;
	}

	public static UnitVal сonv(String fromCode, String toCode, String context) throws Exception {
		// origin - 29.01.2025, last edit - 19.03.2025
		UnitVal res = new UnitVal(0.0, toCode);

		if (Etc.strEquals(fromCode, toCode)) {
			res = new UnitVal(1.0, fromCode);
			return res;
		}

		try {
//			// direct conv
//			var directLinkConv = Unit.getLinkConv(fromCode, toCode);
//			if (directLinkConv.size() != 0) {
//				res = Unit.getConv(fromCode, toCode, context);
//			}
//
//			// reverse conv
//			if (res.src.isEmpty()) {
//				var reverseLinkConv = Unit.getLinkConv(toCode, fromCode);
//				if (reverseLinkConv.size() != 0) {
//					var tmp = Unit.getConv(toCode, fromCode, context);
//					// if (tmp.val != 0.0) {
//					res = new UnitVal(Etc.reverseRatio(tmp.val), tmp.unit.code);
//					// }
//				}
//			}
//
//			// cross conv
//			if (res.src.isEmpty()) {
//				var crossLinkConv = Unit.getLinkConv(toCode, fromCode);
//				if (crossLinkConv.size() != 0) {
//					var totalRatioConv = Unit.getTotalRatioConv(toCode, fromCode);
//					// if (totalRatioConv != 0.0) {
//					res = new UnitVal(totalRatioConv, toCode);
//					// }
//				}
//			}

			var totalRatioConv = Unit.getTotalRatioConv(fromCode, toCode);
			res = new UnitVal(totalRatioConv, toCode);

		} catch (Exception ex) {
			WB.addLog("Unit.сonv(String fromCode, String toCode, String context):UnitVal, ex=" + ex.getMessage(), "",
					"Unit");
		}
		return res;
	}

	public void isExist() throws Exception {
		// origin - 17.09.2024, last edit - 13.06.2025
		try {
			// for (var currUnit : WB.abcLast.unit) {
			// if (Etc.strEquals(currUnit.id, this.id)) {
			// var tableDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id),
			// this.table);
			// for (var currDto : tableDto) {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.code), "Unit");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.code = dto.code;
				this.parent = dto.parent;
				this.description = dto.description;
				this.role = dto.role;
				this.more = dto.more;

				var listUnit = DAL.getTable(WB.lastConnWork, Qry.getText(WB.lastConnWork, "Unit", ""));
				this.upper = ModelDto.getUpper(listUnit, this.parent);
				this.lower = ModelDto.getLower(listUnit, this.code);
				// this.upper = ModelDto.getUpper(WB.abcLast.unit, this.parent);
				// this.lower = ModelDto.getLower(WB.abcLast.unit, this.code);
				// this.lower = ModelDto.getLower(this.code, "Unit");

				this.expectedValue = MoreVal.getFieldByKey(this.more, "AbcExpectedValue");
				this.MKEIcode = MoreVal.getFieldByKey(this.more, "MKEI");
				this.nameCent = MoreVal.getFieldByKey(this.more, "NameCent");
				this.weight = new UnitVal(MoreVal.getFieldByKey(this.more, "Weight"));
				this.volume = new UnitVal(MoreVal.getFieldByKey(this.more, "Volume"));
				this.lenght = new UnitVal(MoreVal.getFieldByKey(this.more, "Lenght"));
				this.width = new UnitVal(MoreVal.getFieldByKey(this.more, "Width"));
				this.height = new UnitVal(MoreVal.getFieldByKey(this.more, "Height"));
				this.duration = new UnitVal(MoreVal.getFieldByKey(this.more, "Duration"));

				this.isExist = true;
				// break;
				// }
			}
		} catch (Exception ex) {
			WB.addLog("Unit.isExist():void, ex=" + ex.getMessage(), "", "Unit");
		}
	}

	public Unit(String Id) throws Exception {
		// origin - 02.10.2024, last edit - 04.05.2025
		this.clear();
		this.table = "Unit";
		this.src = Id;
		if (Id.isEmpty() == false) {
			this.id = this.code = Id;
		}
		this.isExist();
	}

	public Unit() throws Exception {
		// origin - 05.12.2023, last edit - 19.05.2025
		this.clear();
	}

	public void clear() throws Exception {
		// origin - 25.11.2024, last edit - 13.06.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = this.getClass().getName();
			this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.role = this.more = "";
			this.weight = this.volume = this.lenght = this.width = this.height = this.duration = new UnitVal();
			this.MKEIcode = this.expectedValue = this.nameCent = "";
			this.lower = new ArrayList<ModelDto>();
			this.upper = new ArrayList<ModelDto>();
		} catch (Exception ex) {
			WB.addLog("Unit.clear():void, ex=" + ex.getMessage(), "", "Unit");
		}
	}

	public String toString() {
		// origin - 25.11.2024, last edit - 11.05.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());

			res = res + Fmtr.addAnyway(", upper ", this.upper.size());
			res = res + Fmtr.addAnyway(", lower ", this.lower.size());

			res = res + Fmtr.addIfNotEmpty(", weight ", this.weight.id);
			res = res + Fmtr.addIfNotEmpty(", volume ", this.volume.id);
			res = res + Fmtr.addIfNotEmpty(", lenght ", this.lenght.id);
			res = res + Fmtr.addIfNotEmpty(", width ", this.width.id);
			res = res + Fmtr.addIfNotEmpty(", height ", this.height.id);
			res = res + Fmtr.addIfNotEmpty(", duration ", this.duration.id);
			res = res + Fmtr.addIfNotEmpty(", MKEIcode ", this.MKEIcode);
			res = res + Fmtr.addAnyway(", expectedValue ", this.expectedValue);
			res = res + Fmtr.addIfNotEmpty(", nameCent ", this.nameCent);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 13.06.2025
		try {

//			// сonv
//			for (var tmp1 : new String[] { "Unit.Box", "Unit.Mcm", "Unit.Mm", "Unit.Cm", "Unit.Meter" }) {
//				for (var tmp2 : new String[] { "Unit.Mcm", "Unit.Mm", "Unit.Cm", "Unit.Meter" }) {
//					for (var tmp3 : new String[] { "" }) {
//						WB.addLog2("Unit.test.сonv, res=" + Unit.сonv(tmp1, tmp2, tmp3).id + ", fromCode="
//								+ tmp1 + ", toCode=" + tmp2 + ", context=" + tmp3, "", "Unit");
//					}
//				}
//			}

//			// getTotalRatioConv
//			for (var getTotalRatioConvArg1 : new String[] { "Unit.Box", "Unit.Mcm", "Unit.Mm", "Unit.Cm",
//					"Unit.Meter" }) {
//				for (var getTotalRatioConvArg2 : new String[] { "Unit.Mcm", "Unit.Mm", "Unit.Cm", "Unit.Meter" }) {
//					WB.addLog2(
//							"Unit.test.getTotalRatioConv, res="
//									+ Unit.getTotalRatioConv(getTotalRatioConvArg1, getTotalRatioConvArg2)
//									+ ", fromCode=" + getTotalRatioConvArg1 + ", toCode=" + getTotalRatioConvArg2,
//							"", "Unit");
//				}
//			}

//			// getLinkConv
//			for (var getLinkConvArg1 : new String[] { "Unit.Box", "Unit.Mcm", "Unit.Mm", "Unit.Cm", "Unit.Meter" }) {
//				for (var getLinkConvArg2 : new String[] { "Unit.Mcm", "Unit.Mm", "Unit.Cm", "Unit.Meter" }) {
//					WB.addLog2("Unit.test.getLinkConv, res=" + Unit.getLinkConv(getLinkConvArg1, getLinkConvArg2)
//							+ ", fromCode=" + getLinkConvArg1 + ", toCode=" + getLinkConvArg2, "", "Unit");
//				}
//			}

//			// ctor(String)
//			WB.addLog2("Unit.test.ctor(String)", "", "Unit");
//			for (var tmp : new String[] { "Unit.Face", "Unit.KZT", "Unit.tralala", "Unit.MainDebt", "Unit.ExactDate",
//					"Unit.Service/Login/Password", "Unit.EveryDayOnTime", "Unit.Percent", "Unit.Month" }) {
//				WB.addLog2("Unit.test.ctor(String)=" + new Unit(tmp), "", "Unit");
//				//WB.log(new Unit(tmp).upper, "Unit.upper");
//			}

//			// ctor()
//			WB.addLog2("Unit.test.ctor()", "", "Unit");
//			WB.addLog2("Unit.test.ctor()=" + new Unit(), "", "Unit");

		} catch (Exception ex) {
			WB.addLog("Unit.test():void, ex=" + ex.getMessage(), "", "Unit");
		}
	}
}