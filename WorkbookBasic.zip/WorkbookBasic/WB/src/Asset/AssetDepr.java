public final class AssetDepr {
	// origin - 01.10.2025, last edit - 12.01.2026
	public String src, src1, src2, src3;
	public String groupFixedAssetId;
	public UnitVal depreciationRate, usefulLife;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("AssetDepr.static ctor, ex=" + ex.getMessage(), "", "AssetDepr");
		}
	}

	private void getSrc() throws Exception {
		// origin - 30.05.2025, last edit - 12.01.2026
		try {
			if (this.src.length() != 0) {
				String tmp = Etc.fixTrim(this.src); // "depreciationRate, groupFixedAssetId, usefulLife"

				int posSpace1 = tmp.indexOf(" ");
				if (posSpace1 > 0) {
					this.src1 = Etc.fixTrim(tmp.substring(0, posSpace1)); // "depreciationRate"
					tmp = Etc.fixTrim(tmp.substring(posSpace1)); // "groupFixedAssetId, usefulLife"

					int posSpace2 = tmp.indexOf(" ");
					if (posSpace2 > 0) {
						this.src2 = Etc.fixTrim(tmp.substring(0, posSpace2)); // "groupFixedAssetId"
						tmp = Etc.fixTrim(tmp.substring(posSpace2)); // "usefulLife" if has
					} else {
						this.src2 = tmp;
						tmp = "";
					}

					if (tmp.length() != 0) {
						this.src3 = Etc.fixTrim(tmp); // "usefulLife" if has
					}
				} else { // only "depreciationRate"
					this.src1 = tmp;
				}
			}
		} catch (Exception ex) {
			WB.addLog("AssetDepr.getSrc():void, ex=" + ex.getMessage(), "", "AssetDepr");
		}
	}

	private void getPart() throws Exception {
		// origin - 30.05.2025, last edit - 12.01.2026
		try {
			if (this.src1.isEmpty() == false) {
				this.depreciationRate = new UnitVal(src1, "(Unit.Percent)");
			}
			this.groupFixedAssetId = src2;
			if (this.src3.isEmpty() == false) {
				this.usefulLife = new UnitVal(src3, "(Unit.Year)");
			}
		} catch (Exception ex) {
			WB.addLog("AssetDepr.getPart():void, ex=" + ex.getMessage(), "", "AssetDepr");
		}
	}

	public AssetDepr(String Src) throws Exception {
		// origin - 30.05.2025, last edit - 08.01.2026
		this.clear();
		this.src = Etc.fixTrim(Src); // "depreciationRate, groupFixedAssetId, usefulLife"
		this.getSrc();
		this.getPart();
	}

	public AssetDepr() throws Exception {
		// origin - 30.05.2025, last edit - 30.05.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 30.05.2025, last edit - 12.01.2026
		try {
			this.src = this.src1 = this.src2 = this.src3 = this.groupFixedAssetId = "";
			this.depreciationRate = new UnitVal();
			this.usefulLife = new UnitVal();
		} catch (Exception ex) {
			WB.addLog("AssetDepr.clear():void, ex=" + ex.getMessage(), "", "AssetDepr");
		}
	}

	public String toString() {
		// origin - 30.05.2025, last edit - 12.01.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway(" src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", src1 ", this.src1);
			res = res + Fmtr.addIfNotEmpty(", src2 ", this.src2);
			res = res + Fmtr.addIfNotEmpty(", src3 ", this.src3);
			res = res + Fmtr.addIfNotEmpty(", depreciationRate ", this.depreciationRate.id);
			res = res + Fmtr.addIfNotEmpty(", groupFixedAssetId ", this.groupFixedAssetId);
			res = res + Fmtr.addIfNotEmpty(", usefulLife ", this.usefulLife.id);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 30.05.2025, last edit - 12.01.2026
		try {

//			WB.addLog2("AssetDepr.test.ctor(String)", "", "AssetDepr");
//			for (var tmp1 : new String[] { "12 2 24", "12 2", "12" }) {
//				WB.addLog2("AssetDepr.test.ctor(String)=" + new AssetDepr(tmp1), "", "AssetDepr");
//			}

		} catch (Exception ex) {
			WB.addLog("AssetDepr.test():void, ex=" + ex.getMessage(), "", "AssetDepr");
		}
	}
}