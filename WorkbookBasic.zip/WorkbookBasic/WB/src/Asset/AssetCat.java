import java.util.ArrayList;
import java.util.List;

public final class AssetCat {
	// origin - 27.05.2025, last edit - 12.01.2026
	// common fields
	public String table, src, id, parent, date1, date2, code, description, geo, role, info, unit, mark, more, defect;
	// special fields
	public String assetCatId;
	public AssetCodeId codeId; // one part codes of asset in cat
	public String fullName, comment;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("AssetCat.static ctor, ex=" + ex.getMessage(), "", "AssetCat");
		}
	}

	// full list asset cat for parent
	public static List<AssetCat> get(String parentId, String role) throws Exception {
		// origin - 27.05.2025, last edit - 04.01.2026
		List<AssetCat> res = new ArrayList<AssetCat>();
		try {
//			var assetList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentInfoFilter(parentId, Info.assetCatalog),
//					"Asset");
			var asset = new Asset(parentId);
			var assetList = asset.lowerList;
			if (assetList.size() != 0) {
				for (var curr : assetList) {
					if ((curr.id.isEmpty() == false) & (Etc.strEquals(curr.role, role))) {
						var tmp = new AssetCat(new AssetDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code,
								curr.description, curr.geo, curr.role, curr.info, curr.unit, curr.more, curr.mark));
						res.add(tmp);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("AssetCat.get(2String):List<AssetCat>, ex=" + ex.getMessage(), "", "AssetCat");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 19.11.2025, last edit - 23.05.2026
		try {
			this.defect = Fmtr.addIfStrEmpty(this.defect, this.assetCatId, "empty assetCatId; ");
		} catch (Exception ex) {
			WB.addLog("AssetCat.validate():void, ex=" + ex.getMessage(), "", "AssetCat");
		}
	}

	private void isExist() throws Exception {
		// origin - 27.05.2025, last edit - 19.11.2025
		try {
			List<FullDto> listDto = new ArrayList<FullDto>();

			if (this.id.isEmpty() == false) {
				listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdRoleInfoFilter(this.id, this.role, this.info),
						"Asset");
			}

			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.date1 = DefVal.setCustom(this.date1, dto.date1);
				this.date2 = DefVal.setCustom(this.date2, dto.date2);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.id = DefVal.setCustom(this.id, dto.id);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.geo = DefVal.setCustom(this.geo, dto.geo);
				this.role = DefVal.setCustom(this.role, dto.role);
				this.info = DefVal.setCustom(this.info, dto.info);
				this.unit = DefVal.setCustom(this.unit, dto.unit);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.mark = DefVal.setCustom(this.mark, dto.mark);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.unit = "";
			}
		} catch (Exception ex) {
			WB.addLog("AssetCat.isExist():void, ex=" + ex.getMessage(), "", "AssetCat");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 11.08.2025, last edit - 12.01.2026
		try {
			this.assetCatId = MoreVal.getFieldByKey(this.more, "AssetCatId");
			this.codeId = new AssetCodeId(MoreVal.getFieldByKey(this.more, "CodeId"));
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("AssetCat.getFieldFromMore():void, ex=" + ex.getMessage(), "", "AssetCat");
		}
	}

	public AssetCat(AssetDto aDto) throws Exception {
		// origin - 27.05.2025, last edit - 19.11.2025
		this.clear();
		this.date1 = aDto.date1;
		this.date2 = aDto.date2;
		this.code = aDto.code;
		this.id = aDto.id;
		this.description = aDto.description;
		this.geo = aDto.geo;
		this.role = aDto.role;
		this.info = aDto.info;
		this.unit = aDto.unit;
		this.more = aDto.more;
		this.mark = aDto.mark;
		this.getFieldFromMore();
		this.validate();
	}

	public AssetCat(String Id, String Role) throws Exception {
		// origin - 27.05.2025, last edit - 19.11.2025
		this.clear();
		this.src = Id + "," + Role;
		this.id = Id;
		this.role = Role;
		this.info = "Info.Asset.Catalog";
		this.isExist();
		this.validate();
	}

	private void clear() throws Exception {
		// origin - 27.05.2025, last edit - 12.01.2026
		try {
			this.table = "Asset";
			this.src = this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.geo = this.role = this.info = this.unit = this.mark = this.more = "";
			this.assetCatId = this.defect = "";
			this.codeId = new AssetCodeId();
			this.fullName = this.comment = "";
		} catch (Exception ex) {
			WB.addLog("AssetCat.clear():void, ex=" + ex.getMessage(), "", "AssetCat");
		}
	}

	public AssetCat() throws Exception {
		// origin - 27.05.2025, last edit - 27.05.2025
		this.clear();
	}

	public String toString() {
		// origin - 27.05.2025, last edit - 12.01.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("table ", this.table);
			res = res + Fmtr.addIfNotEmpty(" src ", this.src);
			res = res + Fmtr.addIfNotEmpty(" id ", this.id);
			res = res + Fmtr.addIfNotEmpty(" parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(" date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(" date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(" code ", this.code);
			res = res + Fmtr.addIfNotEmpty(" description ", this.description);
			res = res + Fmtr.addIfNotEmpty(" ", this.geo);
			res = res + Fmtr.addIfNotEmpty(" ", this.role);
			res = res + Fmtr.addIfNotEmpty(" ", this.info);
			res = res + Fmtr.addIfNotEmpty(" ", this.unit);
			res = res + Fmtr.addIfNotEmpty(" more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(" defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(" assetCatId ", this.assetCatId);
			res = res + Fmtr.addIfNotEmpty(" codeId ", this.codeId);
			res = res + Fmtr.addIfNotEmpty(" fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(" comment ", this.comment);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 27.05.2025, last edit - 11.08.2025
		try {

//			// test get(List<AssetCat>)
//			WB.addLog2("AssetCat.test.get(List<AssetCat>)", "", "AssetCat");
//			for (var tmp1 : new String[] { "Asset.PM.Catalog", "Asset.PS.Catalog" }) {
//				for (var tmp2 : new String[] { "Role.Asset.Service", "Role.Asset.Jewel" }) {
//					var tmp = AssetCat.get(tmp1, tmp2);
//					WB.addLog2("AssetCat.test.get(List<AssetCat>), res.size=" + tmp.size() + ", parentId=" + tmp1
//							+ ", role=" + tmp2, "", "AssetCat");
//					WB.log(tmp, "AssetCat");
//				}
//			}

//			// test ctor (2String)
//			WB.addLog2("AssetCat.test.ctor(String,String)", "", "AssetCat");
//			for (var tmp1 : new String[] { "Asset.PM.Catalog.1", "Asset.Tralala.Catalog.1",
//					"Asset.PS.Catalog.1.2" }) {
//				for (var tmp2 : new String[] { "Role.Asset.Service", "Role.Asset.Jewel", "Asset.PS.Catalog.1.2" }) {
//					WB.addLog2("AssetCat.test.ctor(2String)=" + new AssetCat(tmp1, tmp2), "", "AssetCat");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("AssetCat.test():void, ex=" + ex.getMessage(), "", "AssetCat");
		}
	}
}