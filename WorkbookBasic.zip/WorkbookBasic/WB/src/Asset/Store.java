import java.util.ArrayList;
import java.util.List;

public final class Store {
	// origin - 27.04.2025, last edit - 21.11.2025
	// common fields
	public String table, src, id, parent, code, description, geo, role, info, mark, more, defect;
	// special fields
	public String storeId, fullName, comment;
	// special timestamp fields
	public ListVal date1, date2, jobCycle;
	// list common + special + timestamp fields in unified val
	public List<FaceDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Store.static ctor, ex=" + ex.getMessage(), "", "Store");
		}
	}

	// full list store
	public static List<FaceDto> get() throws Exception {
		// origin - 26.10.2025, last edit - 26.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceByRole = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter("Role.Store.Basic"), "Face");
			if (faceByRole.size() != 0) {
				for (var currFace : faceByRole) {
					for (var curr : new Store(currFace.parent, currFace.code).val) {
						if (curr.id.isEmpty() == false) {
							res.add(curr);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Store.get():List<FaceDto>, ex=" + ex.getMessage(), "", "Store");
		}
		return res;
	}

	// full list store
	public static List<FaceDto> get(String parentId) throws Exception {
		// origin - 04.05.2025, last edit - 26.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceByParentRole = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleFilter(parentId, "Role.Store.Basic"), "Face");
			if (faceByParentRole.size() != 0) {
				for (var currFace : faceByParentRole) {
					for (var curr : new Store(currFace.parent, currFace.code).val) {
						if (curr.id.isEmpty() == false) {
							res.add(curr);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Store.get(String):List<FaceDto>, ex=" + ex.getMessage(), "", "Store");
		}
		return res;
	}

	// full list store on date1
	public static List<FaceDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 27.04.2025, last edit - 26.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceByParentRole = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleFilter(parentId, "Role.Store.Basic"), "Face");
			if (faceByParentRole.size() != 0) {
				for (var currFace : faceByParentRole) {
					var currFaceStore = new Store(currFace.parent, currFace.code);
					var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceStore.val, "");
					if (curr.id.isEmpty() == false) {
						res.add(curr);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Store.getCurr(2String):List<FaceDto>, ex=" + ex.getMessage(), "", "Store");
		}
		return res;
	}

	// item store on date1
	public static FaceDto getCurr(String date1, String faceParentId, String faceStoreId) throws Exception {
		// origin - 27.04.2025, last edit - 26.10.2025
		FaceDto res = new FaceDto();
		try {
			var currFaceStore = new Store(faceParentId, faceStoreId);
			if (currFaceStore.val.size() != 0) {
				var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceStore.val, "");
				if (curr.id.isEmpty() == false) {
					res = curr;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Store.getCurr(3String):FaceDto, ex=" + ex.getMessage(), "", "Store");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 21.11.2025, last edit - 21.11.2025
		try {
		} catch (Exception ex) {
			WB.addLog("Store.validate():void, ex=" + ex.getMessage(), "", "Store");
		}
	}

	private void getVal() throws Exception {
		// origin - 27.04.2025, last edit - 04.10.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currJobCycle = "";
			String currMore = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currJobCycle = this.jobCycle.getByIndex(i);
				currMore = "";
				currMore = currMore + MoreVal.setPartMore("StoreId", this.storeId);
				currMore = currMore + MoreVal.setPartMore("JobCycle", currJobCycle);
				currMore = currMore + MoreVal.setPartMore("FullName", this.fullName);
				currMore = currMore + MoreVal.setPartMore("Comment", this.comment);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description, this.geo,
						this.role, this.info, currMore, this.mark);
//				tmp.storeId = this.storeId;
//				tmp.jobCycle = new JobCycle(currJobCycle);
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("Store.getVal():void, ex=" + ex.getMessage(), "", "Store");
		}
	}

	private void isExist() throws Exception {
		// origin - 27.04.2025, last edit - 21.11.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentCodeRoleFilter(this.parent, this.code, "Role.Store.Basic"), "Face");
			if (listDto.size() != 0) {
				var currDto = listDto.getFirst();
				var tmp = new SpanDate(currDto.date1, currDto.date2);
				this.date1 = new ListVal(tmp.date1);
				this.date2 = new ListVal(tmp.date2);
				this.id = DefVal.setCustom(this.id, currDto.id);
				this.parent = DefVal.setCustom(this.parent, currDto.parent);
				this.code = DefVal.setCustom(this.code, currDto.code);
				this.description = DefVal.setCustom(this.description, currDto.description);
				this.geo = DefVal.setCustom(this.geo, currDto.geo);
				this.role = DefVal.setCustom(this.role, currDto.role);
				this.info = DefVal.setCustom(this.info, currDto.info);
				this.more = DefVal.setCustom(this.more, currDto.more);
				this.mark = DefVal.setCustom(this.mark, currDto.mark);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("Store.isExist():void, ex=" + ex.getMessage(), "", "Store");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 04.10.2025, last edit - 04.10.2025
		try {
			this.storeId = MoreVal.getFieldByKey(this.more, "StoreId");
			this.jobCycle = new ListVal(MoreVal.getFieldByKey(this.more, "JobCycle"), "");
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("Store.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Store");
		}
	}

	public Store(String ParentId, String StoreId) throws Exception {
		// origin - 27.04.2025, last edit - 21.11.2025
		this.clear();
		this.src = ParentId + "," + StoreId;
		this.parent = ParentId;
		this.code = StoreId;
		this.isExist();
		this.getVal();
		this.validate();
	}

	private void clear() throws Exception {
		// origin - 27.04.2025, last edit - 21.11.2025
		try {
			this.table = "Face";
			this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.more = this.mark = "";
			this.storeId = this.fullName = this.comment = this.defect = "";
			this.date1 = this.date2 = this.jobCycle = new ListVal();
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("Store.clear():void, ex=" + ex.getMessage(), "", "Store");
		}
	}

	public Store() throws Exception {
		// origin - 27.04.2025, last edit - 27.04.2025
		this.clear();
	}

	public String toString() {
		// origin - 27.04.2025, last edit - 21.11.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", storeId ", this.storeId);
			res = res + Fmtr.addIfNotEmpty(", jobCycle ", this.jobCycle.id);
			res = res + Fmtr.addIfNotEmpty(", store.val.size ", this.val.size());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 27.04.2025, last edit - 24.08.2026
		try {

//			WB.addLog2("Store.test.get():List<FaceDto>", "", "Store");
//			var tmp = Store.get();
//			WB.addLog2("Store.test.get():List<FaceDto>, res.size=" + tmp.size(), "", "Store");
//			WB.log(tmp, "Store");

//			WB.addLog2("Store.test.get(String):List<FaceDto>", "", "Store");
//			for (var tmp1 : new String[] { "Face.FA1", "Face.Tralala" }) {
//				var tmp2 = Store.get(tmp1);
//				WB.addLog2("Store.test.get(String):List<FaceDto>, res.size=" + tmp2.size() + ", parentId=" + tmp1, "",
//						"Store");
//				WB.log(tmp2, "Store");
//			}

//			WB.addLog2("Store.test.getCurr(2String):List<FaceDto>", "", "Store");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-01", "2025-01-31", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1", "Face.Tralala" }) {
//					var tmp3 = Store.getCurr(tmp1, tmp2);
//					WB.addLog2("Store.test.getCurr(2String):List<FaceDto>, res.size=" + tmp3.size() + ", date1=" + tmp1
//							+ ", parentId=" + tmp2, "", "Store");
//					WB.log(tmp3, "Store");
//				}
//			}

//			WB.addLog2("Store.test.getCurr(3String):FaceDto", "", "Store");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-01", "2025-01-31", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1 , Face.FA1.Store1", "Face.Tralala , Face.Tralala.Store1" }) {
//					var tmp3 = new NVal(tmp2);
//					WB.addLog2("Store.test.getCurr(3String):FaceDto, res=" + Store.getCurr(tmp1, tmp3.getVal(1), tmp3.getVal(2)) + ", date1="
//							+ tmp1 + ", faceParentId=" + tmp3.getVal(1) + ", faceStoreId=" + tmp3.getVal(2), "", "Store");
//				}
//			}

//			WB.addLog2("Store.test.ctor(2String)", "", "Store");
//			for (var tmp1 : new String[] { "Face.FA1 , Face.FA1.Store1", "Face.Tralala , Face.Tralala.Store1" }) {
//				var tmp2 = new NVal(tmp1);
//				WB.addLog2("Store.test.ctor(2String)=" + new Store(tmp2.getVal(1), tmp2.getVal(2)), "", "Store");
//			}

		} catch (Exception ex) {
			WB.addLog("Store.test():void, ex=" + ex.getMessage(), "", "Store");
		}
	}
}