import java.util.ArrayList;
import java.util.List;

public final class Asset {
	// origin - 28.09.2023, last edit - 19.11.2025
	// common fields
	public String table, src, id, parent, date1, date2, code, description, geo, role, info, unit, more, mark, defect;
	// special fields
	public String fullName, comment, templateId, termId;
	public List<AssetDto> subAsset, price, part;
	public List<ModelDto> lower, upper;
	public AssetReg reg;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Asset.static ctor, ex=" + ex.getMessage(), "", "Asset");
		}
	}

	private void validate() throws Exception { // TODO
		// origin - 19.11.2025, last edit - 19.11.2025
		try {
			if (this.termId.isEmpty()) {
				this.defect = this.defect + "empty termId; ";
			}
			if (this.templateId.isEmpty()) {
				this.defect = this.defect + "empty templateId; ";
			}
		} catch (Exception ex) {
			WB.addLog("Asset.validate():void, ex=" + ex.getMessage(), "", "Asset");
		}
	}

	public void getByTemplate() throws Exception {
		// origin - 18.05.2025, last edit - 15.09.2025
		try {
			this.id = new IdGen("", "").id;
			this.date1 = DateTool.getNow().toString();
			this.date2 = "";
			this.code = "";
			this.description = "";
			this.more = this.getMoreFromField();
			this.mark = "Mark.DD";
			this.part.clear();
			this.price.clear();
			this.subAsset.clear();
		} catch (Exception ex) {
			WB.addLog2("Asset.getByTemplate():void, ex=" + ex.getMessage(), "", "Asset");
		}
	}

	private void isExist() throws Exception {
		// origin - 30.12.2024, last edit - 19.11.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), "Asset");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.date1 = DefVal.setCustom(this.date1, dto.date1);
				this.date2 = DefVal.setCustom(this.date2, dto.date2);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.code = DefVal.setCustom(this.code, dto.id);
				this.parent = DefVal.setCustom(this.parent, dto.parent);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.geo = DefVal.setCustom(this.geo, dto.geo);
				this.role = DefVal.setCustom(this.role, dto.role);
				this.info = DefVal.setCustom(this.info, dto.info);
				this.unit = DefVal.setCustom(this.unit, dto.unit);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.mark = DefVal.setCustom(this.mark, dto.mark);
				var listDto2 = DAL.getTable(WB.lastConnWork, Qry.getText(WB.lastConnWork, "Asset", ""));
				this.upper = ModelDto.getUpper(listDto2, this.parent);
				this.lower = ModelDto.getLower(listDto2, this.code);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.unit = "";
			}
		} catch (Exception ex) {
			WB.addLog("Asset.isExist():void, ex=" + ex.getMessage(), "", "Asset");
		}
	}

	private String getMoreFromField() throws Exception {
		// origin - 18.05.2025, last edit - 01.10.2025
		String res = "";
		try {
			res = res + MoreVal.setPartMore("TemplateId", this.templateId);
			res = res + MoreVal.setPartMore("TermId", this.termId);
			res = res + MoreVal.setPartMore("FullName", this.fullName);
			res = res + MoreVal.setPartMore("Comment", this.comment);
		} catch (Exception ex) {
			WB.addLog("Asset.getMoreFromField():String, ex=" + ex.getMessage(), "", "Asset");
		}
		return res;
	}

	private void getFieldFromMore() throws Exception {
		// origin - 18.05.2025, last edit - 01.10.2025
		try {
			this.templateId = MoreVal.getFieldByKey(this.more, "TemplateId");
			this.termId = MoreVal.getFieldByKey(this.more, "TermId");
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("Asset.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Asset");
		}
	}

	private void getPart() throws Exception {
		// origin - 13.05.2025, last edit - 01.10.2025
		try {
			if (this.id.isEmpty() == false) {
				this.part = AssetPart.get(this.id);
				this.price = AssetPrice.get(this.id);
				this.subAsset = SubAsset.get(this.id);
				this.reg = new AssetReg(this.id);
			}
		} catch (Exception ex) {
			WB.addLog("Asset.getPart():void, ex=" + ex.getMessage(), "", "Asset");
		}
	}

	public Asset(String Id) throws Exception {
		// origin - 05.12.2023, last edit - 19.11.2025
		this.clear();
		this.src = this.id = Id;
		this.isExist();
		this.getPart();
		if (this.templateId.isEmpty() == false) {
			this.getByTemplate();
		}
		this.validate();
	}

	public Asset() throws Exception {
		// origin - 05.12.2023, last edit - 19.05.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 29.12.2024, last edit - 19.11.2025
		try {
			this.table = "Asset";
			this.src = this.table = this.id = this.parent = this.date1 = this.date2 = this.code = this.description = "";
			this.geo = this.role = this.info = this.unit = this.more = this.mark = this.defect = "";
			this.lower = new ArrayList<ModelDto>();
			this.upper = new ArrayList<ModelDto>();
			this.fullName = this.comment = this.templateId = this.termId = "";
			this.subAsset = new ArrayList<AssetDto>();
			this.price = new ArrayList<AssetDto>();
			this.part = new ArrayList<AssetDto>();
			this.reg = new AssetReg();
		} catch (Exception ex) {
			WB.addLog("Asset.clear():void, ex=" + ex.getMessage(), "", "Asset");
		}
	}

	public String toString() {
		// origin - 30.12.2024, last edit - 19.11.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(" id ", this.id);
			res = res + Fmtr.addIfNotEmpty(" parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(" date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(" date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(" code ", this.code);
			res = res + Fmtr.addIfNotEmpty(" description ", this.description);
			res = res + Fmtr.addIfNotEmpty(" ", this.geo);
			res = res + Fmtr.addIfNotEmpty(" ", this.role);
			res = res + Fmtr.addIfNotEmpty(" ", this.info);
			res = res + Fmtr.addIfNotEmpty(" ", this.unit);
			res = res + Fmtr.addIfNotEmpty(" more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(" defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(" ", this.mark);
			res = res + Fmtr.addIfNotEmpty(" templateId ", this.templateId);
			res = res + Fmtr.addIfNotEmpty(" termId ", this.termId);
			res = res + Fmtr.addAnyway(" upper ", this.upper.size());
			res = res + Fmtr.addAnyway(" lower ", this.lower.size());
			res = res + Fmtr.addIfNotEmpty(" fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(" comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(" part ", this.part.size());
			res = res + Fmtr.addIfNotEmpty(" price ", this.price.size());
			res = res + Fmtr.addIfNotEmpty(" subAsset ", this.subAsset.size());
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 16.08.2025
		try {

//			WB.addLog2("Asset.test.ctor(String=templateId)", "", "Asset");
//			for (var tmp1 : new String[] { "Asset.Service.Template", "Asset.Money" }) {
//				WB.addLog2("Asset.test.ctor(String=templateId)=" + new Asset(tmp1), "", "Asset");
//			}

//			WB.addLog2("Asset.test.ctor(String)", "", "Asset");
//			for (var tmp1 : new String[] { "Asset.Good.Template", "Asset.tralala", "Asset.Test.1" }) {
//				WB.addLog2("Asset.test.ctor(String)=" + new Asset(tmp1), "", "Asset");
//			}

		} catch (Exception ex) {
			WB.addLog("Asset.test():void, ex=" + ex.getMessage(), "", "Asset");
		}
	}
}