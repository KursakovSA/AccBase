import java.util.ArrayList;
import java.util.List;

public final class Asset {
	// origin - 28.09.2023, last edit - 17.09.2026
	// common fields
	public String table, src, id, parent, date1, date2, code, description, geo, role, info, unit, more, mark, defect;
	// special fields
	public String fullName, comment;
	public List<AssetDto> subAssetList, priceList, partList;
	public List<FullDto> lowerList, upperList;
	public AssetCodeId codeId; // part codes of asset in asset (other in cat)
	public AssetDepr depr;
	public AssetSpec spec;
	public AssetCondition condition;
	public static List<String> nameList;
	public static List<String> dimList;

	static {
		try {
			Asset.nameList = List.of("TemplateId", "TermId");
			Asset.dimList = Dim.nameList;
		} catch (Exception ex) {
			WB.addLog("Asset.static ctor, ex=" + ex.getMessage(), "", "Asset");
		}
	}

	private void fix() throws Exception { // TODO
		// origin - 01.05.2026, last edit - 01.05.2026
		try {
			this.date1 = DefVal.set(this.date1, WB.minDateSupported.toString());
			this.date2 = DefVal.set(this.date2, WB.maxDateSupported.toString());
			this.mark = DefVal.set(this.mark, "Mark.DD");
		} catch (Exception ex) {
			WB.addLog("Asset.fix():void, ex=" + ex.getMessage(), "", "Asset");
		}
	}

	public static FullDto getFullDtoByList(List<String> in) throws Exception {
		// origin - 02.03.2026, last edit - 02.03.2026
		FullDto res = new FullDto();
		try {
			res.table = "Asset";
			res.id = Etc.fixTrim(in.get(0));
			res.parent = Etc.fixTrim(in.get(1));
			res.date1 = Etc.fixTrim(in.get(2));
			res.date2 = Etc.fixTrim(in.get(3));
			res.code = Etc.fixTrim(in.get(4));
			res.description = Etc.fixTrim(in.get(5));
			res.geo = Etc.fixTrim(in.get(6));
			res.role = Etc.fixTrim(in.get(7));
			res.info = Etc.fixTrim(in.get(8));
			res.unit = Etc.fixTrim(in.get(9));
			res.more = Etc.fixTrim(in.get(10));
			res.mark = Etc.fixTrim(in.get(11));
		} catch (Exception ex) {
			WB.addLog("Asset.getFullDtoByList(List<String>):FullDto, ex=" + ex.getMessage(), "", "Asset");
		}
		return res;
	}

	public static List<String> getListByFullDto(FullDto in) throws Exception {
		// origin - 31.01.2026, last edit - 01.03.2026
		List<String> res = new ArrayList<String>();
		try {
			res.add(in.id);
			res.add(in.parent);
			res.add(in.date1);
			res.add(in.date2);
			res.add(in.code);
			res.add(in.description);
			res.add(in.geo);
			res.add(in.role);
			res.add(in.info);
			res.add(in.unit);
			res.add(in.more);
			res.add(in.mark);
		} catch (Exception ex) {
			WB.addLog("Asset.getByTable(FullDto):List<String>, ex=" + ex.getMessage(), "", "Asset");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 19.11.2025, last edit - 15.09.2026
		try {
			this.defect = Fmtr.addIfStrEmpty(this.defect, MoreVal.getFieldByKey(this.more, "TermId"), "empty termId; ");
			this.defect = Fmtr.addIfStrEmpty(this.defect, MoreVal.getFieldByKey(this.more, "TemplateId"),
					"empty templateId; ");
		} catch (Exception ex) {
			WB.addLog("Asset.validate():void, ex=" + ex.getMessage(), "", "Asset");
		}
	}

	public void getByTemplate() throws Exception {
		// origin - 18.05.2025, last edit - 21.12.2025
		try {
			this.id = new IdGen("", "").id;
			this.date1 = DateTool.getNow().toString();
			this.date2 = "";
			this.code = "";
			this.description = "";
			this.more = this.getMoreFromField();
			this.mark = "Mark.DD";
			this.partList.clear();
			this.priceList.clear();
			this.subAssetList.clear();
		} catch (Exception ex) {
			WB.addLog2("Asset.getByTemplate():void, ex=" + ex.getMessage(), "", "Asset");
		}
	}

	private void isExist() throws Exception {
		// origin - 30.12.2024, last edit - 15.09.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), "Asset");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.date1 = DefVal.setCustom(this.date1, dto.date1);
				this.date2 = DefVal.setCustom(this.date2, dto.date2);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.code = DefVal.setCustom(this.code, dto.id);
				this.parent = DefVal.setCustom(this.parent, dto.parent);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.geo = DefVal.setCustom(this.geo, dto.geo);
				this.role = DefVal.setCustom(this.role, dto.role);
				this.info = DefVal.setCustom(this.info, dto.info);
				this.unit = DefVal.setCustom(this.unit, dto.unit);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.mark = DefVal.setCustom(this.mark, dto.mark);
				this.upperList = FullDto.getUpper(this.table, this.parent);
				this.lowerList = FullDto.getLower(this.table, this.id);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.clear();
			}
		} catch (Exception ex) {
			WB.addLog("Asset.isExist():void, ex=" + ex.getMessage(), "", "Asset");
		}
	}

	private String getMoreFromField() throws Exception {
		// origin - 18.05.2025, last edit - 15.09.2026
		String res = "";
		try {
			res = res + MoreVal.setPart("FullName", this.fullName);
			res = res + MoreVal.setPart("Comment", this.comment);
			res = res + MoreVal.setPart("CodeId", this.codeId.src);
			res = res + MoreVal.setPart("Spec", this.spec.src);
			res = res + MoreVal.setPart("Condition", this.condition.src);
		} catch (Exception ex) {
			WB.addLog("Asset.getMoreFromField():String, ex=" + ex.getMessage(), "", "Asset");
		}
		return res;
	}

	private void getFieldFromMore() throws Exception {
		// origin - 18.05.2025, last edit - 15.09.2026
		try {
			this.codeId = new AssetCodeId(MoreVal.getFieldByKey(this.more, "CodeId"));
			this.spec = new AssetSpec(MoreVal.getFieldByKey(this.more, "Spec"));
			this.condition = new AssetCondition(MoreVal.getFieldByKey(this.more, "Condition"));
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("Asset.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Asset");
		}
	}

	private void getPart() throws Exception {
		// origin - 13.05.2025, last edit - 12.01.2026
		try {
			if (this.id.isEmpty() == false) {
				this.partList = AssetPart.get(this.id);
				this.priceList = AssetPrice.get(this.id);
				this.subAssetList = SubAsset.get(this.id);
				this.depr = new AssetDepr(this.id);
			}
		} catch (Exception ex) {
			WB.addLog("Asset.getPart():void, ex=" + ex.getMessage(), "", "Asset");
		}
	}

	public Asset(String Id) throws Exception {
		// origin - 05.12.2023, last edit - 15.09.2026
		this.clear();
		this.src = this.id = Id;
		this.isExist();
		this.getPart();
		if (MoreVal.getFieldByKey(this.more, "TemplateId").isEmpty() == false) {
			this.getByTemplate();
		}
		this.fix();
		this.validate();
	}

	public Asset() throws Exception {
		// origin - 05.12.2023, last edit - 19.05.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 29.12.2024, last edit - 15.09.2026
		try {
			this.table = "Asset";
			this.src = this.table = this.id = this.parent = this.date1 = this.date2 = this.code = this.description = "";
			this.geo = this.role = this.info = this.unit = this.more = this.mark = this.defect = "";
			this.lowerList = new ArrayList<FullDto>();
			this.upperList = new ArrayList<FullDto>();
			this.fullName = this.comment = "";
			this.subAssetList = new ArrayList<AssetDto>();
			this.priceList = new ArrayList<AssetDto>();
			this.partList = new ArrayList<AssetDto>();
			this.depr = new AssetDepr();
			this.codeId = new AssetCodeId();
			this.spec = new AssetSpec();
			this.condition = new AssetCondition();
			this.depr = new AssetDepr();
		} catch (Exception ex) {
			WB.addLog("Asset.clear():void, ex=" + ex.getMessage(), "", "Asset");
		}
	}

	public String toString() {
		// origin - 30.12.2024, last edit - 15.09.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(" id ", this.id);
			res = res + Fmtr.addIfNotEmpty(" parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(" date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(" date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(" code ", this.code);
			res = res + Fmtr.addIfNotEmpty(" description ", this.description);
			res = res + Fmtr.addIfNotEmpty(" ", this.geo);
			res = res + Fmtr.addIfNotEmpty(" ", this.role);
			res = res + Fmtr.addIfNotEmpty(" ", this.info);
			res = res + Fmtr.addIfNotEmpty(" ", this.unit);
			res = res + Fmtr.addIfNotEmpty(" more ", this.more);
			res = res + Fmtr.addIfNotEmpty(" defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(" ", this.mark);
			res = res + Fmtr.addIfNotEmpty(" codeId ", this.codeId);
			res = res + Fmtr.addIfNotEmpty(" spec ", this.spec);
			res = res + Fmtr.addIfNotEmpty(" condition ", this.condition);
			res = res + Fmtr.addIfNotEmpty(" depr ", this.depr);
			res = res + Fmtr.addAnyway(" upperList ", this.upperList.size());
			res = res + Fmtr.addAnyway(" lowerList ", this.lowerList.size());
			res = res + Fmtr.addIfNotEmpty(" fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(" comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(" partList ", this.partList.size());
			res = res + Fmtr.addIfNotEmpty(" priceList ", this.priceList.size());
			res = res + Fmtr.addIfNotEmpty(" subAssetList ", this.subAssetList.size());
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 05.03.2026
		try {

//			WB.addLog2("Asset.test.ctor(String=templateId)", "", "Asset");
//			for (var tmp1 : new String[] { "Asset.Service.Template", "Asset.Money" }) {
//				WB.addLog2("Asset.test.ctor(String=templateId)=" + new Asset(tmp1), "", "Asset");
//			}

//			WB.addLog2("Asset.test.ctor(String)", "", "Asset");
//			for (var tmp1 : new String[] { "Asset.Good.Template", "Asset.tralala", "Asset.Test.1" }) {
//				WB.addLog2("Asset.test.ctor(String)=" + new Asset(tmp1), "", "Asset");
//			}

		} catch (Exception ex) {
			WB.addLog("Asset.test():void, ex=" + ex.getMessage(), "", "Asset");
		}
	}
}