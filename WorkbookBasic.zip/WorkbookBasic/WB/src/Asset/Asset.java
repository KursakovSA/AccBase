import java.util.ArrayList;
import java.util.List;

public final class Asset {
	// origin - 28.09.2023, last edit - 24.10.2026
	// common fields
	public String table, src, id, parent, date1, date2, code, description, geo, role, info, unit, more, mark, defect;
	// special fields
	public List<AssetDto> subAssetList, priceList, partList;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Asset.static ctor, ex=" + ex.getMessage(), "", "Asset");
		}
	}
	
	public static List<FullDto> getMassReg(int countFace) throws Exception { // TODO
		// origin - 07.11.2026, last edit - 07.11.2026
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			for (int i = 1; i <= countFace; i++) {
			}
		} catch (Exception ex) {
			WB.addLog("Asset.getMassReg(int):List<FullDto>, ex=" + ex.getMessage(), "", "Asset");
		}
		return res;
	}

	private void fix() throws Exception {
		// origin - 01.05.2026, last edit - 24.10.2026
		try {
			if (Etc.strNotValid(this.id)) {
				return;
			}

			this.date1 = DefVal.set(this.date1, WB.minDateSupported.toString());
			this.date2 = DefVal.set(this.date2, WB.maxDateSupported.toString());
			this.mark = DefVal.set(this.mark, "Mark.DD");
		} catch (Exception ex) {
			WB.addLog("Asset.fix():void, ex=" + ex.getMessage(), "", "Asset");
		}
	}

	public static FullDto getFullDtoByList(List<String> in) throws Exception { //for CSV
		// origin - 02.03.2026, last edit - 02.03.2026
		FullDto res = new FullDto();
		try {
			res.table = "Asset";
			res.id = Etc.fixTrim(in.get(0));
			res.parent = Etc.fixTrim(in.get(1));
			res.date1 = Etc.fixTrim(in.get(2));
			res.date2 = Etc.fixTrim(in.get(3));
			res.code = Etc.fixTrim(in.get(4));
			res.description = Etc.fixTrim(in.get(5));
			res.geo = Etc.fixTrim(in.get(6));
			res.role = Etc.fixTrim(in.get(7));
			res.info = Etc.fixTrim(in.get(8));
			res.unit = Etc.fixTrim(in.get(9));
			res.more = Etc.fixTrim(in.get(10));
			res.mark = Etc.fixTrim(in.get(11));
		} catch (Exception ex) {
			WB.addLog("Asset.getFullDtoByList(List<String>):FullDto, ex=" + ex.getMessage(), "", "Asset");
		}
		return res;
	}

	public static List<String> getListByFullDto(FullDto in) throws Exception { //for CSV
		// origin - 31.01.2026, last edit - 01.03.2026
		List<String> res = new ArrayList<String>();
		try {
			res.add(in.id);
			res.add(in.parent);
			res.add(in.date1);
			res.add(in.date2);
			res.add(in.code);
			res.add(in.description);
			res.add(in.geo);
			res.add(in.role);
			res.add(in.info);
			res.add(in.unit);
			res.add(in.more);
			res.add(in.mark);
		} catch (Exception ex) {
			WB.addLog("Asset.getListByFullDto(FullDto):List<String>, ex=" + ex.getMessage(), "", "Asset");
		}
		return res;
	}

	private void validate() throws Exception {
		// origin - 19.11.2025, last edit - 24.10.2026
		try {
			if (Etc.strNotValid(this.id)) {
				return;
			}

			this.defect = Fmtr.addIfStrEmpty(this.defect, MoreVal.getFieldByKey(this.more, "TemplateId"),
					"empty templateId; ");
		} catch (Exception ex) {
			WB.addLog("Asset.validate():void, ex=" + ex.getMessage(), "", "Asset");
		}
	}

	public void getByTemplate() throws Exception {
		// origin - 18.05.2025, last edit - 24.10.2026
		try {
			this.id = new IdGen("", "").id;
			this.date1 = DateTool.getNow().toString();
			this.date2 = "";
			this.code = "";
			this.description = "";
			this.setMoreByTemplate();
			this.mark = "Mark.DD";
			this.partList.clear();
			this.priceList.clear();
			this.subAssetList.clear();
		} catch (Exception ex) {
			WB.addLog2("Asset.getByTemplate():void, ex=" + ex.getMessage(), "", "Asset");
		}
	}

	private void isExist() throws Exception {
		// origin - 30.12.2024, last edit - 24.10.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), "Asset");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.date1 = DefVal.setCustom(this.date1, dto.date1);
				this.date2 = DefVal.setCustom(this.date2, dto.date2);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.code = DefVal.setCustom(this.code, dto.id);
				this.parent = DefVal.setCustom(this.parent, dto.parent);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.geo = DefVal.setCustom(this.geo, dto.geo);
				this.role = DefVal.setCustom(this.role, dto.role);
				this.info = DefVal.setCustom(this.info, dto.info);
				this.unit = DefVal.setCustom(this.unit, dto.unit);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.mark = DefVal.setCustom(this.mark, dto.mark);
			}

			if (listDto.size() == 0) {
				this.clear();
			}
		} catch (Exception ex) {
			WB.addLog("Asset.isExist():void, ex=" + ex.getMessage(), "", "Asset");
		}
	}

	public void resetMoreByPartList(List<String> inList) throws Exception {
		// origin - 24.10.2026, last edit - 25.10.2026
		try {
			if (Etc.strNotValid(this.more)) {
				return;
			}
			var tmpMore = this.more;
			for (var curr : inList) { // inList is "FullName=килограмм" etc.
				var name = MoreVal.getNameByPart(curr);
				if (Etc.strNotContains(name, NameVar.getListByClass("Asset"))) {
					continue;
				}
				var val = MoreVal.getValueByPart(curr);
				if (Etc.strNotValid(name, val)) {
					continue;
				}
				tmpMore = MoreVal.resetPart(tmpMore, MoreVal.setPart(name, val));
			}
			this.more = tmpMore;
		} catch (Exception ex) {
			WB.addLog("Asset.resetMoreByPartList(List<String>):String, ex=" + ex.getMessage(), "", "Asset");
		}
	}

	private void setMoreByTemplate() throws Exception {
		// origin - 18.05.2025, last edit - 24.10.2026
		try {
			this.more = MoreVal.resetByVarList(this.more, NameVar.getListByClass("Asset"));
			this.more = MoreVal.resetPart(this.more, MoreVal.setPart("FullName", "?"));
		} catch (Exception ex) {
			WB.addLog("Asset.setMoreByTemplate():String, ex=" + ex.getMessage(), "", "Asset");
		}
	}

	public String getValName(String name) throws Exception {
		// origin - 23.10.2026, last edit - 24.10.2026
		String res = "";
		try {
			if (Etc.strNotValid(this.more, name)) {
				return res;
			}
			res = MoreVal.getFieldByKey(this.more, name);
		} catch (Exception ex) {
			WB.addLog("Asset.getValName(String):String, ex=" + ex.getMessage(), "", "Asset");
		}
		return res;
	}

	private void getPart() throws Exception {
		// origin - 13.05.2025, last edit - 24.10.2026
		try {
			if (Etc.strNotValid(this.id)) {
				return;
			}
			this.partList = AssetPart.get(this.id);
			this.priceList = AssetPrice.get(this.id);
			this.subAssetList = SubAsset.get(this.id);
		} catch (Exception ex) {
			WB.addLog("Asset.getPart():void, ex=" + ex.getMessage(), "", "Asset");
		}
	}

	public boolean isNew() throws Exception { // TODO
		// origin - 24.10.2026, last edit - 24.10.2026
		boolean res = false;
		try {
			if (this.id.isEmpty()) {
				return res = false;
			}

			if (this.isTemplate() == false) {
				return res = false;
			}

			var tmp = MoreVal.getFieldByKey(this.more, "TemplateId");
			if (Etc.strNotValid(tmp, this.mark)) {
				return res;
			}
			if (Etc.strEquals(this.mark, "Mark.DD")) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("Asset.isNew():boolean, ex=" + ex.getMessage(), "", "Asset");
		}
		return res;
	}

	private boolean isTemplate() throws Exception {
		// origin - 24.10.2026, last edit - 24.10.2026
		boolean res = false;
		try {
			if (this.id.isEmpty()) {
				return res = false;
			}

			var tmp = MoreVal.getFieldByKey(this.more, "TemplateId");
			if (Etc.strNotValid(tmp, this.mark)) {
				return res;
			}
			if (Etc.strEquals(this.mark, "Mark.MD")) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("Asset.isTemplate():boolean, ex=" + ex.getMessage(), "", "Asset");
		}
		return res;
	}

	public Asset(String Id) throws Exception {
		// origin - 05.12.2023, last edit - 24.10.2026
		this.clear();
		this.src = this.id = Id;
		this.isExist();
		this.getPart();
		if (this.isTemplate()) {
			this.getByTemplate();
		}
		this.fix();
		this.validate();
	}

	public Asset() throws Exception {
		// origin - 05.12.2023, last edit - 19.05.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 29.12.2024, last edit - 24.10.2026
		try {
			this.table = "Asset";
			this.src = this.table = this.id = this.parent = this.date1 = this.date2 = this.code = this.description = "";
			this.geo = this.role = this.info = this.unit = this.more = this.mark = this.defect = "";
			this.subAssetList = new ArrayList<AssetDto>();
			this.priceList = new ArrayList<AssetDto>();
			this.partList = new ArrayList<AssetDto>();
		} catch (Exception ex) {
			WB.addLog("Asset.clear():void, ex=" + ex.getMessage(), "", "Asset");
		}
	}

	public String toString() {
		// origin - 30.12.2024, last edit - 24.10.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", ", this.unit);
			res = res + Fmtr.addAnyway(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addAnyway(", part,price,subAsset=",
					this.partList.size() + "," + this.priceList.size() + "," + this.subAssetList.size());
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 25.10.2026
		try {

//			WB.addLog2("Asset.test.resetMoreByPartList(List<String>):String", "", "Asset");
//			for (var tmp1 : new String[] { "", "FullName=литр;", "FullName=килограмм;Weight=1000.00(Unit.Gr);",
//					"Weight=1000.00(Unit.Gr);FullName=килограмм;" }) {
//				for (var tmp2 : new String[] { "", "FullName=100 грамм;", "FullName=услуга;Weight=999.00(Unit.Gr);",
//						"Weight=999.00(Unit.Gr);FullName=услуга;", "MKEI=800;Lenght=1870.00(Unit.Meter);",
//						"Tralala=метр;" }) {
//					var tmp3 = List.of(tmp2.split(";"));
//					var tmp4 = new Asset("Asset.Test.1");
//					tmp4.more = tmp1;
//					tmp4.resetMoreByPartList(tmp3);
//					WB.addLog2("Asset.test.resetMoreByPartList(List<String>):String, tmp4.more=" + tmp4.more + ", tmp1="
//							+ tmp1 + ", tmp2=" + tmp2, "", "Asset");
//				}
//			}

//			WB.addLog2("Asset.test.getValName(String):String", "", "Asset");
//			for (var tmp1 : new String[] { "Asset.Service.Template", "Asset.Test.1" }) {
//				for (var tmp2 : new String[] { "TemplateId", "PassportNumber", "FullName", "PerformEvery" }) {
//					var tmp3 = new Asset(tmp1);
//					WB.addLog2("Asset.test.getValName(String):String, res=" + tmp3.getValName(tmp2) + ", tmp2=" + tmp2
//							+ ", tmp3.more=" + tmp3.more, "", "Asset");
//				}
//			}

//			WB.addLog2("Asset.test.ctor(String)", "", "Asset");
//			for (var tmp1 : new String[] { null, "", "Asset.Good.Template", "Asset.Service.Template", "Asset.tralala",
//					"Asset.Test.1" }) {
//				WB.addLog2("Asset.test.ctor(String), res=" + new Asset(tmp1) + ", tmp1=" + tmp1, "", "Asset");
//			}

		} catch (Exception ex) {
			WB.addLog("Asset.test():void, ex=" + ex.getMessage(), "", "Asset");
		}
	}
}