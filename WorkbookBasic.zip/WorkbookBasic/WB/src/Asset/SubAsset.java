import java.util.ArrayList;
import java.util.List;

public final class SubAsset {
	// origin - 01.03.2025, last edit - 02.11.2026
	// common fields
	public String table, src, id, parent, date1, date2, code, description, geo, role, info, unit, mark, more;
	// special fields
	public String qty, amt, defect;
	// special timestamp fields
	// list common + special + timestamp fields in unified val
	public static List<String> infoList;

	static {
		try {
			SubAsset.infoList = List.of("Info.Asset.SubAsset");
		} catch (Exception ex) {
			WB.addLog("SubAsset.static ctor, ex=" + ex.getMessage(), "", "SubAsset");
		}
	}

	// full list sub asset items
	public static List<AssetDto> get(String parentId) throws Exception {
		// origin - 30.04.2025, last edit - 02.11.2026
		List<AssetDto> res = new ArrayList<AssetDto>();
		try {
			if (Etc.strNotValid(parentId)) {
				return res;
			}

			var subAssetList = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentInfoFilter(parentId, SubAsset.infoList.getFirst()), "Asset");
			for (var currSubAsset : subAssetList) {
				var curr = new SubAsset(currSubAsset.parent, currSubAsset.code);
				var tmp = new AssetDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
						curr.geo, curr.role, curr.info, curr.unit, curr.more, curr.mark);
				if (tmp.code.isEmpty() == false) {
					res.add(tmp);
				}
			}
		} catch (Exception ex) {
			WB.addLog("SubAsset.get(String):List<AssetDto>, ex=" + ex.getMessage(), "", "SubAsset");
		}
		return res;
	}

	// full list sub asset items on date1
	public static List<AssetDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 30.04.2025, last edit - 02.11.2026
		List<AssetDto> res = new ArrayList<AssetDto>();
		try {
			if (Etc.strNotValid(date1, parentId)) {
				return res;
			}

			var subAssetList = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentInfoFilter(parentId, SubAsset.infoList.getFirst()), "Asset");
			for (var currSubAsset : subAssetList) {
				var curr = new SubAsset(currSubAsset.parent, currSubAsset.code);
				var tmp1 = new AssetDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
						curr.geo, curr.role, curr.info, curr.unit, curr.more, curr.mark);
				var tmp2 = AssetDto.getChronoByUnit(DateTool.getLocalDate(date1), List.of(tmp1), "");
				if (tmp2.code.isEmpty() == false) {
					res.add(tmp2);
				}
			}
		} catch (Exception ex) {
			WB.addLog("SubAsset.getCurr(2String):List<AssetDto>, ex=" + ex.getMessage(), "", "SubAsset");
		}
		return res;
	}

	// item sub asset position on date1
	public static AssetDto getCurr(String date1, String parentId, String subAssetCode) throws Exception {
		// origin - 29.04.2025, last edit - 19.10.2026
		AssetDto res = new AssetDto();
		try {
			if (Etc.strNotValid(date1, parentId, subAssetCode)) {
				return res;
			}

			var curr = new SubAsset(parentId, subAssetCode);
			var tmp1 = new AssetDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description, curr.geo,
					curr.role, curr.info, curr.unit, curr.more, curr.mark);
			var tmp2 = AssetDto.getChronoByUnit(DateTool.getLocalDate(date1), List.of(tmp1), "");
			if (tmp2.code.isEmpty() == false) {
				res = tmp2;
			}
		} catch (Exception ex) {
			WB.addLog("SubAsset.getCurr(3String):AssetDto, ex=" + ex.getMessage(), "", "SubAsset");
		}
		return res;
	}

	private void validate() throws Exception {
		// origin - 20.11.2025, last edit - 10.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}
		} catch (Exception ex) {
			WB.addLog("SubAsset.validate():void, ex=" + ex.getMessage(), "", "SubAsset");
		}
	}

	private void isExist() throws Exception {
		// origin - 01.03.2025, last edit - 02.11.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentCodeInfoFilter(this.parent, this.code, SubAsset.infoList.getFirst()), "Asset");
			if (listDto.size() != 0) {
				var currDto = listDto.getFirst();
				this.date1 = DefVal.setCustom(this.date1, currDto.date1);
				this.date2 = DefVal.setCustom(this.date2, currDto.date2);
				this.id = DefVal.setCustom(this.id, currDto.id);
				this.code = DefVal.setCustom(this.code, currDto.code);
				this.description = DefVal.setCustom(this.description, currDto.description);
				this.geo = DefVal.setCustom(this.geo, currDto.geo);
				this.role = DefVal.setCustom(this.role, currDto.role);
				this.info = DefVal.setCustom(this.info, currDto.info);
				this.unit = DefVal.setCustom(this.unit, currDto.unit);
				this.more = DefVal.setCustom(this.more, currDto.more);
				this.mark = DefVal.setCustom(this.mark, currDto.mark);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.clear();
			}
		} catch (Exception ex) {
			WB.addLog("SubAsset.isExist():void, ex=" + ex.getMessage(), "", "SubAsset");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 13.08.2025, last edit - 02.11.2026
		try {
			this.qty = MoreVal.getFieldByKey(this.more, "Qty");
			this.amt = MoreVal.getFieldByKey(this.more, "Amt");
		} catch (Exception ex) {
			WB.addLog("SubAsset.getFieldFromMore():void, ex=" + ex.getMessage(), "", "SubAsset");
		}
	}

	public SubAsset(String ParentId, String Code) throws Exception {
		// origin - 01.03.2025, last edit - 20.11.2025
		this.clear();
		this.src = ParentId + "," + Code;
		this.parent = ParentId;
		this.code = Code;
		this.isExist();
		this.validate();
	}

	private void clear() throws Exception {
		// origin - 01.03.2025, last edit - 02.11.2026
		try {
			this.table = "Asset";
			this.src = this.id = this.parent = this.geo = this.role = this.info = this.unit = this.more = this.mark = "";
			this.date1 = this.date2 = this.code = this.description = this.defect = this.qty = this.amt = "";
		} catch (Exception ex) {
			WB.addLog("SubAsset.clear():void, ex=" + ex.getMessage(), "", "SubAsset");
		}
	}

	public SubAsset() throws Exception {
		// origin - 01.03.2025, last edit - 01.03.2025
		this.clear();
	}

	public String toString() {
		// origin - 01.03.2025, last edit - 02.11.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", ", this.unit);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", qty ", this.qty);
			res = res + Fmtr.addIfNotEmpty(", amt ", this.amt);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 01.03.2025, last edit - 24.08.2026
		try {

//			WB.addLog2("SubAsset.test.get(String):List<AssetDto>", "", "SubAsset");
//			for (var tmp1 : new String[] { "Asset.Test.1", "Asset.Tralala" }) {
//				var tmp2 = SubAsset.get(tmp1);
//				WB.addLog2("SubAsset.test.get(String):List<AssetDto>, res.size=" + tmp2.size() + ", parentId=" + tmp1,
//						"", "SubAsset");
//				WB.log(tmp2, "SubAsset");
//			}

//			WB.addLog2("SubAsset.test.getCurr(2String):List<AssetDto>", "", "SubAsset");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Asset.Test.1" }) {
//					var tmp3 = SubAsset.getCurr(tmp1, tmp2);
//					WB.addLog2("SubAsset.test.getCurr(2String):List<AssetDto>, res.size=" + tmp3.size() + ", date1="
//							+ tmp1 + ", parentId=" + tmp2, "", "SubAsset");
//					WB.log(tmp3, "SubAsset");
//				}
//			}

//			WB.addLog2("SubAsset.test.getCurr(3String):AssetDto", "", "SubAsset");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Asset.Test.1 , Asset.Test.1.Sub1" }) {
//					var tmp3 = new NVal(tmp2);
//					WB.addLog2("SubAsset.test.getCurr(3String):AssetDto, res="
//							+ SubAsset.getCurr(tmp1, tmp3.getVal(1), tmp3.getVal(2)) + ", date1=" + tmp1 + ", parentId=" + tmp3.getVal(1)
//							+ ", subAssetCode=" + tmp3.getVal(2), "", "SubAsset");
//				}
//			}

//			WB.addLog2("SubAsset.test.ctor(2String)", "", "SubAsset");
//			for (var tmp1 : new String[] { "Asset.Test.1 , Asset.Test.1.Sub1", "Asset.Test.1 , Asset.Test.1.Sub2",
//					"Asset.Tralala , Asset.Tralala.Sub1" }) {
//				var tmp2 = new NVal(tmp1);
//				WB.addLog2("SubAsset.test.ctor(2String)=" + new SubAsset(tmp2.getVal(1), tmp2.getVal(2)), "", "SubAsset");
//			}

		} catch (Exception ex) {
			WB.addLog("SubAsset.test():void, ex=" + ex.getMessage(), "", "SubAsset");
		}
	}
}