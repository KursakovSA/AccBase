import java.util.ArrayList;
import java.util.List;

public class SubAsset {
	// origin - 01.03.2025, last edit - 30.04.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, date1, date2, code, description, geo, role, info, unit, mark, more;
	// special fields
	public String quantity, amount, fullName, comment;
	// special timestamp fields
	// list common + special + timestamp fields in unified val

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("SubAsset.static ctor, ex=" + ex.getMessage(), "", "SubAsset");
		}
	}

	// full list sub asset items
	public static List<AssetDto> get(String parentId) throws Exception {
		// origin - 30.04.2025, last edit - 30.04.2025
		List<AssetDto> res = new ArrayList<AssetDto>();
		try {
			var subAssetList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentInfoFilter(parentId, Info.assetSubAsset),
					"Asset");
			if (subAssetList.size() != 0) {
				for (var currSubAsset : subAssetList) {
					var curr = new SubAsset(currSubAsset.parent, currSubAsset.code);
					var tmp1 = new AssetDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
							curr.geo, curr.role, curr.info, curr.unit, curr.more, curr.mark);
					tmp1.fullName = curr.fullName;
					tmp1.comment = curr.comment;
					tmp1.quantity = curr.quantity;
					tmp1.amount = curr.amount;
					if (tmp1.code.isEmpty() == false) {
						res.add(tmp1);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("SubAsset.get(List<AssetDto>), ex=" + ex.getMessage(), "", "SubAsset");
		}
		return res;
	}

	// full list sub asset items on date1
	public static List<AssetDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 30.04.2025, last edit - 30.04.2025
		List<AssetDto> res = new ArrayList<AssetDto>();
		try {
			var subAssetList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentInfoFilter(parentId, Info.assetSubAsset),
					"Asset");
			if (subAssetList.size() != 0) {
				for (var currSubAsset : subAssetList) {
					var curr = new SubAsset(currSubAsset.parent, currSubAsset.code);
					var tmp1 = new AssetDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
							curr.geo, curr.role, curr.info, curr.unit, curr.more, curr.mark);
					tmp1.fullName = curr.fullName;
					tmp1.comment = curr.comment;
					tmp1.quantity = curr.quantity;
					tmp1.amount = curr.amount;
					var tmp2 = AssetDto.getChrono(DateTool.getLocalDate(date1), List.of(tmp1), "");
					if (tmp2.code.isEmpty() == false) {
						res.add(tmp2);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("SubAsset.getCurr(List<AssetDto>), ex=" + ex.getMessage(), "", "SubAsset");
		}
		return res;
	}

	// item sub asset position on date1
	public static AssetDto getCurr(String date1, String parentId, String subAssetCode) throws Exception {
		// origin - 29.04.2025, last edit - 30.04.2025
		AssetDto res = new AssetDto();
		try {
			var curr = new SubAsset(parentId, subAssetCode);
			var tmp1 = new AssetDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description, curr.geo,
					curr.role, curr.info, curr.unit, curr.more, curr.mark);
			tmp1.fullName = curr.fullName;
			tmp1.comment = curr.comment;
			tmp1.quantity = curr.quantity;
			tmp1.amount = curr.amount;
			var tmp2 = AssetDto.getChrono(DateTool.getLocalDate(date1), List.of(tmp1), "");
			if (tmp2.code.isEmpty() == false) {
				res = tmp2;
			}
		} catch (Exception ex) {
			WB.addLog("SubAsset.getCurr(AssetDto), ex=" + ex.getMessage(), "", "SubAsset");
		}
		return res;
	}

	public void isExist() throws Exception {
		// origin - 01.03.2025, last edit - 30.04.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentCodeInfoFilter(this.parent, this.code, Info.assetSubAsset), this.table);
			if (listDto.size() != 0) {
				for (var currDto : listDto) {
					this.date1 = DefVal.setCustom(this.date1, currDto.date1);
					this.date2 = DefVal.setCustom(this.date2, currDto.date2);

					this.id = DefVal.setCustom(this.id, currDto.id);

					this.code = DefVal.setCustom(this.code, currDto.code);
					this.description = DefVal.setCustom(this.description, currDto.description);

					this.geo = DefVal.setCustom(this.geo, currDto.geo);
					this.role = DefVal.setCustom(this.role, currDto.role);
					this.info = DefVal.setCustom(this.info, currDto.info);
					this.unit = DefVal.setCustom(this.unit, currDto.unit);
					this.more = DefVal.setCustom(this.more, currDto.more);
					this.mark = DefVal.setCustom(this.mark, currDto.mark);

					this.fullName = MoreVal.getFieldByKey(currDto.more, "FullName");
					this.comment = MoreVal.getFieldByKey(currDto.more, "Comment");
					this.quantity = MoreVal.getFieldByKey(currDto.more, "Quantity");
					this.amount = MoreVal.getFieldByKey(currDto.more, "Amount");

					this.isExist = true;
					break;
				}
			}

			if (listDto.size() == 0) {
				this.parent = this.code = "";
			}
		} catch (Exception ex) {
			WB.addLog("SubAsset.isExist, ex=" + ex.getMessage(), "", "SubAsset");
		}
	}

	public SubAsset(String ParentId, String Code) throws Exception {
		// origin - 01.03.2025, last edit - 30.04.2025
		this.clear();
		this.table = "Asset";
		this.src = ParentId + "," + Code;
		this.parent = ParentId;
		this.code = Code;
		this.isExist();
	}

	public void clear() throws Exception {
		// origin - 01.03.2025, last edit - 30.04.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = this.src = this.id = this.parent = this.geo = this.role = this.info = this.unit = this.more = this.mark = "";
			this.date1 = this.date2 = this.code = this.description = this.quantity = this.amount = "";
			this.fullName = this.comment = "";
		} catch (Exception ex) {
			WB.addLog("SubAsset.clear, ex=" + ex.getMessage(), "", "SubAsset");
		}
	}

	public SubAsset() throws Exception {
		// origin - 01.03.2025, last edit - 01.03.2025
		this.clear();
	}

	public String toString() {
		// origin - 01.03.2025, last edit - 30.04.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);

			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);

			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", ", this.unit);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);

			res = res + Fmtr.addIfNotEmpty(", quantity ", this.quantity);
			res = res + Fmtr.addIfNotEmpty(", amount ", this.amount);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 01.03.2025, last edit - 24.05.2025
		try {

//			// get(List<AssetDto>)
//			WB.addLog2("SubAsset.test.get(List<AssetDto>)", "", "SubAsset");
//			for (var tmp1 : new String[] { "Asset.Test.1" }) {
//				WB.addLog2("SubAsset.test.get(List<AssetDto>), res.size=" + SubAsset.get(tmp1).size() + ", parentId="
//						+ tmp1, "", "SubAsset");
//				WB.log(SubAsset.get(tmp1), "SubAsset");
//			}

//			// getCurr(List<AssetDto>)
//			WB.addLog2("SubAsset.test.getCurr(List<AssetDto>)", "", "SubAsset");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Asset.Test.1" }) {
//					WB.addLog2("SubAsset.test.getCurr(List<AssetDto>), res.size=" + SubAsset.getCurr(tmp1, tmp2).size()
//							+ ", date1=" + tmp1 + ", parentId=" + tmp2, "", "SubAsset");
//					WB.log(SubAsset.getCurr(tmp1, tmp2), "SubAsset");
//				}
//			}

//			// getCurr(AssetDto)
//			WB.addLog2("SubAsset.test.getCurr(AssetDto)", "", "SubAsset");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Asset.Test.1" }) {
//					for (var tmp3 : new String[] { "Asset.Test.1.Sub1" }) {
//						WB.addLog2(
//								"SubAsset.test.getCurr(AssetDto), res=" + SubAsset.getCurr(tmp1, tmp2, tmp3)
//										+ ", date1=" + tmp1 + ", parentId=" + tmp2 + ", subAssetCode=" + tmp3,
//								"", "SubAsset");
//					}
//				}
//			}

//			// ctor (String,String)
//			for (var tmp1 : new String[] { "Asset.Test.1", "Asset.Tralala" }) {
//				for (var tmp2 : new String[] { "Asset.Test.1.Sub1", "Asset.Test.1.Sub2" }) {
//					WB.addLog2("SubAsset.test.ctor(String,String)=" + new SubAsset(tmp1, tmp2), "", "SubAsset");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("SubAsset.test, ex=" + ex.getMessage(), "", "SubAsset");
		}
	}
}