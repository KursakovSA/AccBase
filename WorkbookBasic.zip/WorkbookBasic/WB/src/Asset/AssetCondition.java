public class AssetCondition {
	// origin - 24.12.2025, last edit - 12.01.2026
	public String src, src1, src2;
	public String code, description;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("AssetCondition.static ctor, ex=" + ex.getMessage(), "", "AssetCondition");
		}
	}

	private void getSrc() throws Exception {
		// origin - 24.12.2025, last edit - 12.01.2026
		try {
			if (this.src.length() != 0) {
				String tmp = Etc.fixTrim(this.src); // "code, description"
				this.src1 = tmp;

				int posSpace1 = tmp.indexOf(" ");
				if (posSpace1 > 0) {
					this.src1 = Etc.fixTrim(tmp.substring(0, posSpace1)); // "code"
					tmp = Etc.fixTrim(tmp.substring(posSpace1)); // "description"

					if (tmp.length() > 0) {
						this.src2 = Etc.fixTrim(tmp); // "description"
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("AssetCondition.getSrc():void, ex=" + ex.getMessage(), "", "AssetCondition");
		}
	}

	private void getPart() throws Exception {
		// origin - 24.12.2025, last edit - 12.01.2026
		try {
			this.code = src1;
			this.description = src2;
		} catch (Exception ex) {
			WB.addLog("AssetCondition.getPart():void, ex=" + ex.getMessage(), "", "AssetCondition");
		}
	}

	public AssetCondition(String Src) throws Exception {
		// origin - 24.12.2025, last edit - 24.12.2025
		this.clear();
		this.src = Etc.fixTrim(Src);
		this.getSrc();
		this.getPart();
	}

	private void clear() throws Exception {
		// origin - 24.12.2025, last edit - 12.01.2026
		try {
			this.src = this.src1 = this.src2 = "";
			this.code = this.description = "";
		} catch (Exception ex) {
			WB.addLog("AssetCondition.clear():void, ex=" + ex.getMessage(), "", "AssetCondition");
		}
	}

	public AssetCondition() throws Exception {
		// origin - 24.12.2025, last edit - 24.12.2025
		this.clear();
	}

	public String toString() {
		// origin - 24.12.2025, last edit - 08.01.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway(" src ", this.src);
			res = res + Fmtr.addIfNotEmpty(" src1 ", this.src1);
			res = res + Fmtr.addIfNotEmpty(" src2 ", this.src2);
			res = res + Fmtr.addIfNotEmpty(" code ", this.code);
			res = res + Fmtr.addIfNotEmpty(" description ", this.description);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 24.12.2025, last edit - 12.01.2026
		try {

//			WB.addLog2("AssetCondition.test.ctor(String)", "", "AssetCondition");
//			for (var tmp1 : new String[] { "новое б/к", "новое 2/к", "новое" }) {
//				WB.addLog2("AssetCondition.test.ctor(String)=" + new AssetCondition(tmp1), "", "AssetCondition");
//			}

		} catch (Exception ex) {
			WB.addLog("AssetCondition.test():void, ex=" + ex.getMessage(), "", "AssetCondition");
		}
	}
}