import java.util.ArrayList;
import java.util.List;

public class AssetPrice {
	// origin - 23.02.2025, last edit - 14.03.2025
	public boolean isValid, isExist;
	public String table, src, id, parent, code, description, geo, role, info, unit, mark;
	public ListVal date1, date2, more;
	public List<AssetDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("AssetPrice.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "AssetPrice");
		}
	}

	public static UnitVal get(String date1, String parentAssetId, String unitCurrencyDescription) throws Exception {
		// origin - 01.03.2025, last edit - 14.03.2025
		UnitVal res = new UnitVal();
		try {
			String unitCurrencyCode = "Unit." + Etc.delStr(unitCurrencyDescription, "Unit.");
			var listAssetDto = new AssetPrice(parentAssetId, unitCurrencyCode).val;
			var dto = AssetDto.getChrono(DateTool.getLocalDate(date1), listAssetDto, unitCurrencyCode);
//			WB.addLog2("AssetPrice.get, dto=" + dto + ", date1=" + date1 + ", parentAssetId=" + parentAssetId
//					+ ", unitCurrencyDescription=" + unitCurrencyDescription, WB.strEmpty, "AssetPrice");
			res = new UnitVal(dto.more, unitCurrencyCode);
		} catch (Exception ex) {
			WB.addLog("AssetPrice.get, ex=" + ex.getMessage(), WB.strEmpty, "AssetPrice");
		}
		return res;
	}

	private void getVal() throws Exception {
		// origin - 25.02.2025, last edit - 14.03.2025
		try {
			String currDate1 = WB.strEmpty;
			String currDate2 = WB.strEmpty;
			String currMore = WB.strEmpty;
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currMore = this.more.getByIndex(i);
				var tmp = new AssetDto(this.id, this.parent, currDate1, currDate2, this.code, this.description,
						this.geo, this.role, this.info, this.unit, currMore, this.mark);
				this.val.add(tmp);
//				WB.addLog2("AssetPrice.getVal, add tmp=" + tmp, WB.strEmpty,"AssetPrice");
			}
		} catch (Exception ex) {
			WB.addLog("AssetPrice.getVal, ex=" + ex.getMessage(), WB.strEmpty, "AssetPrice");
		}
	}

	public void isExist() throws Exception {
		// origin - 23.02.2025, last edit - 14.03.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getParentFilter(this.parent), this.table);
			if (listDto.size() != WB.intZero) {
				for (var currDto : listDto) {

					if ((this.unit.isEmpty() == false) && (Etc.strEquals(this.unit, currDto.unit)) == false) {
						continue;
					}

					if ((Etc.strEquals(currDto.info, Info.assetPrice))) {
						this.date1 = new ListVal(currDto.date1, WB.strEmpty);
						this.date2 = new ListVal(currDto.date2, WB.strEmpty);

						this.code = DefVal.setCustom(this.code, currDto.code);
						this.id = DefVal.setCustom(this.id, currDto.id);
						this.description = DefVal.setCustom(this.description, currDto.description);
						this.geo = DefVal.setCustom(this.geo, currDto.geo);
						this.role = DefVal.setCustom(this.role, currDto.role);
						this.info = DefVal.setCustom(this.info, currDto.info);
						this.unit = DefVal.setCustom(this.unit, currDto.unit);

						this.more = new ListVal(currDto.more, WB.strEmpty);

						this.mark = DefVal.setCustom(this.mark, currDto.mark);
						this.isExist = true;
						break; // only 1 record for 1 currency unit code
					}
				}
			}

		} catch (Exception ex) {
			WB.addLog("AssetPrice.isExist, ex=" + ex.getMessage(), WB.strEmpty, "AssetPrice");
		}
	}

	public AssetPrice(String ParentId) throws Exception {
		// origin - 01.03.2025, last edit - 01.03.2025
		this(ParentId, Unit.currCurrency.code);
	}

	public AssetPrice(String ParentId, String UnitCode) throws Exception {
		// origin - 23.02.2025, last edit - 14.03.2025
		this();
		this.table = "Asset"; // ??magic string??
		this.src = this.parent = ParentId;

		if (UnitCode.isEmpty() == false) {
			this.unit = UnitCode; // this is currency, ex. "Unit.KZT", "Unit.USD", etc.
//			WB.addLog2(
//					"AssetPrice.ctor(parentAssetId, UnitCode), this.unit=" + this.unit + ", UnitCode=" + UnitCode,
//					WB.strEmpty, "AssetPrice");
		}

		if (UnitCode.isEmpty()) {
			this.unit = Unit.currCurrency.code; // this is currency, ex. "Unit.KZT", "Unit.USD", etc.
//			WB.addLog2(
//					"AssetPrice.ctor(parentAssetId, UnitCode), this.unit=" + this.unit + ", UnitCode=" + UnitCode,
//					WB.strEmpty, "AssetPrice");
		}

		this.isExist();
		this.getVal();
	}

	public void clear() throws Exception {
		// origin - 23.02.2025, last edit - 14.03.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.unit = this.mark = WB.strEmpty;
			this.date1 = this.date2 = this.more = new ListVal();
			this.val = new ArrayList<AssetDto>();
		} catch (Exception ex) {
			WB.addLog("AssetPrice.clear, ex=" + ex.getMessage(), WB.strEmpty, "AssetPrice");
		}
	}

	public AssetPrice() throws Exception {
		// origin - 23.02.2025, last edit - 25.02.2025
		this.clear();
	}

	public String toString() {
		// origin - 23.02.2025, last edit - 07.03.2025
		String res = WB.strEmpty;
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", ", this.unit);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.id);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addAnyway(", val.size ", this.val.size());

			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 23.02.2025, last edit - 14.03.2025
		try {

//			// get (date, parentAssetId, currency)
//			for (var tmp1 : new String[] { "2024-01-31", "2025-01-31" }) {
//				for (var tmp2 : new String[] { "Asset.Test.1", "Asset.Money" }) {
//					for (var tmp3 : Price.currency) {
//						WB.addLog2("AssetPrice.test.get(date, parentAssetId)="
//								+ AssetPrice.get(tmp1, tmp2, tmp3).id + ", date1=" + tmp1 + ", parentId=" + tmp2
//								+ ", currency=" + tmp3, WB.strEmpty, "AssetPrice");
//					}
//				}
//			}

//			// ctor()
//			WB.addLog2("AssetPrice.test.ctor()=" + new AssetPrice(), WB.strEmpty, "AssetPrice");

//			// ctor (String)
//			for (var tmp1 : new String[] { "Asset.Test.1" }) {
//				// LocalDateTime localStart = WB.getLocalStart();
//				WB.addLog2("AssetPrice.test.ctor(String)=" + new AssetPrice(tmp1), WB.strEmpty,
//						"AssetPrice");
//				// WB.getLocalEnd("AssetPrice.test.ctor(String), parentId=" + tmp1,localStart);
//			}

		} catch (Exception ex) {
			WB.addLog("AssetPrice.test, ex=" + ex.getMessage(), WB.strEmpty, "AssetPrice");
		}
	}
}