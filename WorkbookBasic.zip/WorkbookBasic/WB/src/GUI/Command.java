import java.io.File;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

import javax.swing.JOptionPane;

public final class Command {
	// origin - 13.12.2023, last edit - 12.10.2025

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Command.static ctor, ex=" + ex.getMessage(), "", "Command");
		}
	}

	@SuppressWarnings("deprecation")
	public static void clearSpoolerPrinters() throws Exception {// not work
		// origin - 20.06.2024, last edit - 13.06.2025
		try {
			Runtime.getRuntime().exec("net stop spooler");
			Runtime.getRuntime().exec("cmd.exe del /f /q %systemroot%\\system32\\spool\\printers\\*.shd");
			Runtime.getRuntime().exec("cmd.exe del /f /q %systemroot%\\system32\\spool\\printers\\*.spl");
			Runtime.getRuntime().exec("net start spooler");
		} catch (Exception ex) {
			WB.addLog("Command.clearControlPrinters():void, ex=" + ex.getMessage(), "", "DAL");
		}
	}

	@SuppressWarnings("deprecation")
	public static void openControlPrinters() throws Exception {
		// origin - 19.06.2024, last edit - 13.06.2025
		try {
			Runtime.getRuntime().exec("control printers");
		} catch (Exception ex) {
			WB.addLog("Command.openControlPrinters():void, ex=" + ex.getMessage(), "", "Command");
		}
	}

	public static void cleanFolderProgram() throws Exception {
		// origin - 30.05.2024, last edit - 13.06.2025
		TreeSet<String> fileToDel = new TreeSet<String>();
		try {
			// clean log
			fileToDel.add(WB.eventLogPath);
			for (var currFileToDel : fileToDel) {
				// WB.addLog2("Command.cleanFolderProgram, currFileToDel=" +
				// currFileToDel,"","Command");
				InOut.delFile(Paths.get(currFileToDel).toFile());
			}
			// Command.cleanInputOutput(Conn.outputDbPattern, Conn.toAllPattern);
		} catch (Exception ex) {
			WB.addLog("Command.cleanFolderProgram():void, ex=" + ex.getMessage(), "", "Command");
		}
	}

	public static void cleanInputOutput(String patternInOut, String patternTo) throws Exception {
		// origin - 29.05.2024, last edit - 13.06.2025
		try {
			InOut.getDelFile(WB.inputOutputDir, patternInOut, patternTo, Conn.patternExtensionSqlite);
		} catch (Exception ex) {
			WB.addLog("Command.cleanInputOutput(String patternInOut, String patternTo):void, ex=" + ex.getMessage(), "",
					"Command");
		}
	}

	public static void replaceInto(TreeSet<String> setConn) throws Exception {
		// origin - 24.05.2024, last edit - 13.06.2025
		LocalDateTime localStart = WB.getLocalStart();
		List<ModelDto> updateDto = new ArrayList<ModelDto>();
		try {
			// new records in table for day
			List<List<String>> testTable = List.of(List.of("Asset", "1"), List.of("Face", "1"), List.of("Deal", "1"),
					List.of("Workbook", "1")); // ??magic strings and numbers

			// int numberPoint = 8; //??
			// int numberCenter = 1; //??

			updateDto = WriteSet.getTest(testTable);
			DAL.getReplaceInto(setConn, updateDto);
		} catch (Exception ex) {
			WB.addLog("Command.replaceInto(TreeSet<String> setConn):void, ex=" + ex.getMessage(), "", "Command");
		}
		WB.getLocalEnd("Command.replaceInto, updateDto.size=" + updateDto.size() + ", setConn=" + setConn, localStart);
	}

	@SuppressWarnings({ "deprecation", "unused" })
	public static void openUserManualLocal() throws Exception {
		// origin - 23.05.2023, last edit - 13.06.2025
		String userManualLocalNameFile = "";
		String pathFileToOpen = "";
		try {
			Conn.readDatabaseLocal();// Conn.getLocal(WB.localDir); // reread DatabaseLocal
			Abc abcLocal = WB.abcLocal;

			for (var currUserManualLocal : abcLocal.userManualLocal) {
				userManualLocalNameFile = Etc.fixTrim(currUserManualLocal.description.toString());
				pathFileToOpen = Command.getFileToExtFile(userManualLocalNameFile);
				// java.awt.Desktop.getDesktop().open(new File(pathFileToOpen));

				// Runtime.getRuntime().exec("explorer.exe " + pathFile); //it is work, too
				java.lang.Process process = Runtime.getRuntime().exec("explorer.exe " + pathFileToOpen.toString(),
						null);
			}
		} catch (Exception ex) {
			WB.addLog("Command.openUserManualLocal():void, ex=" + ex.getMessage(), "", "Command");
		}
	}

	public static void getLastRecord(TreeSet<String> setConn) throws Exception {
		// origin - 31.12.2023, last edit - 13.06.2025
		try {
			LocalDateTime localStart = WB.getLocalStart();
			TreeSet<String> resConn = DefVal.set(setConn, Conn.work); // Conn.getSetOrDefault(setConn);
			List<ModelDto> dtoLast = new ArrayList<ModelDto>();
			for (var currConn : resConn) {
				localStart = WB.getLocalStart();
				dtoLast = DAL.getTable(currConn, Qry.getWorkbookLastRecordSQLite);// Qry.getWorkbookLastRecord());
				WB.addLog2("Command.getLastRecord, dtoLast.size=" + dtoLast.size() + ", currConn=" + currConn, "",
						"Command");
				WB.getLocalEnd("Command.getLastRecord" + ", " + currConn, localStart);
			}
		} catch (Exception ex) {
			WB.addLog("Command.getLastRecord(TreeSet<String> setConn):void, ex=" + ex.getMessage(), "", "DAL");
		}
	}

	public static void updateBases(TreeSet<String> setConn) throws Exception {
		// origin - 24.12.2023, last edit - 13.06.2025
		try {
			LocalDateTime localStart = WB.getLocalStart();
			setConn = DefVal.set(setConn, Conn.work);// Conn.getSetOrDefault(setConn);
			List<ModelDto> updateDto = new ArrayList<ModelDto>();
			updateDto = WB.abcTemplate.update;
			DAL.getReplaceInto(setConn, updateDto);
			WB.getLocalEnd("Command.updateBases, updateDto.size=" + updateDto.size() + ", setConn=" + setConn,
					localStart);
		} catch (Exception ex) {
			WB.addLog("Command.updateBases(TreeSet<String> setConn):void, ex=" + ex.getMessage(), "", "Command");
		}
	}

	public static void updateExtFiles() throws Exception {
		// origin - 24.12.2023, last edit - 13.06.2025
		try {
			LocalDateTime localStart = WB.getLocalStart();
			String sourceExtFile = "";
			String fileTo = "";
			Conn.readDatabaseLocal();// Conn.getLocal(WB.localDir);
			Abc abcLocal = WB.abcLocal;

			for (var currLocal : abcLocal.sourceExtFile) {
				sourceExtFile = currLocal.description.toString();// TODO ??? or take currLocal.code ???
				fileTo = Command.getFileToExtFile(sourceExtFile);
				Conn.copyExtFile(sourceExtFile, fileTo);

				// if find new DatabaseLocal file
				if (Etc.strContains(Etc.getFileName(sourceExtFile), Conn.localDbPattern)) {
					Conn.readDatabaseLocal();// Conn.getLocal(WB.localDir);
				}
				// WB.addLog2("Command.updateExtFiles, sourceExtFile=" + sourceExtFile + ",
				// Id="+ currLocal.id, "", "Command");
			}
			WB.getLocalEnd("Command.updateExtFiles" + ", " + abcLocal.basic.size(), localStart);
		} catch (Exception ex) {
			WB.addLog("Command.updateExtFiles():void, ex=" + ex.getMessage(), "", "Command");
		}
	}

	private static String getFileToExtFile(String sourceExtFile) throws Exception {
		// origin - 01.01.2024, last edit - 13.06.2025
		String res = WB.commonDocDir + File.separator + Etc.getFileName(sourceExtFile);
		try {
			String destinationExtFile = "";

			// if find new DatabaseLocal file
			if (Etc.strContains(Etc.getFileName(sourceExtFile), Conn.localDbPattern)) {
				destinationExtFile = Etc.getFileName(sourceExtFile).replace(Conn.localDbPattern,
						Conn.localDbPattern + "_" + DateTool.getLabelDateTimeForFileName());
				res = WB.localDir + File.separator + destinationExtFile;
			}
		} catch (Exception ex) {
			WB.addLog("Command.getFileToExtFile(String sourceExtFile):void, ex=" + ex.getMessage(), "", "Command");
		}
		return res;
	}

	public static void vacuum(TreeSet<String> setConn) throws Exception {
		// origin - 19.12.2023, last edit - 13.06.2025
		try {
			LocalDateTime localStart = WB.getLocalStart();
			setConn = DefVal.set(setConn, Conn.work);// Conn.getSetOrDefault(setConn);
			DAL.getVacuum(setConn);
			WB.getLocalEnd("Command.vacuum for setConn.size=" + setConn.size() + ", setConn=" + setConn, localStart);
		} catch (Exception ex) {
			WB.addLog("Command.vacuum(TreeSet<String> setConn):void, ex=" + ex.getMessage(), "", "Command");
		}
	}

	public static void reindex(TreeSet<String> setConn) throws Exception {
		// origin - 19.12.2023, last edit - 13.06.2025
		try {
			LocalDateTime localStart = WB.getLocalStart();
			setConn = DefVal.set(setConn, Conn.work);// Conn.getSetOrDefault(setConn);
			DAL.getReindex(setConn);
			WB.getLocalEnd("Command.reindex for setConn.size=" + setConn.size() + ", setConn=" + setConn, localStart);
		} catch (Exception ex) {
			WB.addLog("Command.reindex(TreeSet<String> setConn):void, ex=" + ex.getMessage(), "", "Command");
		}
	}

	public static void integrityCheck(TreeSet<String> setConn) throws Exception {
		// origin - 19.12.2023, last edit - 13.06.2025
		try {
			LocalDateTime localStart = WB.getLocalStart();
			setConn = DefVal.set(setConn, Conn.work);// Conn.getSetOrDefault(setConn);
			DAL.getIntegrityCheck(setConn);
			WB.getLocalEnd("Command.integrityCheck for setConn.size=" + setConn.size() + ", setConn=" + setConn,
					localStart);
		} catch (Exception ex) {
			WB.addLog("Command.integrityCheck(TreeSet<String> setConn):void, ex=" + ex.getMessage(), "", "Command");
		}
	}

	public static void input(TreeSet<String> setConnFrom, TreeSet<String> setConnTo, String patternInOut,
			String patternTo) throws Exception {
		// origin - 28.05.2024, last edit - 13.06.2025
		try {
			LocalDateTime localStart = WB.getLocalStart();
			List<ModelDto> dtoInput = new ArrayList<ModelDto>();
			dtoInput = DAL.setByTemplate(setConnFrom, "");
			DAL.getReplaceInto(setConnTo, dtoInput);
			WB.getLocalEnd("Command.input for setConnFrom.size=" + setConnFrom.size(), localStart);
			WB.addLog2("Command.input, setConnFrom.size=" + setConnFrom.size() + ", dtoInput.size=" + dtoInput.size()
					+ ", setConnTo=" + setConnTo + ", patternInOut=" + patternInOut + ", patternTo=" + patternTo, "",
					"Command");
		} catch (Exception ex) {
			WB.addLog(
					"Command.input(TreeSet<String> setConnFrom, TreeSet<String> setConnTo, String patternInOut, String patternTo):void, ex="
							+ ex.getMessage(),
					"", "Command");
		}
	}

	public static void outputBackup(TreeSet<String> setConn) throws Exception {
		// origin - 28.05.2024, last edit - 13.06.2025
		try {
			LocalDateTime localStart = WB.getLocalStart();
			setConn = DefVal.set(setConn, Conn.work);// Conn.getSetOrDefault(setConn);
			DAL.getOutputBackup(setConn);
			WB.getLocalEnd("Command.outputBackup for setConn.size=" + setConn.size() + ", setConn=" + setConn,
					localStart);
		} catch (Exception ex) {
			WB.addLog("Command.outputBackup(TreeSet<String> setConn):void, ex=" + ex.getMessage(), "", "Command");
		}
	}

	public static void backup(TreeSet<String> setConn) throws Exception {
		// origin - 18.12.2023, last edit - 13.06.2025
		try {
			LocalDateTime localStart = WB.getLocalStart();
			setConn = DefVal.set(setConn, Conn.work);// Conn.getSetOrDefault(setConn);
			DAL.getBackup(setConn);
			WB.getLocalEnd("Command.backup for setConn.size=" + setConn.size() + ", setConn=" + setConn, localStart);
		} catch (Exception ex) {
			WB.addLog("Command.backup(TreeSet<String> setConn):void, ex=" + ex.getMessage(), "", "Command");
		}
	}

	public static void exit() throws Exception {
		// origin - 11.12.2023, last edit - 13.06.2025
		try {
			int selection = JOptionPane.showConfirmDialog(WB.frameBasic, "Do you want to leave the program ?",
					"Exit question", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
			if (selection == JOptionPane.OK_OPTION) {
				WB.addLog2("Command.exit", "", "Command");
				WB.getFinish();
				System.exit(0);
			}
		} catch (Exception ex) {
			WB.addLog("Command.exit():void, ex=" + ex.getMessage(), "", "Command");
		}
	}

	private Command() {
		// origin - 04.11.2024, last edit - 04.11.2024
	}

	public static void test() throws Exception {
		// origin - 28.05.2024, last edit - 13.06.2025
		try {

		} catch (Exception ex) {
			WB.addLog("Command.test():void, ex=" + ex.getMessage(), "", "Command");
		}
	}
}