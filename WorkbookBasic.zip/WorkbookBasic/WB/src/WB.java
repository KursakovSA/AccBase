import java.io.File;
import java.net.InetAddress;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;

public class WB extends JFrame {
	// origin - 25.09.2023, last edit - 26.11.2024
	private static final long serialVersionUID = 1L;
	public static final String startDir = System.getProperty("user.dir");

	public static final String strPipe = "|";
	public static final String strPipeSpace = WB.strPipe + WB.strSpace;
	public static final String strQuestionMark = "?";
	public static final String strSlash = "/";
	public static final String strColon = ":";
	public static final String strSemiColon = ";";
	public static final String strSpace = " ";
	public static final char charSpace = ' ';
	public static final String strSemiColonSpace = WB.strSemiColon + WB.strSpace;
	public static final String strComma = ",";
	public static final char charComma = ',';
	public static final char charDot = '.';
	public static final String strCommaSpace = WB.strComma + WB.strSpace;
	public static final String strEmpty = "";
	public static final String strApostrophe = "'";
	public static final String strEquals = "=";
	public static final String strDot = ".";

	public static final String strParenthesisLeft = "(";
	public static final String strParenthesisRight = ")";

	public static final String strSquareBracketLeft = "[";
	public static final String strSquareBracketRight = "]";

	public static final String strBraceLeft = "{";
	public static final String strBraceRight = "}";

	public static final String strAngleBracketLeft = "<";
	public static final String strAngleBracketRight = ">";

	public static final String strSharp = "#";
	public static final String strZero = "0";
	public static final String strDash = "-";
	public static final String strSplit = WB.strSpace + WB.strDash + WB.strSpace;
	public static final String strAtSimbol = "@";
	public static final String strUnderScore = "_";

	public static int eventCounter = 0;
	public static StringBuilder eventLog = new StringBuilder(WB.strEmpty);
	public static StringBuilder eventLog2 = new StringBuilder(WB.strEmpty);

	public static LocalDateTime eventGlobalStart;
	public static LocalDateTime eventGlobalEnd;

	public static String eventLogFile = "eventLog.csv"; // basic log default;
	public static String eventLogPath = WB.startDir + File.separator + eventLogFile;

	public static String lastSaveDir = System.getProperty("user.dir");
	public static String lastSelectFileDir = System.getProperty("user.dir");
	public static String mediaDir = System.getProperty("user.dir") + File.separator + "media";
	public static String commonDocDir = System.getProperty("user.dir") + File.separator + "commonDoc";
	public static String localDir = System.getProperty("user.dir") + File.separator + "local";
	public static String templateDocDir = System.getProperty("user.dir") + File.separator + "templateDoc";
	public static String backupDir = System.getProperty("user.dir") + File.separator + "backup";
	public static String inputOutputDir = System.getProperty("user.dir") + File.separator + "inputOutput";

	public static String lastConn = WB.strEmpty;
	public static String lastConnWork = WB.strEmpty;

	public static Abc abcGlobal;
	public static Abc abcTemplate;
	public static Abc abcLocal;
	public static Abc abcLast;

	public static final LocalDate minDateSupported = LocalDate.of(1900, Month.JANUARY, 01); // any date in app not need
																							// less minDateSupported
	public static final LocalDate maxDateSupported = LocalDate.of(2060, Month.DECEMBER, 31); // any date in app not need
																								// better
																								// maxDateSupported

	public static final LocalDate minDateDocSupported = LocalDate.of(2000, Month.JANUARY, 01); // for doc record in app
	public static final LocalDate maxDateDocSupported = maxDateSupported; // for doc record in app

	public static String currUser;
	public static String version;

	public static String frameBasicTitle;
	public static JFrame frameBasic;

	static {
		try {
			WB.version = "26.11.2024";
			WB.abcGlobal = new Abc(Conn.globalPath);
			WB.abcTemplate = new Abc(Conn.templatePath);
			WB.abcLocal = new Abc();
			WB.abcLast = new Abc();
			WB.currUser = WB.getAuthData();
			WB.frameBasicTitle = "Workbook Basic (accounting program), based on Java, SQLite, Eclipse. License : GPL 3.0. Made in Qazaqstan."
					+ ", version -" + version + ", support - github.com/KursakovSA/AccBase, currUser - " + currUser;
		} catch (Exception ex) {
			addLog("WB.static ctor abcGlobal, abcTemplate, ex=" + ex.getMessage(), WB.strEmpty, "WB");
		} finally {
			Etc.doNothing();
		}
		WB.addLog("WB.static ctor block init, WB.abcGlobal=" + WB.abcGlobal, WB.strEmpty, "WB");
		WB.addLog("WB.static ctor block init, WB.abcTemplate=" + WB.abcTemplate, WB.strEmpty, "WB");
	}

	public static void main(String[] args) throws Exception {
		// origin - 25.09.2023, last edit - 07.10.2024
		LocalDateTime localStart = WB.getLocalStart();
		try {
			WB.getGlobalStart();
			Conn.init();
			WB.init();
			WB.test();
			WB.frameBasic = GUI.getFrameBasic();

		} catch (Exception ex) {
			addLog("WB.main, ex=" + ex.getMessage(), WB.strEmpty, "WB");
		} finally {
			Etc.doNothing();
		}
		WB.getLocalEnd("WB.main, end ", localStart);
		// WB.addLog("WB.main, end", WB.strEmpty, "WB");
	}

	private static void init() throws Exception {
		// origin - 21.10.2023, last edit - 27.08.2024
		try {
			if (Conn.systemFact.isEmpty()) {
				return;
			}
			WB.createDir();
			WB.restoreLastState();
			WB.javaInfo();
		} catch (Exception ex) {
			WB.addLog("WB.init, ex=" + ex.getMessage(), WB.strEmpty, "WB");
		} finally {
			Etc.doNothing();
		}
		WB.addLog("WB.init, end", WB.strEmpty, "WB");
		WB.addLog2("WB.init, end", WB.strEmpty, "WB");
	}

	private static void javaInfo() throws Exception {
		// origin - 05.07.2024, last edit - 11.07.2024
		try {
			WB.addLog2("WB.init, java.version=" + System.getProperty("java.version"), WB.strEmpty, "WB");
			WB.addLog2("WB.init, java.home=" + System.getProperty("java.home"), WB.strEmpty, "WB");
			WB.addLog2("WB.init, java.class.path=" + System.getProperty("java.class.path"), WB.strEmpty, "WB");
			// WB.addLog2("WB.init, java.io.dir=" + System.getProperty("java.io.dir"),
			// WB.strEmpty, "WB");
			WB.addLog2("WB.init, os.name=" + System.getProperty("os.name"), WB.strEmpty, "WB");
		} catch (Exception ex) {
			addLog("WB.javaInfo, ex=" + ex.getMessage(), WB.strEmpty, "WB");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("WB.javaInfo end ", WB.strEmpty, "WB");
	}

	private static void createDir() throws Exception {
		// origin - 05.07.2024, last edit - 05.07.2024
		try {
			for (String dirPath : new String[] { mediaDir, commonDocDir, templateDocDir, backupDir, localDir,
					inputOutputDir }) {
				if (Files.notExists(Paths.get(dirPath))) {
					Files.createDirectory(Paths.get(dirPath));
					WB.addLog("WB.init, createDir=" + dirPath, WB.strEmpty, "WB");
				}
			}
		} catch (Exception ex) {
			addLog("WB.init, ex=" + ex.getMessage(), WB.strEmpty, "WB");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("WB.createDir end ", WB.strEmpty, "WB");
	}

	@SuppressWarnings("unused")
	private static void restoreLastState() throws Exception {// TOTHINK
		// origin - 14.02.2024, last edit - 05.07.2024
		List<ModelDto> lastState = new ArrayList<ModelDto>();
		List<ModelDto> restoreState = new ArrayList<ModelDto>();
		try {
			// TODO
		} catch (Exception ex) {
			addLog("WB.restoreLastState, ex=" + ex.getMessage(), WB.strEmpty, "WB");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("WB.restoreLastState, lastState=" + lastState, WB.strEmpty, "WB");
		// WB.addLog2("WB.restoreLastState, restoreState=" + restoreState, WB.strEmpty,
		// "WB");
	}

	@SuppressWarnings("unused")
	private static void saveLastState() throws Exception {// TOTHINK
		// origin - 14.02.2024, last edit - 05.07.2024
		List<ModelDto> lastState = new ArrayList<ModelDto>();
		try {

		} catch (Exception ex) {
			addLog("WB.saveLastState, ex=" + ex.getMessage(), WB.strEmpty, "WB");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("WB.saveLastState, lastState=" + lastState, WB.strEmpty, "WB");
	}

	private static void test() throws Exception {
		// origin - 25.09.2023, last edit - 21.11.2024
		try {
			if (isProject()) {
				Abc.test();
				Etc.test();
				Account.test();
				Asset.test();
				Deal.test();
				Debt.test();
				Face.test();
				Geo.test();
				Meter.test();
				Price.test();
				Process.test();
				Unit.test();
				Workbook.test();
				Slice.test();
				Mark.test();
				Role.test();
				Info.test();
				Sign.test();
				Item.test();
				ModelDto.test();
				Report.test();
				InOut.test();
				TemplateDoc.test();
				DAL.test();
				GUI.test();
				TimeJob.test();
				Command.test();
				Conn.test();
				Qry.test();
				DateTool.test();
				// WorkDay.test();
				LocInt.test();
				Conv.test();
				// CSV.test();
				IdGen.test();
				DefVal.test();
				Formatter.test();
				StopList.test();
				ListVal.test();
				CompositeVal.test();
				UnitVal.test();
				ModelVal.test();
				TagVal.test();
				// ReadVal.test();
				ReadSet.test();
				WriteSet.test();
				Pawn.test();
				PawnDoc.test();
				Term.test();
				Movement.test();
				MoreVal.test();
				SPL.test();
				Prolongation.test();
				RangeVal.test();
				ViewData.test();
				Access.test();
				AnnoVal.test();
				SimplexVal.test();
			}
		} catch (Exception ex) {
			addLog("WB.test, ex=" + ex.getMessage(), WB.strEmpty, "WB");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("WB.test, end ", WB.strEmpty, "WB");
	}

	public static void writeFile(String pathFile, String fileContent) throws Exception {
		// origin - 19.10.2023, last edit - 12.08.2024
		try {
			Path pf = Paths.get(pathFile);
			boolean isReplace = true;
			if (isProject() == false) {
				if (Files.exists(pf)) {
					isReplace = false;
				}
			}
			if (isReplace) {
				// writeReplace(pf, fileContent);
				Files.write(pf, fileContent.toString().getBytes("utf-8"));
			} else {
				// writeAppend(pf, fileContent);
				Files.write(pf, fileContent.toString().getBytes("utf-8"), StandardOpenOption.APPEND);
			}
		} catch (Exception ex) {
			addLog("WB.writeFile, ex=" + ex.getMessage(), WB.strEmpty, "WB");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("WB.writeFile, end ", WB.strEmpty, "WB");
	}

	@SuppressWarnings({ "deprecation", "unused" })
	public static void openFile(String pathFile) throws Exception {
		// origin - 19.10.2023, last edit - 17.09.2024
		if (isProject()) {
			try {
				// Desktop.getDesktop().open(new File(pathFile));

				// Runtime.getRuntime().exec("explorer.exe " + pathFile); //it is work, too
				java.lang.Process process = Runtime.getRuntime().exec("explorer.exe " + pathFile.toString(), null);

			} catch (Exception ex) {
				System.out.println("WB.openFile, ex=" + ex.getMessage() + ", pathFile=" + pathFile);
			} finally {
				Etc.doNothing();
			}
		}
		// WB.addLog2("WB.openFile, end ", WB.strEmpty, "WB");
	}

	private static String getAuthData() throws Exception {
		// origin - 05.12.2023, last edit - 07.07.2024
		String res = WB.strEmpty;
		try {
			res = res + InetAddress.getLocalHost().getHostName() + "\\";
			res = res + System.getProperty("user.name");
		} catch (Exception ex) {
			addLog("WB.getAuthData, ex=" + ex.getMessage(), WB.strEmpty, "WB");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("WB.getAuthData, res=" + res, WB.strEmpty, "WB");
		return res;
	}

	private static boolean hasFile(String dir, String file) throws Exception {
		// origin - 07.12.2023, last edit - 07.07.2024
		boolean res = false;
		try {
			Path checkFilePath = Paths.get(dir + File.separator + file);
			if (Files.exists(checkFilePath)) {
				res = true;
			}
		} catch (Exception ex) {
			addLog("WB.hasFile, ex=" + ex.getMessage(), WB.strEmpty, "WB");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("WB.hasFile, res=" + res + ", dir=" + dir + ", file=" + file,
		// WB.strEmpty, "WB");
		return res;
	}

	private static boolean isProject() throws Exception {
		// origin - 05.12.2023, last edit - 07.07.2024
		boolean res = false;
		try {
			if (hasFile(startDir, ".project")) { // if in startDir exist project Eclipse then isDev = true
				res = true;
			}
		} catch (Exception ex) {
			System.out.println("WB.isDev, ex=" + ex.getMessage());
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("WB.isProject, res=" + res, WB.strEmpty, "WB");
		return res;
	}

	public static void getGlobalStart() throws Exception {
		// origin - 25.10.2023, last edit - 07.07.2024
		try {
			eventGlobalStart = DateTool.getNow2();// DateTool.getOffsetDateTimeNow();
			WB.addLog("WB.getGlobalStart, eventGlobalStart=" + DateTool.formatter(eventGlobalStart), WB.strEmpty, "WB");
		} catch (Exception ex) {
			addLog("WB.getGlobalStart, ex=" + ex.getMessage(), WB.strEmpty, "WB");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("WB.getGlobalStart, end", WB.strEmpty, "WB");
	}

	public static LocalDateTime getLocalStart() throws Exception {
		// origin - 13.06.2024, last edit - 07.07.2024
		LocalDateTime res = null;
		try {
			res = DateTool.getNow2();
		} catch (Exception ex) {
			addLog("WB.getLocalStart, ex=" + ex.getMessage(), WB.strEmpty, "WB");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("WB.getLocalStart, res=" + res, WB.strEmpty, "WB");
		return res;
	}

	public static LocalDateTime getLocalEnd(String source, LocalDateTime localStart) throws Exception {
		// origin - 13.06.2024, last edit - 07.07.2024
		LocalDateTime res = null;
		try {
			res = DateTool.getNow2();
		} catch (Exception ex) {
			addLog("WB.getLocalEnd, ex=" + ex.getMessage(), WB.strEmpty, "WB");
		} finally {
			Etc.doNothing();
		}
		WB.addLog("WB.getLocalEnd, durationLocal=" + DateTool.getDuration(localStart, res) + " ms, " + source,
				WB.strEmpty, "WB");
		// WB.addLog2("WB.getLocalEnd, res=" + res, WB.strEmpty, "WB");
		return res;
	}

	public static void getFinish() throws Exception {
		// origin - 26.09.2023, last edit - 07.07.2024
		try {
			WB.saveLastState();
			WB.getEventEnd();
			WB.writeFile(eventLogPath, eventLog.toString());
			WB.openFile(eventLogPath);
		} catch (Exception ex) {
			addLog("WB.getFinish, ex=" + ex.getMessage(), WB.strEmpty, "WB");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("WB.getFinish, end", WB.strEmpty, "WB");
	}

	private static void getEventEnd() throws Exception {
		// origin - 21.10.2023, last edit - 04.08.2024
		try {
			WB.eventGlobalEnd = DateTool.getNow2();// DateTool.getOffsetDateTimeNow();
			WB.addLog("WB.getEventEnd, eventGlobalEnd=" + DateTool.formatter(eventGlobalEnd), WB.strEmpty, "WB");
			WB.addLog(
					"WB.getEventEnd, durationGlobal=" + DateTool.getDuration(eventGlobalStart, eventGlobalEnd) + " ms",
					WB.strEmpty, "WB");
			WB.addLog("Log detail");
			WB.addLog(eventLog2.toString());
		} catch (Exception ex) {
			WB.addLog("WB.getEventEnd, ex=" + ex.getMessage(), WB.strEmpty, "WB");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("WB.getEventEnd, end", WB.strEmpty, "WB");
	}

	public static void addLog2(Object EventObj, String EventCont, String EventMeth) throws Exception {
		// origin - 03.11.2023, last edit - 14.11.2024
		try {
			WB.eventCounter = WB.eventCounter + 1;
			// WB.appender2(WB.formatter(EventObj, EventCont, EventMeth));
			WB.eventLog2.append(WB.formatter(EventObj, EventCont, EventMeth));
		} catch (Exception ex) {
			WB.addLog("WB.addLog2, ex=" + ex.getMessage(), WB.strEmpty, "WB");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("WB.addLog2, end", WB.strEmpty, "WB");
	}

	public static void addLog(Object EventObj, String EventCont, String EventMeth) {
		// origin - 26.09.2023, last edit - 14.11.2024
		WB.eventCounter = WB.eventCounter + 1;
		try {
			// WB.appender(WB.formatter(EventObj, EventCont, EventMeth));
			WB.eventLog.append(WB.formatter(EventObj, EventCont, EventMeth));
		} catch (Exception ex) {
			WB.addLog("WB.addLog, ex=" + ex.getMessage(), WB.strEmpty, "WB");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("WB.addLog, end", WB.strEmpty, "WB");
	}

	private static void addLog(String str) throws Exception {
		// origin - 03.11.2023, last edit - 14.11.2024
		try {
			WB.eventCounter = WB.eventCounter + 1;
			// WB.appender(str + System.lineSeparator());
			WB.eventLog.append(str + System.lineSeparator());
		} catch (Exception ex) {
			WB.addLog("WB.addLog, ex=" + ex.getMessage(), WB.strEmpty, "WB");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("WB.addLog, end", WB.strEmpty, "WB");
	}

	private static String formatter(Object eventObj, String eventCont, String eventMeth) throws Exception {
		// origin - 21.10.2023, last edit - 15.11.2024
		String res = WB.strEmpty;
		try {
			// res = res + WB.strSharp + eventCounter + WB.strSemiColonSpace +
			// DateTool.formatter(DateTool.getNow2())
			res = res + WB.strSharp + eventCounter + WB.strPipeSpace + DateTool.formatter(DateTool.getNow2())
			// + WB.strSemiColonSpace + eventObj.toString() + WB.strSemiColonSpace;
					+ WB.strPipeSpace + eventObj.toString() + WB.strPipeSpace;

			if (eventCont.isEmpty()) {
				// res = res + WB.currUser + WB.strSemiColonSpace;
				res = res + WB.currUser + WB.strPipeSpace;
			} else {
				// res = res + eventCont + WB.strCommaSpace + WB.currUser +
				// WB.strSemiColonSpace;
				res = res + eventCont + WB.strPipeSpace + WB.currUser + WB.strPipeSpace;
			}

			// res = res + eventMeth + WB.strSemiColon + System.lineSeparator();
			res = res + eventMeth + WB.strPipeSpace + System.lineSeparator();

		} catch (Exception ex) {
			WB.addLog("WB.formatter, ex=" + ex.getMessage(), WB.strEmpty, "WB");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("WB.addLog, end", WB.strEmpty, "WB");
		return res;
	}

//	private static void appender2(String currEventAdd) throws Exception {
//		// origin - 03.11.2023, last edit - 14.11.2024
//		try {
//			WB.eventLog2.append(currEventAdd.toString());
//		} catch (Exception ex) {
//			WB.addLog("WB.appender2, ex=" + ex.getMessage(), WB.strEmpty, "WB");
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("WB.appender2, end", WB.strEmpty, "WB");
//	}

//	private static void appender(String currEventAdd) throws Exception {
//		// origin - 21.10.2023, last edit - 14.11.2024
//		try {
//			WB.eventLog.append(currEventAdd.toString());
//		} catch (Exception ex) {
//			WB.addLog("WB.appender, ex=" + ex.getMessage(), WB.strEmpty, "WB");
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("WB.appender, end", WB.strEmpty, "WB");
//	}
}
