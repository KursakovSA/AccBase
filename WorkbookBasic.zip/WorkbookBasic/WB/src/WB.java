import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import javax.swing.JFrame;

public class WB extends JFrame {
	// origin - 25.09.2023, last edit - 15.01.2024
	private static final long serialVersionUID = 1L;
	public static final String startDir;
	public static String lastSaveDir;
	public static String lastSelectFileDir;
	public static String mediaDir;
	public static String docDir;
	public static String localDir;
	public static String templateDocDir;
	public static String backupDir;
	public static String lastConn = new String();
	public static Abc abcGlobal = new Abc();
	public static Abc abcLocal = new Abc();
	public static Abc abcLast = new Abc();
	public static final LocalDate minDateSupported;
	public static final LocalDate maxDateSupported;
	public static String frameBasicTitle;
	public static JFrame frameBasic;
	public static String currUser;
	public static String version;

	static {
		startDir = System.getProperty("user.dir");
		currUser = getAuthData();
		lastSaveDir = System.getProperty("user.dir");
		lastSelectFileDir = System.getProperty("user.dir");
		mediaDir = System.getProperty("user.dir") + File.separator + "media";
		docDir = System.getProperty("user.dir") + File.separator + "doc";
		templateDocDir = System.getProperty("user.dir") + File.separator + "templateDoc";
		backupDir = System.getProperty("user.dir") + File.separator + "backup";
		localDir = System.getProperty("user.dir") + File.separator + "local";
		minDateSupported = LocalDate.of(2000, 01, 01);
		maxDateSupported = LocalDate.of(2060, 12, 31);
		try {
			abcGlobal = new Abc(Conn.globalPath);
		} catch (Exception ex) {
			Logger.add("WB.main, abcGlobal static ctor, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(),
					"", "WB");
		} finally {
			Etc.doNothing();
		}
		Logger.add("WB.static ctor block init, abcGlobal=" + abcGlobal, "", "WB");
		version = "15.01.2024";
		frameBasicTitle = "Workbook Basic (accounting program), based on Java, SQLite, Eclipse. License : GPL 3.0. Made in Qazaqstan."
				+ ", version -" + WB.version + ", [currUser - " + WB.currUser + "]";
	}

	public static void main(String[] args) throws Exception {
		// origin - 25.09.2023, last edit - 23.12.2023
		try {
			Logger.getGlobalStart();
			Conn.init();
			WB.init();
			test();
			frameBasic = GUI.getFrameBasic();

		} catch (Exception ex) {
			Logger.add("WB.main, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "WB");
		} finally {
			Etc.doNothing();
		}
	}

	private static void init() {
		// origin - 21.10.2023, last edit - 06.01.2024
		if (Conn.systemFact.isEmpty()) {
			return;
		}
		for (String dirPath : new String[] { mediaDir, docDir, templateDocDir, backupDir, localDir }) {
			if (Files.notExists(Paths.get(dirPath))) {
				try {
					Files.createDirectory(Paths.get(dirPath));
				} catch (IOException ex) {
					Logger.add("WB.init, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "WB");
				} finally {
					Etc.doNothing();
				}
				Logger.add("WB.init, createDir=" + dirPath, "", "WB");
			}
		}
	}

	private static void test() throws Exception {
		// origin - 25.09.2023, last edit - 15.01.2024
		if (isDev()) {
			//Abc.test();

			Etc.test();
			// Account.test();
			// Asset.test();
			// Deal.test();
			 Debt.test();
			// Face.test();
			// Geo.test();
			// Meter.test();
			// Price.test();
			// Process.test();
			// Unit.test();
			 //Workbook.test();
			// Slice.test();
			// Mark.test();
			// Role.test();
			// Info.test();
			// Sign.test();
			// Item.test();
			// Model.test();

			//ModelDto.test();
			//Report.test();
			//Output.test();
			//Input.test();
			//TemplateDoc.test();
			//DAL.test();
			//GUI.test();
			//Rule.test();
			//Validation.test();
			 //Schedule.test();
		}
	}

	public static void writeFile(String pathFile, String fileContent) throws Exception {
		// origin - 19.10.2023, last edit - 18.12.2023
		Path pf = Paths.get(pathFile);
		if (isDev()) {
			writeReplace(pf, fileContent);
		} else {
			if (Files.exists(pf)) {
				writeAppend(pf, fileContent);
			} else {
				writeReplace(pf, fileContent);
			}
		}
	}

	public static void writeAppend(Path pf, String fileContent) throws Exception {
		// origin - 06.12.2023, last edit - 23.12.2023
		try {
			Files.write(pf, fileContent.toString().getBytes("utf-8"), StandardOpenOption.APPEND);
		} catch (Exception ex) {
			Logger.add("WB.writeAppend, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace() + ", path=" + pf,
					"", "WB");
		} finally {
			Etc.doNothing();
		}
	}

	public static void writeReplace(Path pf, String fileContent) throws Exception {
		// origin - 06.12.2023, last edit - 23.12.2023
		try {
			Files.write(pf, fileContent.toString().getBytes("utf-8"));
		} catch (Exception ex) {
			Logger.add("WB.writeReplace, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace() + ", path=" + pf,
					"", "WB");
		} finally {
			Etc.doNothing();
		}
	}

	public static void openFile(String pathFile) throws Exception {
		// origin - 19.10.2023, last edit - 23.12.2023
		if (isDev()) {
			try {
				Desktop.getDesktop().open(new File(pathFile));
			} catch (Exception ex) {
				Logger.add("WB.openFile, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace() + ", pathFile="
						+ pathFile, "", "WB");
			} finally {
				Etc.doNothing();
			}
		}
	}

	private static String getAuthData() {
		// origin - 05.12.2023, last edit - 23.12.2023
		String res = "";
		try {
			res = res + InetAddress.getLocalHost().getHostName() + "\\";
			res = res + System.getProperty("user.name");
		} catch (Exception ex) {
			Logger.add("WB.getAuthData, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "WB");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	private static boolean hasFile(String dir, String file) throws Exception {
		// origin - 07.12.2023, last edit - 23.12.2023
		boolean res = false;
		try {
			Path checkFilePath = Paths.get(dir + File.separator + file);
			if (Files.exists(checkFilePath)) {
				res = true;
			}
		} catch (Exception ex) {
			Logger.add("WB.hasFile, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "WB");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	private static boolean isDev() throws Exception {
		// origin - 05.12.2023, last edit - 23.12.2023
		boolean res = false;
		try {
			if (hasFile(startDir, ".project")) { // if in startDir exist project Eclipse then isDev = true
				res = true;
			}
		} catch (Exception ex) {
			Logger.add("WB.isDev, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "WB");
		} finally {
			Etc.doNothing();
		}
		return res;
	}
}
