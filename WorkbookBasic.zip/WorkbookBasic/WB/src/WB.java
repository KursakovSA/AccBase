import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;

public class WB extends JFrame {
	// origin - 25.09.2023, last edit - 23.05.2024
	private static final long serialVersionUID = 1L;
	public static final String startDir = System.getProperty("user.dir");

	public static int eventCounter = 0;
	public static StringBuilder eventLog = new StringBuilder("");
	public static StringBuilder eventLog2 = new StringBuilder("");
	
//	public static OffsetDateTime eventGlobalStart;
//	public static OffsetDateTime eventGlobalEnd;
//	public static OffsetDateTime eventLocalStart;
//	public static OffsetDateTime eventLocalEnd;
	
	public static LocalDateTime eventGlobalStart;
	public static LocalDateTime eventGlobalEnd;
	public static LocalDateTime eventLocalStart;
	public static LocalDateTime eventLocalEnd;
	
	public static String eventLogFile = "eventLog.csv"; // basic log default;
	public static String eventLogPath = WB.startDir + File.separator + eventLogFile;

	public static String lastSaveDir = System.getProperty("user.dir");
	public static String lastSelectFileDir = System.getProperty("user.dir");
	public static String mediaDir = System.getProperty("user.dir") + File.separator + "media";
	public static String commonDocDir = System.getProperty("user.dir") + File.separator + "commonDoc";
	public static String localDir = System.getProperty("user.dir") + File.separator + "local";
	public static String templateDocDir = System.getProperty("user.dir") + File.separator + "templateDoc";
	public static String backupDir = System.getProperty("user.dir") + File.separator + "backup";
	public static String inputOutputDir = System.getProperty("user.dir") + File.separator + "inputOutput";
	
	public static String lastConn = new String();
	
	public static Abc abcGlobal = new Abc();
	public static Abc abcTemplate = new Abc();
	public static Abc abcLocal = new Abc();
	public static Abc abcLast = new Abc();
	
	public static final LocalDate minDateSupported = LocalDate.of(2000, Month.JANUARY, 01);
	public static final LocalDate maxDateSupported = LocalDate.of(2060, Month.DECEMBER, 31);
	
	public static String currUser = getAuthData();
	public static String version = "22.05.2024";
	
	public static String frameBasicTitle = "Workbook Basic (accounting program), based on Java, SQLite, Eclipse. License : GPL 3.0. Made in Qazaqstan."
			+ ", version -" + version + ", [currUser - " + currUser + "]";
	public static JFrame frameBasic;

	static {
		try {
			abcGlobal = new Abc(Conn.globalPath);
			abcTemplate = new Abc(Conn.templatePath);
		} catch (Exception ex) {
			addLog("WB.static ctor abcGlobal, abcTemplate, ex=" + ex.getMessage(), "", "WB");
		} finally {
			Etc.doNothing();
		}
		addLog("WB.static ctor block init, abcGlobal=" + abcGlobal, "", "WB");
		addLog("WB.static ctor block init, abcTemplate=" + abcTemplate, "", "WB");
	}

	public static void main(String[] args) throws Exception {
		// origin - 25.09.2023, last edit - 23.05.2024
		try {
			getGlobalStart();
			Conn.init();
			WB.init();
			test();
			frameBasic = GUI.getFrameBasic();

		} catch (Exception ex) {
			addLog("WB.main, ex=" + ex.getMessage(), "", "WB");
		} finally {
			Etc.doNothing();
		}
	}

	private static void init() {
		// origin - 21.10.2023, last edit - 23.05.2024
		if (Conn.systemFact.isEmpty()) {
			return;
		}
		
		for (String dirPath : new String[] { mediaDir, commonDocDir, templateDocDir, backupDir, localDir, inputOutputDir }) {
			if (Files.notExists(Paths.get(dirPath))) {
				try {
					Files.createDirectory(Paths.get(dirPath));
				} catch (IOException ex) {
					addLog("WB.init, ex=" + ex.getMessage(), "", "WB");
				} finally {
					Etc.doNothing();
				}
				addLog("WB.init, createDir=" + dirPath, "", "WB");
			}
		}
		
		WB.restoreLastState();
	}
	
	@SuppressWarnings("unused")
	private static void restoreLastState() {//TODO
		// origin - 14.02.2024, last edit - 23.05.2024
		List<ModelDto> lastState = new ArrayList<ModelDto>();
		List<ModelDto> restoreState = new ArrayList<ModelDto>();
		try {
			//TODO
		} catch (Exception ex) {
			addLog("WB.restoreLastState, ex=" + ex.getMessage(), "", "WB");
		} finally {
			Etc.doNothing();
		}
		//addLog2("WB.restoreLastState, lastState=" + lastState, "", "WB");
		//addLog2("WB.restoreLastState, restoreState=" + restoreState, "", "WB");
	}
	
	@SuppressWarnings("unused")
	private static void saveLastState() {//TODO
		// origin - 14.02.2024, last edit - 23.05.2024
		List<ModelDto> lastState = new ArrayList<ModelDto>();
		try {
			//TODO
		} catch (Exception ex) {
			addLog("WB.saveLastState, ex=" + ex.getMessage(), "", "WB");
		} finally {
			Etc.doNothing();
		}
		//addLog2("WB.saveLastState, lastState=" + lastState, "", "WB");
	}

	private static void test() throws Exception {
		// origin - 25.09.2023, last edit - 22.05.2024
		if (isProject()) {
			// Abc.test();
			 //Etc.test();
			// Account.test();
			// Asset.test();
			// Deal.test();
			// Debt.test();
			// Face.test();
			// Geo.test();
			// Meter.test();
			// Price.test();
			// Process.test();
			// Unit.test();
			// Workbook.test();
			// Slice.test();
			// Mark.test();
			// Role.test();
			// Info.test();
			// Sign.test();
			// Item.test();
			 //Model.test();
			 //ModelDto.test();
			// Report.test();
			// InOut.test();
			// TemplateDoc.test();
			// DAL.test();
			// GUI.test();
			// Rule.test();
			// Validation.test();
			// Schedule.test();
			// DateTool.test();
		}
	}

	public static void writeFile(String pathFile, String fileContent) throws Exception {
		// origin - 19.10.2023, last edit - 18.02.2024
		Path pf = Paths.get(pathFile);
		if (isProject()) {
			writeReplace(pf, fileContent);
		} else {
			if (Files.exists(pf)) {
				writeAppend(pf, fileContent);
			} else {
				writeReplace(pf, fileContent);
			}
		}
	}

	public static void writeAppend(Path pf, String fileContent) throws Exception {
		// origin - 06.12.2023, last edit - 23.05.2024
		try {
			Files.write(pf, fileContent.toString().getBytes("utf-8"), StandardOpenOption.APPEND);
		} catch (Exception ex) {
			System.out.println("WB.writeAppend, ex=" + ex.getMessage() + ", path=" + pf);
		} finally {
			Etc.doNothing();
		}
	}

	public static void writeReplace(Path pf, String fileContent) throws Exception {
		// origin - 06.12.2023, last edit - 23.05.2024
		try {
			Files.write(pf, fileContent.toString().getBytes("utf-8"));
		} catch (Exception ex) {
			System.out.println("WB.writeReplace, ex=" + ex.getMessage() + ", path=" + pf);
		} finally {
			Etc.doNothing();
		}
	}

	public static void openFile(String pathFile) throws Exception {
		// origin - 19.10.2023, last edit - 23.05.2024
		if (isProject()) {
			try {
				Desktop.getDesktop().open(new File(pathFile));
			} catch (Exception ex) {
				System.out.println("WB.openFile, ex=" + ex.getMessage() + ", pathFile=" + pathFile);
			} finally {
				Etc.doNothing();
			}
		}
	}

	private static String getAuthData() {
		// origin - 05.12.2023, last edit - 23.05.2024
		String res = "";
		try {
			res = res + InetAddress.getLocalHost().getHostName() + "\\";
			res = res + System.getProperty("user.name");
		} catch (Exception ex) {
			addLog("WB.getAuthData, ex=" + ex.getMessage(), "", "WB");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	private static boolean hasFile(String dir, String file) throws Exception {
		// origin - 07.12.2023, last edit - 23.05.2024
		boolean res = false;
		try {
			Path checkFilePath = Paths.get(dir + File.separator + file);
			if (Files.exists(checkFilePath)) {
				res = true;
			}
		} catch (Exception ex) {
			addLog("WB.hasFile, ex=" + ex.getMessage(), "", "WB");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	private static boolean isProject() throws Exception {
		// origin - 05.12.2023, last edit - 23.05.2024
		boolean res = false;
		try {
			if (hasFile(startDir, ".project")) { // if in startDir exist project Eclipse then isDev = true
				res = true;
			}
		} catch (Exception ex) {
			System.out.println("WB.isDev, ex=" + ex.getMessage());
		} finally {
			Etc.doNothing();
		}
		return res;
	}
	
//	public static String getNow() {
//		// origin - 21.05.2024, last edit - 21.05.2024
//		String res = "";
//		//res = DateTool.getOffsetDateTimeNow().toString();
//		res = DateTool.getLocalDateTimeNow().toString();
//		return res;
//	}

	public static void getGlobalStart() {
		// origin - 25.10.2023, last edit - 21.05.2024
		eventGlobalStart = DateTool.getLocalDateTimeNow();//DateTool.getOffsetDateTimeNow();
		addLog("WB.getGlobalStart, eventGlobalStart=" + DateTool.formatter(eventGlobalStart), "", "WB");
	}

	public static void getLocalStart() {
		// origin - 21.10.2023, last edit - 21.05.2024
		// Logger.getLocalStart(); //--- for copy/paste
		eventLocalStart = DateTool.getLocalDateTimeNow();//DateTool.getOffsetDateTimeNow();
	}

	public static void getLocalEnd(String source) {
		// origin - 21.10.2023, last edit - 21.05.2024
		// Logger.getLocalEnd(); //--- for copy/paste
		eventLocalEnd = DateTool.getLocalDateTimeNow();//DateTool.getOffsetDateTimeNow();
		addLog("WB.getLocalEnd, durationLocal=" + DateTool.getDuration(eventLocalStart, eventLocalEnd) + " ms, "
				+ source, "", "WB");
	}

	public static void getFinish() throws Exception {
		// origin - 26.09.2023, last edit - 14.02.2024
		saveLastState();
		getEventEnd();
		writeFile(eventLogPath, eventLog.toString());
		openFile(eventLogPath);
	}

	private static void getEventEnd() throws Exception {
		// origin - 21.10.2023, last edit - 21.05.2024
		eventGlobalEnd = DateTool.getLocalDateTimeNow();//DateTool.getOffsetDateTimeNow();
		addLog("WB.getEventEnd, eventGlobalEnd=" + DateTool.formatter(eventGlobalEnd), "", "WB");
		addLog("WB.getEventEnd, durationGlobal=" + DateTool.getDuration(eventGlobalStart, eventGlobalEnd)
				+ " ms", "", "WB");
		addLog("Log detail");
		addLog(eventLog2.toString());
		// add("******************");
	}

	public static void addLog2(Object EventObj, String EventCont, String EventMeth) {
		// origin - 03.11.2023, last edit - 18.01.2024
		eventCounter = eventCounter + 1;
		appender2(formatter(EventObj, EventCont, EventMeth));
	}

	public static void addLog(Object EventObj, String EventCont, String EventMeth) {
		// origin - 26.09.2023, last edit - 18.01.2024
		eventCounter = eventCounter + 1;
		appender(formatter(EventObj, EventCont, EventMeth));
	}

	private static void addLog(String str) {
		// origin - 03.11.2023, last edit - 18.01.2024
		eventCounter = eventCounter + 1;
		appender(str + System.lineSeparator());
	}

	private static String formatter(Object eventObj, String eventCont, String eventMeth) {
		// origin - 21.10.2023, last edit - 21.05.2024
		String res = "";
		//res = res + "#" + eventCounter + "; " + DateTool.getOffsetDateTimeNow() + "; " + eventObj + "; ";
		res = res + "#" + eventCounter + "; " + DateTool.formatter(DateTool.getLocalDateTimeNow()) + "; " + eventObj + "; ";
		if (eventCont.isEmpty()) {
			res = res + WB.currUser + "; ";
		} else {
			res = res + eventCont + ", " + WB.currUser + "; ";
		}
		res = res + eventMeth + ";" + System.lineSeparator();
		return res;
	}

	private static void appender2(String currEventAdd) {
		// origin - 03.11.2023, last edit - 05.12.2023
		eventLog2.append(currEventAdd.toString());
	}

	private static void appender(String currEventAdd) {
		// origin - 21.10.2023, last edit - 05.12.2023
		eventLog.append(currEventAdd.toString());
	}

}
