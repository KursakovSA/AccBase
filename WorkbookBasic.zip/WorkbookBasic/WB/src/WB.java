import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class WB extends JFrame {
	// origin - 25.09.2023, last edit - 14.12.2023
	private static final long serialVersionUID = 1L;
	public static String startDir = new String();
	public static String lastSaveDir = new String();
	public static String lastSelectFileDir = new String();
	public static String mediaDir = new String();
	public static String docDir = new String();
	public static String templateDocDir = new String();
	public static String lastConn = new String();
	public static final Abc abcGlobal = new Abc();
	public static Abc abcLast = new Abc();
	public static final LocalDate minDateSupported;
	public static final LocalDate maxDateSupported;
	public static final String frameBasicTitle;
	public static JFrame frameBasic;
	public static String currUser;
	public static String version;

	static {
		startDir = System.getProperty("user.dir");
		//Logger.add("WB.main.static ctor, startDir=" + startDir, "", "WB");
		currUser = getAuthData();
		lastSaveDir = System.getProperty("user.dir");
		lastSelectFileDir = System.getProperty("user.dir");
		mediaDir = System.getProperty("user.dir") + File.separator + "media";
		docDir = System.getProperty("user.dir") + File.separator + "doc";
		templateDocDir = System.getProperty("user.dir") + File.separator + "templateDoc";
		minDateSupported = LocalDate.of(2020, 01, 01);
		maxDateSupported = LocalDate.of(2060, 12, 31);
		Abc abcGlobal = Abc.getBasic(Conn.globalPath);
		Logger.add("WB.static init, abcGlobal=" + abcGlobal, "", "WB");
		version = "14.12.2023";
		frameBasicTitle = "Workbook Basic (accounting program), based on Java, SQLite, Eclipse. License : GPL 3.0. Made in Qazaqstan." + 
		", version -" + WB.version + ", [currUser - "+WB.currUser +"]";
	}

	public static void main(String[] args) throws Exception {
		// origin - 25.09.2023, last edit - 13.12.2023
		try {
			Logger.getGlobalStart();
			StartUp();
			frameBasic = GUI.getFrameBasic();
			
			//var listener = new TimePrinter();
			//var timer = new Timer(1000, listener);
			//var timer = new Timer();
			//timer.start();
			
		} catch (Exception ex) {
			Logger.add("WB.main, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "WB");
		} finally {
		}
	}

	private static void StartUp() throws Exception {
		// origin - 25.09.2023, last edit - 13.12.2023
		try {
			Conn.init();
			WB.init();
			test();
		} catch (Exception ex) {
			Logger.add("WB.onStartApp, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "WB");
		} finally {
		}
	}

	private static void init() {
		// origin - 21.10.2023, last edit - 04.12.2023
		if (Conn.systemFact.size() != 0) {
			for (String dirPath : new String[] { mediaDir, docDir, templateDocDir }) {
				if (Files.notExists(Paths.get(dirPath))) {
					try {
						Files.createDirectory(Paths.get(dirPath));
					} catch (IOException ex) {
						Logger.add("WB.init, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "WB");
					}
					Logger.add("WB.init, createDir=" + dirPath, "", "WB");
				}
			}
		}
	}

	private static void test() throws Exception {
		// origin - 25.09.2023, last edit - 13.12.2023
		if (isDev() == true) {
			Abc.test();
			Etc.test();
			Account.test();
			Asset.test();
			Deal.test();
			Debt.test();
			Face.test();
			Geo.test();
			Meter.test();
			Price.test();
			Process.test();
			Report.test();
			Unit.test();
			Workbook.test();
			Slice.test();
			Mark.test();
			Role.test();
			Info.test();
			Sign.test();
			Item.test();
			Model.test();
			ModelDto.test();
			Report.test();
			Output.test();
			Input.test();
			TemplateDoc.test();
			Rule.test();
			DAL.test();
			GUI.test();
			Rule.test();
		}
	}

	public static void writeFile(String pathFile, String fileContent) throws Exception {
		// origin - 19.10.2023, last edit - 06.12.2023
		Path pf = Paths.get(pathFile);
		// try {
		if (isDev()) {
			writeReplace(pf, fileContent);
		} else {
			if (Files.exists(pf)) {
				writeAppend(pf, fileContent);
			} else {
				writeReplace(pf, fileContent);
			}
		}
//		} catch (Exception ex) {
//			Logger.add("WB.writeFile, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace() + ", pathFile="
//					+ pathFile, "", "WB");
//		} finally {
//		}
	}
	
	public static void writeAppend(Path pf, String fileContent) throws Exception {
		// origin - 06.12.2023, last edit - 06.12.2023
		try {
			Files.write(pf, fileContent.toString().getBytes("utf-8"), StandardOpenOption.APPEND);
		} catch (Exception ex) {
			Logger.add("WB.writeAppend, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace() + ", path=" + pf,
					"", "WB");
		} finally {
		}
	}

	public static void writeReplace(Path pf, String fileContent) throws Exception {
		// origin - 06.12.2023, last edit - 06.12.2023
		try {
			Files.write(pf, fileContent.toString().getBytes("utf-8"));
		} catch (Exception ex) {
			Logger.add("WB.writeReplace, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace() + ", path=" + pf,
					"", "WB");
		} finally {
		}
	}

	public static void openFile(String pathFile) throws Exception {
		// origin - 19.10.2023, last edit - 05.12.2023
		if (isDev()) {
			try {
				Desktop.getDesktop().open(new File(pathFile));
			} catch (Exception ex) {
				Logger.add("WB.openFile, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace() + ", pathFile="
						+ pathFile, "", "WB");
			} finally {
			}
		}
	}
	
	private static String getAuthData() {
		// origin - 05.12.2023, last edit - 08.12.2023
		String res = "";
		try {
			res = res + InetAddress.getLocalHost().getHostName()+"\\";
			res = res + System.getProperty("user.name");
		} catch (Exception ex) {
			Logger.add("WB.getAuthData, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "WB");
		} finally {
		}
		Logger.add2("WB.getAuthData, res=" + res, res, "WB");
		return res;
	}
	
	public static boolean hasFile(String dir, String file) throws Exception {
		// origin - 07.12.2023, last edit - 07.12.2023
		boolean res = false;
		try {
			Path checkFilePath = Paths.get(dir + File.separator + file);
			if (Files.exists(checkFilePath)) {
				res = true;
			}
		} catch (Exception ex) {
			Logger.add("WB.hasFile, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "WB");
		} finally {
		}
		Logger.add2("WB.hasFile, res=" + res, "", "WB");
		return res;
	}
	
	public static void exit() throws Exception {
		// origin - 11.12.2023, last edit - 13.12.2023
		int select = JOptionPane.showConfirmDialog(frameBasic, "You want to leave the program ?",
				"Exit question", JOptionPane.YES_NO_OPTION);
		if (select == 0) {
			Logger.add("WB.exit", "", "WB");
			Logger.getFinish();
			System.exit(0);
		}
	}

	public static boolean isDev() throws Exception {
		// origin - 05.12.2023, last edit - 13.12.2023
		boolean res = false;
		try {
			if (hasFile(startDir, ".project")) { //if in startDir exist project Eclipse then isDev = true
				res = true;
			}
		} catch (Exception ex) {
			Logger.add("WB.isDev, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "WB");
		} finally {
		}
		Logger.add2("WB.isDev, res=" + res, "", "WB");
		return res;
	}
}
