import java.time.LocalDateTime;

public class AssetNote {
	// origin - 23.02.2025, last edit - 24.02.2025
	public String table, id, parent, geo, role, info, unit, mark, context;
	public ListVal date1, date2, code, description, more;
	public boolean isValid, isExist;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("AssetNote.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "AssetNote");
		} finally {
			Etc.doNothing();
		}
	}

	public void fix() throws Exception { // TODO
		// origin - 23.02.2025, last edit - 23.02.2025
		try {

		} catch (Exception ex) {
			WB.addLog("AssetNote.fix, ex=" + ex.getMessage(), WB.strEmpty, "AssetNote");
		} finally {
			Etc.doNothing();
		}
	}

	public void isExist() throws Exception {
		// origin - 23.02.2025, last edit - 24.02.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getParentFilter(this.parent), this.table);
			if (listDto.size() != WB.intZero) {
				for (var currDto : listDto) {
					if ((Etc.strEquals(currDto.info, this.context))) {
						this.date1 = new ListVal(currDto.date1, WB.strEmpty);
						this.date2 = new ListVal(currDto.date2, WB.strEmpty);
						this.code = new ListVal(currDto.code);
						this.id = DefVal.setCustom(this.id, currDto.id);
						this.description = new ListVal(currDto.description);
						this.geo = DefVal.setCustom(this.geo, currDto.geo);
						this.role = DefVal.setCustom(this.role, currDto.role);
						this.info = DefVal.setCustom(this.info, currDto.info);
						this.unit = DefVal.setCustom(this.unit, currDto.unit);
						this.more = new ListVal(currDto.more, WB.strEmpty);
						this.mark = DefVal.setCustom(this.mark, currDto.mark);

						this.isExist = true;
						break;
					}
				}
			}

		} catch (Exception ex) {
			WB.addLog("AssetNote.isExist, ex=" + ex.getMessage(), WB.strEmpty, "AssetNote");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("AssetNote.isExist=" + this.isExist, WB.strEmpty,"AssetNote");
	}

	public void isValid() throws Exception { // TODO
		// origin - 23.02.2025, last edit - 24.02.2025
		try {
		} catch (Exception ex) {
			WB.addLog("AssetNote.isValid, ex=" + ex.getMessage(), WB.strEmpty, "AssetNote");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("AssetNote.isValid=" + this.isValid, WB.strEmpty,"AssetNote");
	}

	public AssetNote(String ParentId, String Context) throws Exception {
		// origin - 23.02.2025, last edit - 23.02.2025
		this();
		this.table = "Asset"; // ??magic string??
		this.parent = ParentId;
		this.context = Context;
		this.isExist();
		this.fix();
	}

	public void clear() throws Exception {
		// origin - 23.02.2025, last edit - 24.02.2025
		try {
			this.table = this.id = this.parent = WB.strEmpty;
			this.geo = this.role = this.info = this.unit = this.mark = WB.strEmpty;
			this.date1 = this.date2 = this.code = this.description = this.more = new ListVal();
			this.isValid = true;
			this.isExist = false;
		} catch (Exception ex) {
			WB.addLog("AssetNote.clear, ex=" + ex.getMessage(), WB.strEmpty, "AssetNote");
		} finally {
			Etc.doNothing();
		}
	}

	public AssetNote() throws Exception {
		// origin - 23.02.2025, last edit - 23.02.2025
		this.clear();
	}

	public String toString() {
		// origin - 23.02.2025, last edit - 23.02.2025
		String res = WB.strEmpty;
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);

			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", ", this.unit);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.id);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
			// WB.addLog2("AssetNote.toString, ex=" + ex.getMessage(), WB.strEmpty,
			// "AssetNote");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 23.02.2025, last edit - 24.02.2025
		try {
//			// ctor()
//			WB.addLog2("AssetNote.test.ctor()=" + new AssetNote(), WB.strEmpty, "AssetNote");

			// ctor (String, String)
			for (var ctorArg1 : new String[] { "Asset.Test.1" }) {
				for (var ctorArg2 : new String[] { Asset.infoPrice }) {
					LocalDateTime localStart = WB.getLocalStart();
					WB.addLog2("AssetNote.test.ctor(String, String)=" + new AssetNote(ctorArg1, ctorArg2), WB.strEmpty,
							"AssetNote");
					WB.getLocalEnd(
							"AssetNote.test.ctor(String, String), parentId=" + ctorArg1 + ", context=" + ctorArg2,
							localStart);
				}
			}

		} catch (Exception ex) {
			WB.addLog("AssetNote.test, ex=" + ex.getMessage(), WB.strEmpty, "AssetNote");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("AssetNote.test end ", WB.strEmpty, "AssetNote");
	}
}