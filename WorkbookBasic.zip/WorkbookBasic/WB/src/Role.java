public class Role extends Model {
	// origin - 06.12.2023, last edit - 18.01.2024
	public static Role root;
	public Role parent;
    
    static {
		root = new Role("Role","Role","RoleData");
	}
    
    public Role(String Id, String Code, String Description) {
		// origin - 06.12.2023, last edit - 06.12.2023
		this.id = Id;
		this.code = Code;
		this.description = Description;
	}
    
    public Role() {
		// origin - 06.12.2023, last edit - 06.12.2023
	}
    
    public static void test() throws Exception {
		// origin - 06.12.2023, last edit - 27.06.2024
    	WB.addLog("Role.test, Role.root=" + Role.root, WB.strEmpty, "Role");
	}
}
