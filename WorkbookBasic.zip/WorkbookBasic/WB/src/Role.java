public class Role extends Model {
	// origin - 06.12.2023, last edit - 06.07.2024
	public Role parent;

	public Role(String Id, String Code, String Description) throws Exception {
		// origin - 06.12.2023, last edit - 07.07.2024
		try {
			this.id = Id;
			this.code = Code;
			this.description = Description;
		} catch (Exception ex) {
			WB.addLog("Role.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Role");
		} finally {
			Etc.doNothing();
		}
	}

	public Role() throws Exception {
		// origin - 06.12.2023, last edit - 07.07.2024
		try {
		} catch (Exception ex) {
			WB.addLog("Role.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Role");
		} finally {
			Etc.doNothing();
		}
	}

	public static void test() throws Exception {
		// origin - 06.12.2023, last edit - 06.07.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Role.test, ex=" + ex.getMessage(), WB.strEmpty, "Role");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Role.test end ", WB.strEmpty, "Role");
	}
}
