import java.util.List;

public class Role extends ModelDto {
	// origin - 06.12.2023, last edit - 17.02.2025
	public static String priceExchangeCurrency, accountStandardTable, priceBasic, dealBasic, assetGood, genericBasic,
			genericComposite;

	static {
		Role.priceExchangeCurrency = "Role.Price.ExchangeCurrency";
		Role.accountStandardTable = "Role.Account.AccTable";
		Role.priceBasic = "Role.Price.Basic";
		Role.dealBasic = "Role.Deal.Basic";
		Role.assetGood = "Role.Asset.Good";
		Role.genericBasic = "Role.Generic.Basic";
		Role.genericComposite = "Role.Generic.Composite";
		try {
		} catch (Exception ex) {
			WB.addLog("Role.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Role");
		} finally {
			Etc.doNothing();
		}
	}

	public void isExist() throws Exception {
		// origin - 17.12.2024, last edit - 17.12.2024
		super.isExist();
		try {
			for (var currRole : WB.abcLast.role) {
				if (Etc.strEquals(currRole.id, this.id)) {
					this.slice = DefVal.setCustom(this.slice, currRole.slice);
					this.date1 = DefVal.setCustom(DateTool.getNow().toString(), currRole.date1);// this.date1,
					this.date2 = DefVal.setCustom(this.date2, currRole.date2);
					this.code = DefVal.setCustom(this.code, currRole.code);
					this.parent = DefVal.setCustom(this.parent, currRole.parent);
					this.description = DefVal.setCustom(this.description, currRole.description);
					this.more = DefVal.setCustom(this.more, currRole.more);

					this.isExist = true;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Role.isExist, ex=" + ex.getMessage(), WB.strEmpty, "Role");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Role.isExist=" + this.isExist, WB.strEmpty,"Role");
	}

	public void isValid() throws Exception {
		// origin - 17.12.2024, last edit - 17.12.2024
		super.isValid();
		try {
			if (this.date1.isEmpty()) {
				this.isValid = false;
			}
		} catch (Exception ex) {
			WB.addLog("Role.isValid, ex=" + ex.getMessage(), WB.strEmpty, "Role");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Role.isValid=" + this.isValid, WB.strEmpty,"Role");
	}

	public Role(String Id) throws Exception {
		// origin - 06.12.2023, last edit - 27.12.2024
		this();
		this.src = Id;
		if (Id.isEmpty() == false) {
			this.id = this.code = Id;
		}
		// this.date1 = DateTool.getNow().toString();
		this.isExist();
		this.isValid();
	}

	public Role() throws Exception {
		// origin - 06.12.2023, last edit - 17.12.2024
		this.clear();
		this.isExist();
		var root = Abc.getRoot(this.table);
		this.id = root.id;
		this.parent = root.parent;
		this.date1 = root.date1;
		this.date2 = root.date2;
		this.code = root.code;
		this.description = root.description;
		this.more = root.more;
	}

	public void clear() throws Exception {
		// origin - 09.12.2024, last edit - 17.12.2024
		try {
			super.clear();
			this.table = this.getClass().getName();
		} catch (Exception ex) {
			WB.addLog("Role.clear, ex=" + ex.getMessage(), WB.strEmpty, "Role");
		} finally {
			Etc.doNothing();
		}
	}

	public String toString() {
		// origin - 27.09.2024, last edit - 17.12.2024
		String res = WB.strEmpty;
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", ", this.slice);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	@SuppressWarnings("unused")
	public static void test() throws Exception {
		// origin - 06.12.2023, last edit - 27.12.2024
		try {
			var tmpList = List.of(WB.strEmpty, "Role.Asset", "Role.tralala", "Role.Deal");

//			// ctor (String Id)
//			for (var tmp : tmpList) {
//				WB.addLog2("Role.test.ctor(String)=" + new Role(tmp.id), WB.strEmpty, "Role");
//			}

		} catch (Exception ex) {
			WB.addLog("Role.test, ex=" + ex.getMessage(), WB.strEmpty, "Role");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Role.test end ", WB.strEmpty, "Role");
	}
}
