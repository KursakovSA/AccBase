public final class PaymentTerm { // TODO
	// origin - 28.08.2025, last edit - 12.10.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, face1, face2, face, date1, date2, code, description, geo, role, info, more,
			mark;
	// special fields
	public String fullName, comment, templateId, termId;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("PaymentTerm.static ctor, ex=" + ex.getMessage(), "", "PaymentTerm");
		}
	}

	private void isExist() throws Exception {// TODO
		// origin - 28.08.2025, last edit - 07.09.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), "Deal");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.code = dto.code;
				this.parent = dto.parent;
				this.face1 = dto.face1;
				this.face2 = dto.face2;
				this.face = dto.face;
				this.description = dto.description;
				this.geo = dto.geo;
				this.role = dto.role;
				this.info = dto.info;
				this.more = dto.more;
				this.getFieldFromMore();
				this.isExist = true;
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("PaymentTerm.isExist():void, ex=" + ex.getMessage(), "", "PaymentTerm");
		}
	}

	public PaymentTerm(String Id) throws Exception {// TODO
		// origin - 28.08.2025, last edit - 28.08.2025
		this.clear();
		this.src = this.id = this.code = Id;
		this.isExist();
	}

	public PaymentTerm() throws Exception {// TODO
		// origin - 28.08.2025, last edit - 28.08.2025
		this.clear();
	}

	public String toString() {// TODO
		// origin - 28.08.2025, last edit - 03.09.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code.length());
			res = res + Fmtr.addIfNotEmpty(", description ", this.description.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", templateId ", this.templateId);
			res = res + Fmtr.addIfNotEmpty(", termId ", this.termId);
			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
		    res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	private void getFieldFromMore() throws Exception {// TODO
		// origin - 28.08.2025, last edit - 03.09.2025
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.templateId = MoreVal.getFieldByKey(this.more, "TemplateId");
			this.termId = MoreVal.getFieldByKey(this.more, "TermId");
		} catch (Exception ex) {
			WB.addLog("PaymentTerm.getFieldFromMore():void, ex=" + ex.getMessage(), "", "PaymentTerm");
		}
	}

	@SuppressWarnings("unused")
	private String getMoreFromField() throws Exception {// TODO
		// origin - 28.08.2025, last edit - 03.09.2025
		String res = "";
		try {
			res = res + MoreVal.setPartMore("FullName", this.fullName);
			res = res + MoreVal.setPartMore("Comment", this.termId);
			res = res + MoreVal.setPartMore("TempalteId", this.templateId);
			res = res + MoreVal.setPartMore("TermId", this.termId);
		} catch (Exception ex) {
			WB.addLog("PaymentTerm.getMoreFromField():String, ex=" + ex.getMessage(), "", "PaymentTerm");
		}
		return res;
	}

	private void clear() throws Exception {// TODO
		// origin - 28.08.2025, last edit - 06.09.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = "Deal";
			this.id = this.parent = this.date1 = this.date2 = this.face1 = this.face2 = this.face = this.code = this.description = "";
			this.geo = this.role = this.info = this.more = this.mark = "";
			this.fullName = this.comment = this.templateId = this.termId = "";
		} catch (Exception ex) {
			WB.addLog("PaymentTerm.clear():void, ex=" + ex.getMessage(), "", "PaymentTerm");
		}
	}

	public static void test() throws Exception {// TODO
		// origin - 28.08.2025, last edit - 02.09.2025
		try {

//			WB.addLog2("PaymentTerm.test.ctor(String)", "", "PaymentTerm");
//			for (var tmp : new String[] { "", "PawnDoc.Template1.V1.Term1", "PawnDoc.Template1.V1.Term2" }) {
//				WB.addLog2("PaymentTerm.test.ctor(string)=" + new PaymentTerm(tmp), "", "PaymentTerm");
//			}

		} catch (Exception ex) {
			WB.addLog("PaymentTerm.test():void, ex=" + ex.getMessage(), "", "PaymentTerm");
		}
	}
}