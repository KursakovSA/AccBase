import java.util.List;

public final class DealTerm {
	// origin - 25.08.2025, last edit - 20.11.2025
	// common fields
	public String table, src, id, parent, face1, face2, face, date1, date2, code, description, geo, role, info, more,
			mark, defect;
	// special fields
	public String fullName, comment, templateId, termId;
	// term fields
	public ProlongationTerm prolongationTerm;
	public ShipmentTerm shipmentTerm;
	public DeliveryTerm deliveryTerm;
	public PaymentTerm paymentTerm;
	public PriceTerm priceTerm;
	public AddTerm addTerm;
	public TemplateDocTerm templateDocTerm;
	// root branch fields
	public List<ModelDto> lower, upper;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("DealTerm.static ctor, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}

	private void validate() throws Exception {
		// origin - 14.09.2025, last edit - 20.11.2025
		try {
			if (this.shipmentTerm.defect.isEmpty()) {
				this.defect = this.defect + "defect shipmentTerm; ";
			}
			if (this.deliveryTerm.defect.isEmpty() == false) {
				this.defect = this.defect + "defect deliveryTerm; ";
			}
			if (this.paymentTerm.defect.isEmpty() == false) {
				this.defect = this.defect + "defect paymentTerm; ";
			}
			if (this.priceTerm.defect.isEmpty() == false) {
				this.defect = this.defect + "defect priceTerm; ";
			}
			if (this.templateDocTerm.defect.isEmpty() == false) {
				this.defect = this.defect + "defect templateDocTerm; ";
			}
			if (this.termId.isEmpty()) {
				this.defect = this.defect + "empty termId; ";
			}
			if (this.templateId.isEmpty()) {
				this.defect = this.defect + "empty templateId; ";
			}
		} catch (Exception ex) {
			WB.addLog("DealTerm.validate():void, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}

	private void isExist() throws Exception {
		// origin - 25.08.2025, last edit - 20.11.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), "Deal");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.code = dto.code;
				this.parent = dto.parent;
				this.face1 = dto.face1;
				this.face2 = dto.face2;
				this.face = dto.face;
				this.description = dto.description;
				this.geo = dto.geo;
				this.role = dto.role;
				this.info = dto.info;
				this.more = dto.more;
				this.mark = dto.mark;
				var listDto2 = DAL.getTable(WB.lastConnWork, Qry.getText(WB.lastConnWork, "Deal", ""));
				this.upper = ModelDto.getUpper(listDto2, this.parent);
				this.lower = ModelDto.getLower(listDto2, this.code);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("DealTerm.isExist():void, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}

	private void getFieldFromMore() throws Exception { // TODO
		// origin - 30.08.2025, last edit - 16.09.2025
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.templateId = MoreVal.getFieldByKey(this.more, "TemplateId");
			this.termId = MoreVal.getFieldByKey(this.more, "TermId");
			this.prolongationTerm = new ProlongationTerm(this.lower);
			this.templateDocTerm = new TemplateDocTerm(this.templateId);
			this.addTerm = new AddTerm(this.termId);
		} catch (Exception ex) {
			WB.addLog("DealTerm.getFieldFromMore():void, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}

	public DealTerm(String Id) throws Exception { // TODO
		// origin - 25.08.2025, last edit - 20.11.2025
		this.clear();
		this.src = this.id = this.code = Id;
		this.isExist();
		this.validate();
	}

	public DealTerm() throws Exception {
		// origin - 25.08.2025, last edit - 25.08.2025
		this.clear();
	}

	public String toString() {
		// origin - 25.08.2025, last edit - 20.11.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code.length());
			res = res + Fmtr.addIfNotEmpty(", description ", this.description.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addAnyway(", shipmentTerm.defect ", this.shipmentTerm.defect);
			res = res + Fmtr.addAnyway(", deliveryTerm.defect ", this.deliveryTerm.defect);
			res = res + Fmtr.addAnyway(", paymentTerm.defect ", this.paymentTerm.defect);
			res = res + Fmtr.addAnyway(", prolongationTerm.defect ", this.prolongationTerm.defect);
			res = res + Fmtr.addAnyway(", priceTerm.defect ", this.priceTerm.defect);
			res = res + Fmtr.addAnyway(", addTerm.description ", this.addTerm.description);
			res = res + Fmtr.addAnyway(", templateDocTerm.defect ", this.templateDocTerm.defect);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	private void clear() throws Exception {
		// origin - 25.08.2025, last edit - 20.11.2025
		try {
			this.table = "Deal";
			this.id = this.parent = this.date1 = this.date2 = this.face1 = this.face2 = this.face = this.code = this.description = "";
			this.geo = this.role = this.info = this.more = this.mark = this.defect = "";
			this.fullName = this.comment = this.templateId = this.termId = "";
			this.prolongationTerm = new ProlongationTerm();
			this.templateDocTerm = new TemplateDocTerm();
			this.shipmentTerm = new ShipmentTerm();
			this.deliveryTerm = new DeliveryTerm();
			this.paymentTerm = new PaymentTerm();
			this.priceTerm = new PriceTerm();
			this.addTerm = new AddTerm();
		} catch (Exception ex) {
			WB.addLog("DealTerm.clear():void, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}

	public static void test() throws Exception { // TODO
		// origin - 25.08.2025, last edit - 08.10.2025
		try {

//			WB.addLog2("DealTerm.test.ctor(String)", "", "DealTerm");
//			for (var tmp1 : new String[] { "", "PawnDoc.Template1.V1.Term1", "PawnDoc.Template1.V1.Term2",
//					"Term.tralala" }) {
//				WB.addLog2("DealTerm.test.ctor(String)=" + new DealTerm(tmp1), "", "DealTerm");
//			}

		} catch (Exception ex) {
			WB.addLog("DealTerm.test():void, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}
}