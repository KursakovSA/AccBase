import java.util.List;

public class DealTerm {
	// origin - 25.08.2025, last edit - 16.09.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, face1, face2, face, date1, date2, code, description, geo, role, info, more,
			mark;
	// special fields
	public String fullName, comment, templateId, termId;
	// term fields
	public ProlongationTerm prolongationTerm;
	public ShipmentTerm shipmentTerm;
	public DeliveryTerm deliveryTerm;
	public PaymentTerm paymentTerm;
	public PriceTerm priceTerm;
	public AddTerm addTerm;
	public TemplateDocTerm templateDocTerm;
	// root branch fields
	public List<ModelDto> lower, upper;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("DealTerm.static ctor, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}

	private void isValid() throws Exception {
		// origin - 14.09.2025, last edit - 14.09.2025
		try {
			this.isTermValid();
			this.isFieldValid();
		} catch (Exception ex) {
			WB.addLog("DealTerm.isValid():void, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}

	private void isFieldValid() throws Exception { // TODO
		// origin - 14.09.2025, last edit - 14.09.2025
		try {
//			if ((this.mainDebtToEstimatedValueLimit.val2 == 0.0) || (this.durationDealLimit.val2 == 0.0)
//			|| (this.durationWarrantySpan.val == 0.0)) {
//		this.isValid = false;
//	}
		} catch (Exception ex) {
			WB.addLog("DealTerm.isFieldValid():void, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}

	private void isTermValid() throws Exception {
		// origin - 14.09.2025, last edit - 15.09.2025
		try {
			if ((this.shipmentTerm.isValid) & (this.deliveryTerm.isValid) & (this.paymentTerm.isValid)
					& (this.priceTerm.isValid) & (this.templateDocTerm.isValid)) {
				this.isValid = true;
			}
		} catch (Exception ex) {
			WB.addLog("DealTerm.isTermValid():void, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}

	private void isExist() throws Exception {
		// origin - 25.08.2025, last edit - 13.09.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), "Deal");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.code = dto.code;
				this.parent = dto.parent;
				this.face1 = dto.face1;
				this.face2 = dto.face2;
				this.face = dto.face;
				this.description = dto.description;
				this.geo = dto.geo;
				this.role = dto.role;
				this.info = dto.info;
				this.more = dto.more;
				this.mark = dto.mark;

				var listDto2 = DAL.getTable(WB.lastConnWork, Qry.getText(WB.lastConnWork, "Deal", ""));
				this.upper = ModelDto.getUpper(listDto2, this.parent);
				this.lower = ModelDto.getLower(listDto2, this.code);

				this.getFieldFromMore();
				this.isExist = true;
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("DealTerm.isExist():void, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}

	private void getFieldFromMore() throws Exception { // TODO
		// origin - 30.08.2025, last edit - 16.09.2025
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.templateId = MoreVal.getFieldByKey(this.more, "TemplateId");
			this.termId = MoreVal.getFieldByKey(this.more, "TermId");
			this.prolongationTerm = new ProlongationTerm(this.lower);
			this.templateDocTerm = new TemplateDocTerm(this.templateId);
			this.addTerm = new AddTerm(this.termId);
		} catch (Exception ex) {
			WB.addLog("DealTerm.getFieldFromMore():void, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}

	public DealTerm(String Id) throws Exception { // TODO
		// origin - 25.08.2025, last edit - 14.09.2025
		this.clear();
		this.src = this.id = this.code = Id;
		this.isExist();
		this.isValid();
	}

	public DealTerm() throws Exception {
		// origin - 25.08.2025, last edit - 25.08.2025
		this.clear();
	}

	public String toString() {
		// origin - 25.08.2025, last edit - 14.09.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code.length());
			res = res + Fmtr.addIfNotEmpty(", description ", this.description.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addAnyway(", shipmentTerm.isValid ", this.shipmentTerm.isValid);
			res = res + Fmtr.addAnyway(", deliveryTerm.isValid ", this.deliveryTerm.isValid);
			res = res + Fmtr.addAnyway(", paymentTerm.isValid ", this.paymentTerm.isValid);
			res = res + Fmtr.addAnyway(", prolongationTerm.isValid ", this.prolongationTerm.isValid);
			res = res + Fmtr.addAnyway(", priceTerm.isValid ", this.priceTerm.isValid);
			res = res + Fmtr.addAnyway(", addTerm.description ", this.addTerm.description);
			res = res + Fmtr.addAnyway(", templateDocTerm.isValid ", this.templateDocTerm.isValid);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	private void clear() throws Exception {
		// origin - 25.08.2025, last edit - 16.09.2025
		try {
			this.isValid = false;
			this.isExist = false;
			this.table = "Deal";
			this.id = this.parent = this.date1 = this.date2 = this.face1 = this.face2 = this.face = this.code = this.description = "";
			this.geo = this.role = this.info = this.more = this.mark = "";
			this.fullName = this.comment = this.templateId = this.termId = "";

			this.prolongationTerm = new ProlongationTerm();
			this.templateDocTerm = new TemplateDocTerm();
			this.shipmentTerm = new ShipmentTerm();
			this.deliveryTerm = new DeliveryTerm();
			this.paymentTerm = new PaymentTerm();
			this.priceTerm = new PriceTerm();
			this.addTerm = new AddTerm();
		} catch (Exception ex) {
			WB.addLog("DealTerm.clear():void, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}

	public static void test() throws Exception { // TODO
		// origin - 25.08.2025, last edit - 07.09.2025
		try {

//			WB.addLog2("DealTerm.test.ctor(String)", "", "DealTerm");
//			for (var ctorStringArg1 : new String[] { "", "PawnDoc.Template1.V1.Term1", "PawnDoc.Template1.V1.Term2",
//					"Term.tralala" }) {
//				WB.addLog2("DealTerm.test.ctor(string)=" + new DealTerm(ctorStringArg1), "", "DealTerm");
//			}

		} catch (Exception ex) {
			WB.addLog("DealTerm.test():void, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}
}