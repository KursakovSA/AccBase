public final class AddTerm {
	// origin - 03.09.2025, last edit - 20.11.2025
	// common fields
	public String table, src, id, parent, face1, face2, face, date1, date2, code, description, geo, role, info, more,
			mark, defect;
	// special fields
	public String fullName, comment, templateId, termId;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("AddTerm.static ctor, ex=" + ex.getMessage(), "", "AddTerm");
		}
	}

	private void validate() throws Exception { // TODO
		// origin - 20.11.2025, last edit - 20.11.2025
		try {
			if (this.termId.isEmpty()) {
				this.defect = this.defect + "empty termId; ";
			}
			if (this.templateId.isEmpty()) {
				this.defect = this.defect + "empty templateId; ";
			}
		} catch (Exception ex) {
			WB.addLog("Staff.validate():void, ex=" + ex.getMessage(), "", "Staff");
		}
	}

	private void isExist() throws Exception {
		// origin - 03.09.2025, last edit - 20.11.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getIdRoleInfoFilter(this.id, "Role.Deal.Term", "Info.Deal.Term"), "Deal");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.code = dto.code;
				this.parent = dto.parent;
				this.face1 = dto.face1;
				this.face2 = dto.face2;
				this.face = dto.face;
				this.description = dto.description;
				this.geo = dto.geo;
				this.role = dto.role;
				this.info = dto.info;
				this.more = dto.more;
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("AddTerm.isExist():void, ex=" + ex.getMessage(), "", "AddTerm");
		}
	}

	public AddTerm(String Id) throws Exception {
		// origin - 03.09.2025, last edit - 20.11.2025
		this.clear();
		this.src = this.id = this.code = Id;
		this.isExist();
		this.validate();
	}

	public AddTerm() throws Exception {
		// origin - 03.09.2025, last edit - 13.09.2025
		this.clear();
	}

	public String toString() {
		// origin - 03.09.2025, last edit - 20.11.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code.length());
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", templateId ", this.templateId);
			res = res + Fmtr.addIfNotEmpty(", termId ", this.termId);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	private void getFieldFromMore() throws Exception {
		// origin - 03.09.2025, last edit - 14.09.2025
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.templateId = MoreVal.getFieldByKey(this.more, "TemplateId");
			this.termId = MoreVal.getFieldByKey(this.more, "TermId");
			this.description = MoreVal.getFieldByKey(this.more, "AddTerm"); // content AddTerm write into
																			// this.description
		} catch (Exception ex) {
			WB.addLog("AddTerm.getFieldFromMore():void, ex=" + ex.getMessage(), "", "AddTerm");
		}
	}

	private void clear() throws Exception {
		// origin - 03.09.2025, last edit - 20.11.2025
		try {
			this.table = "Deal";
			this.id = this.parent = this.date1 = this.date2 = this.face1 = this.face2 = this.face = this.code = this.description = "";
			this.geo = this.role = this.info = this.more = this.mark = this.defect = "";
			this.fullName = this.comment = this.templateId = this.termId = "";
		} catch (Exception ex) {
			WB.addLog("AddTerm.clear():void, ex=" + ex.getMessage(), "", "AddTerm");
		}
	}

	public static void test() throws Exception {
		// origin - 03.09.2025, last edit - 08.10.2025
		try {

//			WB.addLog2("AddTerm.test.ctor(String)", "", "AddTerm");
//			for (var tmp : new String[] { "PawnDoc.Template1.V1.Term1", "PawnDoc.Template1.V1.Term2" }) {
//				WB.addLog2("AddTerm.test.ctor(String)=" + new AddTerm(tmp), "", "AddTerm");
//			}

		} catch (Exception ex) {
			WB.addLog("AddTerm.test():void, ex=" + ex.getMessage(), "", "AddTerm");
		}
	}
}