import java.util.List;

public class ProlongationTerm {
	// origin - 28.08.2025, last edit - 03.09.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, face1, face2, face, date1, date2, code, description, geo, role, info, more,
			mark;
	// special fields
	public String fullName, comment, templateId, termId;
	public RangeVal countLimit;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("ProlongationTerm.static ctor, ex=" + ex.getMessage(), "", "ProlongationTerm");
		}
	}

	private void isValid() throws Exception {
		// origin - 08.09.2025, last edit - 15.09.2025
		try {
			if (this.isExist) {
				if (this.countLimit.val2 != 0) {
					this.isValid = true;
				}
			}
		} catch (Exception ex) {
			WB.addLog("ProlongationTerm.isValid():void, ex=" + ex.getMessage(), "", "ProlongationTerm");
		}
	}

	public static boolean isProlongationTerm(String role, String info) throws Exception {
		// origin - 30.08.2025, last edit - 15.09.2025
		boolean res = false;
		try {
			if ((Etc.strEquals(role, "Role.Deal.Prolongation")) && (Etc.strEquals(info, "Info.Deal.Term"))) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("ProlongationTerm.isProlongationTerm(2string), ex=" + ex.getMessage(), "", "ProlongationTerm");
		}
		return res;
	}

	private void isExist() throws Exception {
		// origin - 28.08.2025, last edit - 15.09.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getIdRoleInfoFilter(this.id, "Role.Deal.Prolongation", "Info.Deal.Term"), "Deal");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.code = dto.code;
				this.parent = dto.parent;
				this.face1 = dto.face1;
				this.face2 = dto.face2;
				this.face = dto.face;
				this.description = dto.description;
				this.geo = dto.geo;
				this.role = dto.role;
				this.info = dto.info;
				this.more = dto.more;
				this.getFieldFromMore();
				this.isExist = true;
			}
		} catch (Exception ex) {
			WB.addLog("ProlongationTerm.isExist():void, ex=" + ex.getMessage(), "", "ProlongationTerm");
		}
	}

	// get new ProlongationTerm by List<ModelDto>,... without isExist
	public ProlongationTerm(List<ModelDto> listModelDto) throws Exception {
		// origin - 30.08.2025, last edit - 08.09.2025
		this.clear();
		for (var currModelDto : listModelDto) {
			if (isProlongationTerm(currModelDto.role, currModelDto.info)) {
				var dDto = new DealDto(currModelDto);
				this.src = this.id = dDto.id;
				this.parent = dDto.parent;
				this.face1 = dDto.face1;
				this.face2 = dDto.face2;
				this.face = dDto.face;
				this.date1 = dDto.date1;
				this.date2 = dDto.date2;
				this.code = dDto.code;
				this.description = dDto.description;
				this.geo = dDto.geo;
				this.role = dDto.role;
				this.info = dDto.info;
				this.more = dDto.more;
				this.getFieldFromMore();
				this.mark = dDto.mark;
				this.isValid();
			}
		}
	}

	// get new ProlongationTerm by DealDto.id,... without isExist
	public ProlongationTerm(DealDto dDto) throws Exception {
		// origin - 28.08.2025, last edit - 08.09.2025
		this.clear();
		this.src = this.id = dDto.id;
		this.parent = dDto.parent;
		this.face1 = dDto.face1;
		this.face2 = dDto.face2;
		this.face = dDto.face;
		this.date1 = dDto.date1;
		this.date2 = dDto.date2;
		this.code = dDto.code;
		this.description = dDto.description;
		this.geo = dDto.geo;
		this.role = dDto.role;
		this.info = dDto.info;
		this.more = dDto.more;
		this.getFieldFromMore();
		this.mark = dDto.mark;
		this.isValid();
	}

	// get new ProlongationTerm by id, parent,... without isExist
	public ProlongationTerm(String Id, String Parent, String Face1, String Face2, String Face, String Date1,
			String Date2, String Code, String Description, String Geo, String Role, String Info, String More,
			String Mark) throws Exception {
		// origin - 28.08.2025, last edit - 08.09.2025
		this.clear();
		this.src = this.id = Id;
		this.parent = Parent;
		this.face1 = Face1;
		this.face2 = Face2;
		this.face = Face;
		this.date1 = Date1;
		this.date2 = Date2;
		this.code = Code;
		this.description = Description;
		this.geo = Geo;
		this.role = Role;
		this.info = Info;
		this.more = More;
		this.getFieldFromMore();
		this.mark = Mark;
		this.isValid();
	}

	public ProlongationTerm(String ProlongationTermId) throws Exception {
		// origin - 28.08.2025, last edit - 16.09.2025
		this.clear();
		this.src = this.id = ProlongationTermId;
		this.isExist();
		this.isValid();
	}

	public ProlongationTerm() throws Exception {
		// origin - 28.08.2025, last edit - 28.08.2025
		this.clear();
	}

	public String toString() {
		// origin - 28.08.2025, last edit - 28.08.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code.length());
			res = res + Fmtr.addIfNotEmpty(", description ", this.description.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addIfNotEmpty(", templateId ", this.templateId);
			res = res + Fmtr.addIfNotEmpty(", termId ", this.termId);

			res = res + Fmtr.addAnyway(", countLimit ", this.countLimit.id);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	private void getFieldFromMore() throws Exception {
		// origin - 28.08.2025, last edit - 16.09.2025
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.templateId = MoreVal.getFieldByKey(this.more, "TemplateId");
			this.termId = MoreVal.getFieldByKey(this.more, "TermId");
			this.countLimit = new RangeVal(MoreVal.getFieldByKey(this.more, "CountLimit"));
		} catch (Exception ex) {
			WB.addLog("ProlongationTerm.getFieldFromMore():void, ex=" + ex.getMessage(), "", "ProlongationTerm");
		}
	}

	private void clear() throws Exception {
		// origin - 28.08.2025, last edit - 15.09.2025
		try {
			this.isValid = false;
			this.isExist = false;
			this.table = "Deal";
			this.id = this.parent = this.date1 = this.date2 = this.face1 = this.face2 = this.face = this.code = this.description = "";
			this.geo = this.role = this.info = this.more = this.mark = "";
			this.fullName = this.comment = this.templateId = this.termId = "";
			this.countLimit = new RangeVal("0.0 - 0.0(Unit.Once)");
		} catch (Exception ex) {
			WB.addLog("ProlongationTerm.clear():void, ex=" + ex.getMessage(), "", "ProlongationTerm");
		}
	}

	public static void test() throws Exception {
		// origin - 28.08.2025, last edit - 30.08.2025
		try {

//			WB.addLog2("ProlongationTerm.test.ctor(String)", "", "ProlongationTerm");
//			for (var tmp : new String[] { "", "PawnDoc.Template1.V1.Term1.Prolongation",
//					"PawnDoc.Template1.V1.Term2.Prolongation", "ProlongationTerm.tralala" }) {
//				WB.addLog2("ProlongationTerm.test.ctor(string)=" + new ProlongationTerm(tmp), "", "ProlongationTerm");
//			}

		} catch (Exception ex) {
			WB.addLog("ProlongationTerm.test():void, ex=" + ex.getMessage(), "", "ProlongationTerm");
		}
	}
}