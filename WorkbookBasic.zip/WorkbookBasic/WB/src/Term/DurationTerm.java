public final class DurationTerm {
	// origin - 26.01.2026, last edit - 28.01.2026
	// common fields
	public String table, src, id, parent, face1, face2, face, date1, date2, code, description, geo, role, info, more,
			mark, defect;
	// special fields
	public String fullName, comment, templateId, termId;
	public UnitVal dealLimit, prolongationLimit, warrantyLimit;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("DurationTerm.static ctor, ex=" + ex.getMessage(), "", "DurationTerm");
		}
	}

	private void validate() throws Exception { // TODO
		// origin - 26.01.2026, last edit - 28.01.2026
		try {
			if (this.src.isEmpty() == false) {
				if (this.termId.isEmpty()) {
					this.defect = this.defect + "empty termId; ";
				}
				if (this.templateId.isEmpty()) {
					this.defect = this.defect + "empty templateId; ";
				}
				if (Etc.strEquals(this.dealLimit.partVal, "0.0") == true) {
					this.defect = this.defect + "dealLimit==0.0; ";
				}
			}
		} catch (Exception ex) {
			WB.addLog("DurationTerm.validate():void, ex=" + ex.getMessage(), "", "DurationTerm");
		}
	}

	private void isExist() throws Exception {
		// origin - 26.01.2026, last edit - 26.01.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleInfoFilter(this.parent, "Role.Deal.Duration", "Info.Deal.Term"), "Deal");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.id = dto.id;
				this.code = dto.code;
				// this.parent = dto.parent;
				this.face1 = dto.face1;
				this.face2 = dto.face2;
				this.face = dto.face;
				this.description = dto.description;
				this.geo = dto.geo;
				this.role = dto.role;
				this.info = dto.info;
				this.more = dto.more;
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("DurationTerm.isExist():void, ex=" + ex.getMessage(), "", "DurationTerm");
		}
	}

	public DurationTerm(String Parent) throws Exception {
		// origin - 26.01.2026, last edit - 26.01.2026
		this.clear();
		this.src = this.parent = Etc.fixTrim(Parent);
		this.isExist();
		this.validate();
	}

	public DurationTerm() throws Exception {
		// origin - 26.01.2026, last edit - 26.01.2026
		this.clear();
	}

	public String toString() {
		// origin - 26.01.2026, last edit - 28.01.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", templateId ", this.templateId);
			res = res + Fmtr.addIfNotEmpty(", termId ", this.termId);
			// if (this.src.isEmpty() == false) {
			res = res + Fmtr.addIfNotEmpty(", dealLimit.id ", this.dealLimit.id);
			res = res + Fmtr.addIfNotEmpty(", prolongationLimit.id ", this.prolongationLimit.id);
			res = res + Fmtr.addIfNotEmpty(", warrantyLimit.id ", this.warrantyLimit.id);
			// }
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	private void getFieldFromMore() throws Exception {
		// origin - 26.01.2026, last edit - 28.01.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.templateId = MoreVal.getFieldByKey(this.more, "TemplateId");
			this.termId = MoreVal.getFieldByKey(this.more, "TermId");
			this.dealLimit = new UnitVal(MoreVal.getFieldByKey(this.more, "DealLimit"));
			this.prolongationLimit = new UnitVal(MoreVal.getFieldByKey(this.more, "ProlongationLimit"));
			this.warrantyLimit = new UnitVal(MoreVal.getFieldByKey(this.more, "WarrantyLimit"));
		} catch (Exception ex) {
			WB.addLog("DurationTerm.getFieldFromMore():void, ex=" + ex.getMessage(), "", "DurationTerm");
		}
	}

	private void clear() throws Exception {
		// origin - 26.01.2026, last edit - 28.01.2026
		try {
			this.table = "Deal";
			this.src = this.id = this.parent = this.date1 = this.date2 = this.face1 = this.face2 = this.face = this.code = this.description = "";
			this.geo = this.role = this.info = this.more = this.mark = this.defect = "";
			this.fullName = this.comment = this.templateId = this.termId = "";
			this.dealLimit = new UnitVal("0.0(Unit.CalendarDay)");// UnitVal.calendarDayInit);
			this.prolongationLimit = new UnitVal("0.0(Unit.Once)");
			this.warrantyLimit = new UnitVal("0.0(Unit.CalendarDay)");// UnitVal.calendarDayInit);
		} catch (Exception ex) {
			WB.addLog("DurationTerm.clear():void, ex=" + ex.getMessage(), "", "DurationTerm");
		}
	}

	public static void test() throws Exception {
		// origin - 26.01.2026, last edit - 28.01.2026
		try {

//			WB.addLog2("DurationTerm.test.ctor(String)", "", "DurationTerm");
//			for (var tmp : new String[] { "", "PawnDoc.Template1.V1.Term1", "PawnDoc.Template1.V1.Term2" }) {
//				WB.addLog2("DurationTerm.test.ctor(String)=" + new DurationTerm(tmp), "", "DurationTerm");
//			}

		} catch (Exception ex) {
			WB.addLog("DurationTerm.test():void, ex=" + ex.getMessage(), "", "DurationTerm");
		}
	}
}