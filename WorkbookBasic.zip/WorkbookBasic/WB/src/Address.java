import java.util.ArrayList;
import java.util.List;

public class Address {
	// origin - 07.03.2025, last edit - 30.03.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, code, description, geo, role, info, mark;
	// special fields - no
	// special timestamp fields
	private ListVal date1, date2, more;
	//list common + special + timestamp fields in unified val
	public List<FaceDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Address.static ctor, ex=" + ex.getMessage(), "", "FaceAddressNote");
		}
	}

	// full list address positions on date1
	public static List<FaceDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 11.03.2025, last edit - 19.03.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceByParent = DAL.getByTemplate(WB.lastConnWork, Qry.getParentFilter(parentId), "Face");
			for (var currFace : faceByParent) {
				if (Etc.strEquals(currFace.role, Role.faceAddress)) {
					var currFaceAddressNote = new Address(currFace.parent, currFace.info);
					var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceAddressNote.val, "");
					if (curr.id.isEmpty() == false) {
						var tmp = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
								curr.geo, curr.role, curr.info, curr.more, curr.mark);
						res.add(tmp); // curr.more = currAddress
						// WB.addLog2("Address.getCurr, add tmp=" + tmp, "","Address");
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Address.getCurr(List<FaceDto>), ex=" + ex.getMessage(), "", "Address");
		}
		return res;
	}

	// item address position on date1
	public static FaceDto getCurr(String date1, String parentFaceId, String infoAddressKindId) throws Exception {
		// origin - 10.03.2025, last edit - 19.03.2025
		FaceDto res = new FaceDto();
		try {
			var currFaceAddressNote = new Address(parentFaceId, infoAddressKindId);
			var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceAddressNote.val, "");
			if (curr.id.isEmpty() == false) {
				res = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description, curr.geo,
						curr.role, curr.info, curr.more, curr.mark); // curr.more = currAddress
			}
		} catch (Exception ex) {
			WB.addLog("Address.getCurr, ex=" + ex.getMessage(), "", "Address");
		}
		return res;
	}

	private void getVal() throws Exception {
		// origin - 07.03.2025, last edit - 19.03.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currMore = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currMore = this.more.getByIndex(i);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description, this.geo,
						this.role, this.info, currMore, this.mark);
				this.val.add(tmp);
				// WB.addLog2("Address.getVal, add tmp=" + tmp, "","Address");
			}
		} catch (Exception ex) {
			WB.addLog("Address.getVal, ex=" + ex.getMessage(), "", "Address");
		}
	}

	public void isExist() throws Exception {
		// origin - 07.03.2025, last edit - 19.03.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getParentFilter(this.parent), this.table);
			if (listDto.size() != 0) {
				for (var currDto : listDto) {
					if ((Etc.strEquals(currDto.role, Role.faceAddress))) {// select by role = "Role.Face.Address"
						if ((Etc.strEquals(currDto.info, this.info))) {// select by info = ex."Info.Code.LawAddress"
							this.date1 = new ListVal(currDto.date1, "");
							this.date2 = new ListVal(currDto.date2, "");

							this.id = DefVal.setCustom(this.id, currDto.id);
							this.parent = DefVal.setCustom(this.parent, currDto.parent);
							this.code = DefVal.setCustom(this.code, currDto.code);
							this.description = DefVal.setCustom(this.description, currDto.description);
							this.geo = DefVal.setCustom(this.geo, currDto.geo);
							this.role = DefVal.setCustom(this.role, currDto.role);
							this.info = DefVal.setCustom(this.info, currDto.info);

							this.more = new ListVal(currDto.more, "");

							this.mark = DefVal.setCustom(this.mark, currDto.mark);
							this.isExist = true;
							break;
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Address.isExist, ex=" + ex.getMessage(), "", "Address");
		}
	}

	public Address(String ParentFaceId, String InfoAddressKindId) throws Exception {
		// origin - 07.03.2025, last edit - 10.03.2025
		this();
		this.table = "Face"; // ??magic string??
		this.src = this.parent = ParentFaceId;
		this.info = InfoAddressKindId;
		this.isExist();
		this.getVal();
	}

	public void clear() throws Exception {
		// origin - 07.03.2025, last edit - 19.03.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.mark = "";
			this.date1 = this.date2 = this.more = new ListVal();
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("Address.clear, ex=" + ex.getMessage(), "", "Address");
		}
	}

	public Address() throws Exception {
		// origin - 07.03.2025, last edit - 07.03.2025
		this.clear();
	}

	public String toString() {
		// origin - 07.03.2025, last edit - 20.03.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);

			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);

			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);

			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);

			res = res + Fmtr.addIfNotEmpty(", more ", this.more.id);

			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 07.03.2025, last edit - 19.03.2025
		try {

//			// getCurr(List<FaceDto>)
//			for (var tmp1 : new String[] { "2025-01-31", "2025-02-20", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
//					WB.addLog2("Address.test.getCurr(List<FaceDto>), res.size="
//							+ Address.getCurr(tmp1, tmp2).size() + ", date1=" + tmp1 + ", parentId=" + tmp2,"", "Address");
//				}
//			}

//			// getCurr(FaceDto)
//			for (var tmp1 : new String[] { "2025-01-31", "2025-02-20", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
//					for (var tmp3 : Info.kindAddress) {
//						WB.addLog2(
//								"Address.test.getCurr(FaceDto), res.more(address)="
//										+ Address.getCurr(tmp1, tmp2, tmp3).more + ", date1=" + tmp1
//										+ ", parentId=" + tmp2 + ", infoKindAddress=" + tmp3,"", "Address");
//					}
//				}
//			}

//			// ctor()
//			WB.addLog2("Address.test.ctor()=" + new Address(), "", "Address");

//			// ctor (String, String)
//			for (var tmp1 : new String[] { "Face.FA1", "Face.tralala", "Face.kgd" }) {
//				for (var tmp2 : Info.kindAddress) {
//					WB.addLog2("Address.test.ctor(String, String)=" + new Address(tmp1, tmp2),"", "Address");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("Address.test, ex=" + ex.getMessage(), "", "Address");
		}
	}
}