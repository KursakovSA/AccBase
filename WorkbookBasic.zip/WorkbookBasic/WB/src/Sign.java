public class Sign extends Model {
	// origin - 06.12.2023, last edit - 06.07.2024
	public Sign parent;

	public Sign(String Id, String Code, String Description) throws Exception {
		// origin - 06.12.2023, last edit - 07.07.2024
		try {
			this.id = Id;
			this.code = Code;
			this.description = Description;
		} catch (Exception ex) {
			WB.addLog("Sign.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Sign");
		} finally {
			Etc.doNothing();
		}
	}

	public Sign() throws Exception {
		// origin - 06.12.2023, last edit - 07.07.2024
		try {
		} catch (Exception ex) {
			WB.addLog("Sign.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Sign");
		} finally {
			Etc.doNothing();
		}
	}

	public static void test() throws Exception {
		// origin - 06.12.2023, last edit - 06.07.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Sign.test, ex=" + ex.getMessage(), WB.strEmpty, "Sign");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Sign.test end ", WB.strEmpty, "Sign");
	}
}
