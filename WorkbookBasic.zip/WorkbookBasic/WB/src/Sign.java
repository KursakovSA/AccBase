public class Sign extends ModelDto {
	// origin - 06.12.2023, last edit - 20.12.2024

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Sign.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Sign");
		} finally {
			Etc.doNothing();
		}
	}

	public void isExist() throws Exception {
		// origin - 20.12.2024, last edit - 20.12.2024
		super.isExist();
		try {
			for (var currSign : WB.abcLast.sign) {
				if (Etc.strEquals(currSign.id, this.id)) {
					this.date1 = DefVal.setCustom(DateTool.getNow().toString(), currSign.date1);// this.date1,
					this.date2 = DefVal.setCustom(this.date2, currSign.date2);
					this.code = DefVal.setCustom(this.code, currSign.code);
					this.parent = DefVal.setCustom(this.parent, currSign.parent);
					this.description = DefVal.setCustom(this.description, currSign.description);
					this.more = DefVal.setCustom(this.more, currSign.more);

					this.isExist = true;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Sign.isExist, ex=" + ex.getMessage(), WB.strEmpty, "Sign");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Sign.isExist=" + this.isExist, WB.strEmpty,"Sign");
	}

	public void isValid() throws Exception {
		// origin - 20.12.2024, last edit - 20.12.2024
		super.isValid();
		try {
			if (this.date1.isEmpty()) {
				this.isValid = false;
			}
		} catch (Exception ex) {
			WB.addLog("Sign.isValid, ex=" + ex.getMessage(), WB.strEmpty, "Sign");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Sign.isValid=" + this.isValid, WB.strEmpty,"Sign");
	}

	public Sign(String Id) throws Exception {
		// origin - 06.12.2023, last edit - 20.12.2024
		this();
		this.src = Id;
		this.id = this.code = Id;
		// this.date1 = DateTool.getNow().toString();
		this.isExist();
		this.isValid();
	}

	public Sign() throws Exception {
		// origin - 06.12.2023, last edit - 20.12.2024
		this.clear();
		this.isExist();
		var root = Abc.getRoot(this.table); // get root from WB.abcLast
		this.id = root.id;
		this.parent = root.parent;
		this.slice = root.slice;
		this.date1 = root.date1;
		this.date2 = root.date2;
		this.code = root.code;
		this.description = root.description;
		this.more = root.more;
	}

	public void clear() throws Exception {
		// origin - 20.12.2024, last edit - 20.12.2024
		try {
			super.clear();
			this.table = this.getClass().getName();
		} catch (Exception ex) {
			WB.addLog("Sign.clear, ex=" + ex.getMessage(), WB.strEmpty, "Sign");
		} finally {
			Etc.doNothing();
		}
	}

	public String toString() {
		// origin - 20.12.2024, last edit - 20.12.2024
		String res = WB.strEmpty;
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 06.12.2023, last edit - 20.12.2024
		try {

//			// ctor()
//			WB.addLog2("Sign.test.ctor()=" + new Sign(), WB.strEmpty, "Sign");
//			// ctor (String Id)
//			for (var tmp : new Sign[] { new Sign("Sign.Acct"), new Sign("Sign.tralala"),
//					new Sign("Sign.MoneyFlow.Input.016") }) {
//				WB.addLog2("Sign.test.ctor(String)=" + new Sign(tmp.id), WB.strEmpty, "Sign");
//			}

		} catch (Exception ex) {
			WB.addLog("Sign.test, ex=" + ex.getMessage(), WB.strEmpty, "Sign");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Sign.test end ", WB.strEmpty, "Sign");
	}
}
