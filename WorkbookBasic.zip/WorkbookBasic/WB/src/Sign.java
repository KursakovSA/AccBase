public class Sign extends Model {
	// origin - 06.12.2023, last edit - 18.01.2024
	public static Sign root;
	public Sign parent;
    
    static {
		root = new Sign("Sign","Sign","SignData");
	}
    
    public Sign(String Id, String Code, String Description) {
		// origin - 06.12.2023, last edit - 06.12.2023
		this.id = Id;
		this.code = Code;
		this.description = Description;
	}
    
    public Sign() {
		// origin - 06.12.2023, last edit - 06.12.2023
	}
    
    public static void test() throws Exception {
		// origin - 06.12.2023, last edit - 27.06.2024
    	WB.addLog("Sign.test, Sign.root=" + Sign.root, WB.strEmpty, "Sign");
	}
}
