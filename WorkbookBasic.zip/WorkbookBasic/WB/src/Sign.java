public class Sign extends Model {
	// origin - 06.12.2023, last edit - 06.12.2023
	public static Sign root;
	public Sign parent;
    
    static {
		root = new Sign("Sign","Sign","SignData");
	}
    
    public Sign(String Id, String Code, String Description) {
		// origin - 06.12.2023, last edit - 06.12.2023
		this.id = Id;
		this.code = Code;
		this.description = Description;
	}
    
    public Sign() {
		// origin - 06.12.2023, last edit - 06.12.2023
	}
    
    public static void test() {
		// origin - 06.12.2023, last edit - 06.12.2023
    	Logger.add("Sign.test, Sign.root=" + Sign.root, "", "Sign");
	}
}
