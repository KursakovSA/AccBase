public class Sign extends ModelDto {
	// origin - 06.12.2023, last edit - 04.08.2024

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Sign.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Sign");
		} finally {
			Etc.doNothing();
		}
	}

	public Sign(String Id, String Code, String Description) throws Exception {
		// origin - 06.12.2023, last edit - 04.08.2024
		super(Id, Code, Description);
	}

	public Sign() throws Exception {
		// origin - 06.12.2023, last edit - 04.08.2024
		super();
	}

	public static void test() throws Exception {
		// origin - 06.12.2023, last edit - 06.07.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Sign.test, ex=" + ex.getMessage(), WB.strEmpty, "Sign");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Sign.test end ", WB.strEmpty, "Sign");
	}
}
