import java.util.ArrayList;
import java.util.List;

public class CompositeVal extends ModelVal {
	// origin - 03.09.2024, last edit - 02.10.2024

	// CompositeVal, ex. source = "(S / M / L / XL)(Unit.Size)",
	// "(34/67/89/90)(Unit.Lenght)", "(A/B/C)(Unit.Kind)", etc.
	// result multiple select, ex. "S/M", "34/67/90", "A" etc. ????
	// or "(dropbox/iam/123456)(Unit.Service/login/pass)"

	public final static String strSplitValue = "/";
	public static final String strLeftSplitPart = "(";
	public static final String strRightSplitPart = ")";
	private static final List<String> listDelStr = List.of(CompositeVal.strLeftSplitPart,
			CompositeVal.strRightSplitPart);

	public String partVal = new String();
	public String partUnit = new String();

	public List<String> val = new ArrayList<String>(); // ex. 12/14
	public Unit unit = new Unit(); // ex. KZT, in total, UnitVal = 12/14 KZT

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("CompositeVal.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "CompositeVal");
		} finally {
			Etc.doNothing();
		}
	}

	private void getUnitVal() throws Exception {
		// origin - 30.09.2024, last edit - 05.10.2024
		try {
			this.val = Formatter.listVal(this.partVal, CompositeVal.strSplitValue);
			String tmp = this.partUnit;

			// tmp = Etc.delStr(tmp, CompositeVal.strLeftSplitPart);
			// tmp = Etc.delStr(tmp, CompositeVal.strRightSplitPart);
			tmp = Etc.delStr(tmp, CompositeVal.listDelStr);
			// WB.addLog2("UnitVal.getUnitVal, tmp=" + tmp, WB.strEmpty, "UnitVal");

			var dto = ReadSet.getByCode(WB.abcLast.basic, tmp);
			if (dto.size() != 0) {
				var dto1 = dto.getFirst();
				this.unit = new Unit(dto1.id, dto1.code, dto1.description); // this is res
			} else {
				this.unit = new Unit(); // this is res
			}
			this.id = this.val + WB.strSpace + this.unit.description;
		} catch (Exception ex) {
			WB.addLog("CompositeVal.getUnitVal, ex=" + ex.getMessage(), WB.strEmpty, "CompositeVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("CompositeVal.getUnitVal, this.unit=" + this.unit, WB.strEmpty,
		// "CompositeVal");
	}

	private void getPart() throws Exception {
		// origin - 30.09.2024, last edit - 30.09.2024
		try {
			if (this.isCompositeVal()) {
				int posLocalSplitValUnit = this.src
						.indexOf(CompositeVal.strRightSplitPart + CompositeVal.strLeftSplitPart); // pos ")("
				if (posLocalSplitValUnit > 0) {
					// this is res
					this.partVal = Etc.fixTrim(this.src.substring(0, posLocalSplitValUnit)); // ex. "(12/14)(Unit.KZT)"
																								// -->
																								// "(12/14)"

					// clean "(", ")", ")(", "()"
					// this.partVal = Etc.delStr(this.partVal, CompositeVal.strLeftSplitPart);
					// this.partVal = Etc.delStr(this.partVal, CompositeVal.strRightSplitPart);
					this.partVal = Etc.delStr(this.partVal, CompositeVal.listDelStr);

					this.partUnit = Etc.fixTrim(this.src.substring(posLocalSplitValUnit));
					// clean "(", ")", ")(", "()"
					// this.partUnit = Etc.delStr(this.partUnit, CompositeVal.strLeftSplitPart);
					// this.partUnit = Etc.delStr(this.partUnit, CompositeVal.strRightSplitPart);
					this.partUnit = Etc.delStr(this.partUnit, CompositeVal.listDelStr);
				}
			}
		} catch (Exception ex) {
			WB.addLog("CompositeVal.getPart, ex=" + ex.getMessage(), WB.strEmpty, "CompositeVal");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("CompositeVal.getPart, this.partVal=" + this.partVal + ", this.partUnit=" + this.partUnit
//				+ ", this.src=" + this.src, WB.strEmpty, "CompositeVal");
	}

	public CompositeVal(String Src) throws Exception {
		// origin - 30.09.2024, last edit - 30.09.2024
		this();
		this.src = Etc.fixTrim(Src);
		this.getPart();
		this.getUnitVal();
	}

	public CompositeVal() throws Exception {
		// origin - 03.09.2024, last edit - 30.09.2024
		super();
	}

	public static void test() throws Exception {
		// origin - 03.09.2024, last edit - 30.09.2024
		try {

//			// ctor
//			var arg1 = new String[] { "(67 / 15)(Unit.KZT)", "(45/56)(Unit.Size)", "89 /23(Unit.Tralala)" };
//			for (var testArg1 : arg1) {
//				CompositeVal compositeVal1 = new CompositeVal(testArg1);
//				WB.addLog2("CompositeVal.test.ctor, compositeVal1=" + compositeVal1 + ", init str=" + testArg1,
//						WB.strEmpty, "UnitVal");
//			}

		} catch (

		Exception ex) {
			WB.addLog("CompositeVal.test, ex=" + ex.getMessage(), WB.strEmpty, "CompositeVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("CompositeVal.test end ", WB.strEmpty, "CompositeVal");
	}
}
