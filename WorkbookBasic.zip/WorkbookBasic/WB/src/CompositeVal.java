import java.util.ArrayList;
import java.util.List;

public class CompositeVal extends ModelVal {
	// origin - 03.09.2024, last edit - 24.11.2024

	// ex. source = "S / M / L / XL(Unit.Size)", Weight = 6.89 / 3.56(Unit.Gr),
	// "(34/67/89/90)(Unit.Lenght)", "A/B/C(Unit.Kind)", etc.
	// or "dropbox/iam/123456(Unit.Service/login/pass)"

	private static List<String> listDelStr;
	public List<String> val;
	private String partVal;

	static {
		try {
			CompositeVal.listDelStr = List.of(WB.strEquals, WB.strParenthesisLeft, WB.strParenthesisRight);
		} catch (Exception ex) {
			WB.addLog("CompositeVal.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "CompositeVal");
		} finally {
			Etc.doNothing();
		}
	}

	private void getVal() throws Exception {
		// origin - 30.09.2024, last edit - 06.01.2025
		try {
			this.name = this.partName;
			this.val = Fmtr.listVal(this.partVal, WB.strSlash);
			this.getUnit();
			this.id = this.partName + this.val.toString() + WB.strSpace + this.unit.code + WB.strCommaSpace
					+ this.unit.description;
		} catch (Exception ex) {
			WB.addLog("CompositeVal.getVal, ex=" + ex.getMessage(), WB.strEmpty, "CompositeVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("CompositeVal.getVal, this.unit=" + this.unit, WB.strEmpty,
		// "CompositeVal");
	}

	private void getPart() throws Exception {
		// origin - 30.09.2024, last edit - 04.01.2025
		try {
			if (ModelVal.isType(this.src) == "CompositeVal") {
				String tmp = this.src;

				int posMiddleEquation = tmp.indexOf(WB.strEquals); // pos "="
				if (posMiddleEquation > 0) {
					this.partName = Etc.fixTrim(tmp.substring(0, posMiddleEquation));
					tmp = Etc.delStr(tmp, this.partName);
					tmp = Etc.delStr(tmp, WB.strEquals);
				}

				int posLocalSplitValUnit = tmp.indexOf(ModelVal.strStartUnit); // pos "(Unit."
				if (posLocalSplitValUnit > 0) {
					this.partVal = Etc.fixTrim(tmp.substring(0, posLocalSplitValUnit));
					this.partUnit = Etc.fixTrim(tmp.substring(posLocalSplitValUnit));
					this.partUnit = Etc.delStr(this.partUnit, CompositeVal.listDelStr);
				}

				if (this.partUnit.isEmpty()) {
					this.partVal = Etc.fixTrim(tmp);
				}
			}
		} catch (Exception ex) {
			WB.addLog("CompositeVal.getPart, ex=" + ex.getMessage(), WB.strEmpty, "CompositeVal");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("CompositeVal.getPart, this.partVal=" + this.partVal + ", this.partUnit=" + this.partUnit
//				+ ", this.partName=" + this.partName + ", this.src=" + this.src, WB.strEmpty, "CompositeVal");
	}

	public CompositeVal(String Src) throws Exception {
		// origin - 30.09.2024, last edit - 21.11.2024
		this();
		this.src = Etc.fixTrim(Src);
		this.getPart();
		this.getVal();
	}

	public CompositeVal() throws Exception {
		// origin - 03.09.2024, last edit - 24.11.2024
		super();
		this.val = new ArrayList<String>();
		this.partVal = this.partUnit = WB.strEmpty;
	}

	public String toString() {
		// origin - 06.01.2025, last edit - 06.01.2025
		String res = WB.strEmpty;
		try {
			res = this.id + WB.strSpace + ", src " + this.src;
		} catch (Exception ex) {
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 03.09.2024, last edit - 06.01.2025
		try {

//			// ctor
//			for (var tmp : new String[] { "Weight = 6.89 / 3.56(Unit.Gr)", "67 / 15(Unit.KZT)", "45/56(Unit.Size)",
//					"89 /23(Unit.Tralala)", "male /female" }) {
//				WB.addLog2("CompositeVal.test.ctor, tmp=" + new CompositeVal(tmp), WB.strEmpty, "CompositeVal");
//			}

		} catch (

		Exception ex) {
			WB.addLog("CompositeVal.test, ex=" + ex.getMessage(), WB.strEmpty, "CompositeVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("CompositeVal.test end ", WB.strEmpty, "CompositeVal");
	}
}
