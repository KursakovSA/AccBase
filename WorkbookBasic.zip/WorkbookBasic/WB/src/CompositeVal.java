import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unused")
public class CompositeVal {
	// origin - 03.09.2024, last edit - 04.09.2024
	public static String strSplit = "/"; // splitter composite values in string, ex. "20 / 30", "34/67/89", etc.
	private static String id = WB.strEmpty; //TOTHINK
	private List<String> source = new ArrayList<String>(); //TOTHINK
	private List<String> target = new ArrayList<String>(); //TOTHINK

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("CompositeVal.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "CompositeVal");
		} finally {
			Etc.doNothing();
		}
	}

//	private static List<String> get(String initStr) throws Exception {
//		// origin - 03.09.2024, last edit - 04.09.2024
//		List<String> res = new ArrayList<String>();
//		try {
//			initStr = Etc.fixTrim(initStr);
//			String[] tmp = initStr.split(CompositeVal.strSplit);
//			String currTmp = WB.strEmpty;
//			for (var currArr : tmp) {
//				currTmp = WB.strEmpty;
//				currTmp = Etc.fixTrim(currArr.toString());
//				// currTmp = currTmp.replace(ListVal.strSplit, WB.strEmpty);
//				if (currTmp.isEmpty() == false) {
//					res.add(currTmp);
//				}
//			}
//
//		} catch (Exception ex) {
//			WB.addLog("CompositeVal.getCompositeVal, ex=" + ex.getMessage(), WB.strEmpty, "CompositeVal");
//		} finally {
//			Etc.doNothing();
//		}
//
//		// WB.addLog2("CompositeVal.getCompositeVal, res=" + Etc.logArray(res),
//		// WB.strEmpty,
//		// "CompositeVal");
//		return res;
//	}

	public CompositeVal() throws Exception {
		// origin - 03.09.2024, last edit - 03.09.2024
		try {
		} catch (Exception ex) {
			WB.addLog("CompositeVal.ctor, ex=" + ex.getMessage(), WB.strEmpty, "CompositeVal");
		} finally {
			Etc.doNothing();
		}
	}

	public static void test() throws Exception {
		// origin - 03.09.2024, last edit - 04.09.2024
		try {

			// get
			var arg1 = new String[] { "67 / 15", "45/56", "89 /23", "95/ 73", "11   /     99" };
			for (var testArg1 : arg1) {
				WB.addLog2("CompositeVal.test.Formatter.listVal, res="
						+ Formatter.listVal(Formatter.listVal(testArg1, CompositeVal.strSplit), "") + ", testArg1="
						+ testArg1, WB.strEmpty, "CompositeVal");

			}

		} catch (Exception ex) {
			WB.addLog("CompositeVal.test, ex=" + ex.getMessage(), WB.strEmpty, "CompositeVal");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("CompositeVal.test end ", WB.strEmpty, "CompositeVal");
	}
}
