import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unused")
public class Deal extends ModelDto {
	// origin - 28.09.2023, last edit - 15.12.2024
	public String dealId, outsideDealId, templateId, termId;
	public List<LocalDate> date1, date2;
	public LocalDate startDate, endDate;
	// public boolean isExpired;
	public UnitVal duration;
	public List<String> templateDoc;

	public ModelDto src = new ModelDto(); // start point building object Deal from codeTemplate
	public List<ModelDto> template = new ArrayList<ModelDto>(); // TODO

	public Term term = new Term();
	public List<Movement> movement = new ArrayList<Movement>(); // TODO
	public List<Prolongation> prolongation = new ArrayList<Prolongation>(); // TODO

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Deal.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Deal");
		} finally {
			Etc.doNothing();
		}
	}

	public void fix() throws Exception {
		// origin - 29.12.2024, last edit - 01.01.2025
		try {
			super.fix();
			this.role = DefVal.set(this.role, Role.dealBasic);
			this.info = DefVal.set(this.info, Info.dealBasic);
			this.mark = DefVal.set(this.mark, Mark.DD);
		} catch (Exception ex) {
			WB.addLog("Deal.fix, ex=" + ex.getMessage(), WB.strEmpty, "Deal");
		} finally {
			Etc.doNothing();
		}
	}

	private void getDuration() throws Exception {
		// origin - 18.09.2024, last edit - 07.10.2024
		try {
			var res1 = (double) ChronoUnit.DAYS.between(this.startDate, this.endDate);
			var res2 = this.term.billingCycle.partUnit;
			// this is res
			this.duration = new UnitVal(Etc.fixTrim(Etc.fixString(res1)), Etc.fixTrim(Etc.fixString(res2)));
			// WB.addLog2("Deal.getDuration, this.duration=" + this.duration, WB.strEmpty,
			// "Deal");
		} catch (Exception ex) {
			WB.addLog("Deal.getDuration, ex=" + ex.getMessage(), WB.strEmpty, "Deal");
		} finally {
			Etc.doNothing();
		}
	}

	public void isValid() throws Exception { // TODO
		// origin - 18.09.2024, last edit - 11.12.2024
		super.isValid();
		try {
			if (this.parent.isEmpty() & this.face1.isEmpty() & this.geo.isEmpty() & this.role.isEmpty()
					& this.info.isEmpty()) {
				this.isValid = false;
			}
		} catch (Exception ex) {
			WB.addLog("Deal.isValid, ex=" + ex.getMessage(), WB.strEmpty, "Deal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Deal.isValid=" + this.isValid, WB.strEmpty,"Deal");
	}

	public void isExist() throws Exception {// TODO
		// origin - 18.09.2024, last edit - 11.12.2024
		super.isExist();
		try {
			var tableDto = DAL.getByTemplate(WB.lastConnWork, Qry.getMoreFilter(this.table), this.table);
			for (var currDto : tableDto) {
				if ((Etc.strEquals(currDto.id, this.src.id)) & (Etc.strEquals(currDto.code, this.src.code))
						& (Etc.strEquals(currDto.description, this.src.description))) {
					this.isExist = true;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Deal.isExist, ex=" + ex.getMessage(), WB.strEmpty, "Deal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Deal.isExist=" + this.isExist, WB.strEmpty,"Deal");
	}

//	private boolean isOutsideDefault() throws Exception {// TODO
//		// origin - 12.09.2024, last edit - 02.10.2024
//		boolean res = false;
//		try {
//		} catch (Exception ex) {
//			WB.addLog("Deal.isOutsideDefault, ex=" + ex.getMessage(), WB.strEmpty, "Deal");
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("Deal.isOutsideDefault, res=" + res, WB.strEmpty, "Deal");
//		return res;
//	}

	private boolean isOutsideDuration() throws Exception {
		// origin - 12.09.2024, last edit - 08.01.2025
		boolean res = false;
		try {
			if ((this.term.durationDealMaxLimit.val != 0.0) & (this.duration.val != 0.0)
					& (this.duration.val != this.term.durationDealMaxLimit.val)) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("Deal.isOutsideDuration, ex=" + ex.getMessage(), WB.strEmpty, "Deal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Deal.isOutsideDuration, res=" + res, WB.strEmpty, "Deal");
		return res;
	}

	private void correctByDefault() throws Exception {// TODO
		// origin - 12.09.2024, last edit - 12.09.2024
		try {
		} catch (Exception ex) {
			WB.addLog("Deal.correctByDefault, ex=" + ex.getMessage(), WB.strEmpty, "Deal");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("Deal.correctByDefault, this.endDate=" + this.endDate
//				+ ", endDateBeforeCorrect = " + endDateBeforeCorrect, WB.strEmpty, "Deal");
	}

	private void correctByDuration() throws Exception {
		// origin - 10.09.2024, last edit - 07.10.2024
		try {
			if (this.isOutsideDuration()) {
//						WB.addLog2("Deal.correctEndDateByDuration, before correct this.Date2=" + this.Date2,
//								WB.strEmpty, "Deal");
//						this.Date2.removeLast();
//						this.Date2.add(DateTool.getEndDateFromDuration(this.startDate, this.durationCreditMaxLimit)); // this
//																														// is
//																														// res
//						WB.addLog2("Deal.correctByDuration, after correct this.Date2=" + this.Date2, WB.strEmpty,
//								"Deal");
//						this.endDate = this.Date2.getLast(); // this is res
//						this.duration = DateTool.getDuration(this.endDate, this.startDate); // this is res

//						WB.addLog2("Deal.correctEndDateByDuration, before correct this.date2=" + this.date2,
//								WB.strEmpty, "Deal");

				this.date2.removeLast();// ?? if find what last = enddate ??

				this.date2
						.add(DateTool.getEndDateFromDuration(this.startDate, (int) this.term.durationDealMaxLimit.val)); // this
				// is
				// res
//						WB.addLog2("Deal.correctByDuration, after correct this.date2=" + this.date2, WB.strEmpty,
//								"Deal");
				this.endDate = this.date2.getLast(); // this is res
				this.getDuration(); // this is res
			}
			// }
			// }
		} catch (Exception ex) {
			WB.addLog("Deal.correctByDuration, ex=" + ex.getMessage(), WB.strEmpty, "Deal");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("Deal.correctByDuration, this.endDate=" + this.endDate
//				+ ", endDateBeforeCorrect = " + endDateBeforeCorrect, WB.strEmpty, "Deal");
	}

	public void getTemplate() throws Exception {
		// origin - 07.09.2024, last edit - 05.10.2024
		try {
			// WB.addLog2("Deal.getTemplate, after run, this.src.code=" + this.src.code,
			// WB.strEmpty, "Deal");
			var tmp1 = ReadSet.getEqualsByCode(WB.abcLast.template, this.src.code);
			if (tmp1.size() != 0) {
				this.src = tmp1.getFirst();
				this.template.add(this.src); // add root template
				var currCodeParent = this.src.code;

				// unwind template tree
				while (currCodeParent.isEmpty() == false) {
					var template = ReadSet.getEqualsByParent(WB.abcLast.template, currCodeParent); // ??
					currCodeParent = WB.strEmpty;
					for (var currTemplate : template) {
						this.template.add(currTemplate);
						// WB.addLog2("Deal.getTemplate, this.template.add(currTemplate)=" +
						// currTemplate, WB.strEmpty,
						// "Deal");
						currCodeParent = currTemplate.code;
					}
				}

			}

		} catch (Exception ex) {
			WB.addLog("Deal.getTemplate, ex=" + ex.getMessage(), WB.strEmpty, "Deal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Deal.getTemplate, this.template.size=" + this.template.size(),
		// WB.strEmpty, "Deal");
	}

	private boolean isExpire() throws Exception {// expire right now, today
		// origin - 05.12.2024, last edit - 05.12.2024
		boolean res = false;
		try {
			if (this.endDate != null) {
				if (this.endDate.isEqual(DateTool.getNow())) {
					res = true;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Deal.isExpire, ex=" + ex.getMessage(), WB.strEmpty, "Deal");
		} finally {
			Etc.doNothing();
		}
		return res;
//		WB.addLog2("Deal.isExpire, res=" + res, WB.strEmpty, "Deal");
	}

	private boolean isExpired() throws Exception {// is expired already
		// origin - 05.12.2024, last edit - 05.12.2024
		boolean res = false;
		try {
			if (this.endDate != null) {
				if (this.endDate.isBefore(DateTool.getNow())) {
					res = true;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Deal.isExpired, ex=" + ex.getMessage(), WB.strEmpty, "Deal");
		} finally {
			Etc.doNothing();
		}
		return res;
//		WB.addLog2("Deal.isExpired, res=" + res, WB.strEmpty, "Deal");
	}

	private void getDate() throws Exception {
		// origin - 08.09.2024, last edit - 05.12.2024
		try {
			var lst1 = Fmtr.listVal(this.src.date1, WB.strSemiColon);
			this.date1 = Fmtr.listStr(lst1); // this is res
			this.startDate = this.date1.getFirst(); // this is res

			if (this.startDate == null) {
				this.startDate = DateTool.getNow();
			}

			var lst2 = Fmtr.listVal(this.src.date2, WB.strSemiColon);
			this.date2 = Fmtr.listStr(lst2); // this is res
			this.endDate = this.date2.getLast(); // this is res

			if (this.endDate == null) {
				this.endDate = DateTool.getNow();
			}

			this.getDuration(); // this is res
			this.correctByDuration(); // ?? take outside ??

			if (this.endDate != null) {
				if (this.endDate.isBefore(DateTool.getNow())) {
					// this.isExpired = true;
				}
			}

		} catch (Exception ex) {
			WB.addLog("Deal.getDate, ex=" + ex.getMessage(), WB.strEmpty, "Deal");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("Deal.getDate, this.startDate=" + this.startDate + ", this.endDate=" + this.endDate
//				+ ", this.duration=" + this.duration, WB.strEmpty, "Deal");
	}

	public Deal(String Table, String Id, String Parent, String Face1, String Face2, String Face, String Date1,
			String Date2, String Code, String Description, String Geo, String Role, String Info, String More)
			throws Exception { // TOTHINK
		// origin - 07.09.2024, last edit - 25.11.2024
		this();
		this.src.table = Table;
		this.src.id = Id;
		this.src.parent = Parent;
		this.src.face1 = Face1;
		this.src.face2 = Face2;
		this.src.face = Face;

		this.src.date1 = Date1;
		if (Date1.isEmpty()) {
			this.src.date1 = DateTool.getNow().toString();
		}
		this.src.date2 = Date2;
//		if (Date2.isEmpty()) {
//			this.src.date2 = DateTool.getNow().toString();
//		}
		this.src.code = Code;
		this.src.description = Description;
		this.src.geo = Geo;
		this.src.role = Role;
		this.src.info = Info;
		this.src.more = More;
		this.getDate();
		this.fix();
	}

	public Deal(String codeTemplate) throws Exception {
		// origin - 01.10.2024, last edit - 29.12.2024
		// super();
		this();
		this.src.code = codeTemplate;
		this.getTemplate();
		this.fix();
	}

	public Deal(ModelDto dto) throws Exception {
		// origin - 07.09.2024, last edit - 25.11.2024
		this(dto.table, dto.id, dto.parent, dto.face1, dto.face2, dto.face, dto.date1, dto.date2, dto.code,
				dto.description, dto.geo, dto.role, dto.info, dto.more);
		// this.getDate();
		this.fix();
	}

	public Deal() throws Exception {
		// origin - 05.12.2023, last edit - 25.11.2024
		this.clear();
	}

	public void clear() throws Exception {
		// origin - 25.11.2024, last edit - 07.12.2024
		try {
			super.clear();
			this.table = this.getClass().getName();
			this.dealId = outsideDealId = WB.strEmpty;
			date1 = date2 = new ArrayList<LocalDate>();
			// startDate = endDate = LocalDate.of();
			// isExpired = false;
			duration = new UnitVal();
			templateDoc = new ArrayList<String>();
		} catch (Exception ex) {
			WB.addLog("Deal.clear, ex=" + ex.getMessage(), WB.strEmpty, "Deal");
		} finally {
			Etc.doNothing();
		}
	}

	public String toString() {
		// origin - 24.11.2023, last edit - 24.11.2024
		String res = WB.strEmpty;
		try {
			res = WB.strBraceLeft + this.id + WB.strCommaSpace + this.parent + WB.strCommaSpace + this.face1
					+ WB.strCommaSpace + this.face2 + WB.strCommaSpace + this.face + WB.strCommaSpace + this.date1
					+ WB.strCommaSpace + this.date2 + WB.strCommaSpace + this.code + WB.strCommaSpace + this.description
					+ WB.strCommaSpace + this.geo + WB.strCommaSpace + this.role + WB.strCommaSpace + this.info
					+ WB.strCommaSpace + this.more + WB.strBraceRight + this.mark + WB.strBraceRight;
		} catch (Exception ex) {
			// WB.addLog2("Deal.toString, ex=" + ex.getMessage(), WB.strEmpty, "Deal");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 25.11.2024
		try {

			// ctor ("codeTemplate")
			Deal dt1 = new Deal("Deal.Face.Pawnshop.Template1");
			WB.addLog2("Deal.test.ctor(codeTemplate), dealTemplate1.template.size=" + dt1.template.size() + dt1
					+ ", this.src.code=" + dt1.src.code, WB.strEmpty, "Deal");

//			// isValid, isExist
//			Deal deal1 = new Deal("Deal", "Deal.Face.FA1.boss", "Deal.enbek.staff", "Face.FA1", WB.strEmpty,
//					WB.strEmpty, WB.strEmpty, WB.strEmpty, "Deal.Face.FA1.boss", "директор", "Geo.Qazaqstan",
//					"Role.Deal.Frame", "Info.Deal.Staff", WB.strEmpty);
//			WB.addLog2(
//					"Deal.test.ctor, deal1=" + deal1 + ", isExist=" + deal1.isExist() + ", isValid=" + deal1.isValid(),
//					WB.strEmpty, "Deal");
//			Deal deal2 = new Deal("Deal", WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					"Deal.tralala", "Deal.tralala", WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty);
//			WB.addLog2(
//					"Deal.test.ctor, deal2=" + deal2 + ", isExist=" + deal2.isExist() + ", isValid=" + deal2.isValid(),
//					WB.strEmpty, "Deal");

//			// ctor ("date1", "date2") different variants
//			Deal newDeal1 = new Deal(WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					"2024-09-01", "2024-09-11", WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					WB.strEmpty);
//			WB.addLog2("Deal.test.ctor(dto), newDeal1=" + newDeal1, WB.strEmpty, "Deal");
//			Deal newDeal2 = new Deal(WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					"2024-09-01;2024-09-06", "2024-09-11;2024-09-16", WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					WB.strEmpty, WB.strEmpty, WB.strEmpty);
//			WB.addLog2("Deal.test.ctor(dto), newDeal2=" + newDeal2, WB.strEmpty, "Deal");
//			Deal newDeal3 = new Deal(WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					"2024-09-01;2024-09-06;", "2024-09-11;2024-09-16;", WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					WB.strEmpty, WB.strEmpty, WB.strEmpty);
//			WB.addLog2("Deal.test.ctor(dto), newDeal3=" + newDeal3, WB.strEmpty, "Deal");
//			// test correctByDuration
//			Deal newDeal4 = new Deal(WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					"2024-09-01", "2024-09-11;2025-09-16;", WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					WB.strEmpty, WB.strEmpty);
//			WB.addLog2("Deal.test.ctor(dto), newDeal4=" + newDeal4, WB.strEmpty, "Deal");

//			// getId
//			WB.addLog2("Deal.getId(), res=" + new Deal().getId(), WB.strEmpty, "Face");
//			WB.addLog2("Deal.getId('', ''), res=" + new Deal().getId("", ""), WB.strEmpty, "Face");
//			WB.addLog2("Deal.getId('DealId', ''), res=" + new Deal().getId("DealId", ""), WB.strEmpty, "Deal");
//			WB.addLog2("Deal.getId('DealId', 'idStringGrowingDigitalInfobase'), res="
//					+ new Deal().getId("DealId", "idStringGrowingDigitalInfobase"), WB.strEmpty, "Deal");
//			WB.addLog2("Deal.getId('DealId', 'idStringGrowingDigitalGlobal'), res="
//					+ new Deal().getId("DealId", "idStringGrowingDigitalGlobal"), WB.strEmpty, "Deal");
//			WB.addLog2("Deal.getId('DealId', 'idIntegerGrowingDigitalGlobal'), res="
//					+ new Deal().getId("DealId", "idIntegerGrowingDigitalGlobal"), WB.strEmpty, "Deal");
//			WB.addLog2("Deal.getId('PawnId', ''), res=" + new Deal().getId("PawnId", ""), WB.strEmpty, "Deal");
//			WB.addLog2("Deal.getId('PawnId', 'idStringGrowingDigitalInfobase'), res="
//					+ new Deal().getId("PawnId", "idStringGrowingDigitalInfobase"), WB.strEmpty, "Deal");
//			WB.addLog2("Deal.getId('PawnId', 'idStringGrowingDigitalGlobal'), res="
//					+ new Deal().getId("PawnId", "idStringGrowingDigitalGlobal"), WB.strEmpty, "Deal");
//			WB.addLog2("Deal.getId('PawnId', 'idIntegerGrowingDigitalGlobal'), res="
//					+ new Deal().getId("PawnId", "idIntegerGrowingDigitalGlobal"), WB.strEmpty, "Deal");

		} catch (Exception ex) {
			WB.addLog("Deal.test, ex=" + ex.getMessage(), WB.strEmpty, "Deal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Deal.test end ", WB.strEmpty, "Deal");
	}
}