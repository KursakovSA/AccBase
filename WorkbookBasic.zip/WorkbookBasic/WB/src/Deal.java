public class Deal extends Model {
	// origin - 28.09.2023, last edit - 18.01.2024
	public static Deal root = new Deal();
	public Deal parent;
    public Face face1;
    public Face face2;
    public Face face;
    public Geo geo;
    public Role role;
    public Info info;
    
    static {
		root = new Deal("Deal","Deal","DealData");
	}
    
    public Deal(String Id, String Code, String Description) {
		// origin - 05.12.2023, last edit - 05.12.2023
		this.id = Id;
		this.code = Code;
		this.description = Description;
	}
    
    public Deal() {
		// origin - 05.12.2023, last edit - 05.12.2023
	}
    
    public static void test() {
		// origin - 28.10.2023, last edit - 18.01.2024
    	WB.addLog("Deal.test, Deal.root=" + Deal.root, "", "Deal");
	}
}