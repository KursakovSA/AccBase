public class Deal extends Model {
	// origin - 28.09.2023, last edit - 06.07.2024
	public Deal parent;
	public Face face1;
	public Face face2;
	public Face face;
	public Geo geo;
	public Role role;
	public Info info;

	public Deal(String Id, String Code, String Description) throws Exception {
		// origin - 05.12.2023, last edit - 07.07.2024
		try {
			this.id = Id;
			this.code = Code;
			this.description = Description;
		} catch (Exception ex) {
			WB.addLog("Deal.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Deal");
		} finally {
			Etc.doNothing();
		}
	}

	public Deal() throws Exception {
		// origin - 05.12.2023, last edit - 07.07.2024
		try {
		} catch (Exception ex) {
			WB.addLog("Deal.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Deal");
		} finally {
			Etc.doNothing();
		}
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 06.07.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Deal.test, ex=" + ex.getMessage(), WB.strEmpty, "Deal");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Deal.test end ", WB.strEmpty, "Deal");
	}
}