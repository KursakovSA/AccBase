public class Deal extends ModelDto {
	// origin - 28.09.2023, last edit - 04.08.2024

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Deal.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Deal");
		} finally {
			Etc.doNothing();
		}
	}

	public Deal(String Id, String Code, String Description) throws Exception {
		// origin - 05.12.2023, last edit - 11.08.2024
		super(Id, Code, Description);
		this.table = this.getClass().getName();
	}

	public Deal() throws Exception {
		// origin - 05.12.2023, last edit - 11.08.2024
		super();
		this.table = this.getClass().getName();
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 29.08.2024
		try {

			// getId
			Deal newDeal = new Deal();
			WB.addLog2("Deal.getId(), res=" + newDeal.getId(), WB.strEmpty, "Face");
			WB.addLog2("Deal.getId('', ''), res=" + newDeal.getId("", ""), WB.strEmpty, "Face");
			WB.addLog2("Deal.getId('DealId', ''), res=" + newDeal.getId("DealId", ""), WB.strEmpty, "Deal");
			WB.addLog2("Deal.getId('DealId', 'idStringGrowingDigitalInfobase'), res="
					+ newDeal.getId("DealId", "idStringGrowingDigitalInfobase"), WB.strEmpty, "Deal");
			WB.addLog2("Deal.getId('DealId', 'idStringGrowingDigitalGlobal'), res="
					+ newDeal.getId("DealId", "idStringGrowingDigitalGlobal"), WB.strEmpty, "Deal");
			WB.addLog2("Deal.getId('DealId', 'idIntegerGrowingDigitalGlobal'), res="
					+ newDeal.getId("DealId", "idIntegerGrowingDigitalGlobal"), WB.strEmpty, "Deal");
			
			WB.addLog2("Deal.getId('PawnId', ''), res=" + newDeal.getId("PawnId", ""), WB.strEmpty, "Deal");
			WB.addLog2("Deal.getId('PawnId', 'idStringGrowingDigitalInfobase'), res="
					+ newDeal.getId("PawnId", "idStringGrowingDigitalInfobase"), WB.strEmpty, "Deal");
			WB.addLog2("Deal.getId('PawnId', 'idStringGrowingDigitalGlobal'), res="
					+ newDeal.getId("PawnId", "idStringGrowingDigitalGlobal"), WB.strEmpty, "Deal");
			WB.addLog2("Deal.getId('PawnId', 'idIntegerGrowingDigitalGlobal'), res="
					+ newDeal.getId("PawnId", "idIntegerGrowingDigitalGlobal"), WB.strEmpty, "Deal");			

		} catch (Exception ex) {
			WB.addLog("Deal.test, ex=" + ex.getMessage(), WB.strEmpty, "Deal");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Deal.test end ", WB.strEmpty, "Deal");
	}
}