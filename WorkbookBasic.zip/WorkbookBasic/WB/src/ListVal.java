import java.util.ArrayList;
import java.util.List;

public class ListVal extends ModelVal {
	// origin - 16.07.2024, last edit - 07.10.2024
	public static String strSplit = ":"; // ??magic string??
	private String abcKey = WB.strEmpty;
	public List<String> val = new ArrayList<String>(); // ex. "12:14:23", "Opel:Fiat:Reno", etc.

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("ListVal.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "ListVal");
		} finally {
			Etc.doNothing();
		}
	}

//	public ListVal(String Src, String Key) throws Exception {
//		// origin - 30.09.2024, last edit - 01.10.2024
//		this();
//		this.src = Etc.fixTrim(Src);
//		// this.getPart();
//	}

	public ListVal(String AbcKey) throws Exception {
		// origin - 30.09.2024, last edit - 09.10.2024
		this();
		this.abcKey = Etc.fixTrim(AbcKey);

		this.src = MoreVal.getByKey(WB.abcTemplate.listVal, "AbcListVal", this.abcKey);
		this.src = DefVal.set(this.src, ModelVal.defVal);

		this.val = Formatter.listVal(this.src, ListVal.strSplit);
		// this.getPart();
	}

	public ListVal() throws Exception {
		// origin - 04.09.2024, last edit - 30.09.2024
		super();
	}

	public static void test() throws Exception {
		// origin - 16.07.2024, last edit - 01.10.2024
		try {

			// ctor1
			ListVal listVal1 = new ListVal("Info.Code.GoldContent");
			WB.addLog2("ListVal.test.ctor1, listVal1=" + listVal1 + ", abcKey=Info.Code.GoldContent", WB.strEmpty,
					"UnitVal");

			// ctor2
			ListVal listVal2 = new ListVal("Info.Code.ProductCondition");
			WB.addLog2("ListVal.test.ctor2, listVal2=" + listVal2 + ", abcKey=Info.Code.ProductCondition", WB.strEmpty,
					"UnitVal");

		} catch (Exception ex) {
			WB.addLog("ListVal.test, ex=" + ex.getMessage(), WB.strEmpty, "ListVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ListVal.test end ", WB.strEmpty, "ListVal");
	}
}
