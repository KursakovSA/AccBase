import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unused")
public class ListVal extends ModelVal {
	// origin - 16.07.2024, last edit - 17.09.2024
	private static String strSplit = ":"; // ??magic string??
	// private final static String defaultListVal = WB.strEmpty;
	private static String id = WB.strEmpty; // TOTHINK
	private List<String> source = new ArrayList<String>(); // TOTHINK
	private List<String> target = new ArrayList<String>(); // TOTHINK

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("ListVal.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "ListVal");
		} finally {
			Etc.doNothing();
		}
	}

	public boolean isListVal() throws Exception { // TODO
		// origin - 17.09.2024, last edit - 17.09.2024
		boolean res = false;
		try {
			if (Etc.strMatch(this.src, ListVal.strSplit) >= 1) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.isListVal, ex=" + ex.getMessage(), WB.strEmpty, "ListVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ListVal.isUnitVal, res=" + res, WB.strEmpty, "ListVal");
		return res;
	}

	private static String getStrListVal(List<ModelDto> segmentAbc, String idListVal, String codeListVal)
			throws Exception {
		// origin - 16.07.2024, last edit - 17.09.2024
		String res = WB.strEmpty;
		try {
			// res = ModelDto.getValueField(segmentAbc, idListVal, codeListVal,
			// ListVal.defaultListVal);
			res = ModelDto.getValueFromMoreByKey(segmentAbc, idListVal, codeListVal);
			res = DefVal.set(res, ModelVal.defVal);
		} catch (Exception ex) {
			WB.addLog("ListVal.getStrListVal, ex=" + ex.getMessage(), WB.strEmpty, "ListVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ListVal.getStrListVal, res=" + res + ", segmentAbc=" + segmentAbc
		// + ", idListVal=" + idListVal, + ", codeListVal" + codeListVal
		// WB.strEmpty, "ListVal");
		return res;
	}

	public ListVal() throws Exception {
		// origin - 16.07.2024, last edit - 16.07.2024
		try {
		} catch (Exception ex) {
			WB.addLog("ListVal.ctor, ex=" + ex.getMessage(), WB.strEmpty, "ListVal");
		} finally {
			Etc.doNothing();
		}
	}

	public static void test() throws Exception {
		// origin - 16.07.2024, last edit - 16.09.2024
		try {

			// Formatter.listVal
			var arg = ListVal.getStrListVal(WB.abcTemplate.listVal, "AbcListVal", "Info.Code.GoldContent");
			WB.addLog2("ListVal.test.Formatter.listVal, res="
					+ Formatter.listVal(Formatter.listVal(arg, ListVal.strSplit), "Info.Code.GoldContent") + ", arg="
					+ arg + ", context=Info.Code.GoldContent", WB.strEmpty, "ListVal");
			arg = ListVal.getStrListVal(WB.abcTemplate.listVal, "AbcListVal", "Info.Code.ProductCondition");
			WB.addLog2("ListVal.test.Formatter.listVal, res="
					+ Formatter.listVal(Formatter.listVal(arg, ListVal.strSplit), "Info.Code.ProductCondition")
					+ ", arg=" + arg + ", context=Info.Code.ProductCondition", WB.strEmpty, "ListVal");

			// getStrListVal
			WB.addLog2("ListVal.test.getStrListVal, res="
					+ ListVal.getStrListVal(WB.abcTemplate.listVal, "AbcListVal", "Info.Code.GoldContent")
					+ ", testArg3=" + "Info.Code.GoldContent", WB.strEmpty, "ListVal");

		} catch (Exception ex) {
			WB.addLog("ListVal.test, ex=" + ex.getMessage(), WB.strEmpty, "ListVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ListVal.test end ", WB.strEmpty, "ListVal");
	}
}
