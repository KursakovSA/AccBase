import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unused")
public class ListVal {
	// origin - 16.07.2024, last edit - 04.09.2024
	private static String strSplit = ":"; // ??magic string??
	private static String defaultListVal = WB.strEmpty;
	private static String id = WB.strEmpty; //TOTHINK
	private List<String> source = new ArrayList<String>(); //TOTHINK
	private List<String> target = new ArrayList<String>(); //TOTHINK

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("ListVal.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "ListVal");
		} finally {
			Etc.doNothing();
		}
	}

	private static String getStrListVal(List<ModelDto> segmentAbc, String idListVal, String codeListVal)
			throws Exception {
		// origin - 16.07.2024, last edit - 17.07.2024
		String res = WB.strEmpty;
		try {
			res = ModelDto.getValueField(segmentAbc, idListVal, codeListVal, ListVal.defaultListVal);
		} catch (Exception ex) {
			WB.addLog("ListVal.getStrListVal, ex=" + ex.getMessage(), WB.strEmpty, "ListVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ListVal.getStrListVal, res=" + res + ", segmentAbc=" + segmentAbc
		// + ", idListVal=" + idListVal, + ", codeListVal" + codeListVal
		// WB.strEmpty, "ListVal");
		return res;
	}

//	private static List<String> getListVal(String initStr) throws Exception {
//		// origin - 16.07.2024, last edit - 04.09.2024
//		List<String> res = new ArrayList<String>();
//		try {
//			initStr = Etc.fixTrim(initStr);
//			String[] tmp = initStr.split(ListVal.strSplit);
//			String currTmp = WB.strEmpty;
//			for (var currArr : tmp) {
//				currTmp = WB.strEmpty;
//				// currTmp = currArr.toString();
//				currTmp = Etc.fixTrim(currArr.toString());
//				// currTmp = currTmp.replace(ListVal.strSplit, WB.strEmpty);
//				if (currTmp.isEmpty() == false) {
//					res.add(currTmp);
//				}
//			}
//
//		} catch (Exception ex) {
//			// WB.addLog("ListVal.getListVal, ex=" + ex.getMessage(), WB.strEmpty,
//			// "ListVal");
//		} finally {
//			Etc.doNothing();
//		}
//
//		// WB.addLog2("ListVal.getListVal, res=" + Etc.logArray(res), WB.strEmpty,
//		// "ListVal");
//		return res;
//	}

	public ListVal() throws Exception {
		// origin - 16.07.2024, last edit - 16.07.2024
		try {
		} catch (Exception ex) {
			WB.addLog("ListVal.ctor, ex=" + ex.getMessage(), WB.strEmpty, "ListVal");
		} finally {
			Etc.doNothing();
		}
	}

	public static void test() throws Exception {
		// origin - 16.07.2024, last edit - 04.09.2024
		try {

//			// getStrListVal
//			WB.addLog2("ListVal.test.getStrListVal, res="
//					+ ListVal.getStrListVal(WB.abcTemplate.listVal, "AbcListVal", "Info.Code.GoldContent")
//					+ ", testArg3=" + "Info.Code.GoldContent", WB.strEmpty, "ListVal");

			// Formatter.listVal
			var arg = ListVal.getStrListVal(WB.abcTemplate.listVal, "AbcListVal", "Info.Code.GoldContent");
			WB.addLog2("ListVal.test.Formatter.listVal, res="
					+ Formatter.listVal(Formatter.listVal(arg, ListVal.strSplit), "Info.Code.GoldContent") + ", arg="
					+ arg + ", context=Info.Code.GoldContent", WB.strEmpty, "ListVal");
			arg = ListVal.getStrListVal(WB.abcTemplate.listVal, "AbcListVal", "Info.Code.ProductCondition");
			WB.addLog2("ListVal.test.Formatter.listVal, res="
					+ Formatter.listVal(Formatter.listVal(arg, ListVal.strSplit), "Info.Code.ProductCondition")
					+ ", arg=" + arg + ", context=Info.Code.ProductCondition", WB.strEmpty, "ListVal");

		} catch (Exception ex) {
			WB.addLog("ListVal.test, ex=" + ex.getMessage(), WB.strEmpty, "ListVal");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("ListVal.test end ", WB.strEmpty, "ListVal");
	}
}
