import java.util.ArrayList;
import java.util.List;

public class ListVal extends ModelVal {
	// origin - 16.07.2024, last edit - 24.03.2025
	// ex. "12:14:23(Unit.EveryDay)", "375:375eqv:583:583eqv:585:850",
	// "CommonExtraDayOff=2022-01-08:2022-01-09(Unit.ExactDate)"
	// "PointBasicDayOff=2023-01-02/P1:2024-01-03/P2:2024-01-04/P4(Unit.ExactDate/Point)"

	public String srcCustom = "";
	public String partVal = "";
	public List<String> val = new ArrayList<String>();
	private static final List<String> listDelStr = List.of("(", ")", "=");

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("ListVal.static ctor, ex=" + ex.getMessage(), "", "ListVal");
		}
	}

	public String getByIndex(int index) throws Exception {
		// origin - 27.02.2025, last edit - 19.03.2025
		String res = "";
		try {
			if (this.val.size() != 0) {
				if (index >= 0) {
					res = this.val.get(index);
				}
			}
		} catch (Exception ex) {
			WB.addLog("ListVal.getByIndex, ex=" + ex.getMessage(), "", "ListVal");
		}
		return res;
	}

	private void getPart() throws Exception {
		// origin - 03.01.2025, last edit - 20.03.2025
		try {
			String tmp = this.src;
			int posMiddleEquation = tmp.indexOf("="); // pos "="
			if (posMiddleEquation > 0) {
				this.partName = Etc.fixTrim(tmp.substring(0, posMiddleEquation));
//				WB.addLog2("ListVal.getPart, this.partName=" + this.partName + ", this.src=" + this.src,"", "ListVal");
				tmp = Etc.delStr(tmp, this.partName);
				tmp = Etc.delStr(tmp, "=");
			}

			int posLocalSplitValUnit = tmp.indexOf(ModelVal.strStartUnit); // pos "(Unit."
			if (posLocalSplitValUnit > 0) {
				this.partVal = Etc.fixTrim(tmp.substring(0, posLocalSplitValUnit));
				this.partUnit = Etc.fixTrim(tmp.substring(posLocalSplitValUnit));
				this.partUnit = Etc.delStr(this.partUnit, ListVal.listDelStr);
			}

			if (this.partUnit.isEmpty()) {
				this.partVal = Etc.fixTrim(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("ListVal.getPart, ex=" + ex.getMessage(), "", "ListVal");
		}
	}

	public ListVal(List<String> initListStr) throws Exception {
		// origin - 44.01.2025, last edit - 24.03.2025
		this();
		this.src = initListStr.toString();
		if (initListStr.size() >= 0) {
			this.val = initListStr;
		}
		this.id = "[" + Fmtr.listVal(this.val, "") + "]";
		this.id = this.id + " " + ", this.val.size " + this.val.size();
	}

	public ListVal(String initStr, String context) throws Exception {// context not use in code, only for different ctor
		// origin - 04.01.2025, last edit - 21.03.2025
		this();
		initStr = Etc.fixTrim(initStr);
		this.src = initStr;
		this.getPart();
		this.getUnit();

		if (Etc.strMatch(this.partVal, ":") >= 0) {// this.partVal = "val1:val2:val3" etc.
			this.val = Fmtr.listVal(this.partVal, ":");
		}

		this.id = "[" + Fmtr.listVal(this.val, "") + "]";
		if (this.partUnit.isEmpty() == false) {
			this.id = this.id + " " + this.unit.code + ", " + this.unit.description;
		}
		this.id = this.id + " " + ", this.val.size " + this.val.size();
	}

	public ListVal(String initStr) throws Exception {
		// origin - 30.09.2024, last edit - 21.03.2025
		this();
		initStr = Etc.fixTrim(initStr);

		this.src = MoreVal.getByKey(WB.abcLast.listVal, "AbcListVal", initStr);
		this.srcCustom = MoreVal.getByKey(WB.abcLast.custom, "Custom", initStr);
		if (this.srcCustom.isEmpty() == false) {
			this.src = this.src + ":" + this.srcCustom;
		}

		this.getPart();
		// this.getUnit();
		this.val = Fmtr.listVal(this.partVal, ":");

		this.id = "[" + Fmtr.listVal(this.val, "") + "]";
//		if (this.partUnit.isEmpty() == false) {
//			this.id = this.id + " " + this.unit.code + ", " + this.unit.description;
//		}
		this.id = this.id + " " + ", this.val.size " + this.val.size();
	}

	public ListVal() throws Exception {
		// origin - 04.09.2024, last edit - 30.09.2024
		super();
	}

	public String toString() {
		// origin - 03.01.2025, last edit - 21.03.2025
		String res = "";
		try {
			res = this.id + " " + ", src " + this.src + ", context " + this.context;
		} catch (Exception ex) {
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 16.07.2024, last edit - 24.03.2025
		try {

//			// ctor (initStr)
//			for (var tmp : new String[] { "Info.Code.GoldContent", "Info.Code.ProductCondition" }) {
//				WB.addLog2("ListVal.test.ctor(initStr)=" + new ListVal(tmp), "", "ListVal");
//			}

//			// ctor (List<String>)
//			List<String> listStr1 = new ArrayList<String>();
//			listStr1 = Fmtr.listVal("2025-01-23: 2025-02-14:", ":");
//			WB.addLog2("ListVal.test.ctor(List<String>)=" + new ListVal(listStr1), "", "ListVal");

//			// ctor (initStr,context)
//			var tmp = new ListVal("PieceAnything=1:2(Unit.Piece)", "");
//			WB.addLog2("ListVal.test.ctor(initStr,context)=" + tmp, "", "ListVal");

//			//CommonExtraDayOff=2022-01-08:2022-01-09(Unit.ExactDate)
//			var tmp1 = new ListVal("CommonExtraDayOff=2022-01-08:2022-01-09(Unit.ExactDate)", "");
//			WB.addLog2("ListVal.test.ctor(initStr,context)=" + tmp1, "", "ListVal");
//			for (var partListVal1 : tmp1.val) {
//				WB.addLog2("ListVal.test.ctor, ListVal(LocalDate)=" + DateTool.getLocalDate(partListVal1), "","ListVal");
//			}

//			// PointBasicDayOff=2023-01-02/P1:2024-01-03/P2:2024-01-04/P4(Unit.ExactDate/Point)
//			var tmp2 = new ListVal("PointBasicDayOff=2023-01-02/P1:2024-01-03/P2:2024-01-04/P4(Unit.ExactDate/Point)","");
//			WB.addLog2("ListVal.test.ctor(initStr,context)=" + tmp2, "", "ListVal");
//			for (var partListVal2 : tmp2.val) {
//				WB.addLog2("ListVal.test.ctor, ListVal(String)=" + partListVal2, "", "ListVal");
//			}

		} catch (Exception ex) {
			WB.addLog("ListVal.test, ex=" + ex.getMessage(), "", "ListVal");
		}
	}
}