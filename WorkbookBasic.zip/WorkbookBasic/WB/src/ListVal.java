import java.util.ArrayList;
import java.util.List;

public class ListVal {
	// origin - 16.07.2024, last edit - 17.07.2024
	private static String strSplit = ":";
	private static String defaultListVal = WB.strEmpty;

	private static String getStrListVal(List<ModelDto> segmentAbc, String idListVal, String codeListVal)
			throws Exception {
		// origin - 16.07.2024, last edit - 17.07.2024
		String res = WB.strEmpty;
		try {
			res = ModelDto.getValueField(segmentAbc, idListVal, codeListVal, ListVal.defaultListVal);
		} catch (Exception ex) {
			WB.addLog("ListVal.getStrListVal, ex=" + ex.getMessage(), WB.strEmpty, "ListVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ListVal.getStrListVal, res=" + res + ", segmentAbc=" + segmentAbc
		// + ", idListVal=" + idListVal, + ", codeListVal" + codeListVal
		// WB.strEmpty, "ListVal");
		return res;
	}

	private static List<String> getListVal(String initStr) throws Exception {
		// origin - 16.07.2024, last edit - 17.07.2024
		List<String> res = new ArrayList<String>();
		try {
			initStr = Etc.fixTrim(initStr);
			String[] tmp = initStr.split(ListVal.strSplit);
			String currTmp = WB.strEmpty;
			for (var currArr : tmp) {
				currTmp = WB.strEmpty;
				currTmp = currArr.toString();
				// currTmp = currTmp.replace(ListVal.strSplit, WB.strEmpty);
				if (currTmp.isEmpty() == false) {
					res.add(currTmp);
				}
			}

		} catch (Exception ex) {
			// WB.addLog("ListVal.getListVal, ex=" + ex.getMessage(), WB.strEmpty,
			// "ListVal");
		} finally {
			Etc.doNothing();
		}

		// WB.addLog2("ListVal.getListVal, res=" + Etc.logArray(res), WB.strEmpty,
		// "ListVal");
		return res;
	}

	public ListVal() throws Exception {
		// origin - 16.07.2024, last edit - 16.07.2024
		try {
		} catch (Exception ex) {
			WB.addLog("ListVal.ctor, ex=" + ex.getMessage(), WB.strEmpty, "ListVal");
		} finally {
			Etc.doNothing();
		}
	}

	public static void test() throws Exception {
		// origin - 16.07.2024, last edit - 17.07.2024
		try {

			// getVal
			WB.addLog2("ListVal.test.getVal, res="
					+ ListVal.getStrListVal(WB.abcTemplate.listVal, "AbcListVal", "Info.Code.GoldContent")
					+ ", testArg3=" + "Info.Code.GoldContent", WB.strEmpty, "ListVal");

			// getStrListVal
			var arg1 = new String[] {
					ListVal.getStrListVal(WB.abcTemplate.listVal, "AbcListVal", "Info.Code.GoldContent"),
					ListVal.getStrListVal(WB.abcTemplate.listVal, "AbcListVal", "Info.Code.ProductCondition"), null };
			for (var testArg1 : arg1) {
				WB.addLog2("ListVal.test.getStrListVal, res=" + Etc.logList(ListVal.getListVal(testArg1))
						+ ", testArg1=" + testArg1, WB.strEmpty, "ListVal");
			}

		} catch (Exception ex) {
			WB.addLog("ListVal.test, ex=" + ex.getMessage(), WB.strEmpty, "ListVal");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("ListVal.test end ", WB.strEmpty, "ListVal");
	}
}
