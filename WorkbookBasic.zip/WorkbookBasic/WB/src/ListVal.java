import java.util.ArrayList;
import java.util.List;

public class ListVal extends ModelVal {
	// origin - 16.07.2024, last edit - 17.11.2024
	// ex. "12:14:23", "375:375eqv:583:583eqv:585:850:875:925:958:960:999" etc.

	private String abcKey = WB.strEmpty;
	public String srcCustom = WB.strEmpty;
	public List<String> val = new ArrayList<String>();

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("ListVal.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "ListVal");
		} finally {
			Etc.doNothing();
		}
	}

	public ListVal(String AbcKey) throws Exception {
		// origin - 30.09.2024, last edit - 22.11.2024
		this();
		this.abcKey = Etc.fixTrim(AbcKey);
		this.src = MoreVal.getByKey(WB.abcLast.listVal, "AbcListVal", this.abcKey);
		this.srcCustom = MoreVal.getByKey(WB.abcLast.custom, "Custom", this.abcKey);
		if (this.srcCustom.isEmpty() == false) {
			this.src = this.src + WB.strColon + this.srcCustom;
		}
		this.src = DefVal.set(this.src, WB.strEmpty);
		this.val = Formatter.listVal(this.src, WB.strColon);
	}

	public ListVal() throws Exception {
		// origin - 04.09.2024, last edit - 30.09.2024
		super();
	}

	public static void test() throws Exception {
		// origin - 16.07.2024, last edit - 19.11.2024
		try {

//			// ctor1
//			ListVal lv1 = new ListVal("Info.Code.GoldContent");
//			WB.addLog2("ListVal.test.ctor1=" + lv1 + ", abcKey=" + lv1.abcKey, WB.strEmpty, "ListVal");

//			// ctor2
//			ListVal lv2 = new ListVal("Info.Code.ProductCondition");
//			WB.addLog2("ListVal.test.ctor2=" + lv2 + ", abcKey=" + lv2.abcKey, WB.strEmpty, "ListVal");

		} catch (Exception ex) {
			WB.addLog("ListVal.test, ex=" + ex.getMessage(), WB.strEmpty, "ListVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ListVal.test end ", WB.strEmpty, "ListVal");
	}
}
