import java.util.ArrayList;
import java.util.List;

public final class Balance {
	// origin - 24.09.2026, last edit - 07.11.2026
	public List<DocItem> headerList;
	public List<DocItem> itemList;
	public List<DocItem> footerList;
	public List<DocItem> totalList;
	public String summary;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Balance.static ctor, ex=" + ex.getMessage(), "", "Balance");
		}
	}

	public static List<Workbook> massPrint(String id) throws Exception { // TODO
		// origin - 07.11.2026, last edit - 07.11.2026
		List<Workbook> res = new ArrayList<Workbook>();
		try {

		} catch (Exception ex) {
			WB.addLog("Balance.massPrint(String):List<Workbook>, ex=" + ex.getMessage(), "", "Balance");
		}
		return res;
	}

	public static List<Workbook> summaryPrint(String id) throws Exception { // TODO
		// origin - 07.11.2026, last edit - 07.11.2026
		List<Workbook> res = new ArrayList<Workbook>();
		try {

		} catch (Exception ex) {
			WB.addLog("Balance.summaryPrint(String):List<Workbook>, ex=" + ex.getMessage(), "", "Balance");
		}
		return res;
	}

	public static List<String> getNameList() throws Exception {
		// origin - 06.11.2026, last edit - 06.11.2026
		List<String> res = new ArrayList<String>();
		try {
			for (var curr : WB.abcGlobal.name) {
				if (curr.id.startsWith("Balance.Name")) {
					var tmp1 = List.of(curr.meterValue.split(";"));
					if (tmp1.size() != 0) {
						res.addAll(tmp1);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Balance.getNameList():List<String>, ex=" + ex.getMessage(), "", "Balance");
		}
		return res;
	}

	public Balance(String Id) throws Exception { // TODO
		// origin - 06.11.2026, last edit - 06.11.2026
		this.clear();
	}

	public Balance() throws Exception {
		// origin - 06.11.2026, last edit - 06.11.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 06.11.2026, last edit - 07.11.2026
		try {
			this.headerList = new ArrayList<DocItem>();
			this.itemList = new ArrayList<DocItem>();
			this.footerList = new ArrayList<DocItem>();
			this.totalList = new ArrayList<DocItem>();
			this.summary = "";
		} catch (Exception ex) {
			WB.addLog("Balance.clear():void, ex=" + ex.getMessage(), "", "Balance");
		}
	}

	public String toString() {
		// origin - 06.11.2026, last edit - 07.11.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("headerList ", this.headerList);
			res = res + Fmtr.addIfNotEmpty(", itemList ", this.itemList);
			res = res + Fmtr.addIfNotEmpty(", footerList ", this.footerList);
			res = res + Fmtr.addIfNotEmpty(", totalList ", this.totalList);
			res = res + Fmtr.addIfNotEmpty(", summary ", this.summary);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 24.09.2026, last edit - 06.11.2026
		try {

//			{
//				WB.addLog2("Balance.test.getNameList():List<String>", "", "Balance");
//				var tmp1 = Balance.getNameList();
//				WB.addLog2("Balance.test.getNameList():List<String>, res.size=" + tmp1.size() + ", tmp1 " + tmp1, "",
//						"Balance");
//			}

		} catch (Exception ex) {
			WB.addLog("Balance.test():void, ex=" + ex.getMessage(), "", "Balance");
		}
	}
}