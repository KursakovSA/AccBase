import java.util.LinkedHashMap;

public final class SPL {
	// origin - 17.10.2024, last edit - 12.10.2025
	public String context, src, partWhole, partFractional, valStr;
	public double valDbl;
	// public String partWhole;
	public String decryptionWhole = ""; // TODO
	// public String partFractional;
	public String decryptionFractional = ""; // TODO
	// public String valStr;
	// public String context;
	public String numberWord = "";

	private static LinkedHashMap<String, String> numberWordMap = new LinkedHashMap<String, String>();
	private static LinkedHashMap<String, String> decryptionWholeMap = new LinkedHashMap<String, String>();
	private static LinkedHashMap<String, String> decryptionFractionalMap = new LinkedHashMap<String, String>();

	static {
		try {
			SPL.numberWordMap = SPL.getNumberWordMap();
			SPL.decryptionWholeMap = SPL.getDecryptionWholeMap();
			SPL.decryptionFractionalMap = SPL.getDecryptionFractionalMap();
		} catch (Exception ex) {
			WB.addLog("SPL.static ctor, ex=" + ex.getMessage(), "", "SPL");
		}
	}

	private void getDigit() throws Exception {
		// origin - 17.10.2024, last edit - 14.06.2025
		try {
			int countDigit = 0;
			String keyMap = "";

			// get whole
			if (Etc.strEquals(this.partWhole, "") == false) {
				String reversePartWhole = new StringBuilder(this.partWhole).reverse().toString();
				for (var currDigit : reversePartWhole.toCharArray()) {
					countDigit = countDigit + 1;
					keyMap = "";
					keyMap = String.valueOf(countDigit) + String.valueOf(currDigit); // разряд + значение разряда
					if (Etc.strEquals(this.getByKey(keyMap), "") == false) {
						this.numberWord = this.getByKey(keyMap) + " " + this.numberWord;
					}
				}
				// if (Etc.strEquals(this.partWhole, "") == false) {
				this.decryptionWhole = SPL.decryptionWholeMap.get(context);
				if (Etc.strEquals(this.decryptionWhole, "") == false) {
					this.numberWord = this.numberWord + " " + this.decryptionWhole;
				}
			}

			// get fractional
			if (Etc.strEquals(this.partFractional, "") == false) {
				String reversePartFractional = new StringBuilder(this.partFractional).reverse().toString();
				for (var currDigit : reversePartFractional.toCharArray()) {
					countDigit = countDigit + 1;
					keyMap = "";
					keyMap = String.valueOf(countDigit) + String.valueOf(currDigit); // разряд + значение разряда
					if (Etc.strEquals(this.getByKey(keyMap), "") == false) {
						this.numberWord = this.getByKey(keyMap) + " " + this.numberWord;
					}
				}
				this.decryptionFractional = SPL.decryptionFractionalMap.get(context);
				if (Etc.strEquals(this.decryptionFractional, "") == false) {
					this.numberWord = this.numberWord + " " + this.decryptionFractional;
				}
			}
		} catch (Exception ex) {
			WB.addLog("SPL.getDigit():void, ex=" + ex.getMessage(), "", "SPL");
		}
	}

	private String getByKey(String keyMap) throws Exception {
		// origin - 17.10.2024, last edit - 14.06.2025
		String res = "";
		try {
			for (var entry : SPL.numberWordMap.entrySet()) {
				String key = entry.getKey();
				String value = entry.getValue();
				if (Etc.strEquals(key, keyMap)) {
					res = value;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("SPL.getByKey(String keyMap):String, ex=" + ex.getMessage(), "", "SPL");
		}
		return res;
	}

	private void getPart() throws Exception {
		// origin - 17.10.2024, last edit - 14.06.2025
		try {
			int posDot = 0;
			posDot = this.src.indexOf(".") + 1;
			String probePartFractional = "";
			if (posDot != 0) {
				probePartFractional = this.src.substring(posDot);
				this.partFractional = probePartFractional;
				this.partWhole = this.src.substring(0, posDot - 1);
				this.partWhole = Etc.delLeaderPlaceholder(this.partWhole, "0");
			}

			if ((posDot == 0) && (Etc.isDigitAll(this.src))) {
				this.partFractional = "";
				this.partWhole = this.src;
				this.partWhole = Etc.delLeaderPlaceholder(this.partWhole, "0");
			}
		} catch (Exception ex) {
			WB.addLog("SPL.getPart():void, ex=" + ex.getMessage(), "", "SPL");
		}
	}

	private void getVal() throws Exception {
		// origin - 17.10.2024, last edit - 14.06.2025
		try {
			this.valDbl = Conv.getDouble(this.src);

			if (this.valDbl == 0.0) {
				this.valStr = Etc.fixTrim(this.src);
			}
		} catch (Exception ex) {
			WB.addLog("SPL.getVal():void, ex=" + ex.getMessage(), "", "SPL");
		}
	}

	public SPL(String Src, String context) throws Exception {
		// origin - 19.10.2024, last edit - 19.10.2024
		this.src = Etc.fixTrim(Src);
		this.context = context;
		this.getVal();
		this.getPart();
		this.getDigit();
	}

	public SPL(String Src) throws Exception {
		// origin - 17.10.2024, last edit - 19.10.2024
		this.src = Etc.fixTrim(Src);
		this.context = "amount";
		this.getVal();
		this.getPart();
		this.getDigit();
	}

	public String toString() {
		// origin - 17.10.2024, last edit - 29.06.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" context ", this.context);
			res = res + Fmtr.addIfNotEmpty(" src ", this.src);
			res = res + Fmtr.addIfNotEmpty(" partWhole ", this.partWhole);
			res = res + Fmtr.addIfNotEmpty(" partFractional ", this.partFractional);
			res = res + Fmtr.addIfNotEmpty(" valStr ", this.valStr);
			res = res + Fmtr.addIfNotEmpty(" valDbl ", this.valDbl);
			res = res + Fmtr.addIfNotEmpty(" decryptionWhole ", this.decryptionWhole);
			res = res + Fmtr.addIfNotEmpty(" decryptionFractional ", this.decryptionFractional);
			res = res + Fmtr.addIfNotEmpty(" numberWord ", this.numberWord);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 17.10.2024, last edit - 14.06.2025
		try {

			// test ctor(String)
			WB.addLog2("SPL.test.ctor(String)", "", "SPL");
			for (var tmp1 : new String[] { "0.13", "7", "16", "93", "713", "7894.1356", "564.13", "7155674.89",
					"109090965", "4578109090965", "03", "5100" }) {
				WB.addLog2("SPL.test.ctor(String)=" + new SPL(tmp1), "", "SPL");
			}

		} catch (Exception ex) {
			WB.addLog("SPL.test():void, ex=" + ex.getMessage(), "", "SPL");
		}
	}

	private static LinkedHashMap<String, String> getDecryptionFractionalMap() throws Exception {
		// origin - 19.10.2024, last edit - 14.06.2025
		LinkedHashMap<String, String> res = new LinkedHashMap<String, String>();
		try {
			res.put("amount", "тиын");
			res.put("quantity", "десятых");
		} catch (Exception ex) {
			WB.addLog("SPL.getDecryptionFractionalMap():LinkedHashMap<String, String>, ex=" + ex.getMessage(), "",
					"SPL");
		}
		return res;
	}

	private static LinkedHashMap<String, String> getDecryptionWholeMap() throws Exception {
		// origin - 19.10.2024, last edit - 14.06.2025
		LinkedHashMap<String, String> res = new LinkedHashMap<String, String>();
		try {
			res.put("amount", "тенге");
			res.put("quantity", "целых");
		} catch (Exception ex) {
			WB.addLog("SPL.getDecryptionWholeMap():LinkedHashMap<String, String>, ex=" + ex.getMessage(), "", "SPL");
		}
		return res;
	}

	private static LinkedHashMap<String, String> getNumberWordMap() throws Exception {
		// origin - 17.10.2024, last edit - 14.06.2025
		LinkedHashMap<String, String> res = new LinkedHashMap<String, String>();
		try {
			// ноль - особый случай, исключение
			res.put("0", "ноль");
			// единицы
			SPL.getUnit(1, res);
			// десятки
			SPL.getTen(2, res);
			// сотни
			SPL.getHundred(3, res);
			// единицы тысячи
			res.put("40", "тысяч");
			res.put("42", "две тысячи"); // 1 - разряд, 2 - цифра (значение) разряда
			res.put("43", "три тысячи");
			res.put("44", "четыре тысячи");
			res.put("45", "пять тысяч");
			res.put("46", "шесть тысяч");
			res.put("47", "семь тысяч");
			res.put("48", "восемь тысяч");
			res.put("49", "девять тысяч");
			res.put("41", "одна тысяча");
			res.put("42", "две тысячи"); // 1 - разряд, 2 - цифра (значение) разряда
			res.put("43", "три тысячи");
			res.put("44", "четыре тысячи");
			res.put("45", "пять тысяч");
			res.put("46", "шесть тысяч");
			res.put("47", "семь тысяч");
			res.put("48", "восемь тысяч");
			res.put("49", "девять тысяч");
			// десятки тысяч
			SPL.getTen(5, res);
			// сотни тысяч
			SPL.getHundred(6, res);
			// единицы миллионов
			res.put("70", "миллионов");
			res.put("71", "один миллион");
			res.put("72", "два миллиона"); // 1 - разряд, 2 - цифра (значение) разряда
			res.put("73", "три миллиона");
			res.put("74", "четыре миллиона");
			res.put("75", "пять миллионов");
			res.put("76", "шесть миллионов");
			res.put("77", "семь миллионов");
			res.put("78", "восемь миллионов");
			res.put("79", "девять миллионов");
			// десятки миллионов
			SPL.getTen(8, res);
			// сотни миллионов
			SPL.getHundred(9, res);
			// единицы миллиардов
			res.put("100", "миллиардов");
			res.put("101", "один миллиард");
			res.put("102", "два миллиарда"); // 1 - разряд, 2 - цифра (значение) разряда
			res.put("103", "три миллиарда");
			res.put("104", "четыре миллиарда");
			res.put("105", "пять миллиардов");
			res.put("106", "шесть миллиардов");
			res.put("107", "семь миллиардов");
			res.put("108", "восемь миллиардов");
			res.put("109", "девять миллиардов");
			// десятки миллиардов
			SPL.getTen(11, res);
			// сотни миллиардов
			SPL.getHundred(12, res);
			// единицы триллонов
			res.put("130", "триллионов");
			res.put("131", "один триллион");
			res.put("132", "два триллиона"); // 1 - разряд, 2 - цифра (значение) разряда
			res.put("133", "три триллиона");
			res.put("134", "четыре триллиона");
			res.put("135", "пять триллионов");
			res.put("136", "шесть триллионов");
			res.put("137", "семь триллионов");
			res.put("138", "восемь триллонов");
			res.put("139", "девять триллионов");
			// десятки триллионов
			SPL.getTen(14, res);
			// сотни триллионов
			SPL.getHundred(15, res);
		} catch (Exception ex) {
			WB.addLog("SPL.getNumberWordMap():LinkedHashMap<String, String>, ex=" + ex.getMessage(), "", "SPL");
		}
		return res;
	}

	private static void getUnit(int position, LinkedHashMap<String, String> map) throws Exception {
		// origin - 19.10.2024, last edit - 14.06.2025
		try {
			String pos = String.valueOf(position);
			// map.put(pos + "0", "ноль");
			map.put(pos + "1", "один");
			map.put(pos + "2", "два"); // 1 - разряд, 2 - цифра (значение) разряда
			map.put(pos + "3", "три");
			map.put(pos + "4", "четыре");
			map.put(pos + "5", "пять");
			map.put(pos + "6", "шесть");
			map.put(pos + "7", "семь");
			map.put(pos + "8", "восемь");
			map.put(pos + "9", "девять");
		} catch (Exception ex) {
			WB.addLog("SPL.getUnit(int position, LinkedHashMap<String, String> map):void, ex=" + ex.getMessage(), "",
					"SPL");
		}
	}

	private static void getTen(int position, LinkedHashMap<String, String> map) throws Exception {
		// origin - 19.10.2024, last edit - 14.06.2025
		try {
			String pos = String.valueOf(position);
			map.put(pos + "1", "десять");
			map.put(pos + "2", "двадцать"); // 1 - разряд, 2 - цифра (значение) разряда
			map.put(pos + "3", "тридцать");
			map.put(pos + "4", "сорок");
			map.put(pos + "5", "пятьдесят");
			map.put(pos + "6", "шестьдесят");
			map.put(pos + "7", "семьдесят");
			map.put(pos + "8", "восемьдесят");
			map.put(pos + "9", "девяносто");
		} catch (Exception ex) {
			WB.addLog("SPL.getTen(int position, LinkedHashMap<String, String> map):void, ex=" + ex.getMessage(), "",
					"SPL");
		}
	}

	private static void getHundred(int position, LinkedHashMap<String, String> map) throws Exception {
		// origin - 19.10.2024, last edit - 14.06.2025
		try {
			String pos = String.valueOf(position);
			map.put(pos + "1", "сто");
			map.put(pos + "2", "двести"); // 1 - разряд, 2 - цифра (значение) разряда
			map.put(pos + "3", "триста");
			map.put(pos + "4", "четыреста");
			map.put(pos + "5", "пятьсот");
			map.put(pos + "6", "шестьсот");
			map.put(pos + "7", "семьсот");
			map.put(pos + "8", "восемьсот");
			map.put(pos + "9", "девятьсот");
		} catch (Exception ex) {
			WB.addLog("SPL.getHundred(int position, LinkedHashMap<String, String> map):void, ex=" + ex.getMessage(), "",
					"SPL");
		}
	}
}