import java.util.TreeSet;

public final class Report {
	// origin - 16.10.2023, last edit - 15.08.2026
	public static TreeSet<String> standard = new TreeSet<String>();
	public static TreeSet<String> sectoral = new TreeSet<String>();
	public static TreeSet<String> custom = new TreeSet<String>();
	public static String defaultCellPhonePrefix = "";

	static {
		Report.defaultCellPhonePrefix = "+7-747";
	}

	public static String getKZIINPlaceholder() throws Exception {// sectoral pawnshop
		// origin - 26.06.2024, last edit - 15.09.2026
		String res = "";
		try {
			res = res + Num.getStrIntRnd(FaceGovId.lenghtIIN); // TODO - how do first 6 numbers in view date - 671125 ???
		} catch (Exception ex) {
			WB.addLog("Report.getKZIINPlaceholder():String, ex=" + ex.getMessage(), "", "Report");
		}
		return res;
	}

	public static String getCellPhonePlaceholder(String initCellPhonePrefix) throws Exception {// sectoral pawnshop
		// origin - 19.06.2024, last edit - 15.09.2026
		// this method need that fill field "cell phone" in report for gov organs, when
		// cell phone not know, but gov organs require you to indicate it
		String res = "";
		try {
			if (initCellPhonePrefix.isEmpty()) {
				initCellPhonePrefix = Report.defaultCellPhonePrefix;
			}
			res = res + Etc.fixTrim(initCellPhonePrefix);
			res = res + "-" + Num.getStrIntRnd(3);
			res = res + "-" + Num.getStrIntRnd(2);
			res = res + "-" + Num.getStrIntRnd(2); // res = ex. +7-747-567-32-71 random cell phone number
		} catch (Exception ex) {
			WB.addLog("Report.getCellPhonePlaceholder(String):String, ex=" + ex.getMessage(), "", "Report");
		}
		return res;
	}

	public Report() throws Exception {
		// origin - 06.07.2024, last edit - 01.05.2025
	}

	public static void test() throws Exception {
		// origin - 06.12.2023, last edit - 14.06.2025
		try {

//			// getKZIINPlaceholder
//			WB.addLog2("Report.getKZIINPlaceholder, res=" + getKZIINPlaceholder(), "", "Report");

//			// getCellPhonePlaceholder
//			for (String testArg1 : new String[] { "+7-701", "+7-707", Report.defaultCellPhonePrefix, "+7-777", "+7-775",""}) {
//				WB.addLog2("Report.test.getCellPhonePlaceholder, res=" + getCellPhonePlaceholder(testArg1)
//						+ ", testArg1=" + testArg1, "", "Report");
//			}

		} catch (Exception ex) {
			WB.addLog("Report.test():void, ex=" + ex.getMessage(), "", "Report");
		}
	}
}