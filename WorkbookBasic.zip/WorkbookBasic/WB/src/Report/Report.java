import java.util.ArrayList;
import java.util.List;

public final class Report { // TODO
	// origin - 13.04.2026, last edit - 07.11.2026

	public static List<Workbook> massPrint(String id) throws Exception { // TODO
		// origin - 07.11.2026, last edit - 07.11.2026
		List<Workbook> res = new ArrayList<Workbook>();
		try {

		} catch (Exception ex) {
			WB.addLog("Report.massPrint(String):List<Workbook>, ex=" + ex.getMessage(), "", "Report");
		}
		return res;
	}

	public static List<Workbook> summaryPrint(String id) throws Exception { // TODO
		// origin - 07.11.2026, last edit - 07.11.2026
		List<Workbook> res = new ArrayList<Workbook>();
		try {

		} catch (Exception ex) {
			WB.addLog("Report.summaryPrint(String):List<Workbook>, ex=" + ex.getMessage(), "", "Report");
		}
		return res;
	}

	public static List<String> getNameList() throws Exception {
		// origin - 07.11.2026, last edit - 07.11.2026
		List<String> res = new ArrayList<String>();
		try {
			for (var curr : WB.abcGlobal.name) {
				if (curr.id.startsWith("Report.Name")) {
					var tmp1 = List.of(curr.meterValue.split(";"));
					if (tmp1.size() != 0) {
						res.addAll(tmp1);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Report.getNameList():List<String>, ex=" + ex.getMessage(), "", "Report");
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 13.04.2026, last edit - 07.11.2026
		try {

//			{
//				WB.addLog2("Report.test.getNameList():List<String>", "", "Report");
//				var tmp1 = Report.getNameList();
//				WB.addLog2("Report.test.getNameList():List<String>, res.size=" + tmp1.size() + ", tmp1 " + tmp1, "",
//						"Report");
//			}

		} catch (Exception ex) {
			WB.addLog("Report.test():void, ex=" + ex.getMessage(), "", "Report");
		}
	}
}