public class Account extends ModelDto {
	// origin - 27.09.2023, last edit - 10.11.2024
	public String accountTable;// TOTHINK
	public String workTable;// TOTHINK
	public String standardTable;// TOTHINK

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Account.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Account");
		} finally {
			Etc.doNothing();
		}
	}

	public String getTable(String inCode) throws Exception {// TOTHINK
		// origin - 10.11.2024, last edit - 10.11.2024
		String res = WB.strEmpty;
		inCode = Etc.fixTrim(inCode);
		try {

		} catch (Exception ex) {
			WB.addLog("Account.getTable, ex=" + ex.getMessage(), WB.strEmpty, "Account");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Account.getTable, res=" + res + ", inCode=" + inCode,WB.strEmpty,
		// "Account");
		return res;
	}

	// this account contains in standard table
	public boolean isStandard(String inCode) throws Exception {// TOTHINK
		// origin - 10.11.2024, last edit - 10.11.2024
		boolean res = false;
		inCode = Etc.fixTrim(inCode);
		try {
			inCode = inCode.replace("Account.", WB.strEmpty);
			inCode = inCode.replace("Account", WB.strEmpty);
		} catch (Exception ex) {
			WB.addLog("Account.isStandard, ex=" + ex.getMessage(), WB.strEmpty, "Account");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Account.isStandard, res=" + res + ", inCode=" +
		// inCode,WB.strEmpty, "Account");
		return res;
	}

	// this account contains in work table
	public boolean isWork(String inCode) throws Exception {// TOTHINK
		// origin - 10.11.2024, last edit - 10.11.2024
		boolean res = false;
		inCode = Etc.fixTrim(inCode);
		try {
			inCode = inCode.replace("Account.", WB.strEmpty);
			inCode = inCode.replace("Account", WB.strEmpty);
		} catch (Exception ex) {
			WB.addLog("Account.isWork, ex=" + ex.getMessage(), WB.strEmpty, "Account");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Account.isWork, res=" + res + ", inCode=" + initCode,
		// WB.strEmpty,
		// "Account");
		return res;
	}

	public static String getCode(String initCode) throws Exception {
		// origin - 30.06.2024, last edit - 30.06.2024
		String res = Etc.fixTrim(initCode);
		try {
			res = res.replace("Account.", WB.strEmpty);
			res = res.replace("Account", WB.strEmpty);
		} catch (Exception ex) {
			WB.addLog("Account.getCode, ex=" + ex.getMessage(), WB.strEmpty, "Account");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Account.getCode, res=" + res + ", initCode=" + initCode,
		// WB.strEmpty, "Account");
		return res;
	}

	public Account(String Id, String Code, String Description) throws Exception {
		// origin - 05.12.2023, last edit - 11.08.2024
		super(Id, Code, Description);
		this.table = this.getClass().getName();
	}

	public Account() throws Exception {
		// origin - 04.12.2023, last edit - 11.08.2024
		super();
		this.table = this.getClass().getName();
	}

	public String toString() {
		// origin - 27.09.2024, last edit - 27.09.2024
		String res = WB.strEmpty;
		try {
			res = this.code + WB.strSpace + this.description;
		} catch (Exception ex) {
			// WB.addLog("Account.toString, ex=" + ex.getMessage(), WB.strEmpty,
			// "Account");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 16.09.2024
		try {

//		// getCode
//		var arg12 = new String[] { "1110", "Account.1210", "Account3350" };
//		for (var testArg1 : arg12) {
//			WB.addLog2("Account.test.getCode, res=" + getCode(testArg1) + ", testArg1=" + testArg1, WB.strEmpty,
//					"Account");
//		}

		} catch (Exception ex) {
			WB.addLog("Account.test, ex=" + ex.getMessage(), WB.strEmpty, "Account");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Account.test end ", WB.strEmpty, "Account");
	}
}