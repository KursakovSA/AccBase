//@SuppressWarnings("unused")
public class Account extends ModelDto {
	// origin - 27.09.2023, last edit - 23.01.2025
	public static String currStandardTable;
	public String accountTable, codeMatch, identificationCode;

	static {
		try {
			Account.currStandardTable = Account.getCurrStandardTable();
		} catch (Exception ex) {
			WB.addLog("Account.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Account");
		} finally {
			Etc.doNothing();
		}
	}

	public void fix() throws Exception {
		// origin - 28.12.2024, last edit - 01.01.2025
		try {
			super.fix();
			this.slice = DefVal.set(this.slice, Slice.Norm);
			this.sign = DefVal.set(this.sign, Sign.AcctDt);
		} catch (Exception ex) {
			WB.addLog("Account.fix, ex=" + ex.getMessage(), WB.strEmpty, "Account");
		} finally {
			Etc.doNothing();
		}
	}

	public static String getCurrStandardTable() throws Exception {
		// origin - 15.12.2024, last edit - 17.12.2024
		String res = WB.strEmpty;
		try {
			for (var currRole : WB.abcLast.role) {
				if (Etc.strContains(currRole.code, Role.accountStandardTable)) {// "Role.Account.AccTable")) {
					if (currRole.date1.isEmpty() & (currRole.date2.isEmpty())) {// skip work table, off balance table
						continue;
					}
					// skip not actual
					if ((currRole.date2.isEmpty() == false)
							& (DateTool.getLocalDate(currRole.date2).isBefore(DateTool.getNow()))) {
						continue;
					}
					res = currRole.code;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Account.getCurrStandardTable, ex=" + ex.getMessage(), WB.strEmpty, "Account");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Account.getCurrStandardTable, res=" + res, WB.strEmpty,
		// "Account");
		return res;
	}

//	public void getAccountTable() throws Exception { // TODO
//		// origin - 12.12.2024, last edit - 15.12.2024
//		try {
////			if (Etc.strContains(this.more, "AbcTable=Account.Table")) {
////				this.accountTable = WB.strEmpty;
////				return;
////			}
//
//			ModelDto currAcc = ReadSet.getEqualsByCode(WB.abcLast.account, this.parent).getFirst();
//			// int count = 0;
//			String tmp = WB.strEmpty;
//
//			// for (;;) {
////			count = count + 1;
////			if (count > 4) {
////				// break;
////			}
//			// if (Etc.strContains(currAcc.more, "AbcTable=Account.Table")) {
//			if (Etc.strEquals(currAcc.role, "Role.Account.AccTableWork")
//					| (Etc.strEquals(currAcc.role, "Role.Account.AccTable2019"))) {
//				this.accountTable = currAcc.id;
////					WB.addLog2("Account.getAccountTable=" + this.accountTable + ", this.code=" + this.code, WB.strEmpty,
////							"Account");
//				// break;
//				// return;
//			}
//			// }
//
//		} catch (Exception ex) {
//			WB.addLog("Account.getAccountTable, ex=" + ex.getMessage(), WB.strEmpty, "Account");
//		} finally {
//			Etc.doNothing();
//		}
//		WB.addLog2("Account.getAccountTable=" + this.accountTable + ", this.code=" + this.code, WB.strEmpty, "Account");
//	}

	public void getRole() throws Exception {
		// origin - 12.12.2024, last edit - 12.12.2024
		try {
			if (this.role.isEmpty() & (this.parent.isEmpty() == false)) {
				Account accForRole = new Account(this.parent);
				if (accForRole.role.isEmpty() == false) {
					this.role = accForRole.role;
				}
			}

		} catch (Exception ex) {
			WB.addLog("Account.getRole, ex=" + ex.getMessage(), WB.strEmpty, "Account");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Account.getRole=" + this.role + ", this.code=" + this.code,
		// WB.strEmpty, "Account");
	}

	public void getMatch() throws Exception {
		// origin - 08.12.2024, last edit - 02.01.2025
		try {

			// direct match (Customer -> 1210)
			for (var currAccMatch : WB.abcGlobal.accountMatching) {
				if (Etc.strEquals(Etc.delStr(currAccMatch.code, "Matching."), this.code)) {
					// skip not actual
					if ((currAccMatch.date2.isEmpty() == false)
							& (DateTool.getLocalDate(currAccMatch.date2).isBefore(DateTool.getLocalDate(this.date1)))) { // DateTool.getNow()
//					WB.addLog2("Account.getMatch, skip=" + currAccMatch + ", this.code=" + this.code, WB.strEmpty,
//							"Account");
						continue;
					}
					this.codeMatch = currAccMatch.meterValue;
				}
			}

			// reverse match, actual not applicable (1210 -> Customer)
			if (this.codeMatch.isEmpty()) {
				for (var currAccMatch : WB.abcGlobal.accountMatching) {
					if (Etc.strEquals(currAccMatch.meterValue, this.code)) {
//						WB.addLog2("Account.getMatch, reverse match, find meterValue=" + currAccMatch.meterValue
//								+ ", this.code=" + this.code, WB.strEmpty, "Account");
						this.codeMatch = Etc.delStr(currAccMatch.code, "Matching.");
//						WB.addLog2(
//								"Account.getMatch, reverse code match=" + this.codeMatch + ", this.code=" + this.code,
//								WB.strEmpty, "Account");
					}
				}
			}

			// cross reverse match (301 -> Customer -> 1210) ???

		} catch (Exception ex) {
			WB.addLog("Account.getMatch, ex=" + ex.getMessage(), WB.strEmpty, "Account");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Account.getMatch=" + this.codeMatch + ", this.code=" +
		// this.code,WB.strEmpty, "Account");
	}

	public void isExist() throws Exception {
		// origin - 08.12.2024, last edit - 31.12.2024
		super.isExist();
		try {
			for (var currAcc : WB.abcLast.account) {
				if (Etc.strEquals(currAcc.id, this.id)) {
					this.slice = DefVal.setCustom(this.slice, currAcc.slice);
					// this.date1 = DefVal.setCustom(DateTool.getNow().toString(), currAcc.date1);//
					// this.date1,
					this.date1 = DefVal.setCustom(this.date1, currAcc.date1);
					this.date2 = DefVal.setCustom(this.date2, currAcc.date2);
					this.code = DefVal.setCustom(this.code, currAcc.code);
					this.code = DefVal.setCustom(this.code, currAcc.id);
					this.parent = DefVal.setCustom(this.parent, currAcc.parent);
					this.description = DefVal.setCustom(this.description, currAcc.description);
					this.role = DefVal.setCustom(this.role, currAcc.role);
					this.sign = DefVal.setCustom(this.sign, currAcc.sign);
					this.more = DefVal.setCustom(this.more, currAcc.more);

					this.accountTable = MoreVal.getFieldByKey(this.more, "AccountTable");

					this.isExist = true;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Account.isExist, ex=" + ex.getMessage(), WB.strEmpty, "Account");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Account.isExist=" + this.isExist, WB.strEmpty,"Account");
	}

	public void isValid() throws Exception {
		// origin - 08.12.2024, last edit - 12.12.2024
		super.isValid();
		try {
			if (this.date1.isEmpty() | this.role.isEmpty() | this.sign.isEmpty()) {
				this.isValid = false;
			}
		} catch (Exception ex) {
			WB.addLog("Account.isValid, ex=" + ex.getMessage(), WB.strEmpty, "Account");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Account.isValid=" + this.isValid, WB.strEmpty,"Account");
	}

	public void getIdCode() throws Exception {
		// origin - 30.06.2024, last edit - 17.12.2024
		String res = Etc.fixTrim(this.code);
		try {
			res = res.replace("Account.", WB.strEmpty);
			res = res.replace("Account", WB.strEmpty);
			this.identificationCode = res;
		} catch (Exception ex) {
			WB.addLog("Account.getIdCode, ex=" + ex.getMessage(), WB.strEmpty, "Account");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Account.getIdCode, res=" + res + ", this.code=" +
		// this.code,WB.strEmpty, "Account");
	}

	public Account(ModelDto dto) throws Exception {
		// origin - 09.12.2024, last edit - 23.01.2025
		this.clear();
		this.src = dto.toString();
		this.id = dto.id;
		this.date1 = dto.date1;
		this.code = dto.code;
		// this.getMatch();
		this.isExist();
		this.getMatch();
		this.getRole();
		this.getIdCode();
		this.isValid();
		this.fix();
	}

	public Account(String Id) throws Exception {
		// origin - 05.12.2023, last edit - 23.01.2025
		this.clear();
		this.src = this.id = Id;
		// this.getMatch();
		this.isExist();
		this.getMatch();
		this.getRole();
		this.getIdCode();
		this.isValid();
		this.fix();
	}

	public Account() throws Exception {
		// origin - 04.12.2023, last edit - 28.12.2024
		this.clear();
		var root = Abc.getRoot(this.table);
		this.id = root.id;
		this.parent = root.parent;
		this.slice = root.slice;
		this.date1 = root.date1;
		this.date2 = root.date2;
		this.code = root.code;
		this.description = root.description;
		this.role = root.role;
		this.sign = root.sign;
		this.more = root.more;
		this.fix();
	}

	public void clear() throws Exception {
		// origin - 09.12.2024, last edit - 17.12.2024
		try {
			super.clear();
			this.table = this.getClass().getName();
			this.codeMatch = this.accountTable = this.identificationCode = WB.strEmpty;
		} catch (Exception ex) {
			WB.addLog("Account.clear, ex=" + ex.getMessage(), WB.strEmpty, "Account");
		} finally {
			Etc.doNothing();
		}
	}

	public String toString() {
		// origin - 27.09.2024, last edit - 23.01.2025
		String res = WB.strEmpty;
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", ", this.slice);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.sign);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);

			res = res + Fmtr.addAnyway(", codeMatch ", this.codeMatch);
			res = res + Fmtr.addAnyway(", accountTable ", this.accountTable);
			res = res + Fmtr.addAnyway(", identificationCode ", this.identificationCode);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 23.01.2025
		try {

//			// build
//			for (var tmp : ModelDto.build(" id @ Account.Customer | date1 @ 2024-12-09 } "
//					+ " id @ Account.Customer | date1 @ 2004-01-03 } " + " id @ Account.1210 | date1 @ 2024-12-26 } "
//					+ " id @ Account.301 | date1 @ 2004-01-07 } ")) {
//				WB.addLog2("Account.test.build(String)=" + new Account(tmp), WB.strEmpty, "Account");
//			}

//			// ctor ()
//			WB.addLog2("Account.test.ctor()=" + new Account(), WB.strEmpty, "Account");

//			// ctor (String Id)
//			for (var tmp : new String[] { "Account.Customer", "Account.1210", "Account.301", "Account.tralala" }) {
//				WB.addLog2("Account.test.ctor(String)=" + new Account(tmp), WB.strEmpty, "Account");
//			}

		} catch (Exception ex) {
			WB.addLog("Account.test, ex=" + ex.getMessage(), WB.strEmpty, "Account");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Account.test end ", WB.strEmpty, "Account");
	}
}