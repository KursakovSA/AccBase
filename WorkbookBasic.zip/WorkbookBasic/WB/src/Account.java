public class Account extends ModelDto {
	// origin - 27.09.2023, last edit - 04.08.2024
	public String accountTable;// TOTHINK

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Account.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Account");
		} finally {
			Etc.doNothing();
		}
	}

	public static String getCode(String initCode) throws Exception {
		// origin - 30.06.2024, last edit - 30.06.2024
		String res = Etc.fixTrim(initCode);
		try {
			res = res.replace("Account.", WB.strEmpty);
			res = res.replace("Account", WB.strEmpty);
		} catch (Exception ex) {
			WB.addLog("Account.getCode, ex=" + ex.getMessage(), WB.strEmpty, "Account");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Account.getCode, res=" + res + ", initCode=" + initCode,
		// WB.strEmpty, "Asset");
		return res;
	}

	public Account(String Id, String Code, String Description) throws Exception {
		// origin - 05.12.2023, last edit - 11.08.2024
		super(Id, Code, Description);
		this.table = this.getClass().getName();
	}

	public Account() throws Exception {
		// origin - 04.12.2023, last edit - 11.08.2024
		super();
		this.table = this.getClass().getName();
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 16.09.2024
		try {

//		// getCode
//		var arg12 = new String[] { "1110", "Account.1210", "Account3350" };
//		for (var testArg1 : arg12) {
//			WB.addLog2("Account.test.getCode, res=" + getCode(testArg1) + ", testArg1=" + testArg1, WB.strEmpty,
//					"Account");
//		}

		} catch (Exception ex) {
			WB.addLog("Account.test, ex=" + ex.getMessage(), WB.strEmpty, "Account");
		} finally {
			Etc.doNothing();
		}
		//WB.addLog2("Account.test end ", WB.strEmpty, "Account");
	}
}