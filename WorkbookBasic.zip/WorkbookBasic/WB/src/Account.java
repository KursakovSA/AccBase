public class Account extends Model {
	// origin - 27.09.2023, last edit - 06.12.2023
	public static Account root;
	public Account parent;
	public Slice slice;
	public Role role;
	public Sign sign;
	// public static Workbook acctTableClosing;
	public Account accountTable;
	
	static {
		root = new Account("Account","Account","AccountData");
	}
	
	public Account(String Id, String Code, String Description) {
		// origin - 05.12.2023, last edit - 05.12.2023
		this.id = Id;
		this.code = Code;
		this.description = Description;
	}
	
	public Account() {
		// origin - 04.12.2023, last edit - 05.12.2023
	}
	
	public static void test() {
		// origin - 28.10.2023, last edit - 04.12.2023
    	Logger.add("Account.test, Account.root=" + Account.root, "", "Account");
	}
}