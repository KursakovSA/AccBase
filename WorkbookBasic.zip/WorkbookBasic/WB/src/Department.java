import java.util.ArrayList;
import java.util.List;

public class Department {
	// origin - 13.03.2025, last edit - 14.03.2025
	public boolean isValid, isExist;
	public String table, src, id, parent, code, description, geo, role, info, mark, more;
	public ListVal date1, date2;
	public List<FaceDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Department.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Department");
		}
	}

	// full list department on date1
	public static List<FaceDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 13.03.2025, last edit - 14.03.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceByParent = DAL.getByTemplate(WB.lastConnWork, Qry.getParentFilter(parentId), "Face");
			for (var currFace : faceByParent) {
				if (Etc.strEquals(currFace.role, Role.storeDepartment)) {
					var currFaceDepartment = new Department(currFace.parent, currFace.code);
					var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceDepartment.val, WB.strEmpty);
					if (curr.id.isEmpty() == false) {
						var tmp = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
								curr.geo, curr.role, curr.info, curr.more, curr.mark);
						res.add(tmp);
						// WB.addLog2("Department.getCurr, add tmp=" + tmp, WB.strEmpty,"Department");
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Department.getCurr(List<FaceDto>), ex=" + ex.getMessage(), WB.strEmpty, "Department");
		}
		return res;
	}

	// item department on date1
	public static FaceDto getCurr(String date1, String faceParentId, String faceDepartmentId) throws Exception {
		// origin - 13.03.2025, last edit - 14.03.2025
		FaceDto res = new FaceDto();
		try {
			var currFaceDepartment = new Department(faceParentId, faceDepartmentId);
			if (currFaceDepartment.val.size() != 0) {
				var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceDepartment.val, WB.strEmpty);
				if (curr.id.isEmpty() == false) {
					res = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
							curr.geo, curr.role, curr.info, curr.more, curr.mark);
				}
			}
		} catch (Exception ex) {
			WB.addLog("Department.getCurr(FaceDto), ex=" + ex.getMessage(), WB.strEmpty, "Department");
		}
		return res;
	}

	private void getVal() throws Exception {
		// origin - 13.03.2025, last edit - 14.03.2025
		try {
			String currDate1 = WB.strEmpty;
			String currDate2 = WB.strEmpty;
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description, this.geo,
						this.role, this.info, this.more, this.mark);
				this.val.add(tmp);
//						WB.addLog2("Department.getVal, add tmp=" + tmp, WB.strEmpty,"Department");
			}
		} catch (Exception ex) {
			WB.addLog("Department.getVal, ex=" + ex.getMessage(), WB.strEmpty, "Department");
		}
	}

	public void isExist() throws Exception {
		// origin - 13.03.2025, last edit - 14.03.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getParentFilter(this.parent), this.table);
			if (listDto.size() != WB.intZero) {
				for (var currDto : listDto) {
					if ((Etc.strEquals(currDto.role, Role.storeDepartment))) {
						if ((Etc.strEquals(currDto.code, this.code))) {
							this.date1 = new ListVal(currDto.date1, WB.strEmpty);
							this.date2 = new ListVal(currDto.date2, WB.strEmpty);

							this.id = DefVal.setCustom(this.id, currDto.id);
							this.parent = DefVal.setCustom(this.parent, currDto.parent);
							this.code = DefVal.setCustom(this.code, currDto.code);
							this.description = DefVal.setCustom(this.description, currDto.description);
							this.geo = DefVal.setCustom(this.geo, currDto.geo);
							this.role = DefVal.setCustom(this.role, currDto.role);
							this.info = DefVal.setCustom(this.info, currDto.info);
							this.more = DefVal.setCustom(this.more, currDto.more);
							this.mark = DefVal.setCustom(this.mark, currDto.mark);

							this.isExist = true;
							break;
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Department.isExist, ex=" + ex.getMessage(), WB.strEmpty, "Department");
		}
	}

	public Department(String ParentId, String DepartmentId) throws Exception {
		// origin - 13.03.2025, last edit - 14.03.2025
		this();
		this.table = "Face"; // ??magic string??
		this.src = ParentId + WB.strComma + DepartmentId;
		this.parent = ParentId;
		this.code = DepartmentId;
		this.isExist();
		this.getVal();
	}

	public void clear() throws Exception {
		// origin - 13.03.2025, last edit - 14.03.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.more = this.mark = WB.strEmpty;
			this.date1 = this.date2 = new ListVal();
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("Department.clear, ex=" + ex.getMessage(), WB.strEmpty, "Department");
		}
	}

	public Department() throws Exception {
		// origin - 13.03.2025, last edit - 13.03.2025
		this.clear();
	}

	public String toString() {
		// origin - 13.03.2025, last edit - 13.03.2025
		String res = WB.strEmpty;
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);

			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);

			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 13.03.2025, last edit - 14.03.2025
		try {

			// getCurr(List<FaceDto>)
			for (var tmp1 : new String[] { "2023-04-05", "2025-01-31", "2025-08-15" }) {
				for (var tmp2 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
					WB.addLog2("Department.test.getCurr(List<FaceDto>), res.size="
							+ Department.getCurr(tmp1, tmp2).size() + ", date1=" + tmp1 + ", parentId=" + tmp2,
							WB.strEmpty, "Department");
				}
			}

			// getCurr(FaceDto)
			for (var tmp1 : new String[] { "2023-04-05", "2025-01-31", "2025-08-15" }) {
				for (var tmp2 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
					for (var tmp3 : new String[] { "Face.FA1.AdmStaff", "Face.Tralala.AdmStaff" }) {
						WB.addLog2(
								"Department.test.getCurr, res=" + Department.getCurr(tmp1, tmp2, tmp3) + ", date1="
										+ tmp1 + ", faceParentId=" + tmp2 + ", faceDepartmentId=" + tmp3,
								WB.strEmpty, "Department");
					}
				}
			}

//			// ctor()
//			WB.addLog2("Department.test.ctor()=" + new Department(), WB.strEmpty, "Department");

//			// ctor (String, String)
//			for (var tmp1 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
//				for (var tmp2 : new String[] { "Face.FA1.AdmStaff", "Face.Tralala.AdmStaff" }) {
//					WB.addLog2("Department.test.ctor(String,String)=" + new Department(tmp1, tmp2), WB.strEmpty,
//							"Department");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("Department.test, ex=" + ex.getMessage(), WB.strEmpty, "Department");
		}
	}
}