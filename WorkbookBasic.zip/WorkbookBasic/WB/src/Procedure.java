import javax.swing.JOptionPane;

public class Procedure {
	// origin - 13.12.2023, last edit - 19.12.2023
	
	public static void pause(int milliSec) throws Exception {
		// origin - 19.12.2023, last edit - 19.12.2023
		Thread.sleep(milliSec); 
	}
	
	public static void shortTest(String conn) throws Exception {
		// origin - 19.12.2023, last edit - 19.12.2023
		Logger.getLocalStart();
		DAL.getShortTest(conn);
		Logger.getLocalEnd("Procedure.shortTest()" + ", " + conn);
	}
	
	public static void vacuum(String conn) throws Exception {
		// origin - 19.12.2023, last edit - 19.12.2023
		Logger.getLocalStart();
		DAL.getVacuum(conn);
		Logger.getLocalEnd("Procedure.vacuum()" + ", " + conn);
	}
	
	public static void reindex(String conn) throws Exception {
		// origin - 19.12.2023, last edit - 19.12.2023
		Logger.getLocalStart();
		DAL.getReindex(conn);
		Logger.getLocalEnd("Procedure.reindex()" + ", " + conn);
	}

	public static void integrityCheck(String conn) throws Exception {
		// origin - 19.12.2023, last edit - 19.12.2023
		Logger.getLocalStart();
		DAL.getIntegrityCheck(conn);
		Logger.getLocalEnd("Procedure.integrityCheck()" + ", " + conn);
	}
	
	public static void backupConn(String conn) throws Exception {
		// origin - 18.12.2023, last edit - 18.12.2023
		Logger.getLocalStart();
		DAL.getBackup(conn);
		Logger.getLocalEnd("Procedure.backupConn()" + ", " + conn);
	}

	public static void exit() throws Exception {
		// origin - 11.12.2023, last edit - 18.12.2023
		int selection = JOptionPane.showConfirmDialog(WB.frameBasic, "Do you want to leave the program ?",
				"Exit question", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		if (selection == JOptionPane.OK_OPTION) {
			Logger.add2("Procedure.exit", "", "Proc");
			Logger.getFinish();
			System.exit(0);
		}
	}
}
