import java.util.ArrayList;
import java.util.List;

public class SpanTime {
	// origin - 09.04.2025, last edit - 10.05.2025
	private String src;
	public List<String> srcList;
	public List<String> val1, val2, val;
	public List<String> time1, time2;
	private static List<String> listDelStr;

	static {
		try {
			SpanTime.listDelStr = List.of(" - ", "- ", " -", "-");
		} catch (Exception ex) {
			WB.addLog("SpanTime.static ctor, ex=" + ex.getMessage(), "", "SpanTime");
		}
	}

	private void getVal12() throws Exception {
		// origin - 11.04.2025, last edit - 14.06.2025
		try {
			String tmp = "";
			String tmp1 = "";
			String tmp2 = "";
			String separator = "-";
			for (int i = 0; i < srcList.size(); i++) {
				tmp = this.srcList.get(i).toString();
				if (Etc.strMatch(tmp, separator) == 1) {
					tmp1 = "";
					tmp2 = "";
					int posLocalSplit = tmp.indexOf(separator);
					if (posLocalSplit > 0) {
						tmp1 = Etc.fixTrim(tmp.substring(0, posLocalSplit));
						tmp1 = Etc.delStr(tmp1, SpanTime.listDelStr);
						this.val1.add(tmp1);

						tmp2 = Etc.fixTrim(tmp.substring(posLocalSplit));
						tmp2 = Etc.delStr(tmp2, SpanTime.listDelStr);
						this.val2.add(tmp2);

						// if (Etc.strMatch(tmp, separator) == 1) {
						// int posLocalSplit = tmp.indexOf(separator);
						// if (posLocalSplit > 0) {
						// this.val1.add(Etc.fixTrim(tmp.substring(0, posLocalSplit)));
						// this.src1 = Etc.delStr(this.src1, TimeVal.listDelStr);

						// this.src2 = Etc.fixTrim(tmp.substring(posLocalSplit));
						// this.src2 = Etc.delStr(this.src2, TimeVal.listDelStr);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("SpanTime.getVal12():void, ex=" + ex.getMessage(), "", "SpanTime");
		}
	}

	private void getVal() throws Exception {
		// origin - 10.04.2025, last edit - 14.06.2025
		try {
			for (int i = 0; i < this.time1.size(); i++) {
				var tmp = this.time1.get(i).toString() + " - " + this.time2.get(i).toString();
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("SpanTime.getVal():void, ex=" + ex.getMessage(), "", "SpanTime");
		}
	}

	private void correctData(int sizeVal1, int sizeVal2) throws Exception {
		// origin - 10.04.2025, last edit - 14.06.2025
		try {
			if ((sizeVal1 == 0) && (sizeVal2 == 0)) {// both time1 and time2 empty
				return;
			}

			if ((sizeVal1 == 0) && (sizeVal2 == 1)) {// time1 empty, time2.size=1
				this.time1.add("09:00");
				return;
			}

			if ((sizeVal1 == 0) && (sizeVal2 > 1)) {// time1 empty, time2.size>1
				for (int i = 1; i <= sizeVal2; i++) {// aline time1,2
					this.time1.add("09:00");
				}
				return;
			}

			if ((sizeVal1 == 1) && (sizeVal2 == 0)) {// time1.size=1, time2 empty
				this.time2.add("18:00");
				return;
			}

			if ((sizeVal1 > 1) && (sizeVal2 == 0)) {// time1.size>1, time2 empty
				for (int i = 1; i <= sizeVal1; i++) {// aline date1,2
					this.time2.add("18:00");
				}
				return;
			}

			if ((sizeVal1 >= 1) && (sizeVal2 >= 1) && (sizeVal1 != sizeVal2)) {// time1 and time2 sizes not equals
				if (sizeVal1 > sizeVal2) {
					for (int i = this.time2.size() + 1; i <= this.time1.size(); i++) {// aline time1,2
						this.time2.add("18:00");
					}
				}
				if (sizeVal1 < sizeVal2) {
					for (int i = this.time1.size() + 1; i <= this.time2.size(); i++) {// aline time1,2
						this.time1.add("09:00");
					}
				}
				return;
			}
		} catch (Exception ex) {
			WB.addLog("SpanTime.correctData(int sizeVal1, int sizeVal2):void, ex=" + ex.getMessage(), "", "SpanTime");
		}
	}

	private void getTime() throws Exception {
		// origin - 09.04.2025, last edit - 14.06.2025
		try {
			for (int i = 0; i < this.val1.size(); i++) {// for val1 -> time1
				this.correctTime(this.val1, this.time1, i);
			}

			for (int i = 0; i < this.val2.size(); i++) {// for val2 -> time2
				this.correctTime(val2, this.time2, i);
			}
		} catch (Exception ex) {
			WB.addLog("SpanTime.getTime():void, ex=" + ex.getMessage(), "", "SpanTime");
		}
	}

	private void correctTime(List<String> thisVal, List<String> thisTime, int thisValIndex) throws Exception {
		// origin - 09.04.2025, last edit - 14.06.2025
		try {
			if (thisVal.size() > 0) {
				var tmp1 = thisVal.get(thisValIndex);
				var tmp2 = DateTool.getLocalTime(tmp1);
				if (Etc.strEquals(tmp2.toString(), "") == false) {
					thisTime.add(tmp2.toString());
				}
			}
		} catch (Exception ex) {
			WB.addLog("SpanTime.correctTime(List<String> thisVal, List<String> thisTime, int thisValIndex):void, ex="
					+ ex.getMessage(), "", "SpanTime");
		}
	}

	private void clear() throws Exception {
		// origin - 09.04.2025, last edit - 14.06.2025
		try {
			this.src = "";
			this.srcList = new ArrayList<String>();
			this.val1 = new ArrayList<String>();
			this.val2 = new ArrayList<String>();
			this.time1 = new ArrayList<String>();
			this.time2 = new ArrayList<String>();
			this.val = new ArrayList<String>();
		} catch (Exception ex) {
			WB.addLog("SpanTime.clear():void, ex=" + ex.getMessage(), "", "SpanTime");
		}
	}

	public SpanTime(String Src) throws Exception { // if ex. src = "08:00-17:00", "9-18,18-02"
		// origin - 11.04.2025, last edit - 09.05.2025
		this();
		this.src = Src;
		this.srcList = Fmtr.listVal(this.src, ",");
		this.getVal12();
		this.getTime();
		this.correctData(this.time1.size(), this.time2.size());
		this.getVal();
	}

	public SpanTime() throws Exception {
		// origin - 09.04.2025, last edit - 09.05.2025
		this.clear();
	}

	public String toString() {
		// origin - 09.04.2025, last edit - 16.04.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", srcList ", this.srcList);

			res = res + Fmtr.addIfNotEmpty(", time1 ", this.time1);
			res = res + Fmtr.addIfNotEmpty(", time2 ", this.time2);
			res = res + Fmtr.addIfNotEmpty(", val ", this.val);
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 09.04.2025, last edit - 14.06.2025
		try {

//			// ctor (String)
//			WB.addLog2("SpanTime.test.ctor(String)", "", "SpanTime");
//			for (var tmp1 : new String[] { "", "08-17", "8-17", "08:00-17:00", "08:00- 17:00", "08:00 -17:00",
//					"09:00 - 18:00", "2025-04-18", "13:00,17:00", "13,17", "9-18,18-02", "9-18" }) {
//				WB.addLog2("SpanTime.test.ctor(String)=" + new SpanTime(tmp1), "", "SpanTime");
//			}

		} catch (Exception ex) {
			WB.addLog("SpanTime.test():void, ex=" + ex.getMessage(), "", "SpanTime");
		}
	}
}