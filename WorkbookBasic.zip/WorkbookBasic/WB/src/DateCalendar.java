import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.YearMonth;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;

public class DateCalendar {
	// origin - 17.01.2024, last edit - 25.01.2024

	public static List<ModelDto> getScheduleNotWorkDay(LocalDate calcDate, Face currFA) throws Exception {// TODO
		// origin - 22.01.2024, last edit - 24.01.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		LocalDate currDate1;
		LocalDate currDate2;
		ModelDto tmp = new ModelDto();
		for (var currSegment : Abc.segmentNotWorkDay) {
			tmp.clear();
			currDate1 = DateCalendar.getLocalDate(currSegment.date1);// left border in data
			currDate2 = DateCalendar.getLocalDate(currSegment.date2);// right border in data
			if (currDate1.isAfter(calcDate)) {
				continue;
			}
			if (currDate1.isBefore(calcDate)) {// because for curr year may be not be actual data
				// tmp = Workbook.getMeterValueString(currSegment.meterValue);
				tmp = currSegment;
			}

			if (currDate1 == calcDate) {// left border hit
				// tmp = Workbook.getMeterValueString(currSegment.meterValue);
				tmp = currSegment;
				break;
			}
			if (currDate2 == calcDate) {// right border hit
				// tmp = Workbook.getMeterValueString(currSegment.meterValue);
				tmp = currSegment;
				break;
			}

			if (currDate1.isBefore(calcDate)) {// range from left border to right border hit
				if (currDate2.isAfter(calcDate)) {
					// tmp = Workbook.getMeterValueString(currSegment.meterValue);
					tmp = currSegment;
					break;
				}
			}
			if (tmp.meterValue.toString().contains("PublicHoliday")) {
				res.add(tmp);
			}
			if (tmp.meterValue.toString().contains("ExtraDayOff")) {
				res.add(tmp);
			}

		}
		WB.addLog2("DateCalendar.getScheduleDayOff, res.size=" + res.size(), "", "DateCalendar");
		return res;
	}

	public static boolean isNotWorkDay(LocalDate currDate, Face currFA) throws Exception {// TODO
		// origin - 22.01.2024, last edit - 25.01.2024
		boolean res = false;
		for (var currDayOff : Abc.segmentNotWorkDay) {
			//if (currDate.toString().contains(currDayOff.meterValue)) {
			if (currDate.toString().endsWith(currDayOff.meterValue)) {
				res = true;
				WB.addLog2(
						"DateCalendar.isNotWorkDay, res=" + res + ", currDayOff=" + currDayOff + ", currDate1=" + currDate,
						"", "DateCalendar");
				break;
			}
		}
		//WB.addLog2("DateCalendar.isDayOff, res=" + res + ", currDate1=" + currDate, "", "DateCalendar");
		return res;
	}

//	public static ModelDto getSegmentByCode(String code) {
//		// origin - 22.01.2024, last edit - 25.01.2024
//		ModelDto res = new ModelDto();
//		for (var currSegment : Abc.segmentNotWorkDay) {
//			if (currSegment.code == code) {// TODO --- ??? contains code ???
//				res = currSegment;
//				break;
//			}
//		}
//		// WB.addLog2("DateCalendar.getSegmentByCode, res=" + res + ", code=" + code,
//		// "", "DateCalendar");
//		return res;
//	}

//	public static String getSegment(LocalDate calcDate, ModelDto filterDto) {
//		// origin - 22.01.2024, last edit - 25.01.2024
//		String res = "";
//		try {
////			 WB.addLog2("DateCalendar.getSegment, ModelDto.getSubset(WB.abcGlobal.basic, filterDto).size=" + ModelDto.getSubset(WB.abcGlobal.basic, filterDto).size() + ", calcDate=" +
////			 calcDate + ", filterDto=" + filterDto,"","DateCalendar");
//			res = Workbook.getChronoMeterValueString(calcDate, ModelDto.getSubset(WB.abcGlobal.basic, filterDto));
//		} catch (Exception ex) {
//			WB.addLog("DateCalendar.getSegment, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace() + ", res="
//					+ res, "", "DateCalendar");
//		} finally {
//			Etc.doNothing();
//		}
////		 WB.addLog2("DateCalendar.getSegment, res=" + res + ", calcDate=" +
////		 calcDate + ", filterDto=" + filterDto,"","DateCalendar");
//		return res;
//	}

	public static OffsetDateTime getOffsetDateTime(String expectedDate) {// TODO
		// origin - 24.11.2023, last edit - 18.01.2024
		OffsetDateTime res;
		expectedDate = Etc.fixTrim(expectedDate);
		try {
			res = OffsetDateTime.parse(expectedDate);
		} catch (Exception ex) {
			// res = OffsetDateTime.of(expectedDate, null, null);
			res = null;
			// WB.addLog("DateCalendar.getOffsetDateTime, ex=" + ex.getMessage(), ",
			// StackTrace=" +
			// ex.getStackTrace(), "DateCalendar");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static LocalDate getLocalDate(String expectedDate) {// TODO
		// origin - 24.11.2023, last edit - 18.01.2024
		LocalDate res = null;
		expectedDate = Etc.fixTrim(expectedDate);
		try {
			res = LocalDate.parse(expectedDate);
			res = fixLocalDate(res);
		} catch (Exception ex) {
			res = null;
			// WB.addLog("DateCalendar.getOffsetDateTime, ex=" + ex.getMessage(), ",
			// StackTrace=" +
			// ex.getStackTrace(), "DateCalendar");
		} finally {
			if (res == null) {
				res = LocalDate.now();
			}
		}
		return res;
	}

	public static LocalTime getLocalTime(String expectedDate) {// TODO
		// origin - 24.11.2023, last edit - 18.01.2024
		LocalTime res;
		expectedDate = Etc.fixTrim(expectedDate);
		try {
			res = LocalTime.parse(expectedDate);
		} catch (Exception ex) {
			res = null;
			// WB.addLog("DateCalendar.getOffsetDateTime, ex=" + ex.getMessage(), ",
			// StackTrace=" +
			// ex.getStackTrace(), "DateCalendar");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static LocalDate fixLocalDate(LocalDate fixDate) {
		// origin - 02.10.2023, last edit - 20.11.2023
		// LocalDate not must be big maxDateSupported and least minDateSupported
		LocalDate res = fixDate;
		if (fixDate.isBefore(WB.minDateSupported)) {
			res = WB.minDateSupported;
		}
		if (fixDate.isAfter(WB.maxDateSupported)) {
			res = WB.maxDateSupported;
		}
		return res;
	}

	public static LocalDate getStartYear(LocalDate currDate) {
		// origin - 22.01.2024, last edit - 23.01.2024
		LocalDate res = LocalDate.of(currDate.getYear(), 1, 1);
		// WB.addLog2("DateCalendar.getStartYear, res=" + res + ", currDate=" +
		// currDate, "", "DateCalendar");
		return res;
	}

	public static LocalDate getEndYear(LocalDate currDate) {
		// origin - 22.01.2024, last edit - 25.01.2024
		LocalDate res = LocalDate.of(currDate.getYear(), 12, 31);
		// WB.addLog2("DateCalendar.getEndYear, res=" + res + ", currDate=" + currDate,
		// "", "DateCalendar");
		return res;
	}

	public static LocalDate getStartMonth(LocalDate currDate) {
		// origin - 22.01.2024, last edit - 25.01.2024
		LocalDate res = YearMonth.of(currDate.getYear(), currDate.getMonth()).atDay(1);// firstDay;//currDate;
		// WB.addLog2("DateCalendar.getStartMonth, res=" + res + ", currDate=" +
		// currDate, "", "DateCalendar");
		return res;
	}

	public static LocalDate getEndMonth(LocalDate currDate) {
		// origin - 22.01.2024, last edit - 25.01.2024
		LocalDate res = YearMonth.of(currDate.getYear(), currDate.getMonth()).atEndOfMonth();// currDate;
		// WB.addLog2("DateCalendar.getEndMonth, res=" + res + ", currDate=" + currDate,
		// "", "DateCalendar");
		return res;
	}

	public static String getLabelDateTimeForFileName() {
		// origin - 27.12.2023, last edit - 18.01.2024
		String res = Etc.fixTrim(getLocalDateTimeNow().toString());
		res = res.replaceAll("-", "_");
		res = res.replaceAll(":", "_");
		res = res + "_";
		return res;
	}

	public static LocalDateTime getLocalDateTimeNow() {
		// origin - 18.12.2023, last edit - 18.12.2023
		return LocalDateTime.now(ZoneOffset.systemDefault().getRules().getOffset(Instant.now()));
	}

	public static int getDuration(OffsetDateTime date1, OffsetDateTime date2) {
		// origin - 21.10.2023, last edit - 18.01.2024
		return Math.abs((int) Etc.roundCustom(Duration.between(date2, date1).toMillis(), Etc.round0));
	}

	public static OffsetDateTime getOffsetDateTimeNow() {
		// origin - 21.10.2023, last edit - 24.11.2023
		return OffsetDateTime.now(ZoneOffset.systemDefault().getRules().getOffset(Instant.now()));
	}

	public static void test() throws Exception {
		// origin - 17.01.2024, last edit - 25.01.2024
		var testDateTime1 = new String[] { "2023-11-24T06:46:16.907+06:00", "2023-11-08 02:15:09", "06:46:16.907+06:00",
				"2019-01-01", "test1", "12.45", "12:45", "12:45:38", "12:45:57.678", null };

		var testDate1 = new String[] { "2023-01-01T06:46:16.907+06:00", "2023-11-08 02:15:09", "06:46:16.907+06:00",
				"2019-01-01", "test1", "12.45", "12:45", "12:45:38", "12:45:57.678", null };

		var testLocalDate = new LocalDate[] { LocalDate.now().minusMonths(1), LocalDate.now(),
				LocalDate.of(2024, 1, 1) };
		
//		// getStartYear
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("DateCalendar.test.getStartYear, res=" + getStartYear(testArg1) + ", testArg1=" + testArg1, "",
//					"DateCalendar");
//		}
//
//		// getEndYear
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("DateCalendar.test.getEndYear, res=" + getEndYear(testArg1) + ", testArg1=" + testArg1, "",
//					"DateCalendar");
//		}

//		// getStartMonth
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("DateCalendar.test.getStartMonth, res=" + getStartMonth(testArg1) + ", testArg1=" + testArg1, "",
//					"DateCalendar");
//		}
//
//		// getEndMonth
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("DateCalendar.test.getEndMonth, res=" + getEndMonth(testArg1) + ", testArg1=" + testArg1, "",
//					"DateCalendar");
//		}

		// isNotWorkDay
		for (var testArg1 : testLocalDate) {
			WB.addLog2("DateCalendar.test.isNotWorkDay, res=" + isNotWorkDay(testArg1, null) + ", testArg1="
					+ testArg1, "", "DateCalendar");
		}

//		// getSegment
//		for (ModelDto testArg2 : Abc.segmentNotWorkDay) {
//			for (LocalDate testArg1 : new LocalDate[] { LocalDate.now().minusYears(1), LocalDate.now() }) {
//				WB.addLog2("DateCalendar.test.getSegment, res=" + getSegment(testArg1, testArg2) + ", testArg1="
//						+ testArg1 + ", testArg2=" + testArg2, "", "DateCalendar");
//			}
//		}

//		// getOffsetDateTime
//		for (var testArg1 : testDateTime1) {
//			WB.addLog2("DateCalendar.test.getOffsetDateTime, res=" + getOffsetDateTime(testArg1) + ", testArg1="
//					+ testArg1, "", "DateCalendar");
//		}
//
//		// getLocalDate
//		for (var testArg1 : testDateTime1) {
//			WB.addLog2("DateCalendar.test.getLocalDate, res=" + getLocalDate(testArg1) + ", testArg1=" + testArg1, "",
//					"DateCalendar");
//		}
//
//		// getLocalTime
//		for (var testArg1 : testDateTime1) {
//			WB.addLog2("DateCalendar.test.getLocalTime, res=" + getLocalTime(testArg1) + ", testArg1=" + testArg1, "",
//					"DateCalendar");
//		}
//
//		// fixLocalDate
//		for (LocalDate testArg1 : new LocalDate[] { LocalDate.of(2026, 4, 28), LocalDate.of(1967, 11, 25),
//				LocalDate.of(2100, 5, 26) }) {
//			WB.addLog2("DateCalendar.test.fixLocalDate, res=" + fixLocalDate(testArg1) + ", testArg1=" + testArg1, "",
//					"DateCalendar");
//		}
	}
}
