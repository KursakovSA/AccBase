import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;

public class DateCalendar {
	// origin - 17.01.2024, last edit - 22.01.2024
	public static List<ModelDto> segment = new ArrayList<ModelDto>();

	static {
		segment.add(ModelDto.getFilter("PublicHoliday.NewYearDay", "Meter.PublicHoliday"));
		segment.add(ModelDto.getFilter("PublicHoliday.InternationalWomenDay", "Meter.PublicHoliday"));
		segment.add(ModelDto.getFilter("PublicHoliday.NauryzMeiramy", "Meter.PublicHoliday"));
		segment.add(ModelDto.getFilter("PublicHoliday.UnityDay", "Meter.PublicHoliday"));
		segment.add(ModelDto.getFilter("PublicHoliday.DefenderFatherland Day", "Meter.PublicHoliday"));
		segment.add(ModelDto.getFilter("PublicHoliday.VictoryDay", "Meter.PublicHoliday"));
		segment.add(ModelDto.getFilter("PublicHoliday.ConstitutionDay", "Meter.PublicHoliday"));
		segment.add(ModelDto.getFilter("PublicHoliday.IndependenceDay", "Meter.PublicHoliday"));
		segment.add(ModelDto.getFilter("PublicHoliday.FirstPresidentDay", "Meter.PublicHoliday"));
		segment.add(ModelDto.getFilter("PublicHoliday.RepublicDay", "Meter.PublicHoliday"));

		segment.add(ModelDto.getFilter("ExtraDayOff.OrthodoxChristmasDay", "Meter.ExtraDayOff"));
		segment.add(ModelDto.getFilter("ExtraDayOff.KurbanAit", "Meter.ExtraDayOff"));
		// segment.add(ModelDto.getFilter("", "Meter.Rate"));
		// segment.add(ModelDto.getFilter("", "Meter.Rate"));
	}

	public static List<ModelDto> getScheduleDayOff(LocalDate currDate1, LocalDate currDate2, Face currFA) {// TODO
		List<ModelDto> res = new ArrayList<ModelDto>();
		WB.addLog2("DateCalendar.getScheduleDayOff, res.size=" + res.size(), "", "DateCalendar");
		return res;
	}
	
	public static boolean isDayOff(LocalDate currDate1, Face currFA) {// TODO
		boolean res = false;
		WB.addLog2("DateCalendar.isDayOff, res=" + res + ", currDate1" + currDate1, "", "DateCalendar");
		return res;
	}

	public static ModelDto getSegmentByCode(String code) {
		// origin - 22.01.2024, last edit - 22.01.2024
		ModelDto res = new ModelDto();
		for (var currSegment : DateCalendar.segment) {
			if (currSegment.code == code) {// TODO --- ??? contains code ???
				res = currSegment;
				break;
			}
		}
		// WB.addLog2("DateCalendar.getSegmentByCode, res=" + res + ", code=" + code,
		// "", "DateCalendar");
		return res;
	}

	public static String getSegment(LocalDate calcDate, ModelDto filterDto) {
		// origin - 22.01.2024, last edit - 22.01.2024
		String res = "";
		try {
//			 WB.addLog2("DateCalendar.getSegment, ModelDto.getSubset(WB.abcGlobal.basic, filterDto).size=" + ModelDto.getSubset(WB.abcGlobal.basic, filterDto).size() + ", calcDate=" +
//			 calcDate + ", filterDto=" + filterDto,"","DateCalendar");
			res = Workbook.getChronoMeterValueString(calcDate, ModelDto.getSubset(WB.abcGlobal.basic, filterDto));
		} catch (Exception ex) {
			WB.addLog("DateCalendar.getSegment, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace() + ", res="
					+ res, "", "DateCalendar");
		} finally {
			Etc.doNothing();
		}
//		 WB.addLog2("DateCalendar.getSegment, res=" + res + ", calcDate=" +
//		 calcDate + ", filterDto=" + filterDto,"","DateCalendar");
		return res;
	}

	public static OffsetDateTime getOffsetDateTime(String expectedDate) {// TODO
		// origin - 24.11.2023, last edit - 18.01.2024
		OffsetDateTime res;
		expectedDate = Etc.fixTrim(expectedDate);
		try {
			res = OffsetDateTime.parse(expectedDate);
		} catch (Exception ex) {
			// res = OffsetDateTime.of(expectedDate, null, null);
			res = null;
			// WB.addLog("DateCalendar.getOffsetDateTime, ex=" + ex.getMessage(), ",
			// StackTrace=" +
			// ex.getStackTrace(), "DateCalendar");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static LocalDate getLocalDate(String expectedDate) {// TODO
		// origin - 24.11.2023, last edit - 18.01.2024
		LocalDate res = null;
		expectedDate = Etc.fixTrim(expectedDate);
		try {
			res = LocalDate.parse(expectedDate);
			res = fixLocalDate(res);
		} catch (Exception ex) {
			res = null;
			// WB.addLog("DateCalendar.getOffsetDateTime, ex=" + ex.getMessage(), ",
			// StackTrace=" +
			// ex.getStackTrace(), "DateCalendar");
		} finally {
			if (res == null) {
				res = LocalDate.now();
			}
		}
		return res;
	}

	public static LocalTime getLocalTime(String expectedDate) {// TODO
		// origin - 24.11.2023, last edit - 18.01.2024
		LocalTime res;
		expectedDate = Etc.fixTrim(expectedDate);
		try {
			res = LocalTime.parse(expectedDate);
		} catch (Exception ex) {
			res = null;
			// WB.addLog("DateCalendar.getOffsetDateTime, ex=" + ex.getMessage(), ",
			// StackTrace=" +
			// ex.getStackTrace(), "DateCalendar");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static LocalDate fixLocalDate(LocalDate fixDate) {
		// origin - 02.10.2023, last edit - 20.11.2023
		// LocalDate not must be big maxDateSupported and least minDateSupported
		LocalDate res = fixDate;
		if (fixDate.isBefore(WB.minDateSupported)) {
			res = WB.minDateSupported;
		}
		if (fixDate.isAfter(WB.maxDateSupported)) {
			res = WB.maxDateSupported;
		}
		return res;
	}

	public static String getLabelDateTimeForFileName() {
		// origin - 27.12.2023, last edit - 18.01.2024
		String res = Etc.fixTrim(getLocalDateTimeNow().toString());
		res = res.replaceAll("-", "_");
		res = res.replaceAll(":", "_");
		res = res + "_";
		return res;
	}

	public static LocalDateTime getLocalDateTimeNow() {
		// origin - 18.12.2023, last edit - 18.12.2023
		return LocalDateTime.now(ZoneOffset.systemDefault().getRules().getOffset(Instant.now()));
	}

	public static int getDuration(OffsetDateTime date1, OffsetDateTime date2) {
		// origin - 21.10.2023, last edit - 18.01.2024
		return Math.abs((int) Etc.roundCustom(Duration.between(date2, date1).toMillis(), Etc.round0));
	}

	public static OffsetDateTime getOffsetDateTimeNow() {
		// origin - 21.10.2023, last edit - 24.11.2023
		return OffsetDateTime.now(ZoneOffset.systemDefault().getRules().getOffset(Instant.now()));
	}

	public static void test() throws Exception {
		// origin - 17.01.2024, last edit - 22.01.2024
		var testDateTime1 = new String[] { "2023-11-24T06:46:16.907+06:00", "2023-11-08 02:15:09", "06:46:16.907+06:00",
				"2019-01-01", "test1", "12.45", "12:45", "12:45:38", "12:45:57.678", null };

//		// getSegment
//		for (LocalDate testArg1 : new LocalDate[] { LocalDate.now().minusYears(1), LocalDate.now() }) {
//			WB.addLog2("DateCalendar.test.getSegment, res="
//					+ getSegment(testArg1, getSegmentByCode("PublicHoliday.NewYearDay")) + ", testArg1=" + testArg1
//					+ ", testArg2=" + getSegmentByCode("PublicHoliday.NewYearDay"), "", "Debt");
//		}

		// getSegment
		for (ModelDto testArg2 : DateCalendar.segment) {
			for (LocalDate testArg1 : new LocalDate[] { LocalDate.now().minusYears(1), LocalDate.now() }) {
				WB.addLog2("DateCalendar.test.getSegment, res=" + getSegment(testArg1, testArg2) + ", testArg1="
						+ testArg1 + ", testArg2=" + testArg2, "", "Debt");
			}
		}

		// getOffsetDateTime
		for (var testArg1 : testDateTime1) {
			WB.addLog2("DateCalendar.test.getOffsetDateTime, res=" + getOffsetDateTime(testArg1) + ", testArg1="
					+ testArg1, "", "DateCalendar");
		}

		// getLocalDate
		for (var testArg1 : testDateTime1) {
			WB.addLog2("DateCalendar.test.getLocalDate, res=" + getLocalDate(testArg1) + ", testArg1=" + testArg1, "",
					"DateCalendar");
		}

		// getLocalTime
		for (var testArg1 : testDateTime1) {
			WB.addLog2("DateCalendar.test.getLocalTime, res=" + getLocalTime(testArg1) + ", testArg1=" + testArg1, "",
					"DateCalendar");
		}

		// fixLocalDate
		for (LocalDate testArg1 : new LocalDate[] { LocalDate.of(2026, 4, 28), LocalDate.of(1967, 11, 25),
				LocalDate.of(2100, 5, 26) }) {
			WB.addLog2("DateCalendar.test.fixLocalDate, res=" + fixLocalDate(testArg1) + ", testArg1=" + testArg1, "",
					"DateCalendar");
		}
	}
}
