import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unused")
public class ScaleVal extends ModelVal {
	// origin - 04.09.2024, last edit - 17.09.2024
	private static String strSplit = ":"; // ??magic string?? // TOTHINK
	private List<String> target = new ArrayList<String>(); // TOTHINK
	private List<ModelDto> part = new ArrayList<ModelDto>(); // TOTHINK
	private List<ModelDto> partLimit = new ArrayList<ModelDto>(); // TOTHINK

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("ScaleVal.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "ScaleVal");
		} finally {
			Etc.doNothing();
		}
	}

	public boolean isScaleVal() throws Exception { //TOTHINK
		// origin - 17.09.2024, last edit - 17.09.2024
		boolean res = false;
		try {
			if (Etc.strMatch(this.src, ScaleVal.strSplit) >= 1) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("ScaleVal.isScaleVal, ex=" + ex.getMessage(), WB.strEmpty, "ScaleVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ScaleVal.isScaleVal, res=" + res, WB.strEmpty,
		// "ScaleVal");
		return res;
	}

	public ScaleVal() throws Exception {
		// origin - 04.09.2024, last edit - 04.09.2024
		try {
		} catch (Exception ex) {
			WB.addLog("ScaleVal.ctor, ex=" + ex.getMessage(), WB.strEmpty, "ScaleVal");
		} finally {
			Etc.doNothing();
		}
	}

	public static void test() throws Exception {
		// origin - 04.09.2024, last edit - 16.09.2024
		try {

		} catch (Exception ex) {
			WB.addLog("ScaleVal.test, ex=" + ex.getMessage(), WB.strEmpty, "ScaleVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ScaleVal.test end ", WB.strEmpty, "ScaleVal");
	}
}
