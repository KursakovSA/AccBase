import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unused")
public class ScaleVal extends ModelVal { // TOTHINK
	// origin - 04.09.2024, last edit - 13.11.2024
	// ex.
	// {argLeftLimit=(0:45.001)(Unit.MinRate);argRightLimit=(0:45.0)(Unit.MinRate);argRate=(0.293:0.105)(Unit.PercentPerDay);}
	private List<UnitVal> argLeftLimit = new ArrayList<UnitVal>(); // TODO
	private List<UnitVal> argRightLimit = new ArrayList<UnitVal>(); // TODO
	private List<UnitVal> argRate = new ArrayList<UnitVal>(); // TODO

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("ScaleVal.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "ScaleVal");
		} finally {
			Etc.doNothing();
		}
	}

	private void getPart() throws Exception {// TODO
		// origin - 30.09.2024, last edit - 30.09.2024
		try {
//			if (this.isScaleVal()) {
//				int posLocalSplitLeft = this.src.indexOf(UnitVal.strLeftSplit); // pos "("
//				if (posLocalSplitLeft > 0) {
//					// this is res
//					this.partVal = Etc.fixTrim(this.src.substring(0, posLocalSplitLeft)); // ex. "12(Unit.KZT)" --> "12"
//
//					// clean, because may be alone chars "(" and\or ")" //??
//					// this.partVal = Etc.delStr(this.partVal, UnitVal.strLeftSplit);
//					// this.partVal = Etc.delStr(this.partVal, UnitVal.strRightSplit);
//					this.partVal = Etc.delStr(this.partVal, UnitVal.listDelStr);
//
//					this.partUnit = Etc.fixTrim(this.src.substring(posLocalSplitLeft));
//				}
//			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.getPart, ex=" + ex.getMessage(), WB.strEmpty, "UnitVal");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("UnitVal.getPart, this.partVal=" + this.partVal + ", this.partUnit=" + this.partUnit + ", this.src="
//				+ this.src, WB.strEmpty, "UnitVal");
	}

	public ScaleVal(String Src) throws Exception {
		// origin - 30.09.2024, last edit - 01.10.2024
		this();
		this.src = Etc.fixTrim(Src);
		this.getPart();
	}

	public ScaleVal() throws Exception {
		// origin - 04.09.2024, last edit - 27.09.2024
		super();
	}

	public static void test() throws Exception {
		// origin - 04.09.2024, last edit - 16.09.2024
		try {

		} catch (Exception ex) {
			WB.addLog("ScaleVal.test, ex=" + ex.getMessage(), WB.strEmpty, "ScaleVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ScaleVal.test end ", WB.strEmpty, "ScaleVal");
	}
}
