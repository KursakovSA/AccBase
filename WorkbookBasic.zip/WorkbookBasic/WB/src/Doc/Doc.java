import java.util.ArrayList;
import java.util.List;

public final class Doc {
	// origin - 13.04.2026, last edit - 09.11.2026
	public List<DocItem> headerList;
	public List<DocItem> itemList;
	public List<DocItem> footerList;
	public List<DocItem> totalList;
	public String summary;
	public static String strDocName;

	static {
		try {
			Doc.strDocName = "Doc.Name";
		} catch (Exception ex) {
			WB.addLog("Doc.static ctor, ex=" + ex.getMessage(), "", "Doc");
		}
	}

	public static List<Workbook> massPrint(String id) throws Exception { // TODO
		// origin - 07.11.2026, last edit - 07.11.2026
		List<Workbook> res = new ArrayList<Workbook>();
		try {

		} catch (Exception ex) {
			WB.addLog("Doc.massPrint(String):List<Workbook>, ex=" + ex.getMessage(), "", "Doc");
		}
		return res;
	}

	public static List<Workbook> summaryPrint(String id) throws Exception { // TODO
		// origin - 07.11.2026, last edit - 07.11.2026
		List<Workbook> res = new ArrayList<Workbook>();
		try {

		} catch (Exception ex) {
			WB.addLog("Doc.summaryPrint(String):List<Workbook>, ex=" + ex.getMessage(), "", "Doc");
		}
		return res;
	}

	public static List<Workbook> get(String id) throws Exception { // TODO
		// origin - 06.11.2026, last edit - 06.11.2026
		List<Workbook> res = new ArrayList<Workbook>();
		try {

		} catch (Exception ex) {
			WB.addLog("Doc.get(String):List<Workbook>, ex=" + ex.getMessage(), "", "Doc");
		}
		return res;
	}

	public static List<Workbook> put(String id) throws Exception { // TODO
		// origin - 06.11.2026, last edit - 06.11.2026
		List<Workbook> res = new ArrayList<Workbook>();
		try {

		} catch (Exception ex) {
			WB.addLog("Doc.put(String):List<Workbook>, ex=" + ex.getMessage(), "", "Doc");
		}
		return res;
	}

	public static List<Workbook> delete(String id) throws Exception { // TODO
		// origin - 06.11.2026, last edit - 06.11.2026
		List<Workbook> res = new ArrayList<Workbook>();
		try {

		} catch (Exception ex) {
			WB.addLog("Doc.delete(String):List<Workbook>, ex=" + ex.getMessage(), "", "Doc");
		}
		return res;
	}

	public Doc(String Id) throws Exception { // TODO
		// origin - 06.11.2026, last edit - 06.11.2026
		this.clear();
	}

	public Doc() throws Exception {
		// origin - 06.11.2026, last edit - 06.11.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 06.11.2026, last edit - 07.11.2026
		try {
			this.headerList = new ArrayList<DocItem>();
			this.itemList = new ArrayList<DocItem>();
			this.footerList = new ArrayList<DocItem>();
			this.totalList = new ArrayList<DocItem>();
			this.summary = "";
		} catch (Exception ex) {
			WB.addLog("Doc.clear():void, ex=" + ex.getMessage(), "", "Doc");
		}
	}

	public String toString() {
		// origin - 06.11.2026, last edit - 07.11.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("headerList ", this.headerList);
			res = res + Fmtr.addIfNotEmpty(", itemList ", this.itemList);
			res = res + Fmtr.addIfNotEmpty(", footerList ", this.footerList);
			res = res + Fmtr.addIfNotEmpty(", totalList ", this.totalList);
			res = res + Fmtr.addIfNotEmpty(", summary ", this.summary);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 13.04.2026, last edit - 09.11.2026
		try {

//			{
//				WB.addLog2("Doc.test.getNameList by NameVar.getNameList(String):List<String>", "", "Doc");
//				var tmp1 = NameVar.getNameList(Doc.strDocName);
//				WB.addLog2("Doc.test.getNameList by NameVar.getNameList(String):List<String>, res.size=" + tmp1.size() + ", tmp1 " + tmp1, "", "Doc");
//			}

		} catch (Exception ex) {
			WB.addLog("Doc.test():void, ex=" + ex.getMessage(), "", "Doc");
		}
	}
}