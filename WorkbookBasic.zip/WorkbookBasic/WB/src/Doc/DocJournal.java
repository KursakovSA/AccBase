import java.util.ArrayList;
import java.util.List;

public final class DocJournal {
	// origin - 11.11.2025, last edit - 08.11.2026
	public static String strAllDoc;
	public static String strUnitDoc;
	public static String strDocJournalName;

	static {
		try {
			DocJournal.strAllDoc = "AllDoc";
			DocJournal.strUnitDoc = "Unit.Doc";
			DocJournal.strDocJournalName = "DocJournal.Name";
		} catch (Exception ex) {
			WB.addLog("DocJournal.static ctor, ex=" + ex.getMessage(), "", "DocJournal");
		}
	}

	public static List<Workbook> getByDocName(String docName) throws Exception {
		// origin - 08.11.2026, last edit - 08.11.2026
		List<Workbook> res = new ArrayList<Workbook>();
		try {
			if (Etc.strNotValid(docName)) {
				return res;
			}
			if (Etc.strNotContains(docName, DocJournal.getFullDocNameListByContentList())) {
				return res;
			}
			res = Workbook.getByCodeContains(docName);
		} catch (Exception ex) {
			WB.addLog("DocJournal.getByDocName(String):List<Workbook>, ex=" + ex.getMessage(), "", "DocJournal");
		}
		return res;
	}

	public static List<Workbook> get() throws Exception {
		// origin - 08.11.2026, last edit - 08.11.2026
		List<Workbook> res = new ArrayList<Workbook>();
		try {
			res = Workbook.getByUnit(DocJournal.strUnitDoc);
		} catch (Exception ex) {
			WB.addLog("DocJournal.get():List<Workbook>, ex=" + ex.getMessage(), "", "DocJournal");
		}
		return res;
	}

	public static List<String> getContentListByDocJournalName(String name) throws Exception {
		// origin - 07.11.2026, last edit - 08.11.2026
		List<String> res = new ArrayList<String>();
		try {
			if (Etc.strNotValid(name)) {
				return res;
			}
			for (var curr : DocJournal.getContentList()) {
				if (curr.startsWith(name)) {
					var tmp1 = List.of(MoreVal.getValueByPart(curr).split(","));
					if (tmp1.size() != 0) {
						res.addAll(tmp1);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("DocJournal.getContentListByDocJournalName(String):List<String>, ex=" + ex.getMessage(), "",
					"DocJournal");
		}
		return res;
	}

	private static List<String> getFullDocNameListByContentList() throws Exception {
		// origin - 08.11.2026, last edit - 08.11.2026
		List<String> res = new ArrayList<String>();
		try {
			for (var curr : DocJournal.getContentList()) {
				var tmp1 = List.of(MoreVal.getValueByPart(curr).split(","));
				if (tmp1.size() != 0) {
					res.addAll(tmp1);
				}
			}
			res = Etc.removeDuplicate(res);
		} catch (Exception ex) {
			WB.addLog("DocJournal.getFullDocNameListByContentList():List<String>, ex=" + ex.getMessage(), "",
					"DocJournal");
		}
		return res;
	}

	private static List<String> getContentList() throws Exception {
		// origin - 07.11.2026, last edit - 07.11.2026
		List<String> res = new ArrayList<String>();
		try {
			for (var curr : WB.abcGlobal.name) {
				if (curr.id.startsWith("DocJournal.Content")) {
					var tmp1 = List.of(curr.meterValue.split(";"));
					if (tmp1.size() != 0) {
						res.addAll(tmp1);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("DocJournal.getContentList():List<String>, ex=" + ex.getMessage(), "", "DocJournal");
		}
		return res;
	}

	public static List<Workbook> massPrint(String id) throws Exception { // TODO
		// origin - 07.11.2026, last edit - 07.11.2026
		List<Workbook> res = new ArrayList<Workbook>();
		try {

		} catch (Exception ex) {
			WB.addLog("DocJournal.massPrint(String):List<Workbook>, ex=" + ex.getMessage(), "", "DocJournal");
		}
		return res;
	}

	public static List<Workbook> summaryPrint(String id) throws Exception { // TODO
		// origin - 07.11.2026, last edit - 07.11.2026
		List<Workbook> res = new ArrayList<Workbook>();
		try {

		} catch (Exception ex) {
			WB.addLog("DocJournal.summaryPrint(String):List<Workbook>, ex=" + ex.getMessage(), "", "DocJournal");
		}
		return res;
	}

	public static List<Workbook> get(String id) throws Exception { // TODO
		// origin - 07.11.2026, last edit - 07.11.2026
		List<Workbook> res = new ArrayList<Workbook>();
		try {

		} catch (Exception ex) {
			WB.addLog("DocJournal.get(String):List<Workbook>, ex=" + ex.getMessage(), "", "DocJournal");
		}
		return res;
	}

	public static List<Workbook> put(String id) throws Exception { // TODO
		// origin - 07.11.2026, last edit - 07.11.2026
		List<Workbook> res = new ArrayList<Workbook>();
		try {

		} catch (Exception ex) {
			WB.addLog("DocJournal.put(String):List<Workbook>, ex=" + ex.getMessage(), "", "DocJournal");
		}
		return res;
	}

	public static List<Workbook> delete(String id) throws Exception { // TODO
		// origin - 07.11.2026, last edit - 07.11.2026
		List<Workbook> res = new ArrayList<Workbook>();
		try {

		} catch (Exception ex) {
			WB.addLog("DocJournal.delete(String):List<Workbook>, ex=" + ex.getMessage(), "", "DocJournal");
		}
		return res;
	}

	public static List<String> getDocNameList() throws Exception {
		// origin - 08.11.2026, last edit - 08.11.2026
		List<String> res = new ArrayList<String>();
		try {
			for (var curr : WB.abcGlobal.name) {
				if (curr.id.startsWith("DocJournal.Name")) {
					var tmp1 = List.of(curr.meterValue.split(";"));
					if (tmp1.size() != 0) {
						res.addAll(tmp1);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("DocJournal.getDocNameList():List<String>, ex=" + ex.getMessage(), "", "DocJournal");
		}
		return res;
	}

	public DocJournal(String Id) throws Exception { // TODO
		// origin - 07.11.2026, last edit - 07.11.2026
		this.clear();
	}

	public DocJournal() throws Exception {
		// origin - 07.11.2026, last edit - 07.11.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 07.11.2026, last edit - 07.11.2026
		try {
		} catch (Exception ex) {
			WB.addLog("DocJournal.clear():void, ex=" + ex.getMessage(), "", "DocJournal");
		}
	}

	public String toString() {
		// origin - 07.11.2026, last edit - 07.11.2026
		String res = "";
		try {
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 07.11.2026, last edit - 09.11.2026
		try {

//			WB.addLog2("DocJournal.test.getByDocName(String):List<Workbook>", "", "DocJournal");
//			for (var tmp1 : new String[] { null, "", "StaffOrder", "BillOrder", "Tralala" }) {
//				var tmp2 = DocJournal.getByDocName(tmp1);
//				WB.addLog2("DocJournal.test.getByDocName(String):List<Workbook>, res.size=" + tmp2.size() + ", tmp1="
//						+ tmp1, "", "DocJournal");
//				WB.log(tmp2, "DocJournal");
//			}

//			{
//				WB.addLog2("DocJournal.test.get():List<Workbook>", "", "DocJournal");
//				var tmp1 = DocJournal.get();
//				WB.addLog2("DocJournal.test.get():List<Workbook>, res.size=" + tmp1.size(), "", "DocJournal");
//				WB.log(tmp1, "DocJournal");
//			}

//			WB.addLog2("DocJournal.test.getContentListByDocJournalName(String):List<String>", "", "DocJournal");
//			for (var tmp1 : DocJournal.getNameList()) {
//				var tmp2 = DocJournal.getContentListByDocJournalName(tmp1);
//				WB.addLog2("DocJournal.test.getContentListByDocJournalName(String):List<String>, res.size="
//						+ tmp2.size() + ", tmp1=" + tmp1 + ", tmp2=" + tmp2, "", "DocJournal");
//			}

//			{
//				WB.addLog2("DocJournal.test.getFullDocNameListByContentList():List<String>", "", "DocJournal");
//				var tmp1 = DocJournal.getFullDocNameListByContentList();
//				WB.addLog2("DocJournal.test.getFullDocNameListByContentList():List<String>, res.size=" + tmp1.size()
//						+ ", tmp1=" + tmp1, "", "DocJournal");
//			}

//			{
//				WB.addLog2("DocJournal.test.getContentList():List<String>", "", "DocJournal");
//				var tmp1 = DocJournal.getContentList();
//				WB.addLog2("DocJournal.test.getContentList():List<String>, res.size=" + tmp1.size() + ", tmp1=" + tmp1,
//						"", "DocJournal");
//			}

//			{
//				WB.addLog2("DocJournal.test.getNameList by NameVar.getNameList(String):List<String>", "", "DocJournal");
//				var tmp1 = NameVar.getNameList(DocJournal.strDocJournalName);
//				WB.addLog2("DocJournal.test.getNameList by NameVar.getNameList(String):List<String>, res.size="
//						+ tmp1.size() + ", tmp1 " + tmp1, "", "DocJournal");
//			}

		} catch (Exception ex) {
			WB.addLog("DocJournal.test():void, ex=" + ex.getMessage(), "", "DocJournal");
		}
	}
}