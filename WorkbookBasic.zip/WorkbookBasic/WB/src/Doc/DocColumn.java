public final class DocColumn {
	// origin - 09.11.2026, last edit - 09.11.2026
	public static String strDocColumnName;

	static {
		try {
			DocColumn.strDocColumnName = "DocColumn.Name";
		} catch (Exception ex) {
			WB.addLog("DocColumn.static ctor, ex=" + ex.getMessage(), "", "DocColumn");
		}
	}

	private DocColumn() throws Exception {
		// origin - 09.11.2026, last edit - 09.11.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 09.11.2026, last edit - 09.11.2026
		try {
		} catch (Exception ex) {
			WB.addLog("DocColumn.clear():void, ex=" + ex.getMessage(), "", "DocColumn");
		}
	}

	public static void test() throws Exception {
		// origin - 09.11.2026, last edit - 09.11.2026
		try {

//			{
//				WB.addLog2("DocColumn.test.getNameList by NameVar.getNameList():List<String>", "", "DocColumn");
//				var tmp1 = NameVar.getNameList(DocColumn.strDocColumnName);
//				WB.addLog2("DocColumn.test.getNameList by NameVar.getNameList():List<String>, res.size=" + tmp1.size()
//						+ ", tmp1 " + tmp1, "", "DocColumn");
//			}

		} catch (Exception ex) {
			WB.addLog("DocColumn.test():void, ex=" + ex.getMessage(), "", "DocColumn");
		}
	}
}