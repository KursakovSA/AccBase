import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

public class LocInt {
	// origin - 02.07.2024, last edit - 02.09.2024
	private static LinkedHashMap<String, String> langMap = new LinkedHashMap<String, String>();
	public static String emergencyStrLang = "[RU]";

	static {
		try {
			LocInt.langMap.put("[Қаз]", "[Qaz]");// 1-local main, 2-substitution
			LocInt.langMap.put("[Qaz]", "[Қаз]");
			LocInt.langMap.put("[RU]", "[EN]");
			LocInt.langMap.put("[EN]", "[RU]");
		} catch (Exception ex) {
			WB.addLog("LocInt.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "LocInt");
		} finally {
			Etc.doNothing();
		}
	}

	private static boolean isAnyLang(String initStr) throws Exception {// ex. "8-701-111-11-11", "PANASONIC", etc.
		// origin - 24.07.2024, last edit - 15.08.2024
		boolean res = false;
		try {
			if (Etc.strContains(initStr, WB.strSquareBracketLeft) == false) {
				if (Etc.strContains(initStr, WB.strSquareBracketRight) == false) {
					res = true;
				}
			}
		} catch (Exception ex) {
			WB.addLog("LocInt.isAnyLang, ex=" + ex.getMessage(), WB.strEmpty, "LocInt");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("LocInt.isAnyLang, res=" + res + ", initStr=" + initStr,
		// WB.strEmpty, "LocInt");
		return res;
	}

	private static String setLocal(List<String> initListStrLocal, String strLocal) throws Exception {
		// origin - 08.07.2024, last edit - 27.07.2024
		String res = WB.strEmpty;
		try {
			for (var currStr : initListStrLocal) {

				// case AnyLang
				if (res.isEmpty()) {
					if (LocInt.isAnyLang(currStr)) {
						res = Etc.fixTrim(currStr.toString());
						break;
					}
				}

				// usual case
				if (res.isEmpty()) {
					if (Etc.strContains(currStr, strLocal)) {
						res = Etc.fixTrim(currStr.toString());
						break;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("LocInt.setLocal, ex=" + ex.getMessage(), WB.strEmpty, "LocInt");
		} finally {
			Etc.doNothing();
		}

		// WB.addLog2("LocInt.setLocal, res=" + res + ", initListStrLocal=" +
		// initListStrLocal + ", strLocal=" + strLocal, WB.strEmpty, "LocInt");
		return res;
	}

	public static String getLocal(String initStrLocal, String strLocal) throws Exception {
		// origin - 27.07.2024, last edit - 27.07.2024
		String res = WB.strEmpty;
		try {
			res = LocInt.getLocal(LocInt.getListStrLocal(initStrLocal), strLocal);
		} catch (Exception ex) {
			WB.addLog("LocInt.getLocal, ex=" + ex.getMessage(), WB.strEmpty, "LocInt");
		} finally {
			Etc.doNothing();
		}

		// WB.addLog2("LocInt.getLocal, res=" + res, WB.strEmpty, "LocInt");
		return res;
	}

	private static String getLocal(List<String> initListStrLocal, String strLocal) throws Exception {
		// origin - 03.07.2024, last edit - 27.07.2024
		String res = WB.strEmpty;
		try {

			// case usual
			res = LocInt.setLocal(initListStrLocal, strLocal);

			// case subst
			if (res.isEmpty()) {
				res = LocInt.setLocal(initListStrLocal, LocInt.langMap.get(strLocal)); // substLocal);
			}

			// emergency case
			if (res.isEmpty()) {
				res = LocInt.setLocal(initListStrLocal, LocInt.emergencyStrLang);
			}

			res = LocInt.delStrLang(res);

		} catch (Exception ex) {
			WB.addLog("LocInt.getLocal, ex=" + ex.getMessage(), WB.strEmpty, "LocInt");
		} finally {
			Etc.doNothing();
		}

		// WB.addLog2("LocInt.getLocal, res=" + res, WB.strEmpty, "LocInt");
		return res;
	}

	private static List<String> getListStrLocal(String initStr) throws Exception {
		// origin - 02.07.2024, last edit - 15.08.2024
		List<String> res = new ArrayList<String>();
		try {
			initStr = Etc.fixTrim(initStr);
			String[] tmp = initStr.split(WB.strSquareBracketRight);
			String currTmp = WB.strEmpty;
			for (var currArr : tmp) {
				currTmp = WB.strEmpty;
				currTmp = Etc.fixTrim(currArr);
				if (Etc.strContains(currArr, WB.strSquareBracketLeft)) { //// if has "anyword["
					if (Etc.strContains(currArr, WB.strSquareBracketRight) == false) { //// if not has "]" then add "]"
						currTmp = currTmp + WB.strSquareBracketRight;
					}
				}
				res.add(currTmp);
			}

		} catch (Exception ex) {
			WB.addLog("LocInt.getListStrLocal, ex=" + ex.getMessage(), WB.strEmpty, "LocInt");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("LocInt.getListStrLocal, res=" + Etc.logList(res), WB.strEmpty,
//		"LocInt");
		return res;
	}

	private static String delStrLang(String initStr) throws Exception {
		// origin - 30.06.2024, last edit - 15.08.2024
		String res = Etc.fixTrim(initStr);
		try {
			if (Etc.strContains(initStr, WB.strSquareBracketLeft)) {
				int posLocalSplitLeft = initStr.indexOf(WB.strSquareBracketLeft); // pos "["
				if (posLocalSplitLeft > 0) {
					res = initStr.substring(0, posLocalSplitLeft); // ex. "Profit[En]" --> "Profit"
				}
			}
		} catch (Exception ex) {
			WB.addLog("delStrLang.delStrLang, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Etc.delStrLang, res=" + res + ", initStr=" + initStr,
		// WB.strEmpty, "Etc");
		return res;
	}

	public LocInt() {
		// origin - 02.07.2024, last edit - 07.07.2024
		try {
		} catch (Exception ex) {
			WB.addLog("LocInt.ctor, ex=" + ex.getMessage(), WB.strEmpty, "LocInt");
		} finally {
			Etc.doNothing();
		}
	}

	public static void test() throws Exception {
		// origin - 02.07.2024, last edit - 16.09.2024
		try {

//			// getLocal
//			var arg1 = new String[] { "8-701-111-11-11", "Доходы", "Доходы[RU]", "Доходы[Ru]",
//					"Доходы[RU]Tабыстар[Қаз]", "Доходы[RU]Profit[EN]", "Доходы[RU]Profit[En]", "Доходы[RU]Revenu[FR]",
//					"Доходы[RU]Tabystar[Qaz]", "Доходы[RU]Tabystar[QAZ]" };// null };
//			for (var testArg1 : arg1) {
//				for (var testArg2 : LocInt.langMap.entrySet()) {
//					String key = testArg2.getKey();
//					WB.addLog2("LocInt.test.getLocal, res=" + LocInt.getLocal(testArg1, key) + ", testArg1=" + testArg1
//							+ ", testArg2.key=" + key, WB.strEmpty, "LocInt");
//				}
//			}

//			// getFactLocal
//			for (var testArg1 : new String[] { "[Ru]", "[EN]", "[FR]", "Revenu[FR]", "Макс[Ru]", "Max[En]" }) {
//				WB.addLog2("LocInt.test.getFactLocal, res=" + LocInt.getFactLocal(testArg1) + ", testArg1=" + testArg1,
//						WB.strEmpty, "LocInt");
//			}

//			// isAnyLang
//			for (var testArg1 : arg1) {
//				WB.addLog2("LocInt.test.isAnyLang, res=" + LocInt.isAnyLang(testArg1) + ", testArg1=" + testArg1, WB.strEmpty,
//						"LocInt");
//			}

//			// getListStrLocal
//			for (var testArg1 : arg1) {
//				WB.addLog2("LocInt.test.getListStrLocal, res=" + Etc.logList(LocInt.getListStrLocal(testArg1))
//						+ ", testArg1=" + testArg1, WB.strEmpty, "LocInt");
//			}

//		// delStrLang
//		for (var testArg1 : arg1) {
//			WB.addLog2("LocInt.test.delStrLang, res=" + LocInt.delStrLang(testArg1) + ", testArg1=" + testArg1, WB.strEmpty,
//					"LocInt");
//		}
		} catch (Exception ex) {
			WB.addLog("LocInt.test, ex=" + ex.getMessage(), WB.strEmpty, "LocInt");
		} finally {
			Etc.doNothing();
		}
		//WB.addLog2("LocInt.test end ", WB.strEmpty, "LocInt");
	}
}
