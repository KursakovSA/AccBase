import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class LocInt {
	// origin - 02.07.2024, last edit - 08.07.2024
	public static String[] localStr = { "[Қаз]", "[Qaz]", "[RU]", "[EN]" };
	public static HashMap<String, String> localSubstitution = new HashMap<String, String>();
	public static String emergencyStrLocal = "[RU]";
	public static String strLocalSplitRight = "]";
	public static String strLocalSplitLeft = "[";

	static {
		try {
			localSubstitution.put("[Қаз]", "[Qaz]");
			localSubstitution.put("[Qaz]", "[Қаз]");
		} catch (Exception ex) {
			WB.addLog("LocInt.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "LocInt");
		} finally {
			Etc.doNothing();
		}
	}

	private static String setLocal(List<String> initListStrLocal, String strLocal) throws Exception {
		// origin - 08.07.2024, last edit - 08.07.2024
		String res = WB.strEmpty;
		try {
			for (var currStr : initListStrLocal) {
				if (currStr.contains(strLocal)) {
					res = Etc.fixTrim(currStr.toString());
				}
			}
		} catch (Exception ex) {
			WB.addLog("LocInt.setLocal, ex=" + ex.getMessage(), WB.strEmpty, "LocInt");
		} finally {
			Etc.doNothing();
		}

		// WB.addLog2("LocInt.setLocal, res=" + res + ", initListStrLocal=" +
		// initListStrLocal + ", strLocal=" + strLocal, WB.strEmpty, "LocInt");
		return res;
	}

	private static String getLocal(List<String> initListStrLocal, String strLocal) throws Exception {
		// origin - 03.07.2024, last edit - 08.07.2024
		String res = WB.strEmpty;
		try {
			res = setLocal(initListStrLocal, strLocal);

			//// if not has main variant then find substitution
			if (res.isEmpty()) {
				res = getLocalSubstitution(initListStrLocal, strLocal);
			}

			//// if not find substitution then find emergency
			if (res.isEmpty()) {
				res = getLocalEmergency(initListStrLocal);
			}

		} catch (Exception ex) {
			WB.addLog("LocInt.getLocal, ex=" + ex.getMessage(), WB.strEmpty, "LocInt");
		} finally {
			Etc.doNothing();
		}

		// WB.addLog2("LocInt.getLocal, res=" + res, WB.strEmpty, "LocInt");
		return res;
	}

	private static String getLocalSubstitution(List<String> initListStrLocal, String strLocal) throws Exception {
		// origin - 08.07.2024, last edit - 08.07.2024
		String res = WB.strEmpty;
		String strLocalSubstitution = WB.strEmpty;
		try {
			if (localSubstitution.containsKey(strLocal)) {
				strLocalSubstitution = localSubstitution.get(strLocal).toString();
//				WB.addLog2(
//						"LocInt.getLocalSubstitution, strLocalSubstitution=" + strLocalSubstitution
//								+ ", initListStrLocal=" + initListStrLocal + ", strLocal=" + strLocal,
//						WB.strEmpty, "LocInt");
			}

			if (strLocalSubstitution.isEmpty() == false) {
				res = setLocal(initListStrLocal, strLocalSubstitution);
			}
		} catch (Exception ex) {
			WB.addLog("LocInt.getLocalSubstitution, ex=" + ex.getMessage(), WB.strEmpty, "LocInt");
		} finally {
			Etc.doNothing();
		}

//		WB.addLog2("LocInt.getLocalSubstitution, res=" + res + ", initListStrLocal=" + initListStrLocal + ", strLocal="
//				+ strLocal, WB.strEmpty, "LocInt");
		return res;
	}

	private static String getLocalEmergency(List<String> initListStrLocal) throws Exception {
		// origin - 07.07.2024, last edit - 07.07.2024
		String res = WB.strEmpty;
		try {
			if (initListStrLocal.size() == 1) {
				res = initListStrLocal.getFirst();
			}

		} catch (Exception ex) {
			WB.addLog("LocInt.getLocalEmergency, ex=" + ex.getMessage(), WB.strEmpty, "LocInt");
		} finally {
			Etc.doNothing();
		}

		// WB.addLog2("LocInt.getLocalEmergency, res=" + res, WB.strEmpty, "LocInt");
		return res;
	}

	public static String getStrLocalFinally(List<String> initListStrLocal, String strLocal) throws Exception {
		// origin - 07.07.2024, last edit - 07.07.2024
		String res = WB.strEmpty;
		try {
			res = getStrLocal(initListStrLocal, strLocal);
			res = delStrLocal(res);
		} catch (Exception ex) {
			WB.addLog("LocInt.getStrLocalFinally, ex=" + ex.getMessage(), WB.strEmpty, "LocInt");
		} finally {
			Etc.doNothing();
		}

		// WB.addLog2("LocInt.getStrLocalFinally, res=" + res, WB.strEmpty, "LocInt");
		return res;
	}

	private static String getStrLocal(List<String> initListStrLocal) throws Exception {
		// origin - 03.07.2024, last edit - 07.07.2024
		String res = WB.strEmpty;
		try {
			res = getLocal(initListStrLocal, LocInt.emergencyStrLocal);
		} catch (Exception ex) {
			WB.addLog("LocInt.getStrLocal(default), ex=" + ex.getMessage(), WB.strEmpty, "LocInt");
		} finally {
			Etc.doNothing();
		}

		// WB.addLog2("LocInt.getStrLocal(default), res=" + res, WB.strEmpty, "LocInt");
		return res;
	}

	private static String getStrLocal(List<String> initListStrLocal, String strLocal) throws Exception {
		// origin - 02.07.2024, last edit - 03.07.2024
		String res = WB.strEmpty;
		try {
			res = getLocal(initListStrLocal, strLocal);

			if (res.isEmpty()) {
				res = getStrLocal(initListStrLocal);
			}

		} catch (Exception ex) {
			WB.addLog("LocInt.getStrLocal, ex=" + ex.getMessage(), WB.strEmpty, "LocInt");
		} finally {
			Etc.doNothing();
		}

		// WB.addLog2("LocInt.getStrLocal, res=" + res, WB.strEmpty, "LocInt");
		return res;
	}

	public static List<String> getListStrLocal(String initStr) throws Exception {
		// origin - 02.07.2024, last edit - 07.07.2024
		List<String> res = new ArrayList<String>();
		try {
			initStr = Etc.fixTrim(initStr);
			String[] tmp = initStr.split(LocInt.strLocalSplitRight);
			String currTmp = WB.strEmpty;
			for (var currArr : tmp) {
				currTmp = WB.strEmpty;
				currTmp = currArr.toString();
				if (Etc.strContains(currArr, LocInt.strLocalSplitLeft)) { //// if has "word["
					if (Etc.strContains(currArr, LocInt.strLocalSplitRight) == false) { //// if not has "]" then add "]"
						currTmp = currTmp + LocInt.strLocalSplitRight;
					}
				}
				res.add(currTmp);
			}

		} catch (Exception ex) {
			// WB.addLog("LocInt.getListStrLocal, ex=" + ex.getMessage(), WB.strEmpty,
			// "LocInt");
		} finally {
			Etc.doNothing();
		}

		// WB.addLog2("LocInt.getListStrLocal, res=" + Etc.logArray(res), WB.strEmpty,
		// "LocInt");
		return res;
	}

	public static String delStrLocal(String initStr) throws Exception {
		// origin - 30.06.2024, last edit - 02.07.2024
		String res = Etc.fixTrim(initStr);
		try {
			for (var currLocal : LocInt.localStr) {
				res = res.replace(currLocal, WB.strEmpty);
			}
		} catch (Exception ex) {
			WB.addLog("delStrLocal.getId, ex=" + ex.getMessage(), WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Etc.delStrLocal, res=" + res + ", initStr=" + initStr,
		// WB.strEmpty, "Etc");
		return res;
	}

	public LocInt() {
		// origin - 02.07.2024, last edit - 07.07.2024
		try {
		} catch (Exception ex) {
			WB.addLog("LocInt.ctor, ex=" + ex.getMessage(), WB.strEmpty, "LocInt");
		} finally {
			Etc.doNothing();
		}
	}

	public static void test() throws Exception {
		// origin - 02.07.2024, last edit - 08.07.2024
		try {
			// getStrLocal
			var arg1 = new String[] { "Доходы", "Доходы[RU]", "Доходы[RU]Tабыстар[Қаз]", "Доходы[RU]Profit[EN]",
					"Доходы[RU]Revenu[FR]", "Доходы[RU]Tabystar[Qaz]", };// null };
			for (var testArg1 : arg1) {
				for (var testArg2 : LocInt.localStr) {
					WB.addLog2("LocInt.test.getStrLocalFinally, res="
							+ getStrLocalFinally(getListStrLocal(testArg1), testArg2) + ", testArg1=" + testArg1
							+ ", testArg2=" + testArg2, WB.strEmpty, "LocInt");
				}
			}

//			// getListStrLocal
//			for (var testArg1 : arg1) {
//				WB.addLog2("LocInt.test.getListStrLocal, res=" + Etc.logList(getListStrLocal(testArg1)) + ", testArg1="
//						+ testArg1, WB.strEmpty, "LocInt");
//			}

//		// delStrLocal
//		for (var testArg1 : arg1) {
//			WB.addLog2("LocInt.test.delStrLocal, res=" + delStrLocal(testArg1) + ", testArg1=" + testArg1, WB.strEmpty,
//					"LocInt");
//		}
		} catch (Exception ex) {
			WB.addLog("LocInt.test, ex=" + ex.getMessage(), WB.strEmpty, "LocInt");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("LocInt.test end ", WB.strEmpty, "LocInt");
	}
}
