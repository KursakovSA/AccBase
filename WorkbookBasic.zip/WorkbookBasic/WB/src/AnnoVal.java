import java.util.ArrayList;
import java.util.List;

public class AnnoVal extends ModelVal {
	// origin - 07.11.2024, last edit - 07.11.2024

	// AnnoVal, ex. = "12 000.0 (14 000.0)", "56 564.0 (67 000.0;83 000.0)"

	private static final String strSplitAnno = ";";
	public static final String strLeftSplitAnnoPart = "(";
	public static final String strRightSplitAnnoPart = ")";
	private static final List<String> listDelStr = List.of(AnnoVal.strLeftSplitAnnoPart, AnnoVal.strRightSplitAnnoPart);

	public String partVal = new String();
	public String partAnno = new String();

	public String val = WB.strEmpty; // ex. "12 000.0"
	public List<String> anno = new ArrayList<String>(); // ex. "(67 000.0;83 000.0)"

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("AnnoVal.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "AnnoVal");
		} finally {
			Etc.doNothing();
		}
	}

	private void getAnnoVal() throws Exception {
		// origin - 07.11.2024, last edit - 07.11.2024
		try {
			this.val = Etc.fixTrim(this.partVal);
			this.anno = Formatter.listVal(this.partAnno, AnnoVal.strSplitAnno);
		} catch (Exception ex) {
			WB.addLog("AnnoVal.getAnnoVal, ex=" + ex.getMessage(), WB.strEmpty, "AnnoVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("AnnoVal.getAnnoVal, this.unit=" + this.unit, WB.strEmpty,
		// "AnnoVal");
	}

	private void getPart() throws Exception {
		// origin - 07.11.2024, last edit - 07.11.2024
		try {
			if (this.isAnnoVal()) {
				int posLocalSplitVal = this.src.indexOf(AnnoVal.strLeftSplitAnnoPart); // pos char "("
				if (posLocalSplitVal > 0) {
					// this is res
					this.partVal = Etc.fixTrim(this.src.substring(0, posLocalSplitVal));
					this.partAnno = Etc.fixTrim(this.src.substring(posLocalSplitVal));
					this.partAnno = Etc.delStr(this.partAnno, AnnoVal.listDelStr);
					this.id = this.partVal + WB.strSpace + Formatter.listVal(this.partAnno, AnnoVal.strSplitAnno);
				}
			}
		} catch (Exception ex) {
			WB.addLog("AnnoVal.getPart, ex=" + ex.getMessage(), WB.strEmpty, "AnnoVal");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("AnnoVal.getPart, this.partVal=" + this.partVal + ", this.partAnno="
//				+ Formatter.listVal(this.partAnno, AnnoVal.strSplitAnno) + ", this.src="
//				+ Formatter.replaceAll(this.src, WB.strSemiColon, WB.strCommaSpace), WB.strEmpty, "AnnoVal");
	}

	public AnnoVal(String Src) throws Exception {
		// origin - 07.11.2024, last edit - 07.11.2024
		this();
		this.src = Etc.fixTrim(Src);
		this.getPart();
		this.getAnnoVal();
	}

	public AnnoVal() throws Exception {
		// origin - 07.11.2024, last edit - 07.11.2024
		super();
	}

	public static void test() throws Exception {
		// origin - 07.11.2024, last edit - 07.11.2024
		try {

//			// ctor
//			var arg1 = new String[] { "12 000.0 (14 000.0)", "56 564.0 (67 000.0;83 000.0)" };
//			for (var testArg1 : arg1) {
//				AnnoVal annoVal1 = new AnnoVal(testArg1);
//				WB.addLog2(
//						"AnnoVal.test.ctor, annoVal1.id=" + annoVal1.id + ", testArg1="
//								+ Formatter.replaceAll(testArg1, WB.strSemiColon, WB.strCommaSpace),
//						WB.strEmpty, "AnnoVal");
//			}

		} catch (

		Exception ex) {
			WB.addLog("AnnoVal.test, ex=" + ex.getMessage(), WB.strEmpty, "AnnoVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("AnnoVal.test end ", WB.strEmpty, "AnnoVal");
	}
}
