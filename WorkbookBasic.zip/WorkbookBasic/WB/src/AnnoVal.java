import java.util.ArrayList;
import java.util.List;

public class AnnoVal extends ModelVal {
	// origin - 07.11.2024, last edit - 04.03.2025
	// AnnoVal, ex. "Price = 12 000.0 (14 000.0) (Unit.KZT)", "56 564.0 (67 000.0;83
	// 000.0)"

	public String partVal, val, partAnno;
	public List<String> anno; // ex. "(67 000.0;83 000.0)"
	private static List<String> listDelStr;

	static {
		try {
			AnnoVal.listDelStr = List.of(WB.strParenthesisLeft, WB.strParenthesisRight, WB.strEquals);
		} catch (Exception ex) {
			WB.addLog("AnnoVal.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "AnnoVal");
		}
	}

	private void getVal() throws Exception {
		// origin - 07.11.2024, last edit - 04.03.2025
		try {
			this.name = this.partName;
			this.val = Etc.fixTrim(this.partVal);
			this.anno = Fmtr.listVal(this.partAnno, WB.strSemiColon);
			this.getUnit();
			this.id = this.name + WB.strSpace + this.val + WB.strSpace + this.anno + WB.strSpace + this.unit.code
					+ WB.strCommaSpace + this.unit.description;
		} catch (Exception ex) {
			WB.addLog("AnnoVal.getVal, ex=" + ex.getMessage(), WB.strEmpty, "AnnoVal");
		}
	}

	private void getPart() throws Exception {
		// origin - 07.11.2024, last edit - 04.03.2025
		try {
			// WB.addLog2("AnnoVal.getPart, isType(this.src)=" + ModelVal.isType(this.src),
			// WB.strEmpty, "AnnoVal");
			if (ModelVal.isType(this.src) == "AnnoVal") {
				String tmp = Etc.fixTrim(this.src);

				int posLocalSplitValUnit = tmp.indexOf(WB.strParenthesisLeft + "Unit."); // pos "(Unit."
				if (posLocalSplitValUnit > 0) {
					this.partUnit = Etc.fixTrim(tmp.substring(posLocalSplitValUnit));
					tmp = Etc.delStr(tmp, this.partUnit);
					this.partUnit = Etc.delStr(this.partUnit, AnnoVal.listDelStr);
				}

				int posLocalStrMiddleEquation = 0;
				posLocalStrMiddleEquation = tmp.indexOf(WB.strEquals); // pos "="
				if (posLocalStrMiddleEquation > 0) {
					this.partName = Etc.fixTrim(tmp.substring(0, posLocalStrMiddleEquation));
					this.partName = Etc.delStr(this.partName, AnnoVal.listDelStr);
					tmp = tmp.substring(posLocalStrMiddleEquation);
					tmp = Etc.delStr(tmp, WB.strEquals);
				}

				int posLocalSplitVal = tmp.indexOf(WB.strParenthesisLeft); // pos char "("
				if (posLocalSplitVal > 0) {
					this.partVal = Etc.fixTrim(tmp.substring(0, posLocalSplitVal));
					this.partAnno = Etc.fixTrim(tmp.substring(posLocalSplitVal));
					this.partAnno = Etc.delStr(this.partAnno, AnnoVal.listDelStr);
					this.id = this.partVal + WB.strSpace + Fmtr.listVal(this.partAnno, WB.strSemiColon);
				}
			}
		} catch (Exception ex) {
			WB.addLog("AnnoVal.getPart, ex=" + ex.getMessage(), WB.strEmpty, "AnnoVal");
		}
//		WB.addLog2("AnnoVal.getPart, this.partVal=" + this.partVal + ", this.partAnno="
//				+ Formatter.listVal(this.partAnno, AnnoVal.strSplitAnno) + ", this.src="
//				+ Formatter.replaceAll(this.src, WB.strSemiColon, WB.strCommaSpace), WB.strEmpty, "AnnoVal");
	}

	public AnnoVal(String Src) throws Exception {
		// origin - 07.11.2024, last edit - 07.11.2024
		this();
		this.src = Etc.fixTrim(Src);
		this.getPart();
		this.getVal();
	}

	public AnnoVal() throws Exception {
		// origin - 07.11.2024, last edit - 21.11.2024
		super();
		this.partVal = this.val = this.partAnno = WB.strEmpty;
		this.anno = new ArrayList<String>();
	}

	public String toString() {
		// origin - 06.01.2025, last edit - 04.03.2025
		String res = WB.strEmpty;
		try {
			res = this.id + WB.strSpace + ", src " + this.src;
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 07.11.2024, last edit - 04.03.2025
		try {

//			// ctor
//			for (var tmp : new String[] { "Price = 100.0 (400.0;830.0) (Unit.KZT)",
//					"12 000.0 (14 000.0) (Unit.tralala)", "56 564.0 (67 000.0;83 000.0)" }) {
//				WB.addLog2("AnnoVal.test.ctor, tmp=" + new AnnoVal(tmp), WB.strEmpty, "AnnoVal");
//			}

		} catch (

		Exception ex) {
			WB.addLog("AnnoVal.test, ex=" + ex.getMessage(), WB.strEmpty, "AnnoVal");
		}
	}
}