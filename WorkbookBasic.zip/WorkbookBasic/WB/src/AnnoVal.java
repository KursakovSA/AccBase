import java.util.ArrayList;
import java.util.List;

public class AnnoVal extends ModelVal {
	// origin - 07.11.2024, last edit - 23.11.2024
	// AnnoVal, ex. "Price = 12 000.0 (14 000.0) (Unit.KZT)", "56 564.0 (67 000.0;83
	// 000.0)"

	private String partVal, val, partAnno;
	public List<String> anno; // ex. "(67 000.0;83 000.0)"
	private static List<String> listDelStr;

	static {
		try {
			AnnoVal.listDelStr = List.of(WB.strParenthesisLeft, WB.strParenthesisRight, WB.strEquals);
		} catch (Exception ex) {
			WB.addLog("AnnoVal.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "AnnoVal");
		} finally {
			Etc.doNothing();
		}
	}

	private void getVal() throws Exception {
		// origin - 07.11.2024, last edit - 24.11.2024
		try {
			this.name = this.partName;
			this.val = Etc.fixTrim(this.partVal);
			this.anno = Fmtr.listVal(this.partAnno, WB.strSemiColon);
			this.id = this.name + WB.strSpace + this.val + WB.strSpace + this.anno;
			this.getUnit();
//			var dto = ReadSet.getByCode(WB.abcLast.basic, this.partUnit);
//			if (dto.size() != 0) {
//				var dto1 = dto.getFirst();
//				this.unit = new Unit(dto1.id, dto1.code, dto1.description);
//				// WB.addLog2("AnnoVal.getPart, this.unit=" + this.unit, WB.strEmpty,
//				// "AnnoVal");
//				this.id = this.id + WB.strSpace + this.unit;
//			}

		} catch (Exception ex) {
			WB.addLog("AnnoVal.getVal, ex=" + ex.getMessage(), WB.strEmpty, "AnnoVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("AnnoVal.getVal, this.unit=" + this.unit, WB.strEmpty,
		// "AnnoVal");
	}

	private void getPart() throws Exception {
		// origin - 07.11.2024, last edit - 24.11.2024
		try {
			//WB.addLog2("AnnoVal.getPart, isType(this.src)=" + ModelVal.isType(this.src), WB.strEmpty, "AnnoVal");
			if (ModelVal.isType(this.src) == "AnnoVal") {
				String tmp = Etc.fixTrim(this.src);

				int posLocalSplitValUnit = tmp.indexOf(WB.strParenthesisLeft + "Unit."); // pos "("
				if (posLocalSplitValUnit > 0) {
					this.partUnit = Etc.fixTrim(tmp.substring(posLocalSplitValUnit));
					tmp = Etc.delStr(tmp, this.partUnit);
					this.partUnit = Etc.delStr(this.partUnit, AnnoVal.listDelStr);
				}

				int posLocalStrMiddleEquation = 0;
				posLocalStrMiddleEquation = tmp.indexOf(WB.strEquals); // pos "="
				if (posLocalStrMiddleEquation > 0) {
					this.partName = Etc.fixTrim(tmp.substring(0, posLocalStrMiddleEquation));
					this.partName = Etc.delStr(this.partName, AnnoVal.listDelStr);
					tmp = tmp.substring(posLocalStrMiddleEquation);
					tmp = Etc.delStr(tmp, WB.strEquals);
				}

				int posLocalSplitVal = tmp.indexOf(WB.strParenthesisLeft); // pos char "("
				if (posLocalSplitVal > 0) {
					this.partVal = Etc.fixTrim(tmp.substring(0, posLocalSplitVal));
					this.partAnno = Etc.fixTrim(tmp.substring(posLocalSplitVal));
					this.partAnno = Etc.delStr(this.partAnno, AnnoVal.listDelStr);
					this.id = this.partVal + WB.strSpace + Fmtr.listVal(this.partAnno, WB.strSemiColon);
				}
			}
		} catch (Exception ex) {
			WB.addLog("AnnoVal.getPart, ex=" + ex.getMessage(), WB.strEmpty, "AnnoVal");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("AnnoVal.getPart, this.partVal=" + this.partVal + ", this.partAnno="
//				+ Formatter.listVal(this.partAnno, AnnoVal.strSplitAnno) + ", this.src="
//				+ Formatter.replaceAll(this.src, WB.strSemiColon, WB.strCommaSpace), WB.strEmpty, "AnnoVal");
	}

	public AnnoVal(String Src) throws Exception {
		// origin - 07.11.2024, last edit - 07.11.2024
		this();
		this.src = Etc.fixTrim(Src);
		this.getPart();
		this.getVal();
	}

	public AnnoVal() throws Exception {
		// origin - 07.11.2024, last edit - 21.11.2024
		super();
		this.partVal = this.val = this.partAnno = WB.strEmpty;
		this.anno = new ArrayList<String>();
	}

	public static void test() throws Exception {
		// origin - 07.11.2024, last edit - 24.11.2024
		try {

//			// ctor
//			var arg1 = new String[] { "Price = 100.0 (400.0;830.0) (Unit.KZT)", "12 000.0 (14 000.0) (Unit.tralala)",
//					"56 564.0 (67 000.0;83 000.0)" };
//			for (var testArg1 : arg1) {
//				AnnoVal av1 = new AnnoVal(testArg1);
//				WB.addLog2("AnnoVal.test.ctor, av1.id=" + av1.id + ", av1.src=" + av1.src, WB.strEmpty, "AnnoVal");
//			}

		} catch (

		Exception ex) {
			WB.addLog("AnnoVal.test, ex=" + ex.getMessage(), WB.strEmpty, "AnnoVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("AnnoVal.test end ", WB.strEmpty, "AnnoVal");
	}
}
