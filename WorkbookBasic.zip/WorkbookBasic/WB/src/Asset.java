import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Asset extends ModelDto {
	// origin - 28.09.2023, last edit - 20.11.2024
	public String assetId, vendorCode, PLUCode, SKUCode, serialNumber, inventoryNumber, passport, VINcode, IMEIcode,
			color, producer, groupFixedAssetId;
	public LocalDate dateMFG, dateEXP;
	public List<String> productCondition;
	public UnitVal liquidationValue, estimatedValue, depreciationRate, usefulLife, standardUsefulLife;
	public RangeVal isNew;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Asset.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Asset");
		} finally {
			Etc.doNothing();
		}
	}

	public Asset(String Id, String Code, String Description) throws Exception {
		// origin - 05.12.2023, last edit - 20.11.2024
		this();
	}

	public Asset() throws Exception {
		// origin - 05.12.2023, last edit - 20.11.2024
		super();
		this.table = this.getClass().getName();
		this.id = new IdGen("AssetId", "idCommonCompositeRandom", this).id;
		assetId = vendorCode = PLUCode = SKUCode = VINcode = IMEIcode = color = producer = groupFixedAssetId = serialNumber = inventoryNumber = passport = WB.strEmpty;
		liquidationValue = estimatedValue = new UnitVal("Unit.KZT");
		productCondition = new ArrayList<String>();
		depreciationRate = new UnitVal("0.0(Unit.Percent)");
		usefulLife = standardUsefulLife = new UnitVal("0.0(Unit.Year)");
		isNew = new RangeVal(); // "2024-08-01 - 2024-11-04, 2024-08-01 - ?, "
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 20.11.2024
		try {

			// ctor1()
			Asset a1 = new Asset();
			WB.addLog2("Asset.test.ctor()=" + a1, WB.strEmpty, "Asset");

		} catch (Exception ex) {
			WB.addLog("Asset.test, ex=" + ex.getMessage(), WB.strEmpty, "Asset");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Asset.test end ", WB.strEmpty, "Asset");
	}
}