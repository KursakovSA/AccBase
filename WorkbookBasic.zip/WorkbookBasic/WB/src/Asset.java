public class Asset extends Model {
	// origin - 28.09.2023, last edit - 27.06.2024
	public static Asset root;
	public Asset parent;
	public Geo geo;
	public Role role;
	public Info info;
	public Unit unit;
	
	static {
		root = new Asset("Asset", "Asset", "AssetData");
	}
	
	public Asset(String Id, String Code, String Description) {
		// origin - 05.12.2023, last edit - 05.12.2023
		this.id = Id;
		this.code = Code;
		this.description = Description;
	}
	
	public Asset() {
		// origin - 05.12.2023, last edit - 05.12.2023
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 27.06.2024
    	WB.addLog("Asset.test, Asset.root=" + Asset.root, WB.strEmpty, "Asset");
	}
}