import java.time.LocalDate;

public class Asset extends ModelDto {
	// origin - 28.09.2023, last edit - 24.09.2024
	public LocalDate dateMFG; //TODO
	public LocalDate dateEXP; //TODO

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Asset.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Asset");
		} finally {
			Etc.doNothing();
		}
	}

	public Asset(String Id, String Code, String Description) throws Exception {
		// origin - 05.12.2023, last edit - 11.08.2024
		super(Id, Code, Description);
		this.table = this.getClass().getName();
	}

	public Asset() throws Exception {
		// origin - 05.12.2023, last edit - 11.08.2024
		super();
		this.table = this.getClass().getName();
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 16.09.2024
		try {

//			// getId
//			Asset newAsset = new Asset();
//			WB.addLog2("Asset.test.getId(), res=" + new IdGen("AssetId", "idCommonCompositeRandom", newAsset).id,
//					WB.strEmpty, "Asset");

		} catch (Exception ex) {
			WB.addLog("Asset.test, ex=" + ex.getMessage(), WB.strEmpty, "Asset");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Asset.test end ", WB.strEmpty, "Asset");
	}
}