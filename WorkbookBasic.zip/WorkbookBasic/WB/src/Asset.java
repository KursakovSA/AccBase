public class Asset extends ModelDto {
	// origin - 28.09.2023, last edit - 20.08.2024

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Asset.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Asset");
		} finally {
			Etc.doNothing();
		}
	}

//	public String getId(String id, LocalDateTime initLocalDateTime, String vendorCode) throws Exception {// TODO for
//																											// IdGen
//		// origin - 28.06.2024, last edit - 20.08.2024
//		String res = WB.strEmpty;
//
//		try {
//			id = Etc.fixTrim(id);
//			res = ModelDto.formatter2(res, id);
//
//			LocalDateTime resDate = initLocalDateTime;
//			if (initLocalDateTime == null) {
//				resDate = DateTool.getNow2();
//			}
//			res = res + DateTool.formatter2(resDate);
//
//			String resVendorCode = Etc.fixTrim(vendorCode);
//			if (resVendorCode.isEmpty()) {
//				resVendorCode = String.valueOf(Etc.getIntRnd(Etc.initRndDefault));
//			}
//
//			res = res + WB.strSharp + resVendorCode;
//		} catch (Exception ex) {
//			WB.addLog("Asset.getId, ex=" + ex.getMessage(), WB.strEmpty, "Asset");
//		} finally {
//			Etc.doNothing();
//		}
////		WB.addLog2("Asset.getId, res=" + res + ", id=" + id + ", initLocalDate=" + initLocalDateTime + ", vendorCode="
////				+ vendorCode, WB.strEmpty, "Asset");
//		return res;
//	}

	public Asset(String Id, String Code, String Description) throws Exception {
		// origin - 05.12.2023, last edit - 11.08.2024
		super(Id, Code, Description);
		this.table = this.getClass().getName();
	}

	public Asset() throws Exception {
		// origin - 05.12.2023, last edit - 11.08.2024
		super();
		this.table = this.getClass().getName();
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 20.08.2024
		try {

			// getId
			Asset newAsset = new Asset();
			WB.addLog2("Asset.test.getId, res=" + newAsset.getId("AssetId", "idCommonCompositeRandom"), WB.strEmpty, "Asset");

		} catch (Exception ex) {
			WB.addLog("Asset.test, ex=" + ex.getMessage(), WB.strEmpty, "Asset");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Asset.test end ", WB.strEmpty, "Asset");
	}
}