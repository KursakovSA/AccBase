import java.util.ArrayList;
import java.util.List;

public class Asset {
	// origin - 28.09.2023, last edit - 05.05.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, date1, date2, code, description, geo, role, info, unit, more, mark;
	// special fields
	public String templateId, assetId, vendorCode, PLUCode, SKUCode, serialNumber, inventoryNumber, passport, VINCode,
			IMEICode, color, producer, groupFixedAssetId, dateMFG, dateEXP, productCondition;
	public String fullName, comment;
	public UnitVal liquidationValue, estimatedValue, depreciationRate, usefulLife, standardUsefulLife;
	public RangeVal isNew;
	public List<AssetDto> subAsset, price, part;
	public List<ModelDto> lower, upper;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Asset.static ctor, ex=" + ex.getMessage(), "", "Asset");
		}
	}

	public void fixByTemplate() throws Exception { // TODO
		// origin - 14.01.2025, last edit - 01.05.2025
		try {
			if (this.templateId.isEmpty() == false) {
			}
		} catch (Exception ex) {
			WB.addLog("Asset.fixByTemplate, ex=" + ex.getMessage(), "", "Asset");
		}
	}

	public void isExist() throws Exception {
		// origin - 30.12.2024, last edit - 13.05.2025
		try {
			// var tableDto = DAL.getByTemplate(WB.lastConnWork,
			// Qry.getMoreFilter(this.table), this.table);
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), this.table);
			// for (var currDto : tableDto) {
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				// if ((Etc.strEquals(currDto.id, this.id))) {
				this.date1 = DefVal.setCustom(this.date1, dto.date1);
				this.date2 = DefVal.setCustom(this.date2, dto.date2);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.code = DefVal.setCustom(this.code, dto.id);
				this.parent = DefVal.setCustom(this.parent, dto.parent);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.geo = DefVal.setCustom(this.geo, dto.geo);
				this.role = DefVal.setCustom(this.role, dto.role);
				this.info = DefVal.setCustom(this.info, dto.info);
				this.unit = DefVal.setCustom(this.unit, dto.unit);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.mark = DefVal.setCustom(this.mark, dto.mark);

				var listDto2 = DAL.getTable(WB.lastConnWork, Qry.getText(WB.lastConnWork, "Asset", ""));
				this.upper = ModelDto.getUpper(listDto2, this.parent);
				this.lower = ModelDto.getLower(listDto2, this.code);

				this.templateId = MoreVal.getFieldByKey(this.more, "TemplateId");
				this.assetId = MoreVal.getFieldByKey(this.more, "AssetId");
				this.vendorCode = MoreVal.getFieldByKey(this.more, "VendorCode");
				this.PLUCode = MoreVal.getFieldByKey(this.more, "PLUCode");
				this.SKUCode = MoreVal.getFieldByKey(this.more, "SKUCode");
				this.serialNumber = MoreVal.getFieldByKey(this.more, "SerialNumber");
				this.inventoryNumber = MoreVal.getFieldByKey(this.more, "InventoryNumber");
				this.passport = MoreVal.getFieldByKey(this.more, "Passport");
				this.VINCode = MoreVal.getFieldByKey(this.more, "VINCode");
				this.IMEICode = MoreVal.getFieldByKey(this.more, "IMEICode");
				this.color = MoreVal.getFieldByKey(this.more, "Color");
				this.producer = MoreVal.getFieldByKey(this.more, "VendorCode");
				this.groupFixedAssetId = MoreVal.getFieldByKey(this.more, "VendorCode");
				this.dateMFG = MoreVal.getFieldByKey(this.more, "VendorCode");
				this.dateEXP = MoreVal.getFieldByKey(this.more, "VendorCode");
				this.productCondition = MoreVal.getFieldByKey(this.more, "VendorCode");

				this.liquidationValue = new UnitVal(MoreVal.getFieldByKey(this.more, "LiquidationValue"));
				this.estimatedValue = new UnitVal(MoreVal.getFieldByKey(this.more, "EstimatedValue"));
				this.depreciationRate = new UnitVal(MoreVal.getFieldByKey(this.more, "DepreciationRate"));
				this.usefulLife = new UnitVal(MoreVal.getFieldByKey(this.more, "UsefulLife"));
				this.standardUsefulLife = new UnitVal(MoreVal.getFieldByKey(this.more, "StandardUsefulLife"));
				this.isNew = new RangeVal(MoreVal.getFieldByKey(this.more, "IsNew"));

				this.isExist = true;
				// break;
				// }
			}
			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = "";
			}
		} catch (Exception ex) {
			WB.addLog("Asset.isExist, ex=" + ex.getMessage(), "", "Asset");
		}
	}

	private void getPart() throws Exception {
		// origin - 13.05.2025, last edit - 13.05.2025
		try {
			if (this.id.isEmpty() == false) {
				this.part = AssetPart.get(this.id);
				this.price = AssetPrice.get(this.id);
				this.subAsset = SubAsset.get(this.id);
			}
		} catch (Exception ex) {
			WB.addLog("Asset.getPart, ex=" + ex.getMessage(), "", "Asset");
		}
	}

	public Asset(String Id) throws Exception {
		// origin - 05.12.2023, last edit - 13.05.2025
		this.clear();
		this.table = "Asset";
		this.src = this.id = Id;
		this.isExist();
		this.getPart();
	}

	public Asset() throws Exception {
		// origin - 05.12.2023, last edit - 04.05.2025
		this.clear();
		var root = Abc.getRoot(this.table);
		// var root = Abc.getRoot("Asset");
		this.id = root.id;
		this.parent = root.parent;
		this.date1 = root.date1;
		this.date2 = root.date2;
		this.code = root.code;
		this.description = root.description;
		this.geo = root.geo;
		this.role = root.role;
		this.info = root.info;
		this.unit = root.unit;
		this.more = root.more;
		this.mark = root.mark;
	}

	public void clear() throws Exception {
		// origin - 29.12.2024, last edit - 05.05.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = this.getClass().getName();
			this.src = this.table = this.id = this.parent = this.date1 = this.date2 = this.code = this.description = "";
			this.geo = this.role = this.info = this.unit = this.more = this.mark = this.templateId = "";
			this.fullName = this.comment = "";
			this.lower = new ArrayList<ModelDto>();
			this.upper = new ArrayList<ModelDto>();

			this.assetId = this.vendorCode = this.PLUCode = this.SKUCode = this.serialNumber = "";
			this.inventoryNumber = this.passport = this.VINCode = this.IMEICode = this.color = "";
			this.producer = this.groupFixedAssetId = this.dateMFG = this.dateEXP = this.productCondition = "";

			this.liquidationValue = this.estimatedValue = this.depreciationRate = this.usefulLife = this.standardUsefulLife = new UnitVal();
			this.isNew = new RangeVal();

			this.subAsset = new ArrayList<AssetDto>();
			this.price = new ArrayList<AssetDto>();
			this.part = new ArrayList<AssetDto>();
		} catch (Exception ex) {
			WB.addLog("Asset.clear, ex=" + ex.getMessage(), "", "Asset");
		}
	}

	public String toString() {
		// origin - 30.12.2024, last edit - 13.05.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", ", this.unit);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addIfNotEmpty(", templateId ", this.templateId);

			res = res + Fmtr.addAnyway(", upper ", this.upper.size());
			res = res + Fmtr.addAnyway(", lower ", this.lower.size());

			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);

			res = res + Fmtr.addIfNotEmpty(", assetId ", this.assetId);
			res = res + Fmtr.addIfNotEmpty(", vendorCode ", this.vendorCode);
			res = res + Fmtr.addIfNotEmpty(", PLUCode", this.PLUCode);
			res = res + Fmtr.addIfNotEmpty(", SKUCode ", this.SKUCode);
			res = res + Fmtr.addIfNotEmpty(", serialNumber ", this.serialNumber);
			res = res + Fmtr.addIfNotEmpty(", inventoryNumber ", this.inventoryNumber);
			res = res + Fmtr.addIfNotEmpty(", passport ", this.passport);
			res = res + Fmtr.addIfNotEmpty(", VINCode ", this.VINCode);
			res = res + Fmtr.addIfNotEmpty(", IMEICode ", this.IMEICode);
			res = res + Fmtr.addIfNotEmpty(", color ", this.color);
			res = res + Fmtr.addIfNotEmpty(", producer ", this.producer);
			res = res + Fmtr.addIfNotEmpty(", groupFixedAssetId ", this.groupFixedAssetId);
			res = res + Fmtr.addIfNotEmpty(", dateMFG ", this.dateMFG);
			res = res + Fmtr.addIfNotEmpty(", dateEXP ", this.dateEXP);
			res = res + Fmtr.addIfNotEmpty(", productCondition ", this.productCondition);

			res = res + Fmtr.addIfNotEmpty(", liquidationValue ", this.liquidationValue.id);
			res = res + Fmtr.addIfNotEmpty(", estimatedValue ", this.estimatedValue.id);
			res = res + Fmtr.addIfNotEmpty(", depreciationRate ", this.depreciationRate.id);
			res = res + Fmtr.addIfNotEmpty(", usefulLife ", this.usefulLife.id);
			res = res + Fmtr.addIfNotEmpty(", standardUsefulLife ", this.standardUsefulLife.id);
			res = res + Fmtr.addIfNotEmpty(", isNew ", this.isNew.id);

			res = res + Fmtr.addIfNotEmpty(", part ", this.part.size());
			res = res + Fmtr.addIfNotEmpty(", price ", this.price.size());
			res = res + Fmtr.addIfNotEmpty(", subAsset ", this.subAsset.size());

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 13.05.2025
		try {

//			// ctor(String)
//			WB.addLog2("Asset.test.ctor(String)", "", "Asset");
//			for (var tmp1 : new String[] { "Asset.Good.Template", "Asset.tralala", "Asset.Test.1" }) {
//				WB.addLog2("Asset.test.ctor(String)=" + new Asset(tmp1), "", "Asset");
//			}

//			// ctor()
//			WB.addLog2("Asset.test.ctor()", "", "Asset");
//			WB.addLog2("Asset.test.ctor()=" + new Asset(), "", "Asset");

		} catch (Exception ex) {
			WB.addLog("Asset.test, ex=" + ex.getMessage(), "", "Asset");
		}
	}
}