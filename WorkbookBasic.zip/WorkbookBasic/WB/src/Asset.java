import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Asset extends ModelDto {
	// origin - 28.09.2023, last edit - 09.11.2024
	public String assetId = WB.strEmpty; // TODO //ex. [IB1][2024-09-27T06:56:36][#85021], but this is not dto.id
	public String vendorCode = WB.strEmpty; // TODO //ex. [IB1][2024-09-27T06:56:36][#85021], but this is not dto.id
	public String PLUCode = WB.strEmpty; // TODO //ex. [IB1][2024-09-27T06:56:36][#85021], but this is not dto.id
	public String SKUCode = WB.strEmpty; // TODO //ex. [IB1][2024-09-27T06:56:36][#85021], but this is not dto.id
	
	public LocalDate dateMFG; // TODO
	public LocalDate dateEXP; // TODO
	
	public List<String> productCondition = new ArrayList<String>(); // TODO
	public String VINcode = WB.strEmpty; // sectoralPawnshop //TODO
	public String IMEIcode = WB.strEmpty; // sectoralPawnshop //TODO
	public String color = WB.strEmpty; // TODO
	public String producer = WB.strEmpty; // TODO
	
	public String groupFixedAssetId = WB.strEmpty; // TODO //for fixed asset
	public UnitVal liquidationValue = new UnitVal("Unit.KZT"); // TODO //for fixed asset
	public UnitVal depreciationRate = new UnitVal("0.0(Unit.Percent)"); // TODO //for fixed asset

	public String serialNumber = WB.strEmpty; // TODO //for fixed asset
	public String inventoryNumber = WB.strEmpty; // TODO //for fixed asset
	public String passport = WB.strEmpty; // TODO //for fixed asset

	public UnitVal usefulLife = new UnitVal("0.0(Unit.Year)"); // TODO //for fixed asset
	public UnitVal standardUsefulLife = new UnitVal("0.0(Unit.Year)"); // TODO //for fixed asset
	
	public RangeVal isNew = new RangeVal(); //TODO "2024-08-01 - 2024-11-04,  2024-08-01 - ?, "
	public UnitVal estimatedValue = new UnitVal("Unit.KZT"); //TODO

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Asset.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Asset");
		} finally {
			Etc.doNothing();
		}
	}

	public Asset(String Id, String Code, String Description) throws Exception {
		// origin - 05.12.2023, last edit - 11.08.2024
		super(Id, Code, Description);
		this.table = this.getClass().getName();
	}

	public Asset() throws Exception {
		// origin - 05.12.2023, last edit - 11.08.2024
		super();
		this.table = this.getClass().getName();
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 28.09.2024
		try {

//			// getId
//			Asset newAsset = new Asset();
//			WB.addLog2("Asset.test.getId(), res=" + new IdGen("AssetId", "idCommonCompositeRandom", newAsset).id,
//					WB.strEmpty, "Asset");

		} catch (Exception ex) {
			WB.addLog("Asset.test, ex=" + ex.getMessage(), WB.strEmpty, "Asset");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Asset.test end ", WB.strEmpty, "Asset");
	}
}