public class Asset extends ModelDto {
	// origin - 28.09.2023, last edit - 08.03.2025
	public String assetId, vendorCode, PLUCode, SKUCode, serialNumber, inventoryNumber, passport, VINCode, IMEICode,
			color, producer, groupFixedAssetId, dateMFG, dateEXP, productCondition;
	public UnitVal liquidationValue, estimatedValue, depreciationRate, usefulLife, standardUsefulLife;
	public RangeVal isNew;
	public SubAsset assetSubNote;
	public AssetPrice priceNote;
	public AssetPart partNote;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Asset.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Asset");
		}
	}

	public void fixByTemplate() throws Exception { // TODO
		// origin - 14.01.2025, last edit - 04.03.2025
		try {
			if (this.templateId.isEmpty() == false) {
			}
		} catch (Exception ex) {
			WB.addLog("Asset.fixByTemplate, ex=" + ex.getMessage(), WB.strEmpty, "Asset");
		}
	}

	public void fix() throws Exception {
		// origin - 30.12.2024, last edit - 04.03.2025
		try {
			super.fix();
			this.id = DefVal.set(this.id, new IdGen("AssetId", "idCommonCompositeRandom", this).id);
			this.geo = DefVal.set(this.geo, Geo.currCountry.id); // Geo.Qazaqstan РК
			this.role = DefVal.set(this.role, Role.assetGood);
			this.info = DefVal.set(this.info, Info.assetActiv);
			this.unit = DefVal.set(this.unit, Unit.strPiece); // Unit.Piece шт
			this.mark = DefVal.set(this.mark, Mark.DD);
			this.fixByTemplate();
		} catch (Exception ex) {
			WB.addLog("Asset.fix, ex=" + ex.getMessage(), WB.strEmpty, "Asset");
		}
	}

	public void isExist() throws Exception {
		// origin - 30.12.2024, last edit - 04.03.2025
		super.isExist();
		try {
			var tableDto = DAL.getByTemplate(WB.lastConnWork, Qry.getMoreFilter(this.table), this.table);
			for (var currDto : tableDto) {
				if ((Etc.strEquals(currDto.id, this.id))) {
					this.date1 = DefVal.setCustom(this.date1, currDto.date1);
					this.date2 = DefVal.setCustom(this.date2, currDto.date2);
					this.code = DefVal.setCustom(this.code, currDto.code);
					this.code = DefVal.setCustom(this.code, currDto.id);
					this.parent = DefVal.setCustom(this.parent, currDto.parent);
					this.description = DefVal.setCustom(this.description, currDto.description);
					this.geo = DefVal.setCustom(this.geo, currDto.geo);
					this.role = DefVal.setCustom(this.role, currDto.role);
					this.info = DefVal.setCustom(this.info, currDto.info);
					this.unit = DefVal.setCustom(this.unit, currDto.unit);
					this.more = DefVal.setCustom(this.more, currDto.more);
					this.mark = DefVal.setCustom(this.mark, currDto.mark);

					var listDto = DAL.getTable(WB.lastConnWork, Qry.getText(WB.lastConnWork, "Asset", WB.strEmpty));
					// WB.addLog2("Asset.isExist, listDto.size=" + listDto.size(), WB.strEmpty,
					// "Asset");
					this.upper = super.getUpper(listDto);
					this.lower = super.getLower(listDto);

					this.templateId = MoreVal.getFieldByKey(this.more, "TemplateId");
					this.assetId = MoreVal.getFieldByKey(this.more, "AssetId");
					this.vendorCode = MoreVal.getFieldByKey(this.more, "VendorCode");
					this.PLUCode = MoreVal.getFieldByKey(this.more, "PLUCode");
					this.SKUCode = MoreVal.getFieldByKey(this.more, "SKUCode");
					this.serialNumber = MoreVal.getFieldByKey(this.more, "SerialNumber");
					this.inventoryNumber = MoreVal.getFieldByKey(this.more, "InventoryNumber");
					this.passport = MoreVal.getFieldByKey(this.more, "Passport");
					this.VINCode = MoreVal.getFieldByKey(this.more, "VINCode");
					this.IMEICode = MoreVal.getFieldByKey(this.more, "IMEICode");
					this.color = MoreVal.getFieldByKey(this.more, "Color");
					this.producer = MoreVal.getFieldByKey(this.more, "VendorCode");
					this.groupFixedAssetId = MoreVal.getFieldByKey(this.more, "VendorCode");
					this.dateMFG = MoreVal.getFieldByKey(this.more, "VendorCode");
					this.dateEXP = MoreVal.getFieldByKey(this.more, "VendorCode");
					this.productCondition = MoreVal.getFieldByKey(this.more, "VendorCode");

					this.liquidationValue = new UnitVal(MoreVal.getFieldByKey(this.more, "LiquidationValue"));
					this.estimatedValue = new UnitVal(MoreVal.getFieldByKey(this.more, "EstimatedValue"));
					this.depreciationRate = new UnitVal(MoreVal.getFieldByKey(this.more, "DepreciationRate"));
					this.usefulLife = new UnitVal(MoreVal.getFieldByKey(this.more, "UsefulLife"));
					this.standardUsefulLife = new UnitVal(MoreVal.getFieldByKey(this.more, "StandardUsefulLife"));
					this.isNew = new RangeVal(MoreVal.getFieldByKey(this.more, "IsNew"));

					this.isExist = true;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Asset.isExist, ex=" + ex.getMessage(), WB.strEmpty, "Asset");
		}
	}

	public void isValid() throws Exception {
		// origin - 30.12.2024, last edit - 04.03.2025
		super.isValid();
		try {
			if (this.date1.isEmpty() | this.role.isEmpty() | this.info.isEmpty() | this.unit.isEmpty()
					| this.mark.isEmpty()) {
				this.isValid = false;
			}
		} catch (Exception ex) {
			WB.addLog("Asset.isValid, ex=" + ex.getMessage(), WB.strEmpty, "Asset");
		}
	}

	public Asset(String Id) throws Exception {
		// origin - 05.12.2023, last edit - 02.03.2025
		this.clear();
		this.src = this.id = Id;
		this.isExist();
		this.assetSubNote = new SubAsset(this.id);
		this.partNote = new AssetPart(this.id);
		this.priceNote = new AssetPrice(this.id, WB.strEmpty);
		this.isValid();
		this.fix();
	}

	public Asset() throws Exception {
		// origin - 05.12.2023, last edit - 30.12.2024
		this.clear();
		var root = Abc.getRoot(this.table);
		this.id = root.id;
		this.parent = root.parent;
		this.date1 = root.date1;
		this.date2 = root.date2;
		this.code = root.code;
		this.description = root.description;
		this.geo = root.geo;
		this.role = root.role;
		this.info = root.info;
		this.unit = root.unit;
		this.more = root.more;
		this.mark = root.mark;
		this.fix();
	}

	public void clear() throws Exception {
		// origin - 29.12.2024, last edit - 04.03.2025
		try {
			super.clear();
			this.table = this.getClass().getName();
			this.assetId = this.vendorCode = this.PLUCode = this.SKUCode = this.serialNumber = WB.strEmpty;
			this.inventoryNumber = this.passport = this.VINCode = this.IMEICode = this.color = WB.strEmpty;
			this.producer = this.groupFixedAssetId = this.dateMFG = this.dateEXP = this.productCondition = WB.strEmpty;

			this.liquidationValue = this.estimatedValue = this.depreciationRate = this.usefulLife = this.standardUsefulLife = new UnitVal();
			this.isNew = new RangeVal(DateTool.getNow().toString() + " - ?");// "2024-11-04 - ?");

			this.assetSubNote = new SubAsset();
			this.priceNote = new AssetPrice();
			this.partNote = new AssetPart();
		} catch (Exception ex) {
			WB.addLog("Asset.clear, ex=" + ex.getMessage(), WB.strEmpty, "Asset");
		}
	}

	public String toString() {
		// origin - 30.12.2024, last edit - 04.03.2025
		String res = WB.strEmpty;
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", ", this.slice);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", ", this.unit);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addIfNotEmpty(", templateId ", this.templateId);

			res = res + Fmtr.addIfNotEmpty(", upper.size ", this.upper.size());
			res = res + Fmtr.addIfNotEmpty(", lower.size ", this.lower.size());

			res = res + Fmtr.addIfNotEmpty(", assetId ", this.assetId);
			res = res + Fmtr.addIfNotEmpty(", vendorCode ", this.vendorCode);
			res = res + Fmtr.addIfNotEmpty(", PLUCode", this.PLUCode);
			res = res + Fmtr.addIfNotEmpty(", SKUCode ", this.SKUCode);
			res = res + Fmtr.addIfNotEmpty(", serialNumber ", this.serialNumber);
			res = res + Fmtr.addIfNotEmpty(", inventoryNumber ", this.inventoryNumber);
			res = res + Fmtr.addIfNotEmpty(", passport ", this.passport);
			res = res + Fmtr.addIfNotEmpty(", VINCode ", this.VINCode);
			res = res + Fmtr.addIfNotEmpty(", IMEICode ", this.IMEICode);
			res = res + Fmtr.addIfNotEmpty(", color ", this.color);
			res = res + Fmtr.addIfNotEmpty(", producer ", this.producer);
			res = res + Fmtr.addIfNotEmpty(", groupFixedAssetId ", this.groupFixedAssetId);
			res = res + Fmtr.addIfNotEmpty(", dateMFG ", this.dateMFG);
			res = res + Fmtr.addIfNotEmpty(", dateEXP ", this.dateEXP);
			res = res + Fmtr.addIfNotEmpty(", productCondition ", this.productCondition);

			res = res + Fmtr.addIfNotEmpty(", liquidationValue ", this.liquidationValue.id);
			res = res + Fmtr.addIfNotEmpty(", estimatedValue ", this.estimatedValue.id);
			res = res + Fmtr.addIfNotEmpty(", depreciationRate ", this.depreciationRate.id);
			res = res + Fmtr.addIfNotEmpty(", usefulLife ", this.usefulLife.id);
			res = res + Fmtr.addIfNotEmpty(", standardUsefulLife ", this.standardUsefulLife.id);
			res = res + Fmtr.addIfNotEmpty(", isNew ", this.isNew.id);

			res = res + Fmtr.addAnyway(", assetSubNote.size ", this.assetSubNote.val.size());
			res = res + Fmtr.addAnyway(", partNote.val.size ", this.partNote.val.size());
			res = res + Fmtr.addAnyway(", priceNote.val.size ", this.priceNote.val.size());

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 04.03.2025
		try {

//			// ctor()
//			WB.addLog2("Asset.test.ctor()=" + new Asset(), WB.strEmpty, "Asset");

//			// ctor (String Id)
//			for (var tmp1 : new String[] { WB.strEmpty, "Asset.Good.Template", "Asset.tralala", "Asset.Test.1" }) {
//				WB.addLog2("Asset.test.ctor(String)=" + new Asset(tmp1), WB.strEmpty, "Asset");
//			}

		} catch (Exception ex) {
			WB.addLog("Asset.test, ex=" + ex.getMessage(), WB.strEmpty, "Asset");
		}
	}
}