import java.time.LocalDateTime;

public class Asset extends Model {
	// origin - 28.09.2023, last edit - 06.07.2024
	// public static Asset root;
	public Asset parent;
	public Geo geo;
	public Role role;
	public Info info;
	public Unit unit;

	public static String getId(String id, LocalDateTime initLocalDateTime, String vendorCode) throws Exception {
		// origin - 28.06.2024, last edit - 28.06.2024
		String res = WB.strEmpty;

		try {
			id = Etc.fixTrim(id);
			res = ModelDto.formatter2(res, id);

			LocalDateTime resDate = initLocalDateTime;
			if (initLocalDateTime == null) {
				resDate = DateTool.getNow2();
			}
			res = res + DateTool.formatter2(resDate);

			String resVendorCode = Etc.fixTrim(vendorCode);
			if (resVendorCode.isEmpty()) {
				resVendorCode = String.valueOf(Etc.getIntRnd(Etc.initRndDefault));
			}

			res = res + "#" + resVendorCode;
		} catch (Exception ex) {
			WB.addLog("Asset.getId, ex=" + ex.getMessage(), WB.strEmpty, "Asset");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("Asset.getId, res=" + res + ", id=" + id + ", initLocalDate=" + initLocalDateTime + ", vendorCode="
//				+ vendorCode, WB.strEmpty, "Asset");
		return res;
	}

	public Asset(String Id, String Code, String Description) throws Exception {
		// origin - 05.12.2023, last edit - 07.07.2024
		try {
			this.id = Id;
			this.code = Code;
			this.description = Description;
		} catch (Exception ex) {
			WB.addLog("Asset.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Asset");
		} finally {
			Etc.doNothing();
		}
	}

	public Asset() throws Exception {
		// origin - 05.12.2023, last edit - 07.07.2024
		try {
		} catch (Exception ex) {
			WB.addLog("Asset.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Asset");
		} finally {
			Etc.doNothing();
		}
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 06.07.2024
		try {

			// getId
			WB.addLog2("Asset.test.getId, res=" + getId("P1", null, "111111"), WB.strEmpty, "Asset");
			WB.addLog2(
					"Asset.test.getId, res="
							+ getId("P2", LocalDateTime.of(WB.minDateDocSupported, DateTool.getNow3()), ""),
					WB.strEmpty, "Asset");

		} catch (Exception ex) {
			WB.addLog("Asset.test, ex=" + ex.getMessage(), WB.strEmpty, "Asset");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Asset.test end ", WB.strEmpty, "Asset");
	}
}