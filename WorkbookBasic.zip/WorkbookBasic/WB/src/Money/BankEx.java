import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public final class BankEx {
	// origin - 13.11.2025, last edit - 19.09.2026

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("BankEx.static ctor, ex=" + ex.getMessage(), "", "BankEx");
		}
	}

	public static List<List<String>> getListByExcel(String pathFile, String map) throws Exception { // TODO
		// origin - 18.09.2026, last edit - 19.09.2026
		List<List<String>> res = new ArrayList<>();
		try {
			var path = Paths.get(pathFile);
			if (path.getFileName().toString().isEmpty()) {
				WB.addLog2("BankEx.getListByExcel(2String):List<String>, pathFile.FileName is empty=" + pathFile, "",
						"BankEx");
				return res;
			}

			if (InOut.hasFile(pathFile) == false) {
				WB.addLog2("BankEx.getListByExcel(2String):List<String>, not exist pathFile=" + pathFile, "", "BankEx");
				return res;
			}

			List<List<String>> tmp = new ArrayList<>();
			if (path.getFileName().toString().endsWith(".xlsx")) {
				tmp = Xls97Reader.get(pathFile, 0);
			}
			if (path.getFileName().toString().endsWith(".xlsx")) {
				tmp = XlsxReader.get(pathFile, 0);
			}
			// WB.log(tmp, "BankEx");
			res.addAll(tmp);
		} catch (Exception ex) {
			WB.addLog("BankEx.getListByExcel(2String):List<FullDto>, ex=" + ex.getMessage(), "", "BankEx");
		}
		return res;
	}

	private BankEx() throws Exception {
		// origin - 18.09.2026, last edit - 19.09.2026
	}

	public static void test() throws Exception {
		// origin - 13.11.2025, last edit - 19.09.2026
		try {

		} catch (Exception ex) {
			WB.addLog("BankEx.test():void, ex=" + ex.getMessage(), "", "BankEx");
		}
	}
}