import java.util.ArrayList;
import java.util.List;

public final class BankEx {
	// origin - 13.11.2025, last edit - 19.09.2026

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("BankEx.static ctor, ex=" + ex.getMessage(), "", "BankEx");
		}
	}

	public static List<List<String>> get(String pathFile, String map) throws Exception { // TOTHINK
		// origin - 26.09.2026, last edit - 19.10.2026
		List<List<String>> res = new ArrayList<>();
		try {
			if (Etc.strNotValid(pathFile, map)) {
				return res;
			}

			if (InOut.hasFile(pathFile) == false) {
				return res;
			}

			if ((pathFile.endsWith(".xls")) || (pathFile.endsWith(".xlsx"))) {
				res = BankEx.getByExcel(pathFile, map);
			}

			// from CSV, TXT ??
		} catch (Exception ex) {
			WB.addLog("BankExMap.get(2String):List<List<String>>, ex=" + ex.getMessage(), "", "BankExMap");
		}
		return res;
	}

	private static List<List<String>> getByExcel(String pathFile, String map) throws Exception {
		// origin - 18.09.2026, last edit - 19.10.2026
		List<List<String>> res = new ArrayList<>();
		try {
			if (Etc.strNotValid(pathFile, map)) {
				return res;
			}

			List<List<String>> tmp = new ArrayList<>();
			if (pathFile.endsWith(".xls")) {
				tmp = Xls97Reader.get(pathFile, 0);
			}
			if (pathFile.endsWith(".xlsx")) {
				tmp = XlsxReader.get(pathFile, 0);
			}

			tmp = BankExMap.get(tmp, map);
			res.addAll(tmp);
		} catch (Exception ex) {
			WB.addLog("BankEx.getByExcel(2String):List<List<String>>, ex=" + ex.getMessage(), "", "BankEx");
		}
		return res;
	}

	private BankEx() throws Exception {
		// origin - 18.09.2026, last edit - 19.09.2026
	}

	public static void test() throws Exception {
		// origin - 13.11.2025, last edit - 01.10.2026
		try {

//			WB.addLog2("BankEx.test.getByExcel(2String):List<List<String>>", "", "BankEx");
//			for (var tmp1 : new String[] { "BankExTest.xlsx", "BankExTest.xls", "Tralala.xlsx" }) {
//				var tmp2 = InOut.getStrPathFileByFileNameInAppDir(tmp1);
//				var tmp3 = BankEx.getByExcel(tmp2, "Pattern=*.xlsx; FirstRow=2; SumCredit=1; KBE=2; KNP=3;");
//				WB.addLog2("BankEx.test.getByExcel(2String):List<List<String>>, res.size=" + tmp3.size() + ", tmp2="
//						+ tmp2, "", "BankEx");
//				WB.log(tmp3, "BankEx");
//			}

		} catch (Exception ex) {
			WB.addLog("BankEx.test():void, ex=" + ex.getMessage(), "", "BankEx");
		}
	}
}