import java.util.ArrayList;
import java.util.List;

public final class Cash {
	// origin - 15.03.2025, last edit - 16.09.2026
	// common fields
	public String table, src, id, parent, code, description, geo, role, info, mark, more, defect;
	// special fields
	public String fullName, comment;
	public ListVal date1, date2;
	// list common + special + timestamp fields in unified val
	public List<FaceDto> val;
	public static List<String> nameList;

	static {
		try {
			Cash.nameList = List.of("CashId", "PaymasterEmpId");
		} catch (Exception ex) {
			WB.addLog("Cash.static ctor, ex=" + ex.getMessage(), "", "Cash");
		}
	}

	// full list cash
	public static List<FaceDto> get() throws Exception {
		// origin - 26.10.2025, last edit - 26.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter("Role.Store.Cash"), "Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					for (var curr : new Cash(currFace.parent, currFace.code).val) {
						if (curr.id.isEmpty() == false) {
							res.add(curr);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Cash.get():List<FaceDto>, ex=" + ex.getMessage(), "", "Cash");
		}
		return res;
	}

	// full list cash for parentId
	public static List<FaceDto> get(String parentId) throws Exception {
		// origin - 04.05.2025, last edit - 26.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, "Role.Store.Cash"),
					"Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					for (var curr : new Cash(currFace.parent, currFace.code).val) {
						if (curr.id.isEmpty() == false) {
							res.add(curr);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Cash.get(String):List<FaceDto>, ex=" + ex.getMessage(), "", "Cash");
		}
		return res;
	}

	// full list cash on date1
	public static List<FaceDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 15.03.2025, last edit - 01.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, "Role.Store.Cash"),
					"Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					var currFaceCash = new Cash(currFace.parent, currFace.code);
					var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceCash.val, "");
					if (curr.id.isEmpty() == false) {
						var tmp = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
								curr.geo, curr.role, curr.info, curr.more, curr.mark);
						res.add(tmp);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Cash.getCurr(2String):List<FaceDto>, ex=" + ex.getMessage(), "", "Cash");
		}
		return res;
	}

	// item cash on date1
	public static FaceDto getCurr(String date1, String faceParentId, String faceCashId) throws Exception {
		// origin - 15.03.2025, last edit - 13.06.2025
		FaceDto res = new FaceDto();
		try {
			var currFaceCash = new Cash(faceParentId, faceCashId);
			if (currFaceCash.val.size() != 0) {
				var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceCash.val, "");
				if (curr.id.isEmpty() == false) {
					res = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
							curr.geo, curr.role, curr.info, curr.more, curr.mark);
				}
			}
		} catch (Exception ex) {
			WB.addLog("Cash.getCurr(3String):FaceDto, ex=" + ex.getMessage(), "", "Cash");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 21.11.2025, last edit - 16.09.2026
		try {
			this.defect = Fmtr.addIfStrEmpty(this.defect, MoreVal.getFieldByKey(this.more, "CashId"), "empty cashId; ");
			this.defect = Fmtr.addIfStrEmpty(this.defect, MoreVal.getFieldByKey(this.more, "PaymasterEmpId"),
					"empty paymasterEmpId; ");
		} catch (Exception ex) {
			WB.addLog("Cash.validate():void, ex=" + ex.getMessage(), "", "Cash");
		}
	}

	private void getVal() throws Exception {
		// origin - 15.03.2025, last edit - 01.10.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description, this.geo,
						this.role, this.info, this.more, this.mark);
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("Cash.getVal():void, ex=" + ex.getMessage(), "", "Cash");
		}
	}

	private void isExist() throws Exception {
		// origin - 15.03.2025, last edit - 21.11.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentCodeRoleFilter(this.parent, this.code, "Role.Store.Cash"), "Face");
			if (listDto.size() != 0) {
				var currDto = listDto.getFirst();
				var tmp = new SpanDate(currDto.date1, currDto.date2);
				this.date1 = new ListVal(tmp.date1);
				this.date2 = new ListVal(tmp.date2);
				this.id = DefVal.setCustom(this.id, currDto.id);
				this.parent = DefVal.setCustom(this.parent, currDto.parent);
				this.code = DefVal.setCustom(this.code, currDto.code);
				this.description = DefVal.setCustom(this.description, currDto.description);
				this.geo = DefVal.setCustom(this.geo, currDto.geo);
				this.role = DefVal.setCustom(this.role, currDto.role);
				this.info = DefVal.setCustom(this.info, currDto.info);
				this.more = DefVal.setCustom(this.more, currDto.more);
				this.mark = DefVal.setCustom(this.mark, currDto.mark);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("Cash.isExist():void, ex=" + ex.getMessage(), "", "Cash");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 12.08.2025, last edit - 16.09.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("Cash.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Cash");
		}
	}

	public Cash(String ParentId, String CashId) throws Exception {
		// origin - 15.03.2025, last edit - 21.11.2025
		this();
		this.src = ParentId + ", " + CashId;
		this.parent = ParentId;
		this.code = CashId;
		this.isExist();
		this.getVal();
		this.validate();
	}

	private void clear() throws Exception {
		// origin - 15.03.2025, last edit - 16.09.2026
		try {
			this.table = "Face";
			this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.more = this.mark = "";
			this.fullName = this.comment = this.defect = "";
			this.date1 = this.date2 = new ListVal();
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("Cash.clear():void, ex=" + ex.getMessage(), "", "Cash");
		}
	}

	public Cash() throws Exception {
		// origin - 15.03.2025, last edit - 15.03.2025
		this.clear();
	}

	public String toString() {
		// origin - 15.03.2025, last edit - 16.09.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 15.03.2025, last edit - 26.10.2025
		try {

//			WB.addLog2("Cash.test.get()", "", "Cash");
//			var tmp = Cash.get();
//			WB.addLog2("Cash.test.get():List<FaceDto>, res.size=" + tmp.size(), "", "Cash");
//			WB.log(tmp, "Cash");

//			// WB.addLog2("Cash.test.getCurr(String)", "", "Cash");
//			for (var tmp1 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
//				WB.addLog2("Cash.test.getCurr(String):List<FaceDto>, res.size=" + Cash.get(tmp1).size() + ", parentId=" + tmp1,
//						"", "Cash");
//				WB.log(Cash.get(tmp1), "Cash");
//			}

//			// WB.addLog2("Cash.test.getCurr(2String)", "", "Cash");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-24", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
//					WB.addLog2("Cash.test.getCurr(2String):List<FaceDto>, res.size=" + Cash.getCurr(tmp1, tmp2).size()
//							+ ", date1=" + tmp1 + ", parentId=" + tmp2, "", "Cash");
//			WB.log(Cash.getCurr(tmp1, tmp2), "Cash");
//				}
//			}

//			// WB.addLog2("Cash.test.getCurr(3String)", "", "Cash");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-24", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
//					for (var tmp3 : new String[] { "Face.FA1.Cash1", "Face.Tralala.Cash1" }) {
//						WB.addLog2("Cash.test.getCurr(3String):FaceDto, res=" + Cash.getCurr(tmp1, tmp2, tmp3) + ", date1=" + tmp1
//								+ ", faceParentId=" + tmp2 + ", faceCashId=" + tmp3, "", "Cash");
//					}
//				}
//			}

//			// WB.addLog2("Cash.test.ctor(2String)", "", "Cash");
//			for (var tmp1 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
//				for (var tmp2 : new String[] { "Face.FA1.Cash1", "Face.Tralala.Cash1" }) {
//					WB.addLog2("Cash.test.ctor(2String)=" + new Cash(tmp1, tmp2), "", "Cash");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("Cash.test():void, ex=" + ex.getMessage(), "", "Cash");
		}
	}
}