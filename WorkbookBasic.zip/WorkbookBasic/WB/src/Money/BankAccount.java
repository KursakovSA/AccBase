import java.util.List;

public final class BankAccount {
	// origin - 08.12.2025, last edit - 10.12.2025
	// common fields
	public String src, id, context, defect;
	// special fields
	public String IBAN, fullName, comment;
	public BankId bankId;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("BankAccount.static ctor, ex=" + ex.getMessage(), "", "BankAccount");
		}
	}

	public static BankAccount getByFaceId(String faceId) throws Exception {
		// origin - 08.12.2025, last edit - 16.10.2026
		BankAccount res = new BankAccount();
		try {
			if (Etc.strNotValid(faceId)) {
				return res;
			}
			var faceDto = new FaceDto(faceId);
			var tmp = MoreVal.getFieldByKey(faceDto.more, "BankAccount");

			if (Etc.strNotValid(tmp)) {
				return res;
			}
			res = new BankAccount(tmp);
		} catch (Exception ex) {
			WB.addLog("BankAccount.getByFaceId(String):BankAccount, ex=" + ex.getMessage() + ", faceId=" + faceId, "",
					"BankAccount");
		}
		return res;
	}

	public String toDoc() throws Exception {
		// origin - 21.12.2025, last edit - 21.12.2025
		String res = "";
		try {
			res = res + "IBAN: " + Etc.fixTrim(this.IBAN) + ", ";
			res = res + this.bankId.toDoc();
		} catch (Exception ex) {
			WB.addLog("BankAccount.toDoc():String, ex=" + ex.getMessage(), "", "BankAccount");
		}
		return res;
	}
	
	private void fix() throws Exception {
		// origin - 25.10.2026, last edit - 25.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}
		} catch (Exception ex) {
			WB.addLog("BankAccount.fix():void, ex=" + ex.getMessage(), "", "BankAccount");
		}
	}

	private void validate() throws Exception {
		// origin - 08.12.2025, last edit - 10.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}

			if (this.IBAN.length() < 4) {
				this.defect = this.defect + "empty IBAN; ";
			}
			if (this.bankId.defect.isEmpty() == false) {
				this.defect = this.defect + "defect bankId; ";
			}
		} catch (Exception ex) {
			WB.addLog("BankAccount.validate():void, ex=" + ex.getMessage(), "", "BankAccount");
		}
	}

	private void clear() throws Exception {
		// origin - 08.12.2025, last edit - 10.12.2025
		try {
			this.src = this.id = this.context = this.defect = this.IBAN = this.fullName = this.comment = "";
			this.bankId = new BankId();
		} catch (Exception ex) {
			WB.addLog("BankAccount.clear():void, ex=" + ex.getMessage(), "", "BankAccount");
		}
	}

	public BankAccount(String Src) throws Exception {
		// origin - 08.12.2025, last edit - 25.10.2026
		this.clear();
		this.src = this.id = Src;
		if (this.src.isEmpty() == false) {
			var tmp1 = new NVal(Src);
			var tmp2 = Etc.fixTrim(tmp1.val.get(0));

			if (tmp2.isEmpty() == false) {
				this.IBAN = tmp2;
			}

			String tmp3 = "";
			if (tmp1.val.size() != 0) {
				tmp3 = Etc.fixTrim(tmp1.val.get(1));
			}

			String tmp4 = "";
			if (tmp1.val.size() != 1) {
				tmp4 = Etc.fixTrim(tmp1.val.get(2));
			}

			if (Etc.strListValid(List.of(tmp3, tmp4))) {
				this.bankId = new BankId(tmp3, tmp4);
			}
		}
		this.fix();
		this.validate();
	}

	public BankAccount() throws Exception {
		// origin - 08.12.2025, last edit - 08.12.2025
		this.clear();
	}

	public String toString() {
		// origin - 08.12.2025, last edit - 11.12.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("IBAN ", this.IBAN);
			res = res + Fmtr.addAnyway(", bankId ", this.bankId.id);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", context ", this.context);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 08.12.2025, last edit - 22.12.2025
		try {

//			WB.addLog2("BankAccount.test.toDoc('Face.GCVP-GFSS.Bank1'):String", "", "BankAccount");
//			WB.addLog2("BankAccount.test.toDoc('Face.GCVP-GFSS.Bank1'):String, res="
//					+ BankAccount.getByFaceId("Face.GCVP-GFSS.Bank1").toDoc(), "", "BankAccount");

//			WB.addLog2("BankAccount.test.getByFaceId(String):BankAccount", "", "BankAccount");
//			for (var tmp1 : new String[] { "Face.GCVP-GFSS.Bank1", "Face.FA1", "Face.Enterprise.Template", "Face.Person.Template",
//					"Face.Tralala" }) {
//				WB.addLog2("BankAccount.test.getByFaceId(String):BankAccount, res=" + BankAccount.getByFaceId(tmp1)
//						+ ", faceId=" + tmp1, "", "BankAccount");
//			}

		} catch (Exception ex) {
			WB.addLog("BankAccount.test():void, ex=" + ex.getMessage(), "", "BankAccount");
		}
	}
}