import java.util.ArrayList;
import java.util.List;

public final class BankExMap {
	// origin - 19.09.2026, last edit - 19.09.2026
	public static List<String> mapList;
	public static List<String> mapNameList;
	public static List<String> mapOperList;

	static {
		try {
			BankExMap.mapList = BankExMap.getMapList();
			BankExMap.mapNameList = List.of("Pattern", "FirstRowData", "SumCredit", "KBE", "KNP");
			BankExMap.mapOperList = List.of("total", "noteqv", "eqv");
		} catch (Exception ex) {
			WB.addLog("BankExMap.static ctor, ex=" + ex.getMessage(), "", "BankExMap");
		}
	}

	public static List<List<String>> filterByCol(List<List<String>> inList, int[] col) throws Exception { // TODO
		// origin - 19.09.2026, last edit - 19.09.2026
		List<List<String>> res = new ArrayList<>();
		try {
		} catch (Exception ex) {
			WB.addLog("BankExMap.filterByCol(List<List<String>>, int[]):List<List<String>>, ex=" + ex.getMessage(), "",
					"BankExMap");
		}
		return res;
	}

	public static List<List<String>> filterByFirstRowData(List<List<String>> inList, int firstLineData)
			throws Exception { // TODO
		// origin - 19.09.2026, last edit - 19.09.2026
		List<List<String>> res = new ArrayList<>();
		try {
		} catch (Exception ex) {
			WB.addLog("BankExMap.filterByFirstRowData(List<List<String>>, int):List<List<String>>, ex="
					+ ex.getMessage(), "", "BankExMap");
		}
		return res;
	}

	public static String getVal(String part, String valName) throws Exception { // TODO
		// origin - 19.09.2026, last edit - 19.09.2026
		String res = "";
		try {
			// del , noteqv
		} catch (Exception ex) {
			WB.addLog("BankExMap.getVal(2String):void, ex=" + ex.getMessage(), "", "BankExMap");
		}
		return res;
	}

	public static String getFilter(String part, String valName) throws Exception { // TODO
		// origin - 19.09.2026, last edit - 19.09.2026
		String res = "";
		try {
			// del , noteqv
		} catch (Exception ex) {
			WB.addLog("BankExMap.getFilter(2String):void, ex=" + ex.getMessage(), "", "BankExMap");
		}
		return res;
	}

	public static String getTotal(String part, String valName) throws Exception { // TODO
		// origin - 19.09.2026, last edit - 19.09.2026
		String res = "";
		try {
			// del , noteqv
		} catch (Exception ex) {
			WB.addLog("BankExMap.getTotal(2String):void, ex=" + ex.getMessage(), "", "BankExMap");
		}
		return res;
	}

	private BankExMap() throws Exception {
		// origin - 19.09.2026, last edit - 19.09.2026
	}

	public static List<String> getMapList() throws Exception {
		// origin - 18.09.2026, last edit - 19.09.2026
		List<String> res = new ArrayList<String>();
		try {
			String tmp1 = "Pattern=*.xls; FirstRowData=2; SumCredit=1,total; KBE=2,eqv856; KNP=3,noteqv19;|"
					+ "Pattern=*.xls; FirstRowData=2; SumCredit=1; KBE=2,eqv856; KNP=3,noteqv19,|"
					+ "Pattern=*.xls; FirstRowData=2; SumCredit=4,total; KNP=8,eqv856;|"
					+ "Pattern=*.xls; FirstRowData=2; SumCredit=4; KNP=8,eqv856;|"
					+ "Pattern=*.xls; FirstRowData=2; SumCredit=4; KNP=8;|"
					+ "Pattern=?; FirstRowData=?; SumCredit=?; KNP=?"; // last map for manual custom user hands
			List<String> tmp2 = List.of(tmp1.split("\\|"));
			res.addAll(tmp2);
		} catch (Exception ex) {
			WB.addLog("BankExMap.getMapList():List<String>, ex=" + ex.getMessage(), "", "BankExMap");
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 19.09.2026, last edit - 19.09.2026
		try {

			WB.addLog2("BankExMap.test. MoreVal.getFieldByKey", "", "BankExMap");
			for (var tmp1 : BankExMap.mapList) {
				for (var tmp2 : BankExMap.mapNameList) {
					var tmp3 = MoreVal.getFieldByKey(tmp1, tmp2);
					WB.addLog2(
							"BankExMap.test.MoreVal.getFieldByKey, res=" + tmp3 + ", tmp1=" + tmp1 + ", tmp2=" + tmp2,
							"", "Move");
				}
			}

//			WB.addLog2("BankExMap.test.static.mapList", "", "BankExMap");
//			WB.addLog2("BankExMap.test.static.mapList.size=" + BankExMap.mapList.size(), "", "BankExMap");
//			WB.log(BankExMap.mapList, "BankExMap");

		} catch (Exception ex) {
			WB.addLog("BankExMap.test():void, ex=" + ex.getMessage(), "", "BankExMap");
		}
	}
}