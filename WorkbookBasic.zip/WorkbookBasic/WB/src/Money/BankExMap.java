import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public final class BankExMap {
	// origin - 19.09.2026, last edit - 20.10.2026

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("BankExMap.static ctor, ex=" + ex.getMessage(), "", "BankExMap");
		}
	}

	private static List<String> getColList() throws Exception {
		// origin - 20.10.2026, last edit - 20.10.2026
		List<String> res = new ArrayList<String>();
		try {
			// ++ctrl col
			var tmp1 = NameVar.getValByClassInfo("BankExMap", "Info.Generic.BankExMapCtrlCol");
			List<String> tmp2 = List.of(tmp1.split(";"));
			res.addAll(tmp2);

			// ++info col
			tmp1 = NameVar.getValByClassInfo("BankExMap", "Info.Generic.BankExMapInfoCol");
			tmp2 = List.of(tmp1.split(";"));
			res.addAll(tmp2);
			res = Etc.removeDuplicate(res);
		} catch (Exception ex) {
			WB.addLog("BankExMap.getColList():List<String>, ex=" + ex.getMessage(), "", "BankExMap");
		}
		return res;
	}

	public static List<String> getKindList() throws Exception {
		// origin - 18.09.2026, last edit - 20.10.2026
		List<String> res = new ArrayList<String>();
		try {
			var tmp1 = NameVar.getValByClassInfo("BankExMap", "Info.Generic.BankExMapKind");
			List<String> tmp2 = List.of(tmp1.split("\\|"));
			res.addAll(tmp2);
			res = Etc.removeDuplicate(res);
		} catch (Exception ex) {
			WB.addLog("BankExMap.getKindList():List<String>, ex=" + ex.getMessage(), "", "BankExMap");
		}
		return res;
	}

	private static String getVal(String strPart) throws Exception {
		// origin - 25.09.2026, last edit - 16.10.2026
		String res = "";
		try {
			if (Etc.strNotValid(strPart)) {
				return res;
			}

			var tmp1 = MoreVal.getValueByPart(strPart);
			List<String> tmp2 = List.of(tmp1.split(","));
			res = tmp2.getFirst(); // ex. val = "8" for "SumCredit=8,total"
		} catch (Exception ex) {
			WB.addLog("BankExMap.getVal(String):String, ex=" + ex.getMessage(), "", "BankExMap");
		}
		return res;
	}

	private static String getVal(String strMap, String valMapName) throws Exception {
		// origin - 19.09.2026, last edit - 19.10.2026
		String res = "";
		try {
			if (Etc.strNotValid(strMap, valMapName)) {
				return res;
			}

			var tmp1 = MoreVal.getFieldByKey(strMap, valMapName);
			List<String> tmp2 = List.of(tmp1.split(","));
			res = tmp2.getFirst();
		} catch (Exception ex) {
			WB.addLog("BankExMap.getVal(2String):String, ex=" + ex.getMessage(), "", "BankExMap");
		}
		return res;
	}

	private static String getOperLessArg(String strPart) throws Exception {
		// origin - 28.09.2026, last edit - 16.10.2026
		String res = "";
		try {
			if (Etc.strNotValid(strPart)) {
				return res;
			}

			strPart = Etc.fixTrim(strPart);
			for (var curr : ColRow.operList) {
				if (strPart.startsWith(curr)) {
					return res = curr;
				}
			}
		} catch (Exception ex) {
			WB.addLog("BankExMap.getOperLessArg(String):String, ex=" + ex.getMessage(), "", "BankExMap");
		}
		return res;
	}

	private static String getOperArg(String operPart) throws Exception {
		// origin - 29.09.2026, last edit - 16.10.2026
		String res = "";
		try {
			if (Etc.strNotValid(operPart)) {
				return res;
			}

			for (var curr : ColRow.operList) {
				if (operPart.startsWith(curr)) { // ex. "eqv856", eqv - oper, 856 - arg
					res = Etc.delStr(operPart, curr);
				}
			}
		} catch (Exception ex) {
			WB.addLog("BankExMap.getOperArg(String):String, ex=" + ex.getMessage(), "", "BankExMap");
		}
		return res;
	}

	private static boolean isColName(String colName) throws Exception {
		// origin - 26.09.2026, last edit - 20.10.2026
		boolean res = false;
		try {
			if (Etc.strNotValid(colName)) {
				return res;
			}

			colName = Etc.fixTrim(colName);
			for (var curr : BankExMap.getColList()) {
				if (colName.startsWith(curr)) {
					res = true;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("BankExMap.isColName(String):boolean, ex=" + ex.getMessage(), "", "BankExMap");
		}
		return res;
	}

//	private static List<List<String>> getColPartListByMap(String strMap) throws Exception {
//		// origin - 29.09.2026, last edit - 30.09.2026
//		List<List<String>> res = new ArrayList<>();
//		try {
//			var tmp1 = MoreVal.getList(strMap, ";");
//			for (var curr : tmp1) {
//				List<String> tmp2 = BankExMap.getColPartList(curr);
//				if (tmp2.size() != 0) {
//					res.add(tmp2); // [[SumCredit, 1], [KBE, 2], [KNP, 3]]
//				}
//			}
//		} catch (Exception ex) {
//			WB.addLog("BankExMap.getColPartListByMap(String):List<List<String>>, ex=" + ex.getMessage(), "",
//					"BankExMap");
//		}
//		return res;
//	}

	private static List<List<String>> getOperPartListByMap(String strMap) throws Exception {
		// origin - 29.09.2026, last edit - 16.10.2026
		List<List<String>> res = new ArrayList<>();
		try {
			if (Etc.strNotValid(strMap)) {
				return res;
			}

			var tmp1 = MoreVal.getList(strMap, ";");
			for (var curr : tmp1) {
				List<String> tmp2 = BankExMap.getOperPartList(curr);
				if (tmp2.size() != 0) {
					res.add(tmp2); // [[*.xls], [2], [4, total, total], [8, eqv856]]
				}
			}
		} catch (Exception ex) {
			WB.addLog("BankExMap.getOperPartListByMap(String):List<List<String>>, ex=" + ex.getMessage(), "",
					"BankExMap");
		}
		return res;
	}

	private static List<String> getOperPartList(String strPart) throws Exception {
		// origin - 28.09.2026, last edit - 16.10.2026
		List<String> res = new ArrayList<>();
		try {
			if (Etc.strNotValid(strPart)) {
				return res;
			}

			var tmp1 = MoreVal.getValueByPart(strPart);
			var tmp2 = List.of(tmp1.split("\\,"));
			res.addAll(tmp2);
		} catch (Exception ex) {
			WB.addLog("BankExMap.getValPartList(String):List<String>, ex=" + ex.getMessage(), "", "BankExMap");
		}
		return res;
	}

	private static int[] getColArrayByMap(String strMap) throws Exception {
		// origin - 25.09.2026, last edit - 16.10.2026
		int[] res = {};
		ArrayList<Integer> tmp0 = new ArrayList<>();
		try {
			if (Etc.strNotValid(strMap)) {
				return res;
			}

			var tmp1 = MoreVal.getList(strMap, ";");
			for (var curr : tmp1) {
				var tmp2 = MoreVal.getNameByPart(curr);
				if (BankExMap.isColName(tmp2)) {
					var tmp3 = BankExMap.getVal(curr);
					if (Etc.isDigitAll(tmp3)) {
						int tmp4 = Integer.valueOf(tmp3);
						if (tmp4 != 0) {
							tmp0.add(tmp4);
						}
					}
				}
			}

			if (tmp0.size() != 0) {
				res = tmp0.stream().mapToInt(i -> i).toArray();
			}
		} catch (Exception ex) {
			WB.addLog("BankExMap.getColArrayByMap(String):int[], ex=" + ex.getMessage(), "", "BankExMap");
		}
		return res;
	}

	private static List<List<String>> getSeparateByFirstRow(List<List<String>> inList, String strMap) throws Exception {
		// origin - 29.09.2026, last edit - 16.10.2026
		List<List<String>> res = new ArrayList<>();
		try {
			if (Etc.strNotValid(strMap)) {
				return res = inList;
			}

			int firstRowDataDefault = 1;
			String tmp = BankExMap.getVal(strMap, "FirstRow");
			List<List<String>> tmp1 = new ArrayList<>();
			if (tmp.isEmpty() == false) {
				int firstRowDataByMap = Integer.valueOf(BankExMap.getVal(strMap, "FirstRow"));
				int firstRowData = DefVal.setCustom(firstRowDataDefault, firstRowDataByMap);
				tmp1 = ColRow.separateByFirstRow(inList, firstRowData);
			}

			res.addAll(tmp1);
		} catch (Exception ex) {
			WB.addLog("BankExMap.getSeparateByFirstRow(List<List<String>>,String):List<List<String>>, ex="
					+ ex.getMessage() + ", strMap=" + strMap, "", "BankExMap");
		}
		return res;
	}

	private static List<List<String>> getTotal(List<List<String>> inList, String strMap) throws Exception {
		// origin - 01.10.2026, last edit - 16.10.2026
		List<List<String>> res = new ArrayList<>();
		try {
			if (Etc.strNotValid(strMap)) {
				return res = inList;
			}

			List<List<String>> tmp1 = new ArrayList<>(inList);
			for (var curr : BankExMap.getOperPartListByMap(strMap)) {// [[*.xls], [2], [1, total], [2, eqv856], [3]]
				if (Etc.strContains(curr.toString(), "total")) {
					Map<Integer, Double> tmp2 = ColRow.sum(inList);
					List<String> tmp3 = tmp2.values().stream().map(String::valueOf).collect(Collectors.toList());
					res.add(tmp3);
					return res; // "total" doing 1 time
				}
			}
			res.addAll(tmp1);
		} catch (Exception ex) {
			WB.addLog("BankExMap.getTotal(List<List<String>>,String):List<List<String>>, ex=" + ex.getMessage(), "",
					"BankExMap");
		}
		return res;
	}

	private static List<List<String>> getSeparateByCol(List<List<String>> inList, String strMap) throws Exception {
		// origin - 29.09.2026, last edit - 16.10.2026
		List<List<String>> res = new ArrayList<>();
		try {
			if (Etc.strNotValid(strMap)) {
				return res = inList;
			}

			int[] col = BankExMap.getColArrayByMap(strMap);
			List<List<String>> tmp2 = new ArrayList<>();
			tmp2 = ColRow.separateCol(inList, col);
			res.addAll(tmp2);
		} catch (Exception ex) {
			WB.addLog("BankExMap.getSeparateByCol(List<List<String>>,String):List<List<String>>, ex=" + ex.getMessage(),
					"", "BankExMap");
		}
		return res;
	}

	private static List<List<String>> getFilterByOper(List<List<String>> inList, String strMap) throws Exception {
		// origin - 30.09.2026, last edit - 16.10.2026
		List<List<String>> res = new ArrayList<>();
		try {
			if (Etc.strNotValid(strMap)) {
				return res = inList;
			}
			List<List<String>> tmp2 = inList;

			List<List<String>> operPartListByMap = BankExMap.getOperPartListByMap(strMap);
			int currColNumber = 0; // ex. 1,2
			String currOperWithArg = ""; // ex. "eqv856", "noteqv19"
			String currOperLessArg = ""; // ex. "eqv", "noteqv"
			String currColVal = ""; // ex. "856", "19"
			for (var curr : operPartListByMap) {// [[*.xls], [2], [1, total], [2, eqv856], [3]]
				if (curr.size() == 2) {
					currColNumber = Integer.valueOf(curr.getFirst());
					if (currColNumber != 0) {
						currOperWithArg = curr.getLast();
						currColVal = BankExMap.getOperArg(currOperWithArg);
						currOperLessArg = BankExMap.getOperLessArg(currOperWithArg);
						if (ColRow.isFilter(currOperLessArg)) {
							tmp2 = ColRow.filterRowByColValAndOper(tmp2, currColNumber, currColVal, currOperLessArg);
						}
					}
				}
			}

			res.addAll(tmp2);
		} catch (Exception ex) {
			WB.addLog("BankExMap.getFilterByOper(List<List<String>>,String):List<List<String>>, ex=" + ex.getMessage(),
					"", "BankExMap");
		}
		return res;
	}

	public static List<List<String>> get(List<List<String>> inList, String strMap) throws Exception {
		// origin - 25.09.2026, last edit - 16.10.2026
		List<List<String>> res = new ArrayList<>();
		try {
			if (inList.size() == 0) {
				return res;
			}

			if (strMap.isEmpty()) {
				return res = inList;
			}

			List<List<String>> tmp1 = new ArrayList<>(); // 1 step - separate by first row
			tmp1 = BankExMap.getSeparateByFirstRow(inList, strMap);

			List<List<String>> tmp2 = tmp1; // 2 step - eqv, noteqv
			tmp2 = BankExMap.getFilterByOper(tmp2, strMap);

			List<List<String>> tmp3 = tmp2; // 3 step - total
			tmp3 = BankExMap.getTotal(tmp3, strMap);

			List<List<String>> tmp4 = tmp3; // 4 step - separate by col
			tmp4 = BankExMap.getSeparateByCol(tmp4, strMap);

			res.addAll(tmp4);
		} catch (Exception ex) {
			WB.addLog("BankExMap.get(List<List<String>>,String):List<List<String>>, ex=" + ex.getMessage(), "",
					"BankExMap");
		}
		return res;
	}

	private BankExMap() throws Exception {
		// origin - 19.09.2026, last edit - 19.09.2026
	}

	public static void test() throws Exception {
		// origin - 19.09.2026, last edit - 20.10.2026
		try {

//			{
//				WB.addLog2("BankExMap.test.getColList():List<String>", "", "BankExMap");
//				var tmp1 = BankExMap.getColList();
//				WB.addLog2("BankExMap.test.getColList():List<String>, res.size=" + tmp1.size() + ", tmp1=" + tmp1, "",
//						"BankExMap");
//				WB.log(tmp1, "BankExMap");
//			}

//			{
//				WB.addLog2("BankExMap.test.getKindList():List<String>", "", "BankExMap");
//				var tmp1 = BankExMap.getKindList();
//				WB.addLog2("BankExMap.test.getKindList():List<String>, res.size=" + tmp1.size() + ", tmp1=" + tmp1, "",
//						"BankExMap");
//				WB.log(tmp1, "BankExMap");
//			}

//			WB.addLog2("BankExMap.test.getColPartListByMap(String):List<List<String>>", "", "BankExMap");
//			for (var tmp1 : BankExMap.getKindList()) {
//				WB.addLog2("BankExMap.test.getColPartListByMap(String):List<List<String>>, res="
//						+ BankExMap.getColPartListByMap(tmp1) + ", tmp1=" + tmp1, "", "BankExMap");
//			}

//			WB.addLog2("BankExMap.test.getOperPartListByMap(String):List<List<String>>", "", "BankExMap");
//			for (var tmp1 : BankExMap.getKindList()) {
//				WB.addLog2("BankExMap.test.getOperPartListByMap(String):List<List<String>>, res="
//						+ BankExMap.getOperPartListByMap(tmp1) + ", tmp1=" + tmp1, "", "BankExMap");
//			}

//			WB.addLog2("BankExMap.test.getOperPartList(String):List<String>", "", "BankExMap");
//			for (var tmp1 : BankExMap.getKindList()) {
//				var tmp2 = MoreVal.getList(tmp1, ";");
//				for (var tmp3 : tmp2) {
//					WB.addLog2("BankExMap.test.getOperPartList(String):List<String>, res="
//							+ BankExMap.getOperPartList(tmp3) + ", tmp3=" + tmp3, "", "BankExMap");
//				}
//			}

//			{
//				WB.addLog2("BankExMap.test.get(List<List<String>>;String):List<List<String>>", "", "BankExMap"); // TODO
//				var tmp1 = List.of("100|856|Unit.Kg|100|200|", "200|856|19|300|400|", "300|856|Unit.Gr|500|600|",
//						"400|W12|Unit.Kg|700|800|");
//				var tmp2 = new ColRow(tmp1);
//				WB.addLog2("BankExMap.test.get(List<List<String>>,String):List<List<String>>, before get", "",
//						"ColRowVal");
//				WB.log(tmp2.row, "BankExMap");
//				for (var tmp3 : BankExMap.getKindList()) {
//					var tmp4 = BankExMap.get(tmp2.row, tmp3);
//					WB.addLog2("BankExMap.test.get(List<List<String>>,String):List<List<String>>, res.size="
//							+ tmp4.size() + ", tmp3=" + tmp3, "", "BankExMap");
//					WB.log(tmp4, "BankExMap");
//				}
//			}

//			{
//				WB.addLog2("BankExMap.test.getOperLessArg(String):String", "", "BankExMap");
//				var tmp1 = List.of("6", "KNP=6,total", "KNP=6,eqv", "KNP=6,noteqv", "eqv567", "noteqv19", "tralala",
//						"6,eqv", "KNP=6,tralala");
//				for (var tmp2 : tmp1) {
//					WB.addLog2("BankExMap.test.getOperLessArg(String):String, res=" + BankExMap.getOperLessArg(tmp2)
//							+ ", tmp2=" + tmp2, "", "BankExMap");
//				}
//			}

//				WB.addLog2("BankExMap.test.getColArray(String):int[]", "", "BankExMap");
//				for (var tmp1 : BankExMap.getKindList()) {
//					WB.addLog2("BankExMap.test.getColArray(String):int[], res="
//							+ Fmtr.listVal(BankExMap.getColArray(tmp1)) + ", tmp1=" + tmp1, "", "BankExMap");
//				}

//				WB.addLog2("BankExMap.test.isColName(String):boolean", "", "BankExMap");
//				for (var tmp1 : BankExMap.getList()) {
//					WB.addLog2("BankExMap.test.isColName(String):boolean, res=" + BankExMap.isColName(tmp1) + ", tmp1="
//							+ tmp1, "", "BankExMap");
//				}
//
//			WB.addLog2("BankExMap.test.getOperArg(3String):String", "", "BankExMap");
//			for (var tmp1 : BankExMap.getKindList()) {
//				for (var tmp2 : BankExMap.getOperPartListByMap(tmp1)) {
//					for (var tmp3 : tmp2) {
//						var tmp4 = BankExMap.getOperArg(tmp3);
//						WB.addLog2("BankExMap.test.getOperArg(String):String, res=" + tmp4 + ", tmp3=" + tmp3, "",
//								"BankExMap");
//					}
//				}
//			}

//				WB.addLog2("BankExMap.test.getVal(2String):String", "", "BankExMap");
//				for (var tmp1 : BankExMap.getKindList()) {
//					for (var tmp2 : BankExMap.nameList) {
//						var tmp3 = BankExMap.getVal(tmp1, tmp2);
//						WB.addLog2("BankExMap.test.getVal(2String):String, res=" + tmp3 + ", tmp1=" + tmp1 + ", tmp2="
//								+ tmp2, "", "BankExMap");
//					}
//				}

		} catch (Exception ex) {
			WB.addLog("BankExMap.test():void, ex=" + ex.getMessage(), "", "BankExMap");
		}
	}
}