import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

public class Conv {
	// origin - 15.07.2024, last edit - 15.07.2024
	
	public static String formatterDouble(String initVal) throws Exception {
		// origin - 11.07.2024, last edit - 15.07.2024
		String res = WB.strEmpty;
		try {
			res = Conv.formatterDouble(initVal, WB.charDot, WB.charSpace);
		} catch (Exception ex) {
			WB.addLog("Conv.formatterDouble, ex=" + ex.getMessage(), WB.strEmpty, "Conv");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Conv.formatterDouble, res=" + res + ", initVal=" +
		// initVal, WB.strEmpty, "Conv");
		return res;
	}

	public static String formatterDouble(String initVal, char decimalSeparator, char groupingSeparator)
			throws Exception {
		// origin - 11.07.2024, last edit - 15.07.2024
		String res = WB.strEmpty;
		try {
			initVal = Conv.fixDouble(initVal);
			double tmp = Conv.getDouble(initVal);
			// res = String.format("%1$,.2f", tmp);
			DecimalFormatSymbols symbols = new DecimalFormatSymbols();
			symbols.setDecimalSeparator(decimalSeparator);
			symbols.setGroupingSeparator(groupingSeparator);
			DecimalFormat decimalFormat = new DecimalFormat("#,##0.00", symbols);
			res = decimalFormat.format(tmp);
		} catch (Exception ex) {
			WB.addLog("Conv.formatterDouble, ex=" + ex.getMessage(), WB.strEmpty, "Conv");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Conv.formatterDouble, res=" + res + ", initVal=" +
		// initVal, WB.strEmpty, "Conv");
		return res;
	}

	public static String fixDouble(String strFix) throws Exception {
		// origin - 10.01.2024, last edit - 15.07.2024
		String res = WB.strEmpty;
		try {
			strFix = Etc.fixTrim(strFix);

			if (strFix.indexOf(WB.strComma) == strFix.lastIndexOf(WB.strComma)) {// if substr contain one char "," ex.
				// "14,8464554" that doing = "14.8464554"
				strFix = strFix.replace(WB.strComma, ".");
			}

			if (strFix.endsWith(",0")) {// fix fraction separator
				strFix = strFix.substring(0, strFix.length() - 2) + ".0"; // ???magic numbers and strings ???
			}

			if (strFix.endsWith(",00")) {// fix fraction separator
				strFix = strFix.substring(0, strFix.length() - 3) + ".0"; // ???magic numbers and strings ???
			}

			if (strFix.endsWith(",000")) {// fix fraction separator
				strFix = strFix.substring(0, strFix.length() - 4) + ".0"; // ???magic numbers and strings ???
			}

			if (strFix.endsWith(",0000")) {// fix fraction separator
				strFix = strFix.substring(0, strFix.length() - 5) + ".0"; // ???magic numbers and strings ???
			}

			if (strFix.endsWith(",00000")) {// fix fraction separator
				strFix = strFix.substring(0, strFix.length() - 6) + ".0"; // ???magic numbers and strings ???
			}

			if (strFix.indexOf(WB.strComma) == strFix.lastIndexOf(WB.strComma)) {// if substr contain one char "," ex.
																					// "14,8464554"
				strFix = strFix.replace(WB.strComma, WB.strEmpty);
			}

			strFix = strFix.replaceAll(WB.strComma, WB.strEmpty);
			strFix = strFix.replaceAll(WB.strSpace, WB.strEmpty);// del space, because spaces not need for double number
			res = strFix;
		} catch (Exception ex) {
			WB.addLog("Conv.fixDouble, ex=" + ex.getMessage(), WB.strEmpty, "Conv");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Conv.fixDouble, res=" + res + ", strFix=" + strFix, WB.strEmpty,
		// "Conv");
		return res;
	}

	public static double getDouble(String initValue) throws Exception {
		// origin - 07.01.2024, last edit - 15.07.2024
		double res = 0.0;
		initValue = Conv.fixDouble(initValue);
		try {
			if (initValue.isEmpty() == false) {
				res = Double.parseDouble(initValue);
			} else {
				res = 0.0;
			}
		} catch (Exception ex) {
			WB.addLog("Conv.getDouble, ex=" + ex.getMessage(), WB.strEmpty, "Conv");
			res = 0.0;
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Conv.getDouble, res=" + res + ", initValue="
		// +
		// fieldMeterValue, WB.strEmpty, "Conv");
		return res;
	}

	public Conv() throws Exception {
		// origin - 15.07.2024, last edit - 15.07.2024
		try {
		} catch (Exception ex) {
			WB.addLog("Conv.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Conv");
		} finally {
			Etc.doNothing();
		}
	}

	public static void test() throws Exception {
		// origin - 15.07.2024, last edit - 15.07.2024
		try {

			// getDouble
			for (String testArg1 : new String[] { "17420", "17 420", "17420.0", "17420.00", "17420,0", "17420,00",
					"17420,000", "17420,0000", "17 420.00", "-17420", "17420 - 18560", "34.152562", "34,152562",
					"34,153,600.2", "34 153 600.2", "34153600.2" }) {
				WB.addLog2("Conv.test.getDouble, res=" + Conv.getDouble(testArg1) + ", testArg1=" + testArg1,
						WB.strEmpty, "Conv");
			}

			// fixDouble
			for (String testArg1 : new String[] { "1,5", "1.5", "17420", "17 420", "17420.0", "17420.00", "17420,0",
					"17420,00", "17420,000", "17420,0000", "17 420.00", "-17420", "17420 - 18560", "34.152562",
					"34,152562", "34,153,600.2", "34 153 600.2", "34153600.2" }) {
				WB.addLog2("Conv.test.fixDouble, res=" + fixDouble(testArg1) + ", testArg1=" + testArg1, WB.strEmpty,
						"Etc");
			}

		} catch (Exception ex) {
			WB.addLog("Conv.test, ex=" + ex.getMessage(), WB.strEmpty, "Conv");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Conv.test end ", WB.strEmpty, "Conv");
	}
}
