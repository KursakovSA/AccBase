public class TagVal extends ModelVal {// ex. "<AnnualMeeting=CostForDinner>", where tag=AnnualMeeting,
										// val=CostForDinner
	// origin - 26.09.2024, last edit - 26.09.2024
	private static final String strLeftSplit = "<";
	private static final String strMiddleEquation = "=";
	private static final String strRightSplit = ">";

	// public String partVal = new String();
	// public String partTag = new String();

	public String tag = WB.strEmpty;
	public String val = WB.strEmpty;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("TagVal.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "TagVal");
		} finally {
			Etc.doNothing();
		}
	}

	private void getPart() throws Exception {
		// origin - 26.09.2024, last edit - 26.09.2024
		try {
			if (this.isTagVal()) {
				int posLocalStrMiddleEquation = this.src.indexOf(TagVal.strMiddleEquation); // pos "="
				if (posLocalStrMiddleEquation > 0) {
					// this is res
					this.tag = Etc.fixTrim(this.src.substring(0, posLocalStrMiddleEquation)); // ex.
																								// "<AnnualMeeting=CostForDinner>"
																								// --> "<AnnualMeeting="
					this.tag = Etc.delStr(this.tag, TagVal.strLeftSplit);
					this.tag = Etc.delStr(this.tag, TagVal.strMiddleEquation);
					this.tag = Etc.delStr(this.tag, TagVal.strRightSplit);

					this.val = Etc.fixTrim(this.src.substring(posLocalStrMiddleEquation));
					this.val = Etc.delStr(this.val, TagVal.strLeftSplit);
					this.val = Etc.delStr(this.val, TagVal.strMiddleEquation);
					this.val = Etc.delStr(this.val, TagVal.strRightSplit);

					this.id = this.tag + TagVal.strMiddleEquation + this.val;
				}
			}
		} catch (Exception ex) {
			WB.addLog("TagVal.getPart, ex=" + ex.getMessage(), WB.strEmpty, "TagVal");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("TagVal.getPart, this.partVal=" + this.partVal + ", this.partUnit=" + this.partUnit + ", this.src="
//				+ this.src, WB.strEmpty, "TagVal");
	}

	public boolean isTagVal() throws Exception {
		// origin - 26.09.2024, last edit - 26.09.2024
		boolean res = false;
		try {
			if (Etc.strMatch(this.src, TagVal.strLeftSplit) == 1) {
				if (Etc.strMatch(this.src, TagVal.strRightSplit) == 1) {
					if (this.src.startsWith(TagVal.strLeftSplit)) {
						if (this.src.endsWith(TagVal.strRightSplit)) {
							res = true;
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("TagVal.isUnitVal, ex=" + ex.getMessage(), WB.strEmpty, "TagVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("TagVal.isTagVal, res=" + res, WB.strEmpty, "TagVal");
		return res;
	}

//	private void get() throws Exception {
//		// origin - 26.09.2024, last edit - 26.09.2024
//		try {
//			this.val = Conv.getDouble(this.partVal);
//
//			String tmp = this.partUnit;
//			tmp = Etc.delStr(tmp, UnitVal.strLeftSplit);
//			tmp = Etc.delStr(tmp, UnitVal.strRightSplit);
//			// WB.addLog2("UnitVal.getUnitVal, tmp=" + tmp, WB.strEmpty, "UnitVal");
//			var dto = ModelDto.getSubsetByCode(WB.abcLast.basic, tmp);
//			if (dto.size() != 0) {
//				var dto1 = dto.getFirst();
//				this.unit = new Unit(dto1.id, dto1.code, dto1.description); // this is res
//			} else {
//				this.unit = new Unit(); // this is res
//			}
//			this.id = this.val + WB.strSpace + this.unit.description;
//		} catch (Exception ex) {
//			WB.addLog("TagVal.get, ex=" + ex.getMessage(), WB.strEmpty, "TagVal");
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("TagVal.get, this.unit=" + this.unit, WB.strEmpty,
//		// "TagVal");
//	}

//	public TagVal(String Val, String Unit) throws Exception {
//		// origin - 26.09.2024, last edit - 26.09.2024
//		this();
//		// clean, because may be alone chars "(" and\or ")" //??
//		Unit = Etc.delStr(Unit, TagVal.strLeftSplit);
//		Unit = Etc.delStr(Unit, TagVal.strRightSplit);
//		this.src = Etc.fixTrim(String.valueOf(Val)) + TagVal.strLeftSplit + Unit + TagVal.strRightSplit;
//		this.getPart();
//		this.get();
//	}

	public TagVal(String Src) throws Exception {
		// origin - 26.09.2024, last edit - 26.09.2024
		this();
		this.src = Etc.fixTrim(Src);
		this.getPart();
		// this.get();
	}

	public TagVal() throws Exception {
		// origin - 26.09.2024, last edit - 26.09.2024
		super();
	}

	public String toString() {
		// origin - 26.09.2024, last edit - 26.09.2024
		String res = WB.strEmpty;
		try {
			res = this.id;
		} catch (Exception ex) {
			// WB.addLog("TagVal.toString, ex=" + ex.getMessage(), WB.strEmpty,
			// "TagVal");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 26.09.2024, last edit - 26.09.2024
		try {

			// ctor1
			TagVal tagVal1 = new TagVal("<AnnualMeeting=CostForDinner>");
			WB.addLog2("TagVal.test.ctor1, tagVal1.id=" + tagVal1.id + ", tagVal1.tag=" + tagVal1.tag + ", tagVal1.val="
					+ tagVal1.val + ", init str=" + "<AnnualMeeting=CostForDinner>", WB.strEmpty, "UnitVal");

		} catch (Exception ex) {
			WB.addLog("TagVal.test, ex=" + ex.getMessage(), WB.strEmpty, "TagVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("TagVal.test end ", WB.strEmpty, "TagVal");
	}
}