import java.util.LinkedHashMap;
import java.util.List;

@SuppressWarnings("unused")
public class Slice extends ModelDto {
	// origin - 06.12.2023, last edit - 20.03.2025
	private static LinkedHashMap<String, String> shift = new LinkedHashMap<String, String>();
	public static String Accounting, Norm, Fact;

	static {
		try {
			Slice.Accounting = "Slice.Accounting";
			Slice.Norm = "Slice.Norm";
			Slice.Fact = "Slice.Fact";
			Slice.shift.put("Slice.Accounting", "Slice.Plan");
			Slice.shift.put("Slice.Accounting", "Slice.Fact");
			Slice.shift.put("Slice.Plan", "Slice.Accounting");
			Slice.shift.put("Slice.Fact", "Slice.Accounting");
		} catch (Exception ex) {
			WB.addLog("Slice.static ctor, ex=" + ex.getMessage(), "", "Slice");
		}
	}

	private static boolean shiftValid(String fromSlice, String toSlice) throws Exception {
		// origin - 02.10.2024, last edit - 21.03.2025
		boolean res = false;
		try {
			for (var currShift : Slice.shift.entrySet()) {
				if ((Etc.strEquals(currShift.getKey(), fromSlice)) && (Etc.strEquals(currShift.getValue(), toSlice))) {
					res = true;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Slice.shiftValid, ex=" + ex.getMessage() + ", res=" + res, "", "Slice");
		}
		return res;
	}

	public void isExist() throws Exception {
		// origin - 02.10.2024, last edit - 20.03.2025
		super.isExist();
		try {
			for (var currDto : WB.abcLast.slice) {
				if (Etc.strEquals(currDto.id, this.id)) {
					this.date1 = DefVal.setCustom(this.date1, currDto.date1);
					this.date2 = DefVal.setCustom(this.date2, currDto.date2);
					this.code = DefVal.setCustom(this.code, currDto.code);
					this.parent = DefVal.setCustom(this.parent, currDto.parent);
					this.description = DefVal.setCustom(this.description, currDto.description);
					this.more = DefVal.setCustom(this.more, currDto.more);

					this.isExist = true;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Slice.isExist, ex=" + ex.getMessage(), "", "Slice");
		}
	}

	public Slice(String Id) throws Exception {
		// origin - 06.12.2023, last edit - 04.03.2025
		this();
		this.src = Id;
		if (Id.isEmpty() == false) {
			this.id = this.code = Id;
		}
		this.date1 = DateTool.getNow().toString();
		this.isExist();
		this.isValid();
	}

	public Slice() throws Exception {
		// origin - 06.12.2023, last edit - 11.08.2024
		super();
		this.table = this.getClass().getName();
	}

	public String toString() {
		// origin - 11.12.2024, last edit - 20.03.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 20.03.2025
		try {
			var tmpList = List.of("", "Slice.Accounting", "Slice.tralala", "Slice.Duplicate");

//			// shiftValid
//			WB.addLog2("Slice.test.shiftValid, res=" + Slice.shiftValid("Slice.Accounting", "Slice.Fact")
//					+ ", sliceFrom=Slice.Accounting, sliceTo=Slice.Fact", "", "Slice");
//			WB.addLog2("Slice.test.shiftValid, res=" + Slice.shiftValid("Slice.Accounting", "Slice.tralala")
//					+ ", sliceFrom=Slice.Accounting, sliceTo=Slice.tralala", "", "Slice");
//			WB.addLog2("Slice.test.shiftValid, res=" + Slice.shiftValid("Slice.Offer", "Slice.Duplicate")
//					+ ", sliceFrom=Slice.Offer, sliceTo=Slice.Duplicate", "", "Slice");

//			// ctor (String Id)
//			for (var tmp : tmpList) {
//				WB.addLog2("Slice.test.ctor(String)=" + new Slice(tmp.id), "", "Slice");
//			}

		} catch (Exception ex) {
			WB.addLog("Slice.test, ex=" + ex.getMessage(), "", "Slice");
		}
	}
}