import java.util.LinkedHashMap;

@SuppressWarnings("unused")
public class Slice extends ModelDto {
	// origin - 06.12.2023, last edit - 04.10.2024

	private static LinkedHashMap<String, String> shift = new LinkedHashMap<String, String>();

	static {
		try {
			Slice.shift.put("Slice.Accounting", "Slice.Plan");
			Slice.shift.put("Slice.Accounting", "Slice.Fact");
			Slice.shift.put("Slice.Plan", "Slice.Accounting");
			Slice.shift.put("Slice.Fact", "Slice.Accounting");
		} catch (Exception ex) {
			WB.addLog("Slice.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Slice");
		} finally {
			Etc.doNothing();
		}
	}

	private static boolean shiftValid(String fromSlice, String toSlice) throws Exception {
		// origin - 02.10.2024, last edit - 13.11.2024
		boolean res = false;
		try {
			for (var currShift : Slice.shift.entrySet()) {
				if ((Etc.strEquals(currShift.getKey(), fromSlice)) & (Etc.strEquals(currShift.getValue(), toSlice))) {
					res = true;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Slice.shiftValid, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Slice");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Slice.shiftValid, res=" + res + ", this=" + this, WB.strEmpty,
		// "Slice");
		return res;
	}

	public boolean isExist() throws Exception {
		// origin - 02.10.2024, last edit - 13.11.2024
		boolean res = super.isExist();
		try {
			var tableDto = DAL.getByTemplate(WB.lastConnWork, Qry.getMoreFilter(this.table), this.table);
			for (var currDto : tableDto) {
				if ((Etc.strEquals(currDto.id, this.id)) & (Etc.strEquals(currDto.code, this.code))
						& (Etc.strEquals(currDto.description, this.description))) {
					res = true;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Slice.isExist, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Slice");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Slice.isExist, res=" + res + ", this=" + this, WB.strEmpty,
		// "Slice");
		return res;
	}

	public Slice(String Id, String Code, String Description) throws Exception {
		// origin - 06.12.2023, last edit - 11.08.2024
		super(Id, Code, Description);
		this.table = this.getClass().getName();
	}

	public Slice() throws Exception {
		// origin - 06.12.2023, last edit - 11.08.2024
		super();
		this.table = this.getClass().getName();
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 15.10.2024
		try {

//			// shiftValid
//			WB.addLog2("Slice.test.shiftValid, res=" + Slice.shiftValid("Slice.Accounting", "Slice.Fact")
//					+ ", sliceFrom=Slice.Accounting, sliceTo=Slice.Fact", WB.strEmpty, "Slice");
//			WB.addLog2("Slice.test.shiftValid, res=" + Slice.shiftValid("Slice.Accounting", "Slice.tralala")
//					+ ", sliceFrom=Slice.Accounting, sliceTo=Slice.tralala", WB.strEmpty, "Slice");
//			WB.addLog2("Slice.test.shiftValid, res=" + Slice.shiftValid("Slice.Offer", "Slice.Duplicate")
//					+ ", sliceFrom=Slice.Offer, sliceTo=Slice.Duplicate", WB.strEmpty, "Slice");

//			// isValid, isExist
//			Slice slice1 = new Slice("Slice.Accounting", "Slice.Accounting", "учет");
//			WB.addLog2("Slice.test.ctor, Slice1=" + slice1 + ", isExist=" + slice1.isExist() + ", isValid="
//					+ slice1.isValid(), WB.strEmpty, "Slice");
//			Slice slice2 = new Slice("Slice", "Slice.tralala", "Slice.tralala");
//			WB.addLog2("Slice.test.ctor, slice2=" + slice2 + ", isExist=" + slice2.isExist() + ", isValid="
//					+ slice2.isValid(), WB.strEmpty, "Slice");

		} catch (Exception ex) {
			WB.addLog("Slice.test, ex=" + ex.getMessage(), WB.strEmpty, "Slice");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Slice.test end ", WB.strEmpty, "Slice");
	}
}
