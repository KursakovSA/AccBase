import java.util.Arrays;
import java.util.TreeSet;

public class Slice extends Model {
	// origin - 06.12.2023, last edit - 18.01.2024
	public static Slice root;
	public static TreeSet<String> allowShift;
	public Slice parent;
    
    static {
		root = new Slice("Slice","Slice","sliceData");
		allowShift = new TreeSet<String>(Arrays.asList("Accounting", "Fact", "Plan"));
	}
    
    public Slice(String Id, String Code, String Description) {
		// origin - 06.12.2023, last edit - 06.12.2023
		this.id = Id;
		this.code = Code;
		this.description = Description;
	}
    
    public Slice() {
		// origin - 06.12.2023, last edit - 06.12.2023
	}
    
    public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 27.06.2024
    	WB.addLog("Slice.test, Slice.root=" + Slice.root, WB.strEmpty, "Slice");
	}
}
