import java.util.Arrays;
import java.util.TreeSet;

public class Slice extends Model {
	// origin - 06.12.2023, last edit - 06.07.2024
	public static TreeSet<String> allowShift;
	public Slice parent;

	static {
		try {
			allowShift = new TreeSet<String>(Arrays.asList("Accounting", "Fact", "Plan"));
		} catch (Exception ex) {
			WB.addLog("Slice.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Slice");
		} finally {
			Etc.doNothing();
		}
	}

	public Slice(String Id, String Code, String Description) throws Exception {
		// origin - 06.12.2023, last edit - 07.07.2024
		try {
			this.id = Id;
			this.code = Code;
			this.description = Description;
		} catch (Exception ex) {
			WB.addLog("Slice.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Slice");
		} finally {
			Etc.doNothing();
		}
	}

	public Slice() throws Exception {
		// origin - 06.12.2023, last edit - 07.07.2024
		try {
		} catch (Exception ex) {
			WB.addLog("Slice.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Slice");
		} finally {
			Etc.doNothing();
		}
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 06.07.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Slice.test, ex=" + ex.getMessage(), WB.strEmpty, "Slice");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Slice.test end ", WB.strEmpty, "Slice");
	}
}
