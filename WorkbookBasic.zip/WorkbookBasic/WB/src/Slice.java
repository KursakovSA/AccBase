import java.util.LinkedHashMap;

public class Slice extends ModelDto {
	// origin - 06.12.2023, last edit - 12.09.2024

	public static LinkedHashMap<String, String> shift = new LinkedHashMap<String, String>();

	static {
		try {
			Slice.shift.put("Accounting","Plan");
			Slice.shift.put("Accounting","Fact");
			Slice.shift.put("Plan","Accounting");
			Slice.shift.put("Fact","Accounting");
		} catch (Exception ex) {
			WB.addLog("Slice.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Slice");
		} finally {
			Etc.doNothing();
		}
	}

	public Slice(String Id, String Code, String Description) throws Exception {
		// origin - 06.12.2023, last edit - 11.08.2024
		super(Id, Code, Description);
		this.table = this.getClass().getName();
	}

	public Slice() throws Exception {
		// origin - 06.12.2023, last edit - 11.08.2024
		super();
		this.table = this.getClass().getName();
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 16.09.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Slice.test, ex=" + ex.getMessage(), WB.strEmpty, "Slice");
		} finally {
			Etc.doNothing();
		}
		//WB.addLog2("Slice.test end ", WB.strEmpty, "Slice");
	}
}
