import java.time.DayOfWeek;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.OffsetDateTime;
import java.time.YearMonth;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;

public class DateTool {
	// origin - 17.01.2024, last edit - 20.02.2024

	private static List<LocalDate> getListStartMonthYear(LocalDate date) {
		// origin - 18.02.2024, last edit - 18.02.2024
		List<LocalDate> res = new ArrayList<LocalDate>();
		LocalDate currStartMonth = getStartYear(date);
		for (int i = 1; i <= 12; i++) {
			// WB.addLog2("DateTool.getListStartMonthYear, currStartMonth=" +
			// currStartMonth, "", "DateTool");
			res.add(currStartMonth);
			currStartMonth = getStartMonth(getEndMonth(currStartMonth).plusDays(1));
		}
		// WB.addLog2("DateTool.getListStartMonth, res=" + res, "", "DateTool");
		return res;
	}

	public static int getNumberWorkDay(LocalDate date1, LocalDate date2, Face currFA) throws Exception {// TODO---currFA
																										// ???
		// origin - 17.02.2024, last edit - 20.02.2024
		int res = 0;
		int transferWeekend = 0;

		for (LocalDate date = date1; date.isBefore(date2.plusDays(1)); date = date.plusDays(1)) {
			// WB.addLog2("DateTool.getNumberWorkDay, date=" + date, "", "DateTool");

			if (isNotWorkDay(date, currFA) == false) {
				if (isWeekend(date, currFA) == false) {
					res = res + 1;
					// WB.addLog2("DateTool.getNumberWorkDay, date=" + date + ", res=" + res, "",
					// "DateTool");
				}
			}

			if (isNotWorkDay(date, currFA)) {
				if (isWeekend(date, currFA)) {
					if (isExtraDayOff(date, currFA) == false) {
						transferWeekend = transferWeekend + 1;
						WB.addLog2("DateTool.getNumberWorkDay, date=" + date + ", transferWeekend=" + transferWeekend,
								"", "DateTool");
					}
				}
			}
		}

		int transferWeekendFromPreviousMonth = 0;// TODO - calc transfer weekend from previous month - example, day of
												// constitution
												// for 2025 31 august
		if (isMonthSpan(date1, date2)) {
			if (Etc.strEquals(date1.getMonth().toString(), "JANUARY") == false) {// for January not previous transfer weekend
																			// from previous month

			}
		}

		res = res - transferWeekend - transferWeekendFromPreviousMonth;
		// WB.addLog2("DateTool.getNumberWorkDay, res=" + res + ", date1=" + date1 + ",
		// date2=" + date2, "", "DateTool");
		return res;
	}
	
	private static boolean isMonthSpan(LocalDate date1, LocalDate date2) throws Exception {
		// origin - 19.02.2024, last edit - 19.02.2024
		boolean res = false;
		if (date1.equals(getStartMonth(date1))) {
			if (date2.equals(getEndMonth(date1))) {
				res = true;
			}
		}
		// WB.addLog2("DateTool.isMonthSpan, res=" + res + ", date1=" + date1 + ",
		// date2=" + date2, "", "DateTool");
		return res;
	}


	private static boolean isWeekend(LocalDate currDate, Face currFA) throws Exception {// TODO --- currFA ???
		// origin - 17.02.2024, last edit - 18.02.2024
		boolean res = false;
		// if (isNotWorkDay(currDate, currFA) != true) {
		if (currDate.getDayOfWeek() == DayOfWeek.SATURDAY) {
			res = true;
		}
		if (currDate.getDayOfWeek() == DayOfWeek.SUNDAY) {
			res = true;
		}
		// }
		// WB.addLog2("DateTool.isWeekend, res=" + res + ", currDate1=" + currDate, "",
		// "DateTool");
		return res;
	}

	private static boolean isExtraDayOff(LocalDate currDate, Face currFA) throws Exception {// TODO --- currFA ???
		// origin - 18.02.2024, last edit - 19.02.2024
		boolean res = false;
		LocalDate dateStartYear = getStartYear(currDate);
		for (var currDayOff : WB.abcGlobal.notWorkDay) {

			if (Etc.strContains(currDayOff.meter, "Meter.ExtraDayOff")) {

				// skip not actual ExtraDayOff
				if (currDayOff.date2.isEmpty() == false) {
					if (getLocalDate(currDayOff.date2).isBefore(dateStartYear)) {
						// WB.addLog2("DateTool.isExtraDayOff, skip not actual isExtraDayOff=" +
						// currDayOff, "", "DateTool");
						continue;
					}
				}
				if (currDayOff.meterValue.isEmpty()) {
					// WB.addLog("DateTool.isExtraDayOff, currDayOff.meterValue=" +
					// currDayOff.meterValue + ", currDate=" + currDate, "", "DateTool");
					continue;
				}
				if (Etc.strContains(currDate.toString(), currDayOff.meterValue)) {
					res = true;
					// WB.addLog2("DateTool.isExtraDayOff, res=" + res + ", currDayOff=" +
					// currDayOff + ", currDate1=" + currDate, "", "DateTool");
					break;
				}
			}
		}
		WB.addLog2("DateTool.isExtraDayOff, res=" + res + ", currDate1=" + currDate, "", "DateTool");
		return res;
	}

	private static boolean isNotWorkDay(LocalDate currDate, Face currFA) throws Exception {// TODO --- currFA ???
		// origin - 22.01.2024, last edit - 19.02.2024
		boolean res = false;
		LocalDate dateStartYear = getStartYear(currDate);
		for (var currDayOff : WB.abcGlobal.notWorkDay) {

			// skip not actual NotWorkDay
			if (currDayOff.date2.isEmpty() == false) {
				if (getLocalDate(currDayOff.date2).isBefore(dateStartYear)) {
					// WB.addLog2("DateTool.isNotWorkDay, skip not actual NotWorkDay=" + currDayOff,
					// "", "DateTool");
					continue;
				}
			}
			if (currDayOff.meterValue.isEmpty()) {
				WB.addLog("DateTool.isNotWorkDay, currDayOff.meterValue=" + currDayOff.meterValue + ", currDate="
						+ currDate, "", "DateTool");
				continue;
			}
			if (Etc.strContains(currDate.toString(), currDayOff.meterValue)) {
				res = true;
				// WB.addLog2("DateTool.isNotWorkDay, res=" + res + ", currDayOff=" + currDayOff
				// + ", currDate1=" + currDate, "", "DateTool");
				break;
			}
		}
		// WB.addLog2("DateTool.isNotWorkDay, res=" + res + ", currDate1=" + currDate,
		// "", "DateTool");
		return res;
	}
	
//	public static List<ModelDto> getScheduleNotWorkDay(LocalDate calcDate, Face currFA) throws Exception {// TODO
//	// origin - 22.01.2024, last edit - 27.01.2024
//	List<ModelDto> res = new ArrayList<ModelDto>();
//	LocalDate currDate1;
//	LocalDate currDate2;
//	ModelDto tmp = new ModelDto();
//	for (var currSegment : Abc.segmentNotWorkDay) {
//		tmp.clear();
//		currDate1 = DateCalendar.getLocalDate(currSegment.date1);// left border in data
//		currDate2 = DateCalendar.getLocalDate(currSegment.date2);// right border in data
//		if (currDate1.isAfter(calcDate)) {
//			continue;
//		}
//		if (currDate1.isBefore(calcDate)) {// because for curr year may be not be actual data
//			// tmp = Workbook.getMeterValueString(currSegment.meterValue);
//			tmp = currSegment;
//		}
//
//		if (currDate1 == calcDate) {// left border hit
//			// tmp = Workbook.getMeterValueString(currSegment.meterValue);
//			tmp = currSegment;
//			break;
//		}
//		if (currDate2 == calcDate) {// right border hit
//			// tmp = Workbook.getMeterValueString(currSegment.meterValue);
//			tmp = currSegment;
//			break;
//		}
//
//		if (currDate1.isBefore(calcDate)) {// range from left border to right border hit
//			if (currDate2.isAfter(calcDate)) {
//				// tmp = Workbook.getMeterValueString(currSegment.meterValue);
//				tmp = currSegment;
//				break;
//			}
//		}
////		if (tmp.meterValue.toString().contains("PublicHoliday")) {
////			res.add(tmp);
////		}
////		if (tmp.meterValue.toString().contains("ExtraDayOff")) {
////			res.add(tmp);
////		}
//
//	}
//	WB.addLog2("DateTool.getScheduleDayOff, res.size=" + res.size(), "", "DateTool");
//	return res;
//}

//	public static ModelDto getSegmentByCode(String code) {
//		// origin - 22.01.2024, last edit - 27.01.2024
//		ModelDto res = new ModelDto();
//		for (var currSegment : Abc.segmentNotWorkDay) {
//			if (currSegment.code == code) {// TODO --- ??? contains code ???
//				res = currSegment;
//				break;
//			}
//		}
//		// WB.addLog2("DateTool.getSegmentByCode, res=" + res + ", code=" + code,
//		// "", "DateTool");
//		return res;
//	}

//	public static String getSegment(LocalDate calcDate, ModelDto filterDto) {
//		// origin - 22.01.2024, last edit - 27.01.2024
//		String res = "";
//		try {
////			 WB.addLog2("DateTool.getSegment, ModelDto.getSubset(WB.abcGlobal.basic, filterDto).size=" + ModelDto.getSubset(WB.abcGlobal.basic, filterDto).size() + ", calcDate=" +
////			 calcDate + ", filterDto=" + filterDto,"","DateTool");
//			res = Workbook.getChronoMeterValueString(calcDate, ModelDto.getSubset(WB.abcGlobal.basic, filterDto));
//		} catch (Exception ex) {
//			WB.addLog("DateTool.getSegment, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace() + ", res="
//					+ res, "", "DateTool");
//		} finally {
//			Etc.doNothing();
//		}
////		 WB.addLog2("DateTool.getSegment, res=" + res + ", calcDate=" +
////		 calcDate + ", filterDto=" + filterDto,"","DateTool");
//		return res;
//	}

	public static OffsetDateTime getOffsetDateTime(String expectedDate) {// TODO
		// origin - 24.11.2023, last edit - 27.01.2024
		OffsetDateTime res;
		expectedDate = Etc.fixTrim(expectedDate);
		try {
			res = OffsetDateTime.parse(expectedDate);
		} catch (Exception ex) {
			// res = OffsetDateTime.of(expectedDate, null, null);
			res = null;
			// WB.addLog("DateTool.getOffsetDateTime, ex=" + ex.getMessage(), ",
			// StackTrace=" + ex.getStackTrace(), "DateTool");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static LocalDate getLocalDate(String expectedDate) {// TODO
		// origin - 24.11.2023, last edit - 27.01.2024
		LocalDate res = null;
		expectedDate = Etc.fixTrim(expectedDate);
		try {
			res = LocalDate.parse(expectedDate);
			res = fixLocalDate(res);
		} catch (Exception ex) {
			res = null;
			// WB.addLog("DateTool.getOffsetDateTime, ex=" + ex.getMessage(), ",
			// StackTrace=" + ex.getStackTrace(), "DateTool");
		} finally {
			if (res == null) {
				res = LocalDate.now();
			}
		}
		return res;
	}

	public static LocalTime getLocalTime(String expectedDate) {// TODO
		// origin - 24.11.2023, last edit - 27.01.2024
		LocalTime res;
		expectedDate = Etc.fixTrim(expectedDate);
		try {
			res = LocalTime.parse(expectedDate);
		} catch (Exception ex) {
			res = null;
			// WB.addLog("DateTool.getOffsetDateTime, ex=" + ex.getMessage(), ",
			// StackTrace=" +
			// ex.getStackTrace(), "DateTool");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static LocalDate fixLocalDate(LocalDate fixDate) {
		// origin - 02.10.2023, last edit - 20.11.2023
		// LocalDate not must be big maxDateSupported and least minDateSupported
		LocalDate res = fixDate;
		if (fixDate.isBefore(WB.minDateSupported)) {
			res = WB.minDateSupported;
		}
		if (fixDate.isAfter(WB.maxDateSupported)) {
			res = WB.maxDateSupported;
		}
		return res;
	}

	private static LocalDate getStartYear(LocalDate currDate) {
		// origin - 22.01.2024, last edit - 18.02.2024
		LocalDate res = LocalDate.of(currDate.getYear(), 1, 1);
		// WB.addLog2("DateTool.getStartYear, res=" + res + ", currDate=" +
		// currDate, "", "DateTool");
		return res;
	}

	private static LocalDate getEndYear(LocalDate currDate) {
		// origin - 22.01.2024, last edit - 18.02.2024
		LocalDate res = LocalDate.of(currDate.getYear(), 12, 31);
		// WB.addLog2("DateTool.getEndYear, res=" + res + ", currDate=" + currDate,
		// "", "DateTool");
		return res;
	}

	private static LocalDate getStartMonth(LocalDate currDate) {
		// origin - 22.01.2024, last edit - 18.02.2024
		LocalDate res = YearMonth.of(currDate.getYear(), currDate.getMonth()).atDay(1);// firstDay;//currDate;
		// WB.addLog2("DateTool.getStartMonth, res=" + res + ", currDate=" +
		// currDate, "", "DateTool");
		return res;
	}

	private static LocalDate getEndMonth(LocalDate currDate) {
		// origin - 22.01.2024, last edit - 18.02.2024
		LocalDate res = YearMonth.of(currDate.getYear(), currDate.getMonth()).atEndOfMonth();// currDate;
		// WB.addLog2("DateTool.getEndMonth, res=" + res + ", currDate=" + currDate,
		// "", "DateTool");
		return res;
	}

	public static String getLabelDateTimeForFileName() {
		// origin - 27.12.2023, last edit - 18.01.2024
		String res = Etc.fixTrim(getLocalDateTimeNow().toString());
		res = res.replaceAll("-", "_");
		res = res.replaceAll(":", "_");
		res = res + "_";
		return res;
	}

	public static LocalDateTime getLocalDateTimeNow() {
		// origin - 18.12.2023, last edit - 18.12.2023
		return LocalDateTime.now(ZoneOffset.systemDefault().getRules().getOffset(Instant.now()));
	}

	public static int getDuration(OffsetDateTime date1, OffsetDateTime date2) {
		// origin - 21.10.2023, last edit - 18.01.2024
		return Math.abs((int) Etc.roundCustom(Duration.between(date2, date1).toMillis(), Etc.round0));
	}

	public static OffsetDateTime getOffsetDateTimeNow() {
		// origin - 21.10.2023, last edit - 24.11.2023
		return OffsetDateTime.now(ZoneOffset.systemDefault().getRules().getOffset(Instant.now()));
	}

	public static void test() throws Exception {
		// origin - 17.01.2024, last edit - 18.02.2024
		var testDateTime1 = new String[] { "2023-11-24T06:46:16.907+06:00", "2023-11-08 02:15:09", "06:46:16.907+06:00",
				"2019-01-01", "test1", "12.45", "12:45", "12:45:38", "12:45:57.678", null };

//		var testDate1 = new String[] { "2023-01-01T06:46:16.907+06:00", "2023-11-08 02:15:09", "06:46:16.907+06:00",
//				"2019-01-01", "test1", "12.45", "12:45", "12:45:38", "12:45:57.678", null };

		var testLocalDate = new LocalDate[] { LocalDate.now().minusMonths(1), LocalDate.now(),
				LocalDate.of(2024, Month.JANUARY, 1), LocalDate.of(2024, Month.APRIL, 18) };

		// getNumberWorkDay
		for (var date1 : getListStartMonthYear(getStartYear(LocalDate.now()).minusDays(1))) {
			WB.addLog2("DateTool.test.getNumberWorkDay, res=" + getNumberWorkDay(date1, getEndMonth(date1), null)
					+ ", month=" + date1.getMonth(), "", "DateTool");
		}
		for (var date1 : getListStartMonthYear(LocalDate.now())) {
			WB.addLog2("DateTool.test.getNumberWorkDay, res=" + getNumberWorkDay(date1, getEndMonth(date1), null)
					+ ", month=" + date1.getMonth(), "", "DateTool");
		}
		
		//isMonthSpan
		WB.addLog2("DateTool.test.isMonthSpan, res=" + isMonthSpan(getStartMonth(LocalDate.now()), getEndMonth(LocalDate.now())), "", "DateTool");
		WB.addLog2("DateTool.test.isMonthSpan, res=" + isMonthSpan(LocalDate.now().minusDays(1), LocalDate.now()), "", "DateTool");

//		// isWeekend
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("DateTool.test.isWeekend, res=" + isWeekend(testArg1, null) + ", testArg1=" + testArg1 + ", (" + testArg1.getDayOfWeek() + ")", "", "DateTool");
//		}

//		// isNotWorkDay
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("DateTool.test.isNotWorkDay, res=" + isNotWorkDay(testArg1, null) + ", testArg1=" + testArg1 + ", (" + testArg1.getDayOfWeek() + ")", "", "DateTool");
//		}

//		// getListStartMonthYear
//		WB.addLog2("DateTool.test.getListStartMonthYear, res=" + getListStartMonthYear(LocalDate.now()), "", "DateTool");

//		// getSegment
//		for (ModelDto testArg2 : WB.abcGlobal.notWorkDay) {
//			for (LocalDate testArg1 : new LocalDate[] { LocalDate.now().minusYears(1), LocalDate.now() }) {
//				WB.addLog2("DateTool.test.getSegment, res=" + getSegment(testArg1, testArg2) + ", testArg1="
//						+ testArg1 + ", testArg2=" + testArg2, "", "DateTool");
//			}
//		}

//		// getOffsetDateTime
//		for (var testArg1 : testDateTime1) {
//			WB.addLog2("DateTool.test.getOffsetDateTime, res=" + getOffsetDateTime(testArg1) + ", testArg1="
//					+ testArg1, "", "DateTool");
//		}
//
//		// getLocalDate
//		for (var testArg1 : testDateTime1) {
//			WB.addLog2("DateTool.test.getLocalDate, res=" + getLocalDate(testArg1) + ", testArg1=" + testArg1, "",
//					"DateTool");
//		}
//
//		// getLocalTime
//		for (var testArg1 : testDateTime1) {
//			WB.addLog2("DateTool.test.getLocalTime, res=" + getLocalTime(testArg1) + ", testArg1=" + testArg1, "",
//					"DateTool");
//		}
//
//		// fixLocalDate
//		for (LocalDate testArg1 : new LocalDate[] { LocalDate.of(2026, Month.APRIL, 28), LocalDate.of(1967, Month.NOVEMBER, 25),
//				LocalDate.of(2100, Month.MAY, 26) }) {
//			WB.addLog2("DateTool.test.fixLocalDate, res=" + fixLocalDate(testArg1) + ", testArg1=" + testArg1, "",
//					"DateTool");
//		}

//		// getStartYear
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("DateTool.test.getStartYear, res=" + getStartYear(testArg1) + ", testArg1=" + testArg1, "",
//					"DateTool");
//		}

//		// getEndYear
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("DateTool.test.getEndYear, res=" + getEndYear(testArg1) + ", testArg1=" + testArg1, "",
//					"DateTool");
//		}

//		// getStartMonth
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("DateTool.test.getStartMonth, res=" + getStartMonth(testArg1) + ", testArg1=" + testArg1, "",
//					"DateTool");
//		}

//		// getEndMonth
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("DateTool.test.getEndMonth, res=" + getEndMonth(testArg1) + ", testArg1=" + testArg1, "",
//					"DateTool");
//		}
	}
}
