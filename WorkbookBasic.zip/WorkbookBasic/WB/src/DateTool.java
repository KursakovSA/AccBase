import java.time.DayOfWeek;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.OffsetDateTime;
import java.time.YearMonth;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class DateTool {
	// origin - 17.01.2024, last edit - 12.06.2024

	public static int getWorkdayCount(LocalDate date1, LocalDate date2, Face currFA) {// TODO---currFA // ???
		// origin - 17.02.2024, last edit - 26.05.2024
		int res = 0;

		for (; !date1.isAfter(date2); date1 = date1.plusDays(1)) {
			if (isWorkdayFinally(date1, currFA)) {
				res = res + 1;
			}
		}

//int transferWeekend = 0;
//		for (LocalDate date = date1; date.isBefore(date2.plusDays(1)); date = date.plusDays(1)) {
//			// WB.addLog2("DateTool.getNumberWorkDay, date=" + date, "", "DateTool");
//
//			if (isNotWorkday(date, currFA) == false) {
//				if (isWeekend(date, currFA) == false) {
//					res = res + 1;
//					// WB.addLog2("DateTool.getNumberWorkDay, date=" + date + ", res=" + res, "",
//					// "DateTool");
//				}
//			}
//			if (hasTransferWeekend(date, currFA)) {
//				if (isMoreWorkdayMonthSpan(date1, currFA)) {
//					transferWeekend = transferWeekend + 1;
//					WB.addLog2("DateTool.getWorkdayCount, transferWeekend = transferWeekend + 1, date=" + date, "",
//							"DateTool");
//				} else {
//					//WB.addLog2("DateTool.getWorkdayCount, no transferWeekend for date=" + date,
//				    //", isMoreWorkdayMonthSpan(date1)=" + isMoreWorkdayMonthSpan(date1, currFA), "DateTool");
//				}
//			}
//		}
//		int transferWeekendFromPreviousMonth = 0;
//		// TODO - calc transfer weekend from previous month - example, day of
//		// constitution for 2025 31 august
//		if (isMonthSpan(date1, date2)) {
//			if (Etc.strEquals(date1.getMonth().toString(), "JANUARY") == false) {// for January not previous transfer
//																					// weekend
//				// from previous month
//				// last day previous month = hasOverlayPublicHolidayAndWeekend
//				if (hasOverlayPublicHolidayOnWeekend(getEndMonth(date1.minusDays(1)), currFA)) {
//					transferWeekendFromPreviousMonth = transferWeekendFromPreviousMonth + 1;
//					WB.addLog2("DateTool.transferWeekendFromPreviousMonth=" + transferWeekendFromPreviousMonth + ", date=" + date1.minusDays(1), "", "DateTool");
//				}
//				if (hasOverlayPublicHolidayOnWeekend(getEndMonth(date1.minusDays(2)), currFA)) {
//					transferWeekendFromPreviousMonth = transferWeekendFromPreviousMonth + 1;
//					WB.addLog2("DateTool.transferWeekendFromPreviousMonth=" + transferWeekendFromPreviousMonth + ", date=" + date1.minusDays(2), "", "DateTool");
//				}
//			}
//		}
//		res = res - transferWeekend - transferWeekendFromPreviousMonth;

		// WB.addLog2("DateTool.getWorkdayCount, res=" + res + ", date1=" + date1 + ",
		// date2=" + date2, "", "DateTool");
		return res;
	}

	private static boolean isWorkdayFinally(LocalDate date1, Face currFA) {
		// origin - 27.05.2024, last edit - 27.05.2024
		boolean res = false;
		if (isWorkday1(date1, null)) { // definition workday previoslly
			if (isWorkday2(date1, null)) { // definition workday finally
				res = true;
			}
		}
		return res;
	}

	private static boolean hasOverlayPublicHolidayOnWeekend(LocalDate date, Face currFA) {
		// TODO --- currFA ???
		// origin - 21.02.2024, last edit - 27.05.2024
		boolean res = false;
		if (isPublicHoliday(date, currFA)) {
			if (isWeekend(date, currFA)) {
				res = true;
			}
		}
		// WB.addLog2("DateTool.hasOverlayPublicHolidayAndWeekend, res=" + res + ",
		// date=" + date, "", "DateTool");
		return res;
	}

	private static boolean isTransferWeekend(LocalDate date, Face currFA) {// TODO --- currFA ???
		// detection transfer weekend weekend in current data
		// origin - 26.05.2024, last edit - 26.05.2024
		boolean res = false;
		LocalDate preDate1 = date.minusDays(1);
		LocalDate preDate2 = date.minusDays(2);
		LocalDate preDate3 = date.minusDays(3);

		// case1 - 1.workday finally; 2.transfer weekend; 3.workday previously = transfer,
		// weekend finally
		if (isWorkday1(preDate2, currFA)) {
			if (hasTransferWeekend(preDate1, currFA)) {
				if (isWorkday1(date, currFA)) { // then date finally = isTransferWeekend
					res = true;
				}
			}
		}

		// case2 - 1.weekend finally; 2.transfer weekend; 3.workday previously = transfer
		// weekend finally
		if (isWeekend(preDate2, currFA)) {
			if (hasTransferWeekend(preDate1, currFA)) {
				if (isWorkday1(date, currFA)) { // then date finally = isTransferWeekend
					res = true;
				}
			}
		}

		// case3 - 1.transfer weekend; 2.weekend finally; 3.workday previously = transfer
		// weekend finally
		if (hasTransferWeekend(preDate2, currFA)) {
			if (isWeekend(preDate1, currFA)) {
				if (isWorkday1(date, currFA)) { // then date finally = isTransferWeekend
					res = true;
				}
			}
		}
		
		// case4 - 1.transfer weekend; 2.transfer weekend; 3.weekend finally; 4.workday
		// previously = transfer
		// weekend finally
		if (hasTransferWeekend(preDate3, currFA)) {
			if (hasTransferWeekend(preDate2, currFA)) {
				if (isWorkday1(preDate1, currFA)) {
					if (isWorkday1(date, currFA)) { // then date finally = isTransferWeekend
						res = true;
					}
				}
			}
		}

		// WB.addLog2("DateTool.isTransferWeekend, res=" + res + ", date1=" + date, "",
		// "DateTool");
		return res;
	}

	private static boolean hasTransferWeekend(LocalDate date, Face currFA) {// TODO --- currFA ???
		// match detection public holiday and weekend in same data
		// origin - 20.02.2024, last edit - 26.02.2024
		boolean res = false;
		if (hasOverlayPublicHolidayOnWeekend(date, currFA)) {
			// TODO -- check what ahead has workday in this month
			res = true;
		}
		// WB.addLog2("DateTool.hasTransferWeekend, res=" + res + ", date1=" + date, "",
		// "DateTool");
		return res;
	}

//	private static boolean isMoreWorkdayMonthSpan(LocalDate date1, Face currFA) {// TODO --- currFA ???
//		// origin - 22.02.2024, last edit - 22.02.2024
//		boolean res = false;
//		LocalDate date2 = getEndMonth(date1);
//		if (date1.equals(date2) == false) {
//			for (LocalDate date = date1.plusDays(1); date.isBefore(date2.plusDays(1)); date = date.plusDays(1)) {
//				if (isWorkday(date, currFA)) {
//					res = true;
//				}
//			}
//		}
//		WB.addLog2("DateTool.isMoreWorkdayMonthSpan, res=" + res + ", date1=" + date1, "", "DateTool");
//		return res;
//	}

	private static boolean isWorkday2(LocalDate date1, Face currFA) {
		// origin - 26.05.2024, last edit - 26.02.2024
		// finally definiton workday
		boolean res = false;
		if (isTransferWeekend(date1, currFA) == false) {
			res = true;
		}
		// WB.addLog2("DateTool.isWorkday2, res=" + res + ", date1=" + date1, "",
		// "DateTool");
		return res;
	}

	private static boolean isWorkday1(LocalDate date1, Face currFA) {
		// origin - 22.02.2024, last edit - 27.02.2024
		// previously definiton workday
		boolean res = false;
		if (isWeekend(date1, currFA) == false) {
			if (isPublicHoliday(date1, currFA) == false) {
				if (isExtraDayOff(date1, currFA) == false) {
					res = true;
				}
			}
		}
		// WB.addLog2("DateTool.isWorkday1, res=" + res + ", date1=" + date1, "",
		// "DateTool");
		return res;
	}

//	private static boolean isMonthSpan(LocalDate date1, LocalDate date2) {
//		// origin - 19.02.2024, last edit - 22.02.2024
//		boolean res = false;
//		if (date1.equals(getStartMonth(date1))) {
//			if (date2.equals(getEndMonth(date1))) {
//				res = true;
//			}
//		}
//		// WB.addLog2("DateTool.isMonthSpan, res=" + res + ", date1=" + date1 + ",
//		// date2=" + date2, "", "DateTool");
//		return res;
//	}

	private static boolean isWeekend(LocalDate currDate, Face currFA) {// TODO --- currFA ???
		// origin - 17.02.2024, last edit - 22.02.2024
		// definition classic weekend - saturday + sunday
		boolean res = false;
		if (currDate.getDayOfWeek() == DayOfWeek.SATURDAY) {
			res = true;
		}
		if (currDate.getDayOfWeek() == DayOfWeek.SUNDAY) {
			res = true;
		}
		// WB.addLog2("DateTool.isWeekend, res=" + res + ", currDate1=" + currDate, "",
		// "DateTool");
		return res;
	}

	private static boolean isPublicHoliday(LocalDate currDate, Face currFA) {// TODO --- currFA ???
		// origin - 21.02.2024, last edit - 26.02.2024
		boolean res = false;
		LocalDate dateStartYear = getStartYear(currDate);
		for (var currPublicHoliday : WB.abcGlobal.publicHoliday) {

			if (Etc.strContains(currPublicHoliday.meter, "Meter.PublicHoliday")) {

				// skip not actual PublicHoliday
				if (currPublicHoliday.date2.isEmpty() == false) {
					if (getLocalDate(currPublicHoliday.date2).isBefore(dateStartYear)) {
						// WB.addLog2("DateTool.isPublicHoliday, skip not actual PublicHoliday=" +
						// currDayOff, "", "DateTool");
						continue;
					}
				}
				if (currPublicHoliday.meterValue.isEmpty()) {
					// WB.addLog("DateTool.isExtraDayOff, currDayOff.meterValue=" +
					// currDayOff.meterValue + ", currDate=" + currDate, "", "DateTool");
					continue;
				}
				if (Etc.strContains(currDate.toString(), currPublicHoliday.meterValue)) {
					res = true;
//					WB.addLog2("DateTool.PublicHoliday, res=" + res + ", currDayOff=" +
//					currDayOff + ", currDate1=" + currDate, "", "DateTool");
					break;
				}
			}
		}
		// WB.addLog2("DateTool.isPublicHoliday, res=" + res + ", currDate1=" +
		// currDate, "", "DateTool");
		return res;
	}

	private static boolean isExtraDayOff(LocalDate currDate, Face currFA) {// TODO --- currFA ???
		// origin - 18.02.2024, last edit - 26.02.2024
		boolean res = false;
		LocalDate dateStartYear = getStartYear(currDate);
		for (var currDayOff : WB.abcGlobal.extraDayOff) {

			if (Etc.strContains(currDayOff.meter, "Meter.ExtraDayOff")) {

				// skip not actual ExtraDayOff
				if (currDayOff.date2.isEmpty() == false) {
					if (getLocalDate(currDayOff.date2).isBefore(dateStartYear)) {
						// WB.addLog2("DateTool.isExtraDayOff, skip not actual isExtraDayOff=" +
						// currDayOff, "", "DateTool");
						continue;
					}
				}
				if (currDayOff.meterValue.isEmpty()) {
					// WB.addLog("DateTool.isExtraDayOff, currDayOff.meterValue=" +
					// currDayOff.meterValue + ", currDate=" + currDate, "", "DateTool");
					continue;
				}
				if (Etc.strContains(currDate.toString(), currDayOff.meterValue)) {
					res = true;
					// WB.addLog2("DateTool.isExtraDayOff, res=" + res + ", currDayOff=" +
					// currDayOff + ", currDate1=" + currDate, "", "DateTool");
					break;
				}
			}
		}
		// WB.addLog2("DateTool.isExtraDayOff, res=" + res + ", currDate1=" + currDate,
		// "", "DateTool");
		return res;
	}

	private static List<LocalDate> getListLocalDate(LocalDate dateStart, LocalDate dateEnd) {
		// origin - 25.05.2024, last edit - 25.05.2024
		List<LocalDate> res = new ArrayList<LocalDate>();
		for (; !dateStart.isAfter(dateEnd); dateStart = dateStart.plusDays(1)) {
			res.add(dateStart);
		}
		// WB.addLog2("DateTool.getListDayYear, res.size=" + res.size() + ", year=" +
		// date.getYear(), "", "DateTool");
		return res;
	}

	private static List<LocalDate> getListStartMonth(List<LocalDate> listDate) {
		// origin - 18.02.2024, last edit - 26.05.2024
		List<LocalDate> res = new ArrayList<LocalDate>();
		for (var testDate : listDate) {
			if (testDate.isEqual(getStartMonth(testDate))) {
				// WB.addLog2("DateTool.getListStartMonth, testDate=" +
				// testDate, "", "DateTool");
				res.add(testDate);
			}
		}
		// WB.addLog2("DateTool.getListStartMonth, res=" + res, "", "DateTool");
		return res;
	}

	public static LocalDate getLocalDate(String expectedDate) {// TODO
		// origin - 24.11.2023, last edit - 23.05.2024
		LocalDate res = null;
		expectedDate = Etc.fixTrim(expectedDate);
		expectedDate = expectedDate.replaceAll("--", "-");
		expectedDate = expectedDate.replaceAll("--", "-");
		try {
			res = LocalDate.parse(expectedDate);
			res = fixLocalDate(res);
		} catch (Exception ex) {
			res = null;
			// WB.addLog("DateTool.getLocalDate, ex=" + ex.getMessage(), "", "DateTool");
		} finally {
			if (res == null) {
				res = LocalDate.now();
			}
		}
		// WB.addLog("DateTool.getLocalDate, res=" + res + ", expectedDate=" +
		// expectedDate,"", "DateTool");
		return res;
	}

	public static LocalTime getLocalTime(String expectedDate) {// TODO
		// origin - 24.11.2023, last edit - 23.05.2024
		LocalTime res;
		expectedDate = Etc.fixTrim(expectedDate);
		try {
			res = LocalTime.parse(expectedDate);
		} catch (Exception ex) {
			res = null;
			// WB.addLog("DateTool.getLocalTime, ex=" + ex.getMessage(), "", "DateTool");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static LocalDate fixLocalDate(LocalDate fixDate) {
		// origin - 02.10.2023, last edit - 20.11.2023
		// LocalDate not must be big maxDateSupported and least minDateSupported
		LocalDate res = fixDate;
		if (fixDate.isBefore(WB.minDateSupported)) {
			res = WB.minDateSupported;
		}
		if (fixDate.isAfter(WB.maxDateSupported)) {
			res = WB.maxDateSupported;
		}
		return res;
	}

	@SuppressWarnings("unused")
	private static LocalDate getStartQuarter(LocalDate currDate) {
		// origin - 21.02.2024, last edit - 22.02.2024
		LocalDate res = getStartMonth(currDate);
		Month currMonth = currDate.getMonth();
		int currYear = currDate.getYear();

		if ((currMonth.equals(Month.JANUARY)) || (currMonth.equals(Month.FEBRUARY))
				|| (currMonth.equals(Month.MARCH))) {
			res = LocalDate.of(currYear, Month.JANUARY, 1);
		}

		if ((currMonth.equals(Month.APRIL)) || (currMonth.equals(Month.MAY)) || (currMonth.equals(Month.JUNE))) {
			res = LocalDate.of(currYear, Month.APRIL, 1);
		}

		if ((currMonth.equals(Month.JULY)) || (currMonth.equals(Month.AUGUST)) || (currMonth.equals(Month.SEPTEMBER))) {
			res = LocalDate.of(currYear, Month.JULY, 1);
		}

		if ((currMonth.equals(Month.OCTOBER)) || (currMonth.equals(Month.NOVEMBER))
				|| (currMonth.equals(Month.DECEMBER))) {
			res = LocalDate.of(currYear, Month.OCTOBER, 1);
		}

		// WB.addLog2("DateTool.getStartQuarter, res=" + res + ", currDate=" +
		// currDate, "", "DateTool");
		return res;
	}

	@SuppressWarnings("unused")
	private static LocalDate getEndQuarter(LocalDate currDate) {
		// origin - 21.02.2024, last edit - 22.02.2024
		LocalDate res = getEndMonth(currDate);
		Month currMonth = currDate.getMonth();
		int currYear = currDate.getYear();

		if ((currMonth.equals(Month.JANUARY)) || (currMonth.equals(Month.FEBRUARY))
				|| (currMonth.equals(Month.MARCH))) {
			res = LocalDate.of(currYear, Month.MARCH, 31);
		}

		if ((currMonth.equals(Month.APRIL)) || (currMonth.equals(Month.MAY)) || (currMonth.equals(Month.JUNE))) {
			res = LocalDate.of(currYear, Month.JUNE, 30);
		}

		if ((currMonth.equals(Month.JULY)) || (currMonth.equals(Month.AUGUST)) || (currMonth.equals(Month.SEPTEMBER))) {
			res = LocalDate.of(currYear, Month.SEPTEMBER, 30);
		}

		if ((currMonth.equals(Month.OCTOBER)) || (currMonth.equals(Month.NOVEMBER))
				|| (currMonth.equals(Month.DECEMBER))) {
			res = LocalDate.of(currYear, Month.DECEMBER, 31);
		}

		// WB.addLog2("DateTool.getEndQuarter, res=" + res + ", currDate=" +
		// currDate, "", "DateTool");
		return res;
	}

	private static LocalDate getStartYear(LocalDate currDate) {
		// origin - 22.01.2024, last edit - 18.02.2024
		LocalDate res = LocalDate.of(currDate.getYear(), 1, 1);
		// WB.addLog2("DateTool.getStartYear, res=" + res + ", currDate=" +
		// currDate, "", "DateTool");
		return res;
	}

	private static LocalDate getEndYear(LocalDate currDate) {
		// origin - 22.01.2024, last edit - 18.02.2024
		LocalDate res = LocalDate.of(currDate.getYear(), 12, 31);
		// WB.addLog2("DateTool.getEndYear, res=" + res + ", currDate=" + currDate,
		// "", "DateTool");
		return res;
	}

	private static LocalDate getStartMonth(LocalDate currDate) {
		// origin - 22.01.2024, last edit - 18.02.2024
		LocalDate res = YearMonth.of(currDate.getYear(), currDate.getMonth()).atDay(1);
		// WB.addLog2("DateTool.getStartMonth, res=" + res + ", currDate=" +
		// currDate, "", "DateTool");
		return res;
	}

	private static LocalDate getEndMonth(LocalDate currDate) {
		// origin - 22.01.2024, last edit - 18.02.2024
		LocalDate res = YearMonth.of(currDate.getYear(), currDate.getMonth()).atEndOfMonth();
		// WB.addLog2("DateTool.getEndMonth, res=" + res + ", currDate=" + currDate,
		// "", "DateTool");
		return res;
	}

	@SuppressWarnings("unused")
	private static LocalDate getStartWeek(LocalDate currDate) {
		// origin - 26.05.2024, last edit - 26.05.2024
		LocalDate res = currDate.with(DayOfWeek.MONDAY);
		// WB.addLog2("DateTool.getStartWeek, res=" + res + ", currDate=" +
		// currDate, "", "DateTool");
		return res;
	}

	@SuppressWarnings("unused")
	private static LocalDate getEndWeek(LocalDate currDate) {
		// origin - 26.05.2024, last edit - 26.05.2024
		LocalDate res = currDate.with(DayOfWeek.SUNDAY);
		// WB.addLog2("DateTool.getEndWeek, res=" + res + ", currDate=" + currDate,
		// "", "DateTool");
		return res;
	}

	public static String getLabelDateTimeForFileName() {
		// origin - 27.12.2023, last edit - 21.05.2024
		String res = Etc.fixTrim(formatter(getLocalDateTimeNow()));
		res = res.replaceAll("-", "_");
		res = res.replaceAll(":", "_");
		res = res + "_";
		return res;
	}

	public static LocalDateTime getLocalDateTimeNow() {
		// origin - 18.12.2023, last edit - 18.12.2023
		return LocalDateTime.now(ZoneOffset.systemDefault().getRules().getOffset(Instant.now()));
	}

	public static int getDuration(LocalDateTime date1, LocalDateTime date2) {
		// origin - 21.05.2024, last edit - 21.05.2024
		return Math.abs((int) Etc.roundCustom(Duration.between(date2, date1).toMillis(), Etc.round0));
	}

	public static int getDuration(OffsetDateTime date1, OffsetDateTime date2) {
		// origin - 21.10.2023, last edit - 18.01.2024
		return Math.abs((int) Etc.roundCustom(Duration.between(date2, date1).toMillis(), Etc.round0));
	}

	public static String formatter2(LocalDateTime formatterLocalDateTime) {
		// origin - 21.05.2024, last edit - 21.05.2024
		String res = "";
		res = formatterLocalDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss")).toString();
		return res;
	}

	public static String formatter(LocalDateTime formatterLocalDateTime) {
		// origin - 21.05.2024, last edit - 21.05.2024
		String res = "";
		res = formatterLocalDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSS")).toString();
		return res;
	}

	@SuppressWarnings("unused")
	public static void test() throws Exception {
		// origin - 17.01.2024, last edit - 27.05.2024
		var testDateTime1 = new String[] { "2023-11-24T06:46:16.907+06:00", "2023-11-08 02:15:09", "06:46:16.907+06:00",
				"2019-01-01", "test1", "12.45", "12:45", "12:45:38", "12:45:57.678", null };

//		var testDate1 = new String[] { "2023-01-01T06:46:16.907+06:00", "2023-11-08 02:15:09", "06:46:16.907+06:00",
//				"2019-01-01", "test1", "12.45", "12:45", "12:45:38", "12:45:57.678", null };

		var testLocalDate = new LocalDate[] { LocalDate.now().minusMonths(1), LocalDate.now(),
				LocalDate.of(2024, Month.JANUARY, 1), LocalDate.of(2024, Month.APRIL, 18) };

		LocalDate dateNow = LocalDate.now();
		LocalDate dateEndCurrYear = getEndYear(dateNow);
		LocalDate dateStartLastYear = getStartYear(getStartYear(dateNow).minusDays(1));
		LocalDate dateStartPostLastYear = getStartYear(dateStartLastYear.minusDays(1));
		List<LocalDate> listDayManyYear = getListLocalDate(dateStartPostLastYear, dateEndCurrYear);
		List<LocalDate> listStartMonth = getListStartMonth(listDayManyYear);

		// getWorkdayCount
		for (var testDate : listStartMonth) {
			WB.addLog2("DateTool.test.getWorkdayCount, res=" + getWorkdayCount(testDate, getEndMonth(testDate), null)
					+ ", month=" + testDate.getMonth() + ", year=" + testDate.getYear(), "", "DateTool");
		}
		
		// isWorkdayFinally detailed (if has trouble in getWorkdayCount)
		List<LocalDate> listDayDetailed = getListLocalDate(LocalDate.of(2022, Month.MAY, 1),
				LocalDate.of(2022, Month.MAY, 31));// may 2022
		for (var testDate : listDayDetailed) {
			WB.addLog2("DateTool.test.isWorkdayFinally, res=" + isWorkdayFinally(testDate, null) + ", testDate="
					+ testDate + ", isPublicHoliday()=" + isPublicHoliday(testDate, null) + ", isExtraDayOff()="
					+ isExtraDayOff(testDate, null) + ", isTransferWeekend()=" + isTransferWeekend(testDate, null), "",
					"DateTool");
		}
		
//		// isTransferWeekend
//		for (var testDate : listDayManyYear) {
//			if (isTransferWeekend(testDate, null)) {
//				WB.addLog2("DateTool.test.isTransferWeekend, res=" + isTransferWeekend(testDate, null) + ", date1="
//						+ testDate, "", "DateTool");
//			}
//		}

//		// isWeekend
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("DateTool.test.isWeekend, res=" + isWeekend(testArg1, null) + ", testArg1=" + testArg1 + ", (" + testArg1.getDayOfWeek() + ")", "", "DateTool");
//		}

//		// getListStartMonthYear
//		WB.addLog2("DateTool.test.getListStartMonthYear, res=" + getListStartMonthYear(LocalDate.now()), "", "DateTool");

//		// getOffsetDateTime
//		for (var testArg1 : testDateTime1) {
//			WB.addLog2("DateTool.test.getOffsetDateTime, res=" + getOffsetDateTime(testArg1) + ", testArg1=" + testArg1,
//					"", "DateTool");
//		}

//		// getLocalDate
//		for (var testArg1 : testDateTime1) {
//			WB.addLog2("DateTool.test.getLocalDate, res=" + getLocalDate(testArg1) + ", testArg1=" + testArg1, "",
//					"DateTool");
//		}

//		// getLocalTime
//		for (var testArg1 : testDateTime1) {
//			WB.addLog2("DateTool.test.getLocalTime, res=" + getLocalTime(testArg1) + ", testArg1=" + testArg1, "",
//					"DateTool");
//		}

//		// fixLocalDate
//		for (LocalDate testArg1 : new LocalDate[] { LocalDate.of(2026, Month.APRIL, 28),
//				LocalDate.of(1967, Month.NOVEMBER, 25), LocalDate.of(2100, Month.MAY, 26) }) {
//			WB.addLog2("DateTool.test.fixLocalDate, res=" + fixLocalDate(testArg1) + ", testArg1=" + testArg1, "",
//					"DateTool");
//		}

//		// getStartYear
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("DateTool.test.getStartYear, res=" + getStartYear(testArg1) + ", testArg1=" + testArg1, "",
//					"DateTool");
//		}

//		// getEndYear
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("DateTool.test.getEndYear, res=" + getEndYear(testArg1) + ", testArg1=" + testArg1, "",
//					"DateTool");
//		}

//		// getStartMonth
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("DateTool.test.getStartMonth, res=" + getStartMonth(testArg1) + ", testArg1=" + testArg1, "",
//					"DateTool");
//		}

//		// getEndMonth
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("DateTool.test.getEndMonth, res=" + getEndMonth(testArg1) + ", testArg1=" + testArg1, "",
//					"DateTool");
//		}

//		// getStartQuarter
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("DateTool.test.getStartQuarter, res=" + getStartQuarter(testArg1) + ", testArg1=" + testArg1, "",
//					"DateTool");
//		}

//		// getEndQuarter
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("DateTool.test.getEndQuarter, res=" + getEndQuarter(testArg1) + ", testArg1=" + testArg1, "",
//					"DateTool");
//		}

//		// getStartWeek
//		for (var testDate : testLocalDate) {
//			WB.addLog2("DateTool.test.getStartWeek, res=" + getStartWeek(testDate) + ", date1=" + testDate, "",
//					"DateTool");
//		}

//		// getEndWeek
//		for (var testDate : testLocalDate) {
//			WB.addLog2("DateTool.test.getEndWeek, res=" + getEndWeek(testDate) + ", date1=" + testDate, "",
//					"DateTool");
//		}

//		// hasTransferWeekend
//		for (var testDate : listDay3Year) {
//			if (hasTransferWeekend(testDate, null)) {
//				WB.addLog2("DateTool.test.hasTransferWeekend, res=" + hasTransferWeekend(testDate, null) + ", date1="
//						+ testDate, "", "DateTool");
//			}
//		}

//		// isWorkday1
//		for (var date1 : listDay3Year) {
//			if (isWorkday1(date1, null) == false) { // show only not workday for shorter
//				WB.addLog2("DateTool.test.isWorkday1, res=" + isWorkday1(date1, null) + ", date1=" + date1 + ", ("
//						+ date1.getDayOfWeek() + ")", "", "DateTool");
//			}
//		}

//		// isWorkday2
//		for (var date1 : listDay3Year) {
//			if (isWorkday2(date1, null) == false) { // show only not workday for shorter
//				WB.addLog2("DateTool.test.isWorkday2, res=" + isWorkday2(date1, null) + ", date1=" + date1 + ", ("
//						+ date1.getDayOfWeek() + ")", "", "DateTool");
//			}
//		}

//		// isExtraDayOff
//		for (var testDate : listDay3Year) {
//			if (isExtraDayOff(testDate, null)) {
//				WB.addLog2(
//						"DateTool.test.isExtraDayOff, res=" + isExtraDayOff(testDate, null) + ", date1=" + testDate,
//						"", "DateTool");
//			}
//		}

//		// isPublicHoliday
//		for (var testDate : listDay3Year) {
//			if (isPublicHoliday(testDate, null)) {
//				WB.addLog2("DateTool.test.isPublicHoliday, res=" + isPublicHoliday(testDate, null) + ", date1=" + testDate, "", "DateTool");
//			}
//		}
	}
}
