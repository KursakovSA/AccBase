import java.time.DayOfWeek;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.OffsetDateTime;
import java.time.Period;
import java.time.YearMonth;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class DateTool {
	// origin - 17.01.2024, last edit - 04.08.2024
	private static String defaultPredCentury = "19";
	private static String defaultCurrCentury = "20"; // ??? get this string for WB.maxDateSupported ??? or currDate ??
	private static int fullLenghtYear = 4;
	private static int shortLenghtYear = 2;
	public static int maxAgePerson = 120;
	public static int minAgePersonGettingPawnLoan = 18; // sectoral pawnshop
	public static String contextGettingPawnLoan = "Pawnshop.GettingPawnLoan"; // sectoral pawnshop

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("DateTool.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
	}

	@SuppressWarnings("unused")
	private static Boolean isValidDateBirth(LocalDate initDateBirth, String context) throws Exception {// TOTHINK
		// origin - 22.06.2024, last edit - 15.07.2024
		Boolean res = true;
		try {
			LocalDate dateNow = DateTool.getNow();

			if (initDateBirth.isAfter(dateNow)) {
				res = false;
			}

			if (DateTool.getAgeByDateBirth(initDateBirth) > DateTool.maxAgePerson) {
				res = false;
			}

			if (Etc.strEquals(context, DateTool.contextGettingPawnLoan)) {
				if (DateTool.getAgeByDateBirth(initDateBirth) < DateTool.minAgePersonGettingPawnLoan) {
					res = false;
				}
			}
		} catch (Exception ex) {
			WB.addLog("DateTool.isValidDateBirth, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2(
//				"DateTool.isValidDateBirth, res=" + res + ", initDateBirth=" + initDateBirth + ", context=" + context,
//				WB.strEmpty, "DateTool");
		return res;
	}

	private static int getAgeByDateBirth(LocalDate initDateBirth) throws Exception {
		// origin - 22.06.2024, last edit - 03.07.2024
		int res = 0;
		try {
			LocalDate dateNow = DateTool.getNow();
			Period period = initDateBirth.until(dateNow);
			res = period.getYears();
		} catch (Exception ex) {
			WB.addLog("DateTool.getAgeByDateBirth, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DateTool.getAgeByDateBirth, res=" + res + ", initDateBirth=" +
		// initDateBirth, WB.strEmpty, "DateTool");
		return res;
	}

	public static LocalDate getNow() throws Exception {
		// origin - 22.06.2024, last edit - 03.07.2024
		LocalDate res = null;
		try {
			res = LocalDate.now();
		} catch (Exception ex) {
			WB.addLog("DateTool.getNow, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DateTool.getNow(LocalDate), res=" + res, WB.strEmpty,
		// "DateTool");
		return res;
	}

	public static LocalDateTime getNow2() throws Exception {
		// origin - 18.12.2023, last edit - 03.07.2024
		LocalDateTime res = null;
		try {
			res = LocalDateTime.now(ZoneOffset.systemDefault().getRules().getOffset(Instant.now()));
		} catch (Exception ex) {
			WB.addLog("DateTool.getNow2, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DateTool.getNow2(LocalDateTime), res=" + res, WB.strEmpty,
		// "DateTool");
		return res;
	}

	public static LocalTime getNow3() throws Exception {
		// origin - 28.06.2024, last edit - 03.07.2024
		LocalTime res = null;
		try {
			res = LocalTime.now(ZoneOffset.systemDefault().getRules().getOffset(Instant.now()));
		} catch (Exception ex) {
			WB.addLog("DateTool.getNow2, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DateTool.getNow3(LocalTime), res=" + res, WB.strEmpty,
		// "DateTool");
		return res;
	}

	private static String getDefaultCentury(String initCentury) throws Exception {
		// origin - 22.06.2024, last edit - 03.07.2024
		String res = Etc.fixTrim(initCentury);
		try {
			if (Etc.strEquals(res, defaultPredCentury) == false) {
				if (Etc.strEquals(res, defaultCurrCentury) == false) {
					res = DateTool.defaultCurrCentury;
				}
			}
		} catch (Exception ex) {
			WB.addLog("DateTool.getDefaultCentury, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DateTool.getDefaultCentury, res=" + res + ", initCentury=" +
		// initCentury, WB.strEmpty, "DateTool");
		return res;
	}

	private static String fixCentury(String initCentury) throws Exception {
		// origin - 21.06.2024, last edit - 15.07.2024
		String res = Etc.fixTrim(initCentury);
		try {
			res = DateTool.getDefaultCentury(res);
		} catch (Exception ex) {
			WB.addLog("DateTool.fixCentury, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DateTool.fixCentury, res=" + res + ", initCentury=" +
		// initCentury, WB.strEmpty, "DateTool");
		return res;
	}

	public static String getDay(LocalDate initDate) throws Exception {
		// origin - 21.06.2024, last edit - 03.07.2024
		String res = WB.strEmpty;
		try {
			res = String.valueOf(initDate.getDayOfMonth());
			res = "00" + res; // ???magic string ???
			res = res.substring(res.length() - 2); // ??? magic number ???
		} catch (Exception ex) {
			WB.addLog("DateTool.getDay, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DateTool.getDay(LocalDate), res=" + res + ", initDate=" +
		// initDate, WB.strEmpty, "DateTool");
		return res;
	}

	public static String getDay(String initKZIIN) throws Exception {
		// origin - 21.06.2024, last edit - 03.07.2024
		String res = WB.strEmpty;
		initKZIIN = Etc.fixTrim(initKZIIN);
		try {
			if (initKZIIN.length() == Info.argLenghtIIN) {
				res = initKZIIN.substring(4, 6);// ??? magic number ???
			} else {
				res = WB.strEmpty;
			}
		} catch (Exception ex) {
			WB.addLog("DateTool.getDay, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("DateTool.getDay, res=" + res + ", initKZIIN=" +
//		initKZIIN, WB.strEmpty, "DateTool");
		return res;
	}

	public static String getMonth(LocalDate initDate) throws Exception {
		// origin - 21.06.2024, last edit - 03.07.2024
		String res = WB.strEmpty;
		try {
			res = String.valueOf(initDate.getMonthValue());
			res = "00" + res; // ???magic string ???
			res = res.substring(res.length() - 2);// ??? magic number ???
		} catch (Exception ex) {
			WB.addLog("DateTool.getMonth, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DateTool.getMonth(LocalDate), res=" + res + ", initDate=" +
		// initDate, WB.strEmpty, "DateTool");
		return res;
	}

	public static String getMonth(String initKZIIN) throws Exception {
		// origin - 21.06.2024, last edit - 03.07.2024
		String res = WB.strEmpty;
		initKZIIN = Etc.fixTrim(initKZIIN);
		try {
			if (initKZIIN.length() == Info.argLenghtIIN) {
				res = initKZIIN.substring(2, 4);// ??? magic number ???
			} else {
				res = WB.strEmpty;
			}
		} catch (Exception ex) {
			WB.addLog("DateTool.getMonth, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("DateTool.getMonth, res=" + res + ", initKZIIN=" +
//		initKZIIN, WB.strEmpty, "DateTool");
		return res;
	}

	public static String getValidCentury(String initCentury, String initYear) throws Exception {
		// origin - 20.06.2024, last edit - 15.07.2024
		String res = WB.strEmpty;
		try {
			initCentury = Etc.fixTrim(initCentury);

			String yearCurrDate = DateTool.getYear(String.valueOf(DateTool.getNow().getYear()));
			// WB.addLog2("DateTool.getValidCentury, yearCurrDate=" +
			// yearCurrDate, WB.strEmpty, "DateTool");
			// WB.addLog2("DateTool.getValidCentury, initCentury=" +
			// initCentury, WB.strEmpty, "DateTool");
			int numberYearCurrDate = Integer.parseInt(yearCurrDate);// ex. for 20-06-2024 this is = 24
			int numberInitYear = Integer.parseInt(initYear);// ex. for 25-11-1967 this is = 67
			if (numberYearCurrDate < numberInitYear) {// ex. 24 < 67
				res = DateTool.defaultPredCentury;
			}

			res = fixCentury(res);
		} catch (Exception ex) {
			WB.addLog("DateTool.getValidCentury, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("DateTool.getValidCentury, res=" + res + ", initCentury=" + initCentury
//				+ ", initYear=" + initYear, WB.strEmpty, "DateTool");
		return res;
	}

	public static String getYear(LocalDate initDate) throws Exception {
		// origin - 21.06.2024, last edit - 15.07.2024
		String res = WB.strEmpty;
		try {
			res = DateTool.getYear(String.valueOf(initDate.getYear()));
		} catch (Exception ex) {
			WB.addLog("DateTool.getYear, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("DateTool.getYear(LocalDate), res=" + res + ", initDate=" +
//		initDate, WB.strEmpty, "DateTool");
		return res;
	}

	public static String getYear(String initYear) throws Exception {
		// origin - 20.06.2024, last edit - 03.07.2024
		String res = WB.strEmpty;
		try {
			initYear = Etc.fixTrim(initYear);

			if (initYear.length() == DateTool.shortLenghtYear) {
				res = initYear; // if initYear = 2 simbols, ex. "24"
			}

			if (initYear.length() == DateTool.fullLenghtYear) {
				res = initYear.substring(2, 4);// ??? magic number ???
			}

			if (initYear.length() == Info.argLenghtIIN) {
				res = initYear.substring(0, 2);// ??? magic number ???
			}
		} catch (Exception ex) {
			WB.addLog("DateTool.getYear, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("DateTool.getYear, res=" + res + ", initYear=" +
//		initYear, WB.strEmpty, "DateTool");
		return res;
	}

	public static String getCentury(LocalDate initDate) throws Exception {
		// origin - 21.06.2024, last edit - 15.07.2024
		String res = WB.strEmpty;
		try {
			res = DateTool.getCentury(getYear(initDate));
		} catch (Exception ex) {
			WB.addLog("DateTool.getCentury, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DateTool.getCentury(LocalDate), res=" + res + ", initDate=" +
		// initDate, WB.strEmpty, "DateTool");
		return res;
	}

	public static String getCentury(String initYear) throws Exception {
		// origin - 20.06.2024, last edit - 15.07.2024
		String res = WB.strEmpty;
		try {
			initYear = Etc.fixTrim(initYear);

			if (initYear.length() == DateTool.fullLenghtYear) {
				res = initYear.substring(0, 2);// ??? magic number ???
			} else {
				res = DateTool.fixCentury(WB.strEmpty);
			}
		} catch (Exception ex) {
			WB.addLog("DateTool.getCentury, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DateTool.getCentury, res=" + res + ", initYear=" +
		// initYear, WB.strEmpty, "DateTool");
		return res;
	}

	public static String getDateBirthFromKZIIN(String initKZIIN, String context) throws Exception {// sectoral pawnshop
		// origin - 19.06.2024, last edit - 15.07.2024
		String res = WB.strEmpty;
		initKZIIN = Etc.fixTrim(initKZIIN);
		try {
			// int lenghtIIN = ModelDto.getLenghtField(Info.argNumeric, Info.argCodeIIN);
			// WB.addLog2("DateTool.getDateBirthFromKZIIN, lenghtIIN=" + lenghtIIN,
			// WB.strEmpty,
			// "DateTool");
			if (initKZIIN.length() != Info.argLenghtIIN) {
				return res;
			}

			if (Etc.isDigitAll(initKZIIN) == false) {
				return res;
			}

			String day = DateTool.getDay(initKZIIN);
			String month = DateTool.getMonth(initKZIIN);
			String year2 = DateTool.getYear(initKZIIN);
			String century = DateTool.getValidCentury(DateTool.getCentury(year2), year2);
			res = DateTool.formatter4(day, month, century, year2);

//			LocalDate resDateBirth = DateTool.getLocalDate(DateTool.formatter3(day, month, century, year2));
//			WB.addLog2("DateTool.isValidDateBirth, res=" + DateTool.isValidDateBirth(resDateBirth, context)
//					+ ", resDateBirth=" + resDateBirth, WB.strEmpty, "DateTool");
//			WB.addLog2("DateTool.getAgeByDateBirth, res=" + DateTool.getAgeByDateBirth(resDateBirth) + ", resDateBirth="
//					+ resDateBirth, WB.strEmpty, "DateTool");

		} catch (Exception ex) {
			WB.addLog2("DateTool.getDateBirthFromKZIIN, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}

		// WB.addLog2("DateTool.getDateBirthFromKZIIN, res=" + res + ", initKZIIN=" +
		// initKZIIN, WB.strEmpty, "DateTool");
		return res;
	}

	public static List<LocalDate> getListLocalDate(LocalDate dateStart, LocalDate dateEnd) throws Exception {
		// origin - 25.05.2024, last edit - 03.07.2024
		List<LocalDate> res = new ArrayList<LocalDate>();
		try {
			for (; !dateStart.isAfter(dateEnd); dateStart = dateStart.plusDays(1)) {
				res.add(dateStart);
			}
		} catch (Exception ex) {
			WB.addLog2("DateTool.getListLocalDate, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DateTool.getListDayYear, res.size=" + res.size() + ", year=" +
		// date.getYear(), WB.strEmpty, "DateTool");
		return res;
	}

	public static List<LocalDate> getListStartMonth(List<LocalDate> listDate) throws Exception {
		// origin - 18.02.2024, last edit - 15.07.2024
		List<LocalDate> res = new ArrayList<LocalDate>();
		try {
			for (var testDate : listDate) {
				if (testDate.isEqual(DateTool.getStartMonth(testDate))) {
					// WB.addLog2("DateTool.getListStartMonth, testDate=" +
					// testDate, WB.strEmpty, "DateTool");
					res.add(testDate);
				}
			}
		} catch (Exception ex) {
			WB.addLog2("DateTool.getListStartMonth, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DateTool.getListStartMonth, res=" + res, WB.strEmpty,
		// "DateTool");
		return res;
	}

	public static LocalDate getLocalDate(String expectedDate) throws Exception {// TODO
		// origin - 24.11.2023, last edit - 15.07.2024
		LocalDate res = null;
		expectedDate = Etc.fixTrim(expectedDate);
		expectedDate = expectedDate.replaceAll("--", "-");
		expectedDate = expectedDate.replaceAll("--", "-");

		if (expectedDate.isEmpty()) {
			res = DateTool.getNow();
			// WB.addLog2("DateTool.getLocalDate, res=" + res + ", expectedDate=" +
			// expectedDate, WB.strEmpty, "DateTool");
			return res;
		}

		try {
			res = LocalDate.parse(expectedDate);
			res = DateTool.fixLocalDate(res);
		} catch (Exception ex) {
			// res = null;
			WB.addLog("DateTool.getLocalDate, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
//			if (res == null) {
//				res = DateTool.getNow();
//			}
		}
		// WB.addLog2("DateTool.getLocalDate, res=" + res + ", expectedDate=" +
		// expectedDate, WB.strEmpty, "DateTool");
		return res;
	}

	public static LocalTime getLocalTime(String expectedDate) throws Exception {// TODO
		// origin - 24.11.2023, last edit - 27.06.2024
		LocalTime res;
		expectedDate = Etc.fixTrim(expectedDate);
		try {
			res = LocalTime.parse(expectedDate);
		} catch (Exception ex) {
			res = null;
			WB.addLog("DateTool.getLocalTime, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DateTool.getLocalTime, res=" + res + ", expectedDate=" +
		// expectedDate, WB.strEmpty, "DateTool");
		return res;
	}

	public static LocalDate fixLocalDate(LocalDate fixDate) throws Exception {
		// origin - 02.10.2023, last edit - 03.07.2024
		// LocalDate not must be big maxDateSupported and least minDateSupported
		LocalDate res = fixDate;
		try {
			if (fixDate.isBefore(WB.minDateSupported)) {
				res = WB.minDateSupported;
			}
			if (fixDate.isAfter(WB.maxDateSupported)) {
				res = WB.maxDateSupported;
			}
		} catch (Exception ex) {
			res = null;
			WB.addLog("DateTool.fixLocalTime, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DateTool.fixLocalDate, res=" + res + ", fixDate=" + fixDate,
		// WB.strEmpty,
		// "DateTool");
		return res;
	}

	@SuppressWarnings("unused")
	private static LocalDate getStartQuarter(LocalDate currDate) throws Exception {
		// origin - 21.02.2024, last edit - 15.07.2024
		LocalDate res = DateTool.getStartMonth(currDate);
		try {
			Month currMonth = currDate.getMonth();
			int currYear = currDate.getYear();

			if ((currMonth.equals(Month.JANUARY)) || (currMonth.equals(Month.FEBRUARY))
					|| (currMonth.equals(Month.MARCH))) {
				res = LocalDate.of(currYear, Month.JANUARY, 1);
			}

			if ((currMonth.equals(Month.APRIL)) || (currMonth.equals(Month.MAY)) || (currMonth.equals(Month.JUNE))) {
				res = LocalDate.of(currYear, Month.APRIL, 1);
			}

			if ((currMonth.equals(Month.JULY)) || (currMonth.equals(Month.AUGUST))
					|| (currMonth.equals(Month.SEPTEMBER))) {
				res = LocalDate.of(currYear, Month.JULY, 1);
			}

			if ((currMonth.equals(Month.OCTOBER)) || (currMonth.equals(Month.NOVEMBER))
					|| (currMonth.equals(Month.DECEMBER))) {
				res = LocalDate.of(currYear, Month.OCTOBER, 1);
			}
		} catch (Exception ex) {
			res = null;
			WB.addLog("DateTool.getStartQuarter, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DateTool.getStartQuarter, res=" + res + ", currDate=" +
		// currDate, WB.strEmpty, "DateTool");
		return res;
	}

	@SuppressWarnings("unused")
	private static LocalDate getEndQuarter(LocalDate currDate) throws Exception {
		// origin - 21.02.2024, last edit - 15.07.2024
		LocalDate res = DateTool.getEndMonth(currDate);
		try {
			Month currMonth = currDate.getMonth();
			int currYear = currDate.getYear();

			if ((currMonth.equals(Month.JANUARY)) || (currMonth.equals(Month.FEBRUARY))
					|| (currMonth.equals(Month.MARCH))) {
				res = LocalDate.of(currYear, Month.MARCH, 31);
			}

			if ((currMonth.equals(Month.APRIL)) || (currMonth.equals(Month.MAY)) || (currMonth.equals(Month.JUNE))) {
				res = LocalDate.of(currYear, Month.JUNE, 30);
			}

			if ((currMonth.equals(Month.JULY)) || (currMonth.equals(Month.AUGUST))
					|| (currMonth.equals(Month.SEPTEMBER))) {
				res = LocalDate.of(currYear, Month.SEPTEMBER, 30);
			}

			if ((currMonth.equals(Month.OCTOBER)) || (currMonth.equals(Month.NOVEMBER))
					|| (currMonth.equals(Month.DECEMBER))) {
				res = LocalDate.of(currYear, Month.DECEMBER, 31);
			}
		} catch (Exception ex) {
			res = null;
			WB.addLog("DateTool.getEndQuarter, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DateTool.getEndQuarter, res=" + res + ", currDate=" +
		// currDate, WB.strEmpty, "DateTool");
		return res;
	}

	public static LocalDate getStartYear(LocalDate currDate) throws Exception {
		// origin - 22.01.2024, last edit - 03.07.2024
		LocalDate res = null;
		try {
			res = LocalDate.of(currDate.getYear(), 1, 1);
		} catch (Exception ex) {
			res = null;
			WB.addLog("DateTool.getStartYear, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DateTool.getStartYear, res=" + res + ", currDate=" +
		// currDate, WB.strEmpty, "DateTool");
		return res;
	}

	public static LocalDate getStartSecondHalfYear(LocalDate currDate) throws Exception {
		// origin - 26.01.2024, last edit - 26.07.2024
		LocalDate res = null;
		try {
			res = LocalDate.of(currDate.getYear(), 7, 1);
		} catch (Exception ex) {
			res = null;
			WB.addLog("DateTool.getStartFirstHalfYear, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DateTool.getStartFirstHalfYear, res=" + res + ", currDate=" +
		// currDate, WB.strEmpty, "DateTool");
		return res;
	}

	public static LocalDate getEndFirstHalfYear(LocalDate currDate) throws Exception {
		// origin - 26.01.2024, last edit - 26.07.2024
		LocalDate res = null;
		try {
			res = LocalDate.of(currDate.getYear(), 6, 30);
		} catch (Exception ex) {
			res = null;
			WB.addLog("DateTool.getEndFirstHalfYear, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DateTool.getEndFirstHalfYear, res=" + res + ", currDate=" +
		// currDate, WB.strEmpty, "DateTool");
		return res;
	}

	public static LocalDate getStartHalfYear(LocalDate currDate) throws Exception {
		// origin - 26.07.2024, last edit - 26.07.2024
		LocalDate res = null;
		try {
			if (currDate.isBefore(DateTool.getEndFirstHalfYear(currDate))) {
				res = DateTool.getStartYear(currDate);
			}
			if (currDate.isAfter(DateTool.getEndFirstHalfYear(currDate))) {
				res = DateTool.getStartSecondHalfYear(currDate);
			}
		} catch (Exception ex) {
			res = null;
			WB.addLog("DateTool.getstartHalfYear, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DateTool.getStartHalfYear, res=" + res + ", currDate=" +
		// currDate,
		// WB.strEmpty, "DateTool");
		return res;
	}

	public static LocalDate getEndHalfYear(LocalDate currDate) throws Exception {
		// origin - 26.07.2024, last edit - 26.07.2024
		LocalDate res = null;
		try {
			if (currDate.isBefore(DateTool.getEndFirstHalfYear(currDate))) {
				res = DateTool.getEndFirstHalfYear(currDate);
			}
			if (currDate.isAfter(DateTool.getEndFirstHalfYear(currDate))) {
				res = DateTool.getEndYear(currDate);
			}
		} catch (Exception ex) {
			res = null;
			WB.addLog("DateTool.getEndHalfYear, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DateTool.getEndHalfYear, res=" + res + ", currDate=" + currDate,
		// WB.strEmpty, "DateTool");
		return res;
	}

	public static LocalDate getEndYear(LocalDate currDate) throws Exception {
		// origin - 22.01.2024, last edit - 03.07.2024
		LocalDate res = null;
		try {
			res = LocalDate.of(currDate.getYear(), 12, 31);
		} catch (Exception ex) {
			res = null;
			WB.addLog("DateTool.getEndYear, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DateTool.getEndYear, res=" + res + ", currDate=" + currDate,
		// WB.strEmpty, "DateTool");
		return res;
	}

	private static LocalDate getStartMonth(LocalDate currDate) throws Exception {
		// origin - 22.01.2024, last edit - 03.07.2024
		LocalDate res = null;
		try {
			res = YearMonth.of(currDate.getYear(), currDate.getMonth()).atDay(1);
		} catch (Exception ex) {
			res = null;
			WB.addLog("DateTool.getStartMonth, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DateTool.getStartMonth, res=" + res + ", currDate=" +
		// currDate, WB.strEmpty, "DateTool");
		return res;
	}

	public static LocalDate getEndMonth(LocalDate currDate) throws Exception {
		// origin - 22.01.2024, last edit - 03.07.2024
		LocalDate res = null;
		try {
			res = YearMonth.of(currDate.getYear(), currDate.getMonth()).atEndOfMonth();
		} catch (Exception ex) {
			res = null;
			WB.addLog("DateTool.getEndMonth, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DateTool.getEndMonth, res=" + res + ", currDate=" + currDate,
		// WB.strEmpty, "DateTool");
		return res;
	}

	@SuppressWarnings("unused")
	private static LocalDate getStartWeek(LocalDate currDate) throws Exception {
		// origin - 26.05.2024, last edit - 03.07.2024
		LocalDate res = null;
		try {
			res = currDate.with(DayOfWeek.MONDAY);
		} catch (Exception ex) {
			WB.addLog("DateTool.getStartWeek, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DateTool.getStartWeek, res=" + res + ", currDate=" +
		// currDate, WB.strEmpty, "DateTool");
		return res;
	}

	@SuppressWarnings("unused")
	private static LocalDate getEndWeek(LocalDate currDate) throws Exception {
		// origin - 26.05.2024, last edit - 03.07.2024
		LocalDate res = null;
		try {
			res = currDate.with(DayOfWeek.SUNDAY);
		} catch (Exception ex) {
			WB.addLog("DateTool.getEndWeek, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DateTool.getEndWeek, res=" + res + ", currDate=" + currDate,
		// WB.strEmpty, "DateTool");
		return res;
	}

	public static String getLabelDateTimeForFileName() throws Exception {
		// origin - 27.12.2023, last edit - 03.07.2024
		String res = Etc.fixTrim(formatter(getNow2()));
		try {
			res = res.replaceAll("-", "_");
			res = res.replaceAll(":", "_");
			res = res + "_";
		} catch (Exception ex) {
			WB.addLog("DateTool.getLabelDateTimeForFileName, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static LocalDate getEndDateFromDuration(LocalDate date1, int duration) throws Exception {
		// origin - 10.09.2024, last edit - 11.09.2024
		LocalDate res = date1;
		try {
			// res = (int)java.time.temporal.ChronoUnit.DAYS.between(date1, date2);
			// res = ChronoUnit.DAYS.between(date1.plusDays(duration), date1);
			res = date1.plusDays(duration);
		} catch (Exception ex) {
			WB.addLog("DateTool.getEndDateFromDuration(LocalDate, int), ex=" + ex.getMessage(), WB.strEmpty,
					"DateTool");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static int getDuration(LocalDateTime date1, LocalDateTime date2) throws Exception {// in ms
		// origin - 21.05.2024, last edit - 18.09.2024
		int res = 0;
		try {
			res = Math.abs((int) Etc.roundCustom(Duration.between(date2, date1).toMillis(), Etc.round0));
		} catch (Exception ex) {
			WB.addLog("DateTool.getDuration(LocalDateTime, LocalDateTime), ex=" + ex.getMessage(), WB.strEmpty,
					"DateTool");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static int getDuration(OffsetDateTime date1, OffsetDateTime date2) throws Exception {// in ms
		// origin - 21.10.2023, last edit - 03.07.2024
		int res = 0;
		try {
			res = Math.abs((int) Etc.roundCustom(Duration.between(date2, date1).toMillis(), Etc.round0));
		} catch (Exception ex) {
			WB.addLog("DateTool.getDuration, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	// ex. "2024-12-31"
	public static String formatter5(LocalDate formatterLocalDate) throws Exception {
		// origin - 28.06.2024, last edit - 03.07.2024
		String res = WB.strEmpty;
		try {
			res = formatterLocalDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")).toString();
		} catch (Exception ex) {
			WB.addLog("DateTool.formatter5, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	// ex. "25.12.2006"
	private static String formatter4(String day, String month, String century, String year2) throws Exception {
		// origin - 22.06.2024, last edit - 03.07.2024
		String res = WB.strEmpty;
		try {
			res = day + "." + month + "." + century + year2; // ???magic string ???
		} catch (Exception ex) {
			WB.addLog("DateTool.formatter4, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	// ex. "2006-12-25"
	public static String formatter3(String day, String month, String century, String year2) throws Exception {
		// origin - 22.06.2024, last edit - 03.07.2024
		String res = WB.strEmpty;
		try {
			res = century + year2 + "-" + month + "-" + day;
		} catch (Exception ex) {
			WB.addLog("DateTool.formatter3, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	// ex. "2006-12-25T12:45:54"
	public static String formatter2(LocalDateTime formatterLocalDateTime) throws Exception {
		// origin - 21.05.2024, last edit - 03.07.2024
		String res = WB.strEmpty;
		try {
			res = formatterLocalDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss")).toString();
		} catch (Exception ex) {
			WB.addLog("DateTool.formatter2, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	// ex. "2006-12-25T12:45:54.8796"
	public static String formatter(LocalDateTime formatterLocalDateTime) throws Exception {
		// origin - 21.05.2024, last edit - 03.07.2024
		String res = WB.strEmpty;
		try {
			res = formatterLocalDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSS")).toString();
		} catch (Exception ex) {
			WB.addLog("DateTool.formatter, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		return res;
	}
	
	private DateTool() {
		// origin - 04.11.2024, last edit - 04.11.2024
	}

	@SuppressWarnings("unused")
	public static void test() throws Exception {
		// origin - 17.01.2024, last edit - 16.09.2024
		try {
			var testDateTime1 = new String[] { "2023-11-24T06:46:16.907+06:00", "2023-11-08 02:15:09",
					"06:46:16.907+06:00", "2019-01-01", "test1", "12.45", "12:45", "12:45:38", "12:45:57.678", null };

//		var testDate1 = new String[] { "2023-01-01T06:46:16.907+06:00", "2023-11-08 02:15:09", "06:46:16.907+06:00",
//				"2019-01-01", "test1", "12.45", "12:45", "12:45:38", "12:45:57.678", null };

			var testLocalDate = new LocalDate[] { DateTool.getNow().minusMonths(1), DateTool.getNow(),
					LocalDate.of(2024, Month.JANUARY, 1), LocalDate.of(2024, Month.APRIL, 18),
					LocalDate.of(2024, Month.JULY, 10), LocalDate.of(2024, Month.OCTOBER, 15) };

			LocalDate dateNow = DateTool.getNow();
			LocalDate dateEndCurrYear = getEndYear(dateNow);
			LocalDate dateStartLastYear = getStartYear(getStartYear(dateNow).minusDays(1));
			LocalDate dateStartPostLastYear = getStartYear(dateStartLastYear.minusDays(1));
			List<LocalDate> listDayManyYear = getListLocalDate(dateStartPostLastYear, dateEndCurrYear);
			List<LocalDate> listStartMonth = getListStartMonth(listDayManyYear);

//			// getEndDateFromDuration() LocalDate, int
//			WB.addLog2("DateTool.test.getEndDateFromDuration(LocalDate, int), res="
//					+ DateTool.getEndDateFromDuration(DateTool.getNow(), 10) + ", testDate=" + DateTool.getNow()
//					+ ", duration=10", WB.strEmpty, "DateTool");

//			// getDuration() LocalDate
//			for (var testDate : testLocalDate) {
//				WB.addLog2("DateTool.test.getDuration(LocalDate), res=" + DateTool.getDuration(DateTool.getNow(), testDate) + ", testDate="
//						+ testDate, WB.strEmpty, "DateTool");
//			}

//			// getDateBirthFromKZIIN in context = DateTool.contextGettingPawnLoan
//			var arg1 = new String[] { "671125567453", "87112567676776767676", "87664gfgf", "361125567453",
//					"971125567453", "021125567453", "231125567453", null };
//			for (var testArg1 : arg1) {
//				WB.addLog2("DateTool.test.getDateBirthFromKZIIN, res="
//						+ getDateBirthFromKZIIN(testArg1, DateTool.contextGettingPawnLoan) + ", testArg1=" + testArg1,
//						WB.strEmpty, "DateTool");
//			}

//			// getStartHalfYear
//			for (var testDate : testLocalDate) {
//				WB.addLog2("DateTool.test.getStartHalfYear, res=" + DateTool.getStartHalfYear(testDate) + ", testDate="
//						+ testDate, WB.strEmpty, "DateTool");
//			}

//			// getEndHalfYear
//			for (var testDate : testLocalDate) {
//				WB.addLog2("DateTool.test.getEndHalfYear, res=" + DateTool.getEndHalfYear(testDate) + ", testDate="
//						+ testDate, WB.strEmpty, "DateTool");
//			}

//		// getDay (LocalDate initDate)
//		for (var testDate : listDayManyYear) {
//			WB.addLog2("DateTool.test.getDay(LocalDate), res=" + getDay(testDate) + ", testDate=" + testDate, WB.strEmpty,
//					"DateTool");
//		}

//		// getMonth (LocalDate initDate)
//		for (var testDate : listDayManyYear) {
//			WB.addLog2("DateTool.test.getMonth(LocalDate), res=" + getMonth(testDate) + ", testDate=" + testDate, WB.strEmpty,
//					"DateTool");
//		}

//		// getCentury (LocalDate initDate)
//		for (var testDate : listDayManyYear) {
//			WB.addLog2("DateTool.test.getCentury(LocalDate), res=" + getCentury(testDate) + ", testDate=" + testDate, WB.strEmpty,
//					"DateTool");
//		}

//		// getYear (LocalDate initDate)
//		for (var testDate : listDayManyYear) {
//			WB.addLog2("DateTool.test.getYear(LocalDate), res=" + getYear(testDate) + ", testDate=" + testDate, WB.strEmpty,
//					"DateTool");
//		}

//		// getListStartMonthYear
//		WB.addLog2("DateTool.test.getListStartMonthYear, res=" + getListStartMonthYear(getNow()), WB.strEmpty, "DateTool");

//		// getOffsetDateTime
//		for (var testArg1 : testDateTime1) {
//			WB.addLog2("DateTool.test.getOffsetDateTime, res=" + getOffsetDateTime(testArg1) + ", testArg1=" + testArg1,
//					WB.strEmpty, "DateTool");
//		}

//		// getLocalDate
//		for (var testArg1 : testDateTime1) {
//			WB.addLog2("DateTool.test.getLocalDate, res=" + getLocalDate(testArg1) + ", testArg1=" + testArg1, WB.strEmpty,
//					"DateTool");
//		}

//		// getLocalTime
//		for (var testArg1 : testDateTime1) {
//			WB.addLog2("DateTool.test.getLocalTime, res=" + getLocalTime(testArg1) + ", testArg1=" + testArg1, WB.strEmpty,
//					"DateTool");
//		}

//		// fixLocalDate
//		for (LocalDate testArg1 : new LocalDate[] { LocalDate.of(2026, Month.APRIL, 28),
//				LocalDate.of(1967, Month.NOVEMBER, 25), LocalDate.of(2100, Month.MAY, 26) }) {
//			WB.addLog2("DateTool.test.fixLocalDate, res=" + fixLocalDate(testArg1) + ", testArg1=" + testArg1, WB.strEmpty,
//					"DateTool");
//		}

//		// getStartYear
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("DateTool.test.getStartYear, res=" + getStartYear(testArg1) + ", testArg1=" + testArg1, WB.strEmpty,
//					"DateTool");
//		}

//		// getEndYear
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("DateTool.test.getEndYear, res=" + getEndYear(testArg1) + ", testArg1=" + testArg1, WB.strEmpty,
//					"DateTool");
//		}

//		// getStartMonth
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("DateTool.test.getStartMonth, res=" + getStartMonth(testArg1) + ", testArg1=" + testArg1, WB.strEmpty,
//					"DateTool");
//		}

//		// getEndMonth
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("DateTool.test.getEndMonth, res=" + getEndMonth(testArg1) + ", testArg1=" + testArg1, WB.strEmpty,
//					"DateTool");
//		}

//		// getStartQuarter
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("DateTool.test.getStartQuarter, res=" + getStartQuarter(testArg1) + ", testArg1=" + testArg1, WB.strEmpty,
//					"DateTool");
//		}

//		// getEndQuarter
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("DateTool.test.getEndQuarter, res=" + getEndQuarter(testArg1) + ", testArg1=" + testArg1, WB.strEmpty,
//					"DateTool");
//		}

//		// getStartWeek
//		for (var testDate : testLocalDate) {
//			WB.addLog2("DateTool.test.getStartWeek, res=" + getStartWeek(testDate) + ", date1=" + testDate, WB.strEmpty,
//					"DateTool");
//		}

//		// getEndWeek
//		for (var testDate : testLocalDate) {
//			WB.addLog2("DateTool.test.getEndWeek, res=" + getEndWeek(testDate) + ", date1=" + testDate, WB.strEmpty,
//					"DateTool");
//		}
		} catch (Exception ex) {
			WB.addLog("DAteTool.test, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
		}
		// WB.addLog2("DateTool.test end ", WB.strEmpty, "DateTool");
	}
}
