import java.time.DayOfWeek;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.OffsetDateTime;
import java.time.Period;
import java.time.YearMonth;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class DateTool {
	// origin - 17.01.2024, last edit - 26.06.2024
	private static String defaultPredCentury = "19";
	private static String defaultCurrCentury = "20"; // ??? get this string for WB.maxDateSupported ??? or currDate ??
	private static int fullLenghtYear = 4;
	private static int shortLenghtYear = 2;
	public static int maxAgePerson = 120;
	public static int minAgePersonGettingPawnLoan = 18; // sectoral pawnshop
	public static String contextGettingPawnLoan = "Pawnshop.GettingPawnLoan"; // sectoral pawnshop

	@SuppressWarnings("unused")
	private static Boolean isValidDateBirth(LocalDate initDateBirth, String context) throws Exception {// TOTHINK
		// origin - 22.06.2024, last edit - 27.06.2024
		Boolean res = true;
		LocalDate dateNow = DateTool.getNow();

		if (initDateBirth.isAfter(dateNow)) {
			res = false;
		}

		if (getAgeByDateBirth(initDateBirth) > DateTool.maxAgePerson) {
			res = false;
		}

		if (Etc.strEquals(context, DateTool.contextGettingPawnLoan)) {
			if (getAgeByDateBirth(initDateBirth) < DateTool.minAgePersonGettingPawnLoan) {
				res = false;
			}
		}

//		WB.addLog2(
//				"DateTool.isValidDateBirth, res=" + res + ", initDateBirth=" + initDateBirth + ", context=" + context,
//				WB.strEmpty, "DateTool");
		return res;
	}

	private static int getAgeByDateBirth(LocalDate initDateBirth) throws Exception {
		// origin - 22.06.2024, last edit - 27.06.2024
		int res = 0;
		LocalDate dateNow = DateTool.getNow();
		Period period = initDateBirth.until(dateNow);
		res = period.getYears();
		// WB.addLog2("DateTool.getAgeByDateBirth, res=" + res + ", initDateBirth=" +
		// initDateBirth, WB.strEmpty, "DateTool");
		return res;
	}

	public static LocalDate getNow() throws Exception {
		// origin - 22.06.2024, last edit - 27.06.2024
		LocalDate res = LocalDate.now();
		// WB.addLog2("DateTool.getNow(LocalDate), res=" + res, WB.strEmpty, "DateTool");
		return res;
	}

	public static LocalDateTime getNow2() throws Exception {
		// origin - 18.12.2023, last edit - 22.06.2024
		return LocalDateTime.now(ZoneOffset.systemDefault().getRules().getOffset(Instant.now()));
	}

	private static String getDefaultCentury(String initCentury) throws Exception {
		// origin - 22.06.2024, last edit - 27.06.2024
		String res = Etc.fixTrim(initCentury);

		if (Etc.strEquals(res, defaultPredCentury) == false) {
			if (Etc.strEquals(res, defaultCurrCentury) == false) {
				res = DateTool.defaultCurrCentury;
			}
		}

		// WB.addLog2("DateTool.getDefaultCentury, res=" + res + ", initCentury=" +
		// initCentury, WB.strEmpty, "DateTool");
		return res;
	}

	private static String fixCentury(String initCentury) throws Exception {
		// origin - 21.06.2024, last edit - 27.06.2024
		String res = Etc.fixTrim(initCentury);
		res = getDefaultCentury(res);
		// WB.addLog2("DateTool.fixCentury, res=" + res + ", initCentury=" +
		// initCentury, WB.strEmpty, "DateTool");
		return res;
	}

	@SuppressWarnings("unused")
	private static String getDay(LocalDate initDate) throws Exception {
		// origin - 21.06.2024, last edit - 27.06.2024
		String res = WB.strEmpty;
		res = String.valueOf(initDate.getDayOfMonth());
		res = "00" + res; // ???magic string ???
		res = res.substring(res.length() - 2); // ??? magic number ???

		// WB.addLog2("DateTool.getDay(LocalDate), res=" + res + ", initDate=" +
		// initDate, WB.strEmpty, "DateTool");
		return res;
	}

	private static String getDay(String initKZIIN) throws Exception {
		// origin - 21.06.2024, last edit - 27.06.2024
		String res = WB.strEmpty;
		initKZIIN = Etc.fixTrim(initKZIIN);

		if (initKZIIN.length() == Info.argLenghtIIN) {
			res = initKZIIN.substring(4, 6);// ??? magic number ???
		} else {
			res = WB.strEmpty;
		}

//		WB.addLog2("DateTool.getDay, res=" + res + ", initKZIIN=" +
//		initKZIIN, WB.strEmpty, "DateTool");
		return res;
	}

	@SuppressWarnings("unused")
	private static String getMonth(LocalDate initDate) throws Exception {
		// origin - 21.06.2024, last edit - 27.06.2024
		String res = WB.strEmpty;
		res = String.valueOf(initDate.getMonthValue());
		res = "00" + res; // ???magic string ???
		res = res.substring(res.length() - 2);// ??? magic number ???

		// WB.addLog2("DateTool.getMonth(LocalDate), res=" + res + ", initDate=" +
		// initDate, WB.strEmpty, "DateTool");
		return res;
	}

	private static String getMonth(String initKZIIN) throws Exception {
		// origin - 21.06.2024, last edit - 27.06.2024
		String res = WB.strEmpty;
		initKZIIN = Etc.fixTrim(initKZIIN);

		if (initKZIIN.length() == Info.argLenghtIIN) {
			res = initKZIIN.substring(2, 4);// ??? magic number ???
		} else {
			res = WB.strEmpty;
		}

//		WB.addLog2("DateTool.getMonth, res=" + res + ", initKZIIN=" +
//		initKZIIN, WB.strEmpty, "DateTool");
		return res;
	}

	private static String getValidCentury(String initCentury, String initYear) throws Exception {
		// origin - 20.06.2024, last edit - 27.06.2024
		String res = WB.strEmpty;
		initCentury = Etc.fixTrim(initCentury);

		String yearCurrDate = getYear(String.valueOf(DateTool.getNow().getYear()));
		// WB.addLog2("DateTool.getValidCentury, yearCurrDate=" +
		// yearCurrDate, WB.strEmpty, "DateTool");
		// WB.addLog2("DateTool.getValidCentury, initCentury=" +
		// initCentury, WB.strEmpty, "DateTool");
		int numberYearCurrDate = Integer.parseInt(yearCurrDate);// ex. for 20-06-2024 this is = 24
		int numberInitYear = Integer.parseInt(initYear);// ex. for 25-11-1967 this is = 67
		if (numberYearCurrDate < numberInitYear) {// ex. 24 < 67
			res = DateTool.defaultPredCentury;
		}

		res = fixCentury(res);

//		WB.addLog2("DateTool.getValidCentury, res=" + res + ", initCentury=" + initCentury
//				+ ", initYear=" + initYear, WB.strEmpty, "DateTool");
		return res;
	}

	private static String getYear(LocalDate initDate) throws Exception {
		// origin - 21.06.2024, last edit - 27.06.2024
		String res = WB.strEmpty;
		res = getYear(String.valueOf(initDate.getYear()));

//		WB.addLog2("DateTool.getYear(LocalDate), res=" + res + ", initDate=" +
//		initDate, WB.strEmpty, "DateTool");
		return res;
	}

	private static String getYear(String initYear) throws Exception {
		// origin - 20.06.2024, last edit - 27.06.2024
		String res = WB.strEmpty;
		initYear = Etc.fixTrim(initYear);

		if (initYear.length() == DateTool.shortLenghtYear) {
			res = initYear; // if initYear = 2 simbols, ex. "24"
		}

		if (initYear.length() == DateTool.fullLenghtYear) {
			res = initYear.substring(2, 4);// ??? magic number ???
		}

		if (initYear.length() == Info.argLenghtIIN) {
			res = initYear.substring(0, 2);// ??? magic number ???
		}

//		WB.addLog2("DateTool.getYear, res=" + res + ", initYear=" +
//		initYear, WB.strEmpty, "DateTool");
		return res;
	}

	@SuppressWarnings("unused")
	private static String getCentury(LocalDate initDate) throws Exception {
		// origin - 21.06.2024, last edit - 27.06.2024
		String res = WB.strEmpty;
		res = getCentury(getYear(initDate));

		// WB.addLog2("DateTool.getCentury(LocalDate), res=" + res + ", initDate=" +
		// initDate, WB.strEmpty, "DateTool");
		return res;
	}

	private static String getCentury(String initYear) throws Exception {
		// origin - 20.06.2024, last edit - 27.06.2024
		String res = WB.strEmpty;
		initYear = Etc.fixTrim(initYear);

		if (initYear.length() == DateTool.fullLenghtYear) {
			res = initYear.substring(0, 2);// ??? magic number ???
		} else {
			res = fixCentury(WB.strEmpty);
		}

		// WB.addLog2("DateTool.getCentury, res=" + res + ", initYear=" +
		// initYear, WB.strEmpty, "DateTool");
		return res;
	}

	public static String getDateBirthFromKZIIN(String initKZIIN, String context) throws Exception {// sectoral pawnshop
		// origin - 19.06.2024, last edit - 27.06.2024
		String res = WB.strEmpty;
		initKZIIN = Etc.fixTrim(initKZIIN);
		try {
			// int lenghtIIN = ModelDto.getLenghtField(Info.argNumeric, Info.argCodeIIN);
			// WB.addLog2("DateTool.getDateBirthFromKZIIN, lenghtIIN=" + lenghtIIN, WB.strEmpty,
			// "DateTool");
			if (initKZIIN.length() != Info.argLenghtIIN) {
				return res;
			}

			if (Etc.isDigitAll(initKZIIN) == false) {
				return res;
			}

			String day = getDay(initKZIIN);
			String month = getMonth(initKZIIN);
			String year2 = getYear(initKZIIN);
			String century = getValidCentury(getCentury(year2), year2);
			res = formatter4(day, month, century, year2);

//			LocalDate resDateBirth = getLocalDate(formatter3(day, month, century, year2));
//			WB.addLog2("DateTool.isValidDateBirth, res=" + isValidDateBirth(resDateBirth, context)
//					+ ", resDateBirth=" + resDateBirth, WB.strEmpty, "DateTool");
//			WB.addLog2("DateTool.getAgeByDateBirth, res=" + getAgeByDateBirth(resDateBirth) + ", resDateBirth="
//					+ resDateBirth, WB.strEmpty, "DateTool");

		} catch (Exception ex) {
			WB.addLog2("DateTool.getDateBirthFromKZIIN, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}

		// WB.addLog2("DateTool.getDateBirthFromKZIIN, res=" + res + ", initKZIIN=" +
		// initKZIIN, WB.strEmpty, "DateTool");
		return res;
	}

	public static List<LocalDate> getListLocalDate(LocalDate dateStart, LocalDate dateEnd) throws Exception {
		// origin - 25.05.2024, last edit - 27.06.2024
		List<LocalDate> res = new ArrayList<LocalDate>();
		for (; !dateStart.isAfter(dateEnd); dateStart = dateStart.plusDays(1)) {
			res.add(dateStart);
		}
		// WB.addLog2("DateTool.getListDayYear, res.size=" + res.size() + ", year=" +
		// date.getYear(), WB.strEmpty, "DateTool");
		return res;
	}

	public static List<LocalDate> getListStartMonth(List<LocalDate> listDate) throws Exception {
		// origin - 18.02.2024, last edit - 27.06.2024
		List<LocalDate> res = new ArrayList<LocalDate>();
		for (var testDate : listDate) {
			if (testDate.isEqual(getStartMonth(testDate))) {
				// WB.addLog2("DateTool.getListStartMonth, testDate=" +
				// testDate, WB.strEmpty, "DateTool");
				res.add(testDate);
			}
		}
		// WB.addLog2("DateTool.getListStartMonth, res=" + res, WB.strEmpty, "DateTool");
		return res;
	}

	public static LocalDate getLocalDate(String expectedDate) throws Exception {// TODO
		// origin - 24.11.2023, last edit - 27.06.2024
		LocalDate res = null;
		expectedDate = Etc.fixTrim(expectedDate);
		expectedDate = expectedDate.replaceAll("--", "-");
		expectedDate = expectedDate.replaceAll("--", "-");

		if (expectedDate.isEmpty()) {
			res = DateTool.getNow();
			// WB.addLog2("DateTool.getLocalDate, res=" + res + ", expectedDate=" +
			// expectedDate, WB.strEmpty, "DateTool");
			return res;
		}

		try {
			res = LocalDate.parse(expectedDate);
			res = fixLocalDate(res);
		} catch (Exception ex) {
			// res = null;
			WB.addLog("DateTool.getLocalDate, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
//			if (res == null) {
//				res = DateTool.getNow();
//			}
		}
		// WB.addLog2("DateTool.getLocalDate, res=" + res + ", expectedDate=" +
		// expectedDate, WB.strEmpty, "DateTool");
		return res;
	}

	public static LocalTime getLocalTime(String expectedDate) throws Exception {// TODO
		// origin - 24.11.2023, last edit - 27.06.2024
		LocalTime res;
		expectedDate = Etc.fixTrim(expectedDate);
		try {
			res = LocalTime.parse(expectedDate);
		} catch (Exception ex) {
			res = null;
			WB.addLog("DateTool.getLocalTime, ex=" + ex.getMessage(), WB.strEmpty, "DateTool");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("DateTool.getLocalTime, res=" + res + ", expectedDate=" +
		// expectedDate, WB.strEmpty, "DateTool");
		return res;
	}

	public static LocalDate fixLocalDate(LocalDate fixDate) throws Exception {
		// origin - 02.10.2023, last edit - 27.06.2024
		// LocalDate not must be big maxDateSupported and least minDateSupported
		LocalDate res = fixDate;
		if (fixDate.isBefore(WB.minDateSupported)) {
			res = WB.minDateSupported;
		}
		if (fixDate.isAfter(WB.maxDateSupported)) {
			res = WB.maxDateSupported;
		}
		// WB.addLog2("DateTool.fixLocalDate, res=" + res + ", fixDate=" + fixDate, WB.strEmpty,
		// "DateTool");
		return res;
	}

	@SuppressWarnings("unused")
	private static LocalDate getStartQuarter(LocalDate currDate) throws Exception {
		// origin - 21.02.2024, last edit - 27.06.2024
		LocalDate res = getStartMonth(currDate);
		Month currMonth = currDate.getMonth();
		int currYear = currDate.getYear();

		if ((currMonth.equals(Month.JANUARY)) || (currMonth.equals(Month.FEBRUARY))
				|| (currMonth.equals(Month.MARCH))) {
			res = LocalDate.of(currYear, Month.JANUARY, 1);
		}

		if ((currMonth.equals(Month.APRIL)) || (currMonth.equals(Month.MAY)) || (currMonth.equals(Month.JUNE))) {
			res = LocalDate.of(currYear, Month.APRIL, 1);
		}

		if ((currMonth.equals(Month.JULY)) || (currMonth.equals(Month.AUGUST)) || (currMonth.equals(Month.SEPTEMBER))) {
			res = LocalDate.of(currYear, Month.JULY, 1);
		}

		if ((currMonth.equals(Month.OCTOBER)) || (currMonth.equals(Month.NOVEMBER))
				|| (currMonth.equals(Month.DECEMBER))) {
			res = LocalDate.of(currYear, Month.OCTOBER, 1);
		}

		// WB.addLog2("DateTool.getStartQuarter, res=" + res + ", currDate=" +
		// currDate, WB.strEmpty, "DateTool");
		return res;
	}

	@SuppressWarnings("unused")
	private static LocalDate getEndQuarter(LocalDate currDate) throws Exception {
		// origin - 21.02.2024, last edit - 27.06.2024
		LocalDate res = getEndMonth(currDate);
		Month currMonth = currDate.getMonth();
		int currYear = currDate.getYear();

		if ((currMonth.equals(Month.JANUARY)) || (currMonth.equals(Month.FEBRUARY))
				|| (currMonth.equals(Month.MARCH))) {
			res = LocalDate.of(currYear, Month.MARCH, 31);
		}

		if ((currMonth.equals(Month.APRIL)) || (currMonth.equals(Month.MAY)) || (currMonth.equals(Month.JUNE))) {
			res = LocalDate.of(currYear, Month.JUNE, 30);
		}

		if ((currMonth.equals(Month.JULY)) || (currMonth.equals(Month.AUGUST)) || (currMonth.equals(Month.SEPTEMBER))) {
			res = LocalDate.of(currYear, Month.SEPTEMBER, 30);
		}

		if ((currMonth.equals(Month.OCTOBER)) || (currMonth.equals(Month.NOVEMBER))
				|| (currMonth.equals(Month.DECEMBER))) {
			res = LocalDate.of(currYear, Month.DECEMBER, 31);
		}

		// WB.addLog2("DateTool.getEndQuarter, res=" + res + ", currDate=" +
		// currDate, WB.strEmpty, "DateTool");
		return res;
	}

	public static LocalDate getStartYear(LocalDate currDate) throws Exception {
		// origin - 22.01.2024, last edit - 27.06.2024
		LocalDate res = LocalDate.of(currDate.getYear(), 1, 1);
		// WB.addLog2("DateTool.getStartYear, res=" + res + ", currDate=" +
		// currDate, WB.strEmpty, "DateTool");
		return res;
	}

	public static LocalDate getEndYear(LocalDate currDate) throws Exception {
		// origin - 22.01.2024, last edit - 27.06.2024
		LocalDate res = LocalDate.of(currDate.getYear(), 12, 31);
		// WB.addLog2("DateTool.getEndYear, res=" + res + ", currDate=" + currDate,
		// WB.strEmpty, "DateTool");
		return res;
	}

	private static LocalDate getStartMonth(LocalDate currDate) throws Exception {
		// origin - 22.01.2024, last edit - 27.06.2024
		LocalDate res = YearMonth.of(currDate.getYear(), currDate.getMonth()).atDay(1);
		// WB.addLog2("DateTool.getStartMonth, res=" + res + ", currDate=" +
		// currDate, WB.strEmpty, "DateTool");
		return res;
	}

	public static LocalDate getEndMonth(LocalDate currDate) throws Exception {
		// origin - 22.01.2024, last edit - 27.06.2024
		LocalDate res = YearMonth.of(currDate.getYear(), currDate.getMonth()).atEndOfMonth();
		// WB.addLog2("DateTool.getEndMonth, res=" + res + ", currDate=" + currDate,
		// WB.strEmpty, "DateTool");
		return res;
	}

	@SuppressWarnings("unused")
	private static LocalDate getStartWeek(LocalDate currDate) throws Exception {
		// origin - 26.05.2024, last edit - 27.06.2024
		LocalDate res = currDate.with(DayOfWeek.MONDAY);
		// WB.addLog2("DateTool.getStartWeek, res=" + res + ", currDate=" +
		// currDate, WB.strEmpty, "DateTool");
		return res;
	}

	@SuppressWarnings("unused")
	private static LocalDate getEndWeek(LocalDate currDate) throws Exception {
		// origin - 26.05.2024, last edit - 27.06.2024
		LocalDate res = currDate.with(DayOfWeek.SUNDAY);
		// WB.addLog2("DateTool.getEndWeek, res=" + res + ", currDate=" + currDate,
		// WB.strEmpty, "DateTool");
		return res;
	}

	public static String getLabelDateTimeForFileName() throws Exception {
		// origin - 27.12.2023, last edit - 21.06.2024
		String res = Etc.fixTrim(formatter(getNow2()));
		res = res.replaceAll("-", "_");
		res = res.replaceAll(":", "_");
		res = res + "_";
		return res;
	}

	public static int getDuration(LocalDateTime date1, LocalDateTime date2) throws Exception {// in ms
		// origin - 21.05.2024, last edit - 21.06.2024
		return Math.abs((int) Etc.roundCustom(Duration.between(date2, date1).toMillis(), Etc.round0));
	}

	public static int getDuration(OffsetDateTime date1, OffsetDateTime date2) throws Exception {// in ms
		// origin - 21.10.2023, last edit - 22.06.2024
		return Math.abs((int) Etc.roundCustom(Duration.between(date2, date1).toMillis(), Etc.round0));
	}

	private static String formatter4(String day, String month, String century, String year2) throws Exception {// ex.
																												// "25.12.2006"
		// origin - 22.06.2024, last edit - 27.06.2024
		String res = WB.strEmpty;
		res = day + "." + month + "." + century + year2; // ???magic string ???
		return res;
	}

	@SuppressWarnings("unused")
	private static String formatter3(String day, String month, String century, String year2) throws Exception {// ex.
																												// "2006-12-25"
		// origin - 22.06.2024, last edit - 27.06.2024
		String res = WB.strEmpty;
		res = century + year2 + "-" + month + "-" + day;
		return res;
	}

	public static String formatter2(LocalDateTime formatterLocalDateTime) throws Exception {
		// origin - 21.05.2024, last edit - 27.06.2024
		String res = WB.strEmpty;
		res = formatterLocalDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss")).toString();
		return res;
	}

	public static String formatter(LocalDateTime formatterLocalDateTime) throws Exception {
		// origin - 21.05.2024, last edit - 27.06.2024
		String res = WB.strEmpty;
		res = formatterLocalDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSS")).toString();
		return res;
	}

	@SuppressWarnings("unused")
	public static void test() throws Exception {
		// origin - 17.01.2024, last edit - 27.06.2024
		var testDateTime1 = new String[] { "2023-11-24T06:46:16.907+06:00", "2023-11-08 02:15:09", "06:46:16.907+06:00",
				"2019-01-01", "test1", "12.45", "12:45", "12:45:38", "12:45:57.678", null };

//		var testDate1 = new String[] { "2023-01-01T06:46:16.907+06:00", "2023-11-08 02:15:09", "06:46:16.907+06:00",
//				"2019-01-01", "test1", "12.45", "12:45", "12:45:38", "12:45:57.678", null };

		var testLocalDate = new LocalDate[] { DateTool.getNow().minusMonths(1), DateTool.getNow(),
				LocalDate.of(2024, Month.JANUARY, 1), LocalDate.of(2024, Month.APRIL, 18) };

		LocalDate dateNow = DateTool.getNow();
		LocalDate dateEndCurrYear = getEndYear(dateNow);
		LocalDate dateStartLastYear = getStartYear(getStartYear(dateNow).minusDays(1));
		LocalDate dateStartPostLastYear = getStartYear(dateStartLastYear.minusDays(1));
		List<LocalDate> listDayManyYear = getListLocalDate(dateStartPostLastYear, dateEndCurrYear);
		List<LocalDate> listStartMonth = getListStartMonth(listDayManyYear);

		// getDateBirthFromKZIIN in context = DateTool.contextGettingPawnLoan
		var arg1 = new String[] { "671125567453", "87112567676776767676", "87664gfgf", "361125567453", "971125567453",
				"021125567453", "231125567453", null };
		for (var testArg1 : arg1) {
			WB.addLog2("DateTool.test.getDateBirthFromKZIIN, res="
					+ getDateBirthFromKZIIN(testArg1, DateTool.contextGettingPawnLoan) + ", testArg1=" + testArg1, WB.strEmpty,
					"DateTool");
		}

//		// getDay (LocalDate initDate)
//		for (var testDate : listDayManyYear) {
//			WB.addLog2("DateTool.test.getDay(LocalDate), res=" + getDay(testDate) + ", testDate=" + testDate, WB.strEmpty,
//					"DateTool");
//		}

//		// getMonth (LocalDate initDate)
//		for (var testDate : listDayManyYear) {
//			WB.addLog2("DateTool.test.getMonth(LocalDate), res=" + getMonth(testDate) + ", testDate=" + testDate, WB.strEmpty,
//					"DateTool");
//		}

//		// getCentury (LocalDate initDate)
//		for (var testDate : listDayManyYear) {
//			WB.addLog2("DateTool.test.getCentury(LocalDate), res=" + getCentury(testDate) + ", testDate=" + testDate, WB.strEmpty,
//					"DateTool");
//		}

//		// getYear (LocalDate initDate)
//		for (var testDate : listDayManyYear) {
//			WB.addLog2("DateTool.test.getYear(LocalDate), res=" + getYear(testDate) + ", testDate=" + testDate, WB.strEmpty,
//					"DateTool");
//		}

//		// getListStartMonthYear
//		WB.addLog2("DateTool.test.getListStartMonthYear, res=" + getListStartMonthYear(getNow()), WB.strEmpty, "DateTool");

//		// getOffsetDateTime
//		for (var testArg1 : testDateTime1) {
//			WB.addLog2("DateTool.test.getOffsetDateTime, res=" + getOffsetDateTime(testArg1) + ", testArg1=" + testArg1,
//					WB.strEmpty, "DateTool");
//		}

//		// getLocalDate
//		for (var testArg1 : testDateTime1) {
//			WB.addLog2("DateTool.test.getLocalDate, res=" + getLocalDate(testArg1) + ", testArg1=" + testArg1, WB.strEmpty,
//					"DateTool");
//		}

//		// getLocalTime
//		for (var testArg1 : testDateTime1) {
//			WB.addLog2("DateTool.test.getLocalTime, res=" + getLocalTime(testArg1) + ", testArg1=" + testArg1, WB.strEmpty,
//					"DateTool");
//		}

//		// fixLocalDate
//		for (LocalDate testArg1 : new LocalDate[] { LocalDate.of(2026, Month.APRIL, 28),
//				LocalDate.of(1967, Month.NOVEMBER, 25), LocalDate.of(2100, Month.MAY, 26) }) {
//			WB.addLog2("DateTool.test.fixLocalDate, res=" + fixLocalDate(testArg1) + ", testArg1=" + testArg1, WB.strEmpty,
//					"DateTool");
//		}

//		// getStartYear
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("DateTool.test.getStartYear, res=" + getStartYear(testArg1) + ", testArg1=" + testArg1, WB.strEmpty,
//					"DateTool");
//		}

//		// getEndYear
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("DateTool.test.getEndYear, res=" + getEndYear(testArg1) + ", testArg1=" + testArg1, WB.strEmpty,
//					"DateTool");
//		}

//		// getStartMonth
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("DateTool.test.getStartMonth, res=" + getStartMonth(testArg1) + ", testArg1=" + testArg1, WB.strEmpty,
//					"DateTool");
//		}

//		// getEndMonth
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("DateTool.test.getEndMonth, res=" + getEndMonth(testArg1) + ", testArg1=" + testArg1, WB.strEmpty,
//					"DateTool");
//		}

//		// getStartQuarter
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("DateTool.test.getStartQuarter, res=" + getStartQuarter(testArg1) + ", testArg1=" + testArg1, WB.strEmpty,
//					"DateTool");
//		}

//		// getEndQuarter
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("DateTool.test.getEndQuarter, res=" + getEndQuarter(testArg1) + ", testArg1=" + testArg1, WB.strEmpty,
//					"DateTool");
//		}

//		// getStartWeek
//		for (var testDate : testLocalDate) {
//			WB.addLog2("DateTool.test.getStartWeek, res=" + getStartWeek(testDate) + ", date1=" + testDate, WB.strEmpty,
//					"DateTool");
//		}

//		// getEndWeek
//		for (var testDate : testLocalDate) {
//			WB.addLog2("DateTool.test.getEndWeek, res=" + getEndWeek(testDate) + ", date1=" + testDate, WB.strEmpty,
//					"DateTool");
//		}
	}
}
