import java.util.List;

public class TemplateDoc extends ModelDto {
	// origin - 06.12.2023, last edit - 20.03.2025
	static {
		try {

		} catch (Exception ex) {
			WB.addLog("TemplateDoc.static ctor, ex=" + ex.getMessage(), "", "TemplateDoc");
		}
	}

	public TemplateDoc() throws Exception {
		// origin - 06.12.2023, last edit - 04.08.2024
		super();
	}

	public static void test() throws Exception {
		// origin - 06.12.2023, last edit - 20.03.2025
		try {

			// build
			List<ModelVal> bld = ModelVal.build("id @ id1 | code @ code1 | description @ description1 } "
					+ "id @ id2 | code @ code2 | description @ description2 }");
			WB.addLog2("TemplateDoc.build(String in)=" + bld, "", "TemplateDoc");

		} catch (Exception ex) {
			WB.addLog("TemplateDoc.test, ex=" + ex.getMessage(), "", "TemplateDoc");
		}
	}
}