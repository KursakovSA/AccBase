import java.util.List;

public class TemplateDoc extends ModelDto {
	// origin - 06.12.2023, last edit - 19.11.2024
	// public static TreeSet<String> standard = new TreeSet<String>();
	// public static TreeSet<String> sectoral = new TreeSet<String>();
	// public static TreeSet<String> custom = new TreeSet<String>();

	static {
		try {
//			TemplateDoc.standard = new TreeSet<String>(
//					List.of(WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty));// TODO
//			TemplateDoc.sectoral = new TreeSet<String>(List.of(WB.strEmpty, WB.strEmpty, WB.strEmpty));// TODO
//			TemplateDoc.custom = new TreeSet<String>(List.of(WB.strEmpty, WB.strEmpty, WB.strEmpty));// TODO
		} catch (Exception ex) {
			WB.addLog("TemplateDoc.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "TemplateDoc");
		} finally {
			Etc.doNothing();
		}
	}

	public TemplateDoc() throws Exception {
		// origin - 06.12.2023, last edit - 04.08.2024
		super();
	}

	public static void test() throws Exception {
		// origin - 06.12.2023, last edit - 19.11.2024
		try {

			// build
			List<ModelVal> bld = ModelVal.build("id @ id1 | code @ code1 | description @ description1 } "
					+ "id @ id2 | code @ code2 | description @ description2 }");
			WB.addLog2("TemplateDoc.build(String in)=" + bld, WB.strEmpty, "TemplateDoc");

		} catch (Exception ex) {
			WB.addLog("TemplateDoc.test, ex=" + ex.getMessage(), WB.strEmpty, "TemplateDoc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("TemplateDoc.test end ", WB.strEmpty, "TemplateDoc");
	}
}
