import java.util.Arrays;
import java.util.TreeSet;

public class TemplateDoc extends ModelDto {
	// origin - 06.12.2023, last edit - 04.08.2024
	public static TreeSet<String> standard = new TreeSet<String>();
	public static TreeSet<String> sectoral = new TreeSet<String>();
	public static TreeSet<String> custom = new TreeSet<String>();

	static {
		try {
			TemplateDoc.standard = new TreeSet<String>(Arrays.asList(WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
					WB.strEmpty, WB.strEmpty, WB.strEmpty));// TODO
			TemplateDoc.sectoral = new TreeSet<String>(Arrays.asList(WB.strEmpty, WB.strEmpty, WB.strEmpty));// TODO
			TemplateDoc.custom = new TreeSet<String>(Arrays.asList(WB.strEmpty, WB.strEmpty, WB.strEmpty));// TODO
		} catch (Exception ex) {
			WB.addLog("TemplateDoc.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "TemplateDoc");
		} finally {
			Etc.doNothing();
		}
	}

	public TemplateDoc() throws Exception {
		// origin - 06.12.2023, last edit - 04.08.2024
		super();
	}

	public static void test() throws Exception {
		// origin - 06.12.2023, last edit - 06.07.2024
		try {

		} catch (Exception ex) {
			WB.addLog("TemplateDoc.test, ex=" + ex.getMessage(), WB.strEmpty, "TemplateDoc");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("TemplateDoc.test end ", WB.strEmpty, "TemplateDoc");
	}
}
