import java.util.Arrays;
import java.util.TreeSet;

public class TemplateDoc extends Model {
	// origin - 06.12.2023, last edit - 08.12.2023

	static {
		standard = new TreeSet<String>(Arrays.asList("", "", "", "", "", "", ""));// TODO
		sectoral = new TreeSet<String>(Arrays.asList("", "", ""));//TODO
		//custom = new TreeSet<String>(Arrays.asList("", "", ""));// TODO
	}

	public TemplateDoc() {
		// origin - 06.12.2023, last edit - 06.12.2023
	}

	public static void test() {
		// origin - 06.12.2023, last edit - 06.12.2023
	}
}
