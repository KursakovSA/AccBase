public class TemplateDoc {
	// origin - 06.12.2023, last edit - 01.05.2025
	static {
		try {

		} catch (Exception ex) {
			WB.addLog("TemplateDoc.static ctor, ex=" + ex.getMessage(), "", "TemplateDoc");
		}
	}

	public TemplateDoc() throws Exception {
		// origin - 06.12.2023, last edit - 04.08.2024
		super();
	}

	public static void test() throws Exception {
		// origin - 06.12.2023, last edit - 13.05.2025
		try {

		} catch (Exception ex) {
			WB.addLog("TemplateDoc.test, ex=" + ex.getMessage(), "", "TemplateDoc");
		}
	}
}