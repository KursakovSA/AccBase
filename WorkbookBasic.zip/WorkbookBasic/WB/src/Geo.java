public class Geo extends Model {
	// origin - 28.09.2023, last edit - 06.12.2023
	public static Geo root;
	public Geo parent;
	public Role role;
    public Unit unit;
    
    static {
		root = new Geo("Geo","Geo","GeoData");
	}
    
    public Geo(String Id, String Code, String Description) {
		// origin - 05.12.2023, last edit - 05.12.2023
		this.id = Id;
		this.code = Code;
		this.description = Description;
	}
    
    public Geo() {
		// origin - 05.12.2023, last edit - 05.12.2023
	}
    
    public static void test() {
		// origin - 28.10.2023, last edit - 05.12.2023
    	Logger.add("Geo.test, Geo.root=" + Geo.root, "", "Geo");
	}
}
