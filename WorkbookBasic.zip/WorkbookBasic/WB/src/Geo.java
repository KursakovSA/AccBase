public class Geo extends ModelDto {
	// origin - 28.09.2023, last edit - 04.08.2024

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Geo.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Geo");
		} finally {
			Etc.doNothing();
		}
	}

	public Geo(String Id, String Code, String Description) throws Exception {
		// origin - 05.12.2023, last edit - 11.08.2024
		super(Id, Code, Description);
		this.table = this.getClass().getName();
	}

	public Geo() throws Exception {
		// origin - 05.12.2023, last edit - 11.08.2024
		super();
		this.table = this.getClass().getName();
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 16.09.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Geo.test, ex=" + ex.getMessage(), WB.strEmpty, "Geo");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Geo.test end ", WB.strEmpty, "Geo");
	}
}
