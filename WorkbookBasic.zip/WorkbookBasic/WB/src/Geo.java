public class Geo extends ModelDto {
	// origin - 28.09.2023, last edit - 15.12.2024

	public static Geo currCountry;
	private static String roleCountry;
	public String fullName, codeAlfa2, codeAlfa3, codeNumber;

	static {
		try {
			Geo.roleCountry = "Role.Geo.Country";
			Geo.currCountry = new Geo("Geo.Qazaqstan");
			// WB.addLog2("Geo.currCountry=" + Geo.currCountry, WB.strEmpty, "Geo");
		} catch (Exception ex) {
			WB.addLog("Geo.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Geo");
		} finally {
			Etc.doNothing();
		}
	}

	public String getCountry() throws Exception {
		// origin - 27.11.2024, last edit - 27.11.2024
		String res = WB.strEmpty;
		try {
			if (Etc.strEquals(this.role, Geo.roleCountry)) {
				res = this.code;
			} else {

				Geo tmp = new Geo(this.parent);
				while (Etc.strEquals(tmp.role, Geo.roleCountry) == false) {
					if (tmp.parent.isEmpty()) {
						// tmp = new Geo("Geo.Qazaqstan");
						break;
					} else {
						tmp = new Geo(tmp.parent);
					}
				}
				res = tmp.code;
			}

		} catch (Exception ex) {
			WB.addLog("Geo.getCountry, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Geo");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Geo.getCountry, res=" + res + ", this=" +
		// this,WB.strEmpty,"Geo");
		return res;
	}

	public void isExist() throws Exception {
		// origin - 26.11.2024, last edit - 11.12.2024
		super.isExist();
		try {
			for (var currGeo : WB.abcLast.geo) {
				if (Etc.strEquals(currGeo.id, this.id)) {
					this.code = currGeo.code;
					this.parent = currGeo.parent;
					this.description = currGeo.description;
					this.role = currGeo.role;
					this.unit = currGeo.unit;
					this.more = currGeo.more;
					this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
					this.codeAlfa2 = MoreVal.getFieldByKey(this.more, "CodeAlfa2");
					this.codeAlfa3 = MoreVal.getFieldByKey(this.more, "CodeAlfa3");
					this.codeNumber = MoreVal.getFieldByKey(this.more, "CodeNumber");

					this.isExist = true;
					break;
				}
			}

		} catch (Exception ex) {
			WB.addLog("Geo.isExist, ex=" + ex.getMessage(), WB.strEmpty, "Geo");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Geo.isExist=" + this.isExist, WB.strEmpty, "Geo");
	}

	public void isValid() throws Exception {
		// origin - 26.11.2024, last edit - 11.12.2024
		super.isValid();
		try {
			if (this.parent.isEmpty() | this.role.isEmpty()) {
				this.isValid = false;
			}
		} catch (Exception ex) {
			WB.addLog("Geo.isValid, ex=" + ex.getMessage(), WB.strEmpty, "Geo");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Geo.isValid=" + this.isValid, WB.strEmpty,"Geo");
	}

	public Geo(String Id) throws Exception {
		// origin - 26.11.2024, last edit - 16.12.2024
		this();
		this.src = Id;
		this.id = Id;
		this.code = Id; // code = id for basic
		this.isExist();
		this.isValid();
	}

	public Geo() throws Exception {
		// origin - 27.11.2024, last edit - 30.11.2024
		this.clear();
		this.isExist();
		var root = Abc.getRoot(this.table); // get root from WB.abcLast
		this.id = root.id;
		this.parent = root.parent;
		this.date1 = root.date1;
		this.date2 = root.date2;
		this.code = root.code;
		this.description = root.description;
		this.role = root.role;
		this.unit = root.unit;
		this.more = root.more;
	}

	public void clear() throws Exception {
		// origin - 26.11.2024, last edit - 26.11.2024
		try {
			super.clear();
			this.table = this.getClass().getName();
			this.fullName = this.codeAlfa2 = this.codeAlfa3 = this.codeNumber = WB.strEmpty;
		} catch (Exception ex) {
			WB.addLog("Geo.clear, ex=" + ex.getMessage(), WB.strEmpty, "Geo");
		} finally {
			Etc.doNothing();
		}
	}

	public String toString() {
		// origin - 26.11.2023, last edit - 11.12.2024
		String res = WB.strEmpty;
		try {
			res = res + Fmtr.addIfNotEmpty("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.unit);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);

			res = res + Fmtr.addIfNotEmpty(", codeAlfa2 ", this.codeAlfa2);
			res = res + Fmtr.addIfNotEmpty(", codeAlfa3 ", this.codeAlfa3);
			res = res + Fmtr.addIfNotEmpty(", codeNumber ", this.codeNumber);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 01.12.2024
		try {

//			// ctor()
//			WB.addLog2("Geo.test.ctor()=" + new Geo() + ", isExist=" + new Geo().isExist() + ", isValid="
//					+ new Geo().isValid(), WB.strEmpty, "Geo");
//			// ctor (String Id)
//			var testGeo = new Geo[] { new Geo(), new Geo("Geo.Qazaqstan"), new Geo("Geo.tralala"),
//					new Geo("Geo.SaryArka") };
//			for (var tmp : testGeo) {
//				WB.addLog2("Geo.test.ctor(String Id)=" + new Geo(tmp.id) + ", isExist=" + new Geo(tmp.id).isExist()
//						+ ", isValid=" + new Geo(tmp.id).isValid(), WB.strEmpty, "Geo");
//			}

//			// get country
//			for (var argGeo : testGeo) {
//				WB.addLog2("Geo.test.getCountry=" + argGeo.getCountry() + ", argGeo=" + argGeo, WB.strEmpty, "Geo");
//			}

		} catch (Exception ex) {
			WB.addLog("Geo.test, ex=" + ex.getMessage(), WB.strEmpty, "Geo");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Geo.test end ", WB.strEmpty, "Geo");
	}
}
