import java.util.ArrayList;
import java.util.List;

public class Geo extends ModelDto {
	// origin - 28.09.2023, last edit - 05.03.2025

	public static Geo currCountry;
	private static String roleCountry;
	public String fullName, codeAlfa2, codeAlfa3, codeNumber, currency;

	static {
		try {
			Geo.roleCountry = "Role.Geo.Country";
			Geo.currCountry = new Geo("Geo.Qazaqstan");
			// WB.addLog2("Geo.currCountry=" + Geo.currCountry, WB.strEmpty, "Geo");
		} catch (Exception ex) {
			WB.addLog("Geo.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Geo");
		}
	}

	public static List<String> getCurrencyPair() throws Exception {// select pairs skind "USD-KZT", "EUR-KZT", etc.
		// origin - 01.03.2025, last edit - 05.03.2025
		List<String> res = new ArrayList<String>();
		try {
			for (var curr1 : Geo.getCurrency()) {
				if (Etc.strEquals(curr1, Unit.currCurrency.description)) {// skip pairs kind "KZT-?"
					continue;
				}
				for (var curr2 : Geo.getCurrency()) {
					if (Etc.strEquals(curr2, curr1)) {// skip pairs kind "EUR-EUR"
						continue;
					}
					if (Etc.strEquals(curr2, Unit.currCurrency.description) == false) {// skip pairs kind "?-EUR, USD"
						continue;
					}
					var tmp = curr1 + "-" + curr2;
					res.add(tmp); // "USD-KZT", "EUR-KZT", etc.
					// WB.addLog2("Geo.getCurrencyPair, add tmp=" + tmp, WB.strEmpty, "Geo");
				}
			}
		} catch (Exception ex) {
			WB.addLog("Geo.getCurrencyPair, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Geo");
		}
		return res;
	}

	public static List<String> getCurrency() throws Exception {
		// origin - 19.02.2025, last edit - 05.03.2025
		List<String> res = new ArrayList<String>();
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getMoreFilter("Currency"), "Geo"); // ??magic string??
			String tmpCurrency = WB.strEmpty;
			for (var curr : listDto) {
				tmpCurrency = MoreVal.getFieldByKey(curr.more, "Currency"); // ??magic string??
				if (tmpCurrency.isEmpty() == false) {
					Unit tmpUnit = new Unit(tmpCurrency);
					res.add(tmpUnit.description); // description = "USD", "KZT", etc.
				}
			}
		} catch (Exception ex) {
			WB.addLog("Geo.getCurrency, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Geo");
		}
		return res;
	}

	public String getCountry() throws Exception {
		// origin - 27.11.2024, last edit - 05.03.2025
		String res = WB.strEmpty;
		try {
			if (Etc.strEquals(this.role, Geo.roleCountry)) {
				res = this.code;
			} else {

				Geo tmp = new Geo(this.parent);
				while (Etc.strEquals(tmp.role, Geo.roleCountry) == false) {
					if (tmp.parent.isEmpty()) {
						// tmp = new Geo("Geo.Qazaqstan");
						break;
					} else {
						tmp = new Geo(tmp.parent);
					}
				}
				res = tmp.code;
			}

		} catch (Exception ex) {
			WB.addLog("Geo.getCountry, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Geo");
		}
		return res;
	}

	public void isExist() throws Exception {
		// origin - 26.11.2024, last edit - 05.03.2025
		super.isExist();
		try {
			for (var currGeo : WB.abcLast.geo) {
				if (Etc.strEquals(currGeo.id, this.id)) {
					this.code = currGeo.code;
					this.parent = currGeo.parent;
					this.description = currGeo.description;
					this.role = currGeo.role;
					this.more = currGeo.more;

					var listDto = WB.abcLast.geo;
					this.upper = super.getUpper(listDto);
					this.lower = super.getLower(listDto);

					this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
					this.codeAlfa2 = MoreVal.getFieldByKey(this.more, "CodeAlfa2");
					this.codeAlfa3 = MoreVal.getFieldByKey(this.more, "CodeAlfa3");
					this.codeNumber = MoreVal.getFieldByKey(this.more, "CodeNumber");
					this.currency = MoreVal.getFieldByKey(this.more, "Currency");

					this.isExist = true;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Geo.isExist, ex=" + ex.getMessage(), WB.strEmpty, "Geo");
		}
	}

	public void isValid() throws Exception {
		// origin - 26.11.2024, last edit - 05.03.2025
		super.isValid();
		try {
			if (this.parent.isEmpty() | this.role.isEmpty()) {
				this.isValid = false;
			}
		} catch (Exception ex) {
			WB.addLog("Geo.isValid, ex=" + ex.getMessage(), WB.strEmpty, "Geo");
		}
	}

	public Geo(String Id) throws Exception {
		// origin - 26.11.2024, last edit - 27.12.2024
		this();
		this.src = Id;
		if (Id.isEmpty() == false) {
			this.id = this.code = Id;
		}
		this.isExist();
		this.isValid();
	}

	public Geo() throws Exception {
		// origin - 27.11.2024, last edit - 19.02.2025
		this.clear();
		this.isExist();
		var root = Abc.getRoot(this.table); // get root from WB.abcLast
		this.id = root.id;
		this.parent = root.parent;
		this.date1 = root.date1;
		this.date2 = root.date2;
		this.code = root.code;
		this.description = root.description;
		this.role = root.role;
		// this.unit = root.unit;
		this.more = root.more;
	}

	public void clear() throws Exception {
		// origin - 26.11.2024, last edit - 05.03.2025
		try {
			super.clear();
			this.table = this.getClass().getName();
			this.fullName = this.codeAlfa2 = this.codeAlfa3 = this.codeNumber = this.currency = WB.strEmpty;
		} catch (Exception ex) {
			WB.addLog("Geo.clear, ex=" + ex.getMessage(), WB.strEmpty, "Geo");
		}
	}

	public String toString() {
		// origin - 26.11.2023, last edit - 05.03.2025
		String res = WB.strEmpty;
		try {
			res = res + Fmtr.addIfNotEmpty("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());

			res = res + Fmtr.addIfNotEmpty(", upper.size ", this.upper.size());
			res = res + Fmtr.addIfNotEmpty(", lower.size ", this.lower.size());

			res = res + Fmtr.addIfNotEmpty(", currency ", this.currency);
			res = res + Fmtr.addIfNotEmpty(", codeAlfa2 ", this.codeAlfa2);
			res = res + Fmtr.addIfNotEmpty(", codeAlfa3 ", this.codeAlfa3);
			res = res + Fmtr.addIfNotEmpty(", codeNumber ", this.codeNumber);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 05.03.2025
		try {

//			// ctor (String Id)
//			for (var tmp : new String[] { WB.strEmpty, "Geo.Qazaqstan", "Geo.tralala", "Geo.SaryArka" }) {
//				WB.addLog2("Geo.test.ctor(String Id)=" + new Geo(tmp), WB.strEmpty, "Geo");
//			}

//			// get country
//			for (var tmp : new String[] {WB.strEmpty, "Geo.Qazaqstan", "Geo.tralala", "Geo.SaryArka"}) {
//				WB.addLog2("Geo.test.getCountry=" + argGeo.getCountry() + ", argGeo=" + argGeo, WB.strEmpty, "Geo");
//			}

		} catch (Exception ex) {
			WB.addLog("Geo.test, ex=" + ex.getMessage(), WB.strEmpty, "Geo");
		}
	}
}