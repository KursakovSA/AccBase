public class Geo extends Model {
	// origin - 28.09.2023, last edit - 06.07.2024
	public Geo parent;
	public Role role;
	public Unit unit;

	public Geo(String Id, String Code, String Description) throws Exception {
		// origin - 05.12.2023, last edit - 07.07.2024
		try {
			this.id = Id;
			this.code = Code;
			this.description = Description;
		} catch (Exception ex) {
			WB.addLog("Geo.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Geo");
		} finally {
			Etc.doNothing();
		}
	}

	public Geo() throws Exception {
		// origin - 05.12.2023, last edit - 07.07.2024
		try {
		} catch (Exception ex) {
			WB.addLog("Geo.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Geo");
		} finally {
			Etc.doNothing();
		}
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 06.07.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Geo.test, ex=" + ex.getMessage(), WB.strEmpty, "Geo");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Geo.test end ", WB.strEmpty, "Geo");
	}
}
