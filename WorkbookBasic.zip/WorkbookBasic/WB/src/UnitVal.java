//@SuppressWarnings("unused")
public class UnitVal extends ModelVal {// ex. raw val UnitVal = "12(Unit.KZT)"
	// origin - 13.09.2024, last edit - 23.09.2024
	private static final String strLeftSplit = "(";
	private static final String strRightSplit = ")";

//	public String context = WB.strEmpty;
//	public String src = new String(); 

	public String partVal = new String();
	public String partUnit = new String();

	// public Meter meter = new Meter(); // TOTHINK
	public double val = 0.0; // ex. 12
	public Unit unit = new Unit(); // ex. KZT, in total, UnitVal = 12 KZT

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("UnitVal.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "UnitVal");
		} finally {
			Etc.doNothing();
		}
	}

	private void getPart() throws Exception {
		// origin - 14.09.2024, last edit - 20.09.2024
		try {
			if (this.isUnitVal()) {
				int posLocalSplitLeft = this.src.indexOf(UnitVal.strLeftSplit); // pos "("
				if (posLocalSplitLeft > 0) {
					// this is res
					this.partVal = Etc.fixTrim(this.src.substring(0, posLocalSplitLeft)); // ex. "12(Unit.KZT)" --> "12"

					// clean, because may be alone chars "(" and\or ")" //??
					this.partVal = Etc.delStr(this.partVal, UnitVal.strLeftSplit);
					this.partVal = Etc.delStr(this.partVal, UnitVal.strRightSplit);

					this.partUnit = Etc.fixTrim(this.src.substring(posLocalSplitLeft));
				}
			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.getPart, ex=" + ex.getMessage(), WB.strEmpty, "UnitVal");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("UnitVal.getPart, this.partVal=" + this.partVal + ", this.partUnit=" + this.partUnit + ", this.src="
//				+ this.src, WB.strEmpty, "UnitVal");
	}

	public boolean isUnitVal() throws Exception {
		// origin - 13.09.2024, last edit - 16.09.2024
		boolean res = false;
		try {
			if (Etc.strMatch(this.src, UnitVal.strLeftSplit) == 1) {
				if (Etc.strMatch(this.src, UnitVal.strRightSplit) == 1) {
					if (this.src.endsWith(UnitVal.strRightSplit)) {
						res = true;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.isUnitVal, ex=" + ex.getMessage(), WB.strEmpty, "UnitVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("UnitVal.isUnitVal, res=" + res, WB.strEmpty, "UnitVal");
		return res;
	}

	private void getUnitVal() throws Exception {
		// origin - 13.09.2024, last edit - 23.09.2024
		try {
			this.val = Conv.getDouble(this.partVal);

			String tmp = this.partUnit;
			tmp = Etc.delStr(tmp, UnitVal.strLeftSplit);
			tmp = Etc.delStr(tmp, UnitVal.strRightSplit);
			// WB.addLog2("UnitVal.getUnitVal, tmp=" + tmp, WB.strEmpty, "UnitVal");
			var dto = ModelDto.getSubsetByCode(WB.abcLast.basic, tmp);
			if (dto.size() != 0) {
				var dto1 = dto.getFirst();
				this.unit = new Unit(dto1.id, dto1.code, dto1.description); // this is res
			} else {
				this.unit = new Unit(); // this is res
			}
			this.id = this.val + WB.strSpace + this.unit.description;
		} catch (Exception ex) {
			WB.addLog("UnitVal.getUnitVal, ex=" + ex.getMessage(), WB.strEmpty, "UnitVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("UnitVal.getUnit, this.unit=" + this.unit, WB.strEmpty,
		// "UnitVal");
	}

//	private void getSrc() throws Exception {
//		// origin - 19.09.2024, last edit - 19.09.2024
//		try {
//			this.src = Etc.fixTrim(String.valueOf(this.val)) + UnitVal.strLeftSplit + this.unit.code + UnitVal.strRightSplit;
//		} catch (Exception ex) {
//			WB.addLog("UnitVal.getSrc, ex=" + ex.getMessage(), WB.strEmpty, "UnitVal");
//		} finally {
//			Etc.doNothing();
//		}
//		WB.addLog2("UnitVal.getSrc, this.src=" + this.src, WB.strEmpty, "UnitVal");
//	}

	public UnitVal(String Val, String Unit) throws Exception {
		// origin - 18.09.2024, last edit - 20.09.2024
		this();
		// clean, because may be alone chars "(" and\or ")" //??
		Unit = Etc.delStr(Unit, UnitVal.strLeftSplit);
		Unit = Etc.delStr(Unit, UnitVal.strRightSplit);
		this.src = Etc.fixTrim(String.valueOf(Val)) + UnitVal.strLeftSplit + Unit + UnitVal.strRightSplit;
		this.getPart();
		this.getUnitVal();
	}

	public UnitVal(String Src) throws Exception {
		// origin - 13.09.2024, last edit - 15.09.2024
		this();
		this.src = Etc.fixTrim(Src);
		this.getPart();
		this.getUnitVal();
	}

	public UnitVal() throws Exception {
		// origin - 13.09.2024, last edit - 15.09.2024
		super();
	}

	public String toString() {
		// origin - 13.09.2024, last edit - 23.09.2024
		String res = WB.strEmpty;
		try {
			// res = Formatter.reflect(this);
			// res = WB.strBraceLeft + res + WB.strBraceRight;
			res = this.id;
		} catch (Exception ex) {
			// WB.addLog("UnitVal.toString, ex=" + ex.getMessage(), WB.strEmpty,
			// "UnitVal");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static String correctForDouble(String initValue) throws Exception {
		// origin - 14.09.2024, last edit - 20.09.2024
		String res = Etc.fixTrim(initValue);
		try {
			// test on UnitVal
			UnitVal testUnitVal = new UnitVal(initValue);
			if (testUnitVal.isUnitVal()) {
				res = testUnitVal.partVal;

//				// clean, because may be alone chars "(" and\or ")" //??
//				res = Etc.delStr(res, UnitVal.strLeftSplit);
//				res = Etc.delStr(res, UnitVal.strRightSplit);
			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.correctForDouble, ex=" + ex.getMessage(), WB.strEmpty, "UnitVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("UnitVal.correctForDouble, res=" + res + ", initValue=" +
		// initValue, WB.strEmpty, "UnitVal");
		return res;
	}

	public static void test() throws Exception {
		// origin - 13.09.2024, last edit - 20.09.2024
		try {

//			// ctor1
//			UnitVal unitVal1 = new UnitVal("0.293(Unit.Percent)");
//			WB.addLog2("UnitVal.test.ctor1, unitVal1=" + unitVal1 + ", init str=" + "0.293(Unit.Percent)", WB.strEmpty,
//					"UnitVal");

//			// ctor2
//			UnitVal unitVal2 = new UnitVal("0.293", "Unit.Percent)");
//			WB.addLog2("UnitVal.test.ctor2, unitVal2=" + unitVal2 + ", init str1=" + "0.293" + ", init str2="
//					+ "Unit.Percent)", WB.strEmpty, "UnitVal");

//			// getDouble (from string with UnitVal)
//			for (String testArg1 : new String[] { "17420(Unit.Percent)", "17 420 (Unit.KZT)", "17420.0 (45 678)" }) {
//				WB.addLog2("UnitVal.test.Conv.getDouble (from string with UnitVal), res=" + Conv.getDouble(testArg1)
//						+ ", before correct testArg1=" + testArg1, WB.strEmpty, "UnitVal");
//				testArg1 = UnitVal.correctForDouble(testArg1);
//				WB.addLog2("UnitVal.test.Conv.getDouble (from string with UnitVal), res=" + Conv.getDouble(testArg1)
//						+ ", testArg1 (after correct) =" + testArg1, WB.strEmpty, "UnitVal");
//			}

		} catch (Exception ex) {
			WB.addLog("UnitVal.test, ex=" + ex.getMessage(), WB.strEmpty, "UnitVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("UnitVal.test end ", WB.strEmpty, "UnitVal");
	}
}