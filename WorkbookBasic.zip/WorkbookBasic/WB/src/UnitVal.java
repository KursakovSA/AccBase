
//@SuppressWarnings("unused")
import java.util.List;

public class UnitVal extends ModelVal {// ex. AmountDeal = "12000.0(Unit.KZT)"
	// origin - 13.09.2024, last edit - 10.11.2024

	public static final String strLeftSplit = "(";
	public static final String strRightSplit = ")";
	private static final List<String> listDelStr = List.of(UnitVal.strLeftSplit, UnitVal.strRightSplit, WB.strEquals);

	public String partName = WB.strEmpty; // ex. "AmountDeal =", from AmountDeal = "12000.0(Unit.KZT)"
	public String partVal = WB.strEmpty;
	public String partUnit = WB.strEmpty;

	public String name = WB.strEmpty; // ex. "AmountDeal", from AmountDeal = "12000.0(Unit.KZT)"
	public double val = 0.0; // ex. 12.0
	public Unit unit = new Unit();

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("UnitVal.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "UnitVal");
		} finally {
			Etc.doNothing();
		}
	}

	private void getPart() throws Exception {
		// origin - 14.09.2024, last edit - 10.11.2024
		try {
			if (this.isUnitVal()) {

				if (Etc.strContains(this.src, WB.strEquals)) {
					int posLocalEquals = this.src.indexOf(WB.strEquals); // pos " = "
					if (posLocalEquals > 0) {
						String tmp = Etc.fixTrim(this.src);
						// this.partName = Etc.fixTrim(this.src.substring(0, posLocalEquals));
						this.partName = Etc.fixTrim(tmp.substring(0, posLocalEquals));
						// WB.addLog2("UnitVal.this.partName=" + this.partName, WB.strEmpty, "UnitVal");
						this.name = Etc.delStr(this.partName, UnitVal.listDelStr);
						// WB.addLog2("UnitVal.getPart, this.name=" + this.name, WB.strEmpty,
						// "UnitVal");
					}
				}

				int posLocalSplitLeft = this.src.indexOf(UnitVal.strLeftSplit); // pos "("
				if (posLocalSplitLeft > 0) {
					this.partVal = Etc.fixTrim(this.src.substring(0, posLocalSplitLeft)); // ex. "12(Unit.KZT)" --> "12"
					this.partVal = Etc.delStr(this.partVal, UnitVal.listDelStr);
					this.partVal = Etc.delStr(this.partVal, this.name);
					// WB.addLog2("UnitVal.getPart, this.partVal, step3=" + this.partVal,
					// WB.strEmpty, "UnitVal");
					this.partUnit = Etc.fixTrim(this.src.substring(posLocalSplitLeft));
				}

			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.getPart, ex=" + ex.getMessage(), WB.strEmpty, "UnitVal");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("UnitVal.getPart, this.partVal=" + this.partVal + ", this.partUnit=" + this.partUnit + ", this.src="
//				+ this.src, WB.strEmpty, "UnitVal");
	}

	private void getUnitVal() throws Exception {
		// origin - 13.09.2024, last edit - 10.11.2024
		try {
			this.val = Conv.getDouble(this.partVal);
//			WB.addLog2("UnitVal.getUnitVal, this.val=" + this.val + ", this.partVal=" + this.partVal, WB.strEmpty,
//					"UnitVal");

			String tmp = this.partUnit;
			tmp = Etc.delStr(tmp, UnitVal.strLeftSplit);
			tmp = Etc.delStr(tmp, UnitVal.strRightSplit);
			// WB.addLog2("UnitVal.getUnitVal, tmp=" + tmp, WB.strEmpty, "UnitVal");
			var dto = ReadSet.getByCode(WB.abcLast.basic, tmp);
			if (dto.size() != 0) {
				var dto1 = dto.getFirst();
				this.unit = new Unit(dto1.id, dto1.code, dto1.description); // this is res
			} else {
				this.unit = new Unit("Unit.KZT"); // this is res
			}

			this.id = this.partName + WB.strSpace + this.val + WB.strSpace + this.unit.description;

		} catch (Exception ex) {
			WB.addLog("UnitVal.getUnitVal, ex=" + ex.getMessage(), WB.strEmpty, "UnitVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("UnitVal.getUnitVal, this.unit=" + this.unit, WB.strEmpty,
		// "UnitVal");
	}

	public UnitVal(String Val, String Unit) throws Exception {
		// origin - 18.09.2024, last edit - 20.09.2024
		this();
		// clean, because may be alone chars "(" and\or ")" //??
		Unit = Etc.delStr(Unit, UnitVal.strLeftSplit);
		Unit = Etc.delStr(Unit, UnitVal.strRightSplit);
		this.src = Etc.fixTrim(String.valueOf(Val)) + UnitVal.strLeftSplit + Unit + UnitVal.strRightSplit;
		this.getPart();
		this.getUnitVal();
	}

	public UnitVal(String Src) throws Exception {
		// origin - 13.09.2024, last edit - 15.09.2024
		this();
		this.src = Etc.fixTrim(Src);
		this.getPart();
		this.getUnitVal();
	}

	public UnitVal() throws Exception {
		// origin - 13.09.2024, last edit - 15.09.2024
		super();
	}

	public String toString() {
		// origin - 13.09.2024, last edit - 09.11.2024
		String res = WB.strEmpty;
		try {
			res = this.id;
		} catch (Exception ex) {
			// WB.addLog("UnitVal.toString, ex=" + ex.getMessage(), WB.strEmpty,
			// "UnitVal");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static String correctForDouble(String initValue) throws Exception {
		// origin - 14.09.2024, last edit - 20.09.2024
		String res = Etc.fixTrim(initValue);
		try {
			// test on UnitVal
			UnitVal testUnitVal = new UnitVal(initValue);
			if (testUnitVal.isUnitVal()) {
				res = testUnitVal.partVal;

//				// clean, because may be alone chars "(" and\or ")" //??
//				res = Etc.delStr(res, UnitVal.strLeftSplit);
//				res = Etc.delStr(res, UnitVal.strRightSplit);
			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.correctForDouble, ex=" + ex.getMessage(), WB.strEmpty, "UnitVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("UnitVal.correctForDouble, res=" + res + ", initValue=" +
		// initValue, WB.strEmpty, "UnitVal");
		return res;
	}

	public static void test() throws Exception {
		// origin - 13.09.2024, last edit - 10.11.2024
		try {

//			// ctor1
//			UnitVal unitVal1 = new UnitVal("0.293(Unit.Percent)");
//			WB.addLog2("UnitVal.test.ctor1, unitVal1=" + unitVal1 + ", unitVal1.src=" + unitVal1.src, WB.strEmpty,
//					"UnitVal");

//			// ctor2
//			UnitVal unitVal2 = new UnitVal("0.293", "Unit.Percent)");
//			WB.addLog2("UnitVal.test.ctor2, unitVal2=" + unitVal2 + ", init str1=" + "0.293" + ", init str2="
//					+ "Unit.Percent)", WB.strEmpty, "UnitVal");

//			// ctor3
//			UnitVal unitVal3 = new UnitVal("AmountDeal = 12000.0(Unit.KZT)");
//			WB.addLog2("UnitVal.test.ctor3, unitVal3=" + unitVal3 + ", this.src=" + unitVal3.src, WB.strEmpty,
//					"UnitVal");

//			// getDouble (from string with UnitVal)
//			for (String testArg1 : new String[] { "17420(Unit.Percent)", "17 420 (Unit.KZT)", "17420.0 (45 678)" }) {
//				WB.addLog2("UnitVal.test.Conv.getDouble (from string with UnitVal), res=" + Conv.getDouble(testArg1)
//						+ ", before correct testArg1=" + testArg1, WB.strEmpty, "UnitVal");
//				testArg1 = UnitVal.correctForDouble(testArg1);
//				WB.addLog2("UnitVal.test.Conv.getDouble (from string with UnitVal), res=" + Conv.getDouble(testArg1)
//						+ ", testArg1 (after correct) =" + testArg1, WB.strEmpty, "UnitVal");
//			}

		} catch (Exception ex) {
			WB.addLog("UnitVal.test, ex=" + ex.getMessage(), WB.strEmpty, "UnitVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("UnitVal.test end ", WB.strEmpty, "UnitVal");
	}
}