import java.util.List;

public class UnitVal extends ModelVal {// ex. AmountDeal = "12000.0(Unit.KZT)"
	// origin - 13.09.2024, last edit - 09.01.2025

	private static final List<String> listDelStr = List.of(WB.strParenthesisLeft, WB.strParenthesisRight, WB.strEquals);
	public String partVal = WB.strEmpty;
	public double val = 0.0;
	// public String valStr = WB.strEmpty; // ?? replace on partVal ??

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("UnitVal.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "UnitVal");
		} finally {
			Etc.doNothing();
		}
	}

	private void getId() throws Exception {
		// origin - 01.12.2024, last edit - 09.01.2025
		try {
			this.id = this.id + this.partName + WB.strSpace + this.partVal;
//			if (this.valStr.isEmpty()) {
//				this.id = this.id + WB.strSpace + this.val;
//			} else {
//				this.id = this.id + WB.strSpace + this.valStr;
//			}
			if (this.partUnit.isEmpty() == false) {
				this.id = this.id + WB.strSpace + this.unit.code + WB.strCommaSpace + this.unit.description;
			}

			if (this.partUnit.isEmpty() & this.partVal.isEmpty()) {
				this.id = WB.strEmpty;
			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.getId, ex=" + ex.getMessage(), WB.strEmpty, "UnitVal");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("UnitVal.getId, this.id=" + this.id, this.src=" + this.src, WB.strEmpty, "UnitVal");
	}

	private void getPart() throws Exception {
		// origin - 14.09.2024, last edit - 04.01.2025
		try {
//			WB.addLog2("UnitVal.getPart, ModelVal.isType(this.src)=" + ModelVal.isType(this.src) + ", this.src="
//					+ this.src, WB.strEmpty, "UnitVal");
			if (ModelVal.isType(this.src) == "UnitVal") {
				String tmp = this.src;
				int posMiddleEquation = tmp.indexOf(WB.strEquals); // pos "="
				if (posMiddleEquation > 0) {
					this.partName = Etc.fixTrim(tmp.substring(0, posMiddleEquation));
//					WB.addLog2("UnitVal.getPart, this.partName=" + this.partName + ", this.src=" + this.src,
//							WB.strEmpty, "UnitVal");
					tmp = Etc.delStr(tmp, this.partName);
					tmp = Etc.delStr(tmp, WB.strEquals);
				}

				int posLocalSplitValUnit = tmp.indexOf(ModelVal.strStartUnit); // pos "(Unit."
				if (posLocalSplitValUnit > 0) {
					this.partVal = Etc.fixTrim(tmp.substring(0, posLocalSplitValUnit));
					this.partUnit = Etc.fixTrim(tmp.substring(posLocalSplitValUnit));
					this.partUnit = Etc.delStr(this.partUnit, UnitVal.listDelStr);
				}

				if (this.partUnit.isEmpty()) {
					this.partVal = Etc.fixTrim(tmp);
				}

			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.getPart, ex=" + ex.getMessage(), WB.strEmpty, "UnitVal");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("UnitVal.getPart, this.partVal=" + this.partVal + ", this.partUnit=" + this.partUnit + ", this.src="
//				+ this.src, WB.strEmpty, "UnitVal");
	}

	private void getVal() throws Exception {
		// origin - 13.09.2024, last edit - 09.01.2025
		try {
			this.getUnit();
			if ((this.partVal.endsWith(".0")) | (Etc.strContains(this.context, "ExpectedDouble"))) {// ??magic string ??
				this.val = Conv.getDouble(this.partVal);
			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.getVal, ex=" + ex.getMessage(), WB.strEmpty, "UnitVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("UnitVal.getVal, this.unit=" + this.unit, WB.strEmpty,
		// "UnitVal");
	}

	public UnitVal(String Val, String Unit) throws Exception {
		// origin - 18.09.2024, last edit - 01.12.2024
		this();
		// clean, because may be alone chars "(" and\or ")" //??
		Unit = Etc.delStr(Unit, WB.strParenthesisLeft);
		Unit = Etc.delStr(Unit, WB.strParenthesisRight);
		this.src = Etc.fixTrim(String.valueOf(Val)) + WB.strParenthesisLeft + Unit + WB.strParenthesisRight;
		this.getPart();
		this.getVal();
		this.getId();
	}

	public UnitVal(String Src) throws Exception {
		// origin - 13.09.2024, last edit - 01.12.2024
		this();
		this.src = Etc.fixTrim(Src);
		this.getPart();
		this.getVal();
		this.getId();
	}

	public UnitVal() throws Exception {
		// origin - 13.09.2024, last edit - 15.09.2024
		super();
	}

	public String toString() {
		// origin - 13.09.2024, last edit - 09.01.2025
		String res = WB.strEmpty;
		try {
			res = this.id + WB.strSpace + ", src " + this.src + ", context " + this.context;
		} catch (Exception ex) {
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static String correctForDouble(String initValue) throws Exception {
		// origin - 14.09.2024, last edit - 13.11.2024
		String res = Etc.fixTrim(initValue);
		try {
			// test on UnitVal
			UnitVal testUnitVal = new UnitVal(initValue);
			if (ModelVal.isType(testUnitVal.src) == "UnitVal") {// if (testUnitVal.isUnitVal()) {
				res = testUnitVal.partVal;

//				// clean, because may be alone chars "(" and\or ")" //??
//				res = Etc.delStr(res, UnitVal.strLeftSplit);
//				res = Etc.delStr(res, UnitVal.strRightSplit);
			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.correctForDouble, ex=" + ex.getMessage(), WB.strEmpty, "UnitVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("UnitVal.correctForDouble, res=" + res + ", initValue=" +
		// initValue, WB.strEmpty, "UnitVal");
		return res;
	}

	public static void test() throws Exception {
		// origin - 13.09.2024, last edit - 09.01.2025
		try {

//			// ctor(String)
//			for (var tmp : new String[] { "0.293(Unit.tralala)", "AmountDeal = 12000.0(Unit.KZT)",
//					"0.293(Unit.Percent)" }) {
//				WB.addLog2("UnitVal.test.ctor(String)=" + new UnitVal(tmp), WB.strEmpty, "UnitVal");
//			}

//			// getDouble (from string with UnitVal)
//			for (String testArg1 : new String[] { "17420(Unit.Percent)", "17 420 (Unit.KZT)", "17420.0 (45 678)" }) {
//				WB.addLog2("UnitVal.test.Conv.getDouble (from string with UnitVal), res=" + Conv.getDouble(testArg1)
//						+ ", before correct testArg1=" + testArg1, WB.strEmpty, "UnitVal");
//				testArg1 = UnitVal.correctForDouble(testArg1);
//				WB.addLog2("UnitVal.test.Conv.getDouble (from string with UnitVal), res=" + Conv.getDouble(testArg1)
//						+ ", testArg1 (after correct) =" + testArg1, WB.strEmpty, "UnitVal");
//			}

		} catch (Exception ex) {
			WB.addLog("UnitVal.test, ex=" + ex.getMessage(), WB.strEmpty, "UnitVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("UnitVal.test end ", WB.strEmpty, "UnitVal");
	}
}