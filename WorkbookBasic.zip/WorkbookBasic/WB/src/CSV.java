import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unused")
public class CSV {
	// origin - 30.07.2023, last edit - 04.08.2024

	public static String expectedDir = WB.commonDocDir;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("CSV.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "CSV");
		} finally {
			Etc.doNothing();
		}
	}

	private static String getSource(String fileName) throws Exception {
		// origin - 31.07.2024, last edit - 04.08.2024
		String res = WB.strEmpty;
		try {
			res = CSV.expectedDir + File.separator + fileName;
		} catch (Exception ex) {
			WB.addLog("CSV.getSource, ex=" + ex.getMessage() + ", fileName=" + fileName, WB.strEmpty, "CSV");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("CSV.getSource, res=" + res + ", fileName=" + fileName,
		// WB.strEmpty, "CSV");
		return res;
	}

	public static List<String> getMatch(String file, String pattern) throws Exception {
		// origin - 31.07.2024, last edit - 31.07.2024
		LocalDateTime localStart = WB.getLocalStart();
		List<String> res = new ArrayList<String>();
		int countRow = 0;
		try {
			try (BufferedReader br = new BufferedReader(new FileReader(file, StandardCharsets.UTF_8))) {
				String line;
				while ((line = br.readLine()) != null) {
					countRow = countRow + 1;
					if (Etc.strContains(line, pattern)) {
						res.add(String.valueOf(countRow));
						// WB.addLog2("CSV.getMatch, res=" + countRow, WB.strEmpty, "CSV");
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("CSV.getMatch, ex=" + ex.getMessage(), WB.strEmpty, "CSV");
		} finally {
			Etc.doNothing();
		}
		WB.getLocalEnd("CSV.getMatch, res=" + res + ",file=" + file + ", pattern=" + pattern + ", countRow=" + countRow,
				localStart);
		WB.addLog2("CSV.getMatch, res=" + res + ", file=" + file + ", pattern=" + pattern + ", countRow=" + countRow,
				WB.strEmpty, "CSV");
		return res;
	}

	public CSV() throws Exception {
		// origin - 30.07.2024, last edit - 31.07.2024
	}

	public static void test() throws Exception {
		// origin - 30.07.2024, last edit - 16.09.2024
		String podft1 = CSV.getSource("podft1.csv");
		String podft2 = CSV.getSource("podft2.csv");
		try {

//			// getMatch
//			CSV.getMatch(podft1, "7777777777");
//			CSV.getMatch(podft1, "8888888888");
//			CSV.getMatch(podft1, "9999999999");
//			CSV.getMatch(podft2, "720321350468");
//			CSV.getMatch(podft2, "831119300805");
//			CSV.getMatch(podft2, "830622350417");

		} catch (Exception ex) {
			WB.addLog("CSV.test, ex=" + ex.getMessage(), WB.strEmpty, "CSV");
		} finally {
			Etc.doNothing();
		}
		//WB.addLog2("CSV.test end ", WB.strEmpty, "CSV");
	}
}
