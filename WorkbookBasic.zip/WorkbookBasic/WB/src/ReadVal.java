public class ReadVal {
	// origin - 04.10.2024, last edit - 09.10.2024

//	public static boolean isRequiredFill(String initVal) throws Exception {
//		// origin - 19.06.2024, last edit - 09.10.2024
//		boolean res = false;
//		try {
//			initVal = Etc.fixTrim(initVal);
//			if (initVal.endsWith("=?")) { // ?? magic string ??
//				res = true;
//			}
//		} catch (Exception ex) {
//			WB.addLog("ReadVal.isRequiredFill, ex=" + ex.getMessage(), WB.strEmpty, "ReadVal");
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("ReadVal.isRequiredFill, res=" + res + ", initVal=" + initVal,
//		// WB.strEmpty, "ReadVal");
//		return res;
//	}

//	public static String getValueByKeyFromEquation(String[] equation, String key) throws Exception {
//		// origin - 16.06.2024, last edit - 09.10.2024
//		String res = WB.strEmpty;
//		try {
//			int indexSignEquals = 0;
//			String strKey = WB.strEmpty;
//			String splitEquation = WB.strEquals;
//			for (var currEquation : equation) {
//				indexSignEquals = 0;
//				indexSignEquals = currEquation.lastIndexOf(splitEquation);
//				if (indexSignEquals > 0) {
//					strKey = WB.strEmpty;
//					strKey = currEquation.substring(0, indexSignEquals);
//					if (strKey.isEmpty() == false) {
//						if (Etc.strEquals(key, strKey)) {
//							res = currEquation.substring(indexSignEquals + 1, currEquation.length());
//						}
//					}
//				}
//
//			}
//		} catch (Exception ex) {
//			WB.addLog("ReadVal.getValueByKeyFromEquation, ex=" + ex.getMessage(), WB.strEmpty, "ReadVal");
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("ReadVal.getValueByKeyFromEquation, res=" + res + ", key=" + key,
//		// WB.strEmpty, "ReadVal");
//		return res;
//	}

//	public static String getValueFromMoreByKey(List<ModelDto> dto, String key, String code) throws Exception {
//		// origin - 17.06.2024, last edit - 09.10.2024
//		// ex. call --- somestring =
//		// ReadVal.getValueFromMoreByKey(WB.abcLast.infoBaseId, "infoBaseId",
//		// "Face.FA1");
//		String res = WB.strEmpty;
//		try {
//			String[] items = {};
//			String splitValueInMore = WB.strSemiColon;
//			for (var currDto : dto) {
//
//				// filter by code (optional)
//				if (code.isEmpty() == false) {// code may be empty
//					if (Etc.strEquals(currDto.code, code) == false) {
//						continue;
//					}
//				}
//
//				// items = Etc.getArrayFromStrSplit(currDto.more, splitValueInMore); // if value
//				// are diffferent in list ???
//				items = currDto.more.split(splitValueInMore); // if value are diffferent in list ???
//				res = ReadVal.getValueByKeyFromEquation(items, key);
//			}
//		} catch (Exception ex) {
//			WB.addLog("ReadVal.getValueFromMoreByKey, ex=" + ex.getMessage(), WB.strEmpty, "ReadVal");
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("ReadVal.getValueFromMoreByKey, res=" + res, WB.strEmpty,
//		// "ReadVal");
//		return res;
//	}

	public ReadVal() throws Exception {
		// origin - 04.10.2024, last edit - 04.10.2024
	}

	public static void test() throws Exception {
		// origin - 04.10.2024, last edit - 09.10.2024
		try {

//			// isRequiredFill
//			for (String testArg1 : new String[] { "KZ?", "IBAN=?", "Description=;", "?Surname=;" }) {
//				WB.addLog2("ReadVal.test.isRequiredFill, res=" + isRequiredFill(testArg1) + ", testArg1=" + testArg1,
//						WB.strEmpty, "ReadVal");
//			}

		} catch (

		Exception ex) {
			WB.addLog("ReadVal.test, ex=" + ex.getMessage(), WB.strEmpty, "ReadVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ReadVal.test end ", WB.strEmpty, "ReadVal");
	}
}
