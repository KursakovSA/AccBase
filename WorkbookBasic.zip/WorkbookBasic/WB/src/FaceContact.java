import java.util.ArrayList;
import java.util.List;

public class FaceContact {
	// origin - 25.04.2025, last edit - 25.04.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, geo, role, info, mark, more;
	// special fields
	public String fullName, comment;
	// special timestamp fields
	public ListVal date1, date2, code, description;
	// list common + special + timestamp fields in unified val
	public List<FaceDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("FaceContact.static ctor, ex=" + ex.getMessage(), "", "FaceContact");
		}
	}

	// full list face contact items on date1
	public static List<FaceDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 25.04.2025, last edit - 26.04.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var currFaceContact = new FaceContact(parentId);
			res = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceContact.val);
		} catch (Exception ex) {
			WB.addLog("FaceContact.getCurr(List<FaceDto>), ex=" + ex.getMessage(), "", "FaceContact");
		}
		return res;
	}

	private void getVal() throws Exception {
		// origin - 25.04.2025, last edit - 25.04.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currCode = "";
			String currDescription = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currCode = this.code.getByIndex(i);
				currDescription = this.description.getByIndex(i);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, currCode, currDescription, this.geo,
						this.role, this.info, this.more, this.mark);
				tmp.comment = this.comment;
				tmp.fullName = this.fullName;
				this.val.add(tmp);
				// WB.addLog2("FaceContact.getVal, add tmp=" + tmp, "","FaceContact");
			}
		} catch (Exception ex) {
			WB.addLog("FaceContact.getVal, ex=" + ex.getMessage(), "", "FaceContact");
		}
	}

	public void isExist() throws Exception {
		// origin - 25.04.2025, last edit - 26.04.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(this.parent, Role.faceContact),
					this.table);
			if (listDto.size() != 0) {
				for (var currDto : listDto) {
					var tmp = new SpanVal(currDto.date1, currDto.date2);
					this.date1 = new ListVal(tmp.date1);
					this.date2 = new ListVal(tmp.date2);

					this.id = DefVal.setCustom(this.id, currDto.id);

					this.code = new ListVal(currDto.code, "");
					this.description = new ListVal(currDto.description, "");

					this.geo = DefVal.setCustom(this.geo, currDto.geo);
					this.role = DefVal.setCustom(this.role, currDto.role);
					this.info = DefVal.setCustom(this.info, currDto.info);
					this.more = DefVal.setCustom(this.more, currDto.more);
					this.mark = DefVal.setCustom(this.mark, currDto.mark);

					this.fullName = MoreVal.getFieldByKey(currDto.more, "FullName");
					this.comment = MoreVal.getFieldByKey(currDto.more, "Comment");

					this.isExist = true;
					break;
				}
			}

			if (listDto.size() == 0) {
				this.parent = "";
			}
		} catch (Exception ex) {
			WB.addLog("FaceContact.isExist, ex=" + ex.getMessage(), "", "FaceContact");
		}
	}

	public FaceContact(String ParentId) throws Exception {
		// origin - 25.04.2025, last edit - 25.04.2025
		this.clear();
		this.table = "Face";
		this.src = this.parent = ParentId;
		this.isExist();
		this.getVal();
	}

	public void clear() throws Exception {
		// origin - 25.04.2025, last edit - 26.04.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = this.src = this.id = this.parent = this.geo = this.role = this.info = this.mark = this.more = "";
			this.date1 = this.date2 = this.code = this.description = new ListVal();
			this.fullName = this.comment = "";
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("FaceContact.clear, ex=" + ex.getMessage(), "", "FaceContact");
		}
	}

	public FaceContact() throws Exception {
		// origin - 25.04.2025, last edit - 25.04.2025
		this.clear();
	}

	public String toString() {
		// origin - 25.04.2025, last edit - 26.04.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);

			res = res + Fmtr.addIfNotEmpty(", code ", this.code.id);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description.id);

			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 25.04.2025, last edit - 28.04.2025
		try {

//			// getCurr(List<FaceDto>)
//			WB.addLog2("FaceContact.test.getCurr(List<FaceDto>)", "", "FaceContact");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.Person.Template" }) {
//					WB.addLog2(
//							"FaceContact.test.getCurr(List<FaceDto>), res.size="
//									+ FaceContact.getCurr(tmp1, tmp2).size() + ", date1=" + tmp1 + ", parentId=" + tmp2,
//							"", "FaceContact");
//			FaceDto.log(FaceContact.getCurr(tmp1, tmp2));
//				}
//			}

//			// ctor (String)
//			WB.addLog2("FaceContact.test.ctor(String)", "", "FaceContact");
//			for (var tmp1 : new String[] { "", "Face.Person.Template", "Face.Tralala" }) {
//				WB.addLog2("FaceContact.test.ctor(String)=" + new FaceContact(tmp1), "", "FaceContact");
//			}

//			// ctor ()
//			WB.addLog2("FaceContact.test.ctor()", "", "FaceContact");
//			WB.addLog2("FaceContact.test.ctor()=" + new FaceContact(), "", "FaceContact");

		} catch (Exception ex) {
			WB.addLog("FaceContact.test, ex=" + ex.getMessage(), "", "FaceContact");
		}
	}
}