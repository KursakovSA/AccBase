import java.util.List;

public class Face extends Model {
	// origin - 28.09.2023, last edit - 30.12.2023
	public static Face root;
	public Face parent;
	public Geo geo;
	public Role role;
	public Info info;
	public List<Face> store; // TODO
	public List<Face> department; // TODO
	public List<Face> cash; // TODO
	public List<Face> bank; // TODO
	public List<Face> staffTable; // TODO

	static {
		root = new Face("Face", "Face", "FaceData");
	}

	public Face(String Id, String Code, String Description) {
		// origin - 05.12.2023, last edit - 05.12.2023
		this.id = Id;
		this.code = Code;
		this.description = Description;
	}

	public Face() {
		// origin - 05.12.2023, last edit - 05.12.2023
	}

	public static void test() {
		// origin - 28.10.2023, last edit - 05.12.2023
		Logger.add("Face.test, Face.root=" + Face.root, "", "Face");
	}
}
