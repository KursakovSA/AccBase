import java.util.ArrayList;
import java.util.List;

public class Face {
	// origin - 28.09.2023, last edit - 13.05.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, date1, date2, code, description, geo, role, info, more, mark;
	// special fields
	public static FaceDto currFA;
	public String faceId, storeId, cashId, paymasterEmpId, userId, deptId, pointId, staffTableId, empId, crewId,
			selfEmpId;
	public String fullName, comment, sex;
	public List<FaceDto> store, dept, cash, bank, user, crew, staffTable, staff, contact, daily, point, address;
	public JobCycle jobCycle;

	static {
		try {
			Face.currFA = Face.getCurrFA();
			// WB.addLog2("Face.currFA=" + Face.currFA, "", "Face");
		} catch (Exception ex) {
			WB.addLog("Face.static ctor, ex=" + ex.getMessage(), "", "Face");
		}
	}

	@SuppressWarnings("unused")
	private String getDateBirth() throws Exception {// TODO calc from IIN
		// origin - 13.05.2025, last edit - 13.05.2025
		String res = "";
		try {
		} catch (Exception ex) {
			WB.addLog("Face.getDateBirth, ex=" + ex.getMessage(), "", "Face");
		}
		return res;
	}

	private void getPart() throws Exception {
		// origin - 06.03.2025, last edit - 04.05.2025
		try {
			this.address = Address.get(this.id);
			this.staffTable = StaffTable.get(this.id);
			this.staff = Staff.get(this.id);
			this.store = Store.get(this.id);
			this.dept = Dept.get(this.id);
			this.cash = Cash.get(this.id);
			this.bank = Bank.get(this.id);
			this.user = User.get(this.id);
			this.crew = Crew.get(this.id);
			this.contact = FaceContact.get(this.id);
			this.daily = FaceDaily.get(this.id);
			this.point = Point.get(this.id);
		} catch (Exception ex) {
			WB.addLog("Face.getPart, ex=" + ex.getMessage(), "", "Face");
		}
	}

	public static FaceDto getCurrFA() throws Exception {
		// origin - 23.11.2024, last edit - 13.05.2025
		FaceDto res = new FaceDto();
		try {
			var faceByRole = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter(Role.faceFA), "Face");
			for (var curr : faceByRole) {
				res = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description, curr.geo,
						curr.role, curr.info, curr.more, curr.mark);
				// WB.addLog2("Face.getCurrFA(), curr=" + curr + ", res=" + res,"","Face");
			}
		} catch (Exception ex) {
			WB.addLog("Face.getCurrFA, ex=" + ex.getMessage(), "", "Face");
		}
		return res;
	}

	public void isExist() throws Exception {
		// origin - 27.11.2024, last edit - 13.05.2025
		try {
			var faceByCode = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), this.table);
			for (var currFace : faceByCode) {
				this.code = currFace.code;
				this.parent = currFace.parent;
				this.date1 = currFace.date1;
				this.date2 = currFace.date2;
				this.description = currFace.description;
				this.geo = DefVal.set(currFace.geo, Geo.currCountry.id);
				this.role = currFace.role;
				this.info = currFace.info;
				this.more = currFace.more;
				this.mark = DefVal.set(currFace.mark, Mark.DD);

				this.fullName = MoreVal.getFieldByKey(this.more, "Fullname");
				this.comment = MoreVal.getFieldByKey(this.more, "Comment");
				this.sex = MoreVal.getFieldByKey(this.more, "Sex");

				this.faceId = MoreVal.getFieldByKey(this.more, "FaceId");
				this.storeId = MoreVal.getFieldByKey(this.more, "StoreId");
				this.cashId = MoreVal.getFieldByKey(this.more, "CashId");
				this.paymasterEmpId = MoreVal.getFieldByKey(this.more, "paymasterEmpId");
				this.userId = MoreVal.getFieldByKey(this.more, "UserId");
				this.deptId = MoreVal.getFieldByKey(this.more, "DeptId");
				this.pointId = MoreVal.getFieldByKey(this.more, "PointId");
				this.staffTableId = MoreVal.getFieldByKey(this.more, "StaffTableId");
				this.empId = MoreVal.getFieldByKey(this.more, "EmpId");
				this.crewId = MoreVal.getFieldByKey(this.more, "CrewId");
				this.selfEmpId = MoreVal.getFieldByKey(this.more, "SelfEmpId");

				this.isExist = true;
				break;
			}
		} catch (Exception ex) {
			WB.addLog("Face.isExist, ex=" + ex.getMessage(), "", "Face");
		}
	}

	public String getId(String moreId, String context) throws Exception {
		// origin - 18.08.2024, last edit - 20.03.2025
		String res = "";
		try {
			context = DefVal.set(context, "idIntegerGrowingDigitalGlobal");
			res = new IdGen(moreId, context).id;
		} catch (Exception ex) {
			WB.addLog("Face.getId, ex=" + ex.getMessage(), "", "Face");
		}
		return res;
	}

	public Face(String Id) throws Exception {
		// origin - 05.12.2023, last edit - 01.05.2025
		this.clear();
		this.table = "Face";
		this.src = this.id = this.code = Id;
		this.isExist();
		this.getPart();
	}

	public Face() throws Exception {
		// origin - 05.12.2023, last edit - 01.05.2025
		this.clear();
		this.isExist();
		var root = Abc.getRoot(this.table); // get root from WB.abcLast
		this.id = root.id;
		this.parent = root.parent;
		this.date1 = root.date1;
		this.date2 = root.date2;
		this.code = root.code;
		this.description = root.description;
		this.geo = root.geo;
		this.role = root.role;
		this.info = root.info;
		this.more = root.more;
		this.mark = root.mark;
	}

	public void clear() throws Exception {
		// origin - 25.11.2024, last edit - 13.05.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = this.getClass().getName();
			this.src = this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.geo = this.role = this.info = this.mark = "";

			this.faceId = this.storeId = this.cashId = this.paymasterEmpId = this.userId = this.deptId = this.pointId = this.staffTableId = this.empId = this.crewId = this.selfEmpId = "";
			this.fullName = this.comment = this.sex = "";

			this.address = new ArrayList<FaceDto>();
			this.staffTable = new ArrayList<FaceDto>();
			this.staff = new ArrayList<FaceDto>();
			this.store = new ArrayList<FaceDto>();
			this.dept = new ArrayList<FaceDto>();
			this.cash = new ArrayList<FaceDto>();
			this.bank = new ArrayList<FaceDto>();
			this.user = new ArrayList<FaceDto>();
			this.crew = new ArrayList<FaceDto>();
			this.contact = new ArrayList<FaceDto>();
			this.daily = new ArrayList<FaceDto>();
			this.point = new ArrayList<FaceDto>();

			this.jobCycle = new JobCycle();

		} catch (Exception ex) {
			WB.addLog("Face.clear, ex=" + ex.getMessage(), "", "Face");
		}
	}

	public String toString() {
		// origin - 24.11.2023, last edit - 13.05.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addIfNotEmpty(", fullname ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", sex ", this.sex);

			res = res + Fmtr.addIfNotEmpty(", faceId ", this.faceId);
			res = res + Fmtr.addIfNotEmpty(", storeId ", this.storeId);
			res = res + Fmtr.addIfNotEmpty(", cashId ", this.cashId);
			res = res + Fmtr.addIfNotEmpty(", paymasterEmpIdId ", this.paymasterEmpId);
			res = res + Fmtr.addIfNotEmpty(", userId ", this.userId);
			res = res + Fmtr.addIfNotEmpty(", deptId ", this.deptId);
			res = res + Fmtr.addIfNotEmpty(", pointId ", this.pointId);
			res = res + Fmtr.addIfNotEmpty(", staffTableId ", this.staffTableId);
			res = res + Fmtr.addIfNotEmpty(", empId ", this.empId);
			res = res + Fmtr.addIfNotEmpty(", crewId ", this.crewId);
			res = res + Fmtr.addIfNotEmpty(", selfEmpId ", this.selfEmpId);

			res = res + Fmtr.addIfNotEmpty(", staffTable ", this.staffTable.size());
			res = res + Fmtr.addIfNotEmpty(", staff ", this.staff.size());
			res = res + Fmtr.addIfNotEmpty(", address ", this.address.size());
			res = res + Fmtr.addIfNotEmpty(", store ", this.store.size());
			res = res + Fmtr.addIfNotEmpty(", dept ", this.dept.size());
			res = res + Fmtr.addIfNotEmpty(", cash ", this.cash.size());
			res = res + Fmtr.addIfNotEmpty(", bank ", this.bank.size());
			res = res + Fmtr.addIfNotEmpty(", user ", this.user.size());
			res = res + Fmtr.addIfNotEmpty(", contact ", this.contact.size());
			res = res + Fmtr.addIfNotEmpty(", daily ", this.daily.size());

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 14.05.2025
		try {

			// test getId(String,String)
			WB.addLog2("Face.test.getId(String,String)", "", "Face");
			WB.addLog2("Face.test.getId('', ''), res=" + new IdGen("", "").id, "", "Face");
			for (var tmp1 : new String[] { "FaceId", "StoreId", "EmpId" }) {
				for (var tmp2 : new String[] { "idIntegerGrowingDigitalGlobal", "idStringGrowingDigitalGlobal",
						"idStringGrowingDigitalInfobase" }) {
					WB.addLog2("Face.test.getId(" + tmp1 + "," + tmp2 + "), res=" + new IdGen(tmp1, tmp2).id, "",
							"Face");
				}
			}

//			// test ctor(String)
//			WB.addLog2("Face.test.ctor(String)", "", "Face");
//			for (var tmp1 : new String[] { "Face.FA1", "Face.Person.Template", "Face.FA1.AdmStaff", "Face.kgd" }) {
//				WB.addLog2("Face.test.ctor(String)=" + new Face(tmp1), "", "Face");
//			}

		} catch (Exception ex) {
			WB.addLog("Face.test, ex=" + ex.getMessage(), "", "Face");
		}
	}
}