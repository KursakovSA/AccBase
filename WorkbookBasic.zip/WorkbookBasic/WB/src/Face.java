import java.util.List;

public class Face extends ModelDto {
	// origin - 28.09.2023, last edit - 04.08.2024
	public List<ModelDto> store; // TODO
	public List<ModelDto> department; // TODO
	public List<ModelDto> cash; // TODO
	public List<ModelDto> bank; // TODO
	public List<ModelDto> staffTable; // TODO

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Face.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Face");
		} finally {
			Etc.doNothing();
		}
	}

	public Face(String Id, String Code, String Description) throws Exception {
		// origin - 05.12.2023, last edit - 04.08.2024
		super(Id, Code, Description);
	}

	public Face() throws Exception {
		// origin - 05.12.2023, last edit - 04.08.2024
		super();
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 06.07.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Face.test, ex=" + ex.getMessage(), WB.strEmpty, "Face");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Conn.test end ", WB.strEmpty, "Conn");
	}
}
