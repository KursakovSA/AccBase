import java.util.ArrayList;
import java.util.List;

public class Face extends ModelDto {
	// origin - 28.09.2023, last edit - 06.10.2024
	public String faceId = WB.strEmpty; // TODO //ex. [IB1][2024-09-27T06:56:36][#85021], but this is not dto.id
	public String storeId = WB.strEmpty; // TODO //ex. [IB1][2024-09-27T06:56:36][#85021], but this is not dto.id
	public String cashId = WB.strEmpty; // TODO //ex. [IB1][2024-09-27T06:56:36][#85021], but this is not dto.id
//	public String userId; // TODO //ex. [IB1][2024-09-27T06:56:36][#85021], but this is not dto.id
//	public String empId; // TODO //ex. [IB1][2024-09-27T06:56:36][#85021], but this is not dto.id
//	public String outsideEmpId; // TODO //ex. [IB1][2024-09-27T06:56:36][#85021], but this is not dto.id

	public List<ModelDto> store = new ArrayList<ModelDto>(); // TOTHINK
	public List<ModelDto> department = new ArrayList<ModelDto>(); // TOTHINK
	public List<ModelDto> cash = new ArrayList<ModelDto>(); // TOTHINK
	public List<ModelDto> bank = new ArrayList<ModelDto>(); // TOTHINK
	public List<ModelDto> staffTable = new ArrayList<ModelDto>(); // TOTHINK

	// ??public List<CompositeVal> store; // TOTHINK
	// ??public List<CompositeVal> department; // TOTHINK
	// ??public List<CompositeVal> cash; // TOTHINK
	// ??public List<CompositeVal> bank; //compositeVal = "12345KZ434 / Jusan bank /
	// г.Астана"
	// ??public List<CompositeVal> staffTable; // TOTHINK

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Face.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Face");
		} finally {
			Etc.doNothing();
		}
	}

	public String getId(String moreId, String context) throws Exception {
		// origin - 18.08.2024, last edit - 29.09.2024
		String res = WB.strEmpty;
		try {
			context = DefVal.set(context, "idIntegerGrowingDigitalGlobal");
			res = new IdGen(moreId, context).id;
		} catch (Exception ex) {
			WB.addLog("Face.getId, ex=" + ex.getMessage(), WB.strEmpty, "Face");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Face.getId, res=" + res, WB.strEmpty, "Face");
		return res;
	}

	public Face(String Id, String Code, String Description) throws Exception {
		// origin - 05.12.2023, last edit - 11.08.2024
		super(Id, Code, Description);
		this.table = this.getClass().getName();
	}

	public Face() throws Exception {
		// origin - 05.12.2023, last edit - 11.08.2024
		super();
		this.table = this.getClass().getName();
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 29.09.2024
		try {

			// getId
			// LocalDateTime localStart = WB.getLocalStart();
			Face newFace = new Face();
			WB.addLog2("Face.getId(), res=" + newFace.getId(), WB.strEmpty, "Face");
			WB.addLog2("Face.getId('', ''), res=" + newFace.getId("", ""), WB.strEmpty, "Face");
			WB.addLog2("Face.getId('EmpId', ''), res=" + newFace.getId("EmpId", ""), WB.strEmpty, "Face");
			WB.addLog2("Face.getId('EmpId', 'idStringGrowingDigitalInfobase'), res="
					+ newFace.getId("EmpId", "idStringGrowingDigitalInfobase"), WB.strEmpty, "Deal");
			WB.addLog2("Face.getId('EmpId', 'idStringGrowingDigitalGlobal'), res="
					+ newFace.getId("EmpId", "idStringGrowingDigitalGlobal"), WB.strEmpty, "Face");
			WB.addLog2("Face.getId('EmpId', 'idIntegerGrowingDigitalGlobal'), res="
					+ newFace.getId("EmpId", "idIntegerGrowingDigitalGlobal"), WB.strEmpty, "Face");
			WB.addLog2("Face.getId('FaceId', ''), res=" + newFace.getId("FaceId", ""), WB.strEmpty, "Face");
			WB.addLog2("Face.getId('FaceId', 'idStringGrowingDigitalInfobase'), res="
					+ newFace.getId("FaceId", "idStringGrowingDigitalInfobase"), WB.strEmpty, "Deal");
			WB.addLog2("Face.getId('FaceId', 'idStringGrowingDigitalGlobal'), res="
					+ newFace.getId("FaceId", "idStringGrowingDigitalGlobal"), WB.strEmpty, "Face");
			WB.addLog2("Face.getId('FaceId', 'idIntegerGrowingDigitalGlobal'), res="
					+ newFace.getId("FaceId", "idIntegerGrowingDigitalGlobal"), WB.strEmpty, "Face");
			// WB.getLocalEnd("Face.test.getId", localStart);

		} catch (Exception ex) {
			WB.addLog("Face.test, ex=" + ex.getMessage(), WB.strEmpty, "Face");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Face.test end ", WB.strEmpty, "Face");
	}
}
