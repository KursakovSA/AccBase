import java.util.ArrayList;
import java.util.List;

public class Face extends ModelDto {
	// origin - 28.09.2023, last edit - 31.03.2025
	public static FaceDto currFA;
	public String faceId, storeId, cashId, userId, depId, staffTableId; // ex. storeId="001", faceId="ALFTN",
																				// etc.
	public String address; // quick address, less kind, maybe with tel, etc.
	public List<FaceDto> storeNote, departmentNote, cashNote, bankNote, userNote, staffNote, crew;
	// public List<FaceSalaryNote> salaryNote;
	public List<StaffTable> staffTableNote;
	public List<Address> addressNote;

	static {
		try {
			Face.currFA = Face.getCurrFA();
			// WB.addLog2("Face.currFA=" + Face.currFA, "", "Face");
		} catch (Exception ex) {
			WB.addLog("Face.static ctor, ex=" + ex.getMessage(), "", "Face");
		}
	}

//	public static FaceDto getCurrPart(String date1, List<FaceDto> listFaceDto) throws Exception { // TODO
//		// origin - 08.03.2025, last edit - 20.03.2025
//		FaceDto res = new FaceDto();
//		try {
//			var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), listFaceDto, Info.genericBasic);
//			if (curr.id.isEmpty() == false) {
//				res = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description, curr.geo,
//						curr.role, curr.info, curr.more, curr.mark);
//			}
//		} catch (Exception ex) {
//			WB.addLog("Face.getCurrPart, ex=" + ex.getMessage(), "", "Face");
//		}
//		return res;
//	}

	private void getPart() throws Exception {
		// origin - 06.03.2025, last edit - 28.03.2025
		try {
			var faceByParent = DAL.getByTemplate(WB.lastConnWork, Qry.getParentFilter(this.id), this.table);
			for (var curr : faceByParent) {
				switch (curr.role) {
				case "Role.Face.Address" -> this.addressNote.add(new Address(curr.parent, curr.id));
				// case "Role.Face.Salary" -> this.salaryNote.add(new
				// FaceSalaryNote(curr.parent, curr.id));
				case "Role.Face.StaffTable" -> this.staffTableNote.add(new StaffTable(curr.parent, curr.id));
				case "Role.Face.Staff" -> this.staffNote.add(new FaceDto(curr));
				case "Role.Store.Basic" -> this.storeNote.add(new FaceDto(curr));
				case "Role.Store.Department" -> this.departmentNote.add(new FaceDto(curr));
				case "Role.Store.Cash" -> this.cashNote.add(new FaceDto(curr));
				case "Role.Store.Bank" -> this.bankNote.add(new FaceDto(curr));
				case "Role.Face.User" -> this.userNote.add(new FaceDto(curr));
				}
			}
		} catch (Exception ex) {
			WB.addLog("Face.getPart, ex=" + ex.getMessage(), "", "Face");
		}
	}

	public void fix() throws Exception {
		// origin - 29.12.2024, last edit - 20.03.2025
		try {
			super.fix();
			this.geo = DefVal.set(this.geo, Geo.currCountry.id);
			this.mark = DefVal.set(this.mark, Mark.DD);
		} catch (Exception ex) {
			WB.addLog("Face.fix, ex=" + ex.getMessage(), "", "Face");
		}
	}

	public static FaceDto getCurrFA() throws Exception {
		// origin - 23.11.2024, last edit - 20.03.2025
		FaceDto res = new FaceDto();
		try {
			var faceByRole = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter(Role.faceFA), "Face");
			for (var curr : faceByRole) {
				res = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description, curr.geo,
						curr.role, curr.info, curr.more, curr.mark);
				// WB.addLog2("Face.getCurrFA(), curr.id=" + curr.id + ", res=" + res,"",
				// "Face");
			}
		} catch (Exception ex) {
			WB.addLog("Face.getCurrFA, ex=" + ex.getMessage(), "", "Face");
		}
		return res;
	}

	public void isExist() throws Exception {
		// origin - 27.11.2024, last edit - 31.03.2025
		super.isExist();
		try {
			var faceByCode = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), this.table);
			for (var currFace : faceByCode) {
				if (Etc.strEquals(currFace.id, this.id)) {
					this.code = currFace.code;
					this.parent = currFace.parent;
					this.date1 = currFace.date1;
					this.date2 = currFace.date2;
					this.description = currFace.description;
					this.geo = currFace.geo;
					this.role = currFace.role;
					this.info = currFace.info;
					this.more = currFace.more;
					this.mark = currFace.mark;

					this.faceId = MoreVal.getFieldByKey(this.more, "FaceId");
					this.storeId = MoreVal.getFieldByKey(this.more, "StoreId");
					this.cashId = MoreVal.getFieldByKey(this.more, "CashId");
					this.userId = MoreVal.getFieldByKey(this.more, "UserId");
					this.depId = MoreVal.getFieldByKey(this.more, "DepId");

					this.isExist = true;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Face.isExist, ex=" + ex.getMessage(), "", "Face");
		}
	}

	public void isValid() throws Exception {
		// origin - 27.11.2024, last edit - 20.03.2025
		try {
			if (this.parent.isEmpty() || this.role.isEmpty() || this.info.isEmpty() || this.mark.isEmpty()) {
				this.isValid = false;
			}
		} catch (Exception ex) {
			WB.addLog("Face.isValid, ex=" + ex.getMessage(), "", "Face");
		}
	}

	public String getId(String moreId, String context) throws Exception {
		// origin - 18.08.2024, last edit - 20.03.2025
		String res = "";
		try {
			context = DefVal.set(context, "idIntegerGrowingDigitalGlobal");
			res = new IdGen(moreId, context).id;
		} catch (Exception ex) {
			WB.addLog("Face.getId, ex=" + ex.getMessage(), "", "Face");
		}
		return res;
	}

	public Face(String Id) throws Exception {
		// origin - 05.12.2023, last edit - 07.03.2025
		this();
		this.src = this.id = this.code = Id;
		this.isExist();
		this.getPart();
		this.isValid();
		this.fix();
	}

	public Face() throws Exception {
		// origin - 05.12.2023, last edit - 05.03.2025
		this.clear();
		this.isExist();
		var root = Abc.getRoot(this.table); // get root from WB.abcLast
		this.id = root.id;
		this.parent = root.parent;
		this.date1 = root.date1;
		this.date2 = root.date2;
		this.code = root.code;
		this.description = root.description;
		this.geo = root.geo;
		this.role = root.role;
		this.info = root.info;
		this.more = root.more;
		this.mark = root.mark;
		this.fix();
	}

	public void clear() throws Exception {
		// origin - 25.11.2024, last edit - 31.03.2025
		try {
			super.clear();
			this.table = this.getClass().getName();
			this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.more = "";
			this.geo = this.role = this.info = this.mark = "";
			this.faceId = this.storeId = this.cashId = this.userId = "";
			this.storeNote = new ArrayList<FaceDto>();
			this.cashNote = new ArrayList<FaceDto>();
			this.bankNote = new ArrayList<FaceDto>();
			this.userNote = new ArrayList<FaceDto>();
			this.departmentNote = new ArrayList<FaceDto>();
			this.staffTableNote = new ArrayList<StaffTable>();
			this.staffNote = new ArrayList<FaceDto>();
			// this.salaryNote = new ArrayList<FaceSalaryNote>();
			this.addressNote = new ArrayList<Address>();
		} catch (Exception ex) {
			WB.addLog("Face.clear, ex=" + ex.getMessage(), "", "Face");
		}
	}

	public String toString() {
		// origin - 24.11.2023, last edit - 31.03.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addIfNotEmpty(", faceId ", this.faceId);
			res = res + Fmtr.addIfNotEmpty(", storeId ", this.storeId);
			res = res + Fmtr.addIfNotEmpty(", cashId ", this.cashId);
			res = res + Fmtr.addIfNotEmpty(", userId ", this.userId);

			res = res + Fmtr.addIfNotEmpty(", staffTableNote.size ", this.staffTableNote.size());
			res = res + Fmtr.addIfNotEmpty(", staffNote.size ", this.staffNote.size());
			// res = res + Fmtr.addIfNotEmpty(", salaryNote.size ", this.salaryNote.size());
			res = res + Fmtr.addIfNotEmpty(", addressNote.size ", this.addressNote.size());
			res = res + Fmtr.addIfNotEmpty(", storeNote.size ", this.storeNote.size());
			res = res + Fmtr.addIfNotEmpty(", departmentNote.size ", this.departmentNote.size());
			res = res + Fmtr.addIfNotEmpty(", cashNote.size ", this.cashNote.size());
			res = res + Fmtr.addIfNotEmpty(", bankNote.size ", this.bankNote.size());
			res = res + Fmtr.addIfNotEmpty(", userNote.size ", this.userNote.size());

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 20.03.2025
		try {

//			// getCurrPart //TODO
//			for (var tmp1 : new String[] { "2024-01-31", "2025-01-31" }) {
//				for (var tmp2 : new String[] { "Face.FA1", "Face.tralala", "Face.kgd" }) {
//					WB.addLog2("Face.test.getCurrPart(bankNote)=" + Face.getCurrPart(tmp1, new Face(tmp2).bankNote).id
//							+ ", date1=" + tmp1 + ", id=" + tmp2, "", "Face");
//					WB.addLog2("Face.test.getCurrPart(cashNote)=" + Face.getCurrPart(tmp1, new Face(tmp2).cashNote).id
//							+ ", date1=" + tmp1 + ", id=" + tmp2, "", "Face");
//					WB.addLog2("Face.test.getCurrPart(storeNote)=" + Face.getCurrPart(tmp1, new Face(tmp2).storeNote).id
//							+ ", date1=" + tmp1 + ", id=" + tmp2, "", "Face");
//					WB.addLog2("Face.test.getCurrPart(userNote)=" + Face.getCurrPart(tmp1, new Face(tmp2).userNote).id
//							+ ", date1=" + tmp1 + ", id=" + tmp2, "", "Face");
//				}
//			}

			// ctor (String)
			for (var tmp1 : new String[] { "Face.FA1", "Face.tralala", "Face.kgd" }) {
				WB.addLog2("Face.test.ctor(String)=" + new Face(tmp1), "", "Face");
			}

		} catch (Exception ex) {
			WB.addLog("Face.test, ex=" + ex.getMessage(), "", "Face");
		}
	}
}