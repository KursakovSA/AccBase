import java.util.ArrayList;
import java.util.List;

public class Face extends ModelDto {
	// origin - 28.09.2023, last edit - 15.12.2024

	public static Face currFA;
	public static String roleFA;
	public String faceId, storeId, cashId;
	public List<Face> store, department, cash, bank, staffTable;

	static {
		try {
			Face.roleFA = "Role.Face.FA";
			Face.currFA = Face.getCurrFA();
			// WB.addLog2("Face.currFA=" + Face.currFA, WB.strEmpty, "Face");
		} catch (Exception ex) {
			WB.addLog("Face.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Face");
		} finally {
			Etc.doNothing();
		}
	}

	public static Face getCurrFA() throws Exception {
		// origin - 23.11.2024, last edit - 27.11.2024
		Face res = new Face();
		try {
			for (var seeFA : WB.abcLast.FA) {
				if (Etc.strEquals(seeFA.role, Face.roleFA)) {
					res = new Face(seeFA.id);
				}
			}
		} catch (Exception ex) {
			WB.addLog("Face.getCurrFA, ex=" + ex.getMessage(), WB.strEmpty, "Face");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Face.getCurrFA, res=" + res, WB.strEmpty, "Face");
		return res;
	}

	public void isExist() throws Exception {
		// origin - 27.11.2024, last edit - 15.12.2024
		super.isExist();
		try {
			var faceByCode = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), this.table);
			for (var currFace : faceByCode) {
				if (Etc.strEquals(currFace.id, this.id)) {
					this.code = currFace.code;
					this.parent = currFace.parent;
					this.date1 = currFace.date1;
					this.date2 = currFace.date2;
					this.description = currFace.description;
					this.geo = currFace.geo;
					this.role = currFace.role;
					this.info = currFace.info;
					this.more = currFace.more;
					this.mark = currFace.mark;

					this.faceId = MoreVal.getFieldByKey(this.more, "FaceId");
					this.storeId = MoreVal.getFieldByKey(this.more, "StoreId");
					this.cashId = MoreVal.getFieldByKey(this.more, "CashId");

					// fill - store, department, cash, bank, staffTable \\TODO

					this.isExist = true;
					break;
				}
			}

		} catch (Exception ex) {
			WB.addLog("Face.isExist, ex=" + ex.getMessage(), WB.strEmpty, "Face");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Face.isExist=" + this.isExist, WB.strEmpty,"Face");
	}

	public void isValid() throws Exception {
		// origin - 27.11.2024, last edit - 11.12.2024
		try {
			if (this.parent.isEmpty() | this.role.isEmpty() | this.info.isEmpty() | this.mark.isEmpty()) {
				this.isValid = false;
			}
		} catch (Exception ex) {
			WB.addLog("Face.isValid, ex=" + ex.getMessage(), WB.strEmpty, "Face");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Face.isValid=" + this.isValid,WB.strEmpty,"Face");
	}

	public String getId(String moreId, String context) throws Exception {
		// origin - 18.08.2024, last edit - 29.09.2024
		String res = WB.strEmpty;
		try {
			context = DefVal.set(context, "idIntegerGrowingDigitalGlobal");
			res = new IdGen(moreId, context).id;
		} catch (Exception ex) {
			WB.addLog("Face.getId, ex=" + ex.getMessage(), WB.strEmpty, "Face");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Face.getId, res=" + res, WB.strEmpty, "Face");
		return res;
	}

	public Face(String Id) throws Exception {
		// origin - 05.12.2023, last edit - 15.12.2024
		this();
		this.src = Id;
		this.id = Id;
		this.isExist();
		this.isValid();
	}

	public Face() throws Exception {
		// origin - 05.12.2023, last edit - 30.11.2024
		this.clear();
		this.isExist();
		var root = Abc.getRoot(this.table); // get root from WB.abcLast
		this.id = root.id;
		this.parent = root.parent;
		this.date1 = root.date1;
		this.date2 = root.date2;
		this.code = root.code;
		this.description = root.description;
		this.geo = root.geo;
		this.role = root.role;
		this.info = root.info;
		this.more = root.more;
		this.mark = root.mark;
	}

	public void clear() throws Exception {
		// origin - 25.11.2024, last edit - 28.11.2024
		try {
			super.clear();
			this.table = this.getClass().getName();
			this.faceId = this.storeId = this.cashId = WB.strEmpty;
			this.store = this.department = this.cash = this.bank = this.staffTable = new ArrayList<Face>();
		} catch (Exception ex) {
			WB.addLog("Face.clear, ex=" + ex.getMessage(), WB.strEmpty, "Face");
		} finally {
			Etc.doNothing();
		}
	}

	public String toString() {
		// origin - 24.11.2023, last edit - 05.12.2024
		String res = WB.strEmpty;
		try {
			res = res + Fmtr.addIfNotEmpty("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addIfNotEmpty(", faceId ", this.faceId);
			res = res + Fmtr.addIfNotEmpty(", storeId ", this.storeId);
			res = res + Fmtr.addIfNotEmpty(", cashId ", this.cashId);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 15.12.2024
		try {

//			// ctor()
//			WB.addLog2("Face.test.ctor()=" + new Face(), WB.strEmpty, "Face");
//			// ctor (String Id)
//			for (var tmp : new Face[] { new Face("Face.FA1"), new Face("Face.tralala"), new Face("Face.kgd") }) {
//				WB.addLog2("Face.test.ctor(String Id)=" + new Face(tmp.id), WB.strEmpty, "Face");
//			}

//			// getId
//			WB.addLog2("Face.getId()=" + new Face().getId(), WB.strEmpty, "Face");
//			WB.addLog2("Face.getId('', '')=" + new Face().getId("", ""), WB.strEmpty, "Face");
//			WB.addLog2("Face.getId('EmpId', '')=" + new Face().getId("EmpId", ""), WB.strEmpty, "Face");
//			WB.addLog2("Face.getId('EmpId', 'idStringGrowingDigitalInfobase')="
//					+ new Face().getId("EmpId", "idStringGrowingDigitalInfobase"), WB.strEmpty, "Deal");
//			WB.addLog2("Face.getId('EmpId', 'idStringGrowingDigitalGlobal')="
//					+ new Face().getId("EmpId", "idStringGrowingDigitalGlobal"), WB.strEmpty, "Face");
//			WB.addLog2("Face.getId('EmpId', 'idIntegerGrowingDigitalGlobal')="
//					+ new Face().getId("EmpId", "idIntegerGrowingDigitalGlobal"), WB.strEmpty, "Face");
//			WB.addLog2("Face.getId('FaceId', '')=" + new Face().getId("FaceId", ""), WB.strEmpty, "Face");
//			WB.addLog2("Face.getId('FaceId', 'idStringGrowingDigitalInfobase')="
//					+ new Face().getId("FaceId", "idStringGrowingDigitalInfobase"), WB.strEmpty, "Deal");
//			WB.addLog2("Face.getId('FaceId', 'idStringGrowingDigitalGlobal')="
//					+ new Face().getId("FaceId", "idStringGrowingDigitalGlobal"), WB.strEmpty, "Face");
//			WB.addLog2("Face.getId('FaceId', 'idIntegerGrowingDigitalGlobal')="
//					+ new Face().getId("FaceId", "idIntegerGrowingDigitalGlobal"), WB.strEmpty, "Face");

		} catch (Exception ex) {
			WB.addLog("Face.test, ex=" + ex.getMessage(), WB.strEmpty, "Face");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Face.test end ", WB.strEmpty, "Face");
	}
}
