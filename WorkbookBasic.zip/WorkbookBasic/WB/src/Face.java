import java.util.ArrayList;
import java.util.List;

public class Face extends ModelDto {
	// origin - 28.09.2023, last edit - 25.11.2024
	public static Face currFA;
	public String faceId, storeId, cashId;
	public List<Face> store, department, cash, bank, staffTable;

	static {
		try {
			Face.currFA = Face.getCurrFA();
		} catch (Exception ex) {
			WB.addLog("Face.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Face");
		} finally {
			Etc.doNothing();
		}
	}

	public static Face getCurrFA() throws Exception {
		// origin - 23.11.2024, last edit - 24.11.2024
		Face res = new Face();
		try {
			for (var seeFA : WB.abcLast.FA) {
				if (Etc.strEquals(seeFA.role, "Role.Face.FA")) {
					res = new Face(seeFA.id, seeFA.code, seeFA.description);
				}
			}
		} catch (Exception ex) {
			WB.addLog("Face.getCurrFA, ex=" + ex.getMessage(), WB.strEmpty, "Face");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Face.getCurrFA, res=" + res, WB.strEmpty, "Face");
		return res;
	}

	public String getId(String moreId, String context) throws Exception {
		// origin - 18.08.2024, last edit - 29.09.2024
		String res = WB.strEmpty;
		try {
			context = DefVal.set(context, "idIntegerGrowingDigitalGlobal");
			res = new IdGen(moreId, context).id;
		} catch (Exception ex) {
			WB.addLog("Face.getId, ex=" + ex.getMessage(), WB.strEmpty, "Face");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Face.getId, res=" + res, WB.strEmpty, "Face");
		return res;
	}

//	public Face(ModelDto In) throws Exception {
//		// origin - 05.12.2023, last edit - 25.11.2024
//		this();
//		// super(In); // ??
//	}

	public Face(String Id, String Code, String Description) throws Exception {//TODO
		// origin - 05.12.2023, last edit - 25.11.2024
		this();
		this.id = Id;
		this.code = Code;
		this.description = Description;
	}

	public Face() throws Exception {
		// origin - 05.12.2023, last edit - 25.11.2024
		this.clear();
	}

	public void clear() throws Exception {
		// origin - 25.11.2024, last edit - 25.11.2024
		try {
			super.clear();
			this.table = this.getClass().getName();
			this.faceId = this.storeId = this.cashId = WB.strEmpty;
			this.store = this.department = this.cash = this.bank = this.staffTable = new ArrayList<Face>();
		} catch (Exception ex) {
			WB.addLog("ModelDto.clear, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
	}

	public String toString() {
		// origin - 24.11.2023, last edit - 25.11.2024
		String res = WB.strEmpty;
		try {
			res = WB.strBraceLeft + this.table + WB.strCommaSpace + this.id + WB.strCommaSpace + this.parent
					+ WB.strCommaSpace + this.date1 + WB.strCommaSpace + this.date2 + WB.strCommaSpace + this.code
					+ WB.strCommaSpace + this.description + WB.strCommaSpace + this.geo + WB.strCommaSpace + this.role
					+ WB.strCommaSpace + this.info + WB.strCommaSpace + this.more + WB.strCommaSpace + this.mark
					+ WB.strBraceRight;
		} catch (Exception ex) {
			// WB.addLog2("Face.toString, ex=" + ex.getMessage(), WB.strEmpty, "Face");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 25.11.2024
		try {

			// ctor()
			WB.addLog2("Face.test.ctor()=" + new Face(), WB.strEmpty, "Face");

//			// getId
//			WB.addLog2("Face.getId()=" + new Face().getId(), WB.strEmpty, "Face");
//			WB.addLog2("Face.getId('', '')=" + new Face().getId("", ""), WB.strEmpty, "Face");
//			WB.addLog2("Face.getId('EmpId', '')=" + new Face().getId("EmpId", ""), WB.strEmpty, "Face");
//			WB.addLog2("Face.getId('EmpId', 'idStringGrowingDigitalInfobase')="
//					+ new Face().getId("EmpId", "idStringGrowingDigitalInfobase"), WB.strEmpty, "Deal");
//			WB.addLog2("Face.getId('EmpId', 'idStringGrowingDigitalGlobal')="
//					+ new Face().getId("EmpId", "idStringGrowingDigitalGlobal"), WB.strEmpty, "Face");
//			WB.addLog2("Face.getId('EmpId', 'idIntegerGrowingDigitalGlobal')="
//					+ new Face().getId("EmpId", "idIntegerGrowingDigitalGlobal"), WB.strEmpty, "Face");
//			WB.addLog2("Face.getId('FaceId', '')=" + new Face().getId("FaceId", ""), WB.strEmpty, "Face");
//			WB.addLog2("Face.getId('FaceId', 'idStringGrowingDigitalInfobase')="
//					+ new Face().getId("FaceId", "idStringGrowingDigitalInfobase"), WB.strEmpty, "Deal");
//			WB.addLog2("Face.getId('FaceId', 'idStringGrowingDigitalGlobal')="
//					+ new Face().getId("FaceId", "idStringGrowingDigitalGlobal"), WB.strEmpty, "Face");
//			WB.addLog2("Face.getId('FaceId', 'idIntegerGrowingDigitalGlobal')="
//					+ new Face().getId("FaceId", "idIntegerGrowingDigitalGlobal"), WB.strEmpty, "Face");

		} catch (Exception ex) {
			WB.addLog("Face.test, ex=" + ex.getMessage(), WB.strEmpty, "Face");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Face.test end ", WB.strEmpty, "Face");
	}
}
