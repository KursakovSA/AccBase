public final class JobTerm {
	// origin - 25.08.2025, last edit - 28.01.2026
	// common fields
	public String table, src, id, parent, face1, face2, face, date1, date2, code, description, geo, role, info, more,
			mark, defect;
	// special fields
	public String fullName, comment, templateId, termId;
	public DurationTerm durationTerm;
	public TemplateDocTerm templateDocTerm;
	public AddTerm addTerm;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("JobTerm.static ctor, ex=" + ex.getMessage(), "", "JobTerm");
		}
	}

	private void validate() throws Exception { // TODO
		// origin - 20.11.2025, last edit - 23.05.2026
		try {
			this.defect = Fmtr.addIfStrEmpty(this.defect, this.termId, "empty termId; ");
			this.defect = Fmtr.addIfStrEmpty(this.defect, this.templateId, "empty templateId; ");
//			if (this.durationTerm.defect.isEmpty() == false) {
//				this.defect = this.defect + "empty durationTerm; ";
//			}
		} catch (Exception ex) {
			WB.addLog("JobTerm.validate():void, ex=" + ex.getMessage(), "", "JobTerm");
		}
	}

	private void isExist() throws Exception {
		// origin - 25.08.2025, last edit - 20.11.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentCodeRoleFilter(this.parent, this.code, "Role.Face.JobTerm"), "Face");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.code = dto.code;
				this.parent = dto.parent;
				this.face1 = dto.face1;
				this.face2 = dto.face2;
				this.face = dto.face;
				this.description = dto.description;
				this.geo = dto.geo;
				this.role = dto.role;
				this.info = dto.info;
				this.more = dto.more;
				this.mark = dto.mark;
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("JobTerm.isExist():void, ex=" + ex.getMessage(), "", "JobTerm");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 30.08.2025, last edit - 28.01.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.templateId = MoreVal.getFieldByKey(this.more, "TemplateId");
			this.termId = MoreVal.getFieldByKey(this.more, "TermId");
			this.durationTerm = new DurationTerm(this.termId);
			this.templateDocTerm = new TemplateDocTerm(this.templateId);
			this.addTerm = new AddTerm(this.termId);
		} catch (Exception ex) {
			WB.addLog("JobTerm.getFieldFromMore():void, ex=" + ex.getMessage(), "", "JobTerm");
		}
	}

	public JobTerm(String Parent, String Id) throws Exception {
		// origin - 25.08.2025, last edit - 20.11.2025
		this.clear();
		this.src = Parent + "," + Id;
		this.parent = Parent;
		this.id = this.code = Id;
		this.isExist();
		this.validate();
	}

	public JobTerm() throws Exception {
		// origin - 25.08.2025, last edit - 25.08.2025
		this.clear();
	}

	public String toString() {
		// origin - 25.08.2025, last edit - 28.01.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(" fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(" comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(" templateId ", this.templateId);
			res = res + Fmtr.addIfNotEmpty(" termId ", this.termId);
			res = res + Fmtr.addIfNotEmpty(", durationTerm ", this.durationTerm);
			res = res + Fmtr.addIfNotEmpty(", addTerm.addTerm.decription ", this.addTerm.description);
			res = res + Fmtr.addIfNotEmpty(", templateDocTerm.id ", this.templateDocTerm.id);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	private void clear() throws Exception {
		// origin - 25.08.2025, last edit - 28.01.2026
		try {
			this.table = "Face";
			this.src = this.id = this.parent = this.date1 = this.date2 = this.face1 = this.face2 = this.face = this.code = this.description = "";
			this.geo = this.role = this.info = this.more = this.mark = this.defect = "";
			this.fullName = this.comment = this.templateId = this.termId = "";
			this.durationTerm = new DurationTerm();
			this.templateDocTerm = new TemplateDocTerm();
			this.addTerm = new AddTerm();
		} catch (Exception ex) {
			WB.addLog("JobTerm.clear():void, ex=" + ex.getMessage(), "", "JobTerm");
		}
	}

	public static void test() throws Exception {
		// origin - 25.08.2025, last edit - 24.08.2026
		try {

//			WB.addLog2("JobTerm.test.ctor(String)", "", "JobTerm");
//			for (var tmp1 : new String[] { "", ",", "Face.FA1.AdmStaff , Face.FA1.AdmStaff.JobTerm",
//					"Face.FA1.Store , Face.FA1.Store.JobTerm" }) {
//				var tmp2 = new NVal(tmp1);
//				WB.addLog2("JobTerm.test.ctor(String)=" + new JobTerm(tmp2.getVal(1), tmp2.getVal(2)), "", "JobTerm");
//			}

		} catch (Exception ex) {
			WB.addLog("JobTerm.test():void, ex=" + ex.getMessage(), "", "JobTerm");
		}
	}
}