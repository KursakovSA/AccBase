import java.util.ArrayList;
import java.util.List;

public final class StaffTable {
	// origin - 09.03.2025, last edit - 14.12.2025
	// common fields
	public String table, src, id, parent, code, description, geo, role, info, more, mark;
	// special fields
	public String deptId, empId, pointId, fullName, comment, defect;
	// special timestamp fields
	public ListVal date1, date2, salary;
	// list common + special + timestamp fields in unified val
	public List<FaceDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("StaffTable.static ctor, ex=" + ex.getMessage(), "", "StaffTable");
		}
	}

	// for person total salary for all staff position on date1
	public static double getTotalCurrSalary(String date1, String parentId) throws Exception {
		// origin - 04.10.2025, last edit - 04.10.2025
		double res = 0.00;
		try {
			var listDto = StaffTable.getCurr(date1, parentId);
			for (var currStaff : listDto) {
				res = res + Conv.getDouble(currStaff.salary);
			}
		} catch (Exception ex) {
			WB.addLog("StaffTable.getCurrTotalSalary(2String):double, ex=" + ex.getMessage(), "", "StaffTable");
		}
		return res;
	}

	// full list StaffTable.empId on date1
	public static List<String> getCurrEmpId(String date1, String parentFAId) throws Exception {
		// origin - 22.04.2025, last edit - 30.09.2025
		List<String> res = new ArrayList<String>();
		try {
			var staffTable = StaffTable.getCurr(date1, parentFAId);
			for (var curr : staffTable) {
				if (curr.empId.isEmpty() == false) {
					res.add(curr.empId);
				}
			}
		} catch (Exception ex) {
			WB.addLog("StaffTable.getCurrEmpId(2String):List<String>, ex=" + ex.getMessage(), "", "StaffTable");
		}
		return res;
	}

	// item StaffTable position salary on date1
	public static double getCurrSalary(String date1, String parentId, String staffTableId) throws Exception {
		// origin - 28.03.2025, last edit - 04.10.2025
		double res = 0.00;
		try {
			var tmp = StaffTable.getCurr(date1, parentId, staffTableId).salary;
			res = Conv.getDouble(tmp);
		} catch (Exception ex) {
			WB.addLog("StaffTable.getCurrSalary(3String):double, ex=" + ex.getMessage(), "", "StaffTable");
		}
		return res;
	}

	// full list StaffTable
	public static List<FaceDto> get() throws Exception {
		// origin - 26.06.2025, last edit - 26.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter("Role.Face.StaffTable"), "Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					for (var curr : new StaffTable(currFace.parent, currFace.code).val) {
						if (curr.id.isEmpty() == false) {
							res.add(curr);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("StaffTable.get():List<FaceDto>, ex=" + ex.getMessage(), "", "StaffTable");
		}
		return res;
	}

	// StaffTable for select parentId
	public static List<FaceDto> get(String parentId) throws Exception {
		// origin - 04.05.2025, last edit - 26.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, "Role.Face.StaffTable"),
					"Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					for (var curr : new StaffTable(currFace.parent, currFace.code).val) {
						if (curr.id.isEmpty() == false) {
							res.add(curr);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("StaffTable.get(String):List<FaceDto>, ex=" + ex.getMessage(), "", "StaffTable");
		}
		return res;
	}

	// full list StaffTable on date1
	public static List<FaceDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 11.03.2025, last edit - 26.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, "Role.Face.StaffTable"),
					"Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					var currFaceStaffTable = new StaffTable(currFace.parent, currFace.code);
					var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceStaffTable.val, "");
					if (curr.id.isEmpty() == false) {
						res.add(curr);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("StaffTable.getCurr(2String):List<FaceDto>, ex=" + ex.getMessage(), "", "StaffTable");
		}
		return res;
	}

	// item StaffTable on date1 by infoId, ex. "Info.Staff.BossSign",
	// "Info.Staff.ChiefAccountantSign", etc.
	public static FaceDto getCurrByInfo(String date1, String parentId, String infoId) throws Exception {
		// origin - 24.11.2025, last edit - 24.11.2025
		FaceDto res = new FaceDto();
		try {
			var mDtoList = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleInfoFilter(parentId, "Role.Face.StaffTable", infoId), "Face");
			var faceDtoList = FaceDto.get(mDtoList);
			var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), faceDtoList, "");
			if (curr.id.isEmpty() == false) {
				res = curr;
			}
		} catch (Exception ex) {
			WB.addLog("StaffTable.getCurrByInfo(3String):FaceDto, ex=" + ex.getMessage(), "", "StaffTable");
		}
		return res;
	}

	// item StaffTable on date1
	public static FaceDto getCurr(String date1, String parentId, String staffTableId) throws Exception {
		// origin - 09.03.2025, last edit - 26.10.2025
		FaceDto res = new FaceDto();
		try {
			var currStaffTable = new StaffTable(parentId, staffTableId);
			var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currStaffTable.val, "");
			if (curr.id.isEmpty() == false) {
				res = curr;
			}
		} catch (Exception ex) {
			WB.addLog("StaffTable.getCurr(3String):FaceDto, ex=" + ex.getMessage(), "", "StaffTable");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 18.11.2025, last edit - 18.11.2025
		try {
			if (this.deptId.isEmpty()) {
				this.defect = this.defect + "empty deptId; ";
			}
			if (this.empId.isEmpty()) {
				this.defect = this.defect + "empty empId; ";
			}
			if (this.salary.id.isEmpty()) {
				this.defect = this.defect + "empty salary; ";
			}
		} catch (Exception ex) {
			WB.addLog("StaffTable.validate():void, ex=" + ex.getMessage(), "", "StaffTable");
		}
	}

	private void getVal() throws Exception {
		// origin - 09.03.2025, last edit - 14.12.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currSalary = "";
			String currMore = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currSalary = this.salary.getByIndex(i);
				currMore = "";
				currMore = currMore + MoreVal.setPartMore("Salary", currSalary);
				currMore = currMore + MoreVal.setPartMore("DeptId", this.deptId);
				currMore = currMore + MoreVal.setPartMore("PointId", this.pointId);
				currMore = currMore + MoreVal.setPartMore("EmpId", this.empId);
				currMore = currMore + MoreVal.setPartMore("FullName", this.fullName);
				currMore = currMore + MoreVal.setPartMore("Comment", this.comment);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description, this.geo,
						this.role, this.info, currMore, this.mark);
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("StaffTable.getVal():void, ex=" + ex.getMessage(), "", "StaffTable");
		}
	}

	private void isExist() throws Exception {
		// origin - 09.03.2025, last edit - 18.11.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentCodeRoleFilter(this.parent, this.code, "Role.Face.StaffTable"), "Face");
			if (listDto.size() != 0) {
				var currDto = listDto.getFirst();
				var tmp = new SpanDate(currDto.date1, currDto.date2);
				this.date1 = new ListVal(tmp.date1);
				this.date2 = new ListVal(tmp.date2);
				this.id = DefVal.setCustom(this.id, currDto.id);
				this.parent = DefVal.setCustom(this.parent, currDto.parent);
				this.code = DefVal.setCustom(this.code, currDto.code);
				this.description = DefVal.setCustom(this.description, currDto.description);
				this.geo = DefVal.setCustom(this.geo, currDto.geo);
				this.role = DefVal.setCustom(this.role, currDto.role);
				this.info = DefVal.setCustom(this.info, currDto.info);
				this.more = DefVal.setCustom(this.more, currDto.more);
				this.mark = DefVal.setCustom(this.mark, currDto.mark);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("StaffTable.isExist():void, ex=" + ex.getMessage(), "", "StaffTable");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 03.10.2025, last edit - 14.12.2025
		try {
			this.deptId = MoreVal.getFieldByKey(this.more, "DeptId");
			this.empId = MoreVal.getFieldByKey(this.more, "EmpId");
			this.pointId = MoreVal.getFieldByKey(this.more, "PointId");
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.salary = new ListVal(MoreVal.getFieldByKey(this.more, "Salary"), "");
		} catch (Exception ex) {
			WB.addLog("StaffTable.getFieldFromMore():void, ex=" + ex.getMessage(), "", "StaffTable");
		}
	}

	public StaffTable(String ParentId, String StaffTableId) throws Exception {
		// origin - 09.03.2025, last edit - 18.11.2025
		this();
		this.src = ParentId + ", " + StaffTableId;
		this.parent = ParentId;
		this.code = StaffTableId;
		this.isExist();
		this.getVal();
		this.validate();
	}

	private void clear() throws Exception {
		// origin - 09.03.2025, last edit - 14.12.2025
		try {
			this.table = "Face";
			this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.more = this.mark = "";
			this.deptId = this.empId = this.pointId = this.fullName = this.comment = this.defect = "";
			this.date1 = this.date2 = this.salary = new ListVal();
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("StaffTable.clear():void, ex=" + ex.getMessage(), "", "StaffTable");
		}
	}

	public StaffTable() throws Exception {
		// origin - 09.03.2025, last edit - 09.03.2025
		this.clear();
	}

	public String toString() {
		// origin - 09.03.2025, last edit - 14.12.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addAnyway(", deptId ", this.deptId);
			res = res + Fmtr.addAnyway(", empId ", this.empId);
			res = res + Fmtr.addAnyway(", pointId ", this.pointId);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addAnyway(", salary ", this.salary.id);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addAnyway(", val.size ", this.val.size());
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 09.03.2025, last edit - 04.10.2025
		try {

//			WB.addLog2("StaffTable.test.getTotalCurrSalary(2String):double", "", "StaffTable");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1" }) {
//					WB.addLog2("StaffTable.test.getTotalCurrSalary(2String):double, res="
//							+ StaffTable.getTotalCurrSalary(tmp1, tmp2) + ", date1=" + tmp1 + ", parentId=" + tmp2, "",
//							"StaffTable");
//				}
//			}

//			WB.addLog2("StaffTable.test.get():List<FaceDto>", "", "StaffTable");
//			WB.addLog2("StaffTable.test.get():List<FaceDto>, res.size=" + StaffTable.get().size(), "", "StaffTable");
//			WB.log(StaffTable.get(), "StaffTable");

//			WB.addLog2("StaffTable.test.get(String):List<FaceDto>", "", "StaffTable");
//			for (var tmp1 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
//				WB.addLog2("StaffTable.test.get(String):List<FaceDto>, res.size=" + StaffTable.get(tmp1).size()
//						+ ", parentId=" + tmp1, "", "StaffTable");
//				WB.log(StaffTable.get(tmp1), "StaffTable");
//			}

//			WB.addLog2("StaffTable.test.getCurrEmpId(2String):List<String>", "", "StaffTable");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-15", "2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1" }) {
//					WB.addLog2("StaffTable.test.getCurrEmpId(2String):List<String>, res=" + StaffTable.getCurrEmpId(tmp1, tmp2)
//							+ ", date1=" + tmp1 + ", parentFAId=" + tmp2, "", "StaffTable");
//				}
//			}

//			WB.addLog2("StaffTable.test.getCurrSalary(3String):double", "", "StaffTable");
//			for (var tmp1 : new String[] { "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01", "2025-02-28",
//					"2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1 , Face.FA1.StaffTable1.Boss",
//						"Face.FA1 , Face.FA1.StaffTable1.ChiefAccountant" }) {
//					var tmp3 = new TwoVal(tmp2);
//					WB.addLog2("StaffTable.test.getCurrSalary(3String):double, res="
//							+ StaffTable.getCurrSalary(tmp1, tmp3.val1, tmp3.val2) + ", date1=" + tmp1 + ", parentId="
//							+ tmp3.val1 + ", staffTableId=" + tmp3.val2, "", "StaffTable");
//				}
//			}

//			WB.addLog2("StaffTable.test.getCurr(2String):List<FaceDto>", "", "StaffTable");
//			for (var tmp1 : new String[] { "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01", "2025-02-15",
//					"2025-02-28", "2025-08-15" }) {
//				var tmp2 = "Face.FA1";
//				var tmp3 = StaffTable.getCurr(tmp1, tmp2);
//				WB.addLog2("StaffTable.test.getCurr(2String):List<FaceDto>, res.size=" + tmp3.size() + ", date1=" + tmp1
//						+ ", parentId=" + tmp2, "", "StaffTable");
//				WB.log(tmp3, "StaffTable");
//			}

//			WB.addLog2("StaffTable.test.getCurr(3String):FaceDto", "", "StaffTable");
//			for (var tmp1 : new String[] { "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01", "2025-02-28",
//					"2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1 , Face.FA1.StaffTable1.Boss",
//						"Face.FA1 , Face.FA1.StaffTable1.ChiefAccountant" }) {
//					var tmp3 = new TwoVal(tmp2);
//					WB.addLog2("StaffTable.test.getCurr(3String):FaceDto, res="
//							+ StaffTable.getCurr(tmp1, tmp3.val1, tmp3.val2) + ", date1=" + tmp1 + ", parentId="
//							+ tmp3.val1 + ", staffTableId=" + tmp3.val2, "", "StaffTable");
//				}
//			}

//			WB.addLog2("StaffTable.test.ctor(2String)", "", "StaffTable");
//			for (var tmp1 : new String[] { "Face.FA1 , Face.FA1.StaffTable1.Boss",
//					"Face.FA1 , Face.FA1.StaffTable1.ChiefAccountant",
//					"Face.Tralala , Face.Tralala.ChiefAccountant" }) {
//				var tmp2 = new TwoVal(tmp1);
//				var tmp3 = new StaffTable(tmp2.val1, tmp2.val2);
//				WB.addLog2("StaffTable.test.ctor(2String)=" + tmp3, "", "StaffTable");
//				WB.log(tmp3.val, "StaffTable");
//			}

		} catch (Exception ex) {
			WB.addLog("StaffTable.test():void, ex=" + ex.getMessage(), "", "StaffTable");
		}
	}
}