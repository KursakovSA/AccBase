import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public final class WorkDay {
	// origin - 24.06.2024, last edit - 11.03.2026

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("WorkDay.static ctor, ex=" + ex.getMessage(), "", "WorkDay");
		}
	}

	public static String getByYearMonth(String year, String month) throws Exception {
		// origin - 06.03.2026, last edit - 15.09.2026
		String res = "";
		try {
			var tmp1 = WorkDay.getByYear(year); // ex. "18;20;19;21;19;22;20;22;22;20;22;21;" for year=2022
			if (tmp1.size() != 0) {
				var numberMonth = Num.getIntByStr(month); // ex. 10, 12
				if (numberMonth >= 1) {
					res = tmp1.get(numberMonth - 1); // ex. "20" for month = 2
				}
			}
		} catch (Exception ex) {
			WB.addLog("WorkDay.getByYearMonth(2String):String, ex=" + ex.getMessage(), "", "WorkDay");
		}
		return res;
	}

	public static String getDiff(String year, String month) throws Exception {
		// origin - 07.03.2026, last edit - 11.03.2026
		String res = "";
		try {
			var normVal = WorkDay.getByYearMonth(year, month);

			if (normVal.isEmpty() == false) {
				month = DateTool.getStrMonth(month);
				var startMonth = year + "-" + month + "-01";
				var endMonth = DateTool.getEndMonth(DateTool.getLocalDate(startMonth)).toString();

				var calcVal = String.valueOf(WorkDay.getByDay(startMonth, endMonth, ""));
				if (calcVal.isEmpty() == false) {
					if (Etc.strEquals(calcVal, normVal) == false) {
						res = "norm=" + normVal + ", " + "calc=" + calcVal;
						WorkDay.getByDay(startMonth, endMonth, "detail diff");
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("WorkDay.getDiff(2String):String, ex=" + ex.getMessage(), "", "WorkDay");
		}
		return res;
	}

	private static List<String> getByYear(String year) throws Exception {
		// origin - 06.03.2026, last edit - 09.03.2026
		List<String> res = new ArrayList<String>();
		try {
			for (var curr : WB.abcGlobal.workDay) {
				if (Etc.strContains(curr.code, year)) { // ex. "WorkDay.2022"
					if (Etc.fixTrim(curr.meterValue).isEmpty() == false) {
						res = List.of(curr.meterValue.split(";")); // ex. "18;20;19;21;19;22;20;22;22;20;22;21;"
						break;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("WorkDay.getByYear(String):List<String>, ex=" + ex.getMessage(), "", "WorkDay");
		}
		return res;
	}

	public static int getByDay(String currDate1, String currDate2, String context) throws Exception {
		// origin - 17.02.2024, last edit - 09.03.2026
		int res = 0;
		try {
			int currRes = 0;
			for (var curr : DateTool.getDateList(currDate1, currDate2)) {
				currRes = 0;
				if (WorkDay.isWorkdayFinally(curr)) {
					currRes = 1;
					res = res + currRes;
				}

				if (context.isEmpty() == false) { // show detail if context is not empty
					WB.addLog2("WorkDay.getByDay(3String):int, currRes=" + currRes + ", for date=" + curr, "",
							"WorkDay");
				}
			}
		} catch (Exception ex) {
			WB.addLog("WorkDay.getByDay(2String):int, ex=" + ex.getMessage(), "", "WorkDay");
		}
		return res;
	}

	private static boolean isWorkdayFinally(String date) throws Exception {
		// origin - 27.05.2024, last edit - 07.03.2026
		boolean res = false;
		try {
			if ((WorkDay.isWorkday1(date)) && // definition workday previoslly
					(WorkDay.isWorkday2(date))) { // definition workday finally
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("WorkDay.isWorkdayFinally(String):boolean, ex=" + ex.getMessage(), "", "WorkDay");
		}
		return res;
	}

	private static List<String> getTransferWeekendList(String date) throws Exception {
		// origin - 08.03.2026, last edit - 09.03.2026
		List<String> res = new ArrayList<String>();
		List<String> calcList1 = new ArrayList<String>();
		List<String> calcList2 = new ArrayList<String>();
		try {
			// prepare list
			// add preDate
			var localDate = DateTool.getLocalDate(date);
			String tmp = "";
			String tmp1 = "";
			for (int i = 6; i >= 1; i--) {
				tmp = "";
				tmp1 = localDate.minusDays(i).toString();
				tmp = tmp1;
				if (WorkDay.isPublicHoliday(tmp1)) {
					tmp = tmp + ";PublicHoliday";
				}
				if (WorkDay.isWeekend(tmp1)) {
					tmp = tmp + ";Weekend";
				}
				calcList1.add(tmp);
			}

			// add this day
			tmp = date + ";this day";
			if (WorkDay.isPublicHoliday(date)) {
				tmp = tmp + ";PublicHoliday";
			}
			if (WorkDay.isWeekend(date)) {
				tmp = tmp + ";Weekend";
			}
			calcList1.add(tmp);

			// add postDate
			String tmp2 = "";
			for (int i = 1; i <= 3; i++) {
				tmp = "";
				tmp2 = localDate.plusDays(i).toString();
				tmp = tmp2;
				if (WorkDay.isPublicHoliday(tmp2)) {
					tmp = tmp + ";PublicHoliday";
				}
				if (WorkDay.isWeekend(tmp2)) {
					tmp = tmp + ";Weekend";
				}
				calcList1.add(tmp2);
			}
			calcList2.addAll(calcList1);

			// processing list
			var count = 0;
			List<String> tmpList1 = new ArrayList<String>();
			String curr2 = "";
			for (var curr1 : calcList1) {
				count = count + 1;
				tmpList1 = List.of(curr1.split(";"));
				tmp1 = tmpList1.get(0);

				// if this date match public holiday and weekend
				if ((Etc.strContains(curr1, "PublicHoliday")) & (Etc.strContains(curr1, "Weekend"))) {

					for (int i = count; i <= calcList1.size(); i++) {
						curr2 = Etc.fixTrim(calcList2.get(i));

						if (Etc.strContains(curr2, "TransferWeekend") == false) { // if this date is free from transfer
																					// weekend

							// if this date is free from public holiday and weekend
							if ((Etc.strContains(curr2, "PublicHoliday") == false)
									& (Etc.strContains(curr2, "Weekend") == false)) {
								tmp2 = curr2 + ";TransferWeekend;" + tmp1;
								calcList2.set(i, tmp2);
								break;
							}
						}
					}

				}
			}

			res.addAll(calcList2);
		} catch (Exception ex) {
			WB.addLog("WorkDay.getTransferWeekendList(String):List<String>, ex=" + ex.getMessage(), "", "WorkDay");
		}
		return res;
	}

	private static boolean isTransferWeekendByList(String date) throws Exception {
		// detection transfer weekend weekend in current data
		// origin - 09.03.2026, last edit - 09.03.2026
		boolean res = false;
		try {
			var tmp = WorkDay.getTransferWeekendList(date);
			for (var curr : tmp) {
				if (curr.startsWith(date)) { // ex. "2026-02-27...."
					if (Etc.strContains(curr, "TransferWeekend")) { // "2026-02-27;TransferWeekend...."
						res = true;
						break;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("WorkDay.isTransferWeekendByList(String):boolean, ex=" + ex.getMessage(), "", "WorkDay");
		}
		return res;
	}

	private static boolean isWorkday2(String date) throws Exception {
		// origin - 26.05.2024, last edit - 09.03.2026
		boolean res = false;
		try {
			// if (WorkDay.isTransferWeekend(date) == false) {
			if (WorkDay.isTransferWeekendByList(date) == false) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("WorkDay.isWorkday2(String):boolean, ex=" + ex.getMessage(), "", "WorkDay");
		}
		return res;
	}

	private static boolean isWorkday1(String date) throws Exception {
		// origin - 22.02.2024, last edit - 09.03.2026
		boolean res = false;
		try {
			if ((WorkDay.isWeekend(date) == false) && (WorkDay.isPublicHoliday(date) == false)
					&& (WorkDay.isExtraDayOff(date) == false)) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("WorkDay.isWorkday1(String):boolean, ex=" + ex.getMessage(), "", "WorkDay");
		}
		return res;
	}

	private static boolean isWeekend(String date) throws Exception {
		// origin - 17.02.2024, last edit - 09.03.2026
		boolean res = false;
		var localDate = DateTool.getLocalDate(date);
		try {
			if (localDate.getDayOfWeek() == DayOfWeek.SATURDAY) {
				res = true;
			}
			if (localDate.getDayOfWeek() == DayOfWeek.SUNDAY) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("WorkDay.isWeekend(String):boolean, ex=" + ex.getMessage(), "", "WorkDay");
		}
		return res;
	}

	private static boolean isPublicHoliday(String date) throws Exception {
		// origin - 21.02.2024, last edit - 29.06.2026
		boolean res = false;
		var localDate = DateTool.getLocalDate(date);
		try {
			// LocalDate dateStartYear = DateTool.getStartYear(localDate);
			for (var currPublicHoliday : WB.abcGlobal.publicHoliday) {

				if (Etc.strContains(currPublicHoliday.meter, "Meter.PublicHoliday")) {

					// skip not actual PublicHoliday by date1
					if ((currPublicHoliday.date1.isEmpty() == false)
							&& (DateTool.getLocalDate(currPublicHoliday.date1).isAfter(localDate))) {
						continue;
					}

					// skip not actual PublicHoliday by date2
					if ((currPublicHoliday.date2.isEmpty() == false)
							&& (DateTool.getLocalDate(currPublicHoliday.date2).isBefore(localDate))) {
						continue;
					}
					if (currPublicHoliday.meterValue.isEmpty()) {
						continue;
					}
					if (Etc.strContains(date, currPublicHoliday.meterValue)) {
						res = true;
						break;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("WorkDay.isPublicHoliday(String):boolean, ex=" + ex.getMessage(), "", "WorkDay");
		}
		return res;
	}

	private static boolean isExtraDayOff(String date) throws Exception {
		// origin - 18.02.2024, last edit - 09.03.2026
		boolean res = false;
		var localDate = DateTool.getLocalDate(date);
		try {
			LocalDate dateStartYear = DateTool.getStartYear(localDate);
			for (var currDayOff : WB.abcGlobal.extraDayOff) {

				if (Etc.strContains(currDayOff.meter, "Meter.ExtraDayOff")) {

					// skip not actual ExtraDayOff
					if ((currDayOff.date2.isEmpty() == false)
							&& (DateTool.getLocalDate(currDayOff.date2).isBefore(dateStartYear))) {
						continue;
					}
					if (currDayOff.meterValue.isEmpty()) {
						continue;
					}
					if (Etc.strContains(date, currDayOff.meterValue)) {
						res = true;
						break;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("WorkDay.isExtraDayOff(String):boolean, ex=" + ex.getMessage(), "", "WorkDay");
		}
		return res;
	}

	private WorkDay() throws Exception {
		// origin - 05.03.2024, last edit - 05.03.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 05.03.2026, last edit - 05.03.2026
		try {
		} catch (Exception ex) {
			WB.addLog("WorkDay.clear():void, ex=" + ex.getMessage(), "", "WorkDay");
		}
	}

	public static void test() throws Exception {
		// origin - 24.06.2024, last edit - 29.06.2026
		try {

//			WB.addLog2("WorkDay.test.getTransferWeekendList(String):List<String>", "", "WorkDay");
//			for (var tmp1 : new String[] { "2026-03-05", "2026-03-08", "2026-03-09", "2026-03-21", "2026-03-22",
//					"2026-03-23", "2026-03-24", "2026-03-25", "2026-03-26", "2026-03-27", "2026-03-28", "2026-03-29",
//					"2026-03-30", "2026-03-31" }) {
//				var tmp2 = WorkDay.getTransferWeekendList(tmp1);
//				WB.addLog2("WorkDay.test.getTransferWeekendList(String):List<String>, res.size=" + tmp2.size()
//						+ ", tmp1=" + tmp1, "", "WorkDay");
//				WB.log(tmp2, "WorkDay");
//			}

//			WB.addLog2("WorkDay.test.getByYearMonth(2String):String", "", "WorkDay");
//			for (var tmp1 : new String[] { "1", "2", "6", "12" }) {
//				var tmp2 = WorkDay.getByYearMonth(String.valueOf(DateTool.getNow().getYear()), tmp1);
//				WB.addLog2("WorkDay.test.getByYearMonth(2String):String, res=" + tmp2 + ", tmp1=" + tmp1 + ", 2026", "",
//						"WorkDay");
//			}

			WB.addLog2("WorkDay.test.getDiff(2String):String", "", "WorkDay");
			for (var tmp1 : DateTool.getStrYearList("2021", "2029")) {
				for (var tmp2 : DateTool.getStrMonthList()) {
					var tmp3 = WorkDay.getDiff(tmp1, tmp2);
					if (tmp3.isEmpty()) { // empty diff not print
						continue;
					}
					WB.addLog2(
							"WorkDay.test.getDiff(2String):String, res=" + tmp3 + ", month=" + tmp2 + ", year=" + tmp1,
							"", "WorkDay");
				}
			}

//			WB.addLog2("WorkDay.test.getByDay(2String):boolean", "", "WorkDay");
//			for (var tmp1 : DateTool.getStrYearList("2021", "2029")) {
//				for (var tmp2 : DateTool.getListStartMonth(tmp1)) {
//					var tmp3 = DateTool.getLocalDate(tmp2);
//					var tmp4 = DateTool.getEndMonth(tmp3);
//					WB.addLog2("WorkDay.test.getByDay(2String):boolean, res=" + WorkDay.getByDay(tmp2, tmp4.toString())
//							+ ", month=" + tmp3.getMonth() + ", year=" + tmp3.getYear(), "", "WorkDay");
//				}
//			}

//			WB.addLog2("WorkDay.test.isExtraDayOff(String):boolean", "", "WorkDay");
//			for (var tmp1 : new String[] { "2026-02-07", "2026-03-07", "2024-01-01", "2024-01-07" }) {
//				WB.addLog2("WorkDay.test.isExtraDayOff(String):boolean, res=" + WorkDay.isExtraDayOff(tmp1) + ", tmp1="
//						+ tmp1, "", "WorkDay");
//			}

//			WB.addLog2("WorkDay.test.isPublicHoliday(String):boolean", "", "WorkDay");
//			for (var tmp1 : new String[] { "2026-02-07", "2026-03-07", "2024-01-07", "2024-01-01" }) {
//				WB.addLog2("WorkDay.test.isPublicHoliday(String):boolean, res="
//						+ WorkDay.isPublicHoliday(tmp1) + ", tmp1=" + tmp1, "", "WorkDay");
//			}

		} catch (Exception ex) {
			WB.addLog("WorkDay.test():void, ex=" + ex.getMessage(), "", "WorkDay");
		}
	}
}