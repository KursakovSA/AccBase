import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.util.List;

public final class WorkDay {
	// origin - 24.06.2024, last edit - 12.10.2025

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("WorkDay.static ctor, ex=" + ex.getMessage(), "", "WorkDay");
		}
	}

	public static int getWorkdayCount(LocalDate date1, LocalDate date2, Face currFA) throws Exception {// TODO---currFA
		// origin - 17.02.2024, last edit - 14.06.2025
		int res = 0;
		try {
			for (; !date1.isAfter(date2); date1 = date1.plusDays(1)) {
				if (isWorkdayFinally(date1, currFA)) {
					res = res + 1;
				}
			}
		} catch (Exception ex) {
			WB.addLog(
					"WorkDay.getWorkdayCount(LocalDate date1, LocalDate date2, Face currFA):int, ex=" + ex.getMessage(),
					"", "WorkDay");
		}
		return res;
	}

	private static boolean isWorkdayFinally(LocalDate date1, Face currFA) throws Exception {
		// origin - 27.05.2024, last edit - 14.06.2025
		boolean res = false;
		try {
			if ((isWorkday1(date1, null)) && // definition workday previoslly
					(isWorkday2(date1, null))) { // definition workday finally
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("WorkDay.isWorkdayFinally(LocalDate date1, Face currFA):boolean, ex=" + ex.getMessage(), "",
					"WorkDay");
		}
		return res;
	}

	private static boolean hasOverlayPublicHolidayOnWeekend(LocalDate date, Face currFA) throws Exception {
		// TODO --- currFA ???
		// origin - 21.02.2024, last edit - 14.06.2025
		boolean res = false;
		try {
			if ((isPublicHoliday(date, currFA)) && (isWeekend(date, currFA))) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("WorkDay.hasOverlayPublicHolidayOnWeekend(LocalDate date, Face currFA):boolean, ex="
					+ ex.getMessage(), "", "WorkDay");
		}
		return res;
	}

	private static boolean isTransferWeekend(LocalDate date, Face currFA) throws Exception {// TODO --- currFA ???
		// detection transfer weekend weekend in current data
		// origin - 26.05.2024, last edit - 14.06.2025
		boolean res = false;
		try {
			LocalDate preDate1 = date.minusDays(1);
			LocalDate preDate2 = date.minusDays(2);
			LocalDate preDate3 = date.minusDays(3);

			// case1 - 1.workday finally; 2.transfer weekend; 3.workday previously =
			// transfer, weekend finally
			if ((isWorkday1(preDate2, currFA)) && (hasTransferWeekend(preDate1, currFA))
					&& (isWorkday1(date, currFA))) {
				// then date finally = isTransferWeekend
				res = true;
			}

			// case2 - 1.weekend finally; 2.transfer weekend; 3.workday previously =
			// transfer weekend finally
			if ((isWeekend(preDate2, currFA)) && (hasTransferWeekend(preDate1, currFA)) && (isWorkday1(date, currFA))) {
				// then date finally = isTransferWeekend
				res = true;
			}

			// case3 - 1.transfer weekend; 2.weekend finally; 3.workday previously =
			// transfer weekend finally
			if ((hasTransferWeekend(preDate2, currFA)) && (isWeekend(preDate1, currFA)) && (isWorkday1(date, currFA))) {
				// then date finally = isTransferWeekend
				res = true;
			}

			// case4 - 1.transfer weekend; 2.transfer weekend; 3.weekend finally; 4.workday
			// previously = transfer weekend finally
			if ((hasTransferWeekend(preDate3, currFA)) && (hasTransferWeekend(preDate2, currFA))
					&& (isWorkday1(preDate1, currFA)) && (isWorkday1(date, currFA))) {
				// then date finally = isTransferWeekend
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("WorkDay.isTransferWeekend(LocalDate date, Face currFA):boolean, ex=" + ex.getMessage(), "",
					"WorkDay");
		}
		return res;
	}

	private static boolean hasTransferWeekend(LocalDate date, Face currFA) throws Exception {// TODO --- currFA ???
		// match detection public holiday and weekend in same data
		// origin - 20.02.2024, last edit - 14.06.2025
		boolean res = false;
		try {
			if (hasOverlayPublicHolidayOnWeekend(date, currFA)) {
				// TODO -- check what ahead has workday in this month
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("WorkDay.hasTransferWeekend(LocalDate date, Face currFA):boolean, ex=" + ex.getMessage(), "",
					"WorkDay");
		}
		return res;
	}

	private static boolean isWorkday2(LocalDate date1, Face currFA) throws Exception {
		// origin - 26.05.2024, last edit - 14.06.2025
		// finally definiton workday
		boolean res = false;
		try {
			if (isTransferWeekend(date1, currFA) == false) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("WorkDay.isWorkday2(LocalDate date1, Face currFA):boolean, ex=" + ex.getMessage(), "", "WorkDay");
		}
		return res;
	}

	private static boolean isWorkday1(LocalDate date1, Face currFA) throws Exception {
		// origin - 22.02.2024, last edit - 14.06.2025
		// previously definiton workday
		boolean res = false;
		try {
			if ((isWeekend(date1, currFA) == false) && (isPublicHoliday(date1, currFA) == false)
					&& (isExtraDayOff(date1, currFA) == false)) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("WorkDay.isWorkday1(LocalDate date1, Face currFA):boolean, ex=" + ex.getMessage(), "", "WorkDay");
		}
		return res;
	}

	private static boolean isWeekend(LocalDate currDate, Face currFA) throws Exception {// TODO --- currFA ???
		// origin - 17.02.2024, last edit - 14.06.2025
		// definition classic weekend - saturday + sunday
		boolean res = false;
		try {
			if (currDate.getDayOfWeek() == DayOfWeek.SATURDAY) {
				res = true;
			}
			if (currDate.getDayOfWeek() == DayOfWeek.SUNDAY) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("WorkDay.isWeekend(LocalDate date1, Face currFA):boolean, ex=" + ex.getMessage(), "", "WorkDay");
		}
		return res;
	}

	private static boolean isPublicHoliday(LocalDate currDate, Face currFA) throws Exception {// TODO --- currFA ???
		// origin - 21.02.2024, last edit - 14.06.2025
		boolean res = false;
		try {
			LocalDate dateStartYear = DateTool.getStartYear(currDate);
			for (var currPublicHoliday : WB.abcGlobal.publicHoliday) {

				if (Etc.strContains(currPublicHoliday.meter, "Meter.PublicHoliday")) {

					// skip not actual PublicHoliday
					if ((currPublicHoliday.date2.isEmpty() == false)
							&& (DateTool.getLocalDate(currPublicHoliday.date2).isBefore(dateStartYear))) {
						// WB.addLog2("WorkDay.isPublicHoliday, skip not actual PublicHoliday="
						// +currDayOff, "", "WorkDay");
						continue;
					}
					if (currPublicHoliday.meterValue.isEmpty()) {
						// WB.addLog("WorkDay.isExtraDayOff, currDayOff.meterValue=" +
						// currDayOff.meterValue + ", currDate=" + currDate, "", "WorkDay");
						continue;
					}
					if (Etc.strContains(currDate.toString(), currPublicHoliday.meterValue)) {
						res = true;
						// WB.addLog2("WorkDay.PublicHoliday, res=" + res + ", currDayOff=" +
						// currDayOff + ", currDate1=" + currDate, "", "WorkDay");
						break;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("WorkDay.isPublicHoliday(LocalDate date1, Face currFA):boolean, ex=" + ex.getMessage(), "",
					"WorkDay");
		}
		return res;
	}

	private static boolean isExtraDayOff(LocalDate currDate, Face currFA) throws Exception {// TODO --- currFA ???
		// origin - 18.02.2024, last edit - 14.06.2025
		boolean res = false;
		try {
			LocalDate dateStartYear = DateTool.getStartYear(currDate);
			for (var currDayOff : WB.abcGlobal.extraDayOff) {

				if (Etc.strContains(currDayOff.meter, "Meter.ExtraDayOff")) {

					// skip not actual ExtraDayOff
					if ((currDayOff.date2.isEmpty() == false)
							&& (DateTool.getLocalDate(currDayOff.date2).isBefore(dateStartYear))) {
						// WB.addLog2("WorkDay.isExtraDayOff, skip not actual isExtraDayOff="
						// +currDayOff, "", "WorkDay");
						continue;
					}
					if (currDayOff.meterValue.isEmpty()) {
						// WB.addLog("WorkDay.isExtraDayOff, currDayOff.meterValue=" +
						// currDayOff.meterValue + ", currDate=" + currDate, "", "WorkDay");
						continue;
					}
					if (Etc.strContains(currDate.toString(), currDayOff.meterValue)) {
						res = true;
						// WB.addLog2("WorkDay.isExtraDayOff, res=" + res + ", currDayOff=" +
						// currDayOff + ", currDate1=" + currDate, "", "WorkDay");
						break;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("WorkDay.isExtraDayOff(LocalDate date1, Face currFA):boolean, ex=" + ex.getMessage(), "",
					"WorkDay");
		}
		return res;
	}

	private WorkDay() {
		// origin - 04.11.2024, last edit - 04.11.2024
	}

	@SuppressWarnings("unused")
	public static void test() throws Exception {
		// origin - 24.06.2024, last edit - 14.06.2025
		try {
			var testDateTime1 = new String[] { "2023-11-24T06:46:16.907+06:00", "2023-11-08 02:15:09",
					"06:46:16.907+06:00", "2019-01-01", "test1", "12.45", "12:45", "12:45:38", "12:45:57.678", null };

//		var testDate1 = new String[] { "2023-01-01T06:46:16.907+06:00", "2023-11-08 02:15:09", "06:46:16.907+06:00",
//				"2019-01-01", "test1", "12.45", "12:45", "12:45:38", "12:45:57.678", null };

			var testLocalDate = new LocalDate[] { DateTool.getNow().minusMonths(1), DateTool.getNow(),
					LocalDate.of(2024, Month.JANUARY, 1), LocalDate.of(2024, Month.APRIL, 18) };

			LocalDate dateNow = DateTool.getNow();
			LocalDate dateEndCurrYear = DateTool.getEndYear(dateNow);
			LocalDate dateStartLastYear = DateTool.getStartYear(DateTool.getStartYear(dateNow).minusDays(1));
			LocalDate dateStartPostLastYear = DateTool.getStartYear(dateStartLastYear.minusDays(1));
			List<LocalDate> listDayManyYear = DateTool.getListLocalDate(dateStartPostLastYear, dateEndCurrYear);
			List<LocalDate> listStartMonth = DateTool.getListStartMonth(listDayManyYear);

//			// getWorkdayCount
//			for (var testDate : listStartMonth) {
//				WB.addLog2("WorkDay.test.getWorkdayCount, res="
//						+ getWorkdayCount(testDate, DateTool.getEndMonth(testDate), null) + ", month="
//						+ testDate.getMonth() + ", year=" + testDate.getYear(), "", "WorkDay");
//			}

//		// isWorkdayFinally detailed (if has trouble in getWorkdayCount)
//		List<LocalDate> listDayDetailed = getListLocalDate(LocalDate.of(2022, Month.MAY, 1),
//				LocalDate.of(2022, Month.MAY, 31));// may 2022
//		for (var testDate : listDayDetailed) {
//			WB.addLog2("WorkDay.test.isWorkdayFinally, res=" + isWorkdayFinally(testDate, null) + ", testDate="
//					+ testDate + ", isPublicHoliday()=" + isPublicHoliday(testDate, null) + ", isExtraDayOff()="
//					+ isExtraDayOff(testDate, null) + ", isTransferWeekend()=" + isTransferWeekend(testDate, null), "",	"WorkDay");
//		}

//		// isTransferWeekend
//		for (var testDate : listDayManyYear) {
//			if (isTransferWeekend(testDate, null)) {
//				WB.addLog2("WorkDay.test.isTransferWeekend, res=" + isTransferWeekend(testDate, null) + ", date1="
//						+ testDate, "", "WorkDay");
//			}
//		}

//		// isWeekend
//		for (var testArg1 : testLocalDate) {
//			WB.addLog2("WorkDay.test.isWeekend, res=" + isWeekend(testArg1, null) + ", testArg1=" + testArg1 + ", (" + testArg1.getDayOfWeek() + ")", "", "WorkDay");
//		}

//		// hasTransferWeekend
//		for (var testDate : listDay3Year) {
//			if (hasTransferWeekend(testDate, null)) {
//				WB.addLog2("WorkDay.test.hasTransferWeekend, res=" + hasTransferWeekend(testDate, null) + ", date1="
//						+ testDate, "", "WorkDay");
//			}
//		}

//		// isWorkday1
//		for (var date1 : listDay3Year) {
//			if (isWorkday1(date1, null) == false) { // show only not workday for shorter
//				WB.addLog2("WorkDay.test.isWorkday1, res=" + isWorkday1(date1, null) + ", date1=" + date1 + ", ("
//						+ date1.getDayOfWeek() + ")", "", "WorkDay");
//			}
//		}

//		// isWorkday2
//		for (var date1 : listDay3Year) {
//			if (isWorkday2(date1, null) == false) { // show only not workday for shorter
//				WB.addLog2("WorkDay.test.isWorkday2, res=" + isWorkday2(date1, null) + ", date1=" + date1 + ", ("
//						+ date1.getDayOfWeek() + ")", "", "WorkDay");
//			}
//		}

//		// isExtraDayOff
//		for (var testDate : listDay3Year) {
//			if (isExtraDayOff(testDate, null)) {
//				WB.addLog2(
//						"WorkDay.test.isExtraDayOff, res=" + isExtraDayOff(testDate, null) + ", date1=" + testDate,"", "WorkDay");
//			}
//		}

//		// isPublicHoliday
//		for (var testDate : listDay3Year) {
//			if (isPublicHoliday(testDate, null)) {
//				WB.addLog2("WorkDay.test.isPublicHoliday, res=" + isPublicHoliday(testDate, null) + ", date1=" + testDate, "", "WorkDay");
//			}
//		}
		} catch (Exception ex) {
			WB.addLog("WorkDay.test():void, ex=" + ex.getMessage(), "", "WorkDay");
		}
	}
}