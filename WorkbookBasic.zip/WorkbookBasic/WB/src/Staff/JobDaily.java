import java.util.ArrayList;
import java.util.List;

public final class JobDaily {
	// origin - 07.05.2025, last edit - 02.11.2026
	public String table, src, id, parent, code, description, geo, role, info, mark, more, defect;
	public ListVal date1, date2, span;
	public List<FaceDto> val;
	public static List<String> strInfoSelect;
	public static List<String> roleList;

	static {
		try {
			JobDaily.roleList = List.of("Role.Face.JobDaily");
			JobDaily.strInfoSelect = List.of("Info.Staff.Late", "Info.Staff.Skip");
		} catch (Exception ex) {
			WB.addLog("JobDaily.static ctor, ex=" + ex.getMessage(), "", "JobDaily");
		}
	}

	public static UnitVal getTotalSpan(SpanDate spanDate, String parentId, String infoSelect) throws Exception {
		// origin - 08.05.2025, last edit - 19.10.2026
		Unit unitSpan = Unit.getExpectedByInfo(infoSelect);
		UnitVal res = new UnitVal("0.0", unitSpan.code);
		List<UnitVal> listUnitVal = new ArrayList<UnitVal>();
		try {
			if (Etc.strNotValid(parentId, infoSelect)) {
				return res;
			}

			var listDto = FaceDto.getChronoSpan(spanDate, new JobDaily(parentId, infoSelect).val);
			if (listDto.size() != 0) {
				for (var curr : listDto) {
					listUnitVal.add(new UnitVal(MoreVal.getFieldByKey(curr.more, "Span"), unitSpan.code));
				}
			}
			if (listUnitVal.size() != 0) {
				res = UnitVal.add(listUnitVal);
			}
		} catch (Exception ex) {
			WB.addLog("JobDaily.getTotalSpan(SpanDate, 2String):UnitVal, ex=" + ex.getMessage(), "", "JobDaily");
		}
		return res;
	}

	public static UnitVal getSpan(String date1, String parentId, String infoSelect) throws Exception {
		// origin - 08.05.2025, last edit - 19.10.2026
		Unit unitSpan = Unit.getExpectedByInfo(infoSelect);
		UnitVal res = new UnitVal("0.0", unitSpan.code);
		List<UnitVal> listUnitVal = new ArrayList<UnitVal>();
		try {
			if (Etc.strNotValid(parentId, infoSelect)) {
				return res;
			}

			var val = new JobDaily(parentId, infoSelect).val;
			var listDto = FaceDto.getChrono(DateTool.getLocalDate(date1), val);
			if (listDto.size() != 0) {
				for (var curr : listDto) {
					listUnitVal.add(new UnitVal(MoreVal.getFieldByKey(curr.more, "Span"), unitSpan.code));
				}
			}
			res = UnitVal.add(listUnitVal);
		} catch (Exception ex) {
			WB.addLog("JobDaily.getSpan(3String):UnitVal, ex=" + ex.getMessage(), "", "JobDaily");
		}
		return res;
	}

	// full list jobDaily for any date1, date2
	public static List<FaceDto> get(String parentId) throws Exception {
		// origin - 07.05.2025, last edit - 02.11.2026
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			if (Etc.strNotValid(parentId)) {
				return res;
			}

			for (var currInfo : JobDaily.strInfoSelect) {
				var faceByParentRole = DAL.getByTemplate(WB.lastConnWork,
						Qry.getParentRoleInfoFilter(parentId, JobDaily.roleList.getFirst(), currInfo), "Face");
				for (var currFace : faceByParentRole) {
					var currJobDaily = new JobDaily(currFace.parent, currInfo);
					for (var curr : currJobDaily.val) {
						if (curr.id.isEmpty() == false) {
							res.add(curr);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("JobDaily.get(String):List<FaceDto>, ex=" + ex.getMessage(), "", "JobDaily");
		}
		return res;
	}

	// full list jobDaily on date1
	public static List<FaceDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 07.05.2025, last edit - 02.11.2026
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			if (Etc.strNotValid(date1, parentId)) {
				return res;
			}

			var faceByParentRole = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleFilter(parentId, JobDaily.roleList.getFirst()), "Face");
			for (var currFace : faceByParentRole) {
				var currFaceJobDaily = new JobDaily(currFace.parent, currFace.info);
				var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceJobDaily.val, "");
				if (curr.id.isEmpty() == false) {
					res.add(curr);
				}
			}
		} catch (Exception ex) {
			WB.addLog("JobDaily.getCurr(2String):List<FaceDto>, ex=" + ex.getMessage(), "", "JobDaily");
		}
		return res;
	}

	// item jobDaily on date1
	public static FaceDto getCurr(String date1, String faceParentId, String infoSelect) throws Exception {
		// origin - 07.05.2025, last edit - 19.10.2026
		FaceDto res = new FaceDto();
		try {
			if (Etc.strNotValid(date1, faceParentId, infoSelect)) {
				return res;
			}

			var currFaceJobDaily = new JobDaily(faceParentId, infoSelect);
			if (currFaceJobDaily.val.size() != 0) {
				var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceJobDaily.val, "");
				if (curr.id.isEmpty() == false) {
					res = curr;
				}
			}
		} catch (Exception ex) {
			WB.addLog("JobDaily.getCurr(3String):FaceDto, ex=" + ex.getMessage(), "", "JobDaily");
		}
		return res;
	}

	private void validate() throws Exception {
		// origin - 20.11.2025, last edit - 10.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}
		} catch (Exception ex) {
			WB.addLog("JobDaily.validate():void, ex=" + ex.getMessage(), "", "JobDaily");
		}
	}

	private void getVal() throws Exception {
		// origin - 07.05.2025, last edit - 02.11.2026
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currSpan = "";
			String currMore = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currSpan = this.span.getByIndex(i);
				currMore = "";
				currMore = currMore + MoreVal.setPart("Span", currSpan);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description, this.geo,
						this.role, this.info, currMore, this.mark);
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("JobDaily.getVal():void, ex=" + ex.getMessage(), "", "JobDaily");
		}
	}

	private void isExist() throws Exception {
		// origin - 07.05.2025, last edit - 02.11.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleInfoFilter(this.parent, JobDaily.roleList.getFirst(), this.info), "Face");

			if (listDto.size() != 0) {
				var currDto = listDto.getFirst();
				var tmp = new SpanDate(currDto.date1, currDto.date2);
				this.date1 = new ListVal(tmp.date1);
				this.date2 = new ListVal(tmp.date2);
				this.id = DefVal.setCustom(this.id, currDto.id);
				this.parent = DefVal.setCustom(this.parent, currDto.parent);
				this.code = DefVal.setCustom(this.code, currDto.code);
				this.description = DefVal.setCustom(this.description, currDto.description);
				this.geo = DefVal.setCustom(this.geo, currDto.geo);
				this.role = DefVal.setCustom(this.role, currDto.role);
				this.info = DefVal.setCustom(this.info, currDto.info);
				this.more = DefVal.setCustom(this.more, currDto.more);
				this.mark = DefVal.setCustom(this.mark, currDto.mark);
				this.span = new ListVal(MoreVal.getFieldByKey(currDto.more, "Span"), "");
			}

			if (listDto.size() == 0) {
				this.clear();
			}
		} catch (Exception ex) {
			WB.addLog("JobDaily.isExist():void, ex=" + ex.getMessage(), "", "JobDaily");
		}
	}

	public JobDaily(String ParentId, String Info) throws Exception {
		// origin - 07.05.2025, last edit - 20.11.2025
		this.clear();
		this.src = ParentId + "," + Info;
		this.parent = ParentId;
		this.info = Info;// ex."Info.Staff.Late"
		this.isExist();
		this.getVal();
		this.validate();
	}

	private void clear() throws Exception {
		// origin - 07.05.2025, last edit - 02.11.2026
		try {
			this.table = "Face";
			this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.more = this.mark = "";
			this.defect = "";
			this.date1 = this.date2 = this.span = new ListVal();
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("JobDaily.clear():void, ex=" + ex.getMessage(), "", "JobDaily");
		}
	}

	public JobDaily() throws Exception {
		// origin - 07.05.2025, last edit - 07.05.2025
		this.clear();
	}

	public String toString() {
		// origin - 07.05.2025, last edit - 02.11.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", span ", this.span.id);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", val.size ", this.val.size());
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 07.05.2025, last edit - 07.10.2025
		try {

//			WB.addLog2("JobDaily.test.getTotalSpan(SpanDate,2String):UnitVal", "", "JobDaily");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-05", "2025-02-03", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1.StaffTable1.ChiefAccountant" }) {
//					for (var tmp3 : new String[] { "Info.Staff.Late" }) {
//						WB.addLog2(
//								"JobDaily.test.getTotalSpan(SpanDate,2String):UnitVal, res="
//										+ JobDaily.getTotalSpan(SpanDate.getQuarter(tmp1), tmp2, tmp3) + ", spanDate="
//										+ SpanDate.getMonth(tmp1).id + ", faceParentId=" + tmp2 + ", info=" + tmp3,
//								"", "JobDaily");
//					}
//				}
//			}

//			WB.addLog2("JobDaily.test.getSpan(3String):UnitVal", "", "JobDaily");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-05", "2025-02-03", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1.StaffTable1.ChiefAccountant" }) {
//					for (var tmp3 : new String[] { "Info.Staff.Late", "Info.Staff.Skip" }) {
//						WB.addLog2(
//								"JobDaily.test.getSpan(3String):UnitVal, res=" + JobDaily.getSpan(tmp1, tmp2, tmp3)
//										+ ", date1=" + tmp1 + ", faceParentId=" + tmp2 + ", info=" + tmp3,
//								"", "JobDaily");
//					}
//				}
//			}

//			WB.addLog2("JobDaily.test.get(String):List<FaceDto>", "", "JobDaily");
//			for (var tmp1 : new String[] { "Face.FA1.StaffTable1.ChiefAccountant", "Face.FA1.StaffTable1.Boss" }) {
//				var tmp2 = JobDaily.get(tmp1);
//				WB.addLog2("JobDaily.test.get(String):List<FaceDto>, res.size=" + tmp2.size() + ", parentId=" + tmp1,
//						"", "JobDaily");
//				WB.log(tmp2, "JobDaily");
//			}

//			WB.addLog2("JobDaily.test.getCurr(2String):List<FaceDto>", "", "JobDaily");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-05", "2025-02-03", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1.StaffTable1.ChiefAccountant" }) {
//					var tmp3 = JobDaily.getCurr(tmp1, tmp2);
//					WB.addLog2("JobDaily.test.getCurr(2String):List<FaceDto>, res.size=" + tmp3.size() + ", date1="
//							+ tmp1 + ", parentId=" + tmp2, "", "JobDaily");
//					WB.log(tmp3, "JobDaily");
//				}
//			}

//			WB.addLog2("JobDaily.test.getCurr(3String):FaceDto", "", "JobDaily");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-05", "2025-02-03", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1.StaffTable1.ChiefAccountant" }) {
//					for (var tmp3 : new String[] { "Info.Staff.Late", "Info.Staff.Skip" }) {
//						WB.addLog2(
//								"JobDaily.test.getCurr(3String):FaceDto, res=" + JobDaily.getCurr(tmp1, tmp2, tmp3)
//										+ ", date1=" + tmp1 + ", faceParentId=" + tmp2 + ", info=" + tmp3,
//								"", "JobDaily");
//					}
//				}
//			}

//			WB.addLog2("JobDaily.test.ctor(2String)", "", "JobDaily");
//			for (var tmp1 : new String[] { "Face.FA1.StaffTable1.ChiefAccountant", "Face.FA1.StaffTable1.Boss" }) {
//				for (var tmp2 : new String[] { "Info.Staff.Late", "Info.Staff.Skip" }) {
//					var tmp3 = new JobDaily(tmp1, tmp2);
//					WB.addLog2("JobDaily.test.ctor(2String)=" + tmp3, "", "JobDaily");
//					WB.log(tmp3.val, "JobDaily");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("JobDaily.test():void, ex=" + ex.getMessage(), "", "JobDaily");
		}
	}
}