import java.util.ArrayList;
import java.util.List;

public final class Staff {
	// origin - 12.03.2025, last edit - 12.10.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, code, description, geo, role, info, more, mark;
	// special fields
	public String faceCatId, fullName, comment;
	// special timestamp fields
	public ListVal date1, date2, salary, jobCycle;
	// list common + special + timestamp fields in unified val
	public List<FaceDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Staff.static ctor, ex=" + ex.getMessage(), "", "Staff");
		}
	}

	// for person total salary for all staff position on date1
	public static double getTotalCurrSalary(String date1, String parentId) throws Exception {
		// origin - 31.03.2025, last edit - 04.10.2025
		double res = 0.00;
		try {
			var listDto = Staff.getCurr(date1, parentId);
			for (var currStaff : listDto) {
				res = res + Conv.getDouble(currStaff.salary);// Staff.getCurrSalary(date1, parentId, currStaff.code);
			}
		} catch (Exception ex) {
			WB.addLog("Staff.getCurrTotalSalary(2String):double, ex=" + ex.getMessage(), "", "Staff");
		}
		return res;
	}

	// item Staff position salary on date1
	public static double getCurrSalary(String date1, String parentId, String staffTableId) throws Exception {
		// origin - 31.03.2025, last edit - 02.10.2025
		double res = 0.00;
		try {
			var tmp = Staff.getCurr(date1, parentId, staffTableId).salary;
			res = Conv.getDouble(tmp);
		} catch (Exception ex) {
			WB.addLog("Staff.getCurrSalary(3String):double, ex=" + ex.getMessage(), "", "Staff");
		}
		return res;
	}

	// full list staff positions for all person
	public static List<FaceDto> get() throws Exception {
		// origin - 27.06.2025, last edit - 26.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter("Role.Face.Staff"), "Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					for (var curr : new Staff(currFace.parent, currFace.code).val) {
						if (curr.id.isEmpty() == false) {
							res.add(curr);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Staff.get():List<FaceDto>, ex=" + ex.getMessage(), "", "Staff");
		}
		return res;
	}

	// full list staff positions for person
	public static List<FaceDto> get(String parentId) throws Exception {
		// origin - 04.05.2025, last edit - 26.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, "Role.Face.Staff"),
					"Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					for (var curr : new Staff(currFace.parent, currFace.code).val) {
						if (curr.id.isEmpty() == false) {
							res.add(curr);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Staff.get(String):List<FaceDto>, ex=" + ex.getMessage(), "", "Staff");
		}
		return res;
	}

	// full list staff positions for person on date1 (currSalary)
	public static List<FaceDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 12.03.2025, last edit - 26.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, "Role.Face.Staff"),
					"Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					var currFaceStaff = new Staff(currFace.parent, currFace.code);
					var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceStaff.val, "");
					if (curr.id.isEmpty() == false) {
						res.add(curr);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Staff.getCurr(2String):List<FaceDto>, ex=" + ex.getMessage(), "", "Staff");
		}
		return res;
	}

	// item staff position for person on date1 (currSalary)
	public static FaceDto getCurr(String date1, String parentId, String staffTableId) throws Exception {
		// origin - 12.03.2025, last edit - 26.10.2025
		FaceDto res = new FaceDto();
		try {
			var currFaceStaffNote = new Staff(parentId, staffTableId);
			var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceStaffNote.val, "");
			if (curr.id.isEmpty() == false) {
				res = curr;
			}
		} catch (Exception ex) {
			WB.addLog("Staff.getCurr(3String):FaceDto, ex=" + ex.getMessage(), "", "Staff");
		}
		return res;
	}

	private void getVal() throws Exception {
		// origin - 12.03.2025, last edit - 02.10.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currSalary = "";
			String currJobCycle = "";
			String currMore = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currSalary = this.salary.getByIndex(i);
				currJobCycle = this.jobCycle.getByIndex(i);
				currMore = "";
				currMore = currMore + MoreVal.setPartMore("Salary", currSalary);
				currMore = currMore + MoreVal.setPartMore("JobCycle", currJobCycle);
				currMore = currMore + MoreVal.setPartMore("FaceCatId", this.faceCatId);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description, this.geo,
						this.role, this.info, currMore, this.mark);
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("Staff.getVal():void, ex=" + ex.getMessage(), "", "Staff");
		}
	}

	private void isExist() throws Exception {
		// origin - 12.03.2025, last edit - 02.10.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentCodeRoleFilter(this.parent, this.code, "Role.Face.Staff"), "Face");
			if (listDto.size() != 0) {
				var currDto = listDto.getFirst();
				var tmp = new SpanDate(currDto.date1, currDto.date2);
				this.date1 = new ListVal(tmp.date1);
				this.date2 = new ListVal(tmp.date2);
				this.id = DefVal.setCustom(this.id, currDto.id);
				this.parent = DefVal.setCustom(this.parent, currDto.parent);
				this.code = DefVal.setCustom(this.code, currDto.code);
				this.description = DefVal.setCustom(this.description, currDto.description);
				this.geo = DefVal.setCustom(this.geo, currDto.geo);
				this.role = DefVal.setCustom(this.role, currDto.role);
				this.info = DefVal.setCustom(this.info, currDto.info);
				this.more = DefVal.setCustom(this.more, currDto.more);
				this.mark = DefVal.setCustom(this.mark, currDto.mark);
				this.getFieldFromMore();
				this.isExist = true;
				this.isValid = true;
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("Staff.isExist():void, ex=" + ex.getMessage(), "", "Staff");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 13.08.2025, last edit - 13.08.2025
		try {
			this.salary = new ListVal(MoreVal.getFieldByKey(this.more, "Salary"), "");
			this.jobCycle = new ListVal(MoreVal.getFieldByKey(this.more, "JobCycle"), "");
			this.faceCatId = MoreVal.getFieldByKey(this.more, "FaceCatId");
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("Staff.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Staff");
		}
	}

	public Staff(String ParentId, String StaffTableId) throws Exception {
		// origin - 12.03.2025, last edit - 11.08.2025
		this.clear();
		this.src = ParentId + "," + StaffTableId;
		this.parent = ParentId;
		this.code = StaffTableId;
		this.isExist();
		this.getVal();
	}

	private void clear() throws Exception {
		// origin - 12.03.2025, last edit - 02.10.2025
		try {
			this.isValid = false;
			this.isExist = false;
			this.table = "Face";
			this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.mark = this.more = "";
			this.faceCatId = this.comment = this.fullName = "";
			this.date1 = this.date2 = this.salary = this.jobCycle = new ListVal();
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("Staff.clear():void, ex=" + ex.getMessage(), "", "Staff");
		}
	}

	public Staff() throws Exception {
		// origin - 12.03.2025, last edit - 12.03.2025
		this.clear();
	}

	public String toString() {
		// origin - 12.03.2025, last edit - 02.10.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", faceCatId ", this.faceCatId);
			res = res + Fmtr.addIfNotEmpty(", salary ", this.salary.id);
			res = res + Fmtr.addIfNotEmpty(", jobCycle ", this.jobCycle.id);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", val.size ", this.val.size());
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 12.03.2025, last edit - 04.10.2025
		try {

//			WB.addLog2("Staff.test.get():List<FaceDto>", "", "Staff");
//			for (var tmp1 : new String[] { "Face.Person.Template", "Face.Tralala" }) {
//				var tmp2 = Staff.get(tmp1);
//				WB.addLog2("Staff.test.get():List<FaceDto>, res.size=" + tmp2.size() + ", parentId=" + tmp1, "",
//						"Staff");
//				WB.log(tmp2, "Staff");
//			}

//			WB.addLog2("Staff.test.getTotalCurrSalary(2String):double", "", "Staff");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.Person.Template" }) {
//					WB.addLog2("Staff.test.getTotalCurrSalary(2String):double, res="
//							+ Staff.getTotalCurrSalary(tmp1, tmp2) + ", date1=" + tmp1 + ", parentId=" + tmp2, "",
//							"Staff");
//				}
//			}

//			WB.addLog2("Staff.test.getCurrSalary(3String):double for person/staffTable", "", "Staff");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.Person.Template" }) {
//					for (var tmp3 : new String[] { "Face.Person.Template.StaffTable1.Boss",
//							"Face.Person.Template.StaffTable1.ChiefAccountant" }) {
//						WB.addLog2("Staff.test.getCurrSalary(3String):double for person/staffTable, res="
//								+ Staff.getCurrSalary(tmp1, tmp2, tmp3) + ", date1=" + tmp1 + ", parentId=" + tmp2
//								+ ", staffTableId=" + tmp3, "", "Staff");
//					}
//				}
//			}

//			WB.addLog2("Staff.test.getCurr(2String):List<FaceDto>", "", "Staff");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.Person.Template", "Face.Tralala" }) {
//					var tmp3 = Staff.getCurr(tmp1, tmp2);
//					WB.addLog2("Staff.test.getCurr(2String):List<FaceDto>, res.size=" + tmp3.size() + ", date1=" + tmp1
//							+ ", parentId=" + tmp2, "", "Staff");
//					WB.log(tmp3, "Staff");
//				}
//			}

//			WB.addLog2("Staff.test.getCurr(3String):FaceDto", "", "Staff");
//			for (var tmp1 : new String[] { "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01", "2025-02-28",
//					"2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.Person.Template" }) {
//					for (var tmp3 : new String[] { "Face.Person.Template.StaffTable1.Boss",
//							"Face.Person.Template.StaffTable1.ChiefAccountant" }) {
//						WB.addLog2(
//								"Staff.test.getCurr(3String):FaceDto, res=" + Staff.getCurr(tmp1, tmp2, tmp3)
//										+ ", date1=" + tmp1 + ", parentId=" + tmp2 + ", staffTableId=" + tmp3,
//								"", "Staff");
//					}
//				}
//			}

//			WB.addLog2("Staff.test.ctor(2String)", "", "Staff");
//			for (var tmp1 : new String[] { "Face.Person.Template , Face.Person.Template.StaffTable1.Boss",
//					"Face.Person.Template , Face.Person.Template.StaffTable1.ChiefAccountant",
//					"Face.kgd , Face.kgd.StaffTable1.ChiefAccountant",
//					"Face.Tralala , Face.FA1.StaffTable1.Tralala" }) {
//				var tmp2 = new TwoVal(tmp1);
//				var tmp3 = new Staff(tmp2.val1, tmp2.val2);
//				WB.addLog2("Staff.test.ctor(2String)=" + tmp3, "", "Staff");
//				WB.log(tmp3.val, "Staff");
//			}

		} catch (Exception ex) {
			WB.addLog("Staff.test():void, ex=" + ex.getMessage(), "", "Staff");
		}
	}
}