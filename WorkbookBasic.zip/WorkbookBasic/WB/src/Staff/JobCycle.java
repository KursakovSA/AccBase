import java.util.ArrayList;
import java.util.List;

public final class JobCycle {
	// origin - 11.04.2025, last edit - 20.11.2025
	public String table, parent, code, description, geo, role, info, mark, more, fullName, comment, defect;
	public String id, src, jobWeek, context;
	private List<String> srcList;
	public JobDay jobDay, addSaturdayJobDay;
	public ListVal date1, date2, jobCycle;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("JobCycle.static ctor, ex=" + ex.getMessage(), "", "JobCycle");
		}
	}

	private void validate() throws Exception { // TODO
		// origin - 20.11.2025, last edit - 23.05.2026
		try {
			this.defect = Fmtr.addIfStrEmpty(this.defect, this.jobCycle.id, "empty jobCycle; ");
			this.defect = Fmtr.addIfStrEmpty(this.defect, this.jobDay.id, "empty jobDay; ");
			this.defect = Fmtr.addIfStrEmpty(this.defect, this.jobWeek, "empty jobWeek; ");
		} catch (Exception ex) {
			WB.addLog("JobCycle.validate():void, ex=" + ex.getMessage(), "", "JobCycle");
		}
	}

	private void getPart() throws Exception {
		// origin - 17.04.2025, last edit - 13.06.2025
		try {
			if (this.srcList.size() == 0) {// if empty src then by default
				this.jobWeek = "5-2";
				this.jobDay = new JobDay("9-18/13-14"); // by default
			}

			if (srcList.size() == 1) { // ex. "6-1 8-17 10-13"
				this.jobWeek = srcList.get(0);
				this.jobDay = new JobDay("9-18/13-14"); // by default
			}

			if (srcList.size() == 2) { // ex. "6-1 8-17 10-13", when 8-17 - this is jobDay
				this.jobWeek = srcList.get(0);
				this.jobDay = new JobDay(srcList.get(1));
			}

			if (srcList.size() == 3) { // ex. "6-1 8-17 10-13", when 10-13 - this is addSaturdayJobDay
				this.jobWeek = srcList.get(0);
				this.jobDay = new JobDay(srcList.get(1));
				this.addSaturdayJobDay = new JobDay(srcList.get(2));
			}
		} catch (Exception ex) {
			WB.addLog("JobCycle.getPart():void, ex=" + ex.getMessage(), "", "JobCycle");
		}
	}

	private void getId() throws Exception {
		// origin - 12.04.2025, last edit - 13.06.2025
		try {
			if (this.srcList.size() >= 1) {
				this.id = this.id + srcList.getFirst();
			}
			this.id = this.id + "/" + this.jobDay.id + "/" + this.addSaturdayJobDay.id;
		} catch (Exception ex) {
			WB.addLog("JobCycle.getId():void, ex=" + ex.getMessage(), "", "JobCycle");
		}
	}

	public JobCycle(String Src) throws Exception {
		// origin - 12.04.2025, last edit - 20.11.2025
		this.clear();
		this.src = Etc.fixTrim(Src);
		this.srcList = Fmtr.listVal(this.src, " ");
		this.getPart();
		this.getId();
		this.validate();
	}

	public JobCycle() throws Exception {
		// origin - 11.04.2025, last edit - 27.04.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 11.04.2025, last edit - 20.11.2025
		try {
			this.srcList = new ArrayList<String>();
			this.jobDay = new JobDay();
			this.addSaturdayJobDay = new JobDay();
			this.table = this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.more = this.mark = "";
			this.fullName = this.comment = this.jobWeek = this.context = this.defect = "";
			this.date1 = this.date2 = this.jobCycle = new ListVal();
		} catch (Exception ex) {
			WB.addLog("JobCycle.clear():void, ex=" + ex.getMessage(), "", "JobCycle");
		}
	}

	public String toString() {
		// origin - 11.04.2025, last edit - 20.11.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway(", src ", this.src);
			res = res + Fmtr.addAnyway(", srcList ", this.srcList);
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", context ", this.context);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", jobWeek ", this.jobWeek);
			res = res + Fmtr.addIfNotEmpty(", jobDay ", this.jobDay.id);
			res = res + Fmtr.addIfNotEmpty(", addSaturdayJobDay ", this.addSaturdayJobDay.id);
			res = res + Fmtr.addIfNotEmpty(", jobCycle ", this.jobCycle.id);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 11.04.2025, last edit - 27.06.2025
		try {

//			WB.addLog2("JobCycle.test.ctor(String)", "", "JobCycle");
//			for (var tmp1 : new String[] { "", "5-2 ", "5-2 8-18", "6-1 8-17 10-13", "7-0 9-20/14-15",
//					"7-0 9-20/14-15 10-13" }) {
//				WB.addLog2("JobCycle.test.ctor(String)=" + new JobCycle(tmp1), "", "JobCycle");
//			}

		} catch (Exception ex) {
			WB.addLog("JobCycle.test():void, ex=" + ex.getMessage(), "", "JobCycle");
		}
	}
}