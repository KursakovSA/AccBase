import java.util.ArrayList;
import java.util.List;

public class Accrual extends ModelDto {
	// origin - 22.12.2024, last edit - 09.01.2025
	public String accrualDealId, accrualTermId;
	public ListVal pointBasicDayOff, commonExtraDayOff;
	public UnitVal performEvery, commonBasicDayOff, baseInterestContains, basePenaltyContains, interestRate,
			penaltyRate, billingCycle;
	public RangeVal totalPenaltyAccrualLimit, totalOverPaymentLimit;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Accrual.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Accrual");
		} finally {
			Etc.doNothing();
		}
	}

	public static List<ModelDto> build(String in) throws Exception {
		// origin - 09.01.2025, last edit - 09.01.2025
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			String[] strDto = in.split(WB.strSpace + WB.strBraceRight + WB.strSpace);
			for (var currStrDto : strDto) {
				res.add(new Accrual(currStrDto));
			}
		} catch (Exception ex) {
			WB.addLog("Accrual.build, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Accrual");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Accrual.build, res=" + res + ", in=" + in, WB.strEmpty,
		// "Accrual");
		return res;
	}

	public void fix() throws Exception { // TODO
		// origin - 28.12.2024, last edit - 01.01.2025
		try {
			super.fix();
			// this.slice = DefVal.set(this.slice, Slice.Norm);
			// this.sign = DefVal.set(this.sign, Sign.AcctDt);
		} catch (Exception ex) {
			WB.addLog("Accrual.fix, ex=" + ex.getMessage(), WB.strEmpty, "Accrual");
		} finally {
			Etc.doNothing();
		}
	}

	public void isValid() throws Exception { // TODO
		// origin - 22.12.2024, last edit - 01.01.2025
		super.isValid();
		try {
//			if (this.parent.isEmpty() | this.role.isEmpty() | this.info.isEmpty()) {
//				this.isValid = false;
//			}
		} catch (Exception ex) {
			WB.addLog("Accrual.isValid, ex=" + ex.getMessage(), WB.strEmpty, "Accrual");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Accrual.isValid=" + this.isValid,WB.strEmpty,"Accrual");
	}

	public void isExist() throws Exception {
		// origin - 22.12.2024, last edit - 09.01.2025
		super.isExist();
		try {
			var tmp1 = ReadSet.getEqualsByCode(WB.abcLast.template, this.accrualDealId);
			if (tmp1.size() != 0) {
				// var currDto = ReadSet.getEqualsByCode(WB.abcLast.template,
				// this.accrualDealId).getFirst();
				var currDto = tmp1.getFirst();
				this.code = currDto.code;
				this.parent = currDto.parent;
				this.face1 = currDto.face1;
				this.face2 = currDto.face2;
				this.face = currDto.face;
				this.description = currDto.description;
				this.geo = currDto.geo;
				this.role = currDto.role;
				this.info = currDto.info;
				this.more = this.more + WB.strEmpty + currDto.more;

				// level accrual deal
				this.performEvery = new UnitVal(MoreVal.getFieldByKey(this.more, "PerformEvery"));
				this.commonBasicDayOff = new UnitVal(MoreVal.getFieldByKey(this.more, "CommonBasicDayOff"));
				this.commonExtraDayOff = new ListVal(MoreVal.getFieldByKey(this.more, "CommonExtraDayOff"),
						WB.strEmpty);
				this.pointBasicDayOff = new ListVal(MoreVal.getFieldByKey(this.more, "PointBasicDayOff"), WB.strEmpty);
				this.baseInterestContains = new UnitVal(MoreVal.getFieldByKey(this.more, "BaseInterestContains"));
				this.basePenaltyContains = new UnitVal(MoreVal.getFieldByKey(this.more, "BasePenaltyContains"));
				this.totalPenaltyAccrualLimit = new RangeVal(
						MoreVal.getFieldByKey(this.more, "TotalPenaltyAccrualLimit"));
			}

			// level term deal
			var tmp2 = ReadSet.getEqualsByCode(WB.abcLast.template, this.accrualTermId);
			if (tmp2.size() != 0) {
				// currDto = ReadSet.getEqualsByCode(WB.abcLast.template,
				// this.accrualTermId).getFirst();
				var currDto = tmp2.getFirst();
				this.more = this.more + WB.strEmpty + currDto.more;
				this.interestRate = new UnitVal(MoreVal.getFieldByKey(this.more, "InterestRate"));
				this.penaltyRate = new UnitVal(MoreVal.getFieldByKey(this.more, "PenaltyRate"));
				this.billingCycle = new UnitVal(MoreVal.getFieldByKey(this.more, "BillingCycle"));
				this.totalOverPaymentLimit = new RangeVal(MoreVal.getFieldByKey(this.more, "TotalOverPaymentLimit"));
				// this.isExist = true;
			}

			if ((tmp1.size() != 0) & (tmp2.size() != 0)) {
				this.isExist = true;
			}

		} catch (Exception ex) {
			WB.addLog("Accrual.isExist, ex=" + ex.getMessage(), WB.strEmpty, "Accrual");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Accrual.isExist=" + this.isExist, WB.strEmpty,"Accrual");
	}

	public Accrual(ModelDto dto) throws Exception {
		// origin - 09.01.2025, last edit - 09.01.2025
		this(dto.id, dto.code);
	}

	public Accrual(String accrualDealId, String accrualTermId) throws Exception {
		// origin - 22.12.2024, last edit - 09.01.2025
		this.clear();
		this.src = accrualDealId + WB.strSpace + accrualDealId;
		this.accrualDealId = accrualDealId;
		this.accrualTermId = accrualTermId;
		this.id = this.src;
		this.isExist();
		this.isValid();
		this.fix();
	}

	public Accrual(String in) throws Exception {
		// origin - 09.01.2025, last edit - 09.01.2025
		super(in);
	}

	public Accrual() throws Exception {
		// origin - 22.12.2024, last edit - 01.01.2025
		this.clear();
	}

	public void clear() throws Exception {
		// origin - 28.11.2024, last edit - 09.01.2025
		try {
			super.clear();
			this.table = "Deal"; // ??magic string ??
			this.accrualTermId = this.accrualDealId = WB.strEmpty;

			this.pointBasicDayOff = this.commonExtraDayOff = new ListVal();
			this.performEvery = this.commonBasicDayOff = this.baseInterestContains = this.basePenaltyContains = this.interestRate = this.penaltyRate = this.billingCycle = new UnitVal();
			this.totalPenaltyAccrualLimit = this.totalOverPaymentLimit = new RangeVal();

		} catch (Exception ex) {
			WB.addLog("Accrual.clear, ex=" + ex.getMessage(), WB.strEmpty, "Accrual");
		} finally {
			Etc.doNothing();
		}
	}

	public String toString() {
		// origin - 22.12.2024, last edit - 09.01.2025
		String res = WB.strEmpty;
		try {
			res = res + Fmtr.addAnyway("src ", this.src.length());
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id.length());
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addIfNotEmpty(", accrualTermId ", this.accrualTermId.length());
			res = res + Fmtr.addIfNotEmpty(", accrualDealId ", this.accrualDealId.length());

			// level accrualDeal
			res = res + Fmtr.addAnyway(", performEvery ", this.performEvery.id);
			res = res + Fmtr.addAnyway(", commonBasicDayOff ", this.commonBasicDayOff.id);
			res = res + Fmtr.addAnyway(", commonExtraDayOff ", this.commonExtraDayOff.id);
			res = res + Fmtr.addAnyway(", pointBasicDayOff ", this.pointBasicDayOff.id);
			res = res + Fmtr.addIfNotEmpty(", baseInterestContains ", this.baseInterestContains.id);
			res = res + Fmtr.addIfNotEmpty(", basePenaltyContains ", this.basePenaltyContains.id);
			res = res + Fmtr.addIfNotEmpty(", totalPenaltyAccrualLimit ", this.totalPenaltyAccrualLimit.id);

			// level accrualTerm
			res = res + Fmtr.addIfNotEmpty(", interestRate ", this.interestRate.id);
			res = res + Fmtr.addIfNotEmpty(", penaltyRate ", this.penaltyRate.id);
			res = res + Fmtr.addIfNotEmpty(", billingCycle ", this.billingCycle.id);
			res = res + Fmtr.addIfNotEmpty(", totalOverPaymentLimit ", this.totalOverPaymentLimit.id);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 22.12.2024, last edit - 09.01.2025
		try {

//			// ctor()
//			WB.addLog2("Accrual.test.ctor()=" + new Accrual(), WB.strEmpty, "Accrual");

			// build
			for (var tmp : Accrual.build(" id @ | code @  } "
					+ " id @ Deal.tralala.Accrual | code Deal.tralala.Term1.Accrual } "
					+ " id @ Deal.Face.Pawnshop.Template1.2024-11-08.Accrual | code @ Deal.Face.Pawnshop.Template1.2024-11-08.Term1.Accrual } ")) {
				WB.addLog2("Accrual.test.build(id. code)=" + new Accrual(tmp), WB.strEmpty, "Accrual");
			}

		} catch (Exception ex) {
			WB.addLog("Accrual.test, ex=" + ex.getMessage(), WB.strEmpty, "Accrual");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Accrual.test end ", WB.strEmpty, "Accrual");
	}
}
