import java.util.ArrayList;
import java.util.List;

public class Accrual {
	// origin - 22.12.2024, last edit - 01.05.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, face1, face2, face, date1, date2, code, description, geo, role, info, more,
			mark;
	// special fields
	public ListVal composition, pointBasicDayOff, commonExtraDayOff;
	public UnitVal performEvery, commonBasicDayOff, baseInterestContains, basePenaltyContains, interestRate,
			penaltyRate, billingCycle;
	public RangeVal totalPenaltyAccrualLimit, totalOverPaymentLimit;
	public String context;
	public static String strTerm, strAccrual;

	static {
		try {
			Accrual.strTerm = "Term";
			Accrual.strAccrual = "Accrual";
		} catch (Exception ex) {
			WB.addLog("Accrual.static ctor, ex=" + ex.getMessage(), "", "Accrual");
		}
	}

	public static String getCodePattern(String codeParent, String strObj) throws Exception {
		// origin - 26.01.2025, last edit - 19.03.2025
		String res = "";
		codeParent = Etc.fixTrim(codeParent);
		strObj = Etc.fixTrim(strObj);
		try {
			if (strObj.isEmpty() == false) {
				res = res + codeParent + "." + Etc.fixTrim(strObj);// ex. "PawnDoc.Template1.V1" + "." + "Accrual"
			}
		} catch (Exception ex) {
			WB.addLog("Accrual.getCodeRatePattern(string,string), ex=" + ex.getMessage(), "", "Accrual");
		}
		return res;
	}

	public void isExist() throws Exception {
		// origin - 22.12.2024, last edit - 01.05.2025
		try {
			List<ModelDto> srcDto = new ArrayList<ModelDto>();
			if (Etc.strContains(this.context, Prolongation.strTerm)) {
				srcDto = WB.abcLast.template;
				var tmp1 = ReadSet.getEqualsByCode(srcDto, this.id);
				if (tmp1.size() != 0) {
					var currDto = tmp1.getFirst();
					this.parent = currDto.parent;
					this.face1 = currDto.face1;
					this.face2 = currDto.face2;
					this.face = currDto.face;
					this.description = currDto.description;
					this.geo = currDto.geo;
					this.role = currDto.role;
					this.info = currDto.info;
					this.more = this.more + "" + currDto.more;

					// level id
					this.composition = new ListVal(MoreVal.getFieldByKey(this.more, "Composition"), "");
					this.performEvery = new UnitVal(MoreVal.getFieldByKey(this.more, "PerformEvery"));
					this.commonBasicDayOff = new UnitVal(MoreVal.getFieldByKey(this.more, "CommonBasicDayOff"));
					this.commonExtraDayOff = new ListVal(MoreVal.getFieldByKey(this.more, "CommonExtraDayOff"), "");
					this.pointBasicDayOff = new ListVal(MoreVal.getFieldByKey(this.more, "PointBasicDayOff"), "");
					this.baseInterestContains = new UnitVal(MoreVal.getFieldByKey(this.more, "BaseInterestContains"));
					this.basePenaltyContains = new UnitVal(MoreVal.getFieldByKey(this.more, "BasePenaltyContains"));
					this.totalPenaltyAccrualLimit = new RangeVal(
							MoreVal.getFieldByKey(this.more, "TotalPenaltyAccrualLimit"));
					this.isExist = true;
				}

				// level code
				var tmp2 = ReadSet.getEqualsByCode(srcDto, this.code);
				if (tmp2.size() != 0) {
					var currDto = tmp2.getFirst();
					this.more = this.more + "" + currDto.more;
					this.interestRate = new UnitVal(MoreVal.getFieldByKey(this.more, "InterestRate"));
					this.penaltyRate = new UnitVal(MoreVal.getFieldByKey(this.more, "PenaltyRate"));
					this.billingCycle = new UnitVal(MoreVal.getFieldByKey(this.more, "BillingCycle"));
					this.totalOverPaymentLimit = new RangeVal(
							MoreVal.getFieldByKey(this.more, "TotalOverPaymentLimit"));
					this.isExist = true;
				}
			}

		} catch (Exception ex) {
			WB.addLog("Accrual.isExist, ex=" + ex.getMessage(), "", "Accrual");
		}
	}

//	public Accrual(ModelDto dto) throws Exception {
//		// origin - 09.01.2025, last edit - 01.05.2025
//		this(dto.id, dto.code);
//	}

	public Accrual(String Id, String Code) throws Exception {
		// origin - 22.12.2024, last edit - 01.05.2025
		this.clear();
		this.src = Id + ", " + Code;
		this.id = Id;
		this.code = Code;
		this.context = Accrual.strTerm; // default
		this.isExist();
	}

	public Accrual() throws Exception {
		// origin - 22.12.2024, last edit - 01.01.2025
		this.clear();
	}

	public void clear() throws Exception {
		// origin - 28.11.2024, last edit - 01.05.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = "Deal";
			this.id = this.parent = this.face1 = this.face2 = this.face = this.date1 = this.date2 = this.code = this.description = "";
			this.geo = this.role = this.info = this.more = this.mark = "";

			this.composition = this.pointBasicDayOff = this.commonExtraDayOff = new ListVal();
			this.performEvery = this.commonBasicDayOff = this.baseInterestContains = this.basePenaltyContains = this.interestRate = this.penaltyRate = this.billingCycle = new UnitVal();
			this.totalPenaltyAccrualLimit = this.totalOverPaymentLimit = new RangeVal();

		} catch (Exception ex) {
			WB.addLog("Accrual.clear, ex=" + ex.getMessage(), "", "Accrual");
		}
	}

	public String toString() {
		// origin - 22.12.2024, last edit - 20.03.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src.length());
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			// level id
			res = res + Fmtr.addAnyway(", composition ", this.composition.id);
			res = res + Fmtr.addAnyway(", performEvery ", this.performEvery.id);
			res = res + Fmtr.addAnyway(", commonBasicDayOff ", this.commonBasicDayOff.id);
			res = res + Fmtr.addAnyway(", commonExtraDayOff ", this.commonExtraDayOff.id);
			res = res + Fmtr.addAnyway(", pointBasicDayOff ", this.pointBasicDayOff.id);
			res = res + Fmtr.addIfNotEmpty(", baseInterestContains ", this.baseInterestContains.id);
			res = res + Fmtr.addIfNotEmpty(", basePenaltyContains ", this.basePenaltyContains.id);
			res = res + Fmtr.addIfNotEmpty(", totalPenaltyAccrualLimit ", this.totalPenaltyAccrualLimit.id);

			// level code
			res = res + Fmtr.addIfNotEmpty(", interestRate ", this.interestRate.id);
			res = res + Fmtr.addIfNotEmpty(", penaltyRate ", this.penaltyRate.id);
			res = res + Fmtr.addIfNotEmpty(", billingCycle ", this.billingCycle.id);
			res = res + Fmtr.addIfNotEmpty(", totalOverPaymentLimit ", this.totalOverPaymentLimit.id);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 22.12.2024, last edit - 01.05.2025
		try {

			// ctor (String,String)
			WB.addLog2("Accrual.test.ctor(String,String)", "", "Accrual");
//			for (var tmp1 : new String[] { "PawnDoc.Template1.V1.Term1.Accrual", "PawnDoc.Template1.V1.Term2.Accrual",
//					"PawnDoc.Tralala" }) {
//				for (var tmp2 : new String[] { "PawnDoc.Template1.V1.Term1.Accrual",
//						"PawnDoc.Template1.V1.Term2.Accrual", "PawnDoc.Tralala" }) {
			WB.addLog2(
					"Accrual.test.ctor(String,String)="
							+ new Accrual("PawnDoc.Template1.V1.Accrual", "PawnDoc.Template1.V1.Term1.Accrual"),
					"", "Accrual");
			WB.addLog2(
					"Accrual.test.ctor(String,String)="
							+ new Accrual("PawnDoc.Template1.V1.Accrual", "PawnDoc.Template1.V1.Term2.Accrual"),
					"", "Accrual");
			// }
			// }

//			// ctor()
//			WB.addLog2("Accrual.test.ctor()", "", "Accrual");
//			WB.addLog2("Accrual.test.ctor()=" + new Accrual(), "", "Accrual");

		} catch (Exception ex) {
			WB.addLog("Accrual.test, ex=" + ex.getMessage(), "", "Accrual");
		}
	}
}