public class Accrual extends ModelDto {
	// origin - 22.12.2024, last edit - 22.12.2024

	// level deal
	public UnitVal commonDayOff, pointDayOff, baseInterestContains, basePenaltyContains, totalPenaltyAccrualLimit;
	// level term
	public UnitVal interestRate, penaltyRate, billingCycle, totalOverPaymentLimit;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Accrual.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Accrual");
		} finally {
			Etc.doNothing();
		}
	}

	public void isValid() throws Exception {
		// origin - 22.12.2024, last edit - 22.12.2024
		super.isValid();
		try {
			if (this.parent.isEmpty() | this.role.isEmpty() | this.info.isEmpty()) {
				this.isValid = false;
			}
		} catch (Exception ex) {
			WB.addLog("Accrual.isValid, ex=" + ex.getMessage(), WB.strEmpty, "Accrual");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Accrual.isValid=" + this.isValid,WB.strEmpty,"Accrual");
	}

	public void isExist() throws Exception { // TOTHINK
		// origin - 22.12.2024, last edit - 22.12.2024
		super.isExist();
		try {
			for (var currPrice : WB.abcLast.price) { // TOTHINK
				if (Etc.strEquals(currPrice.id, this.id)) {
					this.code = currPrice.code;
					this.parent = currPrice.parent;
					this.description = currPrice.description;
					this.role = currPrice.role;
					this.info = currPrice.info;
					this.unit = currPrice.unit;
					this.isExist = true;
					break;
				}
			}

		} catch (Exception ex) {
			WB.addLog("Accrual.isExist, ex=" + ex.getMessage(), WB.strEmpty, "Accrual");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Accrual.isExist=" + this.isExist, WB.strEmpty,"Accrual");
	}

	public Accrual(String termId) throws Exception { //TOTHINK
		// origin - 22.12.2024, last edit - 22.12.2024
		this();
		this.id = termId;
		this.src = termId;
		this.isExist();
		this.isValid();
	}

	public Accrual() throws Exception {
		// origin - 22.12.2024, last edit - 22.12.2024
		this.clear();
		this.isExist();
		var root = Abc.getRoot(this.table); // TOTHINK
		this.id = root.id;
		this.code = root.code;
		this.description = root.description;
		this.role = root.role;
		this.info = root.info;
		this.unit = root.unit;
	}

	public void clear() throws Exception {
		// origin - 28.11.2024, last edit - 22.12.2024
		try {
			super.clear();
			this.table = this.getClass().getName(); // TOTHINK

			commonDayOff = pointDayOff = baseInterestContains = basePenaltyContains = totalPenaltyAccrualLimit = new UnitVal();
			interestRate = penaltyRate = billingCycle = totalOverPaymentLimit = new UnitVal();

		} catch (Exception ex) {
			WB.addLog("Accrual.clear, ex=" + ex.getMessage(), WB.strEmpty, "Accrual");
		} finally {
			Etc.doNothing();
		}
	}

	public String toString() {
		// origin - 22.12.2024, last edit - 22.12.2024
		String res = WB.strEmpty;
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", ", this.slice);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 22.12.2024, last edit - 22.12.2024
		try {

//			// ctor()
//			WB.addLog2("Price.test.ctor()=" + new Price(), WB.strEmpty, "Price");
//			// ctor (String Id)
//			for (var tmp : new Price[] { new Price(), new Price("Price.tralala"), new Price("Price.Basic"),
//					new Price("Price.KZT-USD") }) {
//				WB.addLog2("Price.test.ctor(String Id)=" + new Price(tmp.id), WB.strEmpty, "Price");
//			}

		} catch (Exception ex) {
			WB.addLog("Accrual.test, ex=" + ex.getMessage(), WB.strEmpty, "Accrual");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Accrual.test end ", WB.strEmpty, "Accrual");
	}
}
