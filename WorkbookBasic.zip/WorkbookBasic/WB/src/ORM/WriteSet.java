import java.util.ArrayList;
import java.util.List;

public class WriteSet {
	// origin - 05.10.2024, last edit - 20.03.2025

	public static List<ModelDto> getTest(List<List<String>> testTable) throws Exception {
		// origin - 08.02.2024, last edit - 13.06.2025
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			for (var currTable : testTable) {
				List<ModelDto> tmp = new ArrayList<ModelDto>();
				tmp.clear();
				String table = currTable.get(0);
				int numberRecord = Integer.parseInt(currTable.get(1));

				for (int i = 0; i < numberRecord; i++) {
					tmp.add(new ModelDto(table, new IdGen(table, "idCommonCompositeRandom").id, "", "", "", "", // IdGen.getNew()
							"", ModelDto.getDate1(""), ModelDto.getDate2(""), "Test", "Test", "", "", "", "", "", "",
							"", "", MoreVal.lastEdit(""), "", "", "", ""));
				}
				res.addAll(tmp);
				// res.addAll(ModelDto.getTestSubset(currTable.get(0),
				// Integer.parseInt(currTable.get(1))));
			}

		} catch (Exception ex) {
			WB.addLog("WriteSet.getTestSubset(List<List<String>> testTable):List<ModelDto>, ex=" + ex.getMessage(), "", "WriteSet");
		}
		// WB.addLog2("WriteSet.getTestSubset, res.size=" + res.size(), "", "WriteSet");
		return res;
	}

	private WriteSet() throws Exception {
		// origin - 05.10.2024, last edit - 04.11.2024
	}

	public static void test() throws Exception {
		// origin - 05.10.2024, last edit - 13.06.2025
		try {

		} catch (

		Exception ex) {
			WB.addLog("WriteSet.test():void, ex=" + ex.getMessage(), "", "WriteSet");
		}
	}
}