import java.io.File;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

public final class Conn {
	// origin - 17.11.2023, last edit - 01.02.2026
	public static String dbDir;

	public static String globalDbPattern, global, globalPath;
	public static String localDbPattern, localPath;
	public static String templateDbPattern, template, templatePath;
	public static String largeDbPattern, testDbPattern, exampleDbPattern;
	public static String inputDbPattern, outputDbPattern, toAllPattern;
	private static String workAutoCreate, workAutoCreatePath;

	public static TreeSet<String> systemFact = new TreeSet<String>();
	public static TreeSet<String> systemNorm;

	public static TreeSet<String> work = new TreeSet<String>();

	public static TreeSet<String> largeDb = new TreeSet<String>();
	public static TreeSet<String> testDb = new TreeSet<String>();
	public static TreeSet<String> exampleDb = new TreeSet<String>();
	private static List<String> tableNorm;
	public static String prefixJdbcSqlite;
	public static String patternExtensionSqlite;
	public static String defaultInfoBaseId = "";

	static {
		try {
			Conn.defaultInfoBaseId = "IB1";
			Conn.dbDir = System.getProperty("user.dir");
			// global = getFile("DatabaseGlobal.sqlite");
			Conn.globalDbPattern = "DatabaseGlobal";
			Conn.global = getFile(Conn.globalDbPattern);// getFile("DatabaseGlobal");
			Conn.globalPath = Conn.getPath(Conn.global);
			// WB.addLog2("Conn.static ctor, globalPath=" + globalPath+ ", global=" +global,
			// "", "Abc");
			Conn.templateDbPattern = "DatabaseTemplate";
			Conn.template = Conn.getFile(Conn.templateDbPattern);// getFile("DatabaseTemplate.sqlite");
			Conn.templatePath = Conn.getPath(Conn.template);
			// WB.addLog2("Conn.static ctor, templatePath=" + templatePath + ", template="
			// +template, "", "Abc");

			Conn.testDbPattern = "test";
			Conn.exampleDbPattern = "example";
			Conn.localDbPattern = "DatabaseLocal";
			Conn.largeDbPattern = "large";

			Conn.inputDbPattern = "input";
			Conn.outputDbPattern = "output";
			Conn.toAllPattern = "_to_all_";

			Conn.workAutoCreate = "MyWorkBase1.sqlite3";
			Conn.workAutoCreatePath = Conn.getPath(Conn.workAutoCreate);

			// Conn.systemNorm = new TreeSet<String>(Arrays.asList(Conn.globalPath,
			// Conn.templatePath));
			Conn.systemNorm = new TreeSet<String>(List.of(Conn.globalPath, Conn.templatePath));
//			Conn.tableNorm = new ArrayList<String>(Arrays.asList("Account", "Asset", "Deal", "Debt", "Face", "Geo",
//					"Info", "Item", "Mark", "Meter", "Price", "Process", "Role", "Sign", "Slice", "Unit", "Workbook"));
			Conn.tableNorm = new ArrayList<String>(List.of("Account", "Asset", "Deal", "Debt", "Face", "Geo", "Info",
					"Item", "Mark", "Meter", "Price", "Process", "Role", "Sign", "Slice", "Unit", "Workbook"));

			Conn.prefixJdbcSqlite = "jdbc:sqlite:";
			Conn.patternExtensionSqlite = ".sqlite";
		} catch (Exception ex) {
			WB.addLog("Conn.static ctor, ex=" + ex.getMessage(), "", "Conn");
		}
	}

	public static String getFile(String subStrFileName) throws Exception {
		// origin - 30.11.2023, last edit - 13.06.2025
		subStrFileName = Etc.fixTrim(subStrFileName);
		String res = subStrFileName;
		try {
			String currFileName = "";
			if (Files.notExists(Paths.get(dbDir))) {
				return res;
			}
			File file = Paths.get(dbDir).toFile();
			for (File currFile : file.listFiles()) {
				if (currFile.isFile() == false) {
					continue;
				}
				currFileName = currFile.getName().toString();
				if (Etc.strContains(currFileName, subStrFileName)) {
					res = currFileName;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Conn.getFile(String subStrFileName):String, ex=" + ex.getMessage(), "", "Conn");
		}
		return res;
	}

	private static String getPath(String file) throws Exception {
		// origin - 30.11.2023, last edit - 13.06.2025
		String res = "";
		try {
			res = Conn.dbDir + File.separator + file;
		} catch (Exception ex) {
			WB.addLog2("Conn.getPath(String file):String, ex=" + ex.getMessage(), "", "Conn");
		}
		return res;
	}

	public static void init() throws Exception {
		// origin - 25.11.2023, last edit - 01.02.2026
		try {
			if (Conn.systemFact.isEmpty()) {
				Conn.getDbList(dbDir);
				// Conn.cloneDbTemplate(dbDir);
				Conn.cloneDbTemplate();
			}
			Conn.getLast();
			Conn.readDatabaseLocal();
			// Conn.getLocal(WB.localDir);
		} catch (Exception ex) {
			WB.addLog2("Conn.init():void, ex=" + ex.getMessage(), "", "Conn");
		}
	}

	private static boolean testLocal(String dirPath, File currFile) throws Exception {
		// origin - 15.06.2024, last edit - 13.06.2025
		boolean res = false;
		try {
			String testLocalPath = dirPath + File.separator + currFile.getName();
			Abc testAbcLocal = new Abc();
			testAbcLocal = new Abc(testLocalPath);

			if (testAbcLocal.basic.isEmpty() == false) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog2("Conn.testLocal(String dirPath, File currFile):boolean, ex=" + ex.getMessage(), "", "Conn");
		}
		return res;
	}

//	public static void readDatabaseLocal() throws Exception {
//		// origin - 19.06.2024, last edit - 20.03.2025
//		try {
//			Conn.getLocal(WB.localDir);
//		} catch (Exception ex) {
//			WB.addLog2("Conn.readDatabaseLocal, ex=" + ex.getMessage(), "", "Conn");
//		}
//	}

	public static void readDatabaseLocal() throws Exception {
		// origin - 06.01.2024, last edit - 13.06.2025
		try {
			String dirPath = WB.localDir;
			if (Files.notExists(Paths.get(dirPath))) {
				WB.addLog("Conn.readDatabaseLocal, Files.notExists in=" + Paths.get(dirPath), "", "Conn");
				return;
			}

			Long maxLastModified = 2L;
			Long currLastModified;

			File file = Paths.get(dirPath).toFile();
			for (File currFile : file.listFiles()) {
				if (Etc.strContains(currFile.getName(), localDbPattern) == false) {
					continue;
				}

				if (Conn.testLocal(dirPath, currFile) == false) {// sometimes being crashing DB local
					continue;
				}

				currLastModified = currFile.lastModified();
				if (currLastModified > maxLastModified) {
					maxLastModified = currLastModified;
					// Conn.setLocal(dirPath, currFile);
					Conn.localPath = dirPath + File.separator + currFile.getName();
					WB.abcLocal = new Abc(Conn.localPath);
				}
			}
		} catch (Exception ex) {
			WB.addLog2("Conn.readDatabaseLocal():void, ex=" + ex.getMessage(), "", "Conn");
		}
		WB.addLog("Conn.readDatabaseLocal, finally localPath=" + localPath + ", finally WB.abcLocal=" + WB.abcLocal, "",
				"Conn");
	}

//	private static void setLocal(String dirPath, File currFile) throws Exception {
//		// origin - 06.01.2024, last edit - 20.03.2025
//		try {
//			Conn.localPath = dirPath + File.separator + currFile.getName();
//			WB.abcLocal = new Abc(localPath);
//			// WB.addLog2("Conn.setLocal, WB.abcLocal=" + WB.abcLocal + ", localPath=" +localPath, "", "Conn");
//		} catch (Exception ex) {
//			WB.addLog2("Conn.setLocal, ex=" + ex.getMessage(), "", "Conn");
//		}
//	}

	private static void getLast() throws Exception {
		// origin - 25.11.2023, last edit - 13.06.2025
		try {
			LocalDateTime localStart = WB.getLocalStart();
			if (Conn.work.isEmpty() == false) {// TODO after do find last conn in interface inputDbConnection
				WB.lastConn = work.first();
				// WB.addLog2("Conn.getLast, WB.lastConn=" + WB.lastConn, "", "Conn");
				WB.abcLast = new Abc(WB.lastConn);
				// WB.addLog2("Conn.getLast, WB.abcLast=" + WB.abcLast + ", WB.lastConn="
				// +WB.lastConn, "", "Conn");
			}

			if (Conn.work.contains(WB.lastConn)) {
				WB.lastConnWork = WB.lastConn;
//			WB.addLog2("Conn.getLast, work.contains(WB.lastConn), WB.lastConnWork=" + WB.lastConnWork
//					+ ", WB.lastConn = " + WB.lastConn, "", "Conn");
			}

			if (WB.lastConnWork.isEmpty()) {
				WB.lastConnWork = work.first();
//			WB.addLog2("Conn.getLast, WB.lastConnWork.isEmpty(), WB.lastConnWork=" + WB.lastConnWork
//					+ ", work.first() = " + work.first(), "", "Conn");
			}
			WB.getLocalEnd("Conn.getLast, WB.abcLast=" + WB.abcLast, localStart);
		} catch (Exception ex) {
			WB.addLog2("Conn.getLast():void, ex=" + ex.getMessage(), "", "Conn");
		}
	}

	public static TreeSet<String> getDbList2(String dirPath, String patternInOut, String patternTo) throws Exception {
		// origin - 31.05.2024, last edit - 13.06.2025
		TreeSet<String> res = new TreeSet<String>();
		try {
			if (Files.notExists(Paths.get(dirPath))) {
				WB.addLog("Conn.getDbList2, Files.notExists in=" + Paths.get(dirPath), "", "Conn");
				return res;
			}

			File file = Paths.get(dirPath).toFile();
			String currFileName = "";
			for (File currFile : file.listFiles()) {
//			WB.addLog2("Conn.getDbList, select file=" + currFile + ", dirPath=" + dirPath + ", patternInOut=" + patternInOut
//					+ ", patternTo=" + patternTo, "", "Conn");
				if (currFile.isFile() == false) {
					continue;
				}

				currFileName = currFile.getName().toString();

				// in future will be new versions SQLite, example "sqlite4, sqlite5" etc.
				if (Etc.strContains(currFileName, Conn.patternExtensionSqlite) == false) {
					continue;
				}

				if (Etc.strContains(currFileName, patternInOut)) {
					if (Etc.strContains(currFileName, patternTo)) {
						// Conn.addDbList(currFile, res);
						res.add(currFile.getPath().toString());
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog2("Conn.getDbList2(String dirPath, String patternInOut, String patternTo):TreeSet<String>, ex="
					+ ex.getMessage(), "", "Conn");
		}
		return res;
	}

	private static void getDbList(String dirPath) throws Exception {
		// origin - 22.10.2023, last edit - 13.06.2025
		try {
			if (Files.notExists(Paths.get(dirPath))) {
				WB.addLog("Conn.getDbList, Files.notExists in=" + Paths.get(dirPath), "", "Conn");
				return;
			}

			File file = Paths.get(dirPath).toFile();
			String currFileName = "";
			for (File currFile : file.listFiles()) {
				if (currFile.isFile() == false) {
					continue;
				}

				currFileName = currFile.getName().toString();

				// in future will be new versions SQLite, example ".sqlite4, .sqlite5", etc.
				if (Etc.strContains(currFileName, Conn.patternExtensionSqlite) == false) {
					continue;
				}

				if (Etc.strContains(currFileName, Conn.testDbPattern)) {
					// Conn.addDbList(currFile, testDb);
					Conn.testDb.add(currFile.getPath().toString());
				}

				if (Etc.strContains(currFileName, Conn.exampleDbPattern)) {
					// Conn.addDbList(currFile, exampleDb);
					Conn.exampleDb.add(currFile.getPath().toString());
				}

				if (Etc.strContains(currFileName, Conn.largeDbPattern)) {
					// Conn.addDbList(currFile, largeDb);
					Conn.largeDb.add(currFile.getPath().toString());
					// WB.addLog2("Conn.getDbList, largePath=" + largePath, "", "Conn");
				}

				// skip DatabaseLocal (earlier dbLocal was in user.dir)
				if (Etc.strContains(currFileName, Conn.localDbPattern)) {
					continue;
				}

				// if in current database no tables norm then skip this database file
				if (hasTableNormList(currFileName.toString()) == false) {
					continue;
				}
				// if in current database no tables then skip this database file
				if (existTableList(currFileName) == false) {
					continue;
				}

				if (isDbList(currFile, Conn.systemNorm)) {
					// Conn.addDbList(currFile, Conn.systemFact);
					Conn.systemFact.add(currFile.getPath().toString());
				} else {
					// Conn.addDbList(currFile, Conn.work);
					Conn.work.add(currFile.getPath().toString());
				}
			}
			WB.addLog2("Conn.getDbList, Conn.work=" + Conn.work, "", "Conn");
			WB.addLog2("Conn.getDbList, Conn.systemFact=" + Conn.systemFact, "", "Conn");
			// WB.addLog2("Conn.getDbList, Conn.testDb=" + testDb, "", "Conn");
			// WB.addLog2("Conn.getDbList, Conn.exampleDb=" + exampleDb, "", "Conn");
		} catch (Exception ex) {
			WB.addLog2("Conn.getDbList(String dirPath):void, ex=" + ex.getMessage(), "", "Conn");
		}
	}

//	private static void addDbList(File currFile, TreeSet<String> dbList) throws Exception {
//		// origin - 24.12.2023, last edit - 20.03.2025
//		try {
//			dbList.add(currFile.getPath().toString()); // ex. getPath = C:\WorkBookBasic\WB\MyWorkBase1.sqlite3
//			// WB.addLog2("Conn.addDbList, currFile=" + currFile + ", dbList=" + dbList + ",
//			// dbList.currSize=" + dbList.size(), "", "Conn");
//		} catch (Exception ex) {
//			WB.addLog2("Conn.addDbList, ex=" + ex.getMessage(), "", "Conn");
//		}
//	}

	private static boolean isDbList(File dbFile, TreeSet<String> dbList) throws Exception {
		// origin - 01.01.2024, last edit - 13.06.2025
		boolean res = false;
		try {
			// dbName = Etc.fixTrim(dbName.toLowerCase());
			if (dbList.contains(dbFile.getPath().toString())) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog2("Conn.isDbList(File dbFile, TreeSet<String> dbList):boolean, ex=" + ex.getMessage(), "", "Conn");
		}
		return res;
	}

	public static String getText(String dbStr) throws Exception {
		// origin - 02.11.2023, last edit - 13.06.2025
		String res = Etc.fixTrim(dbStr);
		try {
			res = Etc.delStr(dbStr, Conn.prefixJdbcSqlite);
			res = Conn.prefixJdbcSqlite + res;
		} catch (Exception ex) {
			WB.addLog2("Conn.getText(String dbStr):String, ex=" + ex.getMessage(), "", "Conn");
		}
		return res;
	}

	private static void cloneDbTemplate() throws Exception {
		// origin - 22.10.2023, last edit - 13.06.2025
		try {
			if (Conn.work.size() > 0) {
				return;
			}
			Path fileTo = Paths.get(Conn.workAutoCreatePath);
			if (Files.exists(fileTo)) {
				return;
			}

			Path fileFrom = Paths.get(Conn.templatePath);
			if (Files.notExists(fileFrom)) {
				return;
			}

			if (Conn.existTableList(fileFrom.toString())) {
				if (Conn.hasTableNormList(fileFrom.toString())) {
					// Conn.copyFile(fileTo, fileFrom);
					Files.copy(fileFrom, fileTo);
					Conn.work.add(fileTo.toString());
					// WB.addLog("Conn.cloneDbTemplate, dbWorkAutoCreatePath=" +
					// workAutoCreatePath,"", "Conn()");
					WB.addLog("Conn.cloneDbTemplate, dbWork=" + Conn.work, "", "Conn()");
				}
			}
		} catch (Exception ex) {
			WB.addLog2("Conn.cloneDbTemplate():void, ex=" + ex.getMessage(), "", "Conn");
		}
	}

	public static void copyExtFile(String urlFrom, String fileTo) throws Exception {
		// origin - 24.12.2023, last edit - 13.06.2025
		try {
			@SuppressWarnings("deprecation")
			URL url = new URL(urlFrom);
			Path outputDocPath = Path.of(fileTo);

			try (InputStream in = url.openStream()) {
				Files.copy(in, outputDocPath, StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (Exception ex) {
			WB.addLog("Conn.copyExtFile(String urlFrom, String fileTo):void, ex=" + ex.getMessage() + ", urlFrom="
					+ urlFrom + ", file to=" + fileTo, "", "Conn");
		}
	}

//	public static void copyFile(Path fileTo, Path fileFrom) throws Exception {
//		// origin - 24.12.2023, last edit - 20.03.2025
//		try {
//			Files.copy(fileFrom, fileTo);
//		} catch (Exception ex) {
//			WB.addLog("Conn.copyFile, ex=" + ex.getMessage(), "", "Conn");
//		}
//	}

	public static boolean hasTableNormList(String currConn) throws Exception {
		// origin - 22.11.2023, last edit - 13.06.2025
		boolean res = false;
		try {
			List<String> dbHasTableFactList = DAL.getTableList(currConn);
			if (dbHasTableFactList.containsAll(Conn.tableNorm)) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("Conn.hasTableNormList(String currConn):boolean, ex=" + ex.getMessage(), "", "Conn");
		}
		return res;
	}

	public static boolean existTableList(String currConn) throws Exception {
		// origin - 16.11.2023, last edit - 13.06.2025
		boolean res = false;
		try {
			if (DAL.getTableList(currConn).isEmpty() != true) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("Conn.existTableList(String currConn):boolean, ex=" + ex.getMessage(), "", "Conn");
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 17.11.2023, last edit - 13.06.2025
		try {

		} catch (Exception ex) {
			WB.addLog("Conn.test():void, ex=" + ex.getMessage(), "", "Conn");
		}
	}
}