import java.util.ArrayList;
import java.util.List;

public class PriceCurrency {
	// origin - 27.02.2025, last edit - 30.03.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, code, description;
	// special fields - no
	// special timestamp fields
	public ListVal date1, date2, more;
	//list common + specilal + timestamp fields in unified val
	public List<BasicDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("PriceCurrency.static ctor, ex=" + ex.getMessage(), "", "PriceCurrency");
		}
	}

	public static UnitVal get(String date1, String currencyPairId) throws Exception {// curr exchange currency
		// origin - 27.02.2025, last edit - 19.03.2025
		UnitVal res = new UnitVal();
		try {
			var val = new PriceCurrency(currencyPairId).val;
			var dto = BasicDto.getChrono(DateTool.getLocalDate(date1), val);
			// WB.addLog2("PriceCurrency.get, dto=" + dto + ", date1=" + date1,"",
			// "PriceCurrency");
			res = new UnitVal(dto.more, Unit.currCurrency.code);
		} catch (Exception ex) {
			WB.addLog("PriceCurrency.get, ex=" + ex.getMessage(), "", "PriceCurrency");
		}
		return res;
	}

	private void getVal() throws Exception {
		// origin - 27.02.2025, last edit - 19.03.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currMore = "";
			for (int i = 0; i < this.more.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currMore = this.more.getByIndex(i);
				var tmp = new BasicDto(this.id, this.parent, currDate1, currDate2, this.code, this.description,
						currMore);
				this.val.add(tmp);
				// WB.addLog2("PriceCurrency.getVal, add tmp=" + tmp,"","PriceCurrency");
			}
		} catch (Exception ex) {
			WB.addLog("PriceCurrency.getVal, ex=" + ex.getMessage(), "", "PriceCurrency");
		}
	}

	public void fix() throws Exception { // TODO
		// origin - 27.02.2025, last edit - 19.03.2025
		try {

		} catch (Exception ex) {
			WB.addLog("PriceCurrency.fix, ex=" + ex.getMessage(), "", "PriceCurrency");
		}
	}

	public void isExist() throws Exception {
		// origin - 27.02.2025, last edit - 19.03.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getCodeFilter(this.src), this.table);
			if (listDto.size() != 0) {
				var currDto = listDto.getFirst();
				this.date1 = new ListVal(currDto.date1, "");
				this.date2 = new ListVal(currDto.date2, "");
				this.code = DefVal.setCustom(this.code, currDto.code);
				this.id = DefVal.setCustom(this.id, currDto.id);
				this.description = DefVal.setCustom(this.description, currDto.description);

				this.more = new ListVal(currDto.more, "");
				this.isExist = true;
				// WB.addLog2("PriceCurrency.isExist, add=" + this.more, "","PriceCurrency");
			}
		} catch (Exception ex) {
			WB.addLog("PriceCurrency.isExist, ex=" + ex.getMessage(), "", "PriceCurrency");
		}
	}

	public void isValid() throws Exception { // TODO
		// origin - 27.02.2025, last edit - 19.03.2025
		try {
		} catch (Exception ex) {
			WB.addLog("PriceCurrency.isValid, ex=" + ex.getMessage(), "", "PriceCurrency");
		}
	}

	public PriceCurrency(String currencyPairId) throws Exception {
		// origin - 27.02.2025, last edit - 01.03.2025
		this();
		this.table = "Price"; // ??magic string??
		this.src = currencyPairId;
		this.isExist();
		this.getVal();
		// this.fix();
	}

	public void clear() throws Exception {
		// origin - 27.02.2025, last edit - 20.03.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = this.src = this.code = this.description = "";
			this.more = new ListVal();
			this.val = new ArrayList<BasicDto>();
		} catch (Exception ex) {
			WB.addLog("PriceCurrency.clear, ex=" + ex.getMessage(), "", "PriceCurrency");
		}
	}

	public PriceCurrency() throws Exception {
		// origin - 27.02.2025, last edit - 27.02.2025
		this.clear();
	}

	public String toString() {
		// origin - 27.02.2025, last edit - 20.03.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);

			res = res + Fmtr.addAnyway(", val.size ", this.val.size());

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 27.02.2025, last edit - 19.03.2025
		try {

//			// get (date, currencyPairId)
//			for (var tmp1 : new String[] { "2024-01-31", "2025-01-31" }) {
//				for (var tmp2 : Price.currencyPair) {
//					WB.addLog2("PriceCurrency.test.get(date, currencyPairId)="
//							+ PriceCurrency.get(tmp1, tmp2).id + ", date1=" + tmp1 + ", currency=" + tmp2,
//							"", "PriceCurrency");
//				}
//			}

//			// ctor()
//						WB.addLog2("PriceCurrency.test.ctor()=" + new PriceCurrency(), "", "PriceCurrency");

//			// ctor (String)
//			for (var tmp1 : Price.currencyPair) {
//				WB.addLog2("PriceCurrency.test.ctor(String)=" + new PriceCurrency(tmp1), "","PriceCurrency");
//			}

		} catch (Exception ex) {
			WB.addLog("PriceCurrency.test, ex=" + ex.getMessage(), "", "PriceCurrency");
		}
	}
}