import java.util.ArrayList;
import java.util.List;

public class ModelVal {
	// origin - 15.09.2024, last edit - 13.01.2025
	public static String strStartUnit;
	public String id, context, src, partName, name, partUnit;
	public Unit unit;

	static {
		try {
			ModelVal.strStartUnit = WB.strParenthesisLeft + "Unit.";
		} catch (Exception ex) {
			WB.addLog("ModelVal.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "ModelVal");
		} finally {
			Etc.doNothing();
		}
	}

	public void getUnit() throws Exception {
		// origin - 24.11.2024, last edit - 09.01.2025
		try {
			if (this.partUnit.isEmpty() == false) {
				this.unit = new Unit(this.partUnit);
				this.context = this.unit.expectedValue;
			}
		} catch (Exception ex) {
			WB.addLog("ModelVal.getUnit, ex=" + ex.getMessage(), WB.strEmpty, "ModelVal");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("ModelVal.getUnit, this.unit=" + this.unit + ", this.partUnit=" + this.partUnit, WB.strEmpty,
//				"ModelVal");
	}

	public static List<ModelVal> build(String in) throws Exception {
		// origin - 19.11.2024, last edit - 19.11.2024
		List<ModelVal> res = new ArrayList<ModelVal>();
		try {
			String[] strVal = in.split(WB.strBraceRight);
			for (var currStrVal : strVal) {
				res.add(new ModelVal(currStrVal));
			}
		} catch (Exception ex) {
			WB.addLog("ModelVal.build, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "ModelVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelVal.build, res=" + res + ", in=" + in, WB.strEmpty,
		// "ModelVal");
		return res;
	}

	public static String isType(String src) throws Exception {
		// origin - 12.11.2024, last edit - 09.01.2025
		String res = WB.strEmpty;
		src = Etc.fixTrim(src);

		try {
			if ((Etc.strMatch(src, WB.strAngleBracketLeft) == 1) & (Etc.strMatch(src, WB.strAngleBracketRight) == 1)
					& (src.startsWith(WB.strAngleBracketLeft)) & (src.endsWith(WB.strAngleBracketRight))) {
				res = "TagVal";
			}

//			if ((Etc.strMatch(src, "argLeftLimit") == 0) & // no ScaleVal
//					(Etc.strMatch(src, WB.strDash) == 0) & // no "-", what not take RangeVal ex.
//															// "2024-11-04T09:00:00 -
//					// 2024-11-04T20:00:00"
//					(Etc.strMatch(src, WB.strColon) >= 1)) { // ":"
//				res = "ListVal";
//			}

			// "{argLeftLimit=(0:45.001)(Unit.MinRate);argRightLimit=(0:45.0)(Unit.MinRate);argRate=(0.293:0.105)(Unit.PercentPerDay);}"
			if ((Etc.strMatch(src, "argLeftLimit") >= 1) & (Etc.strMatch(src, "argRightLimit") >= 1)) {
				res = "ScaleVal";
			}

			// ex. "12 000.00 (14 000.00)", "56 564.00 (67 000.00;83 000.00)"
			if ((Etc.strMatch(src, WB.strParenthesisLeft) >= 1) & (Etc.strMatch(src, WB.strParenthesisRight) >= 1)
					& (src.startsWith(WB.strParenthesisLeft) == false) & (src.endsWith(WB.strParenthesisLeft) == false)
					& (Etc.strMatch(src, WB.strSlash) == 0) & (Etc.strMatch(src, WB.strColon) == 0)) {
				res = "AnnoVal";
			}

			// mask AnnoVal, identification RangeVal must be after AnnoVal
			// ex. "120.0 - 140.0 (Unit.KZT)", "66781 - 66783", "2024-11-04T09:00:00 -
			// 2024-11-04T20:00:00"
			if ((Etc.strMatch(src, WB.strSplit) == 1) & (src.startsWith(WB.strSplit) == false)
					& (src.endsWith(WB.strSplit) == false)) {
				res = "RangeVal";
			}

			// mask AnnoVal, identification CompositeVal must be after AnnoVal
			// ex. "Weight = 6.89 / 3.56(Unit.Gr)", "S / M / L / XL(Unit.Size)", "male
			// /female"
			if (Etc.strMatch(src, WB.strSlash) >= 1) { // "/"
				res = "CompositeVal";
			}

			if ((Etc.strMatch(src, WB.strParenthesisLeft) == 1) & (Etc.strMatch(src, WB.strParenthesisRight) == 1)
					& (src.endsWith(WB.strParenthesisRight)) & (Etc.strMatch(src, "(Unit.") == 1)
					& (Etc.strMatch(src, WB.strSlash) == 0) & (Etc.strMatch(src, WB.strSplit) == 0)) {
				res = "UnitVal"; // ex. AmountDeal = "12000.0(Unit.KZT)"
			}

			if ((src.endsWith(WB.strEquals)) | (src.endsWith(WB.strEquals + WB.strQuestionMark))) {
				res = "SimplexVal"; // ex. "IIN=;" "IIN=?;"
			}
			if ((res.isEmpty()) & // {
					(Etc.strMatch(src, WB.strEquals) == 1) & (src.startsWith(WB.strEquals) == false)
					& (src.endsWith(WB.strEquals) == false)) {
				res = "SimplexVal"; // ex. "IIN=123456789012;"
			}

		} catch (Exception ex) {
			WB.addLog("ModelVal.isType, ex=" + ex.getMessage(), WB.strEmpty, "ModelVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelVal.isType, res=" + res, WB.strEmpty, "ModelVal");
		return res;
	}

	public String toString() {
		// origin - 15.09.2024, last edit - 19.11.2024
		String res = WB.strEmpty;
		try {
			res = Fmtr.reflect(this);
			// res = Formatter.reflectFull(this);
			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
			// WB.addLog("ModelVal.toString, ex=" + ex.getMessage(), WB.strEmpty,
			// "ModelVal");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public ModelVal(String in) throws Exception {
		// origin - 19.11.2024, last edit - 01.12.2024
		this();
		this.id = ModelDto.getFieldByKey(in, "id");
		this.context = ModelDto.getFieldByKey(in, "context");
		this.src = ModelDto.getFieldByKey(in, "src");
		this.partName = ModelDto.getFieldByKey(in, "partName");
		this.name = ModelDto.getFieldByKey(in, "name");
	}

	public ModelVal() throws Exception {
		// origin - 15.09.2024, last edit - 01.12.2024
		this.clear();
		// id = context = src = partName = name = partUnit = WB.strEmpty;
	}

	public void clear() throws Exception {
		// origin - 01.12.2024, last edit - 01.12.2024
		try {
			this.id = this.context = this.src = this.partName = this.name = this.partUnit = WB.strEmpty;
			this.unit = null;
		} catch (Exception ex) {
			WB.addLog("ModelVal.clear, ex=" + ex.getMessage(), WB.strEmpty, "ModelVal");
		} finally {
			Etc.doNothing();
		}
	}

	public static void test() throws Exception {
		// origin - 04.09.2024, last edit - 05.12.2024
		try {

//			// build
//			List<ModelVal> bld = ModelVal.build(
//					"id @ id1 | context @ context1 | src @ src1 } " + "id @ id2 | context @ context2 | src @ src2 }");
//			WB.addLog2("ModelVal.build(String in)=" + bld, WB.strEmpty, "ModelVal");
//			// ctor1
//			ModelVal mv1 = new ModelVal();
//			WB.addLog2("ModelVal.test.ctor1()=" + mv1, WB.strEmpty, "ModelVal");

//			// isType
//			var arg1 = new String[] {
//					"{argLeftLimit=(0:45.001)(Unit.MinRate);argRightLimit=(0:45.0)(Unit.MinRate);argRate=(0.293:0.105)(Unit.PercentPerDay);}",
//					"<AnnualMeeting=CostForDinner>", "AmountDeal = 12000.0(Unit.KZT)", "12000.0(Unit.KZT)",
//					"120.0 - 140.0", "66781 - 66783", "2024-11-04T09:00:00 - 2024-11-04T20:00:00",
//					"12 000.00 (14 000.00)", "56 564.00 (67 000.00;83 000.00)", "IIN=;", "IIN=?;", "IIN=123456789012;",
//					"12:14:23" };
//			for (var testArg1 : arg1) {
//				WB.addLog2(
//						"ModelVal.isType=" + ModelVal.isType(testArg1) + ", src="
//								+ Formatter.replaceAll(testArg1, WB.strSemiColon, WB.strCommaSpace),
//						WB.strEmpty, "ModelVal");
//			}

		} catch (Exception ex) {
			WB.addLog("ModelVal.test, ex=" + ex.getMessage(), WB.strEmpty, "ModelVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelVal.test end ", WB.strEmpty, "ModelVal");
	}
}