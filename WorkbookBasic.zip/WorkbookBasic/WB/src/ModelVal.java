import java.util.ArrayList;
import java.util.List;

public class ModelVal {
	// origin - 15.09.2024, last edit - 19.03.2025
	public static String strStartUnit;
	public String id, context, src, partName, name, partUnit;
	public Unit unit;

	static {
		try {
			ModelVal.strStartUnit = "(" + "Unit.";
		} catch (Exception ex) {
			WB.addLog("ModelVal.static ctor, ex=" + ex.getMessage(), "", "ModelVal");
		}
	}

	public void getUnit() throws Exception {
		// origin - 24.11.2024, last edit - 19.03.2025
		try {
			if (this.partUnit.isEmpty() == false) {
				this.unit = new Unit(this.partUnit);
				this.context = this.unit.expectedValue;
			}
		} catch (Exception ex) {
			WB.addLog("ModelVal.getUnit, ex=" + ex.getMessage(), "", "ModelVal");
		}
	}

	public static List<ModelVal> build(String in) throws Exception {
		// origin - 19.11.2024, last edit - 20.03.2025
		List<ModelVal> res = new ArrayList<ModelVal>();
		try {
			String[] strVal = in.split("}");
			for (var currStrVal : strVal) {
				res.add(new ModelVal(currStrVal));
			}
		} catch (Exception ex) {
			WB.addLog("ModelVal.build, ex=" + ex.getMessage() + ", res=" + res, "", "ModelVal");
		}
		return res;
	}

	public static String isType(String src) throws Exception {
		// origin - 12.11.2024, last edit - 21.03.2025
		String res = "";
		src = Etc.fixTrim(src);

		try {
			if ((Etc.strMatch(src, "<") == 1) && (Etc.strMatch(src, ">") == 1) && (src.startsWith("<"))
					&& (src.endsWith(">"))) {
				res = "TagVal";
			}

//			if ((Etc.strMatch(src, "argLeftLimit") == 0) && // no ScaleVal
//					(Etc.strMatch(src, "-") == 0) && // no "-", what not take RangeVal ex.
//															// "2024-11-04T09:00:00 -
//					// 2024-11-04T20:00:00"
//					(Etc.strMatch(src, ":") >= 1)) { // ":"
//				res = "ListVal";
//			}

			// "{argLeftLimit=(0:45.001)(Unit.MinRate);argRightLimit=(0:45.0)(Unit.MinRate);argRate=(0.293:0.105)(Unit.PercentPerDay);}"
			if ((Etc.strMatch(src, "argLeftLimit") >= 1) && (Etc.strMatch(src, "argRightLimit") >= 1)) {
				res = "ScaleVal";
			}

			// ex. "12 000.00 (14 000.00)", "56 564.00 (67 000.00;83 000.00)"
			if ((Etc.strMatch(src, "(") >= 1) && (Etc.strMatch(src, ")") >= 1)
					&& (src.startsWith("(") == false) && (src.endsWith("(") == false) && (Etc.strMatch(src, "/") == 0)
					&& (Etc.strMatch(src, ":") == 0)) {
				res = "AnnoVal";
			}

			// mask AnnoVal, identification RangeVal must be after AnnoVal
			// ex. "120.0 - 140.0 (Unit.KZT)", "66781 - 66783", "2024-11-04T09:00:00 -
			// 2024-11-04T20:00:00"
			if ((Etc.strMatch(src, " - ") == 1) && (src.startsWith(" - ") == false)
					&& (src.endsWith(" - ") == false)) {
				res = "RangeVal";
			}

			// mask AnnoVal, identification CompositeVal must be after AnnoVal
			// ex. "Weight = 6.89 / 3.56(Unit.Gr)", "S / M / L / XL(Unit.Size)", "male
			// /female"
			if (Etc.strMatch(src, "/") >= 1) {
				res = "CompositeVal";
			}

			if ((Etc.strMatch(src, "(") == 1) && (Etc.strMatch(src, ")") == 1) && (src.endsWith(")"))
					&& (Etc.strMatch(src, "(Unit.") == 1) && (Etc.strMatch(src, "/") == 0)
					&& (Etc.strMatch(src, " - ") == 0)) {
				res = "UnitVal"; // ex. AmountDeal = "12000.0(Unit.KZT)"
			}

			if ((src.endsWith("=")) || (src.endsWith("=?"))) {
				res = "SimplexVal"; // ex. "IIN=;" "IIN=?;"
			}
			if ((res.isEmpty()) && // {
					(Etc.strMatch(src, "=") == 1) && (src.startsWith("=") == false) && (src.endsWith("=") == false)) {
				res = "SimplexVal"; // ex. "IIN=123456789012;"
			}

		} catch (Exception ex) {
			WB.addLog("ModelVal.isType, ex=" + ex.getMessage(), "", "ModelVal");
		}
		return res;
	}

	public String toString() {
		// origin - 15.09.2024, last edit - 20.03.2025
		String res = "";
		try {
			res = Fmtr.reflect(this);
			// res = Formatter.reflectFull(this);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public ModelVal(String in) throws Exception {
		// origin - 19.11.2024, last edit - 01.12.2024
		this();
		this.id = ModelDto.getFieldByKey(in, "id");
		this.context = ModelDto.getFieldByKey(in, "context");
		this.src = ModelDto.getFieldByKey(in, "src");
		this.partName = ModelDto.getFieldByKey(in, "partName");
		this.name = ModelDto.getFieldByKey(in, "name");
	}

	public ModelVal() throws Exception {
		// origin - 15.09.2024, last edit - 19.03.2025
		this.clear();
		// id = context = src = partName = name = partUnit = "";
	}

	public void clear() throws Exception {
		// origin - 01.12.2024, last edit - 19.03.2025
		try {
			this.id = this.context = this.src = this.partName = this.name = this.partUnit = "";
			this.unit = null;
		} catch (Exception ex) {
			WB.addLog("ModelVal.clear, ex=" + ex.getMessage(), "", "ModelVal");
		}
	}

	public static void test() throws Exception {
		// origin - 04.09.2024, last edit - 21.03.2025
		try {

//			// build
//			List<ModelVal> bld = ModelVal.build(
//					"id @ id1 | context @ context1 | src @ src1 } " + "id @ id2 | context @ context2 | src @ src2 }");
//			WB.addLog2("ModelVal.build(String in)=" + bld, "", "ModelVal");

			// // ctor1
//			ModelVal mv1 = new ModelVal();
//			WB.addLog2("ModelVal.test.ctor1()=" + mv1, "", "ModelVal");

//			// isType
//			var arg1 = new String[] {
//					"{argLeftLimit=(0:45.001)(Unit.MinRate);argRightLimit=(0:45.0)(Unit.MinRate);argRate=(0.293:0.105)(Unit.PercentPerDay);}",
//					"<AnnualMeeting=CostForDinner>", "AmountDeal = 12000.0(Unit.KZT)", "12000.0(Unit.KZT)",
//					"120.0 - 140.0", "66781 - 66783", "2024-11-04T09:00:00 - 2024-11-04T20:00:00",
//					"12 000.00 (14 000.00)", "56 564.00 (67 000.00;83 000.00)", "IIN=;", "IIN=?;", "IIN=123456789012;",
//					"12:14:23" };
//			for (var testArg1 : arg1) {
//				WB.addLog2(
//						"ModelVal.isType=" + ModelVal.isType(testArg1) + ", src="
//								+ Formatter.replaceAll(testArg1, ";", ", ),"", "ModelVal");
//			}

		} catch (Exception ex) {
			WB.addLog("ModelVal.test, ex=" + ex.getMessage(), "", "ModelVal");
		}
	}
}