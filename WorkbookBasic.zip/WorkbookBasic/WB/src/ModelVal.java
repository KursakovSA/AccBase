import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unused")
public class ModelVal {
	// origin - 15.09.2024, last edit - 17.09.2024

	public String id = WB.strEmpty;
	public String context = WB.strEmpty;
	public String src = WB.strEmpty;
	public final static String defVal = WB.strEmpty;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("ModelVal.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "ModelVal");
		} finally {
			Etc.doNothing();
		}
	}

	public boolean isSimplexVal() throws Exception {// ex. "IIN=123456789012;", "IIN=;", "IIN=?;"
		// origin - 05.10.2024, last edit - 05.10.2024
		boolean res = false;
		try {
			if (this.isUnitVal() == false) {
				if (Etc.strMatch(this.src, CompositeVal.strLeftSplitPart) == 2) {
					res = true;
				}
			}
		} catch (Exception ex) {
			WB.addLog("ModelVal.isSimplexVal, ex=" + ex.getMessage(), WB.strEmpty, "ModelVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelVal.isSimplexVal, res=" + res, WB.strEmpty, "ModelVal");
		return res;
	}
	
	public boolean isTagVal() throws Exception {// ex. "<AnnualMeeting=CostForDinner>"
		// origin - 26.09.2024, last edit - 05.10.2024
		boolean res = false;
		try {
			if (Etc.strMatch(this.src, TagVal.strLeftSplit) == 1) {
				if (Etc.strMatch(this.src, TagVal.strRightSplit) == 1) {
					if (this.src.startsWith(TagVal.strLeftSplit)) {
						if (this.src.endsWith(TagVal.strRightSplit)) {
							res = true;
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("ModelVal.isUnitVal, ex=" + ex.getMessage(), WB.strEmpty, "ModelVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelVal.isTagVal, res=" + res, WB.strEmpty, "ModelVal");
		return res;
	}

	public boolean isCompositeVal() throws Exception { // TOTHINK
		// origin - 17.09.2024, last edit - 02.10.2024
		boolean res = false;
		try {
			if (Etc.strMatch(this.src, CompositeVal.strSplitValue) >= 1) {
				if (Etc.strMatch(this.src, CompositeVal.strLeftSplitPart) == 2) {
					if (Etc.strMatch(this.src, CompositeVal.strLeftSplitPart) == 2) {
						res = true;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("ModelVal.isCompositeVal, ex=" + ex.getMessage(), WB.strEmpty, "ModelVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelVal.isCompositeVal, res=" + res, WB.strEmpty, "ModelVal");
		return res;
	}

	public boolean isScaleVal() throws Exception { // TOTHINK //?? must know about other val ??
		// ex.
		// {argLeftLimit=(0:45.001)(Unit.MinRate);argRightLimit=(0:45.0)(Unit.MinRate);argRate=(0.293:0.105)(Unit.PercentPerDay);}
		// origin - 17.09.2024, last edit - 05.10.2024
		boolean res = false;
		try {
			if (Etc.strMatch(this.src, ScaleVal.strLeftSplit) == 1) {
				if (Etc.strMatch(this.src, ScaleVal.strRightSplit) == 1) {
					if (Etc.strMatch(this.src, ListVal.strSplit) > 1) { // ?? contains ListVals
						if (Etc.strMatch(this.src, UnitVal.strLeftSplit) > 1) { // ?? contains UnitVals
							if (Etc.strMatch(this.src, UnitVal.strRightSplit) > 1) { // ?? contains UnitVals
								res = true;
							}
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("ModelVal.isScaleVal, ex=" + ex.getMessage(), WB.strEmpty, "ModelVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelVal.isScaleVal, res=" + res, WB.strEmpty, "ModelVal");
		return res;
	}

	public boolean isUnitVal() throws Exception {// ex. AmountDeal = "12.0(Unit.KZT)"
		// origin - 13.09.2024, last edit - 02.10.2024
		boolean res = false;
		try {
			if (Etc.strMatch(this.src, UnitVal.strLeftSplit) == 1) {
				if (Etc.strMatch(this.src, UnitVal.strRightSplit) == 1) {
					if (this.src.endsWith(UnitVal.strRightSplit)) {
						res = true;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.isUnitVal, ex=" + ex.getMessage(), WB.strEmpty, "UnitVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("UnitVal.isUnitVal, res=" + res, WB.strEmpty, "UnitVal");
		return res;
	}

	public boolean isListVal() throws Exception {
		// origin - 17.09.2024, last edit - 02.10.2024
		boolean res = false;
		try {
			if (Etc.strMatch(this.src, ListVal.strSplit) >= 1) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("ModelVal.isListVal, ex=" + ex.getMessage(), WB.strEmpty, "ModelVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelVal.isListVal, res=" + res, WB.strEmpty, "ModelVal");
		return res;
	}

	public String toString() {
		// origin - 15.09.2024, last edit - 15.09.2024
		String res = WB.strEmpty;
		try {
			res = Formatter.reflect(this);
			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
			// WB.addLog("ModelVal.toString, ex=" + ex.getMessage(), WB.strEmpty,
			// "ModelVal");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public ModelVal() throws Exception {
		// origin - 15.09.2024, last edit - 16.09.2024
	}

	public static void test() throws Exception {
		// origin - 04.09.2024, last edit - 04.09.2024
		try {

		} catch (Exception ex) {
			WB.addLog("ModelVal.test, ex=" + ex.getMessage(), WB.strEmpty, "ModelVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelVal.test end ", WB.strEmpty, "ModelVal");
	}
}