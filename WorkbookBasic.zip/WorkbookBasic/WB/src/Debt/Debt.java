import java.util.ArrayList;
import java.util.List;

public class Debt {
	// origin - 28.09.2023, last edit - 01.05.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, date1, date2, code, description, geo, role, info, more;
	// special fields
	public static String rateBasic, minRate, minSalary, contextSalaryTaxQazaqstan;
	public static String[] codePatternSalaryTaxQazaqstan;
	public List<ModelDto> lower, upper;

	static {
		try {
			Debt.minRate = "Debt.MinRate";
			Debt.minSalary = "Debt.MinSalary";
			Debt.rateBasic = "RateBasic";
			Debt.codePatternSalaryTaxQazaqstan = new String[] { "SN", "GFSS", "IncomePerson", "OPVR", "OPV", "OSMS" };
			Debt.contextSalaryTaxQazaqstan = "SalaryTaxQazaqstan";
		} catch (Exception ex) {
			WB.addLog("Debt.static ctor, ex=" + ex.getMessage(), "", "Debt");
		}
	}

	public static UnitVal addOutside(String date1, UnitVal sumLess, String code) throws Exception {
		// origin - 28.01.2025, last edit - 14.06.2025
		UnitVal res = new UnitVal();
		double res1 = 0.0;
		try {
			res1 = sumLess.val + Debt.getByBase(date1, code, sumLess).val;
			res1 = Etc.roundDebt(res1, "");
			res = new UnitVal(res1, sumLess.partUnit);
		} catch (Exception ex) {
			WB.addLog("Debt.addOutside(String date1, UnitVal sumLess, String code):UnitVal, ex=" + ex.getMessage(), "",
					"Debt");
		}
		return res;
	}

	public static UnitVal convToCurrUnit(String date1, UnitVal inUnitVal) throws Exception {// ex. in=5 Unit.MinSalary
		// origin - 27.01.2025, last edit - 14.06.2025
		UnitVal res = inUnitVal;// new UnitVal();
		double res1 = 0.0;
		String codePatternInUnit = "";
		codePatternInUnit = inUnitVal.unit.code;
		codePatternInUnit = Etc.delStr(codePatternInUnit, "Unit.");
		try {
			if (Etc.strEquals(inUnitVal.unit.code, Unit.currCurrency.code) == false) {
				UnitVal rate = Debt.getChronoVal(date1, codePatternInUnit);// ex. rate = 85000 Unit.KZT (=Unit.currUnit)
				if (Etc.strEquals(rate.unit.code, Unit.currCurrency.code)) {
					res1 = inUnitVal.val * rate.val; // ex. res1 = 5 Unit.MinSalary * 85000 Unit.KZT (=Unit.currUnit)
					res1 = Etc.roundDebt(res1, "");
					res = new UnitVal(res1, rate.partUnit); // ex. res = 425000 Unit.KZT (5 * 85000)
				}
			}
		} catch (Exception ex) {
			WB.addLog("Debt.convToCurrUnit(String date1, UnitVal inUnitVal):UnitVal, ex=" + ex.getMessage(), "",
					"Debt");
		}
		return res;
	}

	public static UnitVal minusInside(String date1, UnitVal sumWith, String code) throws Exception {
		// origin - 27.01.2027, last edit - 14.06.2025
		UnitVal res = new UnitVal();
		double res1 = 0.0;
		try {
			res1 = sumWith.val - Debt.getInside(date1, sumWith, code).val;
			res1 = Etc.roundDebt(res1, "");
			res = new UnitVal(res1, sumWith.partUnit);
		} catch (Exception ex) {
			WB.addLog("Debt.minusInside(String date1, UnitVal sumWith, String code):UnitVal, ex=" + ex.getMessage(), "",
					"Debt");
		}
		return res;
	}

	public static UnitVal getInside(String date1, UnitVal sumWith, String code) throws Exception {// ex. tax, VAT, etc.
		// origin - 02.10.2023, last edit - 14.06.2025
		UnitVal res = new UnitVal();
		double res1 = 0.0;
		try {
			UnitVal rate = Debt.getChronoVal(date1, code);
			res1 = (sumWith.val * rate.val) / (100.0 + rate.val);
			res1 = Etc.roundDebt(res1, "");
			res = new UnitVal(res1, sumWith.partUnit);
		} catch (Exception ex) {
			WB.addLog("Debt.getInside(String date1, UnitVal sumWith, String code):UnitVal, ex=" + ex.getMessage(), "",
					"Debt");
		}
		return res;
	}

	public static String getCodePattern(String strDebt) throws Exception {
		// origin - 21.01.2025, last edit - 14.06.2025
		String res = "";
		strDebt = Etc.fixTrim(strDebt);
		String strRate = "";
		try {
			res = Debt.getCodePattern(strDebt, strRate);
		} catch (Exception ex) {
			WB.addLog("Debt.getCodePattern(String strDebt):String, ex=" + ex.getMessage(), "", "Debt");
		}
		return res;
	}

	private static String getCodePattern(String strDebt, String strRate) throws Exception {
		// origin - 20.01.2025, last edit - 14.06.2025
		String res = "";
		strDebt = Etc.fixTrim(strDebt);
		strRate = Etc.fixTrim(strRate);
		try {
			if (strRate.isEmpty()) {
				strRate = Debt.rateBasic; // default
			}
			res = res + Etc.fixTrim(strDebt) + "." + Etc.fixTrim(strRate);
		} catch (Exception ex) {
			WB.addLog("Debt.getCodePattern(String strDebt, String strRate):String, ex=" + ex.getMessage(), "", "Debt");
		}
		return res;
	}

	private static String getContext(String date1, String codeRate) throws Exception {
		// origin - 22.01.2025, last edit - 14.06.2025
		String res = "";
		try {
			if (codeRate.isEmpty() == false) {
				for (var tmp : Debt.codePatternSalaryTaxQazaqstan) {
					if (Etc.strContains(codeRate, tmp)) { // no cents
						res = Debt.contextSalaryTaxQazaqstan;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Debt.getContext(String date1, String codeRate):String, ex=" + ex.getMessage(), "", "Debt");
		}
		return res;
	}

	public static UnitVal getByBase(String date1, UnitVal rate, UnitVal base) throws Exception { // ex. accrual pawndoc
		// origin - 26.01.2025, last edit - 14.06.2025
		UnitVal res = new UnitVal();
		double tmp = 0.0;
		try {
			tmp = base.val * Etc.ratio100(rate.val);
			tmp = Etc.roundDebt(tmp, "");
			res = new UnitVal(tmp, base.unit.id);
		} catch (Exception ex) {
			WB.addLog("Debt.getByBase(String date1, UnitVal rate, UnitVal base):UnitVal, ex=" + ex.getMessage(), "",
					"Debt");
		}
		return res;
	}

	public static UnitVal getByBase(String date1, String codeRate, UnitVal base) throws Exception {
		// origin - 15.01.2025, last edit - 14.06.2025
		UnitVal res = new UnitVal();
		double tmp = 0.0;
		try {
			double rate = Debt.getChronoVal(date1, codeRate).val; // ex. tax sell, tax salary, etc.
			tmp = base.val * Etc.ratio100(rate);
			String context = Debt.getContext(date1, codeRate);
			tmp = Etc.roundDebt(tmp, context);
			res = new UnitVal(tmp, base.unit.id);
		} catch (Exception ex) {
			WB.addLog("Debt.getByBase(String date1, String codeRate, UnitVal base):UnitVal, ex=" + ex.getMessage(), "",
					"Debt");
		}
		return res;
	}

//	public void getBySpan() throws Exception { // TODO
//		// origin - 16.01.2025, last edit - 19.03.2025
//		// get sum from date1,2, span time
//		double res = 0.0;
//		try {
//			double rateTax = this.rate.val;
//			res = this.base.val * Etc.ratio100(rateTax); // only net sum, less base
//			res = Etc.roundDebt(res, "");
////			WB.addLog2("Debt.getBySpan, res=" + res + ", this.base=" + this.base.id + ", this.rate=" + this.rate.id,
////					"", "Debt");
//			this.sumGeneral = new UnitVal(res, Unit.currUnit.id);
//		} catch (Exception ex) {
//			WB.addLog("Debt.getBySpan, ex=" + ex.getMessage(), "", "Debt");
//		}
////		WB.addLog2("Debt.getBySpan, this.sumGeneral=" + this.sumGeneral.id + ", this.base=" + this.base.id
////				+ ", this.rate=" + this.rate.id, "", "Debt");
//	}

	public void isExist() throws Exception {
		// origin - 16.12.2024, last edit - 14.06.2025
		try {
			var commonDebt = new ArrayList<ModelDto>();
			commonDebt.addAll(WB.abcLast.debt);
			commonDebt.addAll(WB.abcGlobal.debt);
			for (var currDebt : commonDebt) {
				if (Etc.strEquals(currDebt.id, this.id)) {
					this.date1 = DefVal.setCustom(DateTool.getNow().toString(), currDebt.date1);
					this.date2 = DefVal.setCustom(this.date2, currDebt.date2);
					this.code = DefVal.setCustom(this.code, currDebt.code);
					this.parent = DefVal.setCustom(this.parent, currDebt.parent);
					this.description = DefVal.setCustom(this.description, currDebt.description);
					this.geo = DefVal.setCustom(this.geo, currDebt.geo);
					this.role = DefVal.setCustom(this.role, currDebt.role);
					this.info = DefVal.setCustom(this.info, currDebt.info);
					this.more = DefVal.setCustom(this.more, currDebt.more);

					this.isExist = true;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Debt.isExist():void, ex=" + ex.getMessage(), "", "Debt");
		}
	}

	public Debt(String Id) throws Exception {
		// origin - 05.12.2023, last edit - 11.08.2025
		this.clear();
		this.src = Id;
		if (Id.isEmpty() == false) {
			this.id = this.code = Id;
		}
		this.isExist();
		this.upper = ModelDto.getUpper(WB.abcLast.debt, this.parent);
		this.lower = ModelDto.getLower(WB.abcLast.debt, this.code);
	}

	public Debt() throws Exception {
		// origin - 05.12.2023, last edit - 19.05.2025
		this.clear();
	}

	public static UnitVal getChronoVal(String date1, String code) throws Exception {
		// origin - 15.01.2024, last edit - 14.06.2025
		UnitVal res = new UnitVal();
		try {
			var listDto = ReadSet.getContainsByCode(WB.abcGlobal.debt, code);
			var dto = ReadSet.getChrono(DateTool.getLocalDate(date1), listDto);
			res = new UnitVal(Etc.fixTrim(dto.meterValue), Etc.fixTrim(dto.unit));
		} catch (Exception ex) {
			WB.addLog("Debt.getChronoVal(String date1, String code):UnitVal, ex=" + ex.getMessage(), "", "Debt");
		}
		return res;
	}

	public void clear() throws Exception {
		// origin - 17.12.2024, last edit - 11.08.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = "Debt";
			this.src = this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.geo = this.role = this.info = this.more = "";
			this.lower = new ArrayList<ModelDto>();
			this.upper = new ArrayList<ModelDto>();
		} catch (Exception ex) {
			WB.addLog("Debt.clear():void, ex=" + ex.getMessage(), "", "Debt");
		}
	}

	public String toString() {
		// origin - 25.11.2024, last edit - 11.05.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());

			res = res + Fmtr.addIfNotEmpty(", upper ", this.upper.size());
			res = res + Fmtr.addIfNotEmpty(", lower ", this.lower.size());

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 14.06.2025
		try {

//			// addOutside
//			for (var addOutsideArg1 : new String[] { "2025-01-03" }) {
//				for (var addOutsideArg2 : new String[] { "100.0(Unit.KZT)", "567.43(Unit.KZT)", "0.00(Unit.KZT)",
//						"323.56452(Unit.KZT)" }) {
//					for (var addOutsideArg3 : new String[] { Debt.getCodePattern("VAT.Sell") }) {
//						WB.addLog2(
//								"Debt.test.addOutside, res="
//										+ Debt.addOutside(addOutsideArg1, new UnitVal(addOutsideArg2), addOutsideArg3).id
//										+ ", sumLess=" + addOutsideArg2 + ", rate=" + addOutsideArg3,"", "Debt");
//					}
//				}
//			}

//			// convToCurrUnit
//			for (var convToCurrUnitArg1 : new String[] { "2023-02-04", "2024-05-06", "2025-01-03" }) {
//				for (var convToCurrUnitArg2 : new String[] { "45.0(Unit.MinRate)", "5.0(Unit.KZT)",
//						"2.56(Unit.MinSalary)" }) {
//					WB.addLog2(
//							"Debt.test.convToCurrUnit, res="
//									+ Debt.convToCurrUnit(convToCurrUnitArg1, new UnitVal(convToCurrUnitArg2)).id
//									+ ", date1=" + convToCurrUnitArg1 + ", inUnitVal=" + convToCurrUnitArg2,"", "Debt");
//				}
//			}

//			// minusInside
//			for (var minusInsideArg1 : new String[] { "2025-01-03" }) {
//				for (var minusInsideArg2 : new String[] { "112.0(Unit.KZT)", "567.68(Unit.KZT)", "0.00(Unit.KZT)",
//						"342.8456(Unit.KZT)" }) {
//					for (var minusInsideArg3 : new String[] { Debt.getCodePattern("VAT.Sell") }) {
//						WB.addLog2("Debt.test.minusInside, res="
//								+ Debt.minusInside(minusInsideArg1, new UnitVal(minusInsideArg2), minusInsideArg3).id
//								+ ", date1=" + minusInsideArg1 + ", sumWith=" + minusInsideArg2 + ", rate="
//								+ minusInsideArg3, "", "Debt");
//					}
//				}
//			}

//			// getInside
//			for (var getInsideArg1 : new String[] { "2025-01-03" }) {
//				for (var getInsideArg2 : new String[] { "112.0(Unit.KZT)", "567.68(Unit.KZT)", "0.00(Unit.KZT)",
//						"342.8456(Unit.KZT)" }) {
//					for (var getInsideArg3 : new String[] { Debt.getCodePattern("VAT.Sell") }) {
//						WB.addLog2("Debt.test.getInside, res="
//								+ Debt.getInside(getInsideArg1, new UnitVal(getInsideArg2), getInsideArg3).id
//								+ ", date1=" + getInsideArg1 + ", sumWith=" + getInsideArg2 + ", rate=" + getInsideArg3,"", "Debt");
//					}
//				}
//			}

//			// getByBase (context pawndoc)
//			for (var getByBaseArg1 : new String[] { "2025-01-03" }) {
//				for (var getByBaseArg2 : new String[] { "PawnDoc.Template1.V1.Term1", "PawnDoc.Template1.V1.Term2" }) {
//					for (var getByBaseArg3 : new String[] { "12347.0(Unit.KZT)", "6733.0(Unit.KZT)" }) {
//						var term = new Term(getByBaseArg2);
//						var pawnDocRate = new Accrual(Accrual.getCodePattern(term.parent, Accrual.strAccrual),
//								Term.getCodePattern(getByBaseArg2, Accrual.strAccrual)).interestRate;
//						WB.addLog2("Debt.test.getByBase (context pawndoc), res="
//								+ Debt.getByBase(getByBaseArg1, pawnDocRate, new UnitVal(getByBaseArg3)).id + ", date1="
//								+ getByBaseArg1 + ", pawnDocRate=" + pawnDocRate.id + ", base=" + getByBaseArg3,"", "Debt");
//					}
//				}
//			}

//			// getByBase (context tax)
//			for (var getByBaseArg1 : new String[] { "2023-02-04", "2024-05-06", "2025-01-03" }) {
//				for (var getByBaseArg2 : new String[] { Debt.getCodePattern("SN"), Debt.getCodePattern("GFSS"),
//						Debt.getCodePattern("VAT.Sell"), Debt.getCodePattern("OPVR"),
//						Debt.getCodePattern("OSMS.EmployeePay"), Debt.getCodePattern("OSMS.EmployeeFee"),
//						Debt.getCodePattern("Pension.OPV"), Debt.getCodePattern("IncomePerson") }) {
//					for (var getByBaseArg3 : new String[] { "12346.97(Unit.KZT)", "6734.33(Unit.KZT)" }) {
//						WB.addLog2("Debt.test.getByBase (context tax), res="
//								+ Debt.getByBase(getByBaseArg1, getByBaseArg2, new UnitVal(getByBaseArg3)).id
//								+ ", date1=" + getByBaseArg1 + ", codeRate=" + getByBaseArg2 + ", base="
//								+ getByBaseArg3, "", "Debt");
//					}
//				}
//			}

//			// getCodePattern
//			for (var getCodePatternArg1 : new String[] { "GFSS", "OPVR", "SN", "VAT.Sell", "OPVR" }) {
//				for (var getCodePatternArg2 : new String[] { "RateBasic", "RateReduce", "Base.MinLimit",
//						"Base.MaxLimit" }) {
//					var tmpGetCodePattern = Debt.getCodePattern(getCodePatternArg1, getCodePatternArg2);
//					WB.addLog2("Debt.test.getCodePattern, res=" + tmpGetCodePattern + ", strDebt=" + getCodePatternArg1
//							+ ", strCode=" + getCodePatternArg2, "", "Debt");
//					WB.addLog2("Debt.test.getChronoVal after getCodePattern, res="
//							+ Debt.getChronoVal("2025-01-03", tmpGetCodePattern).id + ", date1=" + "2025-01-03"
//							+ ", code=" + tmpGetCodePattern, "", "Debt");
//				}
//			}

//			// getChronoVal
//			for (var getChronoValArg1 : new String[] { "2023-02-04", "2024-05-06", "2025-01-03" }) {
//				for (var getChronoValArg2 : new String[] { Debt.minRate, Debt.minSalary,
//						Debt.getCodePattern("VAT.Sell"), Debt.getCodePattern("SN"),
//						Debt.getCodePattern("GFSS") }) {
//					WB.addLog2(
//							"Debt.test.getChronoVal, res=" + Debt.getChronoVal(getChronoValArg1, getChronoValArg2)
//									+ ", date1=" + getChronoValArg1 + ", code=" + getChronoValArg2,"", "Debt");
//				}
//			}

//			// ctor (String)
//			WB.addLog2("Debt.test.ctor(String)", "", "Debt");
//			for (var ctor1StringArg1 : new String[] { "", "Debt.GFSS", "Debt.IncomePerson.Base", "Debt.tralala",
//					"Debt.Pension.OPVR.RateBasic2024", "Debt.Pawnshop.Interest" }) {
//				WB.addLog2("Debt.test.ctor(String)=" + new Debt(ctor1StringArg1), "", "Debt");
//			}

		} catch (Exception ex) {
			WB.addLog("Debt.test():void, ex=" + ex.getMessage(), "", "Debt");
		}
	}
}