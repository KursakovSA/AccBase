import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Person extends Face { // TODO
	// origin - 29.08.2024, last edit - 29.10.2024

	public String personId = WB.strEmpty; // TODO //this is not dto.id
	public String userId = WB.strEmpty; // TODO //this is not dto.id
	public String empId = WB.strEmpty; // TODO //this is not dto.id
	public String outsideEmpId = WB.strEmpty; // this is not dto.id
	public String borrowerId = WB.strEmpty; // TODO //sectoral pawnshop
	public String businessmanId = WB.strEmpty; // TODO //individual entrepreneur id, this is not dto.id
	public String sex = WB.strEmpty; // TODO
	public LocalDate dateBirth; // TODO calc from IIN
	public List<String> borrowerType = new ArrayList<String>(); // TODO //sectoral pawnshop

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Person.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Person");
		} finally {
			Etc.doNothing();
		}
	}

	public String getId(String moreId, String context) throws Exception {
		// origin - 18.08.2024, last edit - 29.09.2024
		String res = WB.strEmpty;
		try {
			context = DefVal.set(context, "idIntegerGrowingDigitalGlobal");
			res = new IdGen(moreId, context).id;
		} catch (Exception ex) {
			WB.addLog("Person.getId, ex=" + ex.getMessage(), WB.strEmpty, "Person");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Person.getId, res=" + res, WB.strEmpty, "Person");
		return res;
	}

	public Person(String Id) throws Exception {
		// origin - 29.09.2024, last edit - 27.11.2024
		super(Id);
	}

	public Person() throws Exception {
		// origin - 29.09.2024, last edit - 29.09.2024
		super();
	}

	public static void test() throws Exception {
		// origin - 29.09.2024, last edit - 29.09.2024
		try {

//			// getId
//			// LocalDateTime localStart = WB.getLocalStart();
//			Face newFace = new Face();
//			WB.addLog2("Face.getId(), res=" + newFace.getId(), WB.strEmpty, "Face");
//			WB.addLog2("Face.getId('', ''), res=" + newFace.getId("", ""), WB.strEmpty, "Face");
//			WB.addLog2("Face.getId('EmpId', ''), res=" + newFace.getId("EmpId", ""), WB.strEmpty, "Face");
//			WB.addLog2("Face.getId('EmpId', 'idStringGrowingDigitalInfobase'), res="
//					+ newFace.getId("EmpId", "idStringGrowingDigitalInfobase"), WB.strEmpty, "Deal");
//			WB.addLog2("Face.getId('EmpId', 'idStringGrowingDigitalGlobal'), res="
//					+ newFace.getId("EmpId", "idStringGrowingDigitalGlobal"), WB.strEmpty, "Face");
//			WB.addLog2("Face.getId('EmpId', 'idIntegerGrowingDigitalGlobal'), res="
//					+ newFace.getId("EmpId", "idIntegerGrowingDigitalGlobal"), WB.strEmpty, "Face");
//			WB.addLog2("Face.getId('FaceId', ''), res=" + newFace.getId("FaceId", ""), WB.strEmpty, "Face");
//			WB.addLog2("Face.getId('FaceId', 'idStringGrowingDigitalInfobase'), res="
//					+ newFace.getId("FaceId", "idStringGrowingDigitalInfobase"), WB.strEmpty, "Deal");
//			WB.addLog2("Face.getId('FaceId', 'idStringGrowingDigitalGlobal'), res="
//					+ newFace.getId("FaceId", "idStringGrowingDigitalGlobal"), WB.strEmpty, "Face");
//			WB.addLog2("Face.getId('FaceId', 'idIntegerGrowingDigitalGlobal'), res="
//					+ newFace.getId("FaceId", "idIntegerGrowingDigitalGlobal"), WB.strEmpty, "Face");
//			// WB.getLocalEnd("Face.test.getId", localStart);

		} catch (Exception ex) {
			WB.addLog("Person.test, ex=" + ex.getMessage(), WB.strEmpty, "Person");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Person.test end ", WB.strEmpty, "Person");
	}
}