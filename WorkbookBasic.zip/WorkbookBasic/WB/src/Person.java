import java.time.LocalDate;
import java.util.List;

public class Person extends Face { // TODO
	// origin - 29.08.2024, last edit - 14.03.2025

	public String personId, userId, empId, outsideEmpId, borrowerId, businessmanId, sex; // TODO
	public LocalDate dateBirth; // TODO calc from IIN
	public List<String> borrowerType; // TODO //sectoral pawnshop
	//public List<FaceSalaryNote> salaryNote;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Person.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Person");
		}
	}

	public String getId(String moreId, String context) throws Exception {
		// origin - 18.08.2024, last edit - 04.03.2025
		String res = WB.strEmpty;
		try {
			context = DefVal.set(context, "idIntegerGrowingDigitalGlobal");
			res = new IdGen(moreId, context).id;
		} catch (Exception ex) {
			WB.addLog("Person.getId, ex=" + ex.getMessage(), WB.strEmpty, "Person");
		}
		return res;
	}

	public Person(String Id) throws Exception {
		// origin - 29.09.2024, last edit - 03.03.2025
		this();
		// this.salaryNote = new SalaryNote(Id, ); //TODO
	}

	public Person() throws Exception {
		// origin - 29.09.2024, last edit - 29.09.2024
		super();
	}

	public static void test() throws Exception {
		// origin - 29.09.2024, last edit - 04.03.2025
		try {

		} catch (Exception ex) {
			WB.addLog("Person.test, ex=" + ex.getMessage(), WB.strEmpty, "Person");
		}
	}
}