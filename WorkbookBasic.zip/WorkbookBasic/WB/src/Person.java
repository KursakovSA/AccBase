import java.time.LocalDate;
import java.util.List;

public class Person extends Face { // TODO
	// origin - 29.08.2024, last edit - 31.03.2025
	// service fields
	public boolean isValid, isExist;

	// common fields
	public String table, src, id, parent, code, description, geo, role, info, mark;
	// special fields
	public String cashId, paymaster;
	// special timestamp fields
	public ListVal date1, date2, salary;
	// list common + specilal + timestamp fields in unified val
	public List<FaceDto> val;

	public String personId, userId, empId, outsideEmpId, borrowerId, businessmanId, sex; // TODO
	public LocalDate dateBirth; // TODO calc from IIN
	public List<String> borrowerType; // TODO //sectoral pawnshop
	// public List<FaceSalaryNote> salaryNote;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Person.static ctor, ex=" + ex.getMessage(), "", "Person");
		}
	}

	public String getId(String moreId, String context) throws Exception {
		// origin - 18.08.2024, last edit - 20.03.2025
		String res = "";
		try {
			context = DefVal.set(context, "idIntegerGrowingDigitalGlobal");
			res = new IdGen(moreId, context).id;
		} catch (Exception ex) {
			WB.addLog("Person.getId, ex=" + ex.getMessage(), "", "Person");
		}
		return res;
	}

	public Person(String Id) throws Exception {
		// origin - 29.09.2024, last edit - 03.03.2025
		this();
		// this.salaryNote = new SalaryNote(Id, ); //TODO
	}

	public Person() throws Exception {
		// origin - 29.09.2024, last edit - 29.09.2024
		super();
	}

	public static void test() throws Exception {
		// origin - 29.09.2024, last edit - 20.03.2025
		try {

		} catch (Exception ex) {
			WB.addLog("Person.test, ex=" + ex.getMessage(), "", "Person");
		}
	}
}