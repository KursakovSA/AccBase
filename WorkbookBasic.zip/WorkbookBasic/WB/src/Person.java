import java.util.List;

public class Person extends Face { // TODO
	// origin - 29.08.2024, last edit - 13.05.2025
	public String borrowerId; // TODO
	public List<String> borrowerType; // TODO //sectoral pawnshop

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Person.static ctor, ex=" + ex.getMessage(), "", "Person");
		}
	}

	public String getId(String moreId, String context) throws Exception {
		// origin - 18.08.2024, last edit - 20.03.2025
		String res = "";
		try {
			context = DefVal.set(context, "idIntegerGrowingDigitalGlobal");
			res = new IdGen(moreId, context).id;
		} catch (Exception ex) {
			WB.addLog("Person.getId, ex=" + ex.getMessage(), "", "Person");
		}
		return res;
	}

	public Person(String Id) throws Exception {
		// origin - 29.09.2024, last edit - 04.05.2025
		this.clear();
		this.table = "Face";
		// this.salaryNote = new SalaryNote(Id, ); //TODO
	}

	public Person() throws Exception {
		// origin - 29.09.2024, last edit - 29.09.2024
		super();
	}

	public static void test() throws Exception {
		// origin - 29.09.2024, last edit - 20.03.2025
		try {

		} catch (Exception ex) {
			WB.addLog("Person.test, ex=" + ex.getMessage(), "", "Person");
		}
	}
}