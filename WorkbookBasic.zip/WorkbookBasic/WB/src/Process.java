import java.util.ArrayList;
import java.util.List;

public class Process extends ModelDto {
	// origin - 28.09.2023, last edit - 21.11.2024
	public List<ModelDto> rule;
	public static String strPatternRule;

	static {
		try {
			Process.strPatternRule = "Rule";
		} catch (Exception ex) {
			WB.addLog("Process.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Process");
		} finally {
			Etc.doNothing();
		}
	}

	public static boolean getMatchRule(ModelDto contextProcess, ModelDto ruleProcess) throws Exception {// TOTHINK
		// origin - 01.08.2024, last edit - 13.11.2024
		boolean res = false;
		try {
			if ((Etc.strEquals(contextProcess.meter, ruleProcess.meter))
					& (Etc.strEquals(contextProcess.unit, ruleProcess.unit))) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("Process.getMatchRule, ex=" + ex.getMessage(), WB.strEmpty, "Process");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Process.getMatchRule, res=" + res + ", contextProcess=" + contextProcess + ", ruleProcess="
				+ ruleProcess, WB.strEmpty, "Process");
		return res;
	}

	public static boolean checkRule(ModelDto contextProcess, ModelDto ruleProcess, String contextCheck)
			throws Exception {// TOTHINK
		// origin - 01.08.2024, last edit - 13.11.2024
		boolean res = true;
		try {
			if (getMatchRule(contextProcess, ruleProcess)) {

				if ((Etc.strEquals(contextCheck, "Info.Process.MaxLimit"))
						& (Conv.getDouble(contextProcess.meterValue) > Conv.getDouble(ruleProcess.meterValue))) {
					res = false;
				}

				if ((Etc.strEquals(contextCheck, "Info.Process.MinLimit"))
						& (Conv.getDouble(contextProcess.meterValue) < Conv.getDouble(ruleProcess.meterValue))) {
					res = false;
				}

				if ((Etc.strEquals(contextCheck, "Meter.Listed")) & // TODO get IIN
						(CSV.getMatch(ruleProcess.meterValue, contextProcess.face1).size() == 0)) {// meterValue="podft1.csv",
					// "podft2.csv"
					res = false;
				}

				if ((Etc.strEquals(contextCheck, "Meter.NotListed")) & // TODO get IIN
						(CSV.getMatch(ruleProcess.meterValue, contextProcess.face1).size() > 0)) {
					res = false;
				}

			}
		} catch (Exception ex) {
			WB.addLog("Process.checkRule, ex=" + ex.getMessage(), WB.strEmpty, "Process");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Process.checkRule, res=" + res + ", contextProcess=" + contextProcess + ", ruleProcess="
				+ ruleProcess + ", contextCheck=" + contextCheck, WB.strEmpty, "Process");
		return res;
	}

	public static boolean ruleIsValid(ModelDto contextProcess, ModelDto ruleProcess) throws Exception {
		// origin - 01.08.2024, last edit - 03.08.2024
		boolean res = true;
		try {

			if (Etc.strEquals(ruleProcess.info, "Info.Process.MaxLimit")) {
				res = Process.checkRule(contextProcess, ruleProcess, "Info.Process.MaxLimit");
			}
			if (Etc.strEquals(ruleProcess.info, "Info.Process.MinLimit")) {
				res = Process.checkRule(contextProcess, ruleProcess, "Info.Process.MinLimit");
			}
			if (Etc.strEquals(ruleProcess.meter, "Meter.Listed")) {
				res = Process.checkRule(contextProcess, ruleProcess, "Meter.Listed");
			}
			if (Etc.strEquals(ruleProcess.meter, "Info.Process.MinLimit")) {
				res = Process.checkRule(contextProcess, ruleProcess, "Meter.NotListed");
			}

		} catch (Exception ex) {
			WB.addLog("Process.ruleIsValid, ex=" + ex.getMessage(), WB.strEmpty, "Process");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Process.ruleIsValid, res=" + res + ", contextProcess=" + contextProcess + ", ruleProcess="
				+ ruleProcess, WB.strEmpty, "Process");
		return res;
	}

	public static boolean contextIsValid(List<ModelDto> contextProcess, List<ModelDto> ruleProcess) throws Exception {
		// origin - 01.08.2024, last edit - 02.08.2024
		boolean res = true;
		try {
			for (var currRule : ruleProcess) {
				for (var currContext : contextProcess) {
					res = Process.ruleIsValid(currContext, currRule);
					if (res = false) {
						break;
					}
				}
				if (res = false) {
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Process.contextIsValid, ex=" + ex.getMessage(), WB.strEmpty, "Process");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Process.contextIsValid, res=" + res + ", contextProcess=" + contextProcess + ", ruleProcess="
				+ ruleProcess, WB.strEmpty, "Process");
		return res;
	}

	public static List<ModelDto> getRule(String parentProcessCode) throws Exception {
		// origin - 02.08.2024, last edit - 05.10.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			res = ReadSet.getEqualsByCode(WB.abcLast.basic, Process.strPatternRule);
			res = ReadSet.getEqualsByParent(res, parentProcessCode);
		} catch (Exception ex) {
			WB.addLog("Process.getRule, ex=" + ex.getMessage(), WB.strEmpty, "Process");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Process.getRule, res=" + res + ", parentProcessCode=" +
		// parentProcessCode, WB.strEmpty, "Process");
		return res;
	}

//	public Process(String Id, String Code, String Description, String Parent) throws Exception {// TOTHINK
//		// origin - 02.08.2024, last edit - 29.12.2024
//		super(Id, Code, Description);
//		this.table = this.getClass().getName();
//		this.parent = Parent;
//		this.rule = getRule(Parent);
//	}

	public Process(String Id) throws Exception {
		// origin - 05.12.2023, last edit - 29.12.2024
		this.clear();
		this.src = this.id = Id;
		this.isExist();
		this.isValid();
		this.fix();
	}

	public Process() throws Exception {
		// origin - 05.12.2023, last edit - 29.12.2024
		this.clear();
		var root = Abc.getRoot(this.table);
		this.id = root.id;
		this.parent = root.parent;
		this.slice = root.slice;
		this.date1 = root.date1;
		this.date2 = root.date2;
		this.code = root.code;
		this.description = root.description;
		this.role = root.role;
		this.sign = root.sign;
		this.more = root.more;
		this.fix();
	}

	public void clear() throws Exception {
		// origin - 29.12.2024, last edit - 29.12.2024
		try {
			super.clear();
			this.table = this.getClass().getName();
			this.rule = new ArrayList<ModelDto>();
		} catch (Exception ex) {
			WB.addLog("Account.clear, ex=" + ex.getMessage(), WB.strEmpty, "Account");
		} finally {
			Etc.doNothing();
		}
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 21.11.2024
		try {

//			// ctor()
//			Process p0 = new Process();
//			WB.addLog2("Process.test.ctor()=" + p0 + ", isExist=" + p0.isExist() + ", isValid=" + p0.isValid(),
//					WB.strEmpty, "Process");

//			// getRule
//			String[] arg1 = new String[] { "Process", "Process.Prot" };
//			for (var testArg1 : arg1) {
//				WB.addLog2(
//						"Process.test.getRule, res.size=" + Process.getRule(testArg1).size() + ", testArg1=" + testArg1,
//						WB.strEmpty, "Process");
//			}

		} catch (Exception ex) {
			WB.addLog("Process.test, ex=" + ex.getMessage(), WB.strEmpty, "Process");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Process.test end ", WB.strEmpty, "Process");
	}
}
