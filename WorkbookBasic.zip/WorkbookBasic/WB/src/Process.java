import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

public class Process extends ModelDto {
	// origin - 28.09.2023, last edit - 04.08.2024
	public List<ModelDto> rule;
	public static TreeSet<String> standard = new TreeSet<String>();
	public static TreeSet<String> sectoral = new TreeSet<String>();
	public static TreeSet<String> custom = new TreeSet<String>();
	public static String strPatternRule = WB.strEmpty;

	static {
		try {
			Process.standard = new TreeSet<String>();// TOTHINK
			Process.sectoral = new TreeSet<String>();// TOTHINK
			Process.custom = new TreeSet<String>();// TOTHINK
			Process.strPatternRule = "Rule";
		} catch (Exception ex) {
			WB.addLog("Process.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Process");
		} finally {
			Etc.doNothing();
		}
	}

	public static boolean getMatchRule(ModelDto contextProcess, ModelDto ruleProcess) throws Exception {// TOTHINK
		// origin - 01.08.2024, last edit - 02.08.2024
		boolean res = false;
		try {
			if (Etc.strEquals(contextProcess.meter, ruleProcess.meter)) {
				if (Etc.strEquals(contextProcess.unit, ruleProcess.unit)) {
					res = true;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Process.getMatchRule, ex=" + ex.getMessage(), WB.strEmpty, "Process");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Process.getMatchRule, res=" + res + ", contextProcess=" + contextProcess + ", ruleProcess="
				+ ruleProcess, WB.strEmpty, "Process");
		return res;
	}

	public static boolean checkRule(ModelDto contextProcess, ModelDto ruleProcess, String contextCheck)
			throws Exception {// TOTHINK
		// origin - 01.08.2024, last edit - 03.08.2024
		boolean res = true;
		try {
			if (getMatchRule(contextProcess, ruleProcess)) {

				if (Etc.strEquals(contextCheck, "Info.Process.MaxLimit")) {
					if (Conv.getDouble(contextProcess.meterValue) > Conv.getDouble(ruleProcess.meterValue)) {
						res = false;
					}
				}

				if (Etc.strEquals(contextCheck, "Info.Process.MinLimit")) {
					if (Conv.getDouble(contextProcess.meterValue) < Conv.getDouble(ruleProcess.meterValue)) {
						res = false;
					}
				}

				if (Etc.strEquals(contextCheck, "Meter.Listed")) {// TODO get IIN
					if (CSV.getMatch(ruleProcess.meterValue, contextProcess.face1).size() == 0) {// meterValue="podft1.csv",
						// "podft2.csv"
						res = false;
					}
				}

				if (Etc.strEquals(contextCheck, "Meter.NotListed")) {// TODO get IIN
					if (CSV.getMatch(ruleProcess.meterValue, contextProcess.face1).size() > 0) {
						res = false;
					}
				}

			}
		} catch (Exception ex) {
			WB.addLog("Process.checkRule, ex=" + ex.getMessage(), WB.strEmpty, "Process");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Process.checkRule, res=" + res + ", contextProcess=" + contextProcess + ", ruleProcess="
				+ ruleProcess + ", contextCheck=" + contextCheck, WB.strEmpty, "Process");
		return res;
	}

	public static boolean ruleIsValid(ModelDto contextProcess, ModelDto ruleProcess) throws Exception {
		// origin - 01.08.2024, last edit - 03.08.2024
		boolean res = true;
		try {

			if (Etc.strEquals(ruleProcess.info, "Info.Process.MaxLimit")) {
				res = Process.checkRule(contextProcess, ruleProcess, "Info.Process.MaxLimit");
			}
			if (Etc.strEquals(ruleProcess.info, "Info.Process.MinLimit")) {
				res = Process.checkRule(contextProcess, ruleProcess, "Info.Process.MinLimit");
			}
			if (Etc.strEquals(ruleProcess.meter, "Meter.Listed")) {
				res = Process.checkRule(contextProcess, ruleProcess, "Meter.Listed");
			}
			if (Etc.strEquals(ruleProcess.meter, "Info.Process.MinLimit")) {
				res = Process.checkRule(contextProcess, ruleProcess, "Meter.NotListed");
			}

		} catch (Exception ex) {
			WB.addLog("Process.ruleIsValid, ex=" + ex.getMessage(), WB.strEmpty, "Process");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Process.ruleIsValid, res=" + res + ", contextProcess=" + contextProcess + ", ruleProcess="
				+ ruleProcess, WB.strEmpty, "Process");
		return res;
	}

	public static boolean contextIsValid(List<ModelDto> contextProcess, List<ModelDto> ruleProcess) throws Exception {
		// origin - 01.08.2024, last edit - 02.08.2024
		boolean res = true;
		try {
			for (var currRule : ruleProcess) {
				for (var currContext : contextProcess) {
					res = Process.ruleIsValid(currContext, currRule);
					if (res = false) {
						break;
					}
				}
				if (res = false) {
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Process.contextIsValid, ex=" + ex.getMessage(), WB.strEmpty, "Process");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Process.contextIsValid, res=" + res + ", contextProcess=" + contextProcess + ", ruleProcess="
				+ ruleProcess, WB.strEmpty, "Process");
		return res;
	}

	public static List<ModelDto> getRule(String parentProcessCode) throws Exception {
		// origin - 02.08.2024, last edit - 02.08.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			res = ModelDto.getSubsetByCode(WB.abcLast.basic, Process.strPatternRule);
			res = ModelDto.getSubsetByParent(res, parentProcessCode);
		} catch (Exception ex) {
			WB.addLog("Process.getRule, ex=" + ex.getMessage(), WB.strEmpty, "Process");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Process.getRule, res=" + res + ", parentProcessCode=" +
		// parentProcessCode, WB.strEmpty, "Process");
		return res;
	}

	public Process(String Id, String Code, String Description, String Parent) throws Exception {
		// origin - 02.08.2024, last edit - 02.08.2024
		try {
			this.id = Id;
			this.code = Code;
			this.description = Description;
			this.parent = Parent;
			this.rule = getRule(Parent);
		} catch (Exception ex) {
			WB.addLog("Process.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Process");
		} finally {
			Etc.doNothing();
		}
	}

	public Process(String Id, String Code, String Description) throws Exception {
		// origin - 05.12.2023, last edit - 02.08.2024
		try {
			this.id = Id;
			this.code = Code;
			this.description = Description;
		} catch (Exception ex) {
			WB.addLog("Process.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Process");
		} finally {
			Etc.doNothing();
		}
	}

	public Process() throws Exception {
		// origin - 05.12.2023, last edit - 07.07.2024
		try {
		} catch (Exception ex) {
			WB.addLog("Process.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Process");
		} finally {
			Etc.doNothing();
		}
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 02.08.2024
		try {

			// getRule
			String[] arg1 = new String[] { "Process", "Process.Prot" };
			for (var testArg1 : arg1) {
				WB.addLog2(
						"Process.test.getRule, res.size=" + Process.getRule(testArg1).size() + ", testArg1=" + testArg1,
						WB.strEmpty, "Process");
			}

		} catch (Exception ex) {
			WB.addLog("Process.test, ex=" + ex.getMessage(), WB.strEmpty, "Process");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Process.test end ", WB.strEmpty, "Process");
	}
}
