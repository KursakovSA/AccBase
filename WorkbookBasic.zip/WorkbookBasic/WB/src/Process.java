import java.util.Arrays;
import java.util.TreeSet;

public class Process extends Model {
	// origin - 28.09.2023, last edit - 18.01.2024
	public static Process root;
	public Process parent;
	public Face face1;
    public Face face2;
    public Face face;
    public Slice slice;
    public Geo geo;
    public Sign sign;
    public Account account;
    public Asset asset;
    public Deal deal;
    public Item item;
    public Debt debt;
    public Price price;
    public Role role;
    public Info info;
    public Meter meter;
    public String meterValue;
    public Unit unit;
    public Mark mark;
    
    static {
		root = new Process("Process","Process","ProcessData");
		standard = new TreeSet<String>(Arrays.asList("", "", "", "", "", "", ""));// TODO
		sectoral = new TreeSet<String>(Arrays.asList("", "", ""));//TODO
		custom = new TreeSet<String>(Arrays.asList("", "", ""));// TODO
	}
    
    public Process(String Id, String Code, String Description) {
		// origin - 05.12.2023, last edit - 05.12.2023
		this.id = Id;
		this.code = Code;
		this.description = Description;
	}
    
    public Process() {
		// origin - 05.12.2023, last edit - 05.12.2023
	}
    
    public static void test() {
		// origin - 28.10.2023, last edit - 18.01.2024
    	WB.addLog("Process.test, Process.root=" + Process.root, "", "Process");
	}
}
