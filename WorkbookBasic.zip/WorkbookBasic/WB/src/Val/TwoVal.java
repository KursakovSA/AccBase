import java.util.List;

public final class TwoVal {
	// origin - 02.10.2025, last edit - 12.10.2025
	public String id, src, partVal1, partVal2;
	private static List<String> listDelStr;
	public String val1, val2;

	static {
		try {
			TwoVal.listDelStr = List.of(",");
		} catch (Exception ex) {
			WB.addLog("TwoVal.static ctor, ex=" + ex.getMessage(), "", "TwoVal");
		}
	}

	private void getId() throws Exception {
		// origin - 02.10.2025, last edit - 02.10.2025
		try {
			this.id = " " + this.val1 + "," + this.val2;
			if (this.partVal1.isEmpty() && this.partVal2.isEmpty()) {
				this.id = "";
			}
		} catch (Exception ex) {
			WB.addLog("TwoVal.getId():void, ex=" + ex.getMessage(), "", "TwoVal");
		}
	}

	private void getVal() throws Exception {
		// origin - 02.10.2025, last edit - 02.10.2025
		try {
			this.val1 = this.partVal1;
			this.val2 = this.partVal2;
		} catch (Exception ex) {
			WB.addLog("TwoVal.getVal():void, ex=" + ex.getMessage(), "", "TwoVal");
		}
	}

	private void getPart() throws Exception {
		// origin - 02.10.2025, last edit - 15.10.2025
		try {
			String tmp = this.src;
			// get partVal1,2
			// int posLocalSplit = tmp.indexOf(" , "); // pos " , "
			int posLocalSplit = tmp.indexOf(","); // pos " , "
			if (posLocalSplit > 0) {
				this.partVal1 = Etc.fixTrim(tmp.substring(0, posLocalSplit));
				this.partVal1 = Etc.delStr(this.partVal1, TwoVal.listDelStr);

				this.partVal2 = Etc.fixTrim(tmp.substring(posLocalSplit));
				this.partVal2 = Etc.delStr(this.partVal2, TwoVal.listDelStr);
			} else {
				this.partVal1 = Etc.fixTrim(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("TwoVal.getPart():void, ex=" + ex.getMessage(), "", "TwoVal");
		}
	}

	public TwoVal(String Src) throws Exception {
		// origin - 02.10.2025, last edit - 02.10.2025
		this.clear();
		this.src = Etc.fixTrim(Src);
		this.getPart();
		this.getVal();
		this.getId();
	}

	public TwoVal() throws Exception {
		// origin - 02.10.2025, last edit - 02.10.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 02.10.2025, last edit - 02.10.2025
		try {
			this.id = this.src = this.partVal1 = this.partVal2 = "";
			this.val1 = this.val2 = "";
		} catch (Exception ex) {
			WB.addLog("TwoVal.clear():void, ex=" + ex.getMessage(), "", "TwoVal");
		}
	}

	public String toString() {
		// origin - 02.10.2025, last edit - 02.10.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("id ", this.id);
			res = res + Fmtr.addAnyway(" src ", this.src);
			res = res + Fmtr.addAnyway(" partVal1  ", this.partVal1);
			res = res + Fmtr.addAnyway(" val1 ", this.val1);
			res = res + Fmtr.addAnyway(" partVal2 ", this.partVal2);
			res = res + Fmtr.addAnyway(" val2 ", this.val2);
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 02.10.2025, last edit - 15.10.2025
		try {

//			WB.addLog2("TwoVal.test.ctor(String)", "", "TwoVal");
//			for (var tmp : new String[] { "Face.FA1", "Face.FA1 ,", "Face.FA1 , ", "Face.FA1 , Face.FA1.Crew1",
//					"Face.Tralala , Face.Tralala.Crew1" }) {
//				WB.addLog2("TwoVal.test.ctor(String), res=" + new TwoVal(tmp), "", "TwoVal");
//			}

		} catch (Exception ex) {
			WB.addLog("TwoVal.test():void, ex=" + ex.getMessage(), "", "TwoVal");
		}
	}
}