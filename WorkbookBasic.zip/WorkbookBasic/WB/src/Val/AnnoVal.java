import java.util.ArrayList;
import java.util.List;

public final class AnnoVal {
	// origin - 07.11.2024, last edit - 29.11.2025
	public String id, context, src, partName, name, partUnit, partVal, val, partAnno;
	public Unit unit;
	public List<String> anno;
	private static List<String> listDelStr;

	static {
		try {
			AnnoVal.listDelStr = List.of("(", ")", "=");
		} catch (Exception ex) {
			WB.addLog("AnnoVal.static ctor, ex=" + ex.getMessage(), "", "AnnoVal");
		}
	}

	public void getUnit() throws Exception {
		// origin - 18.06.2025, last edit - 18.06.2025
		try {
			if (this.partUnit.isEmpty() == false) {
				this.unit = new Unit(this.partUnit);
				this.context = this.unit.expectedValue;
			}
		} catch (Exception ex) {
			WB.addLog("AnnoVal.getUnit():void, ex=" + ex.getMessage(), "", "AnnoVal");
		}
	}

	private void getVal() throws Exception {
		// origin - 07.11.2024, last edit - 29.11.2025
		try {
			this.name = this.partName;
			this.val = Etc.fixTrim(this.partVal);
			this.anno = Fmtr.listVal(this.partAnno, ";");
			this.getUnit();
			this.id = this.name + " " + this.val + " " + this.anno;// + " " + this.unit.code + ", "
			// + this.unit.description;
			if (this.partUnit.isEmpty() == false) {
				this.id = this.id + " " + this.unit.code + ", " + this.unit.description;
			}
		} catch (Exception ex) {
			WB.addLog("AnnoVal.getVal():void, ex=" + ex.getMessage(), "", "AnnoVal");
		}
	}

	private void getPart() throws Exception {
		// origin - 07.11.2024, last edit - 18.06.2025
		try {
			String tmp = Etc.fixTrim(this.src);

			int posLocalSplitValUnit = tmp.indexOf("(Unit.");
			if (posLocalSplitValUnit > 0) {
				this.partUnit = Etc.fixTrim(tmp.substring(posLocalSplitValUnit));
				tmp = Etc.delStr(tmp, this.partUnit);
				this.partUnit = Etc.delStr(this.partUnit, AnnoVal.listDelStr);
			}

			int posLocalStrMiddleEquation = 0;
			posLocalStrMiddleEquation = tmp.indexOf("=");
			if (posLocalStrMiddleEquation > 0) {
				this.partName = Etc.fixTrim(tmp.substring(0, posLocalStrMiddleEquation));
				this.partName = Etc.delStr(this.partName, AnnoVal.listDelStr);
				tmp = tmp.substring(posLocalStrMiddleEquation);
				tmp = Etc.delStr(tmp, "=");
			}

			int posLocalSplitVal = tmp.indexOf("("); // pos char "("
			if (posLocalSplitVal > 0) {
				this.partVal = Etc.fixTrim(tmp.substring(0, posLocalSplitVal));
				this.partAnno = Etc.fixTrim(tmp.substring(posLocalSplitVal));
				this.partAnno = Etc.delStr(this.partAnno, AnnoVal.listDelStr);
				this.id = this.partVal + " " + Fmtr.listVal(this.partAnno, ";");
			}
			// }
		} catch (Exception ex) {
			WB.addLog("AnnoVal.getPart():void, ex=" + ex.getMessage(), "", "AnnoVal");
		}
	}

	public AnnoVal(String Src) throws Exception {
		// origin - 07.11.2024, last edit - 18.06.2025
		this.clear();
		this.src = Etc.fixTrim(Src);
		this.getPart();
		this.getVal();
	}

	public AnnoVal() throws Exception {
		// origin - 07.11.2024, last edit - 18.06.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 18.06.2025, last edit - 06.09.2025
		try {
			this.id = this.context = this.src = this.partName = this.name = this.partUnit = this.partVal = this.val = this.partAnno = "";
			this.anno = new ArrayList<String>();
			this.unit = null;
		} catch (Exception ex) {
			WB.addLog("AnnoVal.clear():void, ex=" + ex.getMessage(), "", "AnnoVal");
		}
	}

	public String toString() {
		// origin - 06.01.2025, last edit - 18.06.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("id ", this.id);
			res = res + Fmtr.addAnyway(" src ", this.src);
			res = res + Fmtr.addAnyway(" partName ", this.partName);
			res = res + Fmtr.addAnyway(" name ", this.name);
			res = res + Fmtr.addAnyway(" partVal ", this.partVal);
			res = res + Fmtr.addAnyway(" val ", this.val);
			res = res + Fmtr.addAnyway(" partAnno ", this.partAnno);
			res = res + Fmtr.addAnyway(" anno ", this.anno);
			res = res + Fmtr.addIfNotEmpty(" context ", this.context);
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 07.11.2024, last edit - 30.11.2025
		try {

//			WB.addLog2("AnnoVal.test.ctor(String)", "", "AnnoVal");
//			for (var tmp : new String[] { "Price = 100.0 (400.0;830.0) (Unit.KZT)",
//					"12 000.0 (14 000.0) (Unit.tralala)", "56 564.0 (67 000.0;83 000.0)", "123456789012 (ИИН)" }) {
//				WB.addLog2("AnnoVal.test.ctor(String), res=" + new AnnoVal(tmp), "", "AnnoVal");
//			}

		} catch (Exception ex) {
			WB.addLog("AnnoVal.test():void, ex=" + ex.getMessage(), "", "AnnoVal");
		}
	}
}