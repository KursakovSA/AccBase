import java.util.ArrayList;
import java.util.List;

public final class NVal {
	// origin - 24.08.2026, last edit - 24.08.2026
	public String id, src;
	private static List<String> listDelStr;
	public List<String> val;

	static {
		try {
			NVal.listDelStr = List.of(",");
		} catch (Exception ex) {
			WB.addLog("NVal.static ctor, ex=" + ex.getMessage(), "", "NVal");
		}
	}

	public String getVal(int userIndex) throws Exception {
		// origin - 24.08.2026, last edit - 24.08.2026
		String res = "";
		try {
			if (userIndex <= 0) {
				return res;
			}
			int innerIndex = userIndex - 1; // innerIndex start on 0
			if (this.val.size() >= userIndex) {
				res = this.val.get(innerIndex);
			}
		} catch (Exception ex) {
			WB.addLog("NVal.getVal():void, ex=" + ex.getMessage() + ", userIndex=" + userIndex, "", "NVal");
		}
		return res;
	}

	private void getId() throws Exception {
		// origin - 24.08.2026, last edit - 24.08.2026
		try {
			this.id = this.val.toString();
//			for (var curr : this.val) {
//				if (curr.isEmpty() == false) {
//					this.id = this.id + curr;
//				}
//			}
		} catch (Exception ex) {
			WB.addLog("NVal.getId():void, ex=" + ex.getMessage(), "", "NVal");
		}
	}

	public NVal(String Src) throws Exception {
		// origin - 24.08.2026, last edit - 24.08.2026
		this.clear();
		this.src = Etc.fixTrim(Src);
		this.val = List.of(this.src.split(NVal.listDelStr.getFirst()));
		this.getId();
	}

	public NVal() throws Exception {
		// origin - 24.08.2026, last edit - 24.08.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 24.08.2026, last edit - 24.08.2026
		try {
			this.id = this.src = "";
			this.val = new ArrayList<String>();
		} catch (Exception ex) {
			WB.addLog("NVal.clear():void, ex=" + ex.getMessage(), "", "NVal");
		}
	}

	public String toString() {
		// origin - 24.08.2026, last edit - 24.08.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("id ", this.id);
			res = res + Fmtr.addAnyway(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", val ", this.val);
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 24.08.2026, last edit - 24.08.2026
		try {

//			WB.addLog2("NVal.test.ctor(String)", "", "NVal");
//			for (var tmp : new String[] { "", "1", "1 , FullAccess", "1 , FullAccess , Face.FA1.StaffTable1.Boss",
//					"1 , FullAccess , Face.FA1.StaffTable1.Boss , 12345678" }) {
//				WB.addLog2("NVal.test.ctor(String), res=" + new NVal(tmp) + ", tmp=" + tmp, "", "NVal");
//			}

		} catch (Exception ex) {
			WB.addLog("NVal.test():void, ex=" + ex.getMessage(), "", "NVal");
		}
	}
}