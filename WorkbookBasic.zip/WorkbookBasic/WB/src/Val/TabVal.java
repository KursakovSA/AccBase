import java.util.ArrayList;
import java.util.List;

public final class TabVal {
	// origin - 15.02.2026, last edit - 17.02.2026
	public String id, code, description;
	public List<String> src, col, val;
	public List<RowVal> row;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("TabVal.static ctor, ex=" + ex.getMessage(), "", "TabVal");
		}
	}

	public static List<String> serialize(TabVal tabVal) throws Exception {
		// origin - 18.02.2026, last edit - 18.02.2026
		List<String> res = new ArrayList<String>();
		try {
			for (var curr : tabVal.row) {
				res.add(RowVal.serialize(curr));
			}
		} catch (Exception ex) {
			WB.addLog("TabVal.serialize(TabVal):List<String>, ex=" + ex.getMessage(), "", "TabVal");
		}
		return res;
	}

	private void getColVal() throws Exception {
		// origin - 16.02.2026, last edit - 18.02.2026
		try {
			if (this.row.size() != 0) {
				var tmp = this.row.getFirst();
				for (var curr : tmp.val) {
					// WB.addLog2("TabVal.getColVal():void, curr=" + curr, "", "TabVal");
//					if (curr.startsWith("Col")) {
//						col.add(curr);
//					} else {
//						val.add(curr);
//					}
					if (Etc.strContains(curr, "Col")) {
						this.col.add(curr);
					} else {
						this.val.add(curr);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("TabVal.getColVal():void, ex=" + ex.getMessage(), "", "TabVal");
		}
	}

	private void getRow() throws Exception {
		// origin - 15.02.2026, last edit - 17.02.2026
		try {
			if (this.src.size() != 0) {
				for (var curr : src) {
					var tmp = new RowVal(curr);
					this.row.add(tmp);
				}
			}
		} catch (Exception ex) {
			WB.addLog("TabVal.getRow():void, ex=" + ex.getMessage(), "", "TabVal");
		}
	}

	public TabVal(List<String> Src) throws Exception {
		// origin - 16.02.2026, last edit - 18.02.2026
		this.clear();
		this.src = Src;
		this.getRow();
		this.getColVal();
	}

	public TabVal() throws Exception {
		// origin - 15.02.2026, last edit - 15.02.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 15.02.2026, last edit - 17.02.2026
		try {
			this.id = this.code = this.description = "";
			this.src = this.col = this.val = new ArrayList<String>();
			this.row = new ArrayList<RowVal>();
		} catch (Exception ex) {
			WB.addLog("TabVal.clear():void, ex=" + ex.getMessage(), "", "TabVal");
		}
	}

	public String toString() {
		// origin - 15.02.2026, last edit - 17.02.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("id ", this.id);
			res = res + Fmtr.addIfNotEmpty("src.size ", this.src.size());
			res = res + Fmtr.addIfNotEmpty(" code ", this.code);
			res = res + Fmtr.addIfNotEmpty(" description ", this.description);
			res = res + Fmtr.addIfNotEmpty(" row.size ", this.row.size());
			res = res + Fmtr.addIfNotEmpty(" col ", this.col);
			res = res + Fmtr.addIfNotEmpty(" val ", this.val);
		} catch (Exception ex) {
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 15.02.2026, last edit - 18.02.2026
		try {

			{
				WB.addLog2("TabVal.test.serialize(TabVal):String", "", "TabVal");
				var tmp1 = List.of("Col1=Face;Col2=Weight;Col3=Unit;Val1=Price;Val2=Sum;", "Face1;W12;Unit.Kg;1;2 ;",
						"Face2;W13;Unit.Kg;3;4", "Face1;W13;Unit.Gr;300;400");
				var tmp2 = new TabVal(tmp1);
				var tmp3 = TabVal.serialize(tmp2);
				WB.addLog2("TabVal.test.serialize(TabVal):String, res.size=" + tmp3.size(), "", "TabVal");
				WB.log(tmp3, "TabVal");
				var tmp4 = new TabVal(tmp3);
				WB.addLog2("TabVal.test.deserialize, res=" + tmp4, "", "TabVal");
				WB.log(tmp4.row, "RowVal");
			}

			{
				WB.addLog2("TabVal.test.ctor(List<String>)", "", "TabVal");
				var tmp1 = List.of("Col1=Face;Col2=Weight;Col3=Unit;Val1=Price;Val2=Sum;", "Face1;W12;Unit.Kg;1;2 ;",
						"Face2;W13;Unit.Kg;3;4", "Face1;W13;Unit.Gr;300;400");
				var tmp2 = new TabVal(tmp1);
				WB.addLog2("TabVal.test.ctor(List<String>), res=" + tmp2, "", "TabVal");
				WB.log(tmp2.row, "RowVal");
			}

		} catch (Exception ex) {
			WB.addLog("TabVal.test():void, ex=" + ex.getMessage(), "", "TabVal");
		}
	}
}