import java.util.ArrayList;
import java.util.List;

public final class StepwiseVal {
	// origin - 05.07.2026, last edit - 05.07.2026
	public String src1, src2, id, unit;
	public List<String> unitLimit, val;

	public String getValByUnitLimit(String unitVal) throws Exception {
		// origin - 05.07.2026, last edit - 06.07.2026
		String res = "";
		try {

			if (unitVal.isEmpty()) {
				return res = "";
			}

			if (this.val.size() == 0) {
				return res = "";
			}

			if (this.val.size() == 1) {
				return res = val.getFirst();
			}

			if (this.unitLimit.size() == 0) {
				return res = val.getFirst();
			}

			// find unitVal > right border unitLimit
			var dblUnitVal = Double.valueOf(unitVal);
			var dblLastUnitVal = Double.valueOf(this.unitLimit.getLast());
			if (dblUnitVal > dblLastUnitVal) {
				if (this.val.size() > this.unitLimit.size()) {
					return res = this.val.get(this.unitLimit.size());
				}
				if (this.val.size() <= this.unitLimit.size()) {
					return res = this.val.getLast();
				}
			}

			// find unitVal < left border unitLimit
			var dblFirstUnitVal = Double.valueOf(this.unitLimit.getFirst());
			if (dblUnitVal <= dblFirstUnitVal) {
				return res = this.val.getFirst();
			}

			// other cases
			for (int i = 0; i < this.unitLimit.size(); i++) {
				if (Etc.strEquals(unitVal, this.unitLimit.get(i))) {
					res = this.val.get(i);
				}
				if (Etc.strEquals(unitVal, this.unitLimit.get(i)) == false) {
					var tmp1 = Double.valueOf(unitVal); // ex. 3.66
					var tmp2 = Double.valueOf(this.unitLimit.get(i)); // ex.5.89
					if (tmp1 <= tmp2) { // ex. 3.66 < 5.89
						res = this.val.get(i); // ex. then res=3.66
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("StepwiseVal.getValByUnitLimit(String):String, ex=" + ex.getMessage(), "", "StepwiseVal");
		}
		return res;
	}

	public StepwiseVal(List<String> Src1, List<String> Src2) throws Exception {
		// origin - 05.07.2026, last edit - 05.07.2026
		this.clear();
		this.src1 = String.valueOf(Src1);
		this.src2 = String.valueOf(Src2);

		if (Src1.size() == 1) {
			this.unit = this.src1; // ex. "тн"
		}

		if (Src1.size() >= 1) {
			this.unit = Src1.getFirst(); // ex. "тн"
			for (int i = 1; i < Src1.size(); i++) {
				this.unitLimit.add(Src1.get(i)); // ex. "5,12"
			}
		}

		if (Src2.size() >= 1) {
			this.val.addAll(Src2);
		}

		this.id = this.unitLimit + this.unit + "," + this.val;
	}

	public StepwiseVal(String Src1, String Src2) throws Exception {
		// origin - 05.07.2026, last edit - 05.07.2026
		this.clear();
		this.src1 = Etc.fixTrim(Src1);
		this.src2 = Etc.fixTrim(Src2);

		var tmp = new ArrayList<String>();
		if (Etc.strContains(this.src1, ",")) {
			tmp.addAll(List.of(Etc.fixTrim(this.src1).split(","))); // ex. "тн,5,12"
		}
		if (Etc.strContains(this.src1, ",") == false) {
			tmp.add(this.src1); // ex. "тн"
		}

		if (tmp.size() == 1) {
			this.unit = this.src1; // ex. "тн"
		}

		if (tmp.size() >= 1) { // ex. "тн,5,12"
			this.unit = tmp.getFirst(); // ex. "тн"
			tmp.removeFirst(); // ex. "5,12"
			if (tmp.size() != 1) {
				this.unitLimit.addAll(tmp); // ex. "5,12"
			}
		}

		this.val = List.of(Etc.fixTrim(Src2).split(","));
		this.id = this.unitLimit + this.unit + "," + this.val;
	}

	public StepwiseVal() throws Exception {
		// origin - 05.07.2026, last edit - 25.05.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 05.07.2026, last edit - 05.07.2026
		try {
			this.src1 = this.src2 = this.id = this.unit = "";
			this.unitLimit = new ArrayList<String>();
			this.val = new ArrayList<String>();
		} catch (Exception ex) {
			WB.addLog("StepwiseVal.clear():void, ex=" + ex.getMessage(), "", "StepwiseVal");
		}
	}

	public String toString() {
		// origin - 05.07.2026, last edit - 05.07.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src1 ", this.src1);
			res = res + Fmtr.addAnyway(", src2 ", this.src2);
			res = res + Fmtr.addAnyway(", id ", this.id);
			res = res + Fmtr.addAnyway(", unit ", this.unit);
			res = res + Fmtr.addAnyway(", unitLimit ", this.unitLimit);
			res = res + Fmtr.addAnyway(", val ", this.val);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 05.07.2026, last edit - 06.07.2026
		try {

//			WB.addLog2("StepwiseVal.test.getValByUnitLimit(String)", "", "StepwiseVal");
//			for (var tmp1 : new String[] { "тн", "тн,5,12" }) {
//				for (var tmp2 : new String[] { "12000", "12000,15000", "12000,15000,16000" }) {
//					var tmp11 = List.of(tmp1.split(","));
//					var tmp22 = List.of(tmp2.split(","));
//					var tmp3 = new StepwiseVal(tmp11, tmp22);
//					for (var tmp4 : new String[] { "", "3", "5", "8", "12", "18" }) {
//						WB.addLog2("StepwiseVal.test.getValByUnitLimit(String), res=" + tmp3.getValByUnitLimit(tmp4)
//								+ ", tmp4=" + tmp4 + ", tmp3=" + tmp3, "", "StepwiseVal");
//					}
//				}
//			}

//			WB.addLog2("StepwiseVal.test.ctor(2List<String>)", "", "StepwiseVal");
//			for (var tmp1 : new String[] { "тн", "тн,5,12" }) {
//				for (var tmp2 : new String[] { "12000", "12000,15000", "12000,15000,16000" }) {
//					var tmp11 = List.of(tmp1.split(","));
//					var tmp22 = List.of(tmp2.split(","));
//					WB.addLog2("StepwiseVal.test.ctor(2List<String>), res=" + new StepwiseVal(tmp11, tmp22), "",
//							"StepwiseVal");
//				}
//			}

//			WB.addLog2("StepwiseVal.test.ctor(2String)", "", "StepwiseVal");
//			for (var tmp1 : new String[] { "тн", "тн,5,12" }) {
//				for (var tmp2 : new String[] { "12000", "12000,15000", "12000,15000,16000" }) {
//					WB.addLog2("StepwiseVal.test.ctor(2String), res=" + new StepwiseVal(tmp1, tmp2), "", "StepwiseVal");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("StepwiseVal.test():void, ex=" + ex.getMessage(), "", "StepwiseVal");
		}
	}
}