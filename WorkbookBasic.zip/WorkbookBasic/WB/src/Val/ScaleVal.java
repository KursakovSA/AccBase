import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unused")
public final class ScaleVal { // TOTHINK
	// origin - 04.09.2024, last edit - 12.10.2025
	// ex.
	// {argLeftLimit=(0:45.001)(Unit.MinRate);argRightLimit=(0:45.0)(Unit.MinRate);argRate=(0.293:0.105)(Unit.PercentPerDay);}
	private List<UnitVal> argLeftLimit = new ArrayList<UnitVal>(); // TODO
	private List<UnitVal> argRightLimit = new ArrayList<UnitVal>(); // TODO
	private List<UnitVal> argRate = new ArrayList<UnitVal>(); // TODO

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("ScaleVal.static ctor, ex=" + ex.getMessage(), "", "ScaleVal");
		}
	}

	private void getPart() throws Exception {// TODO
		// origin - 30.09.2024, last edit - 13.06.2025
		try {
//			if (this.isScaleVal()) {
//				int posLocalSplitLeft = this.src.indexOf(UnitVal.strLeftSplit); // pos "("
//				if (posLocalSplitLeft > 0) {
//					// this is res
//					this.partVal = Etc.fixTrim(this.src.substring(0, posLocalSplitLeft)); // ex. "12(Unit.KZT)" --> "12"
//
//					// clean, because may be alone chars "(" and\or ")" //??
//					// this.partVal = Etc.delStr(this.partVal, UnitVal.strLeftSplit);
//					// this.partVal = Etc.delStr(this.partVal, UnitVal.strRightSplit);
//					this.partVal = Etc.delStr(this.partVal, UnitVal.listDelStr);
//
//					this.partUnit = Etc.fixTrim(this.src.substring(posLocalSplitLeft));
//				}
//			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.getPart():void, ex=" + ex.getMessage(), "", "UnitVal");
		}
	}

	public ScaleVal(String Src) throws Exception {
		// origin - 30.09.2024, last edit - 17.06.2025
		// this.src = Etc.fixTrim(Src);
		// this.getPart();
	}

	public ScaleVal() throws Exception {
		// origin - 04.09.2024, last edit - 27.09.2024
	}

	public static void test() throws Exception {
		// origin - 04.09.2024, last edit - 13.06.2025
		try {

		} catch (Exception ex) {
			WB.addLog("ScaleVal.test():void, ex=" + ex.getMessage(), "", "ScaleVal");
		}
	}
}