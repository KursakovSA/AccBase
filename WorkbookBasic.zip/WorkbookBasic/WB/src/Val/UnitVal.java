import java.util.List;

public class UnitVal {// ex. AmountDeal = "12000.0(Unit.KZT)"
	// origin - 13.09.2024, last edit - 17.06.2025
	public String id, context, src, partName, name, partUnit;
	public Unit unit;
	private static List<String> listDelStr;
	public String partVal;
	public double val;

	static {
		UnitVal.listDelStr = List.of("(", ")", "=");
		try {
		} catch (Exception ex) {
			WB.addLog("UnitVal.static ctor, ex=" + ex.getMessage(), "", "UnitVal");
		}
	}

	public static UnitVal multiply(List<UnitVal> multipliers, String toUnit) throws Exception {
		// origin - 15.02.2025, last edit - 13.06.2025
		UnitVal res = new UnitVal();
		double res1 = 1.0;
		try {
			UnitVal tmp = new UnitVal();
			for (var curr : multipliers) {
				tmp = UnitVal.conv(curr, toUnit, "");
				// res1 = res1 + tmp.val;
				res1 = Etc.multiply(res1, tmp.val);
			}
			res = new UnitVal(res1, toUnit);
		} catch (Exception ex) {
			WB.addLog("UnitVal.multiply (List<UnitVal> multipliers, String toUnit):UnitVal, ex=" + ex.getMessage(), "",
					"UnitVal");
		}
		return res;
	}

	public static UnitVal multiply(List<UnitVal> multipliers) throws Exception {// (same unit)
		// origin - 14.02.2025, last edit - 13.06.2025
		UnitVal res = new UnitVal();
		double res1 = 1.0;
		try {
			var toUnit = "";
			for (var curr : multipliers) {
				// res1 = res1 * curr.val;
				res1 = Etc.multiply(res1, curr.val);
				toUnit = curr.unit.code;
			}
			res = new UnitVal(res1, toUnit);
		} catch (Exception ex) {
			WB.addLog("UnitVal.multiply (List<UnitVal> multipliers):UnitVal, ex=" + ex.getMessage(), "", "UnitVal");
		}
		return res;
	}

	public static UnitVal add(List<UnitVal> adds) throws Exception {// (same unit)
		// origin - 15.02.2025, last edit - 13.06.2025
		UnitVal res = new UnitVal();
		double res1 = 0.0;
		try {
			UnitVal tmp = new UnitVal();
			String currToCode = "";
			for (var curr : adds) {
				currToCode = curr.unit.code;
				tmp = UnitVal.conv(curr, currToCode, "");
				// res1 = res1 + tmp.val;
				res1 = Etc.add(res1, tmp.val);
			}
			res = new UnitVal(res1, currToCode);
		} catch (Exception ex) {
			WB.addLog("UnitVal.add (List<UnitVal> adds):UnitVal, ex=" + ex.getMessage(), "", "UnitVal");
		}
		return res;
	}

	public static UnitVal add(List<UnitVal> adds, String toUnit) throws Exception {
		// origin - 14.02.2025, last edit - 13.06.2025
		UnitVal res = new UnitVal();
		double res1 = 0.0;
		try {
			UnitVal tmp = new UnitVal();
			for (var curr : adds) {
				tmp = UnitVal.conv(curr, toUnit, "");
				// res1 = res1 + tmp.val;
				res1 = Etc.add(res1, tmp.val);
			}
			res = new UnitVal(res1, toUnit);
		} catch (Exception ex) {
			WB.addLog("UnitVal.add (List<UnitVal> adds, String toUnit):UnitVal, ex=" + ex.getMessage(), "", "UnitVal");
		}
		return res;
	}

//	@SuppressWarnings("unused")
//	private static List<UnitVal> build(String[] src) throws Exception {
//		// origin - 14.02.2025, last edit - 17.06.2025
//		List<UnitVal> res = new ArrayList<UnitVal>();
//		try {
//			for (var curr : src) {
//				res.add(new UnitVal(curr));
//			}
//		} catch (Exception ex) {
//			WB.addLog("UnitVal.build(String[] src):List<UnitVal>, ex=" + ex.getMessage(), "", "UnitVal");
//		}
//		return res;
//	}

	public static UnitVal conv(UnitVal fromUnitVal, String toUnit, String context) throws Exception {
		// origin - 29.01.2025, last edit - 13.06.2025
		UnitVal res = new UnitVal();
		try {
			UnitVal conv = Unit.сonv(fromUnitVal.unit.code, toUnit, context);
			// res = new UnitVal(conv.val * fromUnitVal.val, conv.unit.code);
			res = new UnitVal(Etc.multiply(conv.val, fromUnitVal.val), conv.unit.code);
		} catch (Exception ex) {
			WB.addLog("UnitVal.conv(UnitVal fromUnitVal, String toUnit, String context):UnitVal, ex=" + ex.getMessage(),
					"", "UnitVal");
		}
		return res;
	}

	private void getId() throws Exception {
		// origin - 01.12.2024, last edit - 13.06.2025
		try {
			if (val != 0.0) {
				this.id = this.id + this.partName + " " + String.valueOf(val);
			}

			if ((val == 0.0) & (partVal.isEmpty() == false)) {
				this.id = this.id + this.partName + " " + partVal;
			}

			if (this.partUnit.isEmpty() == false) {
				this.id = this.id + " " + this.unit.code + ", " + this.unit.description;
			}

			if (this.partUnit.isEmpty() && this.partVal.isEmpty()) {
				this.id = "";
			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.getId():void, ex=" + ex.getMessage(), "", "UnitVal");
		}
	}

	private void getPart() throws Exception {
		// origin - 14.09.2024, last edit - 17.06.2025
		try {
//			WB.addLog2("UnitVal.getPart, ModelVal.isType(this.src)=" + ModelVal.isType(this.src) + ", this.src="
//					+ this.src, "", "UnitVal");
			String tmp = this.src;
			int posMiddleEquation = tmp.indexOf("="); // pos "="
			if (posMiddleEquation > 0) {
				this.partName = Etc.fixTrim(tmp.substring(0, posMiddleEquation));
//					WB.addLog2("UnitVal.getPart, this.partName=" + this.partName + ", this.src=" + this.src,"", "UnitVal");
				tmp = Etc.delStr(tmp, this.partName);
				tmp = Etc.delStr(tmp, "=");
			}

			int posLocalSplitValUnit = tmp.indexOf("(Unit.");
			if (posLocalSplitValUnit > 0) {
				this.partVal = Etc.fixTrim(tmp.substring(0, posLocalSplitValUnit));
				this.partUnit = Etc.fixTrim(tmp.substring(posLocalSplitValUnit));
				this.partUnit = Etc.delStr(this.partUnit, UnitVal.listDelStr);
			}

			if (this.partUnit.isEmpty()) {
				this.partVal = Etc.fixTrim(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.getPart():void, ex=" + ex.getMessage(), "", "UnitVal");
		}
	}

	public void getUnit() throws Exception {
		// origin - 02.06.2025, last edit - 13.06.2025
		try {
			if (this.partUnit.isEmpty() == false) {
				this.unit = new Unit(this.partUnit);
				this.context = this.unit.expectedValue;
			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.getUnit():void, ex=" + ex.getMessage(), "", "UnitVal");
		}
	}

	private void getVal() throws Exception {
		// origin - 13.09.2024, last edit - 13.06.2025
		try {
			this.getUnit();
			if (Etc.strEquals(partVal, "?") == false) {// if "?" then not written double
//				if ((this.partVal.endsWith(".0")) || (Etc.strContains(this.context, "ExpectedDouble"))) {
				this.val = Conv.getDouble(this.partVal);
//				}
			}
		} catch (Exception ex) {
			WB.addLog("UnitVal.getVal():void, ex=" + ex.getMessage(), "", "UnitVal");
		}
	}

	public UnitVal(double Val, String Unit) throws Exception {
		// origin - 16.01.2025, last edit - 20.03.2025
		this();
		// clean, because may be alone chars "(" and\or ")" //??
		Unit = Etc.delStr(Unit, "(");
		Unit = Etc.delStr(Unit, ")");
		this.src = Etc.fixTrim(String.valueOf(Val)) + "(" + Unit + ")";
		this.getPart();
		this.getVal();
		this.getId();
	}

	public UnitVal(String Val, String Unit) throws Exception {
		// origin - 18.09.2024, last edit - 20.03.2025
		this();
		// clean, because may be alone chars "(" and\or ")" //??
		Unit = Etc.delStr(Unit, "(");
		Unit = Etc.delStr(Unit, ")");
		this.src = Etc.fixTrim(String.valueOf(Val)) + "(" + Unit + ")";
		this.getPart();
		this.getVal();
		this.getId();
	}

	public UnitVal(String Src) throws Exception {
		// origin - 13.09.2024, last edit - 01.12.2024
		this();
		this.src = Etc.fixTrim(Src);
		this.getPart();
		this.getVal();
		this.getId();
	}

	public UnitVal() throws Exception {
		// origin - 13.09.2024, last edit - 02.06.2025
		this.clear();
	}

	public void clear() throws Exception {
		// origin - 02.06.2025, last edit - 13.06.2025
		try {
			this.id = this.context = this.src = this.partName = this.name = this.partUnit = "";
			this.partVal = "";
			this.val = 0.0;
			this.unit = null;
		} catch (Exception ex) {
			WB.addLog("UnitVal.clear():void, ex=" + ex.getMessage(), "", "UnitVal");
		}
	}

	public String toString() {
		// origin - 13.09.2024, last edit - 21.03.2025
		String res = "";
		try {
			res = this.id + " " + ", src " + this.src + ", context " + this.context;
		} catch (Exception ex) {
		}
		return res;
	}

	public static String correctForDouble(String initValue) throws Exception {
		// origin - 14.09.2024, last edit - 15.06.2025
		String res = Etc.fixTrim(initValue);
		try {
			// test on UnitVal
			UnitVal testUnitVal = new UnitVal(initValue);
			res = testUnitVal.partVal;

//				// clean, because may be alone chars "(" and\or ")" //??
//				res = Etc.delStr(res, UnitVal.strLeftSplit);
//				res = Etc.delStr(res, UnitVal.strRightSplit);
		} catch (Exception ex) {
			WB.addLog("UnitVal.correctForDouble(String initValue):String, ex=" + ex.getMessage(), "", "UnitVal");
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 13.09.2024, last edit - 13.06.2025
		try {

//			// multiply (toUnit)
//			var multiplyToUnitArg0 = new String[] { "6.2(Unit.Mcm)", "5.3(Unit.Mm)", "7.9(Unit.Meter)" };
//			var multiplyToUnitArg1 = UnitVal.build(multiplyToUnitArg0);
//			for (var multiplyArg2 : new String[] { "Unit.Mcm", "Unit.Mm", "Unit.Cm", "Unit.Meter" }) {
//				WB.addLog2("UnitVal.test.multiply (toUnit), res="
//						+ UnitVal.multiply(multiplyToUnitArg1, multiplyArg2).id + ", multipliers="
//						+ Fmtr.listVal(multiplyToUnitArg0, "") + ", toUnit=" + multiplyArg2, "","UnitVal");
//			}

//			// multiply (same unit)
//			var multiplySameUnitArg0 = new String[] { "3.0(Unit.Mm)", "6.0(Unit.Mm)", "5.0(Unit.Mm)", "4.2(Unit.Mm)",
//					"7.999(Unit.Mm)" };
//			var multiplySameUnitArg1 = UnitVal.build(multiplySameUnitArg0);
//			WB.addLog2(
//					"UnitVal.test.multiply (same unit), res=" + UnitVal.multiply(multiplySameUnitArg1).id
//							+ ", multipliers=" + Fmtr.listVal(multiplySameUnitArg0, ""),"", "UnitVal");

//			// add (n time)
//			var adds = 1.99;
//			for (var addArg1 : new int[] { 10, 100, 1000, 10000, 100000, 1000000 }) {
//				var tmp = 0.0;
//				for (int i = 0; i < addArg1; i++) {
//					// tmp = tmp + adds; //its wrong
//					tmp = Etc.add(tmp, adds);
//				}
//				WB.addLog2("UnitVal.test.add (n time), res=" + new UnitVal(tmp, "(Unit.Mm)").id + ", adds=" + adds
//						+ ", time=" + addArg1, "", "UnitVal");
//			}

//			// add (same unit)
//			var addSameUnitArg0 = new String[] { "3.0(Unit.Mm)", "6.0(Unit.Mm)", "5.0(Unit.Mm)", "4.2(Unit.Mm)",
//					"7.999(Unit.Mm)" };
//			var addSameUnitArg1 = UnitVal.build(addSameUnitArg0);
//			WB.addLog2("UnitVal.test.add (same unit), res=" + UnitVal.add(addSameUnitArg1).id + ", adds="
//					+ Fmtr.listVal(addSameUnitArg0, ""), "", "UnitVal");

//			// add (toUnit)
//			var addToUnitArg0 = new String[] { "6.0(Unit.Mcm)", "5.0(Unit.Mm)", "4.2(Unit.Cm)", "7.9(Unit.Meter)" };
//			var addToUnitArg1 = UnitVal.build(addToUnitArg0);
//			for (var addArg2 : new String[] { "Unit.Mcm", "Unit.Mm", "Unit.Cm", "Unit.Meter" }) {
//				WB.addLog2(
//						"UnitVal.test.add (toUnit), res=" + UnitVal.add(addToUnitArg1, addArg2).id + ", adds="
//								+ Fmtr.listVal(addToUnitArg0, "") + ", toUnit=" + addArg2,"", "UnitVal");
//			}

//			// сonv
//			for (var сonvArg1 : new String[] { "3.0(Unit.Box)", "6.0(Unit.Mcm)", "5.0(Unit.Mm)", "4.2(Unit.Cm)",
//					"7.9(Unit.Meter)" }) {
//				for (var сonvArg2 : new String[] { "Unit.Mcm", "Unit.Mm", "Unit.Cm", "Unit.Meter" }) {
//					for (var сonvArg3 : new String[] { "" }) {// ", lenght" }) {
//						WB.addLog2("UnitVal.test.сonv, res="
//								+ UnitVal.conv(new UnitVal(сonvArg1), сonvArg2, сonvArg3).id + ", fromUnitVal="
//								+ сonvArg1 + ", toUnit=" + сonvArg2 + ", context=" + сonvArg3, "", "UnitVal");
//					}
//				}
//			}

//			// ctor(String,String)
//			for (var tmp1 : new String[] { "0.293", "0.0" }) {
//				for (var tmp2 : new String[] { "(Unit.Percent)", "Unit.WorkHour" }) {
//					WB.addLog2("UnitVal.test.ctor(String,String)=" + new UnitVal(tmp1, tmp2), "", "UnitVal");
//				}
//			}

//			// ctor(String)
//			for (var tmp : new String[] { "0.293(Unit.tralala)", "AmountDeal = 12000.0(Unit.KZT)",
//					"0.293(Unit.Percent)", "(Unit.Percent)"}) {
//				WB.addLog2("UnitVal.test.ctor(String)=" + new UnitVal(tmp), "", "UnitVal");
//			}

//			// getDouble (from string with UnitVal)
//			for (String testArg1 : new String[] { "17420(Unit.Percent)", "17 420 (Unit.KZT)", "17420.0 (45 678)" }) {
//				WB.addLog2("UnitVal.test.Conv.getDouble (from string with UnitVal), res=" + Conv.getDouble(testArg1)
//						+ ", before correct testArg1=" + testArg1, "", "UnitVal");
//				testArg1 = UnitVal.correctForDouble(testArg1);
//				WB.addLog2("UnitVal.test.Conv.getDouble (from string with UnitVal), res=" + Conv.getDouble(testArg1)
//						+ ", testArg1 (after correct) =" + testArg1, "", "UnitVal");
//			}

		} catch (Exception ex) {
			WB.addLog("UnitVal.test():void, ex=" + ex.getMessage(), "", "UnitVal");
		}
	}
}