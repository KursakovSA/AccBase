import java.util.ArrayList;
import java.util.List;

public final class MoreVal {
	// origin - 05.10.2024, last edit - 12.10.2025
	public static boolean isRequiredFill(String initVal) throws Exception {
		// origin - 19.06.2024, last edit - 13.06.2025
		boolean res = false;
		try {
			initVal = Etc.fixTrim(initVal);
			if (initVal.endsWith("=?")) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("MoreVal.isRequiredFill(String):boolean, ex=" + ex.getMessage(), "", "MoreVal");
		}
		return res;
	}

	public static List<String> getList(String more) throws Exception {
		// origin - 15.04.2026, last edit - 15.04.2026
		List<String> res = new ArrayList<String>();
		try {
			res = List.of(more.split(";"));
		} catch (Exception ex) {
			WB.addLog("MoreVal.getList(String):List<String>, ex=" + ex.getMessage(), "", "MoreVal");
		}
		return res;
	}

	public static String setPartMore(String titlePartMore, String valPartMore) throws Exception {
		// origin - 18.05.2025, last edit - 13.06.2025
		String res = "";
		try {
			valPartMore = Etc.fixTrim(valPartMore);
			if (valPartMore.isEmpty() == false) {
				res = titlePartMore + "=" + valPartMore + ";";
			}
		} catch (Exception ex) {
			WB.addLog("MoreVal.setMore(2String):String, ex=" + ex.getMessage(), "", "MoreVal");
		}
		return res;
	}

	public static String getFromEquation(String[] equation, String key) throws Exception {
		// origin - 16.06.2024, last edit - 13.06.2025
		String res = "";
		try {
			int indexSignEquals = 0;
			String strKey = "";
			String splitEquation = "=";
			for (var currEquation : equation) {
				indexSignEquals = 0;
				indexSignEquals = currEquation.lastIndexOf(splitEquation);
				if (indexSignEquals > 0) {
					strKey = "";
					strKey = currEquation.substring(0, indexSignEquals);
					strKey = Etc.fixTrim(strKey);
					if ((strKey.isEmpty() == false) && (Etc.strEquals(key, strKey))) {
						res = currEquation.substring(indexSignEquals + 1, currEquation.length());
						res = Etc.fixTrim(res);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("MoreVal.getFromEquation(String[], String):String, ex=" + ex.getMessage(), "", "MoreVal");
		}
		return res;
	}

	public static String getByKey(List<FullDto> dto, String key, String code) throws Exception {
		// origin - 17.06.2024, last edit - 13.06.2025
		// ex. call --- somestring =
		// MoreVal.getByKey(WB.abcLast.infoBaseId, "infoBaseId", "Face.FA1");
		String res = "";
		try {
			String[] items = {};
			String splitValueInMore = ";";
			for (var currDto : dto) {

				// filter by code (optional)
				if ((code.isEmpty() == false) && // code may be empty
						(Etc.strEquals(currDto.code, code) == false)) {
					continue;
				}

				// items = Etc.getArrayFromStrSplit(currDto.more, splitValueInMore); // if value
				// are diffferent in list ???
				items = currDto.more.split(splitValueInMore); // if value are diffferent in list ???
				res = MoreVal.getFromEquation(items, key);
			}
		} catch (Exception ex) {
			WB.addLog("MoreVal.getByKey(List<FullDto>, 2String):String, ex=" + ex.getMessage(), "", "MoreVal");
		}
		return res;
	}

	public static String getFieldByKey(String initMore, String key) throws Exception {
		// origin - 08.10.2024, last edit - 13.06.2025
		String res = "";
		initMore = Etc.fixTrim(initMore);
		try {
			String[] items = initMore.split(";"); // if value are diffferent in list ???
			res = MoreVal.getFromEquation(items, key);
		} catch (Exception ex) {
			WB.addLog("MoreVal.getFieldByKey(2String):String, ex=" + ex.getMessage() + ", res=" + res, "", "MoreVal");
		}
		return res;
	}

	public static String lastEdit(String initRes) throws Exception {
		// origin - 25.06.2024, last edit - 13.06.2025
		String res = Etc.fixTrim(initRes);
		try {
			res = MoreVal.delFieldByKey(res, "LastEdit");
			res = res + "LastEdit=" + DateTool.formatter2(DateTool.getNow2()) + ";";
		} catch (Exception ex) {
			WB.addLog("MoreVal.lastEdit(String):String, ex=" + ex.getMessage() + ", res=" + res, "", "MoreVal");
		}
		return res;
	}

	public static String delFieldByKey(String initMore, String delField) throws Exception {
		// origin - 25.06.2024, last edit - 13.06.2025
		String res = "";
		initMore = Etc.fixTrim(initMore);
		try {
			String[] items = {};
			// items = Etc.getArrayFromStrSplit(initMore, ";"); // if value are
			// diffferent in list ???
			items = initMore.split(";"); // if value are diffferent in list ???
			for (var item : items) {
				if (Etc.strContains(item, delField)) {// skip deleting field //?? delField + equation = ??
					continue;
				}
				res = res + item;
			}
		} catch (Exception ex) {
			WB.addLog("MoreVal.delFieldByKey(2String):String, ex=" + ex.getMessage() + ", res=" + res, "", "MoreVal");
		}
		return res;
	}

	private MoreVal() throws Exception {
		// origin - 05.10.2024, last edit - 18.06.2025
	}

	public String toString() {
		// origin - 14.11.2024, last edit - 18.06.2025
		String res = "";
		try {
			// res = Formatter.listIter(this.val, "MoreVal");
			// res = this.id;
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 05.10.2024, last edit - 18.06.2025
		try {

//			// isRequiredFill
//			for (String testArg1 : new String[] { "KZ?", "IBAN=?", "Description=;", "?Surname=;" }) {
//				WB.addLog2("MoreVal.test.isRequiredFill, res=" + isRequiredFill(testArg1) + ", testArg1=" + testArg1,"", "MoreVal");
//			}

//			// getFieldByKey(initMore, key)
//			// String initMore =
//			// "AbcBasic=Meter.Basic;AbcExpectedValue=Meter.ExpectedDouble;";
//			// String key = "AbcExpectedValue";
//			String initMore = "EmpId=001;AbcBasic=Face.Basic;Comment=;FullName=;Salary=220000.0:245000.0:;";
//			String key = "Salary";
//			WB.addLog2(
//					"MoreVal.test.getFieldByKey, res=" + MoreVal.getFieldByKey(initMore, key) + ", initMore="
//							+ initMore.replaceAll(";", ",") + ", key=" + key,"", "MoreVal");

		} catch (Exception ex) {
			WB.addLog("MoreVal.test():void, ex=" + ex.getMessage(), "", "MoreVal");
		}
	}
}