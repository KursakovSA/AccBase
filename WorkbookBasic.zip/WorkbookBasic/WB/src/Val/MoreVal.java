import java.util.ArrayList;
import java.util.List;

public final class MoreVal {
	// origin - 05.10.2024, last edit - 14.09.2026

	private static String getValueByPart(String partMore) throws Exception {
		// origin - 12.09.2026, last edit - 14.09.2026
		String res = "";
		try {
			var tmp1 = MoreVal.cleanPart(partMore);

			if (Etc.strContains(tmp1, "=") == false) {
				return res;
			}

			if (Etc.strContains(tmp1, "=")) {
				int index1 = tmp1.indexOf("=");
				int indexLast = tmp1.lastIndexOf("=");
				if (index1 != indexLast) {
					return res;
				}
				if (index1 != -1) {
					String tmp2 = tmp1.substring(index1 + 1);
					res = Etc.fixTrim(tmp2);
				}
			}
		} catch (Exception ex) {
			WB.addLog("MoreVal.getValueByPart(String):String, ex=" + ex.getMessage(), "", "MoreVal");
		}
		return res;
	}

	private static String getNameByPart(String partMore) throws Exception {
		// origin - 12.09.2026, last edit - 14.09.2026
		String res = "";
		try {
			var tmp1 = MoreVal.cleanPart(partMore);

			if (Etc.strContains(tmp1, "=") == false) {
				return res;
			}

			if (Etc.strContains(tmp1, "=")) {
				int index1 = tmp1.indexOf("=");
				int indexLast = tmp1.lastIndexOf("=");
				if (index1 != indexLast) {
					return res;
				}
				if (index1 != -1) {
					String tmp2 = tmp1.substring(0, index1);
					res = Etc.fixTrim(tmp2);
				}
			}
		} catch (Exception ex) {
			WB.addLog("MoreVal.getNameByPart(String):String, ex=" + ex.getMessage(), "", "MoreVal");
		}
		return res;
	}

	public static List<String> cleanPartList(List<String> partList) throws Exception {
		// origin - 14.09.2026, last edit - 14.09.2026
		List<String> res = new ArrayList<String>();
		try {
			for (var curr : partList) {
				res.add(MoreVal.cleanPart(curr));
			}
		} catch (Exception ex) {
			WB.addLog("MoreVal.cleanPartList(String):List<String>, ex=" + ex.getMessage(), "", "MoreVal");
		}
		return res;
	}

	private static String cleanPart(String part) throws Exception {
		// origin - 13.09.2026, last edit - 13.09.2026
		String res = "";
		try {
			String tmp = Etc.fixTrim(part);
			tmp = Etc.delTailPlaceholder(tmp, ";");
			tmp = Etc.delLeaderPlaceholder(tmp, ";");
			tmp = Etc.delTailPlaceholder(tmp, "=");
			tmp = Etc.delLeaderPlaceholder(tmp, "=");
			res = tmp;
		} catch (Exception ex) {
			WB.addLog("MoreVal.cleanPart(String):String, ex=" + ex.getMessage(), "", "MoreVal");
		}
		return res;
	}

	public static String reset(String startMore, String namePartMore, String valPartMore) throws Exception {
		// origin - 12.09.2026, last edit - 16.09.2026
		String res = "";
		try {
			startMore = Etc.fixTrim(startMore);
			namePartMore = MoreVal.cleanPart(namePartMore);
			valPartMore = MoreVal.cleanPart(valPartMore);
			var newPartMore = MoreVal.setPart(namePartMore, valPartMore);

			if ((startMore.isEmpty()) & (newPartMore.isEmpty() == false)) {
				return res = MoreVal.setPart(namePartMore, valPartMore);
			}

			List<String> tmp1 = Fmtr.getListStrBySplit(startMore, ";");
			String tmp2 = "";
			boolean matchThisNamePartMore = false;
			for (var curr : tmp1) {
				if (curr.startsWith(namePartMore) == false) {
					tmp2 = tmp2 + curr + ";";
					continue;
				}

				if (curr.startsWith(namePartMore)) {
					matchThisNamePartMore = true;
					tmp2 = tmp2 + newPartMore;
					continue;
				}
			}

			if (matchThisNamePartMore == false) {
				tmp2 = tmp2 + newPartMore;
			}

			res = tmp2;
		} catch (Exception ex) {
			WB.addLog("MoreVal.reset(3String):String, ex=" + ex.getMessage(), "", "MoreVal");
		}
		return res;
	}

	public static String set(String startMore, String newMore) throws Exception {
		// origin - 15.09.2026, last edit - 15.09.2026
		String res = "";
		try {
			res = MoreVal.reset(startMore, newMore);
		} catch (Exception ex) {
			WB.addLog("MoreVal.set(2String):String, ex=" + ex.getMessage(), "", "MoreVal");
		}
		return res;
	}

	public static String resetPart(String startMore, String newPartMore) throws Exception {
		// origin - 15.09.2026, last edit - 15.09.2026
		String res = "";
		try {
			res = MoreVal.reset(startMore, newPartMore);
		} catch (Exception ex) {
			WB.addLog("MoreVal.resetPart(2String):String, ex=" + ex.getMessage(), "", "MoreVal");
		}
		return res;
	}

	public static String reset(String startMore, String newPartMore) throws Exception {
		// origin - 12.09.2026, last edit - 15.09.2026
		String res = "";
		try {
			startMore = Etc.fixTrim(startMore);
			if (startMore.isEmpty()) {
				return res = Etc.fixTrim(newPartMore);
			}

			if (newPartMore.isEmpty()) {
				return res = startMore;
			}

			var tmp1 = Fmtr.getListStrBySplit(newPartMore, ";");
			String tmp2 = startMore;
			String namePartMore = "";
			String valPartMore = "";
			for (var curr : tmp1) { // newPartMore may be list items or one item
				namePartMore = "";
				valPartMore = "";
				namePartMore = MoreVal.getNameByPart(curr);
				valPartMore = MoreVal.getValueByPart(curr);
				tmp2 = MoreVal.reset(tmp2, namePartMore, valPartMore);
			}

			// var namePartMore = MoreVal.getNameByPart(newPartMore);
			// var valPartMore = MoreVal.getValueByPart(newPartMore);
			// res = MoreVal.resetPart(startMore, namePartMore, valPartMore);
			res = tmp2;
		} catch (Exception ex) {
			WB.addLog("MoreVal.reset(2String):String, ex=" + ex.getMessage(), "", "MoreVal");
		}
		return res;
	}

	public static String setPart(String namePartMore, String valPartMore) throws Exception {
		// origin - 18.05.2025, last edit - 14.09.2026
		String res = "";
		try {
			namePartMore = MoreVal.cleanPart(namePartMore);
			valPartMore = MoreVal.cleanPart(valPartMore);

			if (valPartMore.isEmpty() == false) {
				res = namePartMore + "=" + valPartMore;
				if (res.endsWith(";") == false) {
					res = res + ";";
				}
			}
		} catch (Exception ex) {
			WB.addLog("MoreVal.setPart(2String):String, ex=" + ex.getMessage(), "", "MoreVal");
		}
		return res;
	}

	public static String getByEquation(String[] equation, String key) throws Exception {
		// origin - 16.06.2024, last edit - 12.09.2026
		String res = "";
		try {
			int indexSignEquals = 0;
			String strKey = "";
			String splitEquation = "=";
			for (var currEquation : equation) {
				indexSignEquals = 0;
				indexSignEquals = currEquation.lastIndexOf(splitEquation);
				if (indexSignEquals > 0) {
					strKey = "";
					strKey = currEquation.substring(0, indexSignEquals);
					strKey = Etc.fixTrim(strKey);
					if ((strKey.isEmpty() == false) && (Etc.strEquals(key, strKey))) {
						res = currEquation.substring(indexSignEquals + 1, currEquation.length());
						res = Etc.fixTrim(res);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("MoreVal.getByEquation(String[], String):String, ex=" + ex.getMessage(), "", "MoreVal");
		}
		return res;
	}

	public static String getByKey(List<FullDto> dto, String key, String code) throws Exception {
		// origin - 17.06.2024, last edit - 12.09.2026
		// ex. call --- somestring =
		// MoreVal.getByKey(WB.abcLast.infoBaseId, "infoBaseId", "Face.FA1");
		String res = "";
		try {
			String[] items = {};
			String splitValueInMore = ";";
			for (var currDto : dto) {

				// filter by code (optional)
				if ((code.isEmpty() == false) && // code may be empty
						(Etc.strEquals(currDto.code, code) == false)) {
					continue;
				}

				// items = Etc.getArrayFromStrSplit(currDto.more, splitValueInMore); // if value
				// are diffferent in list ???
				items = currDto.more.split(splitValueInMore); // if value are diffferent in list ???
				res = MoreVal.getByEquation(items, key);
			}
		} catch (Exception ex) {
			WB.addLog("MoreVal.getByKey(List<FullDto>, 2String):String, ex=" + ex.getMessage(), "", "MoreVal");
		}
		return res;
	}

	public static String getFieldByKey(String initMore, String key) throws Exception {
		// origin - 08.10.2024, last edit - 12.09.2026
		String res = "";
		initMore = Etc.fixTrim(initMore);
		try {
			String[] items = initMore.split(";"); // if value are diffferent in list ???
			res = MoreVal.getByEquation(items, key);
		} catch (Exception ex) {
			WB.addLog("MoreVal.getFieldByKey(2String):String, ex=" + ex.getMessage() + ", res=" + res, "", "MoreVal");
		}
		return res;
	}

	public static boolean isRequiredFill(String initVal) throws Exception {
		// origin - 19.06.2024, last edit - 13.09.2026
		boolean res = false;
		try {
			initVal = Etc.fixTrim(initVal);
			if ((initVal.endsWith("=?")) && (initVal.endsWith("=?;"))) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("MoreVal.isRequiredFill(String):boolean, ex=" + ex.getMessage(), "", "MoreVal");
		}
		return res;
	}

	private MoreVal() throws Exception {
		// origin - 05.10.2024, last edit - 18.06.2025
	}

	public static void test() throws Exception {
		// origin - 05.10.2024, last edit - 15.09.2026
		try {
//
//			WB.addLog2("MoreVal.test.getValueByPart(String)", "", "MoreVal");
//			for (var tmp1 : new String[] { "", "FullName=килограмм;", "Weight=1000.00(Unit.Gr);MKEI=166;",
//					"FullName=100 грамм;;", "MKEI=8;Lenght=1000.00(Unit.Meter);", ";;Volume=1000.00(Unit.Ml)",
//					";FullName=миллиметр;" }) {
//				WB.addLog2(
//						"MoreVal.test.getValueByPart(String), res=" + MoreVal.getValueByPart(tmp1) + ", tmp1=" + tmp1,
//						"", "MoreVal");
//			}

//			WB.addLog2("MoreVal.test.getNameByPart(String)", "", "MoreVal");
//			for (var tmp1 : new String[] { "", "FullName=килограмм;", "Weight=1000.00(Unit.Gr);MKEI=166;",
//					"FullName=100 грамм;;", "MKEI=8;Lenght=1000.00(Unit.Meter);", ";;Volume=1000.00(Unit.Ml)",
//					";FullName=миллиметр;" }) {
//				WB.addLog2("MoreVal.test.getNameByPart(String), res=" + MoreVal.getNameByPart(tmp1) + ", tmp1=" + tmp1,
//						"", "MoreVal");
//			}

//			WB.addLog2("MoreVal.test.resetPart(2String)", "", "MoreVal");
//			for (var tmp1 : new String[] { "", "FullName=килограмм;", "Weight=1000.00(Unit.Gr);MKEI=166;",
//					"FullName=100 грамм;Weight=0.10(Unit.Kg);", "MKEI=8;Lenght=1000.00(Unit.Meter);",
//					"FullName=литр;Volume=1000.00(Unit.Ml);",
//					"FullName=метр;Lenght=100.00(Unit.Cm);Width=100.00(Unit.Cm);Height=100.00(Unit.Cm);",
//					"FullName=миллиметр;Lenght=1000.00(Unit.Mcm);" }) {
//				for (var tmp2 : new String[] { "", "FullName=килограмм;", "Weight=1000.00(Unit.Gr);",
//						"FullName=100 грамм;", "MKEI=8;Lenght=1000.00(Unit.Meter);", "FullName=литр;", "FullName=метр;",
//						"FullName=миллиметр;" }) {
//					WB.addLog2("MoreVal.test.resetPart(2String), res " + MoreVal.reset(tmp1, tmp2) + ", tmp1 " + tmp1
//							+ ", tmp2 " + tmp2, "", "MoreVal");
//				}
//			}

//			WB.addLog2("MoreVal.test.resetPart(3String)", "", "MoreVal");
//			for (var tmp1 : new String[] { "", "FullName=килограмм;", "Weight=1000.00(Unit.Gr);MKEI=166;",
//					"FullName=100 грамм;Weight=0.10(Unit.Kg);", "MKEI=8;Lenght=1000.00(Unit.Meter);",
//					"FullName=литр;Volume=1000.00(Unit.Ml);",
//					"FullName=метр;Lenght=100.00(Unit.Cm);Width=100.00(Unit.Cm);Height=100.00(Unit.Cm);",
//					"FullName=миллиметр;Lenght=1000.00(Unit.Mcm);" }) {
//				for (var tmp2 : new String[] { "", "FullName=килограмм;", "Weight=1000.00(Unit.Gr);",
//						"FullName=100 грамм;", "MKEI=8;Lenght=1000.00(Unit.Meter);", "FullName=литр;", "FullName=метр;",
//						"FullName=миллиметр;" }) {
//					var tmp3 = MoreVal.getNameByPart(tmp2);
//					var tmp4 = MoreVal.getValueByPart(tmp2);
//					WB.addLog2("MoreVal.test.resetPart(3String), res " + MoreVal.reset(tmp1, tmp3, tmp4) + ", tmp1 "
//							+ tmp1 + ", tmp3 " + tmp3 + ", tmp4 " + tmp4, "", "MoreVal");
//				}
//			}

//			WB.addLog2("MoreVal.test.cleanPart(String)", "", "MoreVal");
//			for (var tmp1 : new String[] { "", "FullName", "FullName=", "=FullName=", "==FullName=", "==FullName==",
//					"166;", "166;;", ";166;", ";;166;;", "FullName=100 грамм", "FullName=100 грамм;" }) {
//				WB.addLog2("MoreVal.test.cleanPart(String), res " + MoreVal.cleanPart(tmp1) + ", tmp1 " + tmp1, "",
//						"MoreVal");
//			}

//			// isRequiredFill
//			for (String testArg1 : new String[] { "KZ?", "IBAN=?", "Description=;", "?Surname=;" }) {
//				WB.addLog2("MoreVal.test.isRequiredFill, res=" + isRequiredFill(testArg1) + ", testArg1=" + testArg1,"", "MoreVal");
//			}

			// getFieldByKey(initMore, key)
			// String initMore =
			// "AbcBasic=Meter.Basic;AbcExpectedValue=Meter.ExpectedDouble;";
			// String key = "AbcExpectedValue";
			String initMore = "EmpId=001;AbcBasic=Face.Basic;Comment=;FullName=;Salary=220000.0:245000.0:;";
			String key = "Salary";
			WB.addLog2(
					"MoreVal.test.getFieldByKey, res=" + MoreVal.getFieldByKey(initMore, key) + ", initMore="
							+ initMore + ", key=" + key,"", "MoreVal");

		} catch (Exception ex) {
			WB.addLog("MoreVal.test():void, ex=" + ex.getMessage(), "", "MoreVal");
		}
	}
}