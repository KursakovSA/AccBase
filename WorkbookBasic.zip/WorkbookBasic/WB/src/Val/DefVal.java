import java.time.LocalDate;
import java.util.TreeSet;

public final class DefVal {
	// origin - 23.08.2024, last edit - 12.10.2025
	static {
		try {
		} catch (Exception ex) {
			WB.addLog("DefVal.static ctor, ex=" + ex.getMessage(), "", "DefVal");
		}
	}

	public static ListVal setCustom(ListVal listVal, ListVal customListVal) throws Exception {
		// origin - 16.03.2025, last edit - 13.06.2025
		ListVal res = listVal;
		try {
			if ((listVal.val.size() == 0) && (customListVal.val.size() != 0)) {
				res = customListVal;
			}
		} catch (Exception ex) {
			WB.addLog("DefVal.setCustomVal(2ListVal):ListVal, ex=" + ex.getMessage(), "", "DefVal");
		}
		return res;
	}

	public static int setCustom(int val, int customVal) throws Exception {
		// origin - 31.08.2024, last edit - 13.06.2025
		int res = val;
		try {
			if (customVal != 0) {
				res = customVal;
			}
		} catch (Exception ex) {
			WB.addLog("DefVal.setCustom(2int):int, ex=" + ex.getMessage(), "", "DefVal");
		}
		return res;
	}

	public static String setIf(String preRes, String val, String customVal) throws Exception {
		// origin - 01.05.2026, last edit - 01.05.2026
		String res = preRes;
		try {
			if (Etc.strEquals(preRes, val)) {
				res = customVal;
			}
		} catch (Exception ex) {
			WB.addLog("DefVal.setIf(3String):String, ex=" + ex.getMessage(), "", "DefVal");
		}
		return res;
	}

	public static String setCustom(String val, String customVal) throws Exception {
		// origin - 31.08.2024, last edit - 01.05.2026
		val = Etc.fixTrim(val);
		String res = val;
		customVal = Etc.fixTrim(customVal);
		try {

			if ((val.isEmpty()) & (customVal.isEmpty() == false)) {
				res = customVal;
			}

			if ((val.isEmpty() == false) & (customVal.isEmpty())) {
				res = val;
			}

			if ((val.isEmpty() == false) & (customVal.isEmpty() == false)) {
				res = customVal;
			}

		} catch (Exception ex) {
			WB.addLog("DefVal.setCustomVal(2String):String, ex=" + ex.getMessage(), "", "DefVal");
		}
		return res;
	}

	public static LocalDate set(LocalDate val, LocalDate defaultVal) throws Exception {
		// origin - 26.08.2024, last edit - 13.06.2025
		LocalDate res = val;
		try {
			if (res == null) {
				res = defaultVal;
			}
		} catch (Exception ex) {
			WB.addLog("DefVal.set(2LocalDate):LocalDate, ex=" + ex.getMessage(), "", "DefVal");
		}
		return res;
	}

	public static String set(String val, int defaultStringLenght) throws Exception {// cut off string on the right what
																					// hit to
		// norm lenght
		// origin - 26.08.2024, last edit - 13.06.2025
		String res = Etc.fixTrim(val);
		try {
			if (res.length() > defaultStringLenght) {
				res = res.substring(res.length() - defaultStringLenght);
			}
		} catch (Exception ex) {
			WB.addLog("DefVal.set(String, int):String, ex=" + ex.getMessage(), "", "DefVal");
		}
		return res;
	}

	public static TreeSet<String> set(TreeSet<String> val, TreeSet<String> defaultVal) throws Exception {
		// origin - 22.08.2024, last edit - 13.06.2025
		TreeSet<String> res = val;
		try {
			if (res.size() == 0) {// difference
				res = defaultVal;
			}
		} catch (Exception ex) {
			WB.addLog("DefVal.set(2TreeSet<String>):TreeSet<String>, ex=" + ex.getMessage(), "", "DefVal");
		}
		return res;
	}

	public static int set(int val, int defaultVal) throws Exception {
		// origin - 16.08.2024, last edit - 13.06.2025
		int res = val;
		try {
			if (res == 0) {// difference
				res = defaultVal;
			}
		} catch (Exception ex) {
			WB.addLog("DefVal.set(2int):int, ex=" + ex.getMessage(), "", "DefVal");
		}
		return res;
	}

	public static String set(String val, String defaultVal) throws Exception {
		// origin - 14.08.2024, last edit - 13.06.2025
		String res = Etc.fixTrim(val);
		try {
			if (res.isEmpty()) {// difference
				res = defaultVal;
			}
		} catch (Exception ex) {
			WB.addLog("DefVal.set(2String):String, ex=" + ex.getMessage(), "", "DefVal");
		}
		return res;
	}

	public static double set(double fixNumb) throws Exception {
		// origin - 01.10.2023, last edit - 13.06.2025
		// for tax calculate and etc where not need be negative number
		double res = (double) fixNumb;
		try {
			res = res < 0 ? 0 : res; // set 0, if < 0
		} catch (Exception ex) {
			WB.addLog("DefVal.set(double):double, ex=" + ex.getMessage(), "", "DefVal");
		}
		return res;
	}

	private DefVal() throws Exception {
		// origin - 23.08.2024, last edit - 04.11.2024
	}

	public static void test() throws Exception {
		// origin - 23.08.2024, last edit - 13.06.2025
		try {

//			// setCustom(listval, listval)
//			for (var tmp1 : new ListVal[] { new ListVal(), new ListVal("", ""),
//					new ListVal("2025-01-01:", "") }) {
//				var tmp2 = new ListVal(DateTool.formatter5(WB.maxDateSupported), "");
//				WB.addLog2("DefVal.test.setCustom(listval, listval), res=" + DefVal.setCustom(tmp1, tmp2) + ", tmp1="
//						+ tmp1.val + ", tmp2=" + tmp2.val, "", "DefVal");
//			}

//			// set(string, int)
//			for (String testArg1 : new String[] { "te", "tes", "test", "test22" }) {
//				WB.addLog2("DefVal.test.set(string, int), res=" + DefVal.set(testArg1, 3) + ", testArg1=" + testArg1
//						+ ", int=3", "", "DefVal");
//			}

		} catch (Exception ex) {
			WB.addLog("DefVal.test():void, ex=" + ex.getMessage(), "", "DefVal");
		}
	}
}