import java.util.List;

public class RangeVal {
	// origin - 01.11.2024, last edit - 17.06.2025
	public String id, context, src, partName, name, partUnit, partVal1, partVal2;
	public Unit unit;
	private static List<String> listDelStr;
	public double val1, val2;

	static {
		try {
			RangeVal.listDelStr = List.of("=", " - ", "- ", " -", "(", ")");
		} catch (Exception ex) {
			WB.addLog("RangeVal.static ctor, ex=" + ex.getMessage(), "", "RangeVal");
		}
	}

	private void getUnit() throws Exception {
		// origin - 16.06.2025, last edit - 16.06.2025
		try {
			if (this.partUnit.isEmpty() == false) {
				this.unit = new Unit(this.partUnit);
				this.context = this.unit.expectedValue;
			}
		} catch (Exception ex) {
			WB.addLog("RangeVal.getUnit():void, ex=" + ex.getMessage(), "", "RangeVal");
		}
	}

	private void getId() throws Exception {
		// origin - 05.01.2025, last edit - 13.06.2025
		try {
			this.id = this.name + " " + this.val1 + "--" + this.val2;
			if (this.partUnit.isEmpty() == false) {
				this.id = this.id + " " + this.unit.code + ", " + this.unit.description;
			}
			if (this.partVal1.isEmpty() && this.partVal2.isEmpty()) {
				this.id = "";
			}
		} catch (Exception ex) {
			WB.addLog("RangeVal.getId():void, ex=" + ex.getMessage(), "", "RangeVal");
		}
	}

	private void getVal() throws Exception {
		// origin - 08.11.2024, last edit - 16.06.2025
		try {
			this.name = this.partName;
			this.getUnit();
//			if (this.unit != null) {
//				this.val1 = Conv.get(this.partVal1, this.unit.expectedValue);
//				this.val2 = Conv.get(this.partVal2, this.unit.expectedValue);
//			} else {
//				this.val1 = Conv.get(this.partVal1, "");
//				this.val2 = Conv.get(this.partVal2, "");
//			}

			this.val1 = Conv.getDouble(this.partVal1);
			this.val2 = Conv.getDouble(this.partVal2);
		} catch (Exception ex) {
			WB.addLog("RangeVal.getVal():void, ex=" + ex.getMessage(), "", "RangeVal");
		}
	}

	private void getPart() throws Exception {
		// origin - 01.11.2024, last edit - 17.06.2025
		try {
			String tmp = this.src;

			// get partUnit
			int posLocalStrMiddleParenthesisLeft = 0;
			posLocalStrMiddleParenthesisLeft = tmp.indexOf("(Unit.");
			if (posLocalStrMiddleParenthesisLeft > 0) {
				int posLocalStrMiddleParenthesisRight = 0;
				posLocalStrMiddleParenthesisRight = tmp.indexOf(")"); // pos ")"
				if (posLocalStrMiddleParenthesisRight > 0) {
					this.partUnit = Etc.fixTrim(
							tmp.substring(posLocalStrMiddleParenthesisLeft, posLocalStrMiddleParenthesisRight));
					this.partUnit = Etc.delStr(this.partUnit, RangeVal.listDelStr);
					tmp = Etc.delStr(tmp, this.partUnit);
					tmp = Etc.delStr(tmp, "(");
					tmp = Etc.delStr(tmp, ")");
				}
			}

			// get partName
			int posLocalStrMiddleEquation = 0;
			posLocalStrMiddleEquation = tmp.indexOf("="); // pos "="
			if (posLocalStrMiddleEquation > 0) {
				this.partName = Etc.fixTrim(tmp.substring(0, posLocalStrMiddleEquation));
				this.partName = Etc.delStr(this.partName, RangeVal.listDelStr);
				// tmp = tmp.substring(posLocalStrMiddleEquation);
				tmp = Etc.delStr(tmp, this.partName);
				tmp = Etc.delStr(tmp, "=");
			}

			// get partVal1,2
			int posLocalSplit = tmp.indexOf(" - "); // pos " - "
			if (posLocalSplit > 0) {
				// this is res
				this.partVal1 = Etc.fixTrim(tmp.substring(0, posLocalSplit));
				this.partVal1 = Etc.delStr(this.partVal1, RangeVal.listDelStr);

				this.partVal2 = Etc.fixTrim(tmp.substring(posLocalSplit));
				this.partVal2 = Etc.delStr(this.partVal2, RangeVal.listDelStr);
//					WB.addLog2("RangeVal.getPart, this.partVal2=" + this.partVal2 + ", this.src=" + this.src,
//							"", "RangeVal");
			}
		} catch (Exception ex) {
			WB.addLog("RangeVal.getPart():void, ex=" + ex.getMessage(), "", "RangeVal");
		}
	}

	public RangeVal(String Src) throws Exception {
		// origin - 01.11.2024, last edit - 16.06.2025
		this.clear();
		this.src = Etc.fixTrim(Src);
		this.getPart();
		this.getVal();
		this.getId();
	}

	public RangeVal() throws Exception {
		// origin - 01.11.2024, last edit - 16.06.2025
		this.clear();
	}

	public void clear() throws Exception {
		// origin - 16.06.2025, last edit - 16.06.2025
		try {
			this.id = this.context = this.src = this.partName = this.name = this.partUnit = this.partVal1 = this.partVal2 = "";
			this.unit = null;
			this.val1 = this.val2 = 0.0;
		} catch (Exception ex) {
			WB.addLog("RangeVal.clear():void, ex=" + ex.getMessage(), "", "RangeVal");
		}
	}

	public String toString() {
		// origin - 05.01.2025, last edit - 16.06.2025
		String res = "";
		try {
			// res = this.id + " " + ", src " + this.src + ", context " + this.context;
			res = res + Fmtr.addAnyway("id ", this.id);
			res = res + Fmtr.addAnyway(" src ", this.src);
			res = res + Fmtr.addAnyway(" context ", this.context);

			res = res + Fmtr.addAnyway(" partName ", this.partName);
			res = res + Fmtr.addAnyway(" name ", this.name);
			res = res + Fmtr.addAnyway(" partUnit ", this.partUnit);
			res = res + Fmtr.addAnyway(" unit ", this.unit);
			res = res + Fmtr.addAnyway(" partVal1  ", this.partVal1);
			res = res + Fmtr.addAnyway(" val1 ", this.val1);
			res = res + Fmtr.addAnyway(" partVal2 ", this.partVal2);
			res = res + Fmtr.addAnyway(" val2 ", this.val2);
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 01.11.2024, last edit - 16.06.2025
		try {

//			// test ctor(String)
//			WB.addLog2("RangeVal.test.ctor(String)", "", "RangeVal");
//			for (var tmp : new String[] { "Price = 20.0 - 40.0 (Unit.KZT)", "120.0 - 140.0 (Unit.tralala)",
//					"WeightLogicalLimit=0.5 - 120.0(Unit.Gr)", "NetToGrossLogicalLimit=0.5 - 1.0(Unit.Ratio)",
//					"TotalPenaltyAccrualLimit=0.0 - 0.1(Unit.MainDebt)" }) {
//				WB.addLog2("RangeVal.test.ctor(String), res=" + new RangeVal(tmp), "", "RangeVal");
//			}

		} catch (Exception ex) {
			WB.addLog("RangeVal.test():void, ex=" + ex.getMessage(), "", "RangeVal");
		}
	}
}