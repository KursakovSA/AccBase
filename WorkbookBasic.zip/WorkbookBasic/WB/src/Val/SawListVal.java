import java.util.ArrayList;
import java.util.List;

public final class SawListVal {
	// origin - 13.03.2026, last edit - 13.03.2026
	public String src, context;
	private static String delimiter;
	public List<String> val;

	static {
		try {
			SawListVal.delimiter = "\\|";
		} catch (Exception ex) {
			WB.addLog("SawListVal.static ctor, ex=" + ex.getMessage(), "", "SawListVal");
		}
	}

	public String getVal(String key) throws Exception {
		// origin - 13.03.2026, last edit - 16.03.2026
		String res = "";
		try {
			for (var curr : this.val) {
				if (Etc.strContains(curr, key)) {
					var tmp = List.of(curr.split(";"));
					res = Etc.fixTrim(tmp.getLast());
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("SawListVal.getVal(String):String, ex=" + ex.getMessage(), "", "SawListVal");
		}
		return res;
	}

	public String getVal(String key, String subkey) throws Exception {
		// origin - 13.03.2026, last edit - 22.03.2026
		String res = "";
		try {
			for (var curr : this.val) {
				if (curr.isEmpty() == false) {
					if (key.isEmpty() == false) {
						if (Etc.strContains(curr, key)) {
							if (subkey.isEmpty() == false) {
								if (Etc.strContains(curr, subkey + ";")) {
									var tmp = List.of(curr.split(";"));
									res = Etc.fixTrim(tmp.getLast());
									break;
								}
							}
						}
					}
				}
			}
		} catch (

		Exception ex) {
			WB.addLog("SawListVal.getVal(2String):String, ex=" + ex.getMessage(), "", "SawListVal");
		}
		return res;
	}

	public SawListVal(String Src) throws Exception {
		// origin - 13.03.2026, last edit - 13.03.2026
		this.clear();
		this.src = Etc.fixTrim(Src);
		this.val = List.of(Src.split(SawListVal.delimiter));
	}

	public SawListVal() throws Exception {
		// origin - 13.03.2026, last edit - 13.03.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 13.03.2026, last edit - 13.03.2026
		try {
			this.src = this.context = "";
			this.val = new ArrayList<String>();
		} catch (Exception ex) {
			WB.addLog("SawListVal.clear():void, ex=" + ex.getMessage(), "", "SawListVal");
		}
	}

	public String toString() {
		// origin - 13.03.2026, last edit - 13.03.2026
		String res = "";
		try {
			// res = res + Fmtr.addAnyway(" src ", this.src);
			res = res + Fmtr.addIfNotEmpty(" context  ", this.context);
			res = res + Fmtr.addAnyway(" val.size ", this.val.size());
			// res = res + Fmtr.addAnyway(" val ", this.val);
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 13.03.2026, last edit - 22.03.2026
		try {

//			{
//				WB.addLog2("SawListVal.test.ctor(String)", "", "SawListVal");
//				var tmp1 = "001;thousand;тысяча|002;003;004;thousand;тысячи|005;006;007;008;009;thousand;тысяч";
//				var tmp2 = new SawListVal(tmp1);
//				WB.addLog2("SawListVal.test.ctor(String), res=" + tmp2, "", "SawListVal");
//				var tmp3 = "006";
//				var tmp4 = "thousand";
//				WB.addLog2("SawListVal.test.getVal(2String), res=" + tmp2.getVal(tmp3, tmp4) + ", tmp3=" + tmp3
//						+ ", tmp4=" + tmp4, "", "SawListVal");
//				WB.addLog2("SawListVal.test.getVal(String), res=" + tmp2.getVal("002") + ", 002", "", "SawListVal");
//			}

//			WB.addLog2("SawListVal.test.getVal(2String)", "", "SPL");
//			for (var tmp1 : new String[] { SPL.contextDefault, "quantity", "tralala" }) {
//				for (var tmp2 : new String[] { "1", "2", "3", "4", "13", "134", "1345", "13456" }) {
//					var tmp3 = SPL.fractionPartName;
//					WB.addLog2("SawListVal.test.getVal(2String), res="
//							+ tmp3.getVal(tmp1, String.valueOf(tmp2.length())) + ", tmp1=" + tmp1 + ", tmp2=" + tmp2,
//							"", "SPL");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("SawListVal.test():void, ex=" + ex.getMessage(), "", "SawListVal");
		}
	}
}