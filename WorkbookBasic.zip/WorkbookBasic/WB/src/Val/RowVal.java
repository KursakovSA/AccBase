import java.util.ArrayList;
import java.util.List;

public final class RowVal {
	// origin - 14.02.2026, last edit - 18.02.2026
	public String id, src, code, description, defect;
	public List<String> val;
	public static String splitterVal;

	static {
		try {
			RowVal.splitterVal = ";";
		} catch (Exception ex) {
			WB.addLog("RowVal.static ctor, ex=" + ex.getMessage(), "", "RowVal");
		}
	}

	private void validate() throws Exception { // TODO
		// origin - 17.02.2026, last edit - 17.02.2026
		try {

		} catch (Exception ex) {
			WB.addLog("RowVal.validate():void, ex=" + ex.getMessage(), "", "RowVal");
		}
	}

	public static String serialize(RowVal rowVal) throws Exception {
		// origin - 18.02.2026, last edit - 18.02.2026
		String res = "";
		try {
			var count = 0;
			for (var curr : rowVal.val) {
				count = count + 1;
				res = res + Etc.fixTrim(curr);
				if (count < rowVal.val.size()) {
					res = res + RowVal.splitterVal;
				}
			}
		} catch (Exception ex) {
			WB.addLog("RowVal.serialize(RowVal):String, ex=" + ex.getMessage(), "", "RowVal");
		}
		return res;
	}

	public String getValByIndex(int userIndex) throws Exception {
		// origin - 18.02.2026, last edit - 18.02.2026
		String res = "";
		try {
			if (userIndex != 0) { // userindex start on 1
				var innerIndex = userIndex - 1; // innnerIndex start on 0
				res = this.val.get(innerIndex);
			}
		} catch (Exception ex) {
			WB.addLog("RowVal.getValByIndex():void, ex=" + ex.getMessage(), "", "RowVal");
		}
		return res;
	}

	public List<String> getList(String in) throws Exception {
		// origin - 15.02.2026, last edit - 18.02.2026
		List<String> res = new ArrayList<String>();
		try {
			var tmp1 = Etc.delTailStr(in, RowVal.splitterVal);
			var tmp2 = List.of(tmp1.split(RowVal.splitterVal));
			res = RowVal.clean(tmp2);
		} catch (Exception ex) {
			WB.addLog("RowVal.getList(String):List<String>, ex=" + ex.getMessage(), "", "RowVal");
		}
		return res;
	}

	private static List<String> clean(List<String> in) throws Exception {
		// origin - 14.02.2026, last edit - 18.02.2026
		List<String> res = new ArrayList<String>();
		try {
			for (var curr : in) {
				res.add(Etc.fixTrim(curr));
			}
		} catch (Exception ex) {
			WB.addLog("RowVal.clean(List<String>):List<String>, ex=" + ex.getMessage(), "", "RowVal");
		}
		return res;
	}

	public RowVal(List<String> Src) throws Exception {
		// origin - 14.02.2026, last edit - 18.02.2026
		this.clear();
		this.src = Src.toString();
		var tmp = String.join(RowVal.splitterVal, Src);
		this.val = this.getList(tmp);
		this.validate();
	}

	public RowVal(String Src) throws Exception {
		// origin - 14.02.2026, last edit - 17.02.2026
		this.clear();
		this.src = Etc.fixTrim(Src);
		this.val = this.getList(this.src);
		this.validate();
	}

	public RowVal() throws Exception {
		// origin - 14.02.2026, last edit - 14.02.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 14.02.2026, last edit - 17.02.2026
		try {
			this.id = this.src = this.code = this.description = this.defect = "";
			this.val = new ArrayList<String>();
		} catch (Exception ex) {
			WB.addLog("RowVal.clear():void, ex=" + ex.getMessage(), "", "RowVal");
		}
	}

	public String toString() {
		// origin - 14.02.2026, last edit - 17.02.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("id ", this.id);
			res = res + Fmtr.addIfNotEmpty("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(" code ", this.code);
			res = res + Fmtr.addIfNotEmpty(" description ", this.description);
			res = res + Fmtr.addIfNotEmpty(" val.size ", this.val.size());
			res = res + Fmtr.addIfNotEmpty(" val ", this.val);
		} catch (Exception ex) {
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 14.02.2026, last edit - 18.02.2026
		try {

			WB.addLog2("RowVal.test.serialize(RowVal):String", "", "RowVal");
			for (var tmp1 : new String[] { "Face;Weight;Unit;1;2;", "Face;Weight;Unit ;1;2 ;", "Face;Weight;Unit;4;5",
					"Unit;1" }) {
				var tmp2 = new RowVal(tmp1);
				var tmp3 = RowVal.serialize(tmp2);
				WB.addLog2("RowVal.test.serialize(RowVal):String, res=" + tmp3 + " src=" + tmp1, "", "RowVal");
				WB.addLog2("RowVal.test.deserialize, res=" + new RowVal(tmp3), "", "RowVal");
			}

//			WB.addLog2("RowVal.test.getValByIndex(int):String", "", "RowVal");
//			for (var tmp1 : new int[] { 1, 2, 3, 4, 5 }) {
//				var tmp2 = new RowVal("Face;Weight;Unit;1;2;");
//				WB.addLog2("RowVal.test.getValByIndex(int):String, res=" + tmp2.getValByIndex(tmp1) + " src=" + tmp2.src
//						+ " userIndex=" + tmp1, "", "RowVal");
//			}

//			WB.addLog2("RowVal.test.ctor(List<String>)", "", "RowVal");
//			for (var tmp1 : new String[] { "Face;Weight;Unit;1;2;", "Face;Weight;Unit ;1;2 ;", "Face;Weight;Unit;4;5",
//					"Unit;1" }) {
//				var tmp2 = Etc.delTailStr(tmp1, RowVal.splitterVal);
//				var tmp3 = List.of(tmp2);
//				WB.addLog2("RowVal.test.ctor(List<String>), res=" + new RowVal(tmp3), "", "RowVal");
//			}

//			WB.addLog2("RowVal.test.ctor(String)", "", "RowVal");
//			for (var tmp1 : new String[] { "Face;Weight;Unit;1;2;", "Face;Weight;Unit ;1;2 ;", "Face;Weight;Unit;4;5",
//					"Unit;1" }) {
//				WB.addLog2("RowVal.test.ctor(String), res=" + new RowVal(tmp1), "", "RowVal");
//			}

		} catch (Exception ex) {
			WB.addLog("RowVal.test():void, ex=" + ex.getMessage(), "", "RowVal");
		}
	}
}