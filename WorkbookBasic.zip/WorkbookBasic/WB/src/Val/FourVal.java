import java.util.List;

public final class FourVal {
	// origin - 14.12.2025, last edit - 14.12.2025
	public String id, src, partVal1, partVal2, partVal3, partVal4;
	private static List<String> listDelStr;
	public String val1, val2, val3, val4;

	static {
		try {
			FourVal.listDelStr = List.of(",");
		} catch (Exception ex) {
			WB.addLog("FourVal.static ctor, ex=" + ex.getMessage(), "", "FourVal");
		}
	}

	private void getId() throws Exception {
		// origin - 14.12.2025, last edit - 14.12.2025
		try {
			this.id = " " + this.val1 + "," + this.val2 + "," + this.val3 + "," + this.val4;
			if (this.partVal1.isEmpty() && this.partVal2.isEmpty() && this.partVal3.isEmpty()
					&& this.partVal4.isEmpty()) {
				this.id = "";
			}
		} catch (Exception ex) {
			WB.addLog("FourVal.getId():void, ex=" + ex.getMessage(), "", "FourVal");
		}
	}

	private void getVal() throws Exception {
		// origin - 14.12.2025, last edit - 14.12.2025
		try {
			this.val1 = this.partVal1;
			this.val2 = this.partVal2;
			this.val3 = this.partVal3;
			this.val4 = this.partVal4;
		} catch (Exception ex) {
			WB.addLog("FourVal.getVal():void, ex=" + ex.getMessage(), "", "FourVal");
		}
	}

	private void getPart() throws Exception {
		// origin - 14.12.2025, last edit - 14.12.2025
		try {
			String[] items = this.src.split(" , ");
			if (items.length > 0) {
				this.partVal1 = items[0];
				this.partVal1 = Etc.delStr(this.partVal1, FourVal.listDelStr);

				if (items.length > 1) {
					this.partVal2 = items[1];
					this.partVal2 = Etc.delStr(this.partVal2, FourVal.listDelStr);
				}

				if (items.length > 2) {
					this.partVal3 = items[2];
					this.partVal3 = Etc.delStr(this.partVal3, FourVal.listDelStr);
				}

				if (items.length > 3) {
					this.partVal4 = items[3];
					this.partVal4 = Etc.delStr(this.partVal4, FourVal.listDelStr);
				}
			}
		} catch (Exception ex) {
			WB.addLog("FourVal.getPart():void, ex=" + ex.getMessage(), "", "FourVal");
		}
	}

	public FourVal(String Src) throws Exception {
		// origin - 14.12.2025, last edit - 14.12.2025
		this.clear();
		this.src = Etc.fixTrim(Src);
		this.getPart();
		this.getVal();
		this.getId();
	}

	public FourVal() throws Exception {
		// origin - 14.12.2025, last edit - 14.12.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 14.12.2025, last edit - 14.12.2025
		try {
			this.id = this.src = this.partVal1 = this.partVal2 = this.partVal3 = this.partVal4 = "";
			this.val1 = this.val2 = this.val3 = this.val4 = "";
		} catch (Exception ex) {
			WB.addLog("FourVal.clear():void, ex=" + ex.getMessage(), "", "FourVal");
		}
	}

	public String toString() {
		// origin - 14.12.2025, last edit - 14.12.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("id ", this.id);
			res = res + Fmtr.addAnyway(" src ", this.src);
			res = res + Fmtr.addIfNotEmpty(" partVal1  ", this.partVal1);
			res = res + Fmtr.addIfNotEmpty(" val1 ", this.val1);
			res = res + Fmtr.addIfNotEmpty(" partVal2 ", this.partVal2);
			res = res + Fmtr.addIfNotEmpty(" val2 ", this.val2);
			res = res + Fmtr.addIfNotEmpty(" partVal3 ", this.partVal3);
			res = res + Fmtr.addIfNotEmpty(" val3 ", this.val3);
			res = res + Fmtr.addIfNotEmpty(" partVal4 ", this.partVal4);
			res = res + Fmtr.addIfNotEmpty(" val4 ", this.val4);
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 14.12.2025, last edit - 14.12.2025
		try {

//			WB.addLog2("FourVal.test.ctor(String)", "", "FourVal");
//			for (var tmp : new String[] { "", "1", "1 , FullAccess", "1 , FullAccess , Face.FA1.StaffTable1.Boss",
//					"1 , FullAccess , Face.FA1.StaffTable1.Boss , 12345678" }) {
//				WB.addLog2("FourVal.test.ctor(String), res=" + new FourVal(tmp), "", "FourVal");
//			}

		} catch (Exception ex) {
			WB.addLog("FourVal.test():void, ex=" + ex.getMessage(), "", "FourVal");
		}
	}
}