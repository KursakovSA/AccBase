import java.util.List;

public final class ThreeVal {
	// origin - 02.10.2025, last edit - 12.10.2025
	public String id, src, partVal1, partVal2, partVal3;
	private static List<String> listDelStr;
	public String val1, val2, val3;

	static {
		try {
			ThreeVal.listDelStr = List.of(",");
		} catch (Exception ex) {
			WB.addLog("ThreeVal.static ctor, ex=" + ex.getMessage(), "", "ThreeVal");
		}
	}

	private void getId() throws Exception {
		// origin - 02.10.2025, last edit - 02.10.2025
		try {
			this.id = " " + this.val1 + "," + this.val2 + "," + this.val3;
			if (this.partVal1.isEmpty() && this.partVal2.isEmpty() && this.partVal3.isEmpty()) {
				this.id = "";
			}
		} catch (Exception ex) {
			WB.addLog("ThreeVal.getId():void, ex=" + ex.getMessage(), "", "ThreeVal");
		}
	}

	private void getVal() throws Exception {
		// origin - 02.10.2025, last edit - 02.10.2025
		try {
			this.val1 = this.partVal1;
			this.val2 = this.partVal2;
			this.val3 = this.partVal3;
		} catch (Exception ex) {
			WB.addLog("ThreeVal.getVal():void, ex=" + ex.getMessage(), "", "ThreeVal");
		}
	}

	private void getPart() throws Exception {
		// origin - 02.10.2025, last edit - 02.10.2025
		try {
			String[] items = this.src.split(" , ");
			if (items.length > 0) {
				this.partVal1 = items[0];
				this.partVal1 = Etc.delStr(this.partVal1, ThreeVal.listDelStr);

				this.partVal2 = items[1];
				this.partVal2 = Etc.delStr(this.partVal2, ThreeVal.listDelStr);

				this.partVal3 = items[2];
				this.partVal3 = Etc.delStr(this.partVal3, ThreeVal.listDelStr);
			}
		} catch (Exception ex) {
			WB.addLog("ThreeVal.getPart():void, ex=" + ex.getMessage(), "", "ThreeVal");
		}
	}

	public ThreeVal(String Src) throws Exception {
		// origin - 02.10.2025, last edit - 02.10.2025
		this.clear();
		this.src = Etc.fixTrim(Src);
		this.getPart();
		this.getVal();
		this.getId();
	}

	public ThreeVal() throws Exception {
		// origin - 02.10.2025, last edit - 02.10.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 02.10.2025, last edit - 02.10.2025
		try {
			this.id = this.src = this.partVal1 = this.partVal2 = this.partVal3 = "";
			this.val1 = this.val2 = this.val3 = "";
		} catch (Exception ex) {
			WB.addLog("ThreeVal.clear():void, ex=" + ex.getMessage(), "", "ThreeVal");
		}
	}

	public String toString() {
		// origin - 02.10.2025, last edit - 02.10.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("id ", this.id);
			res = res + Fmtr.addAnyway(" src ", this.src);
			res = res + Fmtr.addAnyway(" partVal1  ", this.partVal1);
			res = res + Fmtr.addAnyway(" val1 ", this.val1);
			res = res + Fmtr.addAnyway(" partVal2 ", this.partVal2);
			res = res + Fmtr.addAnyway(" val2 ", this.val2);
			res = res + Fmtr.addAnyway(" partVal3 ", this.partVal3);
			res = res + Fmtr.addAnyway(" val3 ", this.val3);
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 02.10.2025, last edit - 02.10.2025
		try {

//			WB.addLog2("ThreeVal.test.ctor(String)", "", "ThreeVal");
//			for (var tmp : new String[] { "Face , Face.FA1 , Face.FA1.Crew1",
//					"Face , Face.Tralala , Face.Tralala.Crew1" }) {
//				WB.addLog2("ThreeVal.test.ctor(String), res=" + new ThreeVal(tmp), "", "ThreeVal");
//			}

		} catch (Exception ex) {
			WB.addLog("ThreeVal.test():void, ex=" + ex.getMessage(), "", "ThreeVal");
		}
	}
}