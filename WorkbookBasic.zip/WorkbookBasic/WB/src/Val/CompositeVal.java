import java.util.ArrayList;
import java.util.List;

public final class CompositeVal {
	// origin - 03.09.2024, last edit - 12.10.2025
	public String id, context, src, partName, name, partUnit;
	public Unit unit;
	private static List<String> listDelStr;
	public List<String> val;
	private String partVal;

	static {
		try {
			CompositeVal.listDelStr = List.of("=", "(", ")");
		} catch (Exception ex) {
			WB.addLog("CompositeVal.static ctor, ex=" + ex.getMessage(), "", "CompositeVal");
		}
	}

	public void getUnit() throws Exception {
		// origin - 16.06.2025, last edit - 16.06.2025
		try {
			if (this.partUnit.isEmpty() == false) {
				this.unit = new Unit(this.partUnit);
				this.context = this.unit.expectedValue;
			}
		} catch (Exception ex) {
			WB.addLog("CompositeVal.getUnit():void, ex=" + ex.getMessage(), "", "CompositeVal");
		}
	}

	private void getVal() throws Exception {
		// origin - 30.09.2024, last edit - 13.06.2025
		try {
			this.name = this.partName;
			this.val = Fmtr.listVal(this.partVal, "/");
			this.getUnit();
			this.id = this.partName + this.val.toString() + " " + this.unit.code + ", " + this.unit.description;
		} catch (Exception ex) {
			WB.addLog("CompositeVal.getVal():void, ex=" + ex.getMessage(), "", "CompositeVal");
		}
	}

	private void getPart() throws Exception {
		// origin - 30.09.2024, last edit - 17.06.2025
		try {
			// if (ModelVal.isType(this.src) == "CompositeVal") {
			String tmp = this.src;

			int posMiddleEquation = tmp.indexOf("="); // pos "="
			if (posMiddleEquation > 0) {
				this.partName = Etc.fixTrim(tmp.substring(0, posMiddleEquation));
				tmp = Etc.delStr(tmp, this.partName);
				tmp = Etc.delStr(tmp, "=");
			}

			int posLocalSplitValUnit = tmp.indexOf("(Unit.");
			if (posLocalSplitValUnit > 0) {
				this.partVal = Etc.fixTrim(tmp.substring(0, posLocalSplitValUnit));
				this.partUnit = Etc.fixTrim(tmp.substring(posLocalSplitValUnit));
				this.partUnit = Etc.delStr(this.partUnit, CompositeVal.listDelStr);
			}

			if (this.partUnit.isEmpty()) {
				this.partVal = Etc.fixTrim(tmp);
			}
			// }
		} catch (Exception ex) {
			WB.addLog("CompositeVal.getPart():void, ex=" + ex.getMessage(), "", "CompositeVal");
		}
	}

	public CompositeVal(String Src) throws Exception {
		// origin - 30.09.2024, last edit - 16.06.2025
		this.clear();
		this.src = Etc.fixTrim(Src);
		this.getPart();
		this.getVal();
	}

	public CompositeVal() throws Exception {
		// origin - 03.09.2024, last edit - 19.03.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 16.06.2025, last edit - 06.09.2025
		try {
			this.id = this.context = this.src = this.partName = this.name = this.partVal = this.partUnit = "";
			this.unit = null;
			this.val = new ArrayList<String>();
		} catch (Exception ex) {
			WB.addLog("CompositeVal.clear():void, ex=" + ex.getMessage(), "", "CompositeVal");
		}
	}

	public String toString() {
		// origin - 06.01.2025, last edit - 21.03.2025
		String res = "";
		try {
			res = this.id + " " + ", src " + this.src;
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 03.09.2024, last edit - 16.06.2025
		try {

//			WB.addLog2("CompositeVal.test.ctor(String)", "", "CompositeVal");
//			for (var tmp : new String[] { "Weight = 6.89 / 3.56(Unit.Gr)", "67 / 15(Unit.KZT)", "45/56(Unit.Size)",
//					"89 /23(Unit.Tralala)", "male /female" }) {
//				WB.addLog2("CompositeVal.test.ctor, res=" + new CompositeVal(tmp), "", "CompositeVal");
//			}

		} catch (Exception ex) {
			WB.addLog("CompositeVal.test():void, ex=" + ex.getMessage(), "", "CompositeVal");
		}
	}
}