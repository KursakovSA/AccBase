import java.util.List;

public final class SimplexVal {
	// origin - 05.10.2024, last edit - 22.11.2025
	private static List<String> listDelStr;
	public String id, context, src, partName, name, partVal, val;

	static {
		try {
			SimplexVal.listDelStr = List.of("=", "?", ";");
		} catch (Exception ex) {
			WB.addLog("SimplexVal.static ctor, ex=" + ex.getMessage(), "", "SimplexVal");
		}
	}

	private void getVal() throws Exception {
		// origin - 12.11.2024, last edit - 22.11.2025
		try {
			this.name = this.partName;
			this.val = this.partVal;
			this.id = this.name + " " + this.val;
		} catch (Exception ex) {
			WB.addLog("SimplexVal.getVal():void, ex=" + ex.getMessage(), "", "SimplexVal");
		}
	}

	private void getPart() throws Exception {
		// origin - 12.11.2024, last edit - 29.11.2025
		try {
			int posLocalStrMiddleEquation = this.src.indexOf("="); // pos "="
			if (posLocalStrMiddleEquation > 0) {
				this.partName = Etc.fixTrim(this.src.substring(0, posLocalStrMiddleEquation));
				this.partName = Etc.delStr(this.partName, SimplexVal.listDelStr);
				this.partVal = Etc.fixTrim(this.src.substring(posLocalStrMiddleEquation));
				this.partVal = Etc.delStr(this.partVal, SimplexVal.listDelStr);
			}
		} catch (Exception ex) {
			WB.addLog("SimplexVal.getPart():void, ex=" + ex.getMessage(), "", "SimplexVal");
		}
	}

	public SimplexVal(String Src) throws Exception {
		// origin - 05.10.2024, last edit - 18.06.2025
		this.clear();
		this.src = Etc.fixTrim(Src);
		this.getPart();
		this.getVal();
	}

	public SimplexVal() throws Exception {
		// origin - 05.10.2024, last edit - 16.05.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 18.06.2025, last edit - 22.11.2025
		try {
			this.id = this.context = this.src = this.partName = this.name = this.partVal = this.val = "";
		} catch (Exception ex) {
			WB.addLog("SimplexVal.clear():void, ex=" + ex.getMessage(), "", "SimplexVal");
		}
	}

	public String toString() {
		// origin - 26.09.2024, last edit - 18.06.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("id ", this.id);
			res = res + Fmtr.addAnyway(" src ", this.src);
			res = res + Fmtr.addAnyway(" partName ", this.partName);
			res = res + Fmtr.addAnyway(" name ", this.name);
			res = res + Fmtr.addAnyway(" partVal ", this.partVal);
			res = res + Fmtr.addAnyway(" val ", this.val);
			res = res + Fmtr.addIfNotEmpty(" context ", this.context);
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 05.10.2024, last edit - 29.11.2025
		try {

//			WB.addLog2("SimplexVal.test.ctor(String)", "", "SimplexVal");
//			var arg1 = new String[] { "IIN=123456789012;", "IIN=;", "IIN=?;" };
//			for (var tmp1 : arg1) {
//				WB.addLog2("SimplexVal.test.ctor(String), res=" + new SimplexVal(tmp1), "", "SimplexVal");
//			}

		} catch (Exception ex) {
			WB.addLog("SimplexVal.test():void, ex=" + ex.getMessage(), "", "SimplexVal");
		}
	}
}