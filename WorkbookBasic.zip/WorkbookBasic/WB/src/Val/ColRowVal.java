import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public final class ColRowVal {
	// origin - 15.02.2026, last edit - 01.09.2026
	public String id, code, description, defect;
	public List<String> src;
	public List<List<String>> row;
	public static String delimiter, delimiterForWrite;

	static {
		ColRowVal.delimiter = "\\|"; // "\\" this is protective shielding
		ColRowVal.delimiterForWrite = "|";
		try {
		} catch (Exception ex) {
			WB.addLog("ColRowVal.static ctor, ex=" + ex.getMessage(), "", "ColRowVal");
		}
	}

	public void fix() throws Exception { // TODO
		// origin - 19.08.2026, last edit - 24.08.2026
		try {
		} catch (Exception ex) {
			WB.addLog("ColRowVal.fix():void, ex=" + ex.getMessage(), "", "ColRowVal");
		}
	}

	private void validate() throws Exception { // TODO
		// origin - 18.02.2026, last edit - 24.08.2026
		try {
		} catch (Exception ex) {
			WB.addLog("ColRowVal.validate():void, ex=" + ex.getMessage(), "", "ColRowVal");
		}
	}

	public Map<Integer, Double> sum(int colSum[]) throws Exception { // TODO
		// origin - 31.08.2026, last edit - 31.08.2026
		Map<Integer, Double> res = new HashMap<>();
		try {
			List<Integer> colSumList = Arrays.stream(colSum).map(x -> x - 1).boxed().toList();

			Map<Integer, Double> tmp = colSumList.stream()
					.collect(Collectors.toMap(colIdx -> colIdx,
							colIdx -> this.row.stream().filter(row -> colIdx >= 0 && colIdx < row.size())
									.map(row -> row.get(colIdx)).filter(val -> val != null && !val.isBlank())
									.mapToDouble(Double::parseDouble).sum()));
			res = tmp;
		} catch (Exception ex) {
			WB.addLog("ColRowVal.sum(int[]):Map<Integer, Double>, ex=" + ex.getMessage(), "", "ColRowVal");
		}
		return res;
	}

	public Map<Integer, Double> sum(int colSum) throws Exception {
		// origin - 31.08.2026, last edit - 31.08.2026
		Map<Integer, Double> res = new HashMap<>();
		try {
			int[] tmp = { colSum };
			res = this.sum(tmp);
		} catch (Exception ex) {
			WB.addLog("ColRowVal.sum(int):Map<Integer, Double>, ex=" + ex.getMessage(), "", "ColRowVal");
		}
		return res;
	}

	public Map<List<String>, List<Double>> groupingWithSum(int[] colGrouping, int[] colSum) throws Exception {
		// origin - 31.08.2026, last edit - 31.08.2026
		Map<List<String>, List<Double>> res = new HashMap<>();
		try {
			List<Integer> colGroupingList = Arrays.stream(colGrouping).map(x -> x - 1).boxed().toList();
			List<Integer> colSumList = Arrays.stream(colSum).map(x -> x - 1).boxed().toList();

			// Группировка и кастомное сведение (reduction)
			Map<List<String>, List<Double>> tmp = this.row.stream().collect(Collectors.groupingBy(
					// 1. Создаем ключ группировки из нужных колонок
					row -> colGroupingList.stream().map(row::get).collect(Collectors.toList()),

					// 2. Сворачиваем строки, суммируя нужные колонки
					Collectors.reducing(
							// Начальное значение (массив нулей по количеству колонок суммирования)
							new ArrayList<>(Collections.nCopies(colSumList.size(), 0.0)),
							// Преобразуем строку в список лонгов для суммирования
							row -> colSumList.stream().map(idx -> Double.parseDouble(row.get(idx)))
									.collect(Collectors.toList()),
							// Складываем два списка поиндексно
							(list1, list2) -> {
								List<Double> sum = new ArrayList<>();
								for (int i = 0; i < list1.size(); i++) {
									sum.add(list1.get(i) + list2.get(i));
								}
								return sum;
							})));
			res = tmp;
		} catch (Exception ex) {
			WB.addLog("ColRowVal.groupingWithSum(2int[]):Map<List<String>, List<Double>>, ex=" + ex.getMessage(), "",
					"ColRowVal");
		}
		return res;
	}

	public Map<Object, Double> groupingWithSum(int[] colGrouping, int colSum) throws Exception {
		// origin - 30.08.2026, last edit - 31.08.2026
		Map<Object, Double> res = new HashMap<>();
		try {
			List<Integer> colList = Arrays.stream(colGrouping).map(x -> x - 1).boxed().toList();
			Map<Object, Double> tmp = this.row.stream().collect(Collectors.groupingBy(
					// 1. Формируем составной ключ
					row -> colList.stream().map(row::get).collect(Collectors.toList()),

					// 2. Считаем сумму по целевой колонке
					Collectors.summingDouble(row -> {
						String val = row.get(colSum - 1);
						return (val == null || val.isEmpty()) ? 0.0 : Double.parseDouble(val);
					})));
			res = tmp;
		} catch (Exception ex) {
			WB.addLog("ColRowVal.groupingWithSum(int[],int):Map<Object, Double>, ex=" + ex.getMessage(), "",
					"ColRowVal");
		}
		return res;
	}

	public Map<Object, List<List<String>>> grouping(int[] col) throws Exception {
		// origin - 24.08.2026, last edit - 31.08.2026
		Map<Object, List<List<String>>> res = new HashMap<>();
		try {
			List<Integer> colList = Arrays.stream(col).map(x -> x - 1).boxed().toList();
			Map<Object, List<List<String>>> tmp = this.row.stream()
					.collect(Collectors.groupingBy(row -> colList.stream().map(row::get).collect(Collectors.toList())));
			res = tmp;
		} catch (Exception ex) {
			WB.addLog("ColRowVal.grouping(int[]):Map<Object, List<List<String>>>, ex=" + ex.getMessage(), "",
					"ColRowVal");
		}
		return res;
	}

	public Map<String, List<List<String>>> grouping(int col) throws Exception {
		// origin - 24.08.2026, last edit - 24.08.2026
		Map<String, List<List<String>>> res = new HashMap<>();
		try {
			Map<String, List<List<String>>> tmp = this.row.stream()
					.collect(Collectors.groupingBy(row -> row.get(col - 1)));
			res = tmp;
		} catch (Exception ex) {
			WB.addLog("ColRowVal.grouping(int):Map<String, List<List<String>>>, ex=" + ex.getMessage(), "",
					"ColRowVal");
		}
		return res;
	}

	public void sort(int col) throws Exception {
		// origin - 31.08.2026, last edit - 31.08.2026
		try {
			int[] tmp = { col };
			this.sort(tmp);
		} catch (Exception ex) {
			WB.addLog("ColRowVal.sort(int):void, ex=" + ex.getMessage(), "", "ColRowVal");
		}
	}

	public void sort(int[] col) throws Exception {
		// origin - 23.08.2026, last edit - 24.08.2026
		try {
			// start comparator
			Comparator<List<String>> multiComparator = Comparator.comparing(row -> row.get(col[0] - 1));
			// add next comparators
			for (int i = 1; i < col.length; i++) {
				int index = col[i]; // Создаем effectively final переменную для лямбды
				multiComparator = multiComparator.thenComparing(row -> row.get(index - 1));
			}
			// sort by chain comparators
			var tmp = this.row.stream().sorted(multiComparator).collect(Collectors.toList());
			this.row.clear();
			this.row.addAll(tmp);
		} catch (Exception ex) {
			WB.addLog("ColRowVal.sort(int[]):void, ex=" + ex.getMessage(), "", "ColRowVal");
		}
	}

	public List<String> getRowByIndex(int index) throws Exception { // userindex start on 1
		// origin - 19.02.2026, last edit - 24.02.2026
		List<String> res = new ArrayList<String>();
		try {
			res = this.row.get(index - 1); // innerIndex start on 0
		} catch (Exception ex) {
			WB.addLog("ColRowVal.getRowByIndex(int):List<String>, ex=" + ex.getMessage(), "", "ColRowVal");
		}
		return res;
	}

	//// getColByIndex(int index)

	private List<List<String>> getRowList(List<String> in) throws Exception {
		// origin - 23.08.2026, last edit - 24.08.2026
		List<List<String>> res = new ArrayList<>();
		try {
			for (var curr : in) {
				// get row
				List<String> tmp = new ArrayList<String>();
				var tmp1 = Etc.delTailStr(curr, ColRowVal.delimiter);
				var tmp2 = List.of(tmp1.split(ColRowVal.delimiter));
				tmp.addAll(Etc.fixTrim(tmp2));

				// add row to tabVal.rowList
				res.add(tmp);
				// res.add(this.getRow(curr));
			}
		} catch (Exception ex) {
			WB.addLog("ColRowVal.getRowList(List<String>):List<List<String>>, ex=" + ex.getMessage(), "", "ColRowVal");
		}
		return res;
	}

//	private List<String> getRow(String in) throws Exception {
//		// origin - 23.08.2026, last edit - 24.08.2026
//		List<String> res = new ArrayList<String>();
//		try {
//			var tmp1 = Etc.delTailStr(in, TabVal.delimiter);
//			var tmp2 = List.of(tmp1.split(TabVal.delimiter));
//			res.addAll(Etc.fixTrim(tmp2));
//		} catch (Exception ex) {
//			WB.addLog("ColRowVal.getRow(String):List<String>, ex=" + ex.getMessage(), "", "ColRowVal");
//		}
//		return res;
//	}

	//// ?? getCol() ????

	public ColRowVal(List<String> Src) throws Exception {
		// origin - 16.02.2026, last edit - 23.08.2026
		this.clear();
		this.src = Etc.fixTrim(Src);
		// this.row.addAll(RowVal.getList(this.src));
		this.row.addAll(this.getRowList(this.src));
		this.fix();
		this.validate();
	}

	public ColRowVal() throws Exception {
		// origin - 15.02.2026, last edit - 15.02.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 15.02.2026, last edit - 24.08.2026
		try {
			this.id = this.code = this.description = this.defect = "";
			this.src = new ArrayList<String>();
			this.row = new ArrayList<>();
		} catch (Exception ex) {
			WB.addLog("ColRowVal.clear():void, ex=" + ex.getMessage(), "", "ColRowVal");
		}
	}

	public String toString() {
		// origin - 15.02.2026, last edit - 01.09.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", src.size ", this.src.size());
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", row.size ", this.row.size());
			res = res + Fmtr.addIfNotEmpty(", row ", this.row);
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 15.02.2026, last edit - 31.08.2026
		try {

			{
				WB.addLog2("ColRowVal.test.sum(int[]):map;", "", "ColRowVal");
				var tmp1 = List.of("Face1|W12|Unit.Kg|100|200|", "Face2|W13|Unit.Kg|300|400|",
						"Face1|W13|Unit.Gr|500|600|", "Face1|W12|Unit.Kg|700|800|");
				var tmp2 = new ColRowVal(tmp1);
				WB.log(tmp2.row, "ColRowVal");
				var tmp3 = new int[] { 4, 5 };
				WB.addLog2("ColRowVal.test.sum(int[]):map, res=" + tmp2.sum(tmp3) + ", tmp3=" + Fmtr.listVal(tmp3), "",
						"ColRowVal");
			}

//			{
//				WB.addLog2("ColRowVal.test.groupingWithSum(2int[]):map;", "", "ColRowVal");
//				var tmp1 = List.of("Face1|W12|Unit.Kg|100|200|", "Face2|W13|Unit.Kg|300|400|",
//						"Face1|W13|Unit.Gr|500|600|", "Face1|W12|Unit.Kg|700|800|");
//				var tmp2 = new ColRowVal(tmp1);
//				WB.log(tmp2.row, "ColRowVal");
//				var tmp3 = new int[] { 1, 2 };
//				var tmp4 = new int[] { 4, 5 };
//				WB.addLog2("ColRowVal.test.groupingWithSum(2int[]):map, res=" + tmp2.groupingWithSum(tmp3, tmp4)
//						+ ", tmp3=" + Fmtr.listVal(tmp3) + ", tmp4=" + Fmtr.listVal(tmp4), "", "ColRowVal");
//			}

//			{
//				WB.addLog2("ColRowVal.test.groupingWithSum(int[],int):map;", "", "ColRowVal");
//				var tmp1 = List.of("Face1|W12|Unit.Kg|100|200|", "Face2|W13|Unit.Kg|300|400|",
//						"Face1|W13|Unit.Gr|500|600|", "Face1|W12|Unit.Kg|700|800|");
//				var tmp2 = new ColRowVal(tmp1);
//				WB.log(tmp2.row, "ColRowVal");
//				var tmp3 = new int[] { 1, 2 };
//				var tmp4 = new int[] { 4, 5 };
//				for (var tmp5 : tmp4) {
//					WB.addLog2("ColRowVal.test.groupingWithSum(int[],int):map, res=" + tmp2.groupingWithSum(tmp3, tmp5)
//							+ ", tmp3=" + Fmtr.listVal(tmp3) + ", tmp5=" + tmp5, "", "ColRowVal");
//				}
//			}

//			{
//				WB.addLog2("ColRowVal.test.grouping(int[]):map", "", "ColRowVal");
//				var tmp1 = List.of("Face1|W12|Unit.Kg|100|200|", "Face2|W13|Unit.Kg|300|400|",
//						"Face1|W13|Unit.Gr|500|600|", "Face1|W12|Unit.Kg|700|800|");
//				var tmp2 = new ColRowVal(tmp1);
//				var tmp3 = new int[] { 1, 2 };
//				WB.addLog2("ColRowVal.test.grouping(int[]):map, res=" + tmp2.grouping(tmp3) + ", tmp3="
//						+ Fmtr.listVal(tmp3), "", "ColRowVal");
//
//			}

//			{
//				WB.addLog2("ColRowVal.test.grouping(int):map", "", "ColRowVal");
//				var tmp1 = List.of("Face1|W12|Unit.Kg|P1|S2 |", "Face2|W13|Unit.Kg|P3|S4|",
//						"Face1|W13|Unit.Gr|P300|S400|");
//				var tmp2 = new ColRowVal(tmp1);
//				for (var tmp3 : new int[] { 3, 2, 1 }) {
//					WB.addLog2("ColRowVal.test.grouping(int):map, res=" + tmp2.grouping(tmp3) + ", tmp3=" + tmp3, "",
//							"ColRowVal");
//				}
//			}

//			{
//				WB.addLog2("ColRowVal.test.sort(int[]):void", "", "ColRowVal");
//				var tmp1 = List.of("Face1|W12|Unit.Kg|P1|S2 |", "Face2|W13|Unit.Kg|P3|S4|",
//						"Face1|W13|Unit.Gr|P300|S400|");
//				var tmp2 = List.of("Иванов|Сергей|Сергеевич|", "Петров|Анатолий|Анатольевич|",
//						"Johnson|John|Johniest|");
//				List<List<String>> tmp3 = new ArrayList<>();
//				tmp3.add(tmp1);
//				tmp3.add(tmp2);
//				for (var tmp4 : tmp3) {
//					for (var tmp0 : new int[][] { { 3 }, { 2 }, { 1 }, { 3, 2 }, { 2, 3 }, { 3, 1 } }) {
//						var tmp5 = new ColRowVal(tmp4);
//						WB.addLog2(
//								"ColRowVal.test.sort(int[]):void, before this.sort()" + ", tmp0=" + Fmtr.listVal(tmp0),
//								"", "ColRowVal");
//						WB.log(tmp5.row, "ColRowVal");
//						tmp5.sort(tmp0);
//						WB.addLog2("ColRowVal.test.sort(int[]):void, after this.sort()" + " tmp0=" + Fmtr.listVal(tmp0),
//								"", "ColRowVal");
//						WB.log(tmp5.row, "ColRowVal");
//					}
//				}
//			}

//			{
//				WB.addLog2("ColRowVal.test.getRowByIndex(int):String", "", "ColRowVal");
//				var tmp1 = List.of(""Face1|W12|Unit.Kg|1|2 |", "Face2|W13|Unit.Kg|3|4",
//						"Face1|W13|Unit.Gr|300|400");
//				var tmp2 = new ColRowVal(tmp1);
//				WB.log(tmp2.row, "ColRowVal");
//				for (var tmp3 : new int[] { 1, 2, 3, 4 }) {
//					WB.addLog2("ColRowVal.test.getRowByIndex(int):String, res=" + tmp2.getRowByIndex(tmp3) + " userIndex="
//							+ tmp3, "", "ColRowVal");
//				}
//			}

//			{
//				WB.addLog2("ColRowVal.test.getColNameByIndex(int):String", "", "ColRowVal");
//				var tmp1 = List.of("Face1|W12|Unit.Kg|1|2 |", "Face2|W13|Unit.Kg|3|4",
//						"Face1;W13;Unit.Gr;300;400");
//				var tmp2 = new ColRowVal(tmp1);
//				for (var tmp3 : new int[] { 1, 2, 3, 4, 5 }) {
//					WB.addLog2("ColRowVal.test.getColNameByIndex(int):String, res=" + tmp2.getColNameByIndex(tmp3)
//							+ " userIndex=" + tmp3, "", "ColRowVal");
//				}
//			}

//			{
//				WB.addLog2("ColRowVal.test.getIndexByColName(String):int", "", "ColRowVal");
//				var tmp1 = List.of("Face1|W12|Unit.Kg|1|2 |", "Face2;W13;Unit.Kg;3;4",
//						"Face1;W13;Unit.Gr;300;400");
//				var tmp2 = new ColRowVal(tmp1);
//				for (var tmp3 : new String[] { "Face", "Weight", "Unit", "Price", "Sum" }) {
//					WB.addLog2("ColRowVal.test.getIndexByColName(String):int, res=" + tmp2.getIndexByColName(tmp3)
//							+ " colName=" + tmp3, "", "ColRowVal");
//				}
//			}

//			{
//				WB.addLog2("ColRowVal.test.ctor(List<String>)", "", "ColRowVal");
//				var tmp1 = List.of("Face1|W12|Unit.Kg|1|2 |", "Face2|W13|Unit.Kg|3|4", "Face1|W13|Unit.Gr|300|400");
//				var tmp2 = new ColRowVal(tmp1);
//				WB.addLog2("ColRowVal.test.ctor(List<String>), res=" + tmp2, "", "ColRowVal");
//				WB.log(tmp2.row, "ColRowVal");
//			}

		} catch (Exception ex) {
			WB.addLog("ColRowVal.test():void, ex=" + ex.getMessage(), "", "ColRowVal");
		}
	}
}