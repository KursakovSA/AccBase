import java.util.ArrayList;
import java.util.List;

public final class TagVal {
	// origin - 26.09.2024, last edit - 12.10.2025
	public String id, src, tag, val;
	private static List<String> listDelStr;

	static {
		try {
			TagVal.listDelStr = List.of("<", "=", ">");
		} catch (Exception ex) {
			WB.addLog("TagVal.static ctor, ex=" + ex.getMessage(), "", "TagVal");
		}
	}

	public static List<TagVal> getList(String inStr) throws Exception {
		// origin - 15.04.2026, last edit - 18.10.2026
		List<TagVal> res = new ArrayList<TagVal>();
		if (Etc.strNotValid(inStr)) {
			return res;
		}
		inStr = Etc.fixTrim(inStr);
		try {
			var tmp = Fmtr.getListStrBySplit(inStr, ";");
			for (var curr : tmp) {
				if (TagVal.containsTagVal(curr)) {
					res.add(new TagVal(curr));
				}
			}
		} catch (Exception ex) {
			WB.addLog("TagVal.getList(String):List<TagVal>, ex=" + ex.getMessage(), "", "TagVal");
		}
		return res;
	}

	public static boolean matchTag(String inStr, String tag) throws Exception {
		// origin - 26.09.2024, last edit - 19.10.2026
		boolean res = false;
		if (Etc.strNotValid(inStr, tag)) {
			return res;
		}
		inStr = Etc.fixString(inStr);
		try {
			if (TagVal.containsTagVal(inStr)) {
				TagVal probeTagVal = new TagVal(inStr);
				res = Etc.strEquals(probeTagVal.tag, tag);
			}

		} catch (Exception ex) {
			WB.addLog("TagVal.matchTag(2String):boolean, ex=" + ex.getMessage(), "", "TagVal");
		}
		return res;
	}

	public static boolean containsTagVal(String inStr) throws Exception {
		// origin - 26.09.2024, last edit - 18.10.2026
		boolean res = false;
		if (Etc.strNotValid(inStr)) {
			return res;
		}
		inStr = Etc.fixString(inStr);
		try {
			int posLocalStrLeftSplit = 999; // ?? magic string ??
			posLocalStrLeftSplit = inStr.indexOf("<"); // pos "<"
			int posLocalStrRightSplit = inStr.indexOf(">") + 1; // pos ">"

			if ((posLocalStrLeftSplit != 999) && (posLocalStrRightSplit > 0)) {
				res = true;
			}

		} catch (Exception ex) {
			WB.addLog("TagVal.containsTagVal(String):boolean, ex=" + ex.getMessage(), "", "TagVal");
		}
		return res;
	}

	public static String delTagVal(String inStr) throws Exception {
		// origin - 26.09.2024, last edit - 18.10.2026
		String res = Etc.fixTrim(inStr);
		try {
			if (Etc.strNotValid(inStr)) {
				return res;
			}

			if (TagVal.containsTagVal(inStr)) {
				int posLocalStrLeftSplit = 999; // ?? magic string ??
				posLocalStrLeftSplit = inStr.indexOf("<"); // pos "<"
				int posLocalStrRightSplit = inStr.indexOf(">") + 1; // pos ">"

				if ((posLocalStrLeftSplit != 999) && (posLocalStrRightSplit > 0)) {
					String probeStrTagVal = inStr.substring(posLocalStrLeftSplit, posLocalStrRightSplit);
					res = Etc.delStr(res, probeStrTagVal);
					res = Etc.fixTrim(res);
				}
			}

		} catch (Exception ex) {
			WB.addLog("TagVal.delTagVal(String):String, ex=" + ex.getMessage(), "", "TagVal");
		}
		return res;
	}

	private void getPart() throws Exception {
		// origin - 26.09.2024, last edit - 15.04.2026
		try {
			int posLocalStrMiddleEquation = this.src.indexOf("="); // pos "="
			if (posLocalStrMiddleEquation > 0) {
				// this is res
				this.tag = Etc.fixTrim(this.src.substring(0, posLocalStrMiddleEquation));
				this.tag = Etc.delStr(this.tag, TagVal.listDelStr);
				this.val = Etc.fixTrim(this.src.substring(posLocalStrMiddleEquation));
				this.val = Etc.delStr(this.val, TagVal.listDelStr);
				this.id = this.tag + "=" + this.val;
			}

			if (this.tag.isEmpty()) {
				this.tag = this.id = this.val = Etc.delStr(this.src, TagVal.listDelStr); // ex. <Armatura12>
			}
		} catch (Exception ex) {
			WB.addLog("TagVal.getPart():void, ex=" + ex.getMessage(), "", "TagVal");
		}
	}

	public TagVal(String Src) throws Exception {
		// origin - 26.09.2024, last edit - 18.06.2025
		this.clear();
		this.src = Etc.fixTrim(Src);
		this.getPart();
	}

	public TagVal() throws Exception {
		// origin - 26.09.2024, last edit - 18.06.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 18.06.2025, last edit - 06.09.2025
		try {
			this.id = this.src = this.tag = this.val = "";
		} catch (Exception ex) {
			WB.addLog("TagVal.clear():void, ex=" + ex.getMessage(), "", "TagVal");
		}
	}

	public String toString() {
		// origin - 26.09.2024, last edit - 15.04.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("id ", this.id);
			res = res + Fmtr.addAnyway(", src ", this.src);
			res = res + Fmtr.addAnyway(", tag ", this.tag);
			res = res + Fmtr.addAnyway(", val ", this.val);
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 26.09.2024, last edit - 15.04.2026
		try {

//			WB.addLog2("TagVal.test.getList(String):List<TagVal>", "", "TagVal");
//			for (var tmp1 : new String[] { "Quantity=1.00;Amount=25000.0;",
//					"FullName=Asset.Docu.Test.1;<AnnualMeeting=CostForDinner>;",
//					"FullName=Asset.Docu.Test.2;<Арматура12>;<AnnualMeeting=Other>;" }) {
//				var tmp2 = TagVal.getList(tmp1);
//				WB.addLog2("TagVal.test.getList(String):List<TagVal>, res.size=" + tmp2.size() + ", tmp1=" + tmp1, "",
//						"TagVal");
//				WB.log(tmp2, "TagVal");
//			}

//			WB.addLog2("TagVal.test.ctor(String), res=" + new TagVal("<AnnualMeeting=CostForDinner>"), "", "TagVal");

//			WB.addLog2("TagVal.test.containsTagVal(String):boolean", "", "TagVal");
//			WB.addLog2("TagVal.test.containsTagVal(String):boolean, res=" + TagVal.containsTagVal(tagVal1.src)
//					+ ", inStr=<AnnualMeeting=CostForDinner>", "", "TagVal");

//			WB.addLog2("TagVal.test.delTagVal(String):String", "", "TagVal");
//			String probeStr = "12000 Unit.KZT <AnnualMeeting=CostForDinner>";
//			WB.addLog2("TagVal.test.delTagVal(String):String, res=" + TagVal.delTagVal(probeStr) + ", probeStr=" + probeStr,"", "TagVal");

//			WB.addLog2("TagVal.test.matchTag(2String):boolean", "", "TagVal");
//			WB.addLog2("TagVal.test.matchTag(2String):boolean, res=" + TagVal.matchTag(tagVal1.src, "AnnualMeeting") + ", tagVal1.src="
//					+ tagVal1.src + ", findTag=AnnualMeeting", "", "TagVal");
//			WB.addLog2("TagVal.test.matchTag(2String):boolean, res=" + TagVal.matchTag(tagVal1.src, "Annual") + ", tagVal1.src="
//					+ tagVal1.src + ", findTag=Annual", "", "TagVal");

		} catch (Exception ex) {
			WB.addLog("TagVal.test():void, ex=" + ex.getMessage(), "", "TagVal");
		}
	}
}