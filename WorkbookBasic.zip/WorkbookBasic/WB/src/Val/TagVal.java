import java.util.List;

public class TagVal {
	// origin - 26.09.2024, last edit - 18.06.2025
	public String id, src, tag, val;
	private static List<String> listDelStr;

	static {
		try {
			TagVal.listDelStr = List.of("<", "=", ">");
		} catch (Exception ex) {
			WB.addLog("TagVal.static ctor, ex=" + ex.getMessage(), "", "TagVal");
		}
	}

	public static boolean matchTag(String inStr, String tag) throws Exception {
		// origin - 26.09.2024, last edit - 13.06.2025
		boolean res = false;
		inStr = Etc.fixString(inStr);
		try {
			if (TagVal.containsTagVal(inStr)) {
				TagVal probeTagVal = new TagVal(inStr);
				res = Etc.strEquals(probeTagVal.tag, tag);
			}

		} catch (Exception ex) {
			WB.addLog("TagVal.matchTag(String inStr, String tag):boolean, ex=" + ex.getMessage(), "", "TagVal");
		}
		return res;
	}

	public static boolean containsTagVal(String inStr) throws Exception {
		// origin - 26.09.2024, last edit - 13.06.2025
		boolean res = false;
		inStr = Etc.fixString(inStr);
		try {
			int posLocalStrLeftSplit = 999; // ?? magic string ??
			posLocalStrLeftSplit = inStr.indexOf("<"); // pos "<"
			int posLocalStrRightSplit = inStr.indexOf(">") + 1; // pos ">"

			if ((posLocalStrLeftSplit != 999) && (posLocalStrRightSplit > 0)) {
				// String probeStrTagVal = inStr.substring(posLocalStrLeftSplit,
				// posLocalStrRightSplit);
				// WB.addLog2("TagVal.containsTagVal, probeStrTagVal=" + probeStrTagVal,"",
				// "TagVal");
				// TagVal probeTagVal = new TagVal(probeStrTagVal);
				// if (ModelVal.isType(probeTagVal.src) == "TagVal") {
				res = true;
				// }
			}

		} catch (Exception ex) {
			WB.addLog("TagVal.containsTagVal(String inStr):boolean, ex=" + ex.getMessage(), "", "TagVal");
		}
		return res;
	}

	public static String delTagVal(String inStr) throws Exception {
		// origin - 26.09.2024, last edit - 13.06.2025
		String res = Etc.fixTrim(inStr);
		try {
			if (TagVal.containsTagVal(inStr)) {
				int posLocalStrLeftSplit = 999; // ?? magic string ??
				posLocalStrLeftSplit = inStr.indexOf("<"); // pos "<"
				int posLocalStrRightSplit = inStr.indexOf(">") + 1; // pos ">"

				if ((posLocalStrLeftSplit != 999) && (posLocalStrRightSplit > 0)) {
					String probeStrTagVal = inStr.substring(posLocalStrLeftSplit, posLocalStrRightSplit);
					res = Etc.delStr(res, probeStrTagVal);
					res = Etc.fixTrim(res);
				}
			}

		} catch (Exception ex) {
			WB.addLog("TagVal.delTagVal(String inStr):String, ex=" + ex.getMessage(), "", "TagVal");
		}
		return res;
	}

	private void getPart() throws Exception {
		// origin - 26.09.2024, last edit - 17.06.2025
		try {
			int posLocalStrMiddleEquation = this.src.indexOf("="); // pos "="
			if (posLocalStrMiddleEquation > 0) {
				// this is res
				this.tag = Etc.fixTrim(this.src.substring(0, posLocalStrMiddleEquation)); // ex.
																							// "<AnnualMeeting=CostForDinner>"
																							// --> "<AnnualMeeting="
				this.tag = Etc.delStr(this.tag, TagVal.listDelStr);
				this.val = Etc.fixTrim(this.src.substring(posLocalStrMiddleEquation));
				this.val = Etc.delStr(this.val, TagVal.listDelStr);
				this.id = this.tag + "=" + this.val;
			}
		} catch (Exception ex) {
			WB.addLog("TagVal.getPart():void, ex=" + ex.getMessage(), "", "TagVal");
		}
	}

	public TagVal(String Src) throws Exception {
		// origin - 26.09.2024, last edit - 18.06.2025
		this.clear();
		this.src = Etc.fixTrim(Src);
		this.getPart();
	}

	public TagVal() throws Exception {
		// origin - 26.09.2024, last edit - 18.06.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 18.06.2025, last edit - 06.09.2025
		try {
			this.id = this.src = this.tag = this.val = "";
		} catch (Exception ex) {
			WB.addLog("TagVal.clear():void, ex=" + ex.getMessage(), "", "TagVal");
		}
	}

	public String toString() {
		// origin - 26.09.2024, last edit - 18.06.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("id ", this.id);
			res = res + Fmtr.addAnyway(" src ", this.src);
			res = res + Fmtr.addAnyway(" tag ", this.tag);
			res = res + Fmtr.addAnyway(" val ", this.val);
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 26.09.2024, last edit - 18.06.2025
		try {

//			// test ctor(String)
//			WB.addLog2("TagVal.test.ctor(String), res=" + new TagVal("<AnnualMeeting=CostForDinner>"), "", "TagVal");

//			// containsTagVal
//			WB.addLog2("TagVal.test.containsTagVal, res=" + TagVal.containsTagVal(tagVal1.src)
//					+ ", inStr=<AnnualMeeting=CostForDinner>", "", "TagVal");

//			// delTagVal
//			String probeStr = "12000 Unit.KZT <AnnualMeeting=CostForDinner>";
//			WB.addLog2("TagVal.test.delTagVal, res=" + TagVal.delTagVal(probeStr) + ", probeStr=" + probeStr,"", "TagVal");

//			// matchTag
//			WB.addLog2("TagVal.test.matchTag, res=" + TagVal.matchTag(tagVal1.src, "AnnualMeeting") + ", tagVal1.src="
//					+ tagVal1.src + ", findTag=AnnualMeeting", "", "TagVal");
//			WB.addLog2("TagVal.test.matchTag, res=" + TagVal.matchTag(tagVal1.src, "Annual") + ", tagVal1.src="
//					+ tagVal1.src + ", findTag=Annual", "", "TagVal");

		} catch (Exception ex) {
			WB.addLog("TagVal.test():void, ex=" + ex.getMessage(), "", "TagVal");
		}
	}
}