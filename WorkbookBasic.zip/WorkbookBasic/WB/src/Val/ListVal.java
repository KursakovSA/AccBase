import java.util.ArrayList;
import java.util.List;

public final class ListVal {
	// origin - 16.07.2024, last edit - 30.11.2025
	public String id, context, src, srcCustom, partName, partVal, name, partUnit;
	public Unit unit;
	public List<String> val;
	private static List<String> listDelStr;

	static {
		try {
			ListVal.listDelStr = List.of("(", ")", "=");
		} catch (Exception ex) {
			WB.addLog("ListVal.static ctor, ex=" + ex.getMessage(), "", "ListVal");
		}
	}

	public void getUnit() throws Exception {
		// origin - 15.06.2025, last edit - 10.09.2026
		try {
			if (this.partUnit.isEmpty() == false) {
				this.unit = new Unit(this.partUnit);
				this.context = MoreVal.getFieldByKey(this.unit.more, "ExpectedValue");
			}
		} catch (Exception ex) {
			WB.addLog("ListVal.getUnit():void, ex=" + ex.getMessage(), "", "ListVal");
		}
	}

	// cut end match ListVal, ex. "one:two:two" -> "one:two"
	public static ListVal reduce(ListVal fromListVal) throws Exception {
		// origin - 09.06.2025, last edit - 13.06.2025
		ListVal res = fromListVal;
		String srcRes = "";
		try {
			if (fromListVal.val.size() > 1) {
				int maxValLessEndDubl = fromListVal.val.size();
				String delVal = fromListVal.val.getLast();
				String tmpEnd = "";
				String tmpPredEnd = "";
				for (int i = fromListVal.val.size(); i >= 2; i--) {
					tmpEnd = fromListVal.val.get(i - 1);
					tmpPredEnd = fromListVal.val.get(i - 2);

					if (Etc.strEquals(tmpEnd, delVal) == false) {
						break;
					}

					if (Etc.strEquals(tmpPredEnd, tmpEnd)) {
						maxValLessEndDubl = i - 1;
					}
				}

				if (maxValLessEndDubl < fromListVal.val.size()) {
					for (int i = 1; i <= maxValLessEndDubl; i++) {
						srcRes = srcRes + fromListVal.val.get(i - 1);
						if (i < maxValLessEndDubl) {
							srcRes = srcRes + ":";
						}
					}
					res = new ListVal(srcRes, "");
				}
			}
		} catch (Exception ex) {
			WB.addLog("ListVal.reduce(ListVal):ListVal, ex=" + ex.getMessage(), "", "ListVal");
		}
		return res;
	}

	public static ListVal ext(ListVal fromListVal, int toSize) throws Exception {
		// origin - 07.06.2025, last edit - 07.09.2026
		ListVal res = fromListVal;
		String srcRes = fromListVal.src;
		try {
			if (fromListVal.val.size() == 0) {
				return res;
			}

			if (toSize > fromListVal.val.size()) {
				var tmp = fromListVal.val.get(fromListVal.val.size() - 1);
				for (int i = fromListVal.val.size() + 1; i <= toSize; i++) {
					srcRes = srcRes + ":" + tmp;
				}
				res = new ListVal(srcRes, "");
			}
		} catch (Exception ex) {
			WB.addLog("ListVal.ext(ListVal, int):ListVal, ex=" + ex.getMessage(), "", "ListVal");
		}
		return res;
	}

	public static ListVal add(ListVal toAdd, String fromAdd) throws Exception {
		// origin - 29.05.2025, last edit - 18.10.2026
		ListVal res = toAdd;
		fromAdd = Etc.fixTrim(fromAdd);
		try {
			if (Etc.strNotValid(fromAdd)) {
				return res;
			}

			boolean isExist = false;
			for (var curr : toAdd.val) {
				if (Etc.strEquals(curr, fromAdd)) {
					isExist = true;
					break;
				}
			}

			if (isExist == false) {
				res = new ListVal(toAdd.src + ":" + fromAdd, "");
			}
		} catch (Exception ex) {
			WB.addLog("ListVal.add(ListVal, String):ListVal, ex=" + ex.getMessage(), "", "ListVal");
		}
		return res;
	}

	public String getByIndex(int index) throws Exception {
		// origin - 27.02.2025, last edit - 07.09.2026
		String res = "";
		try {
			if (index < 0) {
				return res;
			}

			if (index > val.size() - 1) {
				return res;
			}

			if (this.val.size() != 0) {
				if (index >= 0) {
					res = this.val.get(index);
				}
			}
		} catch (Exception ex) {
			WB.addLog("ListVal.getByIndex(int):String, ex=" + ex.getMessage(), "", "ListVal");
		}
		return res;
	}

	private void getPart() throws Exception {
		// origin - 03.01.2025, last edit - 17.06.2025
		try {
			String tmp = this.src;
			int posMiddleEquation = tmp.indexOf("="); // pos "="
			if (posMiddleEquation > 0) {
				this.partName = Etc.fixTrim(tmp.substring(0, posMiddleEquation));
//				WB.addLog2("ListVal.getPart, this.partName=" + this.partName + ", this.src=" + this.src,"", "ListVal");
				tmp = Etc.delStr(tmp, this.partName);
				tmp = Etc.delStr(tmp, "=");
			}

			int posLocalSplitValUnit = tmp.indexOf("(Unit.");
			if (posLocalSplitValUnit > 0) {
				this.partVal = Etc.fixTrim(tmp.substring(0, posLocalSplitValUnit));
				this.partUnit = Etc.fixTrim(tmp.substring(posLocalSplitValUnit));
				this.partUnit = Etc.delStr(this.partUnit, ListVal.listDelStr);
			}

			if (this.partUnit.isEmpty()) {
				this.partVal = Etc.fixTrim(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("ListVal.getPart():void, ex=" + ex.getMessage(), "", "ListVal");
		}
	}

	public ListVal(List<String> initListStr) throws Exception {
		// origin - 04.01.2025, last edit - 15.06.2025
		this.clear();
		this.src = initListStr.toString();
		if (initListStr.size() >= 0) {
			this.val = initListStr;
		}
		this.id = "[" + Fmtr.listVal(this.val, "") + "]";
		// this.id = this.id + " " + ", this.val.size " + this.val.size();
	}

	public ListVal(String initStr, String context) throws Exception {// context not use in code, only for different ctor
		// origin - 04.01.2025, last edit - 14.09.2026
		this.clear();
		initStr = Etc.fixTrim(initStr);
		this.src = initStr;
		this.getPart();
		this.getUnit();

		if (Etc.strMatch(this.partVal, ":") >= 0) {// this.partVal = "val1:val2:val3" etc.
			this.val = Fmtr.getListStrBySplit(this.partVal, ":");
		}

		this.id = "[" + Fmtr.listVal(this.val, "") + "]";
		if (this.partUnit.isEmpty() == false) {
			this.id = this.id + " " + this.unit.code + ", " + this.unit.description;
		}
		// this.id = this.id + " " + ", this.val.size " + this.val.size();
	}

	public ListVal(String initStr) throws Exception {
		// origin - 30.09.2024, last edit - 14.09.2026
		this.clear();
		initStr = Etc.fixTrim(initStr);
		this.src = MoreVal.getByKey(WB.abcLast.listVal, "AbcListVal", initStr);

		this.srcCustom = MoreVal.getByKey(WB.abcLast.custom, "Custom", initStr + ".Custom");
		if (this.srcCustom.isEmpty() == false) {
			this.src = this.src + ":" + this.srcCustom;
		}

		this.getPart();
		this.val = Fmtr.getListStrBySplit(this.partVal, ":");

		this.id = "[" + Fmtr.listVal(this.val, "") + "]";
		// this.id = this.id + " " + ", this.val.size " + this.val.size();
	}

	public ListVal() throws Exception {
		// origin - 04.09.2024, last edit - 15.06.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 15.06.2025, last edit - 06.09.2025
		try {
			this.id = this.context = this.src = this.srcCustom = this.partName = this.name = this.partVal = this.partUnit = "";
			this.unit = null;
			this.val = new ArrayList<String>();
		} catch (Exception ex) {
			WB.addLog("ListVal.clear():void, ex=" + ex.getMessage(), "", "ListVal");
		}
	}

	public String toString() {
		// origin - 03.01.2025, last edit - 25.09.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("id ", this.id);
			res = res + Fmtr.addAnyway(", src ", this.src);
			res = res + Fmtr.addAnyway(", srcCustom ", this.srcCustom);
			res = res + Fmtr.addAnyway(", context ", this.context);
			res = res + Fmtr.addAnyway(", val.size ", this.val.size());
			res = res + Fmtr.addAnyway(", val ", this.val);
		} catch (Exception ex) {
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 16.07.2024, last edit - 21.10.2026
		try {

//			WB.addLog2("ListVal.test.reduce(ListVal):ListVal", "", "ListVal");
//			for (var in : new String[] { "one:one", "one:two", "one:two:two", "one:two:three",
//					"one:two:three:three:three", "one:two:two:three:three:three" }) {
//				var tmp = ListVal.reduce(new ListVal(in, ""));
//				WB.addLog2("ListVal.test.reduce(ListVal):ListVal, res=" + tmp.id + ", in=" + in + ", out=" + tmp, "", "ListVal");
//			}

//			WB.addLog2("ListVal.test.ext(ListVal,int):ListVal", "", "ListVal");
//			ListVal tmp = new ListVal("one:two", "");
//			for (var tmp1 : new int[] { 1, 2, 3, 4 }) {
//				WB.addLog2(
//						"ListVal.test.ext(ListVal,int):ListVal, res=" + ListVal.ext(tmp, tmp1).val + ", src=" + tmp.val + ", toSize=" + tmp1,
//						"", "ListVal");
//			}

//			WB.addLog2("ListVal.test.add(ListVal,String):ListVal", "", "ListVal");
//			ListVal tmp = new ListVal("one:two", "");
//			for (var tmp1 : new String[] { "one", "two", "three" }) {
//				WB.addLog2("ListVal.test.add(ListVal,String):ListVal, res=" + ListVal.add(tmp, tmp1).val + ", toAdd=" + tmp.val + ", fromAdd="
//						+ tmp1, "", "ListVal");
//			}

//			WB.addLog2("ListVal.test.ctor(initStr)", "", "ListVal");
//			for (var tmp : new String[] { "Tralala", "Info.Code.Sex" }) {
//				WB.addLog2("ListVal.test.ctor(initStr)=" + new ListVal(tmp) + ", initStr=" + tmp, "", "ListVal");
//			}

//			WB.addLog2("ListVal.test.ctor(List<String>)", "", "ListVal");
//			List<String> listStr1 = new ArrayList<String>();
//			listStr1 = Fmtr.listVal("2025-01-23: 2025-02-14:", ":");
//			WB.addLog2("ListVal.test.ctor(List<String>)=" + new ListVal(listStr1), "", "ListVal");

//			WB.addLog2("ListVal.test.ctor(2String)", "", "ListVal");
//			for (var tmp1 : new String[] { "5-2 9-18:", "5-2 9-18", "2025-01-01: 2025-02-01", "2025-01-01: 2025-02-01:",
//					"2025-01-31:", "2025-01-31" }) {
//				WB.addLog2("ListVal.test.ctor(2String)=" + new ListVal(tmp1, ""), "", "ListVal");
//			}

//			WB.addLog2("ListVal.test.ctor(CommonExtraDayOff...)", "", "ListVal");
//			var tmp1 = new ListVal("CommonExtraDayOff=2022-01-08:2022-01-09(Unit.ExactDate)", "");
//			WB.addLog2("ListVal.test.ctor(initStr,context)=" + tmp1, "", "ListVal");
//			for (var partListVal1 : tmp1.val) {
//				WB.addLog2("ListVal.test.ctor, ListVal(LocalDate)=" + DateTool.getLocalDate(partListVal1), "",
//						"ListVal");
//			}

//			WB.addLog2("ListVal.test.ctor(PointBasicDayOff...)", "", "ListVal");
//			var tmp2 = new ListVal("PointBasicDayOff=2023-01-02/P1:2024-01-03/P2:2024-01-04/P4(Unit.ExactDate/Point)",
//					"");
//			WB.addLog2("ListVal.test.ctor(initStr,context)=" + tmp2, "", "ListVal");
//			for (var partListVal2 : tmp2.val) {
//				WB.addLog2("ListVal.test.ctor, ListVal(String)=" + partListVal2, "", "ListVal");
//			}

		} catch (Exception ex) {
			WB.addLog("ListVal.test():void, ex=" + ex.getMessage(), "", "ListVal");
		}
	}
}