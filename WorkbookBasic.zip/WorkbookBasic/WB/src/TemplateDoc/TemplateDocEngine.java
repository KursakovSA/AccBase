import java.util.ArrayList;
import java.util.List;

public final class TemplateDocEngine {
	// origin - 13.09.2025, last edit - 12.10.2025
	// private static List<ProcessVar> processVar;
	private static List<String> listDelStr;
	static {
		try {
			// TemplateDocEngine.processVar = ProcessVar.get();
			// WB.log(TemplateDocEngine.processVar, "TemplateDocEngine");
			TemplateDocEngine.listDelStr = List.of("[", "]");
		} catch (Exception ex) {
			WB.addLog("TemplateDocEngine.static ctor, ex=" + ex.getMessage(), "", "TemplateDocEngine");
		}
	}

	public static void set(String date1, String templateDocId, String docId) throws Exception { // TODO
		// origin - 14.06.2025, last edit - 24.09.2025
		try {
			// var inPattern = TemplateDocEngine.getPattern(templateDocId, docId);
			// var outPattern = TemplateDocEngine.setPattern(inPattern);
			// LinkedHashMap<String, String> mapPattern = new LinkedHashMap<String,
			// String>();
		} catch (Exception ex) {
			WB.addLog("TemplateDocEngine.set(3String):void, ex=" + ex.getMessage(), "", "TemplateDocEngine");
		}
	}

	public static String setPattern(String date1, String pattern) throws Exception {
		// origin - 18.09.2025, last edit - 28.09.2025
		String res = "";
		pattern = Etc.delStr(pattern, TemplateDocEngine.listDelStr);
		try {
			switch (pattern) {
			case "FullName_CurrFA" -> res = FaceReg.getCurrFullName(date1, Face.currFA.id, "Info.Face.FullName");
			case "DocReg_CurrFA" -> res = FaceReg.getCurrDocReg(date1, Face.currFA.id, "Info.Face.FullName"); // ?? info
																												// diff
																												// ??
			case "BIN_CurrFA" -> res = Face.getGovId(Face.currFA.id, "BIN");
			case "IIN_CurrFA" -> res = Face.getGovId(Face.currFA.id, "IIN");
			case "RNN_CurrFA" -> res = Face.getGovId(Face.currFA.id, "RNN");
			case "IdKZ_CurrFA" -> res = Face.getGovId(Face.currFA.id, "IdKZ");
			case "LawAddress_CurrFA" -> res = Address.getCurr(date1, Face.currFA.id, "Info.Code.LawAddress").more;
			case "RegAddress_CurrFA" -> res = Address.getCurr(date1, Face.currFA.id, "Info.Code.RegAddress").more;
			default -> res = "";
			}
//			if (Etc.strEquals(pattern, "FullName_CurrFA")) {
//				res = FaceReg.getCurrFullName(date1, Face.currFA.id, "Info.Face.FullName");
//			}
//			if (Etc.strEquals(pattern, "DocReg_CurrFA")) {
//				res = FaceReg.getCurrDocReg(date1, Face.currFA.id, "Info.Face.FullName"); // ?? info diff ??
//			}
		} catch (Exception ex) {
			WB.addLog("TemplateDocEngine.setPattern(2String):String, ex=" + ex.getMessage(), "", "TemplateDocEngine");
		}
		res = Etc.fixTrim(res);
		return res;
	}

	public static List<String> setPattern(String date1, List<String> pattern) throws Exception { // ?? need ??
		// origin - 20.09.2025, last edit - 28.09.2025
		List<String> res = new ArrayList<String>();
		try {
			for (var currPattern : pattern) {
				res.add(TemplateDocEngine.setPattern(date1, currPattern));
			}
		} catch (Exception ex) {
			WB.addLog("TemplateDocEngine.setPattern(String,List<String>):List<String>, ex=" + ex.getMessage(), "",
					"TemplateDocEngine");
		}
		return res;
	}

	public static List<ProcessVar> getPattern(String date1, String templateDocId, String docId) throws Exception { // TODO
		// origin - 14.09.2025, last edit - 28.09.2025
		List<ProcessVar> res = new ArrayList<ProcessVar>();
		try {
			res = ProcessVar.getByInfo("Info.Process.Pattern");
		} catch (Exception ex) {
			WB.addLog("TemplateDocEngine.getPattern(3String):List<ProcessVar>, ex=" + ex.getMessage(), "",
					"TemplateDocEngine");
		}
		return res;
	}

	private TemplateDocEngine() throws Exception {
		// origin - 13.11.2025, last edit - 13.09.2025
		this.clear();
	}

	private void clear() throws Exception { // TODO
		// origin - 13.09.2025, last edit - 13.09.2025
		try {
		} catch (Exception ex) {
			WB.addLog("TemplateDocEngine.clear():void, ex=" + ex.getMessage(), "", "TemplateDocEngine");
		}
	}

	public static void test() throws Exception {
		// origin - 13.09.2025, last edit - 13.11.2025
		try {

			WB.addLog2("TemplateDocEngine.test.getPattern(3String):List<ProcessVar>", "", "TemplateDocEngine"); // TODO
			WB.log(TemplateDocEngine.getPattern("2024-05-24", "", ""), "TemplateDocEngine");

//			WB.addLog2("TemplateDocEngine.test.setPattern(List<String>):List<String>", "", "TemplateDocEngine");
//			for (var tmp1 : new String[] { "2024-05-24", "2025-01-31", "2025-02-20", "2025-08-15" }) {
//				var tmp2 = List.of("[FullName_CurrFA]", "BIN_CurrFA", "Tralala_CurrFA");
//				WB.addLog2("TemplateDocEngine.test.getPattern(List<String>):List<String>, res="
//						+ TemplateDocEngine.setPattern(tmp1, tmp2) + ", date1=" + tmp1 + ", list pattern=" + tmp2, "",
//						"TemplateDocEngine");
//			}

//			WB.addLog2("TemplateDocEngine.test.setPattern(String):String", "", "TemplateDocEngine");
//			for (var tmp1 : new String[] { "2024-05-24", "2025-01-31", "2025-02-20", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "[FullName_CurrFA]", "FullName_CurrFA", "Face_Tralala" }) {
//					WB.addLog2("TemplateDocEngine.test.getPattern(String):String, res="
//							+ TemplateDocEngine.setPattern(tmp1, tmp2) + ", date1=" + tmp1 + ", pattern=" + tmp2, "",
//							"TemplateDocEngine");
//				}
//			}

//			WB.addLog2("TemplateDocEngine.test.get(String):void", "", "TemplateDocEngine"); //TODO
//			for (var tmp1 : new String[] { "TemplatePawnDoc1.mht", "З2.mht" }) {
//				WB.addLog2("TemplateDocEngine.test.get(String):void=" + ", templateId=" + tmp1, "", "TemplateDocEngine");
//				TemplateDocEngine.get(tmp1);
//			}

		} catch (Exception ex) {
			WB.addLog("TemplateDocEngine.test():void, ex=" + ex.getMessage(), "", "TemplateDocEngine");
		}
	}
}