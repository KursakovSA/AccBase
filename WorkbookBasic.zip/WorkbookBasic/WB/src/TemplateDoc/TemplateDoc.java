import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class TemplateDoc {
	// origin - 06.12.2023, last edit - 18.09.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, date1, date2, face1, face2, face, code, description, geo, role, info, more,
			mark;
	// special fields
	public String fullName, comment, templateId, termId, docId;
	public static String expectedDir;

	static {
		try {
			TemplateDoc.expectedDir = WB.templateDocDir;
		} catch (Exception ex) {
			WB.addLog("TemplateDoc.static ctor, ex=" + ex.getMessage(), "", "TemplateDoc");
		}
	}

	public List<String> getMatch(String file, String pattern) throws Exception { // TODO
		// origin - 18.09.2025, last edit - 18.09.2025
		LocalDateTime localStart = WB.getLocalStart();
		List<String> res = new ArrayList<String>();
		int countRow = 0;
		try {
			try (BufferedReader br = new BufferedReader(new FileReader(file, StandardCharsets.UTF_8))) {
				String line;
				while ((line = br.readLine()) != null) {
					countRow = countRow + 1;
					if (Etc.strContains(line, pattern)) {
						res.add(String.valueOf(countRow));
						// WB.addLog2("TemplateDoc.getMatch, res=" + countRow, "", "TemplateDoc");
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("TemplateDoc.getMatch(2String):List<String>, ex=" + ex.getMessage(), "", "TemplateDoc");
		}
		WB.getLocalEnd("TemplateDoc.getMatch, res=" + res + ",file=" + file + ", pattern=" + pattern + ", countRow="
				+ countRow, localStart);
		WB.addLog2("TemplateDoc.getMatch, res=" + res + ", file=" + file + ", pattern=" + pattern + ", countRow="
				+ countRow, "", "TemplateDoc");
		return res;
	}

	public String getSource(String fileName) throws Exception {
		// origin - 18.09.2025, last edit - 18.09.2025
		String res = "";
		try {
			res = TemplateDoc.expectedDir + File.separator + fileName;
		} catch (Exception ex) {
			WB.addLog("TemplateDoc.getSource(String):String, ex=" + ex.getMessage() + ", fileName=" + fileName, "",
					"TemplateDoc");
		}
		return res;
	}

	@SuppressWarnings("unused")
	public static void getCurrById(String date1, String templateDealId, String docId) throws Exception { // TODO
		// origin - 16.09.2025, last edit - 18.09.2025
		// List<String> res = new ArrayList<String>();
		try {
			// var modelDtoList = DAL.getByTemplate(WB.lastConnWork,
			// Qry.getIdInfoFilter(templateDealId, "Info.Deal.Term"),
			// "Deal");
			// var dealDtoList = DealDto.get(modelDtoList);
			// var tmp = DealDto.getChrono(DateTool.getLocalDate(date1), dealDtoList);
			// if (tmp.size() != 0) {
			// for (var curr : tmp) {
			var tmp = new TemplateDoc(templateDealId, docId);
			// if (tmp2.description.isEmpty() == false) {
			// res.addAll(Fmtr.listVal(tmp2.description, " "));
			// }
			// }
			// }
		} catch (Exception ex) {
			WB.addLog("TemplateDoc.getCurrById(String):void>, ex=" + ex.getMessage(), "", "TemplateDoc");
		}
		// return res;
	}

	private void isValid() throws Exception {
		// origin - 08.09.2025, last edit - 15.09.2025
		try {
			if (this.isExist) {
				if (this.description.isEmpty() == false) {
					this.isValid = true;
				}
			}
		} catch (Exception ex) {
			WB.addLog("TemplateDoc.isValid():void, ex=" + ex.getMessage(), "", "TemplateDoc");
		}
	}

	private void isExist() throws Exception {
		// origin - 06.09.2025, last edit - 18.09.2025
		try {
			var tmp = new TemplateDocTerm(this.id);
			this.code = tmp.code;
			this.parent = tmp.parent;
			this.date1 = tmp.date1;
			this.date2 = tmp.date2;
			this.face1 = tmp.face1;
			this.face2 = tmp.face2;
			this.face = tmp.face;
			this.description = tmp.description;
			this.geo = tmp.geo;
			this.role = tmp.role;
			this.info = tmp.info;
			this.more = tmp.more;
			this.getFieldFromMore();
			this.isExist = true;

			if (tmp.description.isEmpty()) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
				this.isExist = false;
			}
		} catch (Exception ex) {
			WB.addLog("TemplateDoc.isExist():void, ex=" + ex.getMessage(), "", "TemplateDoc");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 06.09.2025, last edit - 16.09.2025
		try {
			this.templateId = MoreVal.getFieldByKey(this.more, "TemplateId");
			this.termId = MoreVal.getFieldByKey(this.more, "TermId");
		} catch (Exception ex) {
			WB.addLog("TemplateDoc.getFieldFromMore():void, ex=" + ex.getMessage(), "", "TemplateDoc");
		}
	}

	private void clear() throws Exception {
		// origin - 06.09.2025, last edit - 16.09.2025
		try {
			this.isValid = false;
			this.isExist = false;
			this.table = "Deal";
			this.id = this.parent = this.date1 = this.date2 = this.face1 = this.face2 = this.face = this.code = this.description = "";
			this.geo = this.role = this.info = this.more = this.mark = "";
			this.fullName = this.comment = this.templateId = this.termId = this.docId = "";
		} catch (Exception ex) {
			WB.addLog("TemplateDoc.clear():void, ex=" + ex.getMessage(), "", "TemplateDoc");
		}
	}

	public TemplateDoc(String TemplateDealId, String DocId) throws Exception {
		// origin - 06.09.2025, last edit - 16.09.2025
		this.clear();
		this.src = TemplateDealId;
		this.id = TemplateDealId;
		this.docId = DocId;
		this.isExist();
		this.isValid();
	}

	public TemplateDoc() throws Exception {
		// origin - 06.12.2023, last edit - 06.09.2025
		this.clear();
	}

	public String toString() {
		// origin - 16.09.2025, last edit - 16.09.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code.length());
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", templateId ", this.templateId);
			res = res + Fmtr.addIfNotEmpty(", termId ", this.termId);
			res = res + Fmtr.addIfNotEmpty(", docId ", this.docId);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 06.12.2023, last edit - 16.09.2025
		try {

			WB.addLog2("TemplateDoc.test.ctor(String)", "", "TemplateDoc");
			for (var tmp1 : new String[] { "", "PawnDoc.Template1.V1", "Deal.Tralala" }) {
				for (var tmp2 : new String[] { "", "Bill", "Invoice" }) {
					WB.addLog2("TemplateDoc.test.ctor(String)=" + new TemplateDoc(tmp1, tmp2) + ", templateDealId="
							+ tmp1 + ", docId=" + tmp2, "", "TemplateDoc");
				}
			}

		} catch (Exception ex) {
			WB.addLog("TemplateDoc.test():void, ex=" + ex.getMessage(), "", "TemplateDoc");
		}
	}
}