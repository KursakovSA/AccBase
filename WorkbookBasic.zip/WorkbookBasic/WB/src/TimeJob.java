public class TimeJob extends ModelDto {
	// origin - 14.01.2024, last edit - 12.09.2024

	public String everyYear = new String();// TOTHINK
	public String everyQuartier = new String();// TOTHINK
	public String everyMonth = new String();// TOTHINK
	public String everyWeek = new String();// TOTHINK
	public String everyDay = new String();// TOTHINK
	public String everyHour = new String();// TOTHINK
	public String everyMinute = new String();// TOTHINK
	public String everySecond = new String();// TOTHINK

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("TimeJob.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "TimeJob");
		} finally {
			Etc.doNothing();
		}
	}

	public TimeJob() throws Exception {
		// origin - 14.01.2024, last edit - 05.09.2024
		super();
	}

	public static void test() throws Exception {
		// origin - 14.01.2024, last edit - 16.09.2024
		try {

		} catch (Exception ex) {
			WB.addLog("TimeJob.test, ex=" + ex.getMessage(), WB.strEmpty, "TimeJob");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("TimeJob.test end ", WB.strEmpty, "TimeJob");
	}

}
