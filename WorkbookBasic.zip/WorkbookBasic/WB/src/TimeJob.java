public class TimeJob extends ModelDto {
	// origin - 14.01.2024, last edit - 12.11.2024

	public String everyYear = WB.strEmpty;// TOTHINK
	public String everyQuartier = WB.strEmpty;// TOTHINK
	public String everyMonth = WB.strEmpty;// TOTHINK
	public String everyWeek = WB.strEmpty;// TOTHINK
	public String everyDay = WB.strEmpty;// TOTHINK
	public String everyHour = WB.strEmpty;// TOTHINK
	public String everyMinute = WB.strEmpty;// TOTHINK
	public String everySecond = WB.strEmpty;// TOTHINK

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("TimeJob.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "TimeJob");
		} finally {
			Etc.doNothing();
		}
	}

	public TimeJob() throws Exception {
		// origin - 14.01.2024, last edit - 05.09.2024
		super();
	}

	public static void test() throws Exception {
		// origin - 14.01.2024, last edit - 16.09.2024
		try {

		} catch (Exception ex) {
			WB.addLog("TimeJob.test, ex=" + ex.getMessage(), WB.strEmpty, "TimeJob");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("TimeJob.test end ", WB.strEmpty, "TimeJob");
	}

}
