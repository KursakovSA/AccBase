import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unused")
public final class StopList {
	// origin - 23.08.2024, last edit - 12.10.2025
	private String id = ""; // "BorrowerId", etc.//TOTHINK
	private String table = "";
	private Boolean idMilitaryService = false;
	private String fileNameCommon = "stoplist1.csv";
	private List<ModelDto> position = new ArrayList<ModelDto>();

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("StopList.static ctor, ex=" + ex.getMessage(), "", "StopList");
		}
	}

	private boolean listed(LocalDate dateNow, String idPerson) throws Exception {// TODO
		// origin - 24.08.2024, last edit - 13.06.2025
		boolean res = false;
		try {
			// res = ModelDto.getValueField(segmentAbc, idListVal, codeListVal,
			// ListVal.defaultListVal);
		} catch (Exception ex) {
			WB.addLog("StopList.listed(LocalDate dateNow, String idPerson):boolean, ex=" + ex.getMessage(), "",
					"StopList");
		}
		return res;
	}

	public StopList() throws Exception {
		// origin - 23.08.2024, last edit - 26.08.2024
		this.idMilitaryService = true;
	}

	public static void test() throws Exception {
		// origin - 23.08.2024, last edit - 13.06.2025
		try {

		} catch (Exception ex) {
			WB.addLog("StopList.test():void, ex=" + ex.getMessage(), "", "StopList");
		}
	}
}