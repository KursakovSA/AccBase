import java.util.List;

public final class TemplateDocVar {
	// origin - 02.04.2026, last edit - 27.04.2026
	public static List<String> listId;

	static {
		TemplateDocVar.listId = List.of("", "CurrDate", "Line", "BankAccount", "FullName", "DocReg", "BIN", "IIN",
				"IdKAZ", "LawAddress", "RegAddress", "BossSign", "ChiefAccountantSign", "IBAN", "BIC", "SPL", "Amount"); //not complete
		try {
		} catch (Exception ex) {
			WB.addLog("TemplateDocVar.static ctor, ex=" + ex.getMessage(), "", "TemplateDocVar");
		}
	}

	private TemplateDocVar() throws Exception {
		// origin - 02.04.2026, last edit - 27.04.2026
	}

	public static void test() throws Exception {
		// origin - 02.04.2026, last edit - 27.04.2026
		try {

		} catch (Exception ex) {
			WB.addLog("TemplateDocVar.test():void, ex=" + ex.getMessage(), "", "TemplateDocVar");
		}
	}
}