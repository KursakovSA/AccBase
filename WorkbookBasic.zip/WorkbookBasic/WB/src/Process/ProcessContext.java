import java.util.ArrayList;
import java.util.List;

public final class ProcessContext {
	// origin - 06.04.2026, last edit - 28.04.2026
	public String src, table, id, parent, face1, face2, face, slice, date1, date2, code, description, geo, sign,
			account, asset, deal, item, debt, role, info, meter, meterValue, unit, more, mark;
	public String defect, fullName, comment;
	// list common + special + timestamp fields in unified val
	public List<FullDto> lowerList, upperList;
	static {
		try {
		} catch (Exception ex) {
			WB.addLog("ProcessContext.static ctor, ex=" + ex.getMessage(), "", "ProcessContext");
		}
	}

//	public String get(String processVar) throws Exception { // TODO
//		// origin - 06.04.2026, last edit - 28.04.2026
//		String res = "";
//		try {
//			var tmp = "";
//			tmp = MoreVal.getFieldByKey(this.more, processVar); // ?? what from this.more ??
//			if (tmp.isEmpty() == false) {
//				res = tmp;
//			}
//		} catch (Exception ex) {
//			WB.addLog("ProcessContext.get(String):String, ex=" + ex.getMessage(), "", "ProcessContext");
//		}
//		return res;
//	}

//	private void get() throws Exception { // TODO
//		// origin - 06.04.2026, last edit - 27.04.2026
//		try {
//			var tmp = "";
//
//			for (var curr : ProcessVar.listId) {
//				tmp = "";
//				tmp = MoreVal.getFieldByKey(this.id, curr); // from this.id
//				if (tmp.isEmpty() == false) {
//					this.more = this.more + MoreVal.setPartMore(curr, tmp);
//				}
//
//				if (tmp.isEmpty()) {
//					tmp = this.getIfEmpty(curr);
//					if (tmp.isEmpty() == false) {
//						this.more = this.more + MoreVal.setPartMore(curr, tmp);
//					}
//				}
//			}
//		} catch (Exception ex) {
//			WB.addLog("ProcessContext.get():String, ex=" + ex.getMessage(), "", "ProcessContext");
//		}
//	}

//	private String getIfEmpty(String processVar) throws Exception { // TODO
//		// origin - 06.04.2026, last edit - 27.04.2026
//		String res = "";
//		try {
//			switch (processVar) {
//			case "CurrFA" -> res = Face.currFA.id;
//			case "CurrDate" -> res = DateTool.getNow().toString();
//
//			default -> res = processVar + "=?";
//			}
//		} catch (Exception ex) {
//			WB.addLog("ProcessContext.getIfEmpty(String):String, ex=" + ex.getMessage(), "", "ProcessContext");
//		}
//		res = Etc.fixTrim(res);
//		return res;
//	}

	private void validate() throws Exception { // TODO
		// origin - 06.04.2026, last edit - 08.04.2026
		try {
		} catch (Exception ex) {
			WB.addLog("ProcessContext.validate():void, ex=" + ex.getMessage(), "", "ProcessContext");
		}
	}

	private void isExist() throws Exception {
		// origin - 27.04.2026, last edit - 28.04.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), "Process");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.date1 = DefVal.setCustom(this.date1, dto.date1);
				this.date2 = DefVal.setCustom(this.date2, dto.date2);
				this.slice = DefVal.setCustom(this.slice, dto.slice);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.face1 = DefVal.setCustom(this.face1, dto.face1);
				this.face2 = DefVal.setCustom(this.face2, dto.face2);
				this.face = DefVal.setCustom(this.face, dto.face);
				this.parent = DefVal.setCustom(this.parent, dto.parent);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.sign = DefVal.setCustom(this.sign, dto.sign);
				this.account = DefVal.setCustom(this.account, dto.account);
				this.geo = DefVal.setCustom(this.geo, dto.geo);
				this.asset = DefVal.setCustom(this.asset, dto.asset);
				this.deal = DefVal.setCustom(this.deal, dto.deal);
				this.item = DefVal.setCustom(this.item, dto.item);
				this.debt = DefVal.setCustom(this.debt, dto.debt);
				this.role = DefVal.setCustom(this.role, dto.role);
				this.info = DefVal.setCustom(this.info, dto.info);
				this.meter = DefVal.setCustom(this.meter, dto.meter);
				this.unit = DefVal.setCustom(this.unit, dto.unit);
				this.meterValue = DefVal.setCustom(this.meterValue, dto.meterValue);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.mark = DefVal.setCustom(this.mark, dto.mark);
				this.upperList = FullDto.getUpper(this.table, this.parent);
				this.lowerList = FullDto.getLower(this.table, this.id);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.unit = "";
			}
		} catch (Exception ex) {
			WB.addLog("ProcessContext.isExist():void, ex=" + ex.getMessage(), "", "ProcessContext");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 27.04.2026, last edit - 27.04.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("ProcessContext.getFieldFromMore():void, ex=" + ex.getMessage(), "", "ProcessContext");
		}
	}

//	public ProcessContext(Process process) throws Exception { // TODO //??workbookDto ??modelDto ??
//		// origin - 06.04.2026, last edit - 27.04.2026
//		this.clear();
//		
//		this.get();
//		this.validate();
//	}

	public ProcessContext(String Id) throws Exception { // TODO
		// origin - 06.04.2026, last edit - 28.04.2026
		this.clear();
		this.table = "Process";
		this.src = this.id = Etc.fixTrim(Id);
		this.isExist();
		// this.get(); // ??
		this.validate();
	}

	public ProcessContext() throws Exception {
		// origin - 06.04.2026, last edit - 06.04.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 06.04.2026, last edit - 28.04.2026
		try {
			this.table = "Process";
			this.src = this.id = this.parent = this.face1 = this.face2 = "";
			this.face = this.slice = this.date1 = this.date2 = this.code = this.description = "";
			this.sign = this.account = this.geo = this.role = this.info = this.meter = this.meterValue = "";
			this.unit = this.more = this.mark = this.asset = this.deal = this.defect = "";
			this.fullName = this.comment = "";
			this.lowerList = new ArrayList<FullDto>();
			this.upperList = new ArrayList<FullDto>();
		} catch (Exception ex) {
			WB.addLog("ProcessContext.clear():void, ex=" + ex.getMessage(), "", "ProcessContext");
		}
	}

	public String toString() {
		// origin - 06.04.2026, last edit - 30.04.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", slice ", this.slice);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", geo ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", sign ", this.sign);
			res = res + Fmtr.addIfNotEmpty(", account ", this.account);
			res = res + Fmtr.addIfNotEmpty(", asset ", this.asset);
			res = res + Fmtr.addIfNotEmpty(", deal ", this.deal);
			res = res + Fmtr.addIfNotEmpty(", item ", this.item);
			res = res + Fmtr.addIfNotEmpty(", debt ", this.debt);
			res = res + Fmtr.addIfNotEmpty(", role ", this.role);
			res = res + Fmtr.addIfNotEmpty(", info ", this.info);
			res = res + Fmtr.addIfNotEmpty(", meter ", this.meter);
			res = res + Fmtr.addIfNotEmpty(", meterValue ", this.meterValue);
			res = res + Fmtr.addIfNotEmpty(", unit ", this.unit);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", mark ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(" upperList ", this.upperList.size());
			res = res + Fmtr.addIfNotEmpty(" lowerList ", this.lowerList.size());
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 06.04.2026, last edit - 07.04.2026
		try {

//			WB.addLog2("ProcessContext.test.ctor(String)", "", "ProcessContext");
//			for (var tmp1 : new String[] { "", "User=Admin" }) {
//				WB.addLog2("ProcessContext.test.ctor(String)=" + new ProcessContext(tmp1) + ", tmp1=" + tmp1, "",
//						"ProcessContext");
//			}

		} catch (Exception ex) {
			WB.addLog("ProcessContext.test():void, ex=" + ex.getMessage(), "", "ProcessContext");
		}
	}
}