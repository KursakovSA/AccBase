import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Workbook {
	// origin - 28.09.2023, last edit - 10.09.2026
	public String src, table, id, parent, face1, face2, face, slice, date1, date2, code, description, sign, account;
	public String geo, role, info, debt, item, meter, meterValue, unit, more, mark, process, asset, deal, defect;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Workbook.static ctor, ex=" + ex.getMessage(), "", "Workbook");
		}
	}

	public static FullDto getFullDtoByList(List<String> in) throws Exception {
		// origin - 02.03.2026, last edit - 02.03.2026
		FullDto res = new FullDto();
		try {
			res.table = "Workbook";
			res.id = Etc.fixTrim(in.get(0));
			res.parent = Etc.fixTrim(in.get(1));
			res.face1 = Etc.fixTrim(in.get(2));
			res.face2 = Etc.fixTrim(in.get(3));
			res.face = Etc.fixTrim(in.get(4));
			res.slice = Etc.fixTrim(in.get(5));
			res.date1 = Etc.fixTrim(in.get(6));
			res.date2 = Etc.fixTrim(in.get(7));
			res.code = Etc.fixTrim(in.get(8));
			res.description = Etc.fixTrim(in.get(9));
			res.geo = Etc.fixTrim(in.get(10));
			res.sign = Etc.fixTrim(in.get(11));
			res.account = Etc.fixTrim(in.get(12));
			res.process = Etc.fixTrim(in.get(13));
			res.asset = Etc.fixTrim(in.get(14));
			res.deal = Etc.fixTrim(in.get(15));
			res.role = Etc.fixTrim(in.get(16));
			res.info = Etc.fixTrim(in.get(17));
			res.meter = Etc.fixTrim(in.get(18));
			res.meterValue = Etc.fixTrim(in.get(19));
			res.unit = Etc.fixTrim(in.get(20));
			res.more = Etc.fixTrim(in.get(21));
			res.mark = Etc.fixTrim(in.get(22));
		} catch (Exception ex) {
			WB.addLog("Workbook.getFullDtoByList(List<String>):FullDto, ex=" + ex.getMessage(), "", "Workbook");
		}
		return res;
	}

	public static List<String> getListByFullDto(FullDto in) throws Exception {
		// origin - 31.01.2026, last edit - 01.03.2026
		List<String> res = new ArrayList<String>();
		try {
			res.add(in.id);
			res.add(in.parent);
			res.add(in.face1);
			res.add(in.face2);
			res.add(in.face);
			res.add(in.slice);
			res.add(in.date1);
			res.add(in.date2);
			res.add(in.code);
			res.add(in.description);
			res.add(in.geo);
			res.add(in.sign);
			res.add(in.account);
			res.add(in.process);
			res.add(in.asset);
			res.add(in.deal);
			res.add(in.role);
			res.add(in.info);
			res.add(in.meter);
			res.add(in.meterValue);
			res.add(in.unit);
			res.add(in.more);
			res.add(in.mark);
		} catch (Exception ex) {
			WB.addLog("Workbook.getByTable(FullDto):List<String>, ex=" + ex.getMessage(), "", "Workbook");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 22.11.2025, last edit - 22.11.2025
		try {
		} catch (Exception ex) {
			WB.addLog("Workbook.validate():void, ex=" + ex.getMessage(), "", "Workbook");
		}
	}

	private void fix() throws Exception { // TODO
		// origin - 29.12.2024, last edit - 01.05.2026
		try {
			this.slice = DefVal.set(this.slice, "Slice.Accounting");
			this.date1 = DefVal.set(this.date1, WB.minDateSupported.toString());
			this.date2 = DefVal.set(this.date2, WB.maxDateSupported.toString());
			this.mark = DefVal.set(this.mark, "Mark.DD");
		} catch (Exception ex) {
			WB.addLog("Workbook.fix():void, ex=" + ex.getMessage(), "", "Workbook");
		}
	}

	public static FullDto getTotal(List<FullDto> listFullDto) throws Exception { // TODO
		// origin - 15.07.2026, last edit - 15.07.2026
		FullDto res = new FullDto();
		try {
//			for (var currPawn : listWorkbookDto) {
//				// WB.addLog2("Pawn.getTotal(List<Pawn>):Pawn, currPawn=" + currPawn,"",
//				// "Pawn");
//				res.weightGross = UnitVal.add(res.weightGross, currPawn.weightGross);
//				res.weightNetto = UnitVal.add(res.weightNetto, currPawn.weightNetto);
//				res.weightCarat = UnitVal.add(res.weightCarat, currPawn.weightCarat);
//				res.estimatedValue = UnitVal.add(res.estimatedValue, currPawn.estimatedValue);
//				res.partMainDebt = UnitVal.add(res.partMainDebt, currPawn.partMainDebt);
//			}
		} catch (Exception ex) {
			WB.addLog("Workbook.getTotal(List<FullDto>):FullDto, ex=" + ex.getMessage(), "", "Workbook");
		}
		return res;
	}

	public static List<FullDto> getTurn1(String date1, String kindAnalyst1) throws Exception {// TODO
		// origin - 30.04.2026, last edit - 30.04.2026
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			LocalDate tmp1 = DateTool.getLocalDate(date1);
			var tmp2 = Workbook.getTurn1(kindAnalyst1);
			res = FullDto.getChrono(tmp1, tmp2);
		} catch (Exception ex) {
			WB.addLog("Workbook.getTurn1(2String):List<FullDto>, ex=" + ex.getMessage(), "", "Workbook");
		}
		return res;
	}

	private static List<FullDto> getTurn1(String kindAnalyst1) throws Exception {
		// origin - 30.04.2026, last edit - 02.05.2026
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			res = DAL.getByTemplate(WB.lastConnWork, Qry.getKindAnalyst1Filter(kindAnalyst1), "Workbook");
		} catch (Exception ex) {
			WB.addLog("Workbook.getTurn1(String):List<FullDto>, ex=" + ex.getMessage(), "", "Workbook");
		}
		return res;
	}

//	public static double getRest(LocalDate date1, LocalDate date2, FullDto filter) throws Exception {// TODO
//		// origin - 18.10.2023, last edit - 19.03.2025
//		// find rest Debt on currDate
//		// currContext may be equals -- "VAT.Sum", "VAT.Base.Sum", "VAT.Base.MaxLimit",
//		// "IncomePersonTax.Dediction".... etc.
//		double res = 0.0;
//		// TODO - here need do get processRateVAT from WorkDatabase.sqlite3
//		res = Etc.roundCustom(res);
//		return res;
//	}

	public Workbook(String Id) throws Exception { // TODO
		// origin - 05.12.2023, last edit - 01.05.2026
		this.clear();
		this.src = this.id = Id;
		this.fix();
		this.validate();
	}

	public Workbook() throws Exception {
		// origin - 05.12.2023, last edit - 11.08.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 01.05.2025, last edit - 10.09.2026
		try {
			this.table = "Workbook";
			this.src = this.id = this.parent = this.face1 = this.face2 = "";
			this.face = this.slice = this.date1 = this.date2 = this.code = this.description = "";
			this.sign = this.account = this.geo = this.role = this.info = this.meter = this.meterValue = "";
			this.unit = this.more = this.mark = this.process = this.asset = this.deal = this.defect = "";
		} catch (Exception ex) {
			WB.addLog("Workbook.clear():void, ex=" + ex.getMessage(), "", "Workbook");
		}
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 01.07.2026
		try {

			WB.addLog2("Workbook.test.getTurn1(2String)", "", "Workbook");
			for (var tmp1 : new String[] { "Asset", "Face2" }) {
				for (var tmp2 : new String[] { "2026-03-15", "2026-04-20", "2026-04-25", "2026-04-26", "2026-04-28",
						"2026-04-30", "2026-05-12" }) {
					var tmp3 = Workbook.getTurn1(tmp2, tmp1);
					WB.addLog2("Workbook.test.getTurn1(2String), res.size=" + tmp3.size() + ", tmp1=" + tmp1 + ", tmp2="
							+ tmp2, "", "Workbook");
					WB.log(tmp3, "Workbook");
				}
			}

//			WB.addLog2("Workbook.test.getTurn1(String)", "", "Workbook");
//			for (var tmp1 : new String[] { "Asset", "Deal", "Face2" }) {
//				var tmp2 = Workbook.getTurn1(tmp1);
//				WB.addLog2("Workbook.test.getTurn1(String), res.size=" + tmp2.size() + ", tmp1=" + tmp1, "",
//						"Workbook");
//				WB.log(tmp2, "Workbook");
//			}

		} catch (Exception ex) {
			WB.addLog("Workbook.test():void, ex=" + ex.getMessage(), "", "Workbook");
		}
	}
}