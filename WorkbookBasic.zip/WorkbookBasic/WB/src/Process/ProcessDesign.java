import java.util.ArrayList;
import java.util.List;

public final class ProcessDesign {
	// origin - 18.07.2026, last edit - 18.07.2026
	public String table, id, parent, date1, date2, code, description, role, more, fullName, comment, defect;
	public Process root;
	public List<Process> designVar;
	public List<Process> designOperation;
	public List<Process> designResult;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("ProcessDesign.static ctor, ex=" + ex.getMessage(), "", "ProcessDesign");
		}
	}

	public static UnitVal get(String date1, String pattern) throws Exception { // TODO
		// origin - 26.07.2026, last edit - 03.09.2026
		UnitVal res = new UnitVal();
		try {
			switch (pattern) {
			case "Area_Rectangle" -> res = Product.getAreaRectangle(null, null, pattern); // TODO
//			case "Volume_Service" -> res = Product.getRatioVolume(res, res, pattern); // TODO
//			case "BIN_CurrFA" -> res = Face.getGovId(Face.currFA.id, "BIN");
//			case "IIN_CurrFA" -> res = Face.getGovId(Face.currFA.id, "IIN");

//			default -> res = Etc.doNothing();
			}
		} catch (Exception ex) {
			WB.addLog("ProcessDesign.get(2String):UnitVal, ex=" + ex.getMessage() + ", pattern=" + pattern, "",
					"ProcessDesign");
		}
		return res;
	}

	private void fix() throws Exception { // TODO
		// origin - 18.07.2026, last edit - 18.07.2026
		try {
		} catch (Exception ex) {
			WB.addLog("ProcessDesign.fix():void, ex=" + ex.getMessage(), "", "ProcessDesign");
		}
	}

	private void validate() throws Exception {
		// origin - 18.07.2026, last edit - 18.07.2026
		try {
			if (this.designVar.size() == 0) {
				this.defect = this.defect + "empty design var; ";
			}
		} catch (Exception ex) {
			WB.addLog("ProcessDesign.validate():void, ex=" + ex.getMessage(), "", "ProcessDesign");
		}
	}

	private void isExist() throws Exception {
		// origin - 18.07.2026, last edit - 18.07.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdRoleFilter(this.id, "Role.Process.Design"),
					this.table);
			if (listDto.size() != 0) {
				var currDto1 = listDto.getFirst();
				this.id = DefVal.setCustom(this.id, currDto1.id);
				this.parent = DefVal.setCustom(this.parent, currDto1.parent);
				this.date1 = DefVal.setCustom(this.date1, currDto1.date1);
				this.date2 = DefVal.setCustom(this.date2, currDto1.date2);
				this.code = DefVal.setCustom(this.code, currDto1.code);
				this.description = DefVal.setCustom(this.description, currDto1.description);
				this.role = DefVal.setCustom(this.role, currDto1.role);
				this.more = DefVal.setCustom(this.more, currDto1.more);

				var currDto2 = FullDto.getLower(this.table, this.id);
				for (var tmp2 : currDto2) {
					if (Etc.strEquals(tmp2.role, "Role.Process.DesignVar")) {
						this.designVar.add(new Process(tmp2.id));
					}
					if (Etc.strEquals(tmp2.role, "Role.Process.DesignOperation")) {
						this.designOperation.add(new Process(tmp2.id));
					}
				}
			}

			if (listDto.size() == 0) {
				this.id = this.defect = "";
			}
		} catch (Exception ex) {
			WB.addLog("ProcessDesign.isExist():void, ex=" + ex.getMessage(), "", "ProcessDesign");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 18.07.2026, last edit - 18.07.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "Fullname");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("ProcessDesign.getFieldFromMore():void, ex=" + ex.getMessage(), "", "ProcessDesign");
		}
	}

	public ProcessDesign(String Id) throws Exception {
		// origin - 18.07.2026, last edit - 18.07.2026
		this.clear();
		this.id = Etc.fixTrim(Id);
		this.isExist();
		this.getFieldFromMore();
		this.fix();
		this.validate();
	}

	private void clear() throws Exception {
		// origin - 18.07.2026, last edit - 18.07.2026
		try {
			this.table = "Process";
			this.id = this.parent = this.code = this.date1 = this.date2 = this.code = this.description = this.defect = "";
			this.role = this.more = this.fullName = this.comment = "";
			this.root = new Process();
			this.designVar = new ArrayList<Process>();
			this.designOperation = new ArrayList<Process>();
			this.designResult = new ArrayList<Process>();
		} catch (Exception ex) {
			WB.addLog("ProcessDesign.clear():void, ex=" + ex.getMessage(), "", "ProcessDesign");
		}
	}

	public ProcessDesign() throws Exception {
		// origin - 18.07.2026, last edit - 18.07.2026
		this.clear();
	}

	public String toString() {
		// origin - 18.07.2026, last edit - 18.07.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", role ", this.role);
			res = res + Fmtr.addIfNotEmpty(", root ", this.root);
			res = res + Fmtr.addIfNotEmpty(", designVar.size ", this.designVar.size());
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", more.lenght ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 18.07.2026, last edit - 08.08.2026
		try {

//			WB.addLog2("ProcessDesign.test.ctor(String)", "", "ProcessDesign");
//			for (var tmp1 : new String[] { "", "Process.Entry", "Process.Design.Test.1", "Process.Design.Tralala" }) {
//				WB.addLog2("ProcessDesign.test.ctor(String), res=" + new ProcessDesign(tmp1), "", "ProcessDesign");
//			}

		} catch (Exception ex) {
			WB.addLog("ProcessDesign.test():void, ex=" + ex.getMessage(), "", "ProcessDesign");
		}
	}
}