import java.util.ArrayList;
import java.util.List;

public final class Geo {
	// origin - 28.09.2023, last edit - 22.11.2025
	// common fields
	public String table, src, id, parent, date1, date2, code, description, role, more, defect;
	// special fields
	public List<ModelDto> lower, upper;
	public static Geo currCountry;
	private static String roleCountry;
	public String fullName, comment, codeAlfa2, codeAlfa3, codeNumber, currency;

	static {
		try {
			Geo.roleCountry = "Role.Geo.Country";
			Geo.currCountry = new Geo("Geo.Qazaqstan");
			// WB.addLog2("Geo.currCountry=" + Geo.currCountry, "", "Geo");
		} catch (Exception ex) {
			WB.addLog("Geo.static ctor, ex=" + ex.getMessage(), "", "Geo");
		}
	}

//	private static List<ModelDto> getLower(List<ModelDto> srcList, String code) throws Exception {
//		// origin - 18.12.2024, last edit - 01.05.2025
//		List<ModelDto> res = new ArrayList<ModelDto>();
//		List<ModelDto> tmpLower1 = new ArrayList<ModelDto>();
//		tmpLower1 = ReadSet.getEqualsByParent(srcList, code); // direct lower 1 level
//		List<ModelDto> tmpLower2 = new ArrayList<ModelDto>(); // lower 2 level
//		boolean foundNewLowerCode = true;
//
//		try {
//			for (;;) { // endless cycle
//				foundNewLowerCode = false;
//				tmpLower2.clear();
//
//				for (var currL1 : tmpLower1) {
//					tmpLower2.addAll(ReadSet.getEqualsByParent(srcList, currL1.code));
//				}
//
//				for (var currL2 : tmpLower2) {
//					if (ModelDto.isContains(tmpLower1, currL2) == false) {
//						tmpLower1.add(currL2);
////					WB.addLog2("ModelDto.getLower, add currL2.code=" + currL2.code + ", for this.code=" + this.code,"", "Debt");
//						foundNewLowerCode = true;
//					}
//				}
//
//				if (foundNewLowerCode == false) {
//					break;
//				}
//			}
//
//			res.addAll(tmpLower1);
//		} catch (Exception ex) {
//			WB.addLog("Geo.getLower, ex=" + ex.getMessage(), "", "Geo");
//		}
//		return res;
//	}

//	private static List<ModelDto> getUpper(List<ModelDto> srcList, String parent) throws Exception {
//		// origin - 17.12.2024, last edit - 01.05.2025
//		List<ModelDto> res = new ArrayList<ModelDto>();
//		String tmpParentCode = parent;
//		List<ModelDto> tmpUpper = new ArrayList<ModelDto>();
//		boolean foundNewParentCode = true;
//
//		try {
//			for (;;) {// endless cycle
//				foundNewParentCode = false;
//				for (var currLst : srcList) {
//					if (Etc.strEquals(currLst.code, tmpParentCode)) {
//						if (ModelDto.isContains(tmpUpper, currLst) == false) {
//							tmpUpper.add(currLst);
////							WB.addLog2("Debt.getUpper, add currLst.code=" + currLst.code + ", tmpParentCode="
////									+ tmpParentCode + ", for this.code=" + this.code, "", "Debt");
//							tmpParentCode = currLst.parent;
//							foundNewParentCode = true;
//							break;
//						}
//					}
//				}
//				if (foundNewParentCode == false) {
//					break;
//				}
//			}
//			// this.upper.addAll(tmpUpper);
//			res.addAll(tmpUpper);
//		} catch (Exception ex) {
//			WB.addLog("Geo.getUpper, ex=" + ex.getMessage(), "", "Geo");
//		}
//		return res;
//	}

	public static List<String> getCurrencyPair() throws Exception {// select pairs kind "USD-KZT", "EUR-KZT", etc.
		// origin - 01.03.2025, last edit - 14.06.2025
		List<String> res = new ArrayList<String>();
		try {
			for (var curr1 : Geo.getCurrency()) {
				if (Etc.strEquals(curr1, Unit.currCurrency.description)) {// skip pairs kind "KZT-?"
					continue;
				}
				for (var curr2 : Geo.getCurrency()) {
					if (Etc.strEquals(curr2, curr1)) {// skip pairs kind "EUR-EUR"
						continue;
					}
					if (Etc.strEquals(curr2, Unit.currCurrency.description) == false) {// skip pairs kind "?-EUR, USD"
						continue;
					}
					var tmp = curr1 + "-" + curr2;
					res.add(tmp); // "USD-KZT", "EUR-KZT", etc.
					// WB.addLog2("Geo.getCurrencyPair, add tmp=" + tmp, "", "Geo");
				}
			}
		} catch (Exception ex) {
			WB.addLog("Geo.getCurrencyPair():List<String>, ex=" + ex.getMessage() + ", res=" + res, "", "Geo");
		}
		return res;
	}

	public static List<String> getCurrency() throws Exception {
		// origin - 19.02.2025, last edit - 14.08.2025
		List<String> res = new ArrayList<String>();
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getMoreFilter("Currency"), "Geo");
			String tmpCurrency = "";
			for (var curr : listDto) {
				tmpCurrency = MoreVal.getFieldByKey(curr.more, "Currency"); // ??magic string??
				if (tmpCurrency.isEmpty() == false) {
					Unit tmpUnit = new Unit(tmpCurrency);
					res.add(tmpUnit.description); // description = "USD", "KZT", etc.
				}
			}
		} catch (Exception ex) {
			WB.addLog("Geo.getCurrency():List<String>, ex=" + ex.getMessage() + ", res=" + res, "", "Geo");
		}
		return res;
	}
	
	private void validate() throws Exception { // TODO
		// origin - 22.11.2025, last edit - 22.11.2025
		try {
		} catch (Exception ex) {
			WB.addLog("Geo.validate():void, ex=" + ex.getMessage(), "", "Geo");
		}
	}

	public String getCountry() throws Exception {
		// origin - 27.11.2024, last edit - 14.06.2025
		String res = "";
		try {
			if (Etc.strEquals(this.role, Geo.roleCountry)) {
				res = this.code;
			} else {

				Geo tmp = new Geo(this.parent);
				while (Etc.strEquals(tmp.role, Geo.roleCountry) == false) {
					if (tmp.parent.isEmpty()) {
						// tmp = new Geo("Geo.Qazaqstan");
						break;
					} else {
						tmp = new Geo(tmp.parent);
					}
				}
				res = tmp.code;
			}

		} catch (Exception ex) {
			WB.addLog("Geo.getCountry():String, ex=" + ex.getMessage() + ", res=" + res, "", "Geo");
		}
		return res;
	}

	private void isExist() throws Exception {
		// origin - 26.11.2024, last edit - 22.11.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.code), "Geo");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.code = dto.code;
				this.parent = dto.parent;
				this.description = dto.description;
				this.role = dto.role;
				this.more = dto.more;
				var listGeo = DAL.getTable(WB.lastConnWork, Qry.getText(WB.lastConnWork, "Geo", ""));
				this.upper = ModelDto.getUpper(listGeo, this.parent);
				this.lower = ModelDto.getLower(listGeo, this.code);
				this.getFieldFromMore();
			}
		} catch (Exception ex) {
			WB.addLog("Geo.isExist():void, ex=" + ex.getMessage(), "", "Geo");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 12.08.2025, last edit - 12.08.2025
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.codeAlfa2 = MoreVal.getFieldByKey(this.more, "CodeAlfa2");
			this.codeAlfa3 = MoreVal.getFieldByKey(this.more, "CodeAlfa3");
			this.codeNumber = MoreVal.getFieldByKey(this.more, "CodeNumber");
			this.currency = MoreVal.getFieldByKey(this.more, "Currency");
		} catch (Exception ex) {
			WB.addLog("Deal.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	public Geo(String Id) throws Exception {
		// origin - 26.11.2024, last edit - 22.11.2025
		this.clear();
		this.src = Id;
		if (Id.isEmpty() == false) {
			this.id = this.code = Id;
		}
		this.isExist();
		this.validate();
	}

	public Geo() throws Exception {
		// origin - 27.11.2024, last edit - 19.05.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 26.11.2024, last edit - 22.11.2025
		try {
			this.table = "Geo";
			this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.role = this.more = this.defect = "";
			this.fullName = this.comment = this.codeAlfa2 = this.codeAlfa3 = this.codeNumber = this.currency = "";
			this.lower = new ArrayList<ModelDto>();
			this.upper = new ArrayList<ModelDto>();
		} catch (Exception ex) {
			WB.addLog("Geo.clear():void, ex=" + ex.getMessage(), "", "Geo");
		}
	}

	public String toString() {
		// origin - 26.11.2023, last edit - 22.11.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", upper ", this.upper.size());
			res = res + Fmtr.addIfNotEmpty(", lower ", this.lower.size());
			res = res + Fmtr.addIfNotEmpty(", currency ", this.currency);
			res = res + Fmtr.addIfNotEmpty(", codeAlfa2 ", this.codeAlfa2);
			res = res + Fmtr.addIfNotEmpty(", codeAlfa3 ", this.codeAlfa3);
			res = res + Fmtr.addIfNotEmpty(", codeNumber ", this.codeNumber);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 14.06.2025
		try {

//			// ctor (String)
//			WB.addLog2("Geo.test.ctor(String)", "", "Geo");
//			WB.addLog2("Geo.test.ctor(String)", "", "Geo");
//			for (var tmp : new String[] { "", "Geo.Qazaqstan", "Geo.tralala", "Geo.SaryArka", "Geo.Astana" }) {
//				WB.addLog2("Geo.test.ctor(String)=" + new Geo(tmp), "", "Geo");
//			}

//			// get country
//			WB.addLog2("Geo.test.getCountry", "", "Geo");
//			for (var tmp : new String[] {"", "Geo.Qazaqstan", "Geo.tralala", "Geo.SaryArka"}) {
//				WB.addLog2("Geo.test.getCountry=" + argGeo.getCountry() + ", argGeo=" + argGeo, "", "Geo");
//			}

		} catch (Exception ex) {
			WB.addLog("Geo.test():void, ex=" + ex.getMessage(), "", "Geo");
		}
	}
}