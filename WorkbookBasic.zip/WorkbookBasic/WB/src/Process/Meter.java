public class Meter {
	// origin - 28.09.2023, last edit - 01.05.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, date1, date2, code, description, more;
	// special fields
	public String expectedValue;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Meter.static ctor, ex=" + ex.getMessage(), "", "Meter");
		}
	}

	public void isExist() throws Exception {
		// origin - 08.10.2024, last edit - 13.06.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.code), "Meter");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.code = dto.code;
				this.description = dto.description;
				this.parent = dto.parent;
				this.more = dto.more;
				this.expectedValue = MoreVal.getFieldByKey(this.more, "AbcExpectedValue");
				this.isExist = true;
			}
		} catch (Exception ex) {
			WB.addLog("Meter.isExist():void, ex=" + ex.getMessage(), "", "Meter");
		}
	}

	public Meter(String Id) throws Exception {
		// origin - 05.12.2023, last edit - 11.08.2025
		this.clear();
		this.src = Id;
		if (Id.isEmpty() == false) {
			this.id = this.code = Id;
		}
		this.isExist();
	}

	public Meter() throws Exception {
		// origin - 05.12.2023, last edit - 19.05.2025
		this.clear();
	}

	public void clear() throws Exception {
		// origin - 21.12.2024, last edit - 13.06.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = "Meter";
			this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.more = "";
		} catch (Exception ex) {
			WB.addLog("Meter.clear():void, ex=" + ex.getMessage(), "", "Meter");
		}
	}

	public String toString() {
		// origin - 21.12.2024, last edit - 01.05.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = res + Fmtr.addIfNotEmpty(", expectedValue ", this.expectedValue);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 13.06.2025
		try {

//			// ctor (String)
//			WB.addLog2("Meter.test.ctor(String)", "", "Meter");
//			for (var tmp : new String[] { "", "Meter.Amount", "Meter.tralala", "Meter.GrossWeight/NetWeight" }) {
//				WB.addLog2("Meter.test.ctor(String)=" + new Meter(tmp), "", "Meter");
//			}

		} catch (Exception ex) {
			WB.addLog("Meter.test():void, ex=" + ex.getMessage(), "", "Meter");
		}
	}
}