import java.util.ArrayList;
import java.util.List;

public final class Account {
	// origin - 27.09.2023, last edit - 21.11.2025
	// common fields
	public String table, src, id, parent, slice, date1, date2, code, description, role, sign, more, defect;
	// special fields
	public static String currStandardTable;
	public String fullName, comment, accountTable, codeMatch, identificationCode;

	static {
		try {
			Account.currStandardTable = Account.getCurrStandardTable();
		} catch (Exception ex) {
			WB.addLog("Account.static ctor, ex=" + ex.getMessage(), "", "Account");
		}
	}

	public static List<String> getByTable(ModelDto in) throws Exception {
		// origin - 31.01.2026, last edit - 31.01.2026
		List<String> res = new ArrayList<String>();
		try {
			res.add(in.id);
			res.add(in.parent);
			res.add(in.slice);
			res.add(in.date1);
			res.add(in.date2);
			res.add(in.code);
			res.add(in.description);
			res.add(in.role);
			res.add(in.sign);
			res.add(in.more);
		} catch (Exception ex) {
			WB.addLog("Account.getByTable(ModelDto):List<String>, ex=" + ex.getMessage(), "", "Account");
		}
		return res;
	}

	public static List<ModelDto> get() throws Exception {
		// origin - 30.11.2025, last edit - 01.12.2025
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			res = DAL.getTable(WB.lastConnWork, Qry.getText(WB.lastConnWork, "Account", ""));
			// res.sort(Comparator.comparing(ModelDto::getSortAccount)); // TODO ??
		} catch (Exception ex) {
			WB.addLog("Account.get():List<ModelDto>, ex=" + ex.getMessage(), "", "Account");
		}
		return res;
	}

	public static List<ModelDto> getBySliceAccounting(String date1) throws Exception { // TODO
		// origin - 30.11.2025, last edit - 01.12.2025
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {

		} catch (Exception ex) {
			WB.addLog("Account.getBySliceAccounting(String):List<ModelDto>, ex=" + ex.getMessage(), "", "Account");
		}
		return res;
	}

	public static List<ModelDto> getCurrByStandardTable(String date1) throws Exception { // TODO
		// origin - 30.11.2025, last edit - 01.12.2025
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {

		} catch (Exception ex) {
			WB.addLog("Account.getCurrByStandardTable(String):List<ModelDto>, ex=" + ex.getMessage(), "", "Account");
		}
		return res;
	}

	public static String getCurrStandardTable() throws Exception {
		// origin - 15.12.2024, last edit - 13.06.2025
		String res = "";
		try {
			// for (var currRole : WB.abcLast.role) {
			var listRole = DAL.getTable(WB.lastConnWork, Qry.getText(WB.lastConnWork, "Role", ""));
			for (var currRole : listRole) {
				if (Etc.strContains(currRole.code, Role.accountStandardTable)) {// "Role.Account.AccTable")) {
					if (currRole.date1.isEmpty() && (currRole.date2.isEmpty())) {// skip work table, off balance table
						continue;
					}
					// skip not actual
					if ((currRole.date2.isEmpty() == false)
							&& (DateTool.getLocalDate(currRole.date2).isBefore(DateTool.getNow()))) {
						continue;
					}
					res = currRole.code;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Account.getCurrStandardTable():String, ex=" + ex.getMessage(), "", "Account");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 21.11.2025, last edit - 21.11.2025
		try {
		} catch (Exception ex) {
			WB.addLog("Account.validate():void, ex=" + ex.getMessage(), "", "Account");
		}
	}

	public void getRole() throws Exception {
		// origin - 12.12.2024, last edit - 13.06.2025
		try {
			if (this.role.isEmpty() && (this.parent.isEmpty() == false)) {
				Account accForRole = new Account(this.parent);
				if (accForRole.role.isEmpty() == false) {
					this.role = accForRole.role;
				}
			}

		} catch (Exception ex) {
			WB.addLog("Account.getRole():void, ex=" + ex.getMessage(), "", "Account");
		}
	}

	public void getMatch() throws Exception {
		// origin - 08.12.2024, last edit - 13.06.2025
		try {

			// direct match (Customer -> 1210)
			for (var currAccMatch : WB.abcGlobal.accountMatching) {
				if (Etc.strEquals(Etc.delStr(currAccMatch.code, "Matching."), this.code)) {
					// skip not actual
					if ((currAccMatch.date2.isEmpty() == false) && (DateTool.getLocalDate(currAccMatch.date2)
							.isBefore(DateTool.getLocalDate(this.date1)))) { // DateTool.getNow()
//					WB.addLog2("Account.getMatch, skip=" + currAccMatch + ", this.code=" + this.code, "","Account");
						continue;
					}
					this.codeMatch = currAccMatch.meterValue;
				}
			}

			// reverse match, actual not applicable (1210 -> Customer)
			if (this.codeMatch.isEmpty()) {
				for (var currAccMatch : WB.abcGlobal.accountMatching) {
					if (Etc.strEquals(currAccMatch.meterValue, this.code)) {
//						WB.addLog2("Account.getMatch, reverse match, find meterValue=" + currAccMatch.meterValue
//								+ ", this.code=" + this.code, "", "Account");
						this.codeMatch = Etc.delStr(currAccMatch.code, "Matching.");
//						WB.addLog2(
//								"Account.getMatch, reverse code match=" + this.codeMatch + ", this.code=" + this.code,"", "Account");
					}
				}
			}

			// cross reverse match (301 -> Customer -> 1210) ???

		} catch (Exception ex) {
			WB.addLog("Account.getMatch():void, ex=" + ex.getMessage(), "", "Account");
		}
	}

	private void isExist() throws Exception {
		// origin - 08.12.2024, last edit - 21.11.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), "Account");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.slice = DefVal.setCustom(this.slice, dto.slice);
				this.date1 = DefVal.setCustom(this.date1, dto.date1);
				this.date2 = DefVal.setCustom(this.date2, dto.date2);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.code = DefVal.setCustom(this.code, dto.id);
				this.parent = DefVal.setCustom(this.parent, dto.parent);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.role = DefVal.setCustom(this.role, dto.role);
				this.sign = DefVal.setCustom(this.sign, dto.sign);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.getFieldFromMore();
			}
		} catch (Exception ex) {
			WB.addLog("Account.isExist():void, ex=" + ex.getMessage(), "", "Account");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 12.08.2025, last edit - 12.08.2025
		try {
			this.accountTable = MoreVal.getFieldByKey(this.more, "AccountTable");
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("Deal.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	public void getIdCode() throws Exception {
		// origin - 30.06.2024, last edit - 13.06.2025
		String res = Etc.fixTrim(this.code);
		try {
			res = res.replace("Account.", "");
			res = res.replace("Account", "");
			this.identificationCode = res;
		} catch (Exception ex) {
			WB.addLog("Account.getIdCode():void, ex=" + ex.getMessage(), "", "Account");
		}
	}

	public Account(String Id) throws Exception {
		// origin - 05.12.2023, last edit - 21.11.2025
		this.clear();
		this.src = this.id = Id;
		// this.getMatch();
		this.isExist();
		this.getMatch();
		this.getRole();
		this.getIdCode();
		this.validate();
	}

	public Account() throws Exception {
		// origin - 04.12.2023, last edit - 19.05.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 09.12.2024, last edit - 21.11.2025
		try {
			this.table = "Account";
			this.id = this.parent = this.slice = this.date1 = this.date2 = this.code = this.description = "";
			this.role = this.sign = this.more = this.defect = "";
			this.fullName = this.comment = this.codeMatch = this.accountTable = this.identificationCode = "";
		} catch (Exception ex) {
			WB.addLog("Account.clear():void, ex=" + ex.getMessage(), "", "Account");
		}
	}

	public String toString() {
		// origin - 27.09.2024, last edit - 21.11.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", ", this.slice);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.sign);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addAnyway(", fullName ", this.fullName);
			res = res + Fmtr.addAnyway(", comment ", this.comment);
			res = res + Fmtr.addAnyway(", codeMatch ", this.codeMatch);
			res = res + Fmtr.addAnyway(", accountTable ", this.accountTable);
			res = res + Fmtr.addAnyway(", identificationCode ", this.identificationCode);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 01.12.2025
		try {

//			WB.addLog2("Account.test.get()", "", "Account");
//			var tmp = Account.get();
//			WB.addLog2("Account.test.get(), res.size=" + tmp.size(), "", "Account");
//			WB.addLog2("Account.test.get(), res.first=" + tmp.getFirst(), "", "Account");
//			WB.addLog2("Account.test.get(), res.last=" + tmp.getLast(), "", "Account");

//			WB.addLog2("Account.test.ctor(String)", "", "Account");
//			for (var tmp : new String[] { "Account.Customer", "Account.1210", "Account.301", "Account.tralala" }) {
//				WB.addLog2("Account.test.ctor(String)=" + new Account(tmp), "", "Account");
//			}

//			WB.addLog2("Account.test.ctor()", "", "Account");
//			WB.addLog2("Account.test.ctor()=" + new Account(), "", "Account");

		} catch (Exception ex) {
			WB.addLog("Account.test():void, ex=" + ex.getMessage(), "", "Account");
		}
	}
}