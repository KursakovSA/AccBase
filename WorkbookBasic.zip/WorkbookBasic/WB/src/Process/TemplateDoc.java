import java.io.BufferedReader;
import java.io.FileReader;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public final class TemplateDoc {
	// origin - 06.12.2023, last edit - 16.09.2026
	// common fields
	public String table, src, id, parent, date1, date2, face1, face2, face, code, description, geo, role, info, more,
			mark, defect;
	// special fields
	public String fullName, comment;
	public static List<String> nameList;

	static {
		AssetCat.nameList = List.of("TemplateId", "TermId", "DocId");
		try {
		} catch (Exception ex) {
			WB.addLog("TemplateDoc.static ctor, ex=" + ex.getMessage(), "", "TemplateDoc");
		}
	}

	public static List<String> getPattern(String templateDocId, String docId) throws Exception { // TODO
		// origin - 20.09.2025, last edit - 20.09.2025
		List<String> res = new ArrayList<String>();
		try {
			// var templateDocTerm = new TemplateDocTerm(templateId);
			// res = templateDocTerm.templateDoc;
		} catch (Exception ex) {
			WB.addLog("TemplateDoc.getPattern(2String):List<String>>, ex=" + ex.getMessage(), "", "TemplateDoc");
		}
		return res;
	}

	public List<String> getMatch(String file, String pattern) throws Exception { // TODO
		// origin - 18.09.2025, last edit - 18.09.2025
		LocalDateTime localStart = WB.getLocalStart();
		List<String> res = new ArrayList<String>();
		int countRow = 0;
		try {
			try (BufferedReader br = new BufferedReader(new FileReader(file, StandardCharsets.UTF_8))) {
				String line;
				while ((line = br.readLine()) != null) {
					countRow = countRow + 1;
					if (Etc.strContains(line, pattern)) {
						res.add(String.valueOf(countRow));
						// WB.addLog2("TemplateDoc.getMatch, res=" + countRow, "", "TemplateDoc");
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("TemplateDoc.getMatch(2String):List<String>, ex=" + ex.getMessage(), "", "TemplateDoc");
		}
		WB.getLocalEnd("TemplateDoc.getMatch, res=" + res + ",file=" + file + ", pattern=" + pattern + ", countRow="
				+ countRow, localStart);
		WB.addLog2("TemplateDoc.getMatch, res=" + res + ", file=" + file + ", pattern=" + pattern + ", countRow="
				+ countRow, "", "TemplateDoc");
		return res;
	}

	public String getSource(String fileName) throws Exception {
		// origin - 18.09.2025, last edit - 12.08.2026
		String res = "";
		try {
			// res = TemplateDoc.expectedDir + File.separator + fileName;
			res = InOut.getStrPathFileByFileNameInAppDir(fileName);
		} catch (Exception ex) {
			WB.addLog("TemplateDoc.getSource(String):String, ex=" + ex.getMessage() + ", fileName=" + fileName, "",
					"TemplateDoc");
		}
		return res;
	}

	@SuppressWarnings("unused")
	public static void getCurrById(String date1, String templateDealId, String docId) throws Exception { // TODO
		// origin - 16.09.2025, last edit - 18.09.2025
		// List<String> res = new ArrayList<String>();
		try {
			// var modelDtoList = DAL.getByTemplate(WB.lastConnWork,
			// Qry.getIdInfoFilter(templateDealId, "Info.Deal.Term"),
			// "Deal");
			// var dealDtoList = DealDto.get(modelDtoList);
			// var tmp = DealDto.getChrono(DateTool.getLocalDate(date1), dealDtoList);
			// if (tmp.size() != 0) {
			// for (var curr : tmp) {
			var tmp = new TemplateDoc(templateDealId, docId);
			// if (tmp2.description.isEmpty() == false) {
			// res.addAll(Fmtr.listVal(tmp2.description, " "));
			// }
			// }
			// }
		} catch (Exception ex) {
			WB.addLog("TemplateDoc.getCurrById(String):void>, ex=" + ex.getMessage(), "", "TemplateDoc");
		}
		// return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 08.09.2025, last edit - 10.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}
			
			this.defect = Fmtr.addIfStrEmpty(this.defect, this.description, "empty description; ");
		} catch (Exception ex) {
			WB.addLog("TemplateDoc.validate():void, ex=" + ex.getMessage(), "", "TemplateDoc");
		}
	}

	private void isExist() throws Exception {
		// origin - 06.09.2025, last edit - 16.09.2026
		try {
			var tmp = new TemplateDocTerm(this.id);
			this.code = tmp.code;
			this.parent = tmp.parent;
			this.date1 = tmp.date1;
			this.date2 = tmp.date2;
			this.face1 = tmp.face1;
			this.face2 = tmp.face2;
			this.face = tmp.face;
			this.description = tmp.description;
			this.geo = tmp.geo;
			this.role = tmp.role;
			this.info = tmp.info;
			this.more = tmp.more;
			this.getFieldFromMore();

			if (tmp.description.isEmpty()) {
				this.clear();
			}
		} catch (Exception ex) {
			WB.addLog("TemplateDoc.isExist():void, ex=" + ex.getMessage(), "", "TemplateDoc");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 06.09.2025, last edit - 16.09.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("TemplateDoc.getFieldFromMore():void, ex=" + ex.getMessage(), "", "TemplateDoc");
		}
	}

	private void clear() throws Exception {
		// origin - 06.09.2025, last edit - 16.09.2026
		try {
			this.table = "Deal";
			this.id = this.parent = this.date1 = this.date2 = this.face1 = this.face2 = this.face = this.code = this.description = "";
			this.geo = this.role = this.info = this.more = this.mark = this.defect = "";
			this.fullName = this.comment = "";
		} catch (Exception ex) {
			WB.addLog("TemplateDoc.clear():void, ex=" + ex.getMessage(), "", "TemplateDoc");
		}
	}

	public TemplateDoc(String TemplateDealId, String DocId) throws Exception {
		// origin - 06.09.2025, last edit - 16.09.2026
		this.clear();
		this.src = TemplateDealId;
		this.id = TemplateDealId;
		this.isExist();
		this.more = MoreVal.reset(this.more, "DocId", DocId);
		this.validate();
	}

	public TemplateDoc() throws Exception {
		// origin - 06.12.2023, last edit - 06.09.2025
		this.clear();
	}

	public String toString() {
		// origin - 16.09.2025, last edit - 16.09.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code.length());
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 06.12.2023, last edit - 11.03.2026
		try {

			WB.addLog2("TemplateDoc.test.ctor(String)", "", "TemplateDoc");
			for (var tmp1 : new String[] { "", "Deal.Face.Template1", "Deal.Tralala" }) {
				for (var tmp2 : new String[] { "", "Bill", "Invoice" }) {
					WB.addLog2("TemplateDoc.test.ctor(String)=" + new TemplateDoc(tmp1, tmp2) + ", tmp1="
							+ tmp1 + ", tmp2=" + tmp2, "", "TemplateDoc");
				}
			}

		} catch (Exception ex) {
			WB.addLog("TemplateDoc.test():void, ex=" + ex.getMessage(), "", "TemplateDoc");
		}
	}
}