import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;

public final class Process {
	// origin - 28.09.2023, last edit - 18.07.2026
	// common fields
	public String table, src, id, parent, date1, date2, face1, face2, face, slice, code, description;
	public String geo, sign, account, asset, deal, item, debt, role, info, meter, meterValue, unit, more, mark, defect;
	// special fields
	public String fullName, comment;
	public static LocalDate minDateSupported; // for doc record in app
	public static LocalDate maxDateSupported; // for doc record in app
	// list common + special + timestamp fields in unified val
	// public List<FullDto> lowerList, upperList;

	static {
		try {
			Process.minDateSupported = LocalDate.of(2000, Month.JANUARY, 01);
			Process.maxDateSupported = WB.maxDateSupported;
		} catch (Exception ex) {
			WB.addLog("Process.static ctor, ex=" + ex.getMessage(), "", "Process");
		}
	}

	public static FullDto getFullDtoByList(List<String> in) throws Exception {
		// origin - 02.03.2026, last edit - 20.07.2026
		FullDto res = new FullDto();
		try {
			res.table = "Process";
			res.id = Etc.fixTrim(in.get(0));
			res.parent = Etc.fixTrim(in.get(1));
			res.face1 = Etc.fixTrim(in.get(2));
			res.face2 = Etc.fixTrim(in.get(3));
			res.face = Etc.fixTrim(in.get(4));
			res.slice = Etc.fixTrim(in.get(5));
			res.date1 = Etc.fixTrim(in.get(6));
			res.date2 = Etc.fixTrim(in.get(7));
			res.code = Etc.fixTrim(in.get(8));
			res.description = Etc.fixTrim(in.get(9));
			res.geo = Etc.fixTrim(in.get(10));
			res.sign = Etc.fixTrim(in.get(11));
			res.account = Etc.fixTrim(in.get(12));
			res.asset = Etc.fixTrim(in.get(13));
			res.deal = Etc.fixTrim(in.get(14));
			res.item = Etc.fixTrim(in.get(15));
			res.debt = Etc.fixTrim(in.get(16));
			res.role = Etc.fixTrim(in.get(17));
			res.info = Etc.fixTrim(in.get(18));
			res.meter = Etc.fixTrim(in.get(19));
			res.meterValue = Etc.fixTrim(in.get(20));
			res.unit = Etc.fixTrim(in.get(21));
			res.more = Etc.fixTrim(in.get(22));
			res.mark = Etc.fixTrim(in.get(23));
		} catch (Exception ex) {
			WB.addLog("Process.getFullDtoByList(List<String>):FullDto, ex=" + ex.getMessage(), "", "Process");
		}
		return res;
	}

	public static List<String> getListByFullDto(FullDto in) throws Exception {
		// origin - 31.01.2026, last edit - 20.07.2026
		List<String> res = new ArrayList<String>();
		try {
			res.add(in.id);
			res.add(in.parent);
			res.add(in.face1);
			res.add(in.face2);
			res.add(in.face);
			res.add(in.slice);
			res.add(in.date1);
			res.add(in.date2);
			res.add(in.code);
			res.add(in.description);
			res.add(in.geo);
			res.add(in.sign);
			res.add(in.account);
			res.add(in.asset);
			res.add(in.deal);
			res.add(in.item);
			res.add(in.debt);
			res.add(in.role);
			res.add(in.info);
			res.add(in.meter);
			res.add(in.meterValue);
			res.add(in.unit);
			res.add(in.more);
			res.add(in.mark);
		} catch (Exception ex) {
			WB.addLog("Process.getListByFullDto(FullDto):List<String>, ex=" + ex.getMessage(), "", "Process");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 22.11.2025, last edit - 22.11.2025
		try {
		} catch (Exception ex) {
			WB.addLog("Process.validate():void, ex=" + ex.getMessage(), "", "Process");
		}
	}

	private List<FullDto> getFastListDto() throws Exception {
		// origin - 10.08.2026, last edit - 10.08.2026
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			var tmp = WB.abcLast.process;
			res = ReadSet.getEqualsByCode(tmp, this.code);
			if (res.size() == 0) {
				res = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.code), "Process");
			}
		} catch (Exception ex) {
			WB.addLog("Process.getFastListDto():void, ex=" + ex.getMessage(), "", "Process");
		}
		return res;
	}

	private void isExist() throws Exception {
		// origin - 29.09.2025, last edit - 10.08.2026
		try {
			// var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id),
			// "Process");
			var listDto = this.getFastListDto();
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.date1 = DefVal.setCustom(this.date1, dto.date1);
				this.date2 = DefVal.setCustom(this.date2, dto.date2);
				this.slice = DefVal.setCustom(this.slice, dto.slice);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.face1 = DefVal.setCustom(this.face1, dto.face1);
				this.face2 = DefVal.setCustom(this.face2, dto.face2);
				this.face = DefVal.setCustom(this.face, dto.face);
				this.parent = DefVal.setCustom(this.parent, dto.parent);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.sign = DefVal.setCustom(this.sign, dto.sign);
				this.account = DefVal.setCustom(this.account, dto.account);
				this.geo = DefVal.setCustom(this.geo, dto.geo);
				this.asset = DefVal.setCustom(this.asset, dto.asset);
				this.deal = DefVal.setCustom(this.deal, dto.deal);
				this.item = DefVal.setCustom(this.item, dto.item);
				this.debt = DefVal.setCustom(this.debt, dto.debt);
				this.role = DefVal.setCustom(this.role, dto.role);
				this.info = DefVal.setCustom(this.info, dto.info);
				this.meter = DefVal.setCustom(this.meter, dto.meter);
				this.unit = DefVal.setCustom(this.unit, dto.unit);
				this.meterValue = DefVal.setCustom(this.meterValue, dto.meterValue);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.mark = DefVal.setCustom(this.mark, dto.mark);
				// this.upperList = FullDto.getUpper(this.table, this.parent);
				// this.lowerList = FullDto.getLower(this.table, this.id);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.unit = "";
			}
		} catch (Exception ex) {
			WB.addLog("Process.isExist():void, ex=" + ex.getMessage(), "", "Process");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 29.09.2025, last edit - 29.09.2025
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("Process.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Process");
		}
	}

	public Process(String Id) throws Exception {
		// origin - 05.12.2023, last edit - 22.11.2025
		this.clear();
		this.table = "Process";
		this.src = this.id = Id;
		this.isExist();
		this.validate();
	}

	public Process() throws Exception {
		// origin - 05.12.2023, last edit - 19.05.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 29.12.2024, last edit - 18.07.2026
		try {
			this.table = "Process";
			this.src = this.id = this.parent = this.face1 = this.face2 = "";
			this.face = this.slice = this.date1 = this.date2 = this.code = this.description = "";
			this.sign = this.account = this.geo = this.role = this.info = this.meter = this.meterValue = "";
			this.item = this.debt = this.unit = this.more = this.mark = this.asset = this.deal = this.defect = "";
			this.fullName = this.comment = "";
			// this.lowerList = new ArrayList<FullDto>();
			// this.upperList = new ArrayList<FullDto>();
		} catch (Exception ex) {
			WB.addLog("Process.clear():void, ex=" + ex.getMessage(), "", "Process");
		}
	}

	public String toString() {
		// origin - 30.04.2026, last edit - 18.07.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", slice ", this.slice);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", geo ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", sign ", this.sign);
			res = res + Fmtr.addIfNotEmpty(", account ", this.account);
			res = res + Fmtr.addIfNotEmpty(", asset ", this.asset);
			res = res + Fmtr.addIfNotEmpty(", deal ", this.deal);
			res = res + Fmtr.addIfNotEmpty(", item ", this.item);
			res = res + Fmtr.addIfNotEmpty(", debt ", this.debt);
			res = res + Fmtr.addIfNotEmpty(", role ", this.role);
			res = res + Fmtr.addIfNotEmpty(", info ", this.info);
			res = res + Fmtr.addIfNotEmpty(", meter ", this.meter);
			res = res + Fmtr.addIfNotEmpty(", meterValue ", this.meterValue);
			res = res + Fmtr.addIfNotEmpty(", unit ", this.unit);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", mark ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			// res = res + Fmtr.addIfNotEmpty(" upperList ", this.upperList.size());
			// res = res + Fmtr.addIfNotEmpty(" lowerList ", this.lowerList.size());
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 30.04.2026
		try {

//			WB.addLog2("Process.test.ctor(String)", "", "Process");
//			for (var tmp1 : new String[] { "", "Process.Entry", "Process.Depr" }) {
//				WB.addLog2("Process.test.ctor(String)=" + new Process(tmp1) + ", tmp1=" + tmp1, "", "Process");
//			}

		} catch (Exception ex) {
			WB.addLog("Process.test():void, ex=" + ex.getMessage(), "", "Process");
		}
	}
}