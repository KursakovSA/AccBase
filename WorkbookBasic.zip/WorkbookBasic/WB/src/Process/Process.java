import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;

public final class Process {
	// origin - 28.09.2023, last edit - 22.11.2025
	// common fields
	public String table, src, id, parent, date1, date2, face1, face2, face, slice, code, description;
	public String geo, sign, account, asset, deal, item, debt, role, info, meter, meterValue, unit, more, mark, defect;
	// special fields
	public String fullName, comment;
	public static LocalDate minDateSupported; // for doc record in app
	public static LocalDate maxDateSupported; // for doc record in app
	public List<ModelDto> rule;
	public static String strPatternRule;
	public UnitVal performEvery, launchType;// performEvery ex. 23:00(Unit.EveryDay) / 23:00(Unit.EveryEndMonth)
											// launchType ex. Auto/Manual/OnDemand/Schedule/
	// list common + special + timestamp fields in unified val
	//public List<ProcessDto> val;
	public List<ModelDto> lower, upper;

	static {
		try {
			Process.strPatternRule = "Rule";
			Process.minDateSupported = LocalDate.of(2000, Month.JANUARY, 01);
			Process.maxDateSupported = WB.maxDateSupported;
		} catch (Exception ex) {
			WB.addLog("Process.static ctor, ex=" + ex.getMessage(), "", "Process");
		}
	}

	public static boolean getMatchRule(ModelDto contextProcess, ModelDto ruleProcess) throws Exception {// TOTHINK
		// origin - 01.08.2024, last edit - 13.06.2025
		boolean res = false;
		try {
			if ((Etc.strEquals(contextProcess.meter, ruleProcess.meter))
					&& (Etc.strEquals(contextProcess.unit, ruleProcess.unit))) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("Process.getMatchRule():boolean, ex=" + ex.getMessage(), "", "Process");
		}
		return res;
	}

	public static boolean checkRule(ModelDto contextProcess, ModelDto ruleProcess, String contextCheck)
			throws Exception {// TOTHINK
		// origin - 01.08.2024, last edit - 13.06.2025
		boolean res = true;
		try {
			if (getMatchRule(contextProcess, ruleProcess)) {

				if ((Etc.strEquals(contextCheck, "Info.Process.MaxLimit"))
						&& (Conv.getDouble(contextProcess.meterValue) > Conv.getDouble(ruleProcess.meterValue))) {
					res = false;
				}

				if ((Etc.strEquals(contextCheck, "Info.Process.MinLimit"))
						&& (Conv.getDouble(contextProcess.meterValue) < Conv.getDouble(ruleProcess.meterValue))) {
					res = false;
				}

				if ((Etc.strEquals(contextCheck, "Meter.Listed")) && // TODO get IIN
						(CSV.getMatch(ruleProcess.meterValue, contextProcess.face1).size() == 0)) {// meterValue="podft1.csv",
					// "podft2.csv"
					res = false;
				}

				if ((Etc.strEquals(contextCheck, "Meter.NotListed")) && // TODO get IIN
						(CSV.getMatch(ruleProcess.meterValue, contextProcess.face1).size() > 0)) {
					res = false;
				}

			}
		} catch (Exception ex) {
			WB.addLog("Process.checkRule():boolean, ex=" + ex.getMessage(), "", "Process");
		}
		return res;
	}

	public static boolean ruleIsValid(ModelDto contextProcess, ModelDto ruleProcess) throws Exception {
		// origin - 01.08.2024, last edit - 13.06.2025
		boolean res = true;
		try {

			if (Etc.strEquals(ruleProcess.info, "Info.Process.MaxLimit")) {
				res = Process.checkRule(contextProcess, ruleProcess, "Info.Process.MaxLimit");
			}
			if (Etc.strEquals(ruleProcess.info, "Info.Process.MinLimit")) {
				res = Process.checkRule(contextProcess, ruleProcess, "Info.Process.MinLimit");
			}
			if (Etc.strEquals(ruleProcess.meter, "Meter.Listed")) {
				res = Process.checkRule(contextProcess, ruleProcess, "Meter.Listed");
			}
			if (Etc.strEquals(ruleProcess.meter, "Info.Process.MinLimit")) {
				res = Process.checkRule(contextProcess, ruleProcess, "Meter.NotListed");
			}

		} catch (Exception ex) {
			WB.addLog("Process.ruleIsValid():boolean, ex=" + ex.getMessage(), "", "Process");
		}
		return res;
	}

	public static boolean contextIsValid(List<ModelDto> contextProcess, List<ModelDto> ruleProcess) throws Exception {
		// origin - 01.08.2024, last edit - 13.06.2025
		boolean res = true;
		try {
			for (var currRule : ruleProcess) {
				for (var currContext : contextProcess) {
					res = Process.ruleIsValid(currContext, currRule);
					if (res = false) {
						break;
					}
				}
				if (res = false) {
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Process.contextIsValid():boolean, ex=" + ex.getMessage(), "", "Process");
		}
		return res;
	}

	public static List<ModelDto> getRule(String parentProcessCode) throws Exception {
		// origin - 02.08.2024, last edit - 13.06.2025
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			res = ReadSet.getEqualsByCode(WB.abcLast.basic, Process.strPatternRule);
			res = ReadSet.getEqualsByParent(res, parentProcessCode);
		} catch (Exception ex) {
			WB.addLog("Process.getRule(String parentProcessCode):List<ModelDto>, ex=" + ex.getMessage(), "", "Process");
		}
		return res;
	}
	
	private void validate() throws Exception { // TODO
		// origin - 22.11.2025, last edit - 22.11.2025
		try {
		} catch (Exception ex) {
			WB.addLog("Process.validate():void, ex=" + ex.getMessage(), "", "Process");
		}
	}
	
	private void isExist() throws Exception {
		// origin - 29.09.2025, last edit - 22.11.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), "Asset");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.date1 = DefVal.setCustom(this.date1, dto.date1);
				this.date2 = DefVal.setCustom(this.date2, dto.date2);
				this.slice = DefVal.setCustom(this.slice, dto.slice);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.face1 = DefVal.setCustom(this.face1, dto.face1);
				this.face2 = DefVal.setCustom(this.face2, dto.face2);
				this.face = DefVal.setCustom(this.face, dto.face);
				this.parent = DefVal.setCustom(this.parent, dto.parent);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.sign = DefVal.setCustom(this.sign, dto.sign);
				this.account = DefVal.setCustom(this.account, dto.account);
				this.geo = DefVal.setCustom(this.geo, dto.geo);
				this.asset = DefVal.setCustom(this.asset, dto.asset);
				this.deal = DefVal.setCustom(this.deal, dto.deal);
				this.item = DefVal.setCustom(this.item, dto.item);
				this.debt = DefVal.setCustom(this.debt, dto.debt);
				this.role = DefVal.setCustom(this.role, dto.role);
				this.info = DefVal.setCustom(this.info, dto.info);
				this.meter = DefVal.setCustom(this.meter, dto.meter);
				this.unit = DefVal.setCustom(this.unit, dto.unit);
				this.meterValue = DefVal.setCustom(this.meterValue, dto.meterValue);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.mark = DefVal.setCustom(this.mark, dto.mark);
				var listDto2 = DAL.getTable(WB.lastConnWork, Qry.getText(WB.lastConnWork, "Process", ""));
				this.upper = ModelDto.getUpper(listDto2, this.parent);
				this.lower = ModelDto.getLower(listDto2, this.code);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.unit = "";
			}
		} catch (Exception ex) {
			WB.addLog("Asset.isExist():void, ex=" + ex.getMessage(), "", "Asset");
		}
	}
	
	private void getFieldFromMore() throws Exception {
		// origin - 29.09.2025, last edit - 29.09.2025
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("Process.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Process");
		}
	}

	public Process(String Id) throws Exception {
		// origin - 05.12.2023, last edit - 22.11.2025
		this.clear();
		this.table = "Process";
		this.src = this.id = Id;
		this.isExist();
		this.validate();
	}

	public Process() throws Exception {
		// origin - 05.12.2023, last edit - 19.05.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 29.12.2024, last edit - 22.11.2025
		try {
			this.table = "Process";
			this.src = this.id = this.parent = this.face1 = this.face2 = "";
			this.face = this.slice = this.date1 = this.date2 = this.code = this.description = "";
			this.sign = this.account = this.geo = this.role = this.info = this.meter = this.meterValue = "";
			this.unit = this.more = this.mark = this.asset = this.deal = this.defect = "";
			this.fullName = this.comment = "";
			this.rule = new ArrayList<ModelDto>();
			this.performEvery = this.launchType = new UnitVal();
			this.lower = new ArrayList<ModelDto>();
			this.upper = new ArrayList<ModelDto>();
		} catch (Exception ex) {
			WB.addLog("Process.clear():void, ex=" + ex.getMessage(), "", "Process");
		}
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 22.11.2025
		try {

//			// ctor()
//			Process p0 = new Process();
//			WB.addLog2("Process.test.ctor()=" + p0,"", "Process");

//			// getRule
//			String[] arg1 = new String[] { "Process", "Process.Prot" };
//			for (var testArg1 : arg1) {
//				WB.addLog2(
//						"Process.test.getRule, res.size=" + Process.getRule(testArg1).size() + ", testArg1=" + testArg1,"", "Process");
//			}

		} catch (Exception ex) {
			WB.addLog("Process.test():void, ex=" + ex.getMessage(), "", "Process");
		}
	}
}