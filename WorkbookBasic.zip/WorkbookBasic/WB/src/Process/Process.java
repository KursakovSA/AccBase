import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;

public class Process {
	// origin - 28.09.2023, last edit - 01.05.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, date1, date2, face1, face2, face, slice, code, description;
	public String geo, sign, account, asset, deal, item, debt, role, info, meter, meterValue, unit, more, mark;
	// special fields
	public static LocalDate minDateSupported; // for doc record in app
	public static LocalDate maxDateSupported; // for doc record in app
	public List<ModelDto> rule;
	public static String strPatternRule;
	public UnitVal performEvery, launchType;// performEvery ex. 23:00(Unit.EveryDay) / 23:00(Unit.EveryEndMonth)
											// launchType ex. Auto/Manual/OnDemand/Schedule/

	static {
		try {
			Process.strPatternRule = "Rule";
			Process.minDateSupported = LocalDate.of(2000, Month.JANUARY, 01);
			Process.maxDateSupported = WB.maxDateSupported;
		} catch (Exception ex) {
			WB.addLog("Process.static ctor, ex=" + ex.getMessage(), "", "Process");
		}
	}

	public static boolean getMatchRule(ModelDto contextProcess, ModelDto ruleProcess) throws Exception {// TOTHINK
		// origin - 01.08.2024, last edit - 21.03.2025
		boolean res = false;
		try {
			if ((Etc.strEquals(contextProcess.meter, ruleProcess.meter))
					&& (Etc.strEquals(contextProcess.unit, ruleProcess.unit))) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("Process.getMatchRule, ex=" + ex.getMessage(), "", "Process");
		}
		return res;
	}

	public static boolean checkRule(ModelDto contextProcess, ModelDto ruleProcess, String contextCheck)
			throws Exception {// TOTHINK
		// origin - 01.08.2024, last edit - 21.03.2025
		boolean res = true;
		try {
			if (getMatchRule(contextProcess, ruleProcess)) {

				if ((Etc.strEquals(contextCheck, "Info.Process.MaxLimit"))
						&& (Conv.getDouble(contextProcess.meterValue) > Conv.getDouble(ruleProcess.meterValue))) {
					res = false;
				}

				if ((Etc.strEquals(contextCheck, "Info.Process.MinLimit"))
						&& (Conv.getDouble(contextProcess.meterValue) < Conv.getDouble(ruleProcess.meterValue))) {
					res = false;
				}

				if ((Etc.strEquals(contextCheck, "Meter.Listed")) && // TODO get IIN
						(CSV.getMatch(ruleProcess.meterValue, contextProcess.face1).size() == 0)) {// meterValue="podft1.csv",
					// "podft2.csv"
					res = false;
				}

				if ((Etc.strEquals(contextCheck, "Meter.NotListed")) && // TODO get IIN
						(CSV.getMatch(ruleProcess.meterValue, contextProcess.face1).size() > 0)) {
					res = false;
				}

			}
		} catch (Exception ex) {
			WB.addLog("Process.checkRule, ex=" + ex.getMessage(), "", "Process");
		}
		return res;
	}

	public static boolean ruleIsValid(ModelDto contextProcess, ModelDto ruleProcess) throws Exception {
		// origin - 01.08.2024, last edit - 20.03.2025
		boolean res = true;
		try {

			if (Etc.strEquals(ruleProcess.info, "Info.Process.MaxLimit")) {
				res = Process.checkRule(contextProcess, ruleProcess, "Info.Process.MaxLimit");
			}
			if (Etc.strEquals(ruleProcess.info, "Info.Process.MinLimit")) {
				res = Process.checkRule(contextProcess, ruleProcess, "Info.Process.MinLimit");
			}
			if (Etc.strEquals(ruleProcess.meter, "Meter.Listed")) {
				res = Process.checkRule(contextProcess, ruleProcess, "Meter.Listed");
			}
			if (Etc.strEquals(ruleProcess.meter, "Info.Process.MinLimit")) {
				res = Process.checkRule(contextProcess, ruleProcess, "Meter.NotListed");
			}

		} catch (Exception ex) {
			WB.addLog("Process.ruleIsValid, ex=" + ex.getMessage(), "", "Process");
		}
		return res;
	}

	public static boolean contextIsValid(List<ModelDto> contextProcess, List<ModelDto> ruleProcess) throws Exception {
		// origin - 01.08.2024, last edit - 20.03.2025
		boolean res = true;
		try {
			for (var currRule : ruleProcess) {
				for (var currContext : contextProcess) {
					res = Process.ruleIsValid(currContext, currRule);
					if (res = false) {
						break;
					}
				}
				if (res = false) {
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Process.contextIsValid, ex=" + ex.getMessage(), "", "Process");
		}
		return res;
	}

	public static List<ModelDto> getRule(String parentProcessCode) throws Exception {
		// origin - 02.08.2024, last edit - 20.03.2025
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			res = ReadSet.getEqualsByCode(WB.abcLast.basic, Process.strPatternRule);
			res = ReadSet.getEqualsByParent(res, parentProcessCode);
		} catch (Exception ex) {
			WB.addLog("Process.getRule, ex=" + ex.getMessage(), "", "Process");
		}
		return res;
	}

	public Process(String Id) throws Exception {
		// origin - 05.12.2023, last edit - 04.05.2025
		this.clear();
		this.table = "Process";
		this.src = this.id = Id;
		// this.item = in.item;
		// this.debt = in.debt;
	}

	public Process() throws Exception {
		// origin - 05.12.2023, last edit - 19.05.2025
		this.clear();
	}

	public void clear() throws Exception {
		// origin - 29.12.2024, last edit - 01.05.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = this.getClass().getName();
			this.src = this.table = this.id = this.parent = this.face1 = this.face2 = "";
			this.face = this.slice = this.date1 = this.date2 = this.code = this.description = "";
			this.sign = this.account = this.geo = this.role = this.info = this.meter = this.meterValue = "";
			this.unit = this.more = this.mark = this.asset = this.deal = "";
		
			this.rule = new ArrayList<ModelDto>();
			performEvery = launchType = new UnitVal();
		} catch (Exception ex) {
			WB.addLog("Process.clear, ex=" + ex.getMessage(), "", "Process");
		}
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 20.03.2025
		try {

//			// ctor()
//			Process p0 = new Process();
//			WB.addLog2("Process.test.ctor()=" + p0 + ", isExist=" + p0.isExist() + ", isValid=" + p0.isValid(),"", "Process");

//			// getRule
//			String[] arg1 = new String[] { "Process", "Process.Prot" };
//			for (var testArg1 : arg1) {
//				WB.addLog2(
//						"Process.test.getRule, res.size=" + Process.getRule(testArg1).size() + ", testArg1=" + testArg1,"", "Process");
//			}

		} catch (Exception ex) {
			WB.addLog("Process.test, ex=" + ex.getMessage(), "", "Process");
		}
	}
}