import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class WorkbookDto {
	// origin - 30.06.2025, last edit - 30.06.2025
	// common fields
	public String table, src, id, parent, date1, date2, face1, face2, face, slice, code, description;
	public String geo, sign, account, process, asset, deal, role, info, meter, meterValue, unit, more, mark;
	// special fields
	public String fullName, comment;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("WorkbookDto.static ctor, ex=" + ex.getMessage(), "", "WorkbookDto");
		}
	}
	
	//public static WorkbookDto getTotal(SpanDate spanDate) throws Exception { //TODO ??
	
	public static WorkbookDto getTotal(List<WorkbookDto> listWorkbookDto) throws Exception { //TODO
		// origin - 11.09.2025, last edit - 11.09.2025
		WorkbookDto res = new WorkbookDto();
		try {
//			for (var currPawn : listWorkbookDto) {
//				// WB.addLog2("Pawn.getTotal(List<Pawn>):Pawn, currPawn=" + currPawn,"",
//				// "Pawn");
//				res.weightGross = UnitVal.add(res.weightGross, currPawn.weightGross);
//				res.weightNetto = UnitVal.add(res.weightNetto, currPawn.weightNetto);
//				res.weightCarat = UnitVal.add(res.weightCarat, currPawn.weightCarat);
//				res.estimatedValue = UnitVal.add(res.estimatedValue, currPawn.estimatedValue);
//				res.partMainDebt = UnitVal.add(res.partMainDebt, currPawn.partMainDebt);
//			}
		} catch (Exception ex) {
			WB.addLog("WorkbookDto.getTotal(List<Pawn>):Pawn, ex=" + ex.getMessage(), "", "WorkbookDto");
		}
		return res;
	}

	public static List<WorkbookDto> getChronoSpan(SpanDate spanDate, List<WorkbookDto> listWorkbookDto)
			throws Exception { // TOTHINK
		// origin - 30.06.2025, last edit - 30.06.2025
		List<WorkbookDto> res = new ArrayList<WorkbookDto>();
		LocalDate currDate1;
		LocalDate currDate2;
		try {
			LocalDate spanDate1 = DateTool.getLocalDate(spanDate.date1.getFirst());
			LocalDate spanDate2 = DateTool.getLocalDate(spanDate.date2.getFirst());
			for (var currDto : listWorkbookDto) {
				currDate1 = DateTool.getLocalDate(currDto.date1);// left border in data
				currDate2 = DateTool.getLocalDate(currDto.date2);// right border in data

				if (currDate1.isBefore(spanDate1)) {
					continue;
				}

				if (currDate2.isAfter(spanDate2)) {
					continue;
				}

				if ((Etc.strEquals(currDate1.toString(), spanDate1.toString()))
						& (Etc.strEquals(currDate2.toString(), spanDate2.toString()))) {
					res.add(currDto);
					continue;
				}

				if ((Etc.strEquals(currDate1.toString(), spanDate1.toString())) & (currDate2.isBefore(spanDate2))) {
					res.add(currDto);
					continue;
				}

				if ((currDate1.isAfter(spanDate1)) & (Etc.strEquals(currDate2.toString(), spanDate2.toString()))) {
					res.add(currDto);
					continue;
				}

				if ((currDate1.isAfter(spanDate1)) & (currDate2.isBefore(spanDate2))) {
					res.add(currDto);
					continue;
				}
			}
		} catch (Exception ex) {
			WB.addLog(
					"WorkbookDto.getChronoSpan(SpanDate spanDate, List<WorkbookDto> listWorkbookDto):List<WorkbookDto>, ex="
							+ ex.getMessage(),
					"", "WorkbookDto");
		}
		return res;
	}

	public static List<WorkbookDto> getChrono(LocalDate calcDate, List<WorkbookDto> listWorkbookDto) throws Exception { // TOTHINK
		// origin - 30.06.2025, last edit - 30.06.2025
		List<WorkbookDto> res = new ArrayList<WorkbookDto>();
		LocalDate currDate1;
		LocalDate currDate2;
		try {
			for (var currDto : listWorkbookDto) {
				currDate1 = DateTool.getLocalDate(currDto.date1);// left border in data
				currDate2 = DateTool.getLocalDate(currDto.date2);// right border in data

				// left border hit or right border hit
				if ((Etc.strEquals(currDate1.toString(), calcDate.toString()))
						|| (Etc.strEquals(currDate2.toString(), calcDate.toString()))) {
					res.add(currDto);
					continue;
				}

				// range from left border to right border hit
				if ((currDate1.isBefore(calcDate)) && (currDate2.isAfter(calcDate))) {
					res.add(currDto);
					continue;
				}
			}
		} catch (Exception ex) {
			WB.addLog(
					"WorkbookDto.getChrono(LocalDate calcDate, List<WorkbookDto> listWorkbookDto):List<WorkbookDto>, ex="
							+ ex.getMessage(),
					"", "WorkbookDto");
		}
		return res;
	}

	public static WorkbookDto getChrono(LocalDate calcDate, List<WorkbookDto> listWorkbookDto, String context)
			throws Exception { // TOTHINK
		// origin - 30.06.2025, last edit - 30.06.2025
		WorkbookDto res = new WorkbookDto();
		LocalDate currDate1;
		LocalDate currDate2;
		try {
			for (var currDto : listWorkbookDto) {
				if (context.isEmpty() == false) {
					if (Etc.strContains(currDto.info, context) == false) {
						continue;
					}
				}

				currDate1 = DateTool.getLocalDate(currDto.date1);// left border in data
				currDate2 = DateTool.getLocalDate(currDto.date2);// right border in data

				// left border hit or right border hit
				if ((Etc.strEquals(currDate1.toString(), calcDate.toString()))
						|| (Etc.strEquals(currDate2.toString(), calcDate.toString()))) {
					res = currDto;
					break;
				}

				// range from left border to right border hit
				if ((currDate1.isBefore(calcDate)) && (currDate2.isAfter(calcDate))) {
					res = currDto;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog(
					"WorkbookDto.getChrono(LocalDate calcDate, List<WorkbookDto> listWorkbookDto, String context):WorkbookDto, ex="
							+ ex.getMessage(),
					"", "WorkbookDto");
		}
		return res;
	}

	public WorkbookDto(String Id, String Parent, String Face1, String Face2, String Face, String Slice, String Date1,
			String Date2, String Code, String Description, String Geo, String Sign, String Account, String Process,
			String Asset, String Deal, String Role, String Info, String Meter, String MeterValue, String Unit,
			String More, String Mark) throws Exception {
		// origin - 30.06.2025, last edit - 30.06.2025
		this.clear();
		this.table = "Process";
		this.id = Id;
		this.parent = Parent;
		this.face1 = Face1;
		this.face2 = Face2;
		this.face = Face;
		this.slice = Slice;
		this.date1 = Date1;
		this.date2 = Date2;
		this.code = Code;
		this.description = Description;
		this.geo = Geo;
		this.sign = Sign;
		this.account = Account;
		this.process = Process;
		this.asset = Asset;
		this.deal = Deal;
		this.role = Role;
		this.info = Info;
		this.meter = Meter;
		this.meterValue = MeterValue;
		this.unit = Unit;
		this.more = More;
		this.mark = Mark;
	}

	private void clear() throws Exception {
		// origin - 30.06.2025, last edit - 06.09.2025
		try {
			this.src = this.table = this.id = this.parent = this.face1 = this.face2 = this.face = this.slice = this.date1 = this.date2 = this.code = this.description = this.geo = this.sign = this.account = this.process = this.asset = this.deal = this.role = this.info = this.meter = this.meterValue = this.unit = this.more = this.mark = "";
		} catch (Exception ex) {
			WB.addLog("WorkbookDto.clear():void, ex=" + ex.getMessage(), "", "WorkbookDto");
		}
	}

	public WorkbookDto() throws Exception {
		// origin - 30.06.2025, last edit - 30.06.2025
		this.clear();
	}

	public String toString() {
		// origin - 30.06.2025, last edit - 30.06.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", slice ", this.slice);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);

			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.sign);
			res = res + Fmtr.addIfNotEmpty(", ", this.account);
			res = res + Fmtr.addIfNotEmpty(", ", this.process);
			res = res + Fmtr.addIfNotEmpty(", ", this.asset);
			res = res + Fmtr.addIfNotEmpty(", ", this.deal);

			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", ", this.meter);
			res = res + Fmtr.addIfNotEmpty(", meterValue", this.meterValue);
			res = res + Fmtr.addIfNotEmpty(", ", this.unit);

			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 30.06.2025, last edit - 30.06.2025
		try {

		} catch (Exception ex) {
			WB.addLog("WorkbookDto.test():void, ex=" + ex.getMessage(), "", "WorkbookDto");
		}
	}
}