public final class ProcessRule { // TODO
	// origin - 11.04.2026, last edit - 28.10.2026
	// common fields
	public String table, src, id, parent, date1, date2, face1, face2, face, slice, code, description;
	public String geo, sign, account, asset, deal, item, debt, role, info, meter, meterValue, unit, more, mark, defect;
	// special fields

//	public boolean check(List<String> listStrCheck) throws Exception {
//		// origin - 12.04.2026, last edit - 28.10.2026
//		boolean res = false;
//		try {
//			var count = 0;
//			for (var curr : listStrCheck) {
//				if (this.check(curr) == true) {
//					count = count + 1;
//				}
//			}
//
//			if (count == listStrCheck.size()) {
//				res = true;
//			}
//		} catch (Exception ex) {
//			WB.addLog("ProcessRule.check(List<String>):boolean, ex=" + ex.getMessage(), "", "ProcessRule");
//		}
//		return res;
//	}

	public boolean check(String strCheck) throws Exception {
		// origin - 01.08.2024, last edit - 26.10.2026
		boolean res = false;
		try {
			if (Etc.strNotValid(strCheck)) {
				return res;
			}

			var checkPattern = this.info + "+" + this.unit;
			switch (checkPattern) {
			case "Info.Process.Contains+Unit.TextFile" -> res = this.checkContainsTextFile(strCheck);
			// default -> res = "";
			}
		} catch (Exception ex) {
			WB.addLog("ProcessRule.check(String):boolean, ex=" + ex.getMessage(), "", "ProcessRule");
		}
		return res;
	}

	private boolean checkContainsTextFile(String strCheck) throws Exception {
		// origin - 12.04.2026, last edit - 19.10.2026
		boolean res = false;
		try {
			if (Etc.strNotValid(strCheck)) {
				return res;
			}
			var tmp = InOut.getStrPathFileByFileNameInAppDir(this.meterValue);
			var checkPattern = this.meter + "+" + CSV.contains(tmp, strCheck);

			switch (checkPattern) {
			case "Meter.Listed+true" -> res = true;
			case "Meter.NotListed+false" -> res = true;
			// default -> res = "";
			}
		} catch (Exception ex) {
			WB.addLog("ProcessRule.checkContainsTextFile(String):boolean, ex=" + ex.getMessage(), "", "ProcessRule");
		}
		return res;
	}

	private void fix() throws Exception {
		// origin - 27.10.2026, last edit - 27.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}

			this.date1 = DefVal.set(this.date1, WB.minDateSupported.toString());
			this.date2 = DefVal.set(this.date2, WB.maxDateSupported.toString());
			this.mark = DefVal.set(this.mark, "Mark.DD");
		} catch (Exception ex) {
			WB.addLog("ProcessRule.fix():void, ex=" + ex.getMessage(), "", "ProcessRule");
		}
	}

	private void validate() throws Exception {
		// origin - 11.04.2026, last edit - 10.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}
		} catch (Exception ex) {
			WB.addLog("ProcessRule.validate():void, ex=" + ex.getMessage(), "", "ProcessRule");
		}
	}

	private void isExist() throws Exception {
		// origin - 11.04.2026, last edit - 26.10.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdRoleFilter(this.id, "Role.Process.Rule"),
					"Process");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.id = dto.id;
				this.parent = dto.parent;
				this.date1 = dto.date1;
				this.date2 = dto.date2;
				this.face1 = dto.face1;
				this.face2 = dto.face2;
				this.slice = dto.slice;
				this.code = dto.code;
				this.description = dto.description;
				this.geo = dto.geo;
				this.sign = dto.sign;
				this.account = dto.account;
				this.asset = dto.asset;
				this.deal = dto.deal;
				this.item = dto.item;
				this.debt = dto.debt;
				this.role = dto.role;
				this.info = dto.info;
				this.meter = dto.meter;
				this.meterValue = dto.meterValue;
				this.unit = dto.unit;
				this.more = dto.more;
				this.mark = dto.mark;
			} else {
				this.clear();
			}
		} catch (Exception ex) {
			WB.addLog("ProcessRule.isExist():void, ex=" + ex.getMessage(), "", "ProcessRule");
		}
	}

	public ProcessRule(String Src) throws Exception {
		// origin - 11.04.2026, last edit - 27.10.2026
		this.clear();
		this.src = Src;
		if (Src.isEmpty() == false) {
			this.id = Etc.fixTrim(Src);
		}
		this.isExist();
		this.fix();
		this.validate();
	}

	public ProcessRule() throws Exception {
		// origin - 11.04.2026, last edit - 11.04.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 11.04.2026, last edit - 26.10.2026
		try {
			this.table = "Process";
			this.src = this.id = this.parent = this.face1 = this.face2 = "";
			this.face = this.slice = this.date1 = this.date2 = this.code = this.description = "";
			this.sign = this.account = this.geo = this.role = this.info = this.meter = this.meterValue = "";
			this.unit = this.more = this.mark = this.asset = this.deal = this.defect = "";
		} catch (Exception ex) {
			WB.addLog("ProcessRule.clear():void, ex=" + ex.getMessage(), "", "ProcessRule");
		}
	}

	public String toString() {
		// origin - 11.04.2026, last edit - 26.10.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", slice ", this.slice);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", sign ", this.sign);
			res = res + Fmtr.addIfNotEmpty(", account ", this.account);
			res = res + Fmtr.addIfNotEmpty(", geo ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", role ", this.role);
			res = res + Fmtr.addIfNotEmpty(", info ", this.info);
			res = res + Fmtr.addIfNotEmpty(", meter ", this.meter);
			res = res + Fmtr.addIfNotEmpty(", meterValue ", this.meterValue);
			res = res + Fmtr.addIfNotEmpty(", unit ", this.unit);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", mark ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", asset ", this.asset);
			res = res + Fmtr.addIfNotEmpty(", deal ", this.deal);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 11.04.2026, last edit - 26.10.2026
		try {

//			WB.addLog2("ProcessRule.test.check(List<String>):boolean", "", "ProcessRule");
//			for (var tmp1 : new String[] { "Process.Rule.Face.NotListed1", "Process.Rule.Face.Listed1" }) {
//				WB.addLog2("Rule.test.ctor(tmp1)=" + new Rule(tmp1) + ", tmp1=" + tmp1, "", "Rule");
//				for (var tmp2 : List.of("111,222", "333,444", "111", "444")) {
//					var tmp3 = List.of(tmp2.split(","));
//					WB.addLog2("ProcessRule.test.check(tmp2)=" + new ProcessRule(tmp1).check(tmp3) + ", tmp3=" + tmp3, "", "ProcessRule");
//				}
//			}

//			WB.addLog2("ProcessRule.test.check(String):boolean", "", "ProcessRule");
//			for (var tmp1 : new String[] { "Process.Rule.Face.NotListed1", "Process.Rule.Face.Listed1" }) {
//				WB.addLog2("Rule.test.ctor(tmp1)=" + new Rule(tmp1) + ", tmp1=" + tmp1, "", "Rule");
//				for (var tmp2 : new String[] { "111", "222", "333", "444" }) {
//					WB.addLog2("ProcessRule.test.check(tmp2)=" + new ProcessRule(tmp1).check(tmp2) + ", tmp2=" + tmp2, "", "ProcessRule");
//				}
//			}

//			WB.addLog2("ProcessRule.test.ctor(String)", "", "ProcessRule");
//			for (var tmp1 : new String[] { "", "Process.Rule.Face.NotListed1", "Process.Rule.Face.Listed1",
//					"Process.Rule.tralala", "Process.Rule.Face.NotStopListed1", "Process.Rule.Face.StopListed1",
//					"Process.Rule.Text.Listed1" }) {
//				WB.addLog2("ProcessRule.test.ctor(String)=" + new Rule(tmp1) + ", tmp1=" + tmp1, "", "ProcessRule");
//			}

		} catch (Exception ex) {
			WB.addLog("ProcessRule.test():void, ex=" + ex.getMessage(), "", "ProcessRule");
		}
	}
}