import java.util.ArrayList;
import java.util.List;

public final class ProcessVar { // Process Variable, ex. "FullName_CurrFA", "FullName_Customer", etc.
	// origin - 22.09.2025, last edit - 12.10.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, date1, date2, face1, face2, face, slice, code, description;
	public String geo, sign, account, asset, deal, item, debt, role, info, meter, meterValue, unit, more, mark;
	// special fields
	public String fullName, comment;
	// list common + special + timestamp fields in unified val

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("ProcessVar.static ctor, ex=" + ex.getMessage(), "", "ProcessVar");
		}
	}

	public static List<ProcessVar> getByInfo(String info) throws Exception {
		// origin - 28.09.2025, last edit - 28.09.2025
		List<ProcessVar> res = new ArrayList<ProcessVar>();
		try {
			var listDto = DAL.getByTemplate(Conn.globalPath, Qry.getRoleInfoFilter("Role.Process.Var", info),
					"Process");
			if (listDto.size() != 0) {
				for (var currDto : listDto) {
					var currProcessVar = new ProcessVar(currDto.id);
					res.add(currProcessVar);
				}
			}
		} catch (Exception ex) {
			WB.addLog("ProcessVar.getByInfo(String):List<ProcessVar>, ex=" + ex.getMessage(), "", "ProcessVar");
		}
		return res;
	}

	public static List<ProcessVar> get() throws Exception {
		// origin - 22.09.2025, last edit - 28.09.2025
		List<ProcessVar> res = new ArrayList<ProcessVar>();
		try {
			var listDto = DAL.getByTemplate(Conn.globalPath, Qry.getRoleFilter("Role.Process.Var"), "Process");
			if (listDto.size() != 0) {
				for (var currDto : listDto) {
					var currProcField = new ProcessVar(currDto.id);
					res.add(currProcField);
				}
			}
		} catch (Exception ex) {
			WB.addLog("ProcessVar.get():List<ProcessVar>, ex=" + ex.getMessage(), "", "ProcessVar");
		}
		return res;
	}

	public ProcessVar(ModelDto mDto) throws Exception {
		// origin - 22.09.2025, last edit - 22.09.2025
		this.clear();
		this.id = mDto.id;
		this.parent = mDto.parent;
		this.face1 = mDto.face1;
		this.face2 = mDto.face2;
		this.face = mDto.face;
		this.date1 = mDto.date1;
		this.date2 = mDto.date2;
		this.code = mDto.code;
		this.description = mDto.description;
		this.geo = mDto.geo;
		this.role = mDto.role;
		this.info = mDto.info;
		this.more = mDto.more;
		this.mark = mDto.mark;
		this.isExist = true; // ??
		this.isValid = true; // ??
		this.getFieldFromMore();
	}

	public ProcessVar(String Id) throws Exception {
		// origin - 22.09.2025, last edit - 22.09.2025
		this.clear();
		this.src = Id;
		this.id = Id;
		this.isExist();
		this.getFieldFromMore();
	}

	public ProcessVar() throws Exception {
		// origin - 22.09.2025, last edit - 22.09.2025
		this.clear();
	}

	private void isExist() throws Exception {
		// origin - 22.09.2025, last edit - 28.09.2025
		try {
			var listDto = DAL.getByTemplate(Conn.globalPath, Qry.getIdRoleFilter(this.id, "Role.Process.Var"),
					"Process");
			if (listDto.size() != 0) {
				var currDto = listDto.getFirst();
				this.id = DefVal.setCustom(this.id, currDto.id);
				this.parent = DefVal.setCustom(this.parent, currDto.parent);
				this.date1 = DefVal.setCustom(this.date1, currDto.date1);
				this.date2 = DefVal.setCustom(this.date2, currDto.date2);
				this.face1 = DefVal.setCustom(this.face1, currDto.face1);
				this.face2 = DefVal.setCustom(this.face2, currDto.face2);
				this.face = DefVal.setCustom(this.face, currDto.face);
				this.slice = DefVal.setCustom(this.slice, currDto.slice);
				this.code = DefVal.setCustom(this.code, currDto.code);
				this.description = DefVal.setCustom(this.description, currDto.description);
				this.geo = DefVal.setCustom(this.geo, currDto.geo);
				this.sign = DefVal.setCustom(this.sign, currDto.sign);
				this.account = DefVal.setCustom(this.account, currDto.account);
				this.asset = DefVal.setCustom(this.asset, currDto.asset);
				this.deal = DefVal.setCustom(this.deal, currDto.deal);
				this.item = DefVal.setCustom(this.item, currDto.item);
				this.debt = DefVal.setCustom(this.debt, currDto.debt);
				this.role = DefVal.setCustom(this.role, currDto.role);
				this.info = DefVal.setCustom(this.info, currDto.info);
				this.meter = DefVal.setCustom(this.meter, currDto.meter);
				this.meterValue = DefVal.setCustom(this.meterValue, currDto.meterValue);
				this.unit = DefVal.setCustom(this.unit, currDto.unit);
				this.more = DefVal.setCustom(this.more, currDto.more);
				this.mark = DefVal.setCustom(this.mark, currDto.mark);
				this.isExist = true;
				this.isValid = true;
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("ProcessVar.isExist():void, ex=" + ex.getMessage(), "", "ProcessVar");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 22.09.2025, last edit - 22.09.2025
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("ProcessVar.getFieldFromMore():void, ex=" + ex.getMessage(), "", "ProcessVar");
		}
	}

	private void clear() throws Exception {
		// origin - 22.09.2025, last edit - 22.09.2025
		try {
			this.table = "Process";
			this.isValid = false;
			this.isExist = false;
			this.src = this.id = this.parent = this.face1 = this.face2 = "";
			this.face = this.slice = this.date1 = this.date2 = this.code = this.description = "";
			this.geo = this.sign = this.account = this.asset = this.deal = this.item = this.debt = "";
			this.role = this.info = this.meter = this.meterValue = this.unit = this.more = this.mark = "";
			this.fullName = this.comment = "";
		} catch (Exception ex) {
			WB.addLog("ProcessVar.clear():void, ex=" + ex.getMessage(), "", "ProcessVar");
		}
	}

	public String toString() {
		// origin - 22.09.2025, last edit - 22.09.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", slice ", this.slice);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);

			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.sign);
			res = res + Fmtr.addIfNotEmpty(", ", this.account);
			res = res + Fmtr.addIfNotEmpty(", ", this.asset);
			res = res + Fmtr.addIfNotEmpty(", ", this.deal);
			res = res + Fmtr.addIfNotEmpty(", ", this.item);
			res = res + Fmtr.addIfNotEmpty(", ", this.debt);

			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", ", this.meter);
			res = res + Fmtr.addIfNotEmpty(", meterValue ", this.meterValue);
			res = res + Fmtr.addIfNotEmpty(", ", this.unit);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 22.09.2025, last edit - 22.09.2025
		try {

//			{
//				WB.addLog2("ProcessVar.test.get():List<ProcessVar>", "", "ProcessVar");
//				var tmp1 = ProcessVar.get();
//				WB.addLog2("ProcessVar.test.get():List<ProcessVar>, res.size=" + tmp1.size(), "", "ProcessVar");
//				WB.log(tmp1, "ProcessVar");
//			}

//			WB.addLog2("ProcessVar.test.ctor(String)", "", "ProcessVar");
//			for (var tmp1 : new String[] { "", "FullName_CurrFA", "Tralala" }) {
//				WB.addLog2("ProcessVar.test.ctor(String)=" + new ProcessVar(tmp1) + ", tmp1=" + tmp1, "", "ProcessVar");
//			}

		} catch (Exception ex) {
			WB.addLog("ProcessVar.test():void, ex=" + ex.getMessage(), "", "ProcessVar");
		}
	}
}