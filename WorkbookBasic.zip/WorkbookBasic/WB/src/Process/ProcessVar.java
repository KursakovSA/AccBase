import java.util.List;

public final class ProcessVar {
	// origin - 22.09.2025, last edit - 27.04.2026
	public static List<String> listId;

	static {
		ProcessVar.listId = List.of("", "CurrDate", "CurrFA", "Face", "Staff", "CurrDoc", "StartDoc", "ParentDoc",
				"User"); //not complete
		try {
		} catch (Exception ex) {
			WB.addLog("ProcessVar.static ctor, ex=" + ex.getMessage(), "", "ProcessVar");
		}
	}

	private ProcessVar() throws Exception {
		// origin - 22.09.2025, last edit - 27.04.2026
	}

	public static void test() throws Exception {
		// origin - 22.09.2025, last edit - 27.04.2026
		try {

		} catch (Exception ex) {
			WB.addLog("ProcessVar.test():void, ex=" + ex.getMessage(), "", "ProcessVar");
		}
	}
}