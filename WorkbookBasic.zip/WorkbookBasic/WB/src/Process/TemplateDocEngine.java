import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class TemplateDocEngine {
	// origin - 13.09.2025, last edit - 26.03.2026
	static {
		try {
		} catch (Exception ex) {
			WB.addLog("TemplateDocEngine.static ctor, ex=" + ex.getMessage(), "", "TemplateDocEngine");
		}
	}

	public static List<String> getByPattern(List<String> strList) throws Exception { // TODO
		// origin - 28.03.2026, last edit - 28.03.2026
		List<String> res = new ArrayList<String>();
		try {
			for (var curr : strList) {
				res.add(TemplateDocEngine.getByPattern(curr));
			}
		} catch (Exception ex) {
			WB.addLog("TemplateDocEngine.getByPattern(List<String>):List<String>, ex=" + ex.getMessage(), "",
					"TemplateDocEngine");
		}
		return res;
	}

	public static String getByPattern(String inStr) throws Exception { // TODO
		// origin - 28.03.2026, last edit - 28.03.2026
		String res = "";
		try {
			var tmp = "";
			var patternList = TemplateDocEngine.getPatternContainsList(inStr);
			for (var curr : patternList) {
				tmp = "";
				if (TemplateDocPattern.isPatternId(curr)) {
					tmp = TemplateDocPattern.get("2025-02-20", "", curr); // TODO
				}
				if (TemplateDocPattern.isPatternId(curr) == false) {
					tmp = curr;
				}
				res = res + tmp;
			}
		} catch (Exception ex) {
			WB.addLog("TemplateDocEngine.getByPattern(String):String, ex=" + ex.getMessage(), "", "TemplateDocEngine");
		}
		return res;
	}

	public static List<String> getPatternContainsList(String src) throws Exception {
		// origin - 28.03.2026, last edit - 28.03.2026
		List<String> res = new ArrayList<String>();
		try {
			var tmp = src;
			var leftBorder = "\\[";
			var rightBorder = "\\]";
			Pattern pattern = Pattern.compile(leftBorder + ".*?" + rightBorder);
			Matcher matcher = pattern.matcher(tmp);

			int lastEnd = 0;
			while (matcher.find()) {
				if (matcher.start() > lastEnd) {
					res.add(tmp.substring(lastEnd, matcher.start()));
				}

				res.add(matcher.group());
				lastEnd = matcher.end();
			}

			if (lastEnd < tmp.length()) {
				res.add(tmp.substring(lastEnd));
			}
		} catch (Exception ex) {
			WB.addLog("TemplateDocEngine.getPatternContainsList(String):List<String>, ex=" + ex.getMessage(), "",
					"TemplateDocEngine");
		}
		return res;
	}

	private TemplateDocEngine() throws Exception {
		// origin - 13.11.2025, last edit - 27.04.2026
	}

	public static void test() throws Exception {
		// origin - 13.09.2025, last edit - 26.04.2026
		try {

			WB.addLog2("TemplateDocEngine.test.getByPattern(String):String", "", "TemplateDocEngine");
			for (var tmp1 : new String[] { "123 [FullName_CurrFA] 4567 [BIC_Face] 89",
					"  [FullName_CurrFA] 123 [Face_Tralala]" }) {
				WB.addLog2("TemplateDocEngine.test.getByPattern(String):String, res="
						+ TemplateDocEngine.getByPattern(tmp1) + ", tmp1=" + tmp1, "", "TemplateDocEngine");
			}

//			WB.addLog2("TemplateDocEngine.test.getPatternContainsList(String):List<String>", "", "TemplateDocEngine");
//			for (var tmp1 : new String[] { "123[FullName_CurrFA]4567[BIC_Face]89",
//					"  [FullName_CurrFA]123[Face_Tralala]" }) {
//				WB.addLog2(
//						"TemplateDocEngine.test.getPatternContainsList(String):List<String>, res="
//								+ TemplateDocEngine.getPatternContainsList(tmp1) + ", tmp1=" + tmp1,
//						"", "TemplateDocEngine");
//			}

		} catch (Exception ex) {
			WB.addLog("TemplateDocEngine.test():void, ex=" + ex.getMessage(), "", "TemplateDocEngine");
		}
	}
}