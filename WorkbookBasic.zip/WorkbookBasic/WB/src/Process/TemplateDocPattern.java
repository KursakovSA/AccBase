import java.util.ArrayList;
import java.util.List;

public final class TemplateDocPattern {
	// origin - 26.03.2026, last edit - 02.04.2026
	public String src, id, code, description, defect, fullName, comment;
	public List<String> arg;
	public static List<String> listId, listDelStr, listArgStr;

	static {
		try {
			TemplateDocPattern.listId = TemplateDocPattern.getId();
			TemplateDocPattern.listDelStr = List.of("[", "]");
			TemplateDocPattern.listArgStr = List.of("(", ")");
		} catch (Exception ex) {
			WB.addLog("TemplateDocPattern.static ctor, ex=" + ex.getMessage(), "", "TemplateDocPattern");
		}
	}

	private static List<String> getId() throws Exception {
		// origin - 02.04.2026, last edit - 27.04.2026
		List<String> res = new ArrayList<String>();
		try {
			var tmp = "";
			for (var currTemplateDocVar : TemplateDocVar.listId) { // ex. "LawAddress"
				for (var currProcessVar : ProcessVar.listId) { // ex. "CurrFA"
					tmp = "";
					tmp = currTemplateDocVar + "_" + currProcessVar; // ex. "LawAddress_CurrFA"
					tmp = Etc.delLeaderPlaceholder(tmp, "_");
					tmp = Etc.delTailPlaceholder(tmp, "_");
					res.add(tmp);
				}
			}
		} catch (Exception ex) {
			WB.addLog("TemplateDocPattern.getId():List<String>, ex=" + ex.getMessage(), "", "TemplateDocPattern");
		}
		return res;
	}

	public static String get(ProcessContext procCont, String patternSrc) throws Exception { // TODO
		// origin - 27.04.2026, last edit - 27.04.2026
		String res = "";
		var date1 = procCont.date1;
		var faceId = procCont.face2; // ? procCont.getFaceId(?) ?
		try {
			res = TemplateDocPattern.get(date1, faceId, patternSrc);
		} catch (Exception ex) {
			WB.addLog("TemplateDocPattern.get(2String):String, ex=" + ex.getMessage(), "", "TemplateDocPattern");
		}
		res = Etc.fixTrim(res);
		return res;
	}

	public static String get(String date1, String faceId, String patternSrc) throws Exception {
		// origin - 18.09.2025, last edit - 27.04.2026
		String res = "";
		var pattern = new TemplateDocPattern(patternSrc);
		var patternId = pattern.id;
		var patternArg = pattern.arg;
		try {
			switch (patternId) {
			// currFA
			case "FullName_CurrFA" -> res = FaceReg.getCurrFullName(date1, Face.currFA.id);
			case "DocReg_CurrFA" -> res = FaceReg.getCurrDocReg(date1, Face.currFA.id);
			case "BIN_CurrFA" -> res = Face.getGovId(Face.currFA.id, "BIN");
			case "IIN_CurrFA" -> res = Face.getGovId(Face.currFA.id, "IIN");
			case "IdKAZ_CurrFA" -> res = Face.getGovId(Face.currFA.id, "IdKAZ");
			case "LawAddress_CurrFA" -> res = Address.getCurrLawAddress(date1, Face.currFA.id);
			case "RegAddress_CurrFA" -> res = Address.getCurrRegAddress(date1, Face.currFA.id);
			case "BossSign_CurrFA" -> res = Staff.getFIO(date1, Face.currFA.id, "Info.Staff.BossSign");
			case "ChiefAccountantSign_CurrFA" ->
				res = Staff.getFIO(date1, Face.currFA.id, "Info.Staff.ChiefAccountantSign");
			case "IBAN_CurrFA" -> res = Bank.getIBANCurrAccount(date1, Face.currFA.id);
			case "BIC_CurrFA" -> res = Bank.getBICCurrAccount(date1, Face.currFA.id);
			case "BankAccount_CurrFA" -> res = Bank.getToDocCurrAccount(date1, Face.currFA.id);

			// Face
			case "BossSign_Face" -> res = Face.getBossSign(faceId);
			case "ChiefAccountantSign_Face" -> res = Face.getChiefAccountantSign(faceId);
			case "FullName_Face" -> res = Face.getFullName(faceId);
			case "DocReg_Face" -> res = FaceReg.getCurrDocReg(date1, faceId);// new FaceDto(faceId).docReg;
			case "BIN_Face" -> res = Face.getGovId(faceId, "BIN");
			case "IIN_Face" -> res = Face.getGovId(faceId, "IIN");
			case "IdKAZ_Face" -> res = Face.getGovId(faceId, "IdKAZ");
			case "LawAddress_Face" -> res = Address.getCurrLawAddress(date1, faceId);
			case "RegAddress_Face" -> res = Address.getCurrRegAddress(date1, faceId);
			case "IBAN_Face" -> res = Bank.getIBANCurrAccount(date1, faceId);
			case "BIC_Face" -> res = Bank.getBICCurrAccount(date1, faceId);
			case "BankAccount_Face" -> res = Bank.getToDocCurrAccount(date1, faceId);
			case "SPL" -> res = SPL.get(patternArg);

			default -> res = patternSrc + "=?";
			}
		} catch (Exception ex) {
			WB.addLog("TemplateDocPattern.get(3String):String, ex=" + ex.getMessage() + ", patternSrc=" + patternSrc,
					"", "TemplateDocPattern");
		}
		res = Etc.fixTrim(res);
		return res;
	}

	public static boolean isPatternId(String inStr) throws Exception {
		// origin - 27.03.2026, last edit - 27.03.2026
		boolean res = false;
		var tmp = TemplateDocPattern.getId(inStr);
		try {
			for (var curr : TemplateDocPattern.listId) {
				if (Etc.strEquals(curr, tmp)) {
					res = true;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("TemplateDocPattern.isPatternId():void, ex=" + ex.getMessage(), "", "TemplateDocPattern");
		}
		return res;
	}

	private static String getId(String src) throws Exception { // ex. from "SPL(12 600;quantity)" to "SPL"
		// origin - 26.03.2026, last edit - 13.04.2026
		String res = "";
		try {
			var tmp = Etc.fixTrim(src);
			if (tmp.length() != 0) {
				if (Etc.strContains(src, TemplateDocPattern.listArgStr) == false) {
					tmp = src + "()";
				}

				tmp = Etc.delStr(tmp, TemplateDocPattern.listDelStr);
				if (tmp.indexOf("(") != 0) {
					tmp = tmp.substring(0, tmp.indexOf("("));
					res = tmp;
				}
			}
		} catch (Exception ex) {
			WB.addLog("TemplateDocPattern.getId(String):String, ex=" + ex.getMessage(), "", "TemplateDocPattern");
		}
		return res;
	}

	private void getArg() throws Exception { // ex. from "SPL(12 600;quantity)" to "12 600;quantity"
		// origin - 26.03.2026, last edit - 27.03.2026
		try {
			var tmp = Etc.fixTrim(this.src);
			tmp = Etc.delStr(tmp, TemplateDocPattern.listDelStr);
			tmp = tmp.replace(this.id, "");
			if (Etc.strContains(this.src, TemplateDocPattern.listArgStr)) {
				tmp = Etc.delStr(tmp, TemplateDocPattern.listArgStr);
				if (tmp.length() != 0) {
					this.arg = List.of(tmp.split(";"));
				}
			}
		} catch (Exception ex) {
			WB.addLog("TemplateDocPattern.getArg():void, ex=" + ex.getMessage(), "", "TemplateDocPattern");
		}
	}

	private void validate() throws Exception { // TODO
		// origin - 26.03.2026, last edit - 02.04.2026
		try {
			if (this.id.isEmpty()) {
				this.defect = this.defect + "empty id; ";
			}
			if (this.code.isEmpty()) {
				this.defect = this.defect + "empty code; ";
			}
			if (this.description.isEmpty()) {
				this.defect = this.defect + "empty description; ";
			}
		} catch (Exception ex) {
			WB.addLog("TemplateDocPattern.validate():void, ex=" + ex.getMessage(), "", "TemplateDocPattern");
		}
	}

	private void clear() throws Exception {
		// origin - 26.03.2026, last edit - 13.04.2026
		try {
			this.src = this.id = this.code = this.description = this.defect = "";
			this.fullName = this.comment = "";
			this.arg = new ArrayList<String>();
		} catch (Exception ex) {
			WB.addLog("TemplateDocPattern.clear():void, ex=" + ex.getMessage(), "", "TemplateDocPattern");
		}
	}

	public TemplateDocPattern(String Src) throws Exception {
		// origin - 26.03.2026, last edit - 06.04.2026
		this.clear();
		this.src = Etc.fixTrim(Src);
		this.id = this.code = this.description = TemplateDocPattern.getId(this.src);

		if (Etc.strContains(this.id, "_")) {
			this.code = this.id.split("_")[0]; // ex. "FullName"
			this.description = this.id.split("_")[1]; // ex. "CurrFA"
		}

		this.getArg();
		this.validate();
	}

	public TemplateDocPattern() throws Exception {
		// origin - 26.03.2026, last edit - 26.03.2026
		this.clear();
	}

	public String toString() {
		// origin - 26.03.2026, last edit - 02.04.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addAnyway(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", arg ", this.arg);
			res = res + Fmtr.addIfNotEmpty(", arg.size ", this.arg.size());
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 26.03.2026, last edit - 13.04.2026
		try {

//			WB.addLog2("TemplateDocPattern.test.getId():List<String>", "", "TemplateDocPattern");
//			for (var tmp1 : TemplateDocPattern.getId()) {
//				WB.addLog2("TemplateDocPattern.test.getId():List<String>, ctor(tmp1)="
//						+ new TemplateDocPattern(tmp1 + "()"), "", "TemplateDocPattern");
//			}

			WB.addLog2("TemplateDocPattern.test.get(3String):String", "", "TemplateDocPattern");
			for (var tmp1 : new String[] { "2024-05-24", "2025-01-31", "2025-02-20", "2025-08-15" }) {
				for (var tmp2 : new String[] { "[FullName_CurrFA()]", "FullName_CurrFA()", "[FullName_CurrFA]",
						"FullName_CurrFA", "Face_Tralala()", "[SPL(41 600;quantity)]", "[SPL(81 600)]" }) {
					WB.addLog2("TemplateDocPattern.test.get(3String):String, res="
							+ TemplateDocPattern.get(tmp1, "", tmp2) + ", tmp1=" + tmp1 + ", tmp2=" + tmp2, "",
							"TemplateDocPattern");
				}
			}

//			WB.addLog2("TemplateDocPattern.test.isPatternId(String):boolean", "", "TemplateDocPattern");
//			for (var tmp1 : List.of(("BIC_Face;BankAccount_Face;SPL;  SPL  ;SPL___;tralala").split(";"))) {
//				WB.addLog2("TemplateDocPattern.test.isPatternId(String):boolean, res="
//						+ TemplateDocPattern.isPatternId(tmp1) + ", tmp1=" + tmp1, "", "TemplateDocPattern");
//			}

//			WB.addLog2("TemplateDocPattern.test.ctor(String)", "", "TemplateDocPattern");
//			for (var tmp1 : new String[] { "", "[SPL(12 600;quantity)]", "[SPL()]", "[SPL]", "12 600;quantity" }) {
//				WB.addLog2("TemplateDocPattern.test.ctor(String)=" + new TemplateDocPattern(tmp1) + ", tmp1=" + tmp1,
//						"", "TemplateDocPattern");
//				WB.addLog2("TemplateDocPattern.test.get(3String):String, res=" + TemplateDocPattern.get("", "", tmp1)
//						+ ", tmp1=" + tmp1, "", "TemplateDocPattern");
//			}

		} catch (Exception ex) {
			WB.addLog("TemplateDocPattern.test():void, ex=" + ex.getMessage(), "", "TemplateDocPattern");
		}
	}
}