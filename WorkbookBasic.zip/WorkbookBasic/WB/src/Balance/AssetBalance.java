public final class AssetBalance { // TODO
	// origin - 19.10.2025, last edit - 19.10.2025
	// common fields
	public String table, src, id, parent, face1, face2, face, date1, date2, code, description, geo, role, info, more,
			mark;
	// special fields
	public String fullName, comment;
	public UnitVal totalWeightGross, totalWeightNetto, totalEstimatedValue, totalPartMainDebt;
	// public Pawn total; // TOTHINK
	// list common + special + timestamp fields in unified val
	//public List<Pawn> val, total;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("AssetBalance.static ctor, ex=" + ex.getMessage(), "", "AssetBalance");
		}
	}

	public static AssetBalance get() throws Exception {// TODO
		// origin - 19.10.2025, last edit - 19.10.2025
		AssetBalance res = new AssetBalance();
		try {

		} catch (Exception ex) {
			WB.addLog("AssetBalance.get():AssetBalance, ex=" + ex.getMessage(), "", "AssetBalance");
		}
		return res;
	}

	public static AssetBalance getCurr() throws Exception {// TODO
		// origin - 19.10.2025, last edit - 19.10.2025
		AssetBalance res = new AssetBalance();
		try {

		} catch (Exception ex) {
			WB.addLog("AssetBalance.getCurr():AssetBalance, ex=" + ex.getMessage(), "", "AssetBalance");
		}
		return res;
	}

	public UnitVal getTotal(String src, String partPattern) throws Exception {// TODO
		// origin - 19.10.2025, last edit - 19.10.2025
		UnitVal res = new UnitVal();
		try {
//			switch (this) {
//			case "totalWeightGross" -> res = tmp.totalWeightGross;
//			case "totelWeightNetto" -> res = tmp.totalWeightNetto;
//			case "totalEstimatedValue" -> res = tmp.totalEstimatedValue;
//			case "tptalPartMainDebt" -> res = tmp.totalPartMainDebt;
//			default -> Etc.doNothing();
//			}
		} catch (Exception ex) {
			WB.addLog("AssetBalance.getTotal(2String):UnitVal, ex=" + ex.getMessage(), "", "AssetBalance");
		}
		return res;
	}

	// full list asset on date1
	public void getVal() throws Exception { // TODO
		// origin - 19.10.2025, last edit - 19.10.2025
		try {
//			var mDtoList = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleMarkFilter("Role.Deal.Pawn", this.mark),
//					"Asset");
//			var dealDtoList = DealDto.get(mDtoList);
//			var currDate1 = DateTool.getLocalDate(this.date1);
////			for (var tmp : DealDto.getChrono(currDate1, dealDtoList)) {
////				// this.val.add(new Pawn(tmp));
//////				new Pawn(tmp.id, tmp.parent, tmp.face1, tmp.face2, tmp.face, tmp.date1, tmp.date2, tmp.code,
//////						tmp.description, tmp.geo, tmp.role, tmp.info, tmp.more, tmp.mark);
////			}
		} catch (Exception ex) {
			WB.addLog("AssetBalance.getVal():void, ex=" + ex.getMessage(), "", "AssetBalance");
		}
	}

	public AssetBalance(String Date1, String Mark) throws Exception { // TODO
		// origin - 19.10.2025, last edit - 19.10.2025
		this.clear();
		this.table = "Asset";
		this.date1 = Date1;
		this.mark = Mark; // usually mark = Mark.TD or CD
		this.getVal();
	}

	public AssetBalance() throws Exception { // TODO
		// origin - 19.10.2025, last edit - 19.10.2025
		this.clear();
	}

	public String toString() { // TODO
		// origin - 19.10.2025, last edit - 19.10.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(" id ", this.id);
			res = res + Fmtr.addIfNotEmpty(" parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(" face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(" face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(" face ", this.face);
			res = res + Fmtr.addIfNotEmpty(" date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(" date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(" code ", this.code);
			res = res + Fmtr.addIfNotEmpty(" description ", this.description);
			res = res + Fmtr.addIfNotEmpty(" ", this.geo);
			res = res + Fmtr.addIfNotEmpty(" ", this.role);
			res = res + Fmtr.addIfNotEmpty(" ", this.info);
			res = res + Fmtr.addIfNotEmpty(" more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(" ", this.mark);
			//res = res + Fmtr.addIfNotEmpty(" val ", this.val.size());
			res = res + Fmtr.addIfNotEmpty(" totalEstimatedValue ", this.totalEstimatedValue.id);
			res = res + Fmtr.addIfNotEmpty(" totalPartMainDebt ", this.totalPartMainDebt.id);
			res = res + Fmtr.addIfNotEmpty(" totalWeightGross ", this.totalWeightGross.id);
			res = res + Fmtr.addIfNotEmpty(" totalWeightNetto ", this.totalWeightNetto.id);
			//res = res + Fmtr.addIfNotEmpty(" total ", this.total);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	private void clear() throws Exception { // TODO
		// origin - 19.10.2025, last edit - 19.10.2025
		try {
			this.table = "Asset";
			this.src = this.id = this.parent = this.date1 = this.date2 = this.face1 = this.face2 = this.face = this.code = this.description = "";
			this.geo = this.role = this.info = this.more = this.mark = "";
			this.fullName = this.comment = "";
			this.totalEstimatedValue = this.totalPartMainDebt = new UnitVal(UnitVal.currCurrencyInit);
			this.totalWeightGross = this.totalWeightNetto = new UnitVal("0.0(Unit.Gr)");
			//this.val = this.total = new ArrayList<Pawn>();
		} catch (Exception ex) {
			WB.addLog("AssetBalance.clear():void, ex=" + ex.getMessage(), "", "AssetBalance");
		}
	}

	public static void test() throws Exception { // TODO
		// origin - 19.10.2025, last edit - 23.10.2025
		try {

//			WB.addLog2("AssetBalance.test.ctor(2String)", "", "AssetBalance");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01" }) {
//				var tmp = new AssetBalance(tmp1, "Mark.TD");
//				WB.addLog2("AssetBalance.test.ctor(2String).val.size=" + tmp.val.size() + ", date=" + tmp1, "",
//						"AssetBalance");
//				WB.log(tmp.val, "Asset val");
//				WB.log(tmp.total, "Asset total");
//			}

		} catch (Exception ex) {
			WB.addLog("AssetBalance.test():void, ex=" + ex.getMessage(), "", "AssetBalance");
		}
	}
}