import java.util.ArrayList;
import java.util.List;

public final class Role {
	// origin - 06.12.2023, last edit - 10.09.2026
	// common fields
	public String table, src, id, parent, date1, date2, code, description, more, fullName, comment, defect;
	// special fields
	public static String priceExchangeCurrency, accountStandardTable;

	static {
		Role.priceExchangeCurrency = "Role.Price.ExchangeCurrency";
		Role.accountStandardTable = "Role.Account.AccTable";
		try {
		} catch (Exception ex) {
			WB.addLog("Role.static ctor, ex=" + ex.getMessage(), "", "Role");
		}
	}

	public static FullDto getFullDtoByList(List<String> in) throws Exception {
		// origin - 02.03.2026, last edit - 02.03.2026
		FullDto res = new FullDto();
		try {
			res.table = "Role";
			res.id = Etc.fixTrim(in.get(0));
			res.parent = Etc.fixTrim(in.get(1));
			res.date1 = Etc.fixTrim(in.get(2));
			res.date2 = Etc.fixTrim(in.get(3));
			res.code = Etc.fixTrim(in.get(4));
			res.description = Etc.fixTrim(in.get(5));
			res.more = Etc.fixTrim(in.get(6));
		} catch (

		Exception ex) {
			WB.addLog("Role.getFullDtoByList(List<String>):FullDto, ex=" + ex.getMessage(), "", "Role");
		}
		return res;
	}

	public static List<String> getListByFullDto(FullDto in) throws Exception {
		// origin - 31.01.2026, last edit - 01.03.2026
		List<String> res = new ArrayList<String>();
		try {
			res.add(in.id);
			res.add(in.parent);
			res.add(in.date1);
			res.add(in.date2);
			res.add(in.code);
			res.add(in.description);
			res.add(in.more);
		} catch (Exception ex) {
			WB.addLog("Role.getByTable(FullDto):List<String>, ex=" + ex.getMessage(), "", "Role");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 22.11.2025, last edit - 22.11.2025
		try {
		} catch (Exception ex) {
			WB.addLog("Role.validate():void, ex=" + ex.getMessage(), "", "Role");
		}
	}

	private List<FullDto> getFastListDto() throws Exception {
		// origin - 10.08.2026, last edit - 10.08.2026
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			var tmp = WB.abcLast.role;
			res = ReadSet.getEqualsByCode(tmp, this.code);
			if (res.size() == 0) {
				res = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.code), "Role");
			}
		} catch (Exception ex) {
			WB.addLog("Role.getFastListDto():void, ex=" + ex.getMessage(), "", "Role");
		}
		return res;
	}

	private void isExist() throws Exception {
		// origin - 17.12.2024, last edit - 10.08.2026
		try {
			// var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.code),
			// "Role");
			var listDto = this.getFastListDto();
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.date1 = DefVal.setCustom(this.date1, dto.date1);
				this.date2 = DefVal.setCustom(this.date2, dto.date2);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.parent = DefVal.setCustom(this.parent, dto.parent);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.getFieldFromMore();
			}
		} catch (Exception ex) {
			WB.addLog("Role.isExist():void, ex=" + ex.getMessage(), "", "Role");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 12.08.2025, last edit - 10.09.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("Deal.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	public Role(String Id) throws Exception {
		// origin - 06.12.2023, last edit - 22.11.2025
		this.clear();
		this.src = Id;
		if (Id.isEmpty() == false) {
			this.id = this.code = Id;
		}
		this.isExist();
		this.validate();
	}

	public Role() throws Exception {
		// origin - 06.12.2023, last edit - 19.05.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 09.12.2024, last edit - 10.09.2026
		try {
			this.table = "Role";
			this.fullName = this.comment = this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.more = "";
			this.defect = "";
		} catch (Exception ex) {
			WB.addLog("Role.clear()(:void, ex=" + ex.getMessage(), "", "Role");
		}
	}

	public String toString() {
		// origin - 27.09.2024, last edit - 22.11.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 06.12.2023, last edit - 14.06.2025
		try {

//			WB.addLog2("Role.test.ctor(String)", "", "Role");
//			for (var tmp : new String[] { "", "Role.Asset", "Role.tralala", "Role.Deal" }) {
//				WB.addLog2("Role.test.ctor(String)=" + new Role(tmp), "", "Role");
//			}

		} catch (Exception ex) {
			WB.addLog("Role.test():void, ex=" + ex.getMessage(), "", "Role");
		}
	}
}