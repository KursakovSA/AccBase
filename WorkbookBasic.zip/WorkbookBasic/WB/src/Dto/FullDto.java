import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public final class FullDto {
	// origin - 30.09.2023, last edit - 04.01.2026
	public String src, table, id, parent, face1, face2, face, slice, date1, date2, code, description, sign, account;
	public String geo, role, info, debt, item, meter, meterValue, unit, more, mark, process, asset, deal, templateId,
			defect;
	public List<FullDto> lowerList, upperList;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("FullDto.static ctor, ex=" + ex.getMessage(), "", "FullDto");
		}
	}

	public void fix() throws Exception { // TODO
		// origin - 30.04.2026, last edit - 02.05.2026
		try {
			this.slice = DefVal.set(this.slice, "Slice.Accounting");
			this.date1 = DefVal.set(this.date1, WB.minDateSupported.toString());
			this.date2 = DefVal.set(this.date2, WB.maxDateSupported.toString());
			this.mark = DefVal.set(this.mark, "Mark.DD");
		} catch (Exception ex) {
			WB.addLog("FullDto.fix():void, ex=" + ex.getMessage(), "", "FullDto");
		}
	}

	public static List<FullDto> getChronoSpan(SpanDate spanDate, List<FullDto> listFullDto) throws Exception {
		// origin - 15.07.2026, last edit - 15.07.2026
		List<FullDto> res = new ArrayList<FullDto>();
		LocalDate currDate1;
		LocalDate currDate2;
		try {
			LocalDate spanDate1 = DateTool.getLocalDate(spanDate.date1.getFirst());
			LocalDate spanDate2 = DateTool.getLocalDate(spanDate.date2.getFirst());
			for (var currDto : listFullDto) {
				currDto.fix();
				currDate1 = DateTool.getLocalDate(currDto.date1);// left border in data
				currDate2 = DateTool.getLocalDate(currDto.date2);// right border in data

				if (currDate1.isBefore(spanDate1)) {
					continue;
				}

				if (currDate2.isAfter(spanDate2)) {
					continue;
				}

				if ((Etc.strEquals(currDate1.toString(), spanDate1.toString()))
						& (Etc.strEquals(currDate2.toString(), spanDate2.toString()))) {
					res.add(currDto);
					continue;
				}

				if ((Etc.strEquals(currDate1.toString(), spanDate1.toString())) & (currDate2.isBefore(spanDate2))) {
					res.add(currDto);
					continue;
				}

				if ((currDate1.isAfter(spanDate1)) & (Etc.strEquals(currDate2.toString(), spanDate2.toString()))) {
					res.add(currDto);
					continue;
				}

				if ((currDate1.isAfter(spanDate1)) & (currDate2.isBefore(spanDate2))) {
					res.add(currDto);
					continue;
				}
			}
		} catch (Exception ex) {
			WB.addLog("FullDto.getChronoSpan(SpanDate, List<FullDto>):List<FullDto>, ex=" + ex.getMessage(), "",
					"FullDto");
		}
		return res;
	}

	public static List<FullDto> getChrono(LocalDate calcDate, List<FullDto> listFullDto) throws Exception {
		// origin - 30.04.2026, last edit - 02.05.2026
		List<FullDto> res = new ArrayList<FullDto>();
		LocalDate currDate1;
		LocalDate currDate2;
		try {
			for (var currDto : listFullDto) {
				currDto.fix();
				currDate1 = DateTool.getLocalDate(currDto.date1);// left border in data
				currDate2 = DateTool.getLocalDate(currDto.date2);// right border in data

				// left border hit or right border hit
				if ((Etc.strEquals(currDate1.toString(), calcDate.toString()))
						|| (Etc.strEquals(currDate2.toString(), calcDate.toString()))) {
					res.add(currDto);
					continue;
				}

				// range from left border to right border hit
				if ((currDate1.isBefore(calcDate)) && (currDate2.isAfter(calcDate))) {
					res.add(currDto);
					continue;
				}
			}
		} catch (Exception ex) {
			WB.addLog("FullDto.getChrono(LocalDate, List<FullDto>):List<FullDto>, ex=" + ex.getMessage(), "",
					"FullDto");
		}
		return res;
	}

//	public static List<FullDto> getTotalByUnit(List<FullDto> in) throws Exception { // TODO
//		// origin - 14.02.2026, last edit - 14.02.2026
//		List<FullDto> res = new ArrayList<FullDto>();
//		try {
//
//		} catch (Exception ex) {
//			WB.addLog("FullDto.getTotalByUnit(List<FullDto>):List<FullDto>, ex=" + ex.getMessage(), "", "FullDto");
//		}
//		return res;
//	}

	public static List<String> getList(FullDto in) throws Exception {
		// origin - 29.01.2026, last edit - 01.03.2026
		List<String> res = new ArrayList<String>();
		try {
			res.add(in.table);
			res.add(in.id);
			res.add(in.parent);
			res.add(in.face1);
			res.add(in.face2);
			res.add(in.face);
			res.add(in.slice);
			res.add(in.date1);
			res.add(in.date2);
			res.add(in.code);
			res.add(in.description);
			res.add(in.geo);
			res.add(in.sign);
			res.add(in.account);
			res.add(in.process);
			res.add(in.asset);
			res.add(in.deal);
			res.add(in.role);
			res.add(in.info);
			res.add(in.meter);
			res.add(in.meterValue);
			res.add(in.unit);
			res.add(in.more);
			res.add(in.mark);
		} catch (Exception ex) {
			WB.addLog("FullDto.getData(FullDto):List<String>, ex=" + ex.getMessage(), "", "FullDto");
		}
		return res;
	}

	public static List<FullDto> get(List<BasicDto> bDto) throws Exception {
		// origin - 12.08.2026, last edit - 12.08.2026
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			if (bDto.size() != 0) {
				for (var tmp : bDto) {
					res.add(new FullDto(tmp));
				}
			}
		} catch (Exception ex) {
			WB.addLog("BasicDto.get(List<BasicDto>):List<FullDto>, ex=" + ex.getMessage(), "", "FullDto");
		}
		return res;
	}

	public static List<FullDto> getByTable(String table) throws Exception {
		// origin - 12.08.2026, last edit - 12.08.2026
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			var tmp = Abc.get(table);
			if (tmp.size() == 0) {
				tmp = DAL.getTable(WB.lastConnWork, Qry.getText(WB.lastConnWork, table, ""));
			}
			if (tmp.size() != 0) {
				res = tmp;
			}
		} catch (Exception ex) {
			WB.addLog("FullDto.getByTable(String):List<FullDto>, ex=" + ex.getMessage(), "", "FullDto");
		}
		return res;
	}

	public static List<FullDto> getUpper(String table, String id) throws Exception {
		// origin - 03.03.2026, last edit - 03.03.2026
		List<FullDto> res = new ArrayList<FullDto>();

		if (Etc.fixTrim(table).isEmpty()) {
			return res;
		}

		if (Etc.fixTrim(id).isEmpty()) {
			return res;
		}

		try {
			var tmp1 = Qry.getUpper(table, id);
			res = DAL.getTable(WB.lastConnWork, tmp1);
		} catch (Exception ex) {
			WB.addLog("FullDto.getUpper(2String):List<FullDto>, ex=" + ex.getMessage(), "", "FullDto");
		}
		return res;
	}

	public static List<FullDto> getLower(String table, String id) throws Exception {
		// origin - 03.03.2026, last edit - 30.06.2026
		List<FullDto> res = new ArrayList<FullDto>();

		if (Etc.fixTrim(table).isEmpty()) {
			return res;
		}

		if (Etc.fixTrim(id).isEmpty()) {
			return res;
		}

		try {
			var tmp1 = Qry.getLower(table, id);
			res = DAL.getTable(WB.lastConnWork, tmp1);
		} catch (Exception ex) {
			WB.addLog("FullDto.getLower(2String):List<FullDto>, ex=" + ex.getMessage(), "", "FullDto");
		}
		return res;
	}

	public static boolean isContains(List<FullDto> lst, FullDto dto) throws Exception {
		// origin - 17.12.2024, last edit - 14.06.2025
		boolean res = false;
		try {
			for (var curr : lst) {
				if (Etc.strEquals(curr.code, dto.code)) {
					res = true;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("FullDto.isContains(List<FullDto>, FullDto):boolean, ex=" + ex.getMessage(), "", "FullDto");
		}
		return res;
	}

	public static String getDate2(String date2) throws Exception {
		// origin - 09.02.2024, last edit - 14.06.2025
		String res = Etc.fixTrim(date2);
		if (res.isEmpty()) {
			try {
				res = DateTool.getLocalDate("").toString();

			} catch (Exception ex) {
				WB.addLog("FullDto.getIDate2(String):String, ex=" + ex.getMessage(), "", "FullDto");
			}
		}
		return res;
	}

	public String getId() { // for Abc.getLower, Abc.getUpper
		// origin - 13.08.2026, last edit - 13.08.2026
		String res = this.id;
		return res;
	}

	public String getParent() { // for Abc.getLower, Abc.getUpper
		// origin - 13.08.2026, last edit - 13.08.2026
		String res = this.parent;
		return res;
	}

	public static String getDate1(String date1) throws Exception {
		// origin - 09.02.2024, last edit - 14.06.2025
		String res = Etc.fixTrim(date1);
		if (res.isEmpty()) {
			try {
				res = DateTool.getLocalDate("").toString();
			} catch (Exception ex) {
				WB.addLog("FullDto.getDate1(String):String, ex=" + ex.getMessage(), "", "FullDto");
			}
		}
		return res;
	}

	public static String getFieldByKey(String inStr, String key) throws Exception {
		// origin - 15.11.2024, last edit - 14.06.2025
		String res = "";
		inStr = Etc.fixTrim(inStr);
		try {
			String[] items = inStr.split(" " + "\\|" + " "); // "\\" this is protective shielding

			int indexSignEquals = 0;
			String strKey = "";
			String splitEquation = "@";
			for (var currEquation : items) {
				indexSignEquals = 0;
				indexSignEquals = currEquation.lastIndexOf(splitEquation);
				if (indexSignEquals > 0) {
					strKey = "";
					strKey = currEquation.substring(0, indexSignEquals);
					strKey = Etc.fixTrim(strKey);
					if ((strKey.isEmpty() == false) && (Etc.strEquals(key, strKey))) {
						res = currEquation.substring(indexSignEquals + 1, currEquation.length());
						res = Etc.fixTrim(res);
					}
				}
			}

		} catch (Exception ex) {
			WB.addLog("FullDto.getFieldByKey(2String):String, ex=" + ex.getMessage() + ", res=" + res, "", "FullDto");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 21.11.2025, last edit - 21.11.2025
		try {
		} catch (Exception ex) {
			WB.addLog("FullDto.validate():void, ex=" + ex.getMessage(), "", "FullDto");
		}
	}

	public FullDto(FullDto in) throws Exception {
		// origin - 02.01.2024, last edit - 30.04.2026
		this.clear();
		this.src = in.src;
		this.table = in.table;
		this.id = in.id;
		this.parent = in.parent;
		this.face1 = in.face1;
		this.face2 = in.face2;
		this.face = in.face;
		this.slice = in.slice;
		this.date1 = in.date1;
		this.date2 = in.date2;
		this.code = in.code;
		this.description = in.description;
		this.sign = in.sign;
		this.account = in.account;
		this.geo = in.geo;
		this.role = in.role;
		this.info = in.info;
		this.meter = in.meter;
		this.meterValue = in.meterValue;
		this.unit = in.unit;
		this.more = in.more;
		this.mark = in.mark;
		this.process = in.process;
		this.asset = in.asset;
		this.deal = in.deal;
		this.fix();
		this.validate();
	}

	public FullDto(BasicDto bDto) throws Exception {
		// origin - 12.08.2026, last edit - 12.08.2026
		this.clear();
		this.id = bDto.id;
		this.parent = bDto.parent;
		this.date1 = bDto.date1;
		this.date2 = bDto.date2;
		this.face1 = bDto.face1;
		this.face2 = bDto.face2;
		this.face = bDto.face;
		this.code = bDto.code;
		this.description = bDto.description;
		this.role = bDto.role;
		this.info = bDto.info;
		this.geo = bDto.geo;
		this.unit = bDto.unit;
		this.sign = bDto.sign;
		this.more = bDto.more;
		this.mark = bDto.mark;
		this.fix();
		this.validate();
	}

	public FullDto(DealDto dDto) throws Exception {
		// origin - 05.09.2025, last edit - 30.04.2026
		this.clear();
		this.table = "Deal";
		this.id = dDto.id;
		this.parent = dDto.parent;
		this.face1 = dDto.face1;
		this.face2 = dDto.face2;
		this.face = dDto.face;
		this.date1 = dDto.date1;
		this.date2 = dDto.date2;
		this.code = dDto.code;
		this.description = dDto.description;
		this.geo = dDto.geo;
		this.role = dDto.role;
		this.info = dDto.info;
		this.more = dDto.more;
		this.mark = dDto.mark;
		this.fix();
		this.validate();
	}

	public FullDto(String Table, String Id, String Parent, String Face1, String Face2, String Face, String Slice,
			String Date1, String Date2, String Code, String Description, String Sign, String Account, String Geo,
			String Role, String Info, String Meter, String MeterValue, String Unit, String More, String Mark,
			String Process, String Asset, String Deal) throws Exception {
		// origin - 02.11.2023, last edit - 30.04.2026
		this.clear();
		this.table = Table;
		this.id = Id;
		this.parent = Parent;
		this.face1 = Face1;
		this.face2 = Face2;
		this.face = Face;
		this.slice = Slice;
		this.date1 = Date1;
		this.date2 = Date2;
		this.code = Code;
		this.description = Description;
		this.sign = Sign;
		this.account = Account;
		this.geo = Geo;
		this.role = Role;
		this.info = Info;
		this.meter = Meter;
		this.meterValue = MeterValue;
		this.unit = Unit;
		this.more = More;
		this.mark = Mark;
		this.process = Process;
		this.asset = Asset;
		this.deal = Deal;
		this.fix();
		this.validate();
	}

	public void clear() throws Exception {
		// origin - 31.12.2023, last edit - 04.01.2026
		try {
			this.src = this.table = this.id = this.parent = this.face1 = this.face2 = this.defect = "";
			this.face = this.slice = this.date1 = this.date2 = this.code = this.description = "";
			this.sign = this.account = this.geo = this.role = this.debt = this.item = this.info = this.meter = this.meterValue = "";
			this.unit = this.more = this.mark = this.process = this.asset = this.deal = this.templateId = "";
			this.lowerList = new ArrayList<FullDto>();
			this.upperList = new ArrayList<FullDto>();
		} catch (Exception ex) {
			WB.addLog("FullDto.clear():void, ex=" + ex.getMessage(), "", "FullDto");
		}
	}

	public FullDto() throws Exception {
		// origin - 02.11.2023, last edit - 24.11.2024
		this.clear();
	}

	public String toString() {
		// origin - 30.09.2023, last edit - 21.11.2025
		String res = "";
		try {
			// res = res + Fmtr.addIfNotEmpty("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", ", this.slice);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.sign);
			res = res + Fmtr.addIfNotEmpty(", ", this.account);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", ", this.process);
			res = res + Fmtr.addIfNotEmpty(", ", this.asset);
			res = res + Fmtr.addIfNotEmpty(", ", this.deal);
			res = res + Fmtr.addIfNotEmpty(", ", this.meter);
			res = res + Fmtr.addIfNotEmpty(", meterValue ", this.meterValue);
			res = res + Fmtr.addIfNotEmpty(", ", this.unit);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 12.10.2023, last edit - 03.03.2026
		try {

//			var tmp1 = new Debt("Debt.GFSS");
//			WB.addLog2("FullDto.test.isContains()=" + FullDto.isContains(WB.abcLast.debt, tmp1)
//					+ ", Debt.GFSS in WB.abcLast.debt", "", "FullDto");
//			var tmp2 = new Debt("Debt.tralala");
//			WB.addLog2("FullDto.test.isContains()=" + FullDto.isContains(WB.abcLast.debt, tmp2)
//					+ ", Debt.tralala in WB.abcLast.debt", "", "FullDto");

//			var res1 = new FullDto("Id1", "Code1", "Description1");
//			WB.addLog2("FullDto.test.ctor(Id, Code, Description), res1=" + res1, "", "FullDto");
//			var res1Clone = new FullDto(res1);
//			WB.addLog2("FullDto.test.ctor(res1), res1Clone=" + res1Clone, "", "FullDto");

		} catch (Exception ex) {
			WB.addLog("FullDto.test():void, ex=" + ex.getMessage(), "", "FullDto");
		}
	}
}