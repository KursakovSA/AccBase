import java.util.ArrayList;
import java.util.List;

public final class Account {
	// origin - 27.09.2023, last edit - 20.06.2026
	// common fields
	public String table, src, id, parent, date1, date2, code, description, role, sign, more, defect;
	// special fields
	public String fullName, comment, normCode;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Account.static ctor, ex=" + ex.getMessage(), "", "Account");
		}
	}

	public static List<String> getUserListView(List<Account> in) throws Exception { // ex, "счет "Товары"
		// origin - 20.06.2026, last edit - 20.06.2026
		List<String> res = new ArrayList<String>();
		try {
			for (var curr : in) {
				res.add(Account.getUserView(curr));
			}
		} catch (Exception ex) {
			WB.addLog("Account.getUserListView(Account):String, ex=" + ex.getMessage(), "", "Account");
		}
		return res;
	}

	public static String getUserView(Account in) throws Exception { // ex, "счет "Товары"
		// origin - 17.06.2026, last edit - 17.06.2026
		String res = "";
		try {
			if (in.code.isEmpty() == false) {
				res = "Счет " + in.description; // TOTHINK
			}
		} catch (Exception ex) {
			WB.addLog("Account.getUserView(Account):String, ex=" + ex.getMessage(), "", "Account");
		}
		return res;
	}

	public static String getNormView(Account in) throws Exception { // ex, "1210;Задолженность покупателей"
		// origin - 17.06.2026, last edit - 20.06.2026
		String res = "";
		try {
			if (in.normCode.isEmpty() == false) {
				res = res + in.normCode;
			}

			var tmp = Account.getNormDescriptionByCode(in.normCode);
			if (tmp.isEmpty() == false) {
				res = res + ";" + tmp;
			}
		} catch (Exception ex) {
			WB.addLog("Account.getNormView(Account):String, ex=" + ex.getMessage(), "", "Account");
		}
		return res;
	}

	private static String getNormDescriptionByCode(String normCode) throws Exception {
		// origin - 20.06.2026, last edit - 12.08.2026
		String res = "";
		try {
			if (normCode.isEmpty()) {
				return res;
			}

			var tmp = InOut.getStrPathFileByFileNameInAppDir("CurrAccountPlan.csv");
			// for (var curr : Account.getNormListView(WB.commonDocDir + File.separator +
			// "CurrAccountPlan.csv")) {
			for (var curr : Account.getNormListView(tmp)) {
				var tmp1 = List.of(curr.split(";")).get(0);
				var tmp2 = List.of(curr.split(";")).get(1);
				if (tmp1.isEmpty() == false) {
					if (tmp2.isEmpty() == false) {
						if (Etc.strEquals(tmp1, normCode)) {
							res = tmp2;
							break;
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Account.getNormDescriptionByCode(String):String, ex=" + ex.getMessage(), "", "Account");
		}
		return res;
	}

	public static List<String> getNormListView(String fileCSV) throws Exception {
		// origin - 17.06.2026, last edit - 20.06.2026
		List<String> res = new ArrayList<String>();
		try {
			var tmp1 = CSV.getListByPath(fileCSV);
			// Account.getNormList(fileCSV);
			for (var curr : tmp1) {
				var tmp2 = List.of(curr.split(";"));
				if (tmp2.size() >= 2) {
					if (Etc.isDigitAll(tmp2.get(0)) == false) { // skip "Код;Наименование;..."
						continue;
					}

					var tmp3 = tmp2.get(0) + ";" + tmp2.get(1); // ex. "1210;Задолженность...."
					res.add(tmp3);
				}
			}
		} catch (Exception ex) {
			WB.addLog("Account.getNormListView(String):List<String>, ex=" + ex.getMessage(), "", "Account");
		}
		return res;
	}

	public static FullDto getFullDtoByList(List<String> in) throws Exception {
		// origin - 02.03.2026, last edit - 02.03.2026
		FullDto res = new FullDto();
		try {
			res.table = "Account";
			res.id = Etc.fixTrim(in.get(0));
			res.parent = Etc.fixTrim(in.get(1));
			res.slice = Etc.fixTrim(in.get(2));
			res.date1 = Etc.fixTrim(in.get(3));
			res.date2 = Etc.fixTrim(in.get(4));
			res.code = Etc.fixTrim(in.get(5));
			res.description = Etc.fixTrim(in.get(6));
			res.role = Etc.fixTrim(in.get(7));
			res.sign = Etc.fixTrim(in.get(8));
			res.more = Etc.fixTrim(in.get(9));
		} catch (Exception ex) {
			WB.addLog("Account.getFullDtoByList(List<String>):FullDto, ex=" + ex.getMessage(), "", "Account");
		}
		return res;
	}

	public static List<String> getListByFullDto(FullDto in) throws Exception {
		// origin - 31.01.2026, last edit - 01.03.2026
		List<String> res = new ArrayList<String>();
		try {
			res.add(in.id);
			res.add(in.parent);
			res.add(in.slice);
			res.add(in.date1);
			res.add(in.date2);
			res.add(in.code);
			res.add(in.description);
			res.add(in.role);
			res.add(in.sign);
			res.add(in.more);
		} catch (Exception ex) {
			WB.addLog("Account.getListByFullDto(FullDto):List<String>, ex=" + ex.getMessage(), "", "Account");
		}
		return res;
	}

//	public static List<FullDto> get() throws Exception {
//		// origin - 30.11.2025, last edit - 16.06.2026
//		List<FullDto> res = new ArrayList<FullDto>();
//		try {
//			res = DAL.getTable(WB.lastConnWork, Qry.getText(WB.lastConnWork, "Account", ""));
//		} catch (Exception ex) {
//			WB.addLog("Account.get():List<FullDto>, ex=" + ex.getMessage(), "", "Account");
//		}
//		return res;
//	}

	private void validate() throws Exception { // TODO
		// origin - 21.11.2025, last edit - 21.11.2025
		try {
		} catch (Exception ex) {
			WB.addLog("Account.validate():void, ex=" + ex.getMessage(), "", "Account");
		}
	}

	private void fix() throws Exception {
		// origin - 12.12.2024, last edit - 16.06.2026
		try {
			if (this.role.isEmpty() && (this.parent.isEmpty() == false)) {
				Account accParent = new Account(this.parent);
				if (accParent.role.isEmpty() == false) {
					this.role = accParent.role;
				}
			}

			if (this.sign.isEmpty() && (this.parent.isEmpty() == false)) {
				Account accParent = new Account(this.parent);
				if (accParent.sign.isEmpty() == false) {
					this.sign = accParent.sign;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Account.fix():void, ex=" + ex.getMessage(), "", "Account");
		}
	}

	private List<FullDto> getFastListDto() throws Exception {
		// origin - 10.08.2026, last edit - 10.08.2026
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			var tmp = WB.abcLast.account;
			res = ReadSet.getEqualsByCode(tmp, this.code);
			if (res.size() == 0) {
				res = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.code), "Account");
			}
		} catch (Exception ex) {
			WB.addLog("Account.getFastListDto():void, ex=" + ex.getMessage(), "", "Account");
		}
		return res;
	}

	private void isExist() throws Exception {
		// origin - 08.12.2024, last edit - 10.08.2026
		try {
			// var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id),
			// "Account");
			var listDto = this.getFastListDto();
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.date1 = DefVal.setCustom(this.date1, dto.date1);
				this.date2 = DefVal.setCustom(this.date2, dto.date2);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.code = DefVal.setCustom(this.code, dto.id);
				this.parent = DefVal.setCustom(this.parent, dto.parent);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.role = DefVal.setCustom(this.role, dto.role);
				this.sign = DefVal.setCustom(this.sign, dto.sign);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.getFieldFromMore();
			}
		} catch (Exception ex) {
			WB.addLog("Account.isExist():void, ex=" + ex.getMessage(), "", "Account");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 12.08.2025, last edit - 21.06.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.normCode = MoreVal.getFieldByKey(this.more, "NormCode");
		} catch (Exception ex) {
			WB.addLog("Account.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Account");
		}
	}

	public Account(String Id) throws Exception {
		// origin - 05.12.2023, last edit - 20.06.2026
		this.clear();
		this.src = this.id = Id;
		this.isExist();
		this.fix();
		this.validate();
	}

	public Account() throws Exception {
		// origin - 04.12.2023, last edit - 19.05.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 09.12.2024, last edit - 20.06.2026
		try {
			this.table = "Account";
			this.id = this.parent = this.date1 = this.date2 = this.code = this.description = "";
			this.role = this.sign = this.more = this.defect = this.fullName = this.comment = this.normCode = "";
		} catch (Exception ex) {
			WB.addLog("Account.clear():void, ex=" + ex.getMessage(), "", "Account");
		}
	}

	public String toString() {
		// origin - 27.09.2024, last edit - 20.06.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.sign);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addAnyway(", fullName ", this.fullName);
			res = res + Fmtr.addAnyway(", comment ", this.comment);
			res = res + Fmtr.addAnyway(", normCode ", this.normCode);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 20.06.2026
		try {

//			WB.addLog2("Account.test.getNormDescriptionByCode(String):String", "", "Account");
//			for (var tmp1 : new String[] { "", "1210", "21122121212" }) {
//				WB.addLog2("Account.test.getNormDescriptionByCode(String):String, res="
//						+ Account.getNormDescriptionByCode(tmp1) + ", tmp1=" + tmp1, "", "Account");
//			}

//			WB.addLog2("Account.test.getNormListView(String):List<String>", "", "Account");
//			for (var tmp1 : new String[] { "CurrAccountPlan.csv", "tralala.csv" }) {
//				var tmp2 = Account.getNormListView(WB.commonDocDir + File.separator + tmp1);
//				WB.addLog2("Account.test.getNormListView(String):List<String>, res.size=" + tmp2.size(), "", "Account");
//				//WB.log(tmp2, "Account");
//			}

		} catch (Exception ex) {
			WB.addLog("Account.test():void, ex=" + ex.getMessage(), "", "Account");
		}
	}
}