import java.util.ArrayList;
import java.util.List;

public final class Meter {
	// origin - 28.09.2023, last edit - 22.11.2025
	// common fields
	public String table, src, id, parent, date1, date2, code, description, more, defect;
	// special fields

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Meter.static ctor, ex=" + ex.getMessage(), "", "Meter");
		}
	}

	public static FullDto getFullDtoByList(List<String> in) throws Exception {
		// origin - 02.03.2026, last edit - 02.03.2026
		FullDto res = new FullDto();
		try {
			res.table = "Meter";
			res.id = Etc.fixTrim(in.get(0));
			res.parent = Etc.fixTrim(in.get(1));
			res.date1 = Etc.fixTrim(in.get(2));
			res.date2 = Etc.fixTrim(in.get(3));
			res.code = Etc.fixTrim(in.get(4));
			res.description = Etc.fixTrim(in.get(5));
			res.more = Etc.fixTrim(in.get(6));
		} catch (

		Exception ex) {
			WB.addLog("Meter.getFullDtoByList(List<String>):FullDto, ex=" + ex.getMessage(), "", "Meter");
		}
		return res;
	}

	public static List<String> getListByFullDto(FullDto in) throws Exception {
		// origin - 31.01.2026, last edit - 01.03.2026
		List<String> res = new ArrayList<String>();
		try {
			res.add(in.id);
			res.add(in.parent);
			res.add(in.date1);
			res.add(in.date2);
			res.add(in.code);
			res.add(in.description);
			res.add(in.more);
		} catch (Exception ex) {
			WB.addLog("Meter.getListByFullDto(FullDto):List<String>, ex=" + ex.getMessage(), "", "Meter");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 22.11.2025, last edit - 22.11.2025
		try {
		} catch (Exception ex) {
			WB.addLog("Meter.validate():void, ex=" + ex.getMessage(), "", "Meter");
		}
	}

	private List<FullDto> getFastListDto() throws Exception {
		// origin - 10.08.2026, last edit - 10.08.2026
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			var tmp = WB.abcLast.meter;
			res = ReadSet.getEqualsByCode(tmp, this.code);
			if (res.size() == 0) {
				res = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.code), "Meter");
			}
		} catch (Exception ex) {
			WB.addLog("Meter.getFastListDto():void, ex=" + ex.getMessage(), "", "Meter");
		}
		return res;
	}

	private void isExist() throws Exception {
		// origin - 08.10.2024, last edit - 10.09.2026
		try {
			// var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.code),
			// "Meter");
			var listDto = this.getFastListDto();
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.code = dto.code;
				this.description = dto.description;
				this.parent = dto.parent;
				this.more = dto.more;
			}
		} catch (Exception ex) {
			WB.addLog("Meter.isExist():void, ex=" + ex.getMessage(), "", "Meter");
		}
	}

	public Meter(String Id) throws Exception {
		// origin - 05.12.2023, last edit - 22.11.2025
		this.clear();
		this.src = Id;
		if (Id.isEmpty() == false) {
			this.id = this.code = Id;
		}
		this.isExist();
		this.validate();
	}

	public Meter() throws Exception {
		// origin - 05.12.2023, last edit - 19.05.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 21.12.2024, last edit - 22.11.2025
		try {
			this.table = "Meter";
			this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.more = "";
		} catch (Exception ex) {
			WB.addLog("Meter.clear():void, ex=" + ex.getMessage(), "", "Meter");
		}
	}

	public String toString() {
		// origin - 21.12.2024, last edit - 10.09.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 13.06.2025
		try {

//			// ctor (String)
//			WB.addLog2("Meter.test.ctor(String)", "", "Meter");
//			for (var tmp : new String[] { "", "Meter.Amount", "Meter.tralala", "Meter.GrossWeight/NetWeight" }) {
//				WB.addLog2("Meter.test.ctor(String)=" + new Meter(tmp), "", "Meter");
//			}

		} catch (Exception ex) {
			WB.addLog("Meter.test():void, ex=" + ex.getMessage(), "", "Meter");
		}
	}
}