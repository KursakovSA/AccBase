import java.util.ArrayList;
import java.util.List;

public final class AccountClosingRule {
	// origin - 22.06.2026, last edit - 22.06.2026
	public String src, id, partFrom, partTo;
	private static List<String> listDelStr;
	public List<String> from;
	public String to;

	static {
		try {
			AccountClosingRule.listDelStr = List.of("->", ";");
		} catch (Exception ex) {
			WB.addLog("AccountClosingRule.static ctor, ex=" + ex.getMessage(), "", "AccountClosingRule");
		}
	}

	private void getFrom() throws Exception {
		// origin - 22.06.2026, last edit - 22.06.2026
		try {
			String tmp = this.partFrom;
			var tmp1 = "";
			var tmp2 = "";

			int posLocalSplit = tmp.indexOf("-"); // pos " - "
			if (posLocalSplit > 0) {
				tmp1 = Etc.fixTrim(tmp.substring(0, posLocalSplit));
				tmp1 = Etc.delStr(tmp1, "-");
				tmp1 = Etc.fixTrim(tmp1);

				tmp2 = Etc.fixTrim(tmp.substring(posLocalSplit));
				tmp2 = Etc.delStr(tmp2, ";");
				tmp2 = Etc.delStr(tmp2, "-");
				tmp2 = Etc.fixTrim(tmp2);
			} else {
				tmp1 = Etc.fixTrim(this.partFrom);
			}

			if (tmp1.isEmpty() == false) {
				this.from.add(tmp1);
				if (tmp2.isEmpty() == false) {
					var numb1 = Integer.valueOf(tmp1);
					var numb2 = Integer.valueOf(tmp2);
					int tmp3 = numb1;
					if (numb1 <= numb2) {
						while (tmp3 < numb2) {
							tmp3 = tmp3 + 1;
							this.from.add(String.valueOf(tmp3));
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("AccountClosingRule.getFrom():void, ex=" + ex.getMessage(), "", "AccountClosingRule");
		}
	}

	private void getTo() throws Exception {
		// origin - 22.06.2026, last edit - 22.06.2026
		try {
			String tmp = this.partTo;
			if (tmp.isEmpty() == false) {
				this.to = tmp;
			}
		} catch (Exception ex) {
			WB.addLog("AccountClosingRule.getTo():void, ex=" + ex.getMessage(), "", "AccountClosingRule");
		}
	}

	private void getPart() throws Exception {
		// origin - 22.06.2026, last edit - 22.06.2026
		try {
			String tmp = this.src;
			int posLocalSplit = tmp.indexOf("->"); // pos " -> "
			if (posLocalSplit > 0) {
				this.partFrom = Etc.fixTrim(tmp.substring(0, posLocalSplit));
				this.partFrom = Etc.delStr(this.partFrom, AccountClosingRule.listDelStr);

				this.partTo = Etc.fixTrim(tmp.substring(posLocalSplit));
				this.partTo = Etc.delStr(this.partTo, AccountClosingRule.listDelStr);
			} else {
				this.partFrom = Etc.fixTrim(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("AccountClosingRule.getPart():void, ex=" + ex.getMessage(), "", "AccountClosingRule");
		}
	}

	public AccountClosingRule(String Src) throws Exception {
		// origin - 22.06.2026, last edit - 22.06.2026
		this.clear();
		this.src = Etc.fixTrim(Src);
		this.id = Src;
		this.getPart();
		this.getFrom();
		this.getTo();
	}

	public AccountClosingRule() throws Exception {
		// origin - 22.06.2026, last edit - 22.06.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 22.06.2026, last edit - 22.06.2026
		try {
			this.src = this.id = this.partFrom = this.partTo = this.to = "";
			this.from = new ArrayList<String>();
		} catch (Exception ex) {
			WB.addLog("AccountClosingRule.clear():void, ex=" + ex.getMessage(), "", "AccountClosingRule");
		}
	}

	public String toString() {
		// origin - 22.06.2026, last edit - 22.06.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addAnyway(" id ", this.id);
			res = res + Fmtr.addAnyway(" partFrom  ", this.partFrom);
			res = res + Fmtr.addAnyway(" partTo ", this.partTo);
			res = res + Fmtr.addAnyway(" from  ", this.from);
			res = res + Fmtr.addAnyway(" to ", this.to);
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 22.06.2026, last edit - 22.06.2026
		try {

//			WB.addLog2("AccountClosingRule.test.ctor(String)", "", "AccountClosingRule");
//			for (var tmp : new String[] { "", "8411-8415->8410;", "8110->1340;", "1420-1423->3130;", "1420-1423;",
//					"1420-1422->3130", "1420 - 1422->3130" }) {
//				WB.addLog2("AccountClosingRule.test.ctor(String), res=" + new AccountClosingRule(tmp), "",
//						"AccountClosingRule");
//			}

		} catch (Exception ex) {
			WB.addLog("AccountClosingRule.test():void, ex=" + ex.getMessage(), "", "AccountClosingRule");
		}
	}
}