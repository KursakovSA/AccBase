import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

public final class Slice {
	// origin - 06.12.2023, last edit - 22.11.2025
	// common fields
	public String table, src, id, parent, date1, date2, code, description, more, defect;
	// special fields
	private static LinkedHashMap<String, String> shift = new LinkedHashMap<String, String>();

	static {
		try {
			Slice.shift.put("Slice.Accounting", "Slice.Plan");
			Slice.shift.put("Slice.Accounting", "Slice.Fact");
			Slice.shift.put("Slice.Plan", "Slice.Accounting");
			Slice.shift.put("Slice.Fact", "Slice.Accounting");
		} catch (Exception ex) {
			WB.addLog("Slice.static ctor, ex=" + ex.getMessage(), "", "Slice");
		}
	}

	public static FullDto getFullDtoByList(List<String> in) throws Exception {
		// origin - 26.02.2026, last edit - 01.03.2026
		FullDto res = new FullDto();
		try {
			// WB.addLog2("Slice.getFullDtoByList, List<String> in=" + in + ", in.size=" +
			// in.size(), "", "Geo");
			res.table = "Slice";
			res.id = Etc.fixTrim(in.get(0));
			res.parent = Etc.fixTrim(in.get(1));
			res.date1 = Etc.fixTrim(in.get(2));
			res.date2 = Etc.fixTrim(in.get(3));
			res.code = Etc.fixTrim(in.get(4));
			res.description = Etc.fixTrim(in.get(5));
			res.more = Etc.fixTrim(in.get(6));
		} catch (

		Exception ex) {
			WB.addLog("Slice.getFullDtoByList(List<String>):FullDto, ex=" + ex.getMessage(), "", "Slice");
		}
		return res;
	}

	public static List<String> getListByFullDto(FullDto in) throws Exception {
		// origin - 30.01.2026, last edit - 01.03.2026
		List<String> res = new ArrayList<String>();
		try {
			res.add(in.id);
			res.add(in.parent);
			res.add(in.date1);
			res.add(in.date2);
			res.add(in.code);
			res.add(in.description);
			res.add(in.more + " "); // that empty last field = space
		} catch (Exception ex) {
			WB.addLog("Slice.getListByFullDto(FullDto):List<String>, ex=" + ex.getMessage(), "", "Slice");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 22.11.2025, last edit - 22.11.2025
		try {
		} catch (Exception ex) {
			WB.addLog("Slice.validate():void, ex=" + ex.getMessage(), "", "Slice");
		}
	}

	private List<FullDto> getFastListDto() throws Exception {
		// origin - 10.08.2026, last edit - 10.08.2026
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			var tmp = WB.abcLast.slice;
			res = ReadSet.getEqualsByCode(tmp, this.code);
			if (res.size() == 0) {
				res = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.code), "Slice");
			}
		} catch (Exception ex) {
			WB.addLog("Slice.getFastListDto():void, ex=" + ex.getMessage(), "", "Slice");
		}
		return res;
	}

	private void isExist() throws Exception {
		// origin - 02.10.2024, last edit - 10.08.2026
		try {
			// var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.code),
			// "Slice");
			var listDto = this.getFastListDto();
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.date1 = DefVal.setCustom(this.date1, dto.date1);
				this.date2 = DefVal.setCustom(this.date2, dto.date2);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.parent = DefVal.setCustom(this.parent, dto.parent);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.more = DefVal.setCustom(this.more, dto.more);
			}
		} catch (Exception ex) {
			WB.addLog("Slice.isExist():void, ex=" + ex.getMessage(), "", "Slice");
		}
	}

	public Slice(String Id) throws Exception {
		// origin - 06.12.2023, last edit - 22.11.2025
		this.clear();
		this.src = Id;
		if (Id.isEmpty() == false) {
			this.id = this.code = Id;
		}
		this.date1 = DateTool.getNow().toString();
		this.isExist();
		this.validate();
	}

	public Slice() throws Exception {
		// origin - 06.12.2023, last edit - 01.05.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 01.05.2025, last edit - 22.11.2025
		try {
			this.table = "Slice";
			this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.more = this.defect = "";
		} catch (Exception ex) {
			WB.addLog("Slice.clear():void, ex=" + ex.getMessage(), "", "Slice");
		}
	}

	public String toString() {
		// origin - 11.12.2024, last edit - 22.11.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 13.06.2025
		try {

//			WB.addLog2("Slice.test.ctor(String)", "", "Slice");
//			for (var tmp : new String[] { "", "Slice.Accounting", "Slice.tralala", "Slice.Duplicate" }) {
//				WB.addLog2("Slice.test.ctor(String)=" + new Slice(tmp), "", "Slice");
//			}

		} catch (Exception ex) {
			WB.addLog("Slice.test():void, ex=" + ex.getMessage(), "", "Slice");
		}
	}
}