import java.util.ArrayList;
import java.util.List;

public final class AccountClosing {
	// origin - 21.06.2026, last edit - 22.06.2026
	// common fields
	public String id, parent, date1, date2, code, description, role, info, sign, meter, meterValue, unit, more, defect,
			fullName, comment;
	// special fields
	public List<AccountClosingRule> rule;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("AccountClosing.static ctor, ex=" + ex.getMessage(), "", "AccountClosing");
		}
	}

	private void validate() throws Exception { // TODO
		// origin - 21.06.2026, last edit - 21.06.2026
		try {
		} catch (Exception ex) {
			WB.addLog("AccountClosing.validate():void, ex=" + ex.getMessage(), "", "AccountClosing");
		}
	}

	private void fix() throws Exception { // TODO
		// origin - 21.06.2026, last edit - 21.06.2026
		try {
		} catch (Exception ex) {
			WB.addLog("AccountClosing.fix():void, ex=" + ex.getMessage(), "", "AccountClosing");
		}
	}

	private void getRule() throws Exception {
		// origin - 22.06.2026, last edit - 22.06.2026
		try {
			if (this.meterValue.isEmpty() == false) {
				var tmp = List.of(this.meterValue.split(";"));
				for (var curr : tmp) {
					this.rule.add(new AccountClosingRule(curr));
				}
			}
		} catch (Exception ex) {
			WB.addLog("AccountClosing.getRule():void, ex=" + ex.getMessage(), "", "AccountClosing");
		}
	}

	private void isExist() throws Exception {
		// origin - 21.06.2026, last edit - 21.06.2026
		try {
			var listDto = DAL.getByTemplate(Conn.global, Qry.getIdFilter(this.id), "Workbook");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.parent = DefVal.setCustom(this.parent, dto.parent);
				this.date1 = DefVal.setCustom(this.date1, dto.date1);
				this.date2 = DefVal.setCustom(this.date2, dto.date2);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.role = DefVal.setCustom(this.role, dto.role);
				this.sign = DefVal.setCustom(this.sign, dto.sign);
				this.meter = DefVal.setCustom(this.meter, dto.meter);
				this.meterValue = DefVal.setCustom(this.meterValue, dto.meterValue);
				this.unit = DefVal.setCustom(this.unit, dto.unit);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.getFieldFromMore();
			}
		} catch (Exception ex) {
			WB.addLog("AccountClosing.isExist():void, ex=" + ex.getMessage(), "", "AccountClosing");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 21.06.2026, last edit - 21.06.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("AccountClosing.getFieldFromMore():void, ex=" + ex.getMessage(), "", "AccountClosing");
		}
	}

	public AccountClosing(String Id) throws Exception {
		// origin - 21.06.2026, last edit - 22.06.2026
		this.clear();
		this.id = Id;
		this.isExist();
		this.getRule();
		this.fix();
		this.validate();
	}

	public AccountClosing() throws Exception {
		// origin - 21.06.2026, last edit - 21.06.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 21.06.2026, last edit - 22.06.2026
		try {
			this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.info = "";
			this.role = this.sign = this.more = this.defect = this.meter = this.meterValue = this.unit = "";
			this.fullName = this.comment = "";
			this.rule = new ArrayList<AccountClosingRule>();
		} catch (Exception ex) {
			WB.addLog("AccountClosing.clear():void, ex=" + ex.getMessage(), "", "AccountClosing");
		}
	}

	public String toString() {
		// origin - 21.06.2026, last edit - 22.06.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", ", this.sign);
			res = res + Fmtr.addIfNotEmpty(", meter ", this.meter);
			res = res + Fmtr.addIfNotEmpty(", meterValue ", this.meterValue);
			res = res + Fmtr.addIfNotEmpty(", unit ", this.unit);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", rule ", this.rule.size());
			res = res + Fmtr.addAnyway(", fullName ", this.fullName);
			res = res + Fmtr.addAnyway(", comment ", this.comment);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 21.06.2026, last edit - 22.06.2026
		try {

//			WB.addLog2("AccountClosing.test.ctor(String)", "", "AccountClosing");
//			for (var tmp : new String[] { "", "AccountClosing.Production", "tralala" }) {
//				WB.addLog2("AccountClosing.test.ctor(String), res=" + new AccountClosing(tmp), "", "AccountClosing");
//			}

		} catch (Exception ex) {
			WB.addLog("AccountClosing.test():void, ex=" + ex.getMessage(), "", "AccountClosing");
		}
	}
}