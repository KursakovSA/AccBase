import java.util.ArrayList;
import java.util.List;

public final class Geo {
	// origin - 28.09.2023, last edit - 10.09.2026
	// common fields
	public String table, src, id, parent, date1, date2, code, description, role, more, defect;
	// special fields
	public List<FullDto> lowerList, upperList;
	public static Geo currCountry;
	private static String roleCountry;
	public String fullName, comment;

	static {
		try {
			Geo.roleCountry = "Role.Geo.Country";
			Geo.currCountry = new Geo("Geo.Qazaqstan");
			// WB.addLog2("Geo.currCountry=" + Geo.currCountry, "", "Geo");
		} catch (Exception ex) {
			WB.addLog("Geo.static ctor, ex=" + ex.getMessage(), "", "Geo");
		}
	}

	public static FullDto getFullDtoByList(List<String> in) throws Exception {
		// origin - 26.02.2026, last edit - 01.03.2026
		FullDto res = new FullDto();
		try {
			res.table = "Geo";
			res.id = Etc.fixTrim(in.get(0));
			res.parent = Etc.fixTrim(in.get(1));
			res.date1 = Etc.fixTrim(in.get(2));
			res.date2 = Etc.fixTrim(in.get(3));
			res.code = Etc.fixTrim(in.get(4));
			res.description = Etc.fixTrim(in.get(5));
			res.role = Etc.fixTrim(in.get(6));
			res.more = Etc.fixTrim(in.get(7));
		} catch (Exception ex) {
			WB.addLog("Geo.getFullDtoByList(List<String>):FullDto, ex=" + ex.getMessage(), "", "Geo");
		}
		return res;
	}

	public static List<String> getListByFullDto(FullDto in) throws Exception {
		// origin - 31.01.2026, last edit - 01.03.2026
		List<String> res = new ArrayList<String>();
		try {
			res.add(in.id);
			res.add(in.parent);
			res.add(in.date1);
			res.add(in.date2);
			res.add(in.code);
			res.add(in.description);
			res.add(in.role);
			res.add(in.more + " "); // that empty last field = space
		} catch (Exception ex) {
			WB.addLog("Geo.getListByFullDto(FullDto):List<String>, ex=" + ex.getMessage(), "", "Geo");
		}
		return res;
	}

	public static List<String> getCurrencyPair() throws Exception {// select pairs kind "USD-KZT", "EUR-KZT", etc.
		// origin - 01.03.2025, last edit - 14.06.2025
		List<String> res = new ArrayList<String>();
		try {
			for (var curr1 : Geo.getCurrency()) {
				if (Etc.strEquals(curr1, Unit.currCurrency.description)) {// skip pairs kind "KZT-?"
					continue;
				}
				for (var curr2 : Geo.getCurrency()) {
					if (Etc.strEquals(curr2, curr1)) {// skip pairs kind "EUR-EUR"
						continue;
					}
					if (Etc.strEquals(curr2, Unit.currCurrency.description) == false) {// skip pairs kind "?-EUR, USD"
						continue;
					}
					var tmp = curr1 + "-" + curr2;
					res.add(tmp); // "USD-KZT", "EUR-KZT", etc.
					// WB.addLog2("Geo.getCurrencyPair, add tmp=" + tmp, "", "Geo");
				}
			}
		} catch (Exception ex) {
			WB.addLog("Geo.getCurrencyPair():List<String>, ex=" + ex.getMessage() + ", res=" + res, "", "Geo");
		}
		return res;
	}

	public static List<String> getCurrency() throws Exception {
		// origin - 19.02.2025, last edit - 14.08.2025
		List<String> res = new ArrayList<String>();
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getMoreFilter("Currency"), "Geo");
			String tmpCurrency = "";
			for (var curr : listDto) {
				tmpCurrency = MoreVal.getFieldByKey(curr.more, "Currency"); // ??magic string??
				if (tmpCurrency.isEmpty() == false) {
					Unit tmpUnit = new Unit(tmpCurrency);
					res.add(tmpUnit.description); // description = "USD", "KZT", etc.
				}
			}
		} catch (Exception ex) {
			WB.addLog("Geo.getCurrency():List<String>, ex=" + ex.getMessage() + ", res=" + res, "", "Geo");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 22.11.2025, last edit - 22.11.2025
		try {
		} catch (Exception ex) {
			WB.addLog("Geo.validate():void, ex=" + ex.getMessage(), "", "Geo");
		}
	}

	public String getCountry() throws Exception {
		// origin - 27.11.2024, last edit - 14.06.2025
		String res = "";
		try {
			if (Etc.strEquals(this.role, Geo.roleCountry)) {
				res = this.code;
			} else {

				Geo tmp = new Geo(this.parent);
				while (Etc.strEquals(tmp.role, Geo.roleCountry) == false) {
					if (tmp.parent.isEmpty()) {
						// tmp = new Geo("Geo.Qazaqstan");
						break;
					} else {
						tmp = new Geo(tmp.parent);
					}
				}
				res = tmp.code;
			}

		} catch (Exception ex) {
			WB.addLog("Geo.getCountry():String, ex=" + ex.getMessage() + ", res=" + res, "", "Geo");
		}
		return res;
	}

	private List<FullDto> getFastListDto() throws Exception {
		// origin - 10.08.2026, last edit - 10.08.2026
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			var tmp = WB.abcLast.geo;
			res = ReadSet.getEqualsByCode(tmp, this.code);
			if (res.size() == 0) {
				res = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.code), "Geo");
			}
		} catch (Exception ex) {
			WB.addLog("Geo.getFastListDto():void, ex=" + ex.getMessage(), "", "Geo");
		}
		return res;
	}

	private void isExist() throws Exception {
		// origin - 26.11.2024, last edit - 13.08.2026
		try {
			// var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.code),
			// "Geo");
			var listDto = this.getFastListDto();
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.code = dto.code;
				this.parent = dto.parent;
				this.description = dto.description;
				this.role = dto.role;
				this.more = dto.more;
//				this.upperList = FullDto.getUpper(this.table, this.parent);
//				this.lowerList = FullDto.getLower(this.table, this.id);
				this.upperList = Abc.getUpper(this.table, this.parent);
				this.lowerList = Abc.getLower(this.table, this.id);
				this.getFieldFromMore();
			}
		} catch (Exception ex) {
			WB.addLog("Geo.isExist():void, ex=" + ex.getMessage(), "", "Geo");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 12.08.2025, last edit - 10.09.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("Geo.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Geo");
		}
	}

	public Geo(String Id) throws Exception {
		// origin - 26.11.2024, last edit - 22.11.2025
		this.clear();
		this.src = Id;
		if (Id.isEmpty() == false) {
			this.id = this.code = Id;
		}
		this.isExist();
		this.validate();
	}

	public Geo() throws Exception {
		// origin - 27.11.2024, last edit - 19.05.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 26.11.2024, last edit - 10.09.2026
		try {
			this.table = "Geo";
			this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.role = this.more = this.defect = "";
			this.fullName = this.comment = "";
			this.lowerList = new ArrayList<FullDto>();
			this.upperList = new ArrayList<FullDto>();
		} catch (Exception ex) {
			WB.addLog("Geo.clear():void, ex=" + ex.getMessage(), "", "Geo");
		}
	}

	public String toString() {
		// origin - 26.11.2023, last edit - 10.09.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", upperList ", this.upperList.size());
			res = res + Fmtr.addIfNotEmpty(", lowerList ", this.lowerList.size());
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 14.06.2025
		try {

//			WB.addLog2("Geo.test.ctor(String)", "", "Geo");
//			for (var tmp : new String[] { "", "Geo.Qazaqstan", "Geo.tralala", "Geo.SaryArka", "Geo.Astana" }) {
//				WB.addLog2("Geo.test.ctor(String)=" + new Geo(tmp), "", "Geo");
//			}

//			WB.addLog2("Geo.test.getCountry", "", "Geo");
//			for (var tmp : new String[] {"", "Geo.Qazaqstan", "Geo.tralala", "Geo.SaryArka"}) {
//				WB.addLog2("Geo.test.getCountry=" + argGeo.getCountry() + ", argGeo=" + argGeo, "", "Geo");
//			}

		} catch (Exception ex) {
			WB.addLog("Geo.test():void, ex=" + ex.getMessage(), "", "Geo");
		}
	}
}