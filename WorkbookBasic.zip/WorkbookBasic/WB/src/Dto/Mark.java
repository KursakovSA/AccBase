import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

public final class Mark {
	// origin - 06.12.2023, last edit - 22.11.2025
	// common fields
	public String table, src, id, parent, date1, date2, code, description, more, defect;
	// special fields
	private static LinkedHashMap<String, String> shift = new LinkedHashMap<String, String>();
	// public static String MD, DD, CD, TD;
	public static List<String> qryFilter_CD_DD, qryFilter_MD_TD, qryFilter_CD_DD_TD;

	static {
		try {
//			Mark.MD = "Mark.MD";
//			Mark.DD = "Mark.DD";
//			Mark.CD = "Mark.CD";
//			Mark.TD = "Mark.TD";

			Mark.qryFilter_CD_DD = List.of("Mark.CD", "Mark.DD");
			Mark.qryFilter_MD_TD = List.of("Mark.MD", "Mark.TD");
			Mark.qryFilter_CD_DD_TD = List.of("Mark.CD", "Mark.DD", "Mark.TD");

			Mark.shift.put("Mark.ArcD", "Mark.DD");
			Mark.shift.put("Mark.DD", "Mark.CD");
			Mark.shift.put("Mark.CD", "Mark.DelD");
			Mark.shift.put("Mark.CD", "Mark.ArcD");
		} catch (Exception ex) {
			WB.addLog("Mark.static ctor, ex=" + ex.getMessage(), "", "Mark");
		}
	}

	public static FullDto getFullDtoByList(List<String> in) throws Exception {
		// origin - 02.03.2026, last edit - 02.03.2026
		FullDto res = new FullDto();
		try {
			res.table = "Mark";
			res.id = Etc.fixTrim(in.get(0));
			res.parent = Etc.fixTrim(in.get(1));
			res.date1 = Etc.fixTrim(in.get(2));
			res.date2 = Etc.fixTrim(in.get(3));
			res.code = Etc.fixTrim(in.get(4));
			res.description = Etc.fixTrim(in.get(5));
			res.more = Etc.fixTrim(in.get(6));
		} catch (

		Exception ex) {
			WB.addLog("Mark.getFullDtoByList(List<String>):FullDto, ex=" + ex.getMessage(), "", "Mark");
		}
		return res;
	}

	public static List<String> getListByFullDto(FullDto in) throws Exception {
		// origin - 31.01.2026, last edit - 01.03.2026
		List<String> res = new ArrayList<String>();
		try {
			res.add(in.id);
			res.add(in.parent);
			res.add(in.date1);
			res.add(in.date2);
			res.add(in.code);
			res.add(in.description);
			res.add(in.more);
		} catch (Exception ex) {
			WB.addLog("Mark.getListByFullDto(FullDto):List<String>, ex=" + ex.getMessage(), "", "Mark");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 22.11.2025, last edit - 22.11.2025
		try {
		} catch (Exception ex) {
			WB.addLog("Mark.validate():void, ex=" + ex.getMessage(), "", "Mark");
		}
	}

	private List<FullDto> getFastListDto() throws Exception {
		// origin - 10.08.2026, last edit - 10.08.2026
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			var tmp = WB.abcLast.mark;
			res = ReadSet.getEqualsByCode(tmp, this.code);
			if (res.size() == 0) {
				res = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.code), "Mark");
			}
		} catch (Exception ex) {
			WB.addLog("Mark.getFastListDto():void, ex=" + ex.getMessage(), "", "Mark");
		}
		return res;
	}

	private void isExist() throws Exception {
		// origin - 02.10.2024, last edit - 10.08.2026
		try {
			// var listDto = DAL.getByTemplate(WB.lastConnWork,
			// Qry.getCodeFilter(this.code), "Mark");
			var listDto = this.getFastListDto();
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.date1 = DefVal.setCustom(this.date1, dto.date1);
				this.date2 = DefVal.setCustom(this.date2, dto.date2);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.parent = DefVal.setCustom(this.parent, dto.parent);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.more = DefVal.setCustom(this.more, dto.more);
			}
		} catch (Exception ex) {
			WB.addLog("Mark.isExist():void, ex=" + ex.getMessage(), "", "Mark");
		}
	}

	public Mark(String Id) throws Exception {
		// origin - 06.12.2023, last edit - 22.11.2025
		this.clear();
		this.src = Id;
		if (Id.isEmpty() == false) {
			this.id = this.code = Id;
		}
		this.date1 = DateTool.getNow().toString();
		this.isExist();
		this.validate();
	}

	public Mark() throws Exception {
		// origin - 06.12.2023, last edit - 11.08.2024
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 01.05.2025, last edit - 22.11.2025
		try {
			this.table = "Mark";
			this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.more = this.defect = "";
		} catch (Exception ex) {
			WB.addLog("Mark.clear():void, ex=" + ex.getMessage(), "", "Mark");
		}
	}

	public String toString() {
		// origin - 11.12.2024, last edit - 22.11.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 13.06.2025
		try {

//			// ctor (String)
//			WB.addLog2("Mark.test.ctor(String)", "", "Mark");
//			for (var tmp : new String[] { "", "Mark.CD", "Mark.tralala", "Mark.MD" }) {
//				WB.addLog2("Mark.test.ctor(String)=" + new Mark(tmp), "", "Mark");
//			}

		} catch (Exception ex) {
			WB.addLog("Mark.test():void, ex=" + ex.getMessage(), "", "Mark");
		}
	}
}