import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public final class BasicDto {
	// origin - 28.02.2025, last edit - 14.07.2026
	public String src, id, table, parent, date1, date2, face1, face2, face, code, description, geo, role, sign, info,
			unit, more, mark, defect;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("BasicDto.static ctor, ex=" + ex.getMessage(), "", "BasicDto");
		}
	}

	private void validate() throws Exception {
		// origin - 18.05.2026, last edit - 23.05.2026
		try {
			this.defect = Fmtr.addIfStrEmpty(this.defect, this.id, "empty id; ");
			this.defect = Fmtr.addIfStrEmpty(this.defect, this.code, "empty code; ");
			this.defect = Fmtr.addIfStrEmpty(this.defect, this.description, "empty description; ");
		} catch (Exception ex) {
			WB.addLog("BasicDto.validate():void, ex=" + ex.getMessage(), "", "BasicDto");
		}
	}

	private void fix() throws Exception { // TODO
		// origin - 02.05.2026, last edit - 15.07.2026
		try {
			this.date1 = DefVal.set(this.date1, WB.minDateSupported.toString());
			this.date2 = DefVal.set(this.date2, WB.maxDateSupported.toString());
		} catch (Exception ex) {
			WB.addLog("BasicDto.fix():void, ex=" + ex.getMessage(), "", "BasicDto");
		}
	}

	public static List<BasicDto> getByTable(String table) throws Exception {
		// origin - 12.08.2026, last edit - 12.08.2026
		List<BasicDto> res = new ArrayList<BasicDto>();
		try {
			var tmp = Abc.get(table);
			if (tmp.size() == 0) {
				tmp = DAL.getTable(WB.lastConnWork, Qry.getText(WB.lastConnWork, table, ""));
			}
			if (tmp.size() != 0) {
				res = BasicDto.get(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("BasicDto.getByTable(String):List<BasicDto>, ex=" + ex.getMessage(), "", "BasicDto");
		}
		return res;
	}

	public static List<BasicDto> getUpper(String table, String id) throws Exception {
		// origin - 18.05.2026, last edit - 18.05.2026
		List<BasicDto> res = new ArrayList<BasicDto>();

		if (Etc.fixTrim(table).isEmpty()) {
			return res;
		}

		if (Etc.fixTrim(id).isEmpty()) {
			return res;
		}

		try {
			var tmp1 = Qry.getUpper(table, id);
			var tmp2 = DAL.getTable(WB.lastConnWork, tmp1);
			for (var tmp3 : tmp2) {
				res.add(new BasicDto(tmp3));
			}
		} catch (Exception ex) {
			WB.addLog("BasicDto.getUpper(2String):List<BasicDto>, ex=" + ex.getMessage(), "", "BasicDto");
		}
		return res;
	}

	public static List<BasicDto> get(List<FullDto> mDto) throws Exception {
		// origin - 01.07.2026, last edit - 01.07.2026
		List<BasicDto> res = new ArrayList<BasicDto>();
		try {
			if (mDto.size() != 0) {
				for (var tmp : mDto) {
					res.add(new BasicDto(tmp));
				}
			}
		} catch (Exception ex) {
			WB.addLog("BasicDto.get(List<FullDto>):List<BasicDto>, ex=" + ex.getMessage(), "", "BasicDto");
		}
		return res;
	}

	public static List<BasicDto> getLower(String table, String id) throws Exception {
		// origin - 18.05.2026, last edit - 01.07.2026
		List<BasicDto> res = new ArrayList<BasicDto>();

		if (Etc.fixTrim(table).isEmpty()) {
			return res;
		}

		if (Etc.fixTrim(id).isEmpty()) {
			return res;
		}

		try {
			var tmp1 = Qry.getLower(table, id);
			var tmp2 = DAL.getTable(WB.lastConnWork, tmp1);
			res = BasicDto.get(tmp2);
		} catch (Exception ex) {
			WB.addLog("BasicDto.getLower(2String):List<BasicDto>, ex=" + ex.getMessage(), "", "BasicDto");
		}
		return res;
	}

	public static List<BasicDto> getChronoSpan(SpanDate spanDate, List<BasicDto> listBasicDto) throws Exception {
		// origin - 15.07.2026, last edit - 15.07.2026
		List<BasicDto> res = new ArrayList<BasicDto>();
		LocalDate currDate1;
		LocalDate currDate2;
		try {
			LocalDate spanDate1 = DateTool.getLocalDate(spanDate.date1.getFirst());
			LocalDate spanDate2 = DateTool.getLocalDate(spanDate.date2.getFirst());
			for (var currDto : listBasicDto) {
				currDto.fix();
				currDate1 = DateTool.getLocalDate(currDto.date1);// left border in data
				currDate2 = DateTool.getLocalDate(currDto.date2);// right border in data

				if (currDate1.isBefore(spanDate1)) {
					continue;
				}

				if (currDate2.isAfter(spanDate2)) {
					continue;
				}

				if ((Etc.strEquals(currDate1.toString(), spanDate1.toString()))
						& (Etc.strEquals(currDate2.toString(), spanDate2.toString()))) {
					res.add(currDto);
					continue;
				}

				if ((Etc.strEquals(currDate1.toString(), spanDate1.toString())) & (currDate2.isBefore(spanDate2))) {
					res.add(currDto);
					continue;
				}

				if ((currDate1.isAfter(spanDate1)) & (Etc.strEquals(currDate2.toString(), spanDate2.toString()))) {
					res.add(currDto);
					continue;
				}

				if ((currDate1.isAfter(spanDate1)) & (currDate2.isBefore(spanDate2))) {
					res.add(currDto);
					continue;
				}
			}
		} catch (Exception ex) {
			WB.addLog("BasicDto.getChronoSpan(SpanDate, List<BasicDto>):List<BasicDto>, ex=" + ex.getMessage(), "",
					"BasicDto");
		}
		return res;
	}

	public static BasicDto getChrono(LocalDate calcDate, List<BasicDto> listBasicDto) throws Exception {
		// origin - 01.03.2025, last edit - 02.05.2026
		BasicDto res = new BasicDto();
		LocalDate currDate1;
		LocalDate currDate2;
		try {
			for (var currDto : listBasicDto) {
				currDto.fix();
				currDate1 = DateTool.getLocalDate(currDto.date1);// left border in data
				currDate2 = DateTool.getLocalDate(currDto.date2);// right border in data

				// left border hit or right border hit
				if ((Etc.strEquals(currDate1.toString(), calcDate.toString()))
						|| (Etc.strEquals(currDate2.toString(), calcDate.toString()))) {
					res = currDto;
					break;
				}

				// range from left border to right border hit
				if ((currDate1.isBefore(calcDate)) && (currDate2.isAfter(calcDate))) {
					res = currDto;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("BasicDto.getChrono(LocalDate, List<BasicDto>):BasicDto, ex=" + ex.getMessage(), "", "BasicDto");
		}
		return res;
	}

	private void isExist() throws Exception {
		// origin - 18.05.2026, last edit - 02.08.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), this.table);
			if (listDto.size() != 0) {
				var currDto = listDto.getFirst();
				this.id = DefVal.setCustom(this.id, currDto.id);
				this.parent = DefVal.setCustom(this.parent, currDto.parent);
				this.date1 = DefVal.setCustom(this.date1, currDto.date1);
				this.date2 = DefVal.setCustom(this.date1, currDto.date2);
				this.face1 = DefVal.setCustom(this.face1, currDto.face1);
				this.face2 = DefVal.setCustom(this.face2, currDto.face2);
				this.face = DefVal.setCustom(this.face, currDto.face);
				this.code = DefVal.setCustom(this.code, currDto.code);
				this.description = DefVal.setCustom(this.description, currDto.description);
				this.role = DefVal.setCustom(this.role, currDto.role);
				this.info = DefVal.setCustom(this.info, currDto.info);
				this.sign = DefVal.setCustom(this.sign, currDto.sign);
				this.unit = DefVal.setCustom(this.unit, currDto.unit);
				this.geo = DefVal.setCustom(this.geo, currDto.geo);
				this.more = DefVal.setCustom(this.more, currDto.more);
				this.mark = DefVal.setCustom(this.mark, currDto.mark);
			}

			if (listDto.size() == 0) {
				this.clear();
			}
		} catch (Exception ex) {
			WB.addLog("BasicDto.isExist():void, ex=" + ex.getMessage(), "", "BasicDto");
		}
	}

	public BasicDto(FullDto mDto) throws Exception {
		// origin - 18.05.2026, last edit - 14.07.2026
		this();
		this.id = mDto.id;
		this.parent = mDto.parent;
		this.date1 = mDto.date1;
		this.date2 = mDto.date2;
		this.face1 = mDto.face1;
		this.face2 = mDto.face2;
		this.face = mDto.face;
		this.code = mDto.code;
		this.description = mDto.description;
		this.role = mDto.role;
		this.info = mDto.info;
		this.geo = mDto.geo;
		this.unit = mDto.unit;
		this.sign = mDto.sign;
		this.more = mDto.more;
		this.mark = mDto.mark;
		this.fix();
		this.validate();
	}

	public BasicDto(String Table, String Src) throws Exception {
		// origin - 18.05.2026, last edit - 18.05.2026
		this();
		this.table = Table;
		this.id = Etc.fixTrim(Src);
		this.isExist();
		this.fix();
		this.validate();
	}

	public BasicDto(String Id, String Parent, String Date1, String Date2, String Code, String Description, String More)
			throws Exception {
		// origin - 28.02.2025, last edit - 18.05.2026
		this();
		this.id = Id;
		this.parent = Parent;
		this.date1 = Date1;
		this.date2 = Date2;
		this.code = Code;
		this.description = Description;
		this.more = More;
		this.fix();
		this.validate();
	}

	private void clear() throws Exception {
		// origin - 28.02.2025, last edit - 14.07.2026
		try {
			this.src = this.table = this.face1 = this.face2 = this.face = "";
			this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.more = this.defect = "";
			this.role = this.info = this.geo = this.sign = this.unit = this.mark = "";
		} catch (Exception ex) {
			WB.addLog("BasicDto.clear():void, ex=" + ex.getMessage(), "", "BasicDto");
		}
	}

	public BasicDto() throws Exception {
		// origin - 28.02.2025, last edit - 28.02.2025
		this.clear();
	}

	public String toString() {
		// origin - 28.02.2025, last edit - 14.07.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", role ", this.role);
			res = res + Fmtr.addIfNotEmpty(", info ", this.info);
			res = res + Fmtr.addIfNotEmpty(", geo ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", sign ", this.sign);
			res = res + Fmtr.addIfNotEmpty(", unit ", this.unit);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", mark ", this.mark);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.02.2025, last edit - 31.07.2026
		try {

//			WB.addLog2("BasicDto.test.getLower(2String)", "", "BasicDto");
//			for (var tmp1 : new String[] { "Deal", "Geo", "Price", "Role" }) {
//				for (var tmp2 : new String[] { "Geo.Qazaqstan", "PriceListDescription.Root.Part1",
//						"Price.BasicCondition", "PriceListDescription.Root", "PriceListDescription.Tralala",
//						"Role.Account" }) {
//					var tmp3 = BasicDto.getLower(tmp1, tmp2);
//					WB.addLog2("BasicDto.test.getLower(2String), res.size=" + tmp3.size() + ", tmp1=" + tmp1 + ", tmp2="
//							+ tmp2, "", "BasicDto");
//					WB.log(tmp3, "BasicDto");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("BasicDto.test():void, ex=" + ex.getMessage(), "", "BasicDto");
		}
	}
}