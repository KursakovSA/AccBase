import java.util.ArrayList;
import java.util.List;

public final class Sign {
	// origin - 06.12.2023, last edit - 22.11.2025
	// common fields
	public String table, src, id, parent, date1, date2, code, description, more, defect;
	// special fields
	// public static String AcctDt;

	static {
		// Sign.AcctDt = "Sign.Acct.Dt";
		try {
		} catch (Exception ex) {
			WB.addLog("Sign.static ctor, ex=" + ex.getMessage(), "", "Sign");
		}
	}

	public static FullDto getFullDtoByList(List<String> in) throws Exception {
		// origin - 02.03.2026, last edit - 02.03.2026
		FullDto res = new FullDto();
		try {
			res.table = "Sign";
			res.id = Etc.fixTrim(in.get(0));
			res.parent = Etc.fixTrim(in.get(1));
			res.date1 = Etc.fixTrim(in.get(2));
			res.date2 = Etc.fixTrim(in.get(3));
			res.code = Etc.fixTrim(in.get(4));
			res.description = Etc.fixTrim(in.get(5));
			res.more = Etc.fixTrim(in.get(6));
		} catch (

		Exception ex) {
			WB.addLog("Sign.getFullDtoByList(List<String>):FullDto, ex=" + ex.getMessage(), "", "Sign");
		}
		return res;
	}

	public static List<String> getListByFullDto(FullDto in) throws Exception {
		// origin - 31.01.2026, last edit - 01.03.2026
		List<String> res = new ArrayList<String>();
		try {
			res.add(in.id);
			res.add(in.parent);
			res.add(in.date1);
			res.add(in.date2);
			res.add(in.code);
			res.add(in.description);
			res.add(in.more);
		} catch (Exception ex) {
			WB.addLog("Sign.getData(FullDto):List<String>, ex=" + ex.getMessage(), "", "Sign");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 22.11.2025, last edit - 22.11.2025
		try {
		} catch (Exception ex) {
			WB.addLog("Sign.validate():void, ex=" + ex.getMessage(), "", "Sign");
		}
	}

	private List<FullDto> getFastListDto() throws Exception {
		// origin - 10.08.2026, last edit - 10.08.2026
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			var tmp = WB.abcLast.sign;
			res = ReadSet.getEqualsByCode(tmp, this.code);
			if (res.size() == 0) {
				res = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.code), "Sign");
			}
		} catch (Exception ex) {
			WB.addLog("Sign.getFastListDto():void, ex=" + ex.getMessage(), "", "Sign");
		}
		return res;
	}

	private void isExist() throws Exception {
		// origin - 20.12.2024, last edit - 10.08.2026
		try {
			// var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.code),
			// "Sign");
			var listDto = this.getFastListDto();
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.date1 = DefVal.setCustom(DateTool.getNow().toString(), dto.date1);
				this.date2 = DefVal.setCustom(this.date2, dto.date2);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.parent = DefVal.setCustom(this.parent, dto.parent);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.more = DefVal.setCustom(this.more, dto.more);
			}
		} catch (Exception ex) {
			WB.addLog("Sign.isExist():void, ex=" + ex.getMessage(), "", "Sign");
		}
	}

	public Sign(String Id) throws Exception {
		// origin - 06.12.2023, last edit - 22.11.2025
		this.clear();
		this.src = Id;
		if (Id.isEmpty() == false) {
			this.id = this.code = Id;
		}
		this.isExist();
		this.validate();
	}

	public Sign() throws Exception {
		// origin - 06.12.2023, last edit - 19.05.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 20.12.2024, last edit - 22.11.2025
		try {
			this.table = "Sign";
			this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.more = this.defect = "";
		} catch (Exception ex) {
			WB.addLog("Sign.clear():void, ex=" + ex.getMessage(), "", "Sign");
		}
	}

	public String toString() {
		// origin - 20.12.2024, last edit - 20.03.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 06.12.2023, last edit - 13.06.2025
		try {

//			// ctor (String)
//			WB.addLog2("Sign.test.ctor(String)", "", "Sign");
//			for (var tmp : new String[] {"", "Sign.Acct", "Sign.tralala", "Sign.MoneyFlow.Input.016"}) {
//				WB.addLog2("Sign.test.ctor(String)=" + new Sign(tmp), "", "Sign");
//			}

		} catch (Exception ex) {
			WB.addLog("Sign.test():void, ex=" + ex.getMessage(), "", "Sign");
		}
	}
}