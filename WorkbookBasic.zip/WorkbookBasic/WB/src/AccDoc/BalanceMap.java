import java.util.ArrayList;
import java.util.List;

public final class BalanceMap { // TODO
	// origin - 24.09.2026, last edit - 25.09.2026
	public static List<String> mapList;
	public static List<String> mapNameList;
	public static List<String> mapOperList;

	static {
		try {
			BalanceMap.mapList = AccDocMap.getMapList();
			BalanceMap.mapNameList = List.of("AssetBalance", "BankBalance", "CashBalance", "DealBalance", "FaceBalance",
					"FixedAssetBalance", "ImprestBalance", "PropMgmtBalance", "PurchaseBalance", "ResPlanBalance",
					"SalaryBalance", "ServiceBalance", "StaffBalance", "StoreBalance", "TrafficBalance", "VatBalance",
					"WriteOffBalance","DebtBalance");
			BalanceMap.mapOperList = List.of("total", "noteqv", "eqv"); // TODO
		} catch (Exception ex) {
			WB.addLog("BalanceMap.static ctor, ex=" + ex.getMessage(), "", "BalanceMap");
		}
	}

	public static List<String> getMapList() throws Exception { // TODO
		// origin - 18.09.2026, last edit - 19.09.2026
		List<String> res = new ArrayList<String>();
		try {
			String tmp1 = "Pattern=*.xls; FirstRowData=2; SumCredit=1,total; KBE=2,eqv856; KNP=3,noteqv19;|"
					+ "Pattern=*.xls; FirstRowData=2; SumCredit=1; KBE=2,eqv856; KNP=3,noteqv19,|"
					+ "Pattern=*.xls; FirstRowData=2; SumCredit=4,total; KNP=8,eqv856;|"
					+ "Pattern=*.xls; FirstRowData=2; SumCredit=4; KNP=8,eqv856;|"
					+ "Pattern=*.xls; FirstRowData=2; SumCredit=4; KNP=8;|"
					+ "Pattern=?; FirstRowData=?; SumCredit=?; KNP=?"; // last map for manual custom user hands
			List<String> tmp2 = List.of(tmp1.split("\\|"));
			res.addAll(tmp2);
		} catch (Exception ex) {
			WB.addLog("BalanceMap.getMapList():List<String>, ex=" + ex.getMessage(), "", "BalanceMap");
		}
		return res;
	}

	public static void test() throws Exception { // TODO
		// origin - 24.09.2026, last edit - 24.09.2026
		try {

		} catch (Exception ex) {
			WB.addLog("BalanceMap.test():void, ex=" + ex.getMessage(), "", "BalanceMap");
		}
	}
}