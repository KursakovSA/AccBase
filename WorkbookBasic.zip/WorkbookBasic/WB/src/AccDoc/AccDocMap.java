import java.util.ArrayList;
import java.util.List;

public final class AccDocMap { // TODO
	// origin - 24.09.2026, last edit - 25.09.2026
	public static List<String> mapList;
	public static List<String> mapNameList;
	public static List<String> mapOperList;

	static {
		try {
			AccDocMap.mapList = AccDocMap.getMapList();
			AccDocMap.mapNameList = List.of("BankOrder", "CashOrder", "BillOrder", "EntryOrder", "FixedAssetDeprOrder",
					"ImprestOrder", "PurchaseOrder", "ResPlanOrder", "SaleOrder", "ServiceOrder", "TrafficOrder",
					"WarrantOrder", "WriteOffOrder", "VatOrder","PriceOrder","StaffOrder","StoreOrder","SalaryOrder");
			AccDocMap.mapOperList = List.of("total", "noteqv", "eqv"); // TODO
		} catch (Exception ex) {
			WB.addLog("AccDocMap.static ctor, ex=" + ex.getMessage(), "", "AccDocMap");
		}
	}

	public static List<String> getMapList() throws Exception { // TODO
		// origin - 18.09.2026, last edit - 19.09.2026
		List<String> res = new ArrayList<String>();
		try {
			String tmp1 = "Pattern=*.xls; FirstRowData=2; SumCredit=1,total; KBE=2,eqv856; KNP=3,noteqv19;|"
					+ "Pattern=*.xls; FirstRowData=2; SumCredit=1; KBE=2,eqv856; KNP=3,noteqv19,|"
					+ "Pattern=*.xls; FirstRowData=2; SumCredit=4,total; KNP=8,eqv856;|"
					+ "Pattern=*.xls; FirstRowData=2; SumCredit=4; KNP=8,eqv856;|"
					+ "Pattern=*.xls; FirstRowData=2; SumCredit=4; KNP=8;|"
					+ "Pattern=?; FirstRowData=?; SumCredit=?; KNP=?"; // last map for manual custom user hands
			List<String> tmp2 = List.of(tmp1.split("\\|"));
			res.addAll(tmp2);
		} catch (Exception ex) {
			WB.addLog("AccDocMap.getMapList():List<String>, ex=" + ex.getMessage(), "", "AccDocMap");
		}
		return res;
	}

	public static void test() throws Exception { // TODO
		// origin - 24.09.2026, last edit - 24.09.2026
		try {

		} catch (Exception ex) {
			WB.addLog("AccDocMap.test():void, ex=" + ex.getMessage(), "", "AccDocMap");
		}
	}
}