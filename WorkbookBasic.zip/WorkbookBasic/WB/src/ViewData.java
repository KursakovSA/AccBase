public class ViewData { // TOTHINK
	// origin - 02.11.2024, last edit - 01.05.2025

	static {
	}

	public ViewData() throws Exception {
		// origin - 02.11.2024, last edit - 02.11.2024
		super();
	}

	public static void test() throws Exception {
		// origin - 02.11.2024, last edit - 02.11.2024
		try {

		} catch (Exception ex) {
			WB.addLog("ViewData.test, ex=" + ex.getMessage(), "", "ViewData");
		}
	}
}