import java.util.Arrays;
import java.util.TreeSet;

public class Rule extends Model {
	// origin - 07.12.2023, last edit - 07.12.2023
	
	static {
		standard = new TreeSet<String>(Arrays.asList("", "", "", "", ""));//TODO
		sectoral = new TreeSet<String>(Arrays.asList("", "", "", "", ""));//TODO
		custom = new TreeSet<String>(Arrays.asList("", "", ""));//TODO
	}
    
    public Rule(String Id, String Code, String Description) {
		// origin - 07.12.2023, last edit - 07.12.2023
		this.id = Id;
		this.code = Code;
		this.description = Description;
	}
    
    public Rule() {
		// origin - 07.12.2023, last edit - 07.12.2023
	}
    
    public static void test() {
		// origin - 07.12.2023, last edit - 07.12.2023
	}
}
