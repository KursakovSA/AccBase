import java.util.List;

public class Rule extends ModelDto {
	// origin - 07.12.2023, last edit - 25.05.2024
	public static double minTimeIntervalSendSameSumOutDocInMs;//TODO to avoid duplicates when sending documents to external services
	public static List<ModelDto> listWorkerEntitledToRefund;//TOTHINK refund check from webkassa
	
//	static {
//		standard = new TreeSet<String>(Arrays.asList("", "", "", "", ""));//TODO
//		sectoral = new TreeSet<String>(Arrays.asList("", "", "", "", ""));//TODO
//		custom = new TreeSet<String>(Arrays.asList("", "", ""));//TODO
//	}
    
    public Rule(String Id, String Code, String Description) {
		// origin - 07.12.2023, last edit - 07.12.2023
		this.id = Id;
		this.code = Code;
		this.description = Description;
	}
    
    public Rule() {
		// origin - 07.12.2023, last edit - 07.12.2023
	}
    
    public static void test() {
		// origin - 07.12.2023, last edit - 07.12.2023
	}
}
