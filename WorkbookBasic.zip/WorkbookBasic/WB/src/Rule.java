import java.util.List;

public class Rule extends ModelDto {
	// origin - 07.12.2023, last edit - 06.07.2024
	public static double minTimeIntervalSendSameSumOutDocInMs;// TODO to avoid duplicates when sending documents to
																// external services
	public static List<ModelDto> listWorkerEntitledToRefund;// TOTHINK refund check from webkassa

	public Rule(String Id, String Code, String Description) throws Exception {
		// origin - 07.12.2023, last edit - 07.07.2024
		try {
			this.id = Id;
			this.code = Code;
			this.description = Description;
		} catch (Exception ex) {
			WB.addLog("Rule.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Rule");
		} finally {
			Etc.doNothing();
		}
	}

	public Rule() throws Exception {
		// origin - 07.12.2023, last edit - 07.07.2024
		try {
		} catch (Exception ex) {
			WB.addLog("Rule.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Rule");
		} finally {
			Etc.doNothing();
		}
	}

	public static void test() throws Exception {
		// origin - 07.12.2023, last edit - 06.07.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Rule.test, ex=" + ex.getMessage(), WB.strEmpty, "Rule");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Rule.test end ", WB.strEmpty, "Rule");
	}
}
