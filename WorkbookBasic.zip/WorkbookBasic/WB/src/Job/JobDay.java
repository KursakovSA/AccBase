import java.util.ArrayList;
import java.util.List;

public final class JobDay {
	// origin - 10.04.2025, last edit - 12.10.2025
	public String id, src;
	private List<String> srcList;
	public SpanTime jobTime, lunchTime, restTime;
	public int countTurn; // ?? del ??

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("JobDay.static ctor, ex=" + ex.getMessage(), "", "JobDay");
		}
	}

	private void getTime() throws Exception {
		// origin - 11.04.2025, last edit - 25.09.2025
		try {
			if (this.srcList.size() == 0) {
				this.jobTime = new SpanTime("09:00-18:00");
				this.lunchTime = new SpanTime("13:00-14:00");
				this.restTime = new SpanTime("13:00-14:00");
				return;
			}

			if (srcList.size() == 1) {
				this.jobTime = new SpanTime(srcList.get(0));
			}

			if (srcList.size() == 2) {
				this.jobTime = new SpanTime(srcList.get(0));
				this.lunchTime = new SpanTime(srcList.get(1));
			}

			if (srcList.size() == 3) {
				this.jobTime = new SpanTime(srcList.get(0));
				this.lunchTime = new SpanTime(srcList.get(1));
				this.restTime = new SpanTime(srcList.get(2));
			}
		} catch (Exception ex) {
			WB.addLog("JobDay.getTime():void, ex=" + ex.getMessage(), "", "JobDay");
		}
	}

	private void getPart() throws Exception {
		// origin - 11.04.2025, last edit - 13.06.2025
		try {
			// this.countTurn = this.jobTime.val.size();
			this.id = this.jobTime.val.toString() + "/";
			this.id = this.id + this.lunchTime.val.toString() + "/";
			this.id = this.id + this.restTime.val.toString() + "/";

			if ((this.jobTime.val.size() == 0) && (this.lunchTime.val.size() == 0) && (this.restTime.val.size() == 0)) {
				this.id = "";
			}
		} catch (Exception ex) {
			WB.addLog("JobDay.getPart():void, ex=" + ex.getMessage(), "", "JobDay");
		}
	}

	public JobDay(String Src) throws Exception {
		// origin - 10.04.2025, last edit - 16.04.2025
		this.clear();
		this.src = Src;
		this.srcList = Fmtr.listVal(this.src, "/");
		this.getTime();
		this.getPart();
	}

	public JobDay() throws Exception {
		// origin - 10.04.2025, last edit - 17.04.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 10.04.2025, last edit - 06.09.2025
		try {
			this.id = "";
			this.src = "";
			this.srcList = new ArrayList<String>();
			this.jobTime = new SpanTime();
			this.lunchTime = new SpanTime();
			this.restTime = new SpanTime();
		} catch (Exception ex) {
			WB.addLog("JobDay.clear():void, ex=" + ex.getMessage(), "", "JobDay");
		}
	}

	public String toString() {
		// origin - 10.04.2025, last edit - 10.05.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway(", src ", this.src);
			res = res + Fmtr.addAnyway(", srcList ", this.srcList);
			res = res + Fmtr.addIfNotEmpty(", jobTime ", this.jobTime.val);
			res = res + Fmtr.addIfNotEmpty(", lunchTime ", this.lunchTime.val);
			res = res + Fmtr.addIfNotEmpty(", restTime ", this.restTime.val);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 10.04.2025, last edit - 25.09.2025
		try {

//			WB.addLog2("JobDay.test.ctor(String)", "", "JobDay");
//			for (var tmp1 : new String[] { "", "08:00 - 17:00", "9-20", "9-18,18-02", "9-18,18-02/13-14" }) {
//				WB.addLog2("JobDay.test.ctor(String)=" + new JobDay(tmp1), "", "JobDay");
//			}

		} catch (Exception ex) {
			WB.addLog("JobDay.test():void, ex=" + ex.getMessage(), "", "JobDay");
		}
	}
}