import java.util.ArrayList;
import java.util.List;

public class JobMap {
	// origin - 23.04.2025, last edit - 10.05.2025
	public boolean isValid, isExist;
	public String table, src, id, parent, code, description, geo, role, info, mark, more;
	public String fullName, comment;
	public ListVal date1, date2;
	public List<FaceDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("JobMap.static ctor, ex=" + ex.getMessage(), "", "JobMap");
		}
	}

	// full plan list jobMap for point on date1 - date2 = spanDate
	@SuppressWarnings("unused")
	public static List<FaceDto> get(String date1, String date2, String deptId, String pointId) throws Exception {// TODO
		// origin - 10.05.2025, last edit - 15.09.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			FaceDto lastPointJobTurn = new FaceDto();
			List<FaceDto> listJobTurn = JobTurn.getCurr(date1, pointId);

			for (var currLocalDate : DateTool.getListLocalDate(date1, date2)) {
				// WB.addLog2("JobMap.currLocalDate=" + currLocalDate.toString(), "", "JobMap");

				var pointJobCycleJobDayJobTime = Point.getCurr(currLocalDate.toString(), "",
						pointId).jobCycle.jobDay.jobTime.val;

				for (var currPointJobTimeVal : pointJobCycleJobDayJobTime) {
					// WB.addLog2("JobMap.currPointJobTimeVal=" + currPointJobTimeVal, "",
					// "JobMap");

					for (var currPointJobTurn : listJobTurn) {
						// WB.addLog2("JobMap.currPointJobTurn.jobTurnId=" + currPointJobTurn.jobTurnId,
						// "", "JobMap");

						var tmp = new FaceDto(new IdGen("Face", "idCommonCompositeRandom").id, pointId,
								currLocalDate.toString(), currLocalDate.toString(), currPointJobTimeVal,
								currPointJobTurn.id, Geo.currCountry.code, "Role.Face.JobMap", "Info.Generic.Basic", "",
								"Mark.DD");
						res.add(tmp);
						lastPointJobTurn = tmp;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("JobMap.get(String date1, String date2, String deptId, String pointId):List<FaceDto>, ex="
					+ ex.getMessage(), "", "JobMap");
		}
		return res;
	}

	// full fact jobMap for point on date1 - date2 = spanDate
	public static List<FaceDto> getCurr(SpanDate spanDate, String parentPointId, String codeJobTurn) throws Exception {
		// origin - 25.04.2025, last edit - 13.06.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var listDto = FaceDto.getChronoSpan(spanDate, new JobMap(parentPointId, codeJobTurn).val);
			if (listDto.size() != 0) {
				for (var curr : listDto) {
					if (curr.id.isEmpty() == false) {
						var tmp = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
								curr.geo, curr.role, curr.info, curr.more, curr.mark);
						tmp.comment = curr.comment;
						tmp.fullName = curr.fullName;
						res.add(tmp);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("JobMap.getCurr(SpanDate spanDate, String parentPointId, String codeJobTurn):List<FaceDto>, ex="
					+ ex.getMessage(), "", "JobMap");
		}
		return res;
	}

	// full list fact jobMap for select codeJobTurn on date1
	public static List<FaceDto> getCurr(String date1, String parentPointId, String codeJobTurn) throws Exception {
		// origin - 23.04.2025, last edit - 15.09.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentCodeRoleInfoFilter(parentPointId, codeJobTurn, "Role.Face.JobMap", "Info.Generic.Extra"),
					"Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					var currFaceJobMap = new JobMap(currFace.parent, codeJobTurn);
					var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceJobMap.val, "");
					if (curr.id.isEmpty() == false) {
						var tmp = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
								curr.geo, curr.role, curr.info, curr.more, curr.mark);
						tmp.comment = curr.comment;
						tmp.fullName = curr.fullName;
						res.add(tmp);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("JobMap.getCurr(String date1, String parentPointId, String codeJobTurn):List<FaceDto>, ex="
					+ ex.getMessage(), "", "JobMap");
		}
		return res;
	}

	private void getVal() throws Exception {
		// origin - 23.04.2025, last edit - 13.06.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description, this.geo,
						this.role, this.info, this.more, this.mark);
				tmp.comment = this.comment;
				tmp.fullName = this.fullName;
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("JobMap.getVal():void, ex=" + ex.getMessage(), "", "JobMap");
		}
	}

	private void isExist() throws Exception {
		// origin - 23.04.2025, last edit - 15.09.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentCodeRoleInfoFilter(this.parent, this.code, "Role.Face.JobMap", "Info.Generic.Extra"),
					this.table);
			if (listDto.size() != 0) {
				for (var currDto : listDto) {
					var tmp = new SpanDate(currDto.date1, currDto.date2);
					this.date1 = new ListVal(tmp.date1);
					this.date2 = new ListVal(tmp.date2);

					this.id = DefVal.setCustom(this.id, currDto.id);
					this.parent = DefVal.setCustom(this.parent, currDto.parent);
					this.code = DefVal.setCustom(this.code, currDto.code);
					this.description = DefVal.setCustom(this.description, currDto.description);
					this.geo = DefVal.setCustom(this.geo, currDto.geo);
					this.role = DefVal.setCustom(this.role, currDto.role);
					this.info = DefVal.setCustom(this.info, currDto.info);
					this.more = DefVal.setCustom(this.more, currDto.more);
					this.mark = DefVal.setCustom(this.mark, currDto.mark);

					this.fullName = MoreVal.getFieldByKey(currDto.more, "FullName");
					this.comment = MoreVal.getFieldByKey(currDto.more, "Comment");

					this.isExist = true;
					break;
				}
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("JobMap.isExist():void, ex=" + ex.getMessage(), "", "JobMap");
		}
	}

	public JobMap(String ParentId, String CodeJobTurn) throws Exception {
		// origin - 23.04.2025, last edit - 11.08.2025
		this.clear();
		this.src = ParentId + "," + CodeJobTurn;
		this.parent = ParentId;
		this.code = CodeJobTurn;
		this.isExist();
		this.getVal();
	}

	private void clear() throws Exception {
		// origin - 23.04.2025, last edit - 06.09.2025
		try {
			this.table = "Face";
			this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.more = this.mark = "";
			this.fullName = this.comment = "";
			this.date1 = this.date2 = new ListVal();
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("JobMap.clear():void, ex=" + ex.getMessage(), "", "JobMap");
		}
	}

	public JobMap() throws Exception {
		// origin - 09.04.2025, last edit - 09.04.2025
		this.clear();
	}

	public String toString() {
		// origin - 23.04.2025, last edit - 25.04.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);

			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);

			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);

			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 23.04.2025, last edit - 15.08.2025
		try {

//			WB.addLog2("JobMap.test.get(List<FaceDto>)", "", "JobMap"); //TODO
//			for (var tmp1 : new String[] { "2025-01-05" }) {
//				for (var tmp2 : new String[] { "2025-01-10" }) {
//					for (var tmp3 : new String[] { "" }) {
//						for (var tmp4 : new String[] { "Face.FA1.AdmStaff.Point1" }) {
//							var tmp = JobMap.get(tmp1, tmp2, tmp3, tmp4);
//							WB.addLog2(
//									"JobMap.test.get(List<FaceDto>)" + ", faceParentId=" + tmp2 + ", codePoint=" + tmp4,
//									"", "JobMap");
//							WB.log(tmp, "JobMap");
//						}
//					}
//				}
//			}

//			WB.addLog2("JobMap.test.getCurr(List<FaceDto>)", "", "JobMap");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-05", "2025-02-03", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1.AdmStaff.Point1" }) {
//					for (var tmp3 : new String[] { "001" }) {
//						var month = SpanDate.getMonth(tmp1);
//						var tmp = JobMap.getCurr(month, tmp2, tmp3);
//						WB.addLog2("JobMap.test.getCurr(List<FaceDto>), res=" + tmp + ", spanDate=" + month
//								+ ", faceParentId=" + tmp2 + ", codeJobTurn=" + tmp3, "", "JobMap");
//							WB.log(tmp, "jobMap");
//					}
//				}
//			}

//			WB.addLog2("JobMap.test.getCurr(List<FaceDto>)", "", "JobMap");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-01", "2025-01-02", "2025-02-20" }) {
//				for (var tmp2 : new String[] { "Face.FA1.AdmStaff.Point1" }) {
//					for (var tmp3 : new String[] { "001", "002" }) {
//						var tmp = JobMap.getCurr(tmp1, tmp2, tmp3);
//						WB.addLog2("JobMap.test.getCurr(List<FaceDto>), res.size=" + tmp.size() + ", date1=" + tmp1
//								+ ", parentId=" + tmp2 + ", codeJobTurn=" + tmp3, "", "JobMap");
//							WB.log(JobMap.getCurr(tmp1, tmp2, tmp3), "JobMap");
//					}
//				}
//			}

//			// test JobMap.ctor(String,String)
//			WB.addLog2("JobMap.test.ctor(String,String)", "", "JobMap");
//			for (var tmp1 : new String[] { "Face.FA1.AdmStaff.Point1" }) {
//				for (var tmp2 : new String[] { "001", "002" }) {
//					WB.addLog2("JobMap.test.ctor(String,String)=" + new JobMap(tmp1, tmp2), "", "JobMap");
//				}
//			}

//			// test JobMap.ctor()
//			WB.addLog2("JobMap.test.ctor()", "", "JobMap");
//			WB.addLog2("JobMap.test.ctor()=" + new JobMap(), "", "JobMap");

		} catch (Exception ex) {
			WB.addLog("JobMap.test():void, ex=" + ex.getMessage(), "", "JobMap");
		}
	}
}