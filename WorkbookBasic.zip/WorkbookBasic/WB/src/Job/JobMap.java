import java.util.ArrayList;
import java.util.List;

public final class JobMap { // TODO
	// origin - 23.04.2025, last edit - 20.11.2025
	public String table, src, id, parent, code, description, geo, role, info, mark, more, defect;
	public String fullName, comment;
	public ListVal date1, date2;
	public List<FaceDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("JobMap.static ctor, ex=" + ex.getMessage(), "", "JobMap");
		}
	}

	// full plan list jobMap for point on date1 - date2 = spanDate
	@SuppressWarnings("unused")
	public static List<FaceDto> get(String date1, String date2, String deptId, String pointId) throws Exception {// TODO
		// origin - 10.05.2025, last edit - 27.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			FaceDto lastPointJobTurn = new FaceDto();
			List<FaceDto> listJobTurn = JobTurn.getCurr(date1, pointId);

			for (var currLocalDate : DateTool.getListLocalDate(date1, date2)) {
				// WB.addLog2("JobMap.currLocalDate=" + currLocalDate.toString(), "", "JobMap");

//				var pointJobCycleJobDayJobTime = Point.getCurr(currLocalDate.toString(), "",
//						pointId).jobCycle.jobDay.jobTime.val;
				var pointJobCycleJobDayJobTime = new JobCycle(
						Point.getCurr(currLocalDate.toString(), "", pointId).jobCycle).jobDay.jobTime.val;

				for (var currPointJobTimeVal : pointJobCycleJobDayJobTime) {
					// WB.addLog2("JobMap.currPointJobTimeVal=" + currPointJobTimeVal, "",
					// "JobMap");

					for (var currPointJobTurn : listJobTurn) {
						// WB.addLog2("JobMap.currPointJobTurn.jobTurnId=" + currPointJobTurn.jobTurnId,
						// "", "JobMap");

						var tmp = new FaceDto(new IdGen("Face", "idCommonCompositeRandom").id, pointId,
								currLocalDate.toString(), currLocalDate.toString(), currPointJobTimeVal,
								currPointJobTurn.id, Geo.currCountry.code, "Role.Face.JobMap", "Info.Generic.Basic", "",
								"Mark.DD");
						res.add(tmp);
						lastPointJobTurn = tmp;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("JobMap.get(4String):List<FaceDto>, ex=" + ex.getMessage(), "", "JobMap");
		}
		return res;
	}

	// full fact jobMap for point on date1 - date2 = spanDate
	public static List<FaceDto> getCurr(SpanDate spanDate, String parentPointId, String codeJobTurn) throws Exception {
		// origin - 25.04.2025, last edit - 27.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var listDto = FaceDto.getChronoSpan(spanDate, new JobMap(parentPointId, codeJobTurn).val);
			if (listDto.size() != 0) {
				for (var curr : listDto) {
					if (curr.id.isEmpty() == false) {
						res.add(curr);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("JobMap.getCurr(SpanDate, 2String):List<FaceDto>, ex=" + ex.getMessage(), "", "JobMap");
		}
		return res;
	}

	// full list fact jobMap for select codeJobTurn on date1
	public static List<FaceDto> getCurr(String date1, String parentPointId, String codeJobTurn) throws Exception {
		// origin - 23.04.2025, last edit - 27.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentCodeRoleInfoFilter(parentPointId,
					codeJobTurn, "Role.Face.JobMap", "Info.Generic.Extra"), "Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					var currFaceJobMap = new JobMap(currFace.parent, codeJobTurn);
					var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceJobMap.val, "");
					if (curr.id.isEmpty() == false) {
						res.add(curr);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("JobMap.getCurr(3String):List<FaceDto>, ex=" + ex.getMessage(), "", "JobMap");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 20.11.2025, last edit - 20.11.2025
		try {
		} catch (Exception ex) {
			WB.addLog("JobMap.validate():void, ex=" + ex.getMessage(), "", "JobMap");
		}
	}

	private void getVal() throws Exception {
		// origin - 23.04.2025, last edit - 06.10.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description, this.geo,
						this.role, this.info, this.more, this.mark);
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("JobMap.getVal():void, ex=" + ex.getMessage(), "", "JobMap");
		}
	}

	private void isExist() throws Exception {
		// origin - 23.04.2025, last edit - 20.11.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentCodeRoleInfoFilter(this.parent, this.code, "Role.Face.JobMap", "Info.Generic.Extra"),
					this.table);
			if (listDto.size() != 0) {
				var currDto = listDto.getFirst();
				var tmp = new SpanDate(currDto.date1, currDto.date2);
				this.date1 = new ListVal(tmp.date1);
				this.date2 = new ListVal(tmp.date2);
				this.id = DefVal.setCustom(this.id, currDto.id);
				this.parent = DefVal.setCustom(this.parent, currDto.parent);
				this.code = DefVal.setCustom(this.code, currDto.code);
				this.description = DefVal.setCustom(this.description, currDto.description);
				this.geo = DefVal.setCustom(this.geo, currDto.geo);
				this.role = DefVal.setCustom(this.role, currDto.role);
				this.info = DefVal.setCustom(this.info, currDto.info);
				this.more = DefVal.setCustom(this.more, currDto.more);
				this.mark = DefVal.setCustom(this.mark, currDto.mark);
				this.fullName = MoreVal.getFieldByKey(currDto.more, "FullName");
				this.comment = MoreVal.getFieldByKey(currDto.more, "Comment");
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("JobMap.isExist():void, ex=" + ex.getMessage(), "", "JobMap");
		}
	}

	public JobMap(String ParentId, String CodeJobTurn) throws Exception {
		// origin - 23.04.2025, last edit - 20.11.2025
		this.clear();
		this.src = ParentId + "," + CodeJobTurn;
		this.parent = ParentId;
		this.code = CodeJobTurn;
		this.isExist();
		this.getVal();
		this.validate();
	}

	private void clear() throws Exception {
		// origin - 23.04.2025, last edit - 20.11.2025
		try {
			this.table = "Face";
			this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.more = this.mark = "";
			this.fullName = this.comment = this.defect = "";
			this.date1 = this.date2 = new ListVal();
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("JobMap.clear():void, ex=" + ex.getMessage(), "", "JobMap");
		}
	}

	public JobMap() throws Exception {
		// origin - 09.04.2025, last edit - 09.04.2025
		this.clear();
	}

	public String toString() {
		// origin - 23.04.2025, last edit - 20.11.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", val.size ", this.val.size());
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception { // TODO
		// origin - 23.04.2025, last edit - 07.10.2025
		try {

//			WB.addLog2("JobMap.test.get(4String):List<FaceDto>", "", "JobMap"); // TODO
//			for (var tmp1 : new String[] { "2025-01-05" }) {
//				for (var tmp2 : new String[] { "2025-01-10" }) {
//					for (var tmp3 : new String[] { "" }) {
//						for (var tmp4 : new String[] { "Face.FA1.AdmStaff.Point1.JobTurn1" }) {
//							var tmp = JobMap.get(tmp1, tmp2, tmp3, tmp4);
//							WB.addLog2("JobMap.test.get(4String):List<FaceDto>" + ", faceParentId=" + tmp2
//									+ ", codePoint=" + tmp4, "", "JobMap");
//							WB.log(tmp, "JobMap");
//						}
//					}
//				}
//			}

//			WB.addLog2("JobMap.test.getCurr(SpanDate,2String):List<FaceDto>", "", "JobMap");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-05", "2025-02-03", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1.AdmStaff.Point1.JobTurn1" }) {
//					for (var tmp3 : new String[] { "Fact data job turn 001" }) {
//						var tmp4 = SpanDate.getMonth(tmp1);
//						var tmp5 = JobMap.getCurr(tmp4, tmp2, tmp3);
//						WB.addLog2("JobMap.test.getCurr(SpanDate,2String):List<FaceDto>, res=" + tmp5 + ", spanDate="
//								+ tmp4.id + ", faceParentId=" + tmp2 + ", codeJobTurn=" + tmp3, "", "JobMap");
//						WB.log(tmp5, "jobMap");
//					}
//				}
//			}

//			WB.addLog2("JobMap.test.getCurr(3String):List<FaceDto>", "", "JobMap");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-01", "2025-01-02", "2025-02-20" }) {
//				for (var tmp2 : new String[] { "Face.FA1.AdmStaff.Point1.JobTurn1" }) {
//					for (var tmp3 : new String[] { "Fact data job turn 001", "Fact data job turn 002" }) {
//						var tmp4 = JobMap.getCurr(tmp1, tmp2, tmp3);
//						WB.addLog2("JobMap.test.getCurr(3String):List<FaceDto>, res.size=" + tmp4.size() + ", date1="
//								+ tmp1 + ", parentId=" + tmp2 + ", codeJobTurn=" + tmp3, "", "JobMap");
//						WB.log(tmp4, "JobMap");
//					}
//				}
//			}

//			WB.addLog2("JobMap.test.ctor(2String)", "", "JobMap");
//			for (var tmp1 : new String[] { "Face.FA1.AdmStaff.Point1.JobTurn1 , Fact data job turn 001",
//					"Face.FA1.AdmStaff.Point1.JobTurn2 , Fact data job turn 002" }) {
//				var tmp2 = new TwoVal(tmp1);
//				var tmp3 = new JobMap(tmp2.val1, tmp2.val2);
//				WB.addLog2("JobMap.test.ctor(2String)=" + tmp3, "", "JobMap");
//				WB.log(tmp3.val, "JobMap");
//			}

		} catch (

		Exception ex) {
			WB.addLog("JobMap.test():void, ex=" + ex.getMessage(), "", "JobMap");
		}
	}
}