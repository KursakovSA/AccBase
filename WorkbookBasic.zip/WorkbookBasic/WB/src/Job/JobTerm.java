import java.util.List;

public class JobTerm { // TODO
	// origin - 25.08.2025, last edit - 16.09.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, face1, face2, face, date1, date2, code, description, geo, role, info, more,
			mark;
	// special fields
	public String fullName, comment, templateId, termId;
	public ProlongationTerm prolongationTerm;
	public PaymentTerm paymentTerm;
	public TemplateDocTerm templateDocTerm;
	public AddTerm addTerm;
	public List<ModelDto> lower, upper;
	public RangeVal durationDealLimit;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("JobTerm.static ctor, ex=" + ex.getMessage(), "", "JobTerm");
		}
	}

	private void isExist() throws Exception { // TODO
		// origin - 25.08.2025, last edit - 08.09.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), "Face");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.code = dto.code;
				this.parent = dto.parent;
				this.face1 = dto.face1;
				this.face2 = dto.face2;
				this.face = dto.face;
				this.description = dto.description;
				this.geo = dto.geo;
				this.role = dto.role;
				this.info = dto.info;
				this.more = dto.more;
				this.mark = dto.mark;

				var listDto2 = DAL.getTable(WB.lastConnWork, Qry.getText(WB.lastConnWork, "Deal", ""));
				this.upper = ModelDto.getUpper(listDto2, this.parent);
				this.lower = ModelDto.getLower(listDto2, this.code);

				this.getFieldFromMore();
				this.isExist = true;
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("JobTerm.isExist():void, ex=" + ex.getMessage(), "", "JobTerm");
		}
	}

	private void getFieldFromMore() throws Exception { // TODO
		// origin - 30.08.2025, last edit - 16.09.2025
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.templateId = MoreVal.getFieldByKey(this.more, "TemplateId");
			this.termId = MoreVal.getFieldByKey(this.more, "TermId");
			this.prolongationTerm = new ProlongationTerm(this.lower);
			this.templateDocTerm = new TemplateDocTerm(this.templateId);
			this.addTerm = new AddTerm(this.termId);
			this.durationDealLimit = new RangeVal(MoreVal.getFieldByKey(this.more, "DurationDealLimit"));
		} catch (Exception ex) {
			WB.addLog("JobTerm.getFieldFromMore():void, ex=" + ex.getMessage(), "", "JobTerm");
		}
	}

	public JobTerm(String Id) throws Exception { // TODO
		// origin - 25.08.2025, last edit - 25.08.2025
		this.clear();
		this.src = this.id = this.code = Id;
		this.isExist();
	}

	public JobTerm() throws Exception {
		// origin - 25.08.2025, last edit - 25.08.2025
		this.clear();
	}

	public String toString() {
		// origin - 25.08.2025, last edit - 16.09.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code.length());
			res = res + Fmtr.addIfNotEmpty(", description ", this.description.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addIfNotEmpty(" fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(" comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(" templateId ", this.templateId);
			res = res + Fmtr.addIfNotEmpty(" termId ", this.termId);

			res = res + Fmtr.addAnyway(", paymentTerm.isValid ", this.paymentTerm.isValid);
			res = res + Fmtr.addAnyway(", prolongationTerm.isValid ", this.prolongationTerm.isValid);
			res = res + Fmtr.addIfNotEmpty(", addTerm.addTerm.decription ", this.addTerm.description);
			res = res + Fmtr.addAnyway(", templateDocTerm.isValid ", this.templateDocTerm.isValid);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	private void clear() throws Exception {
		// origin - 25.08.2025, last edit - 16.09.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = "Face";
			this.id = this.parent = this.date1 = this.date2 = this.face1 = this.face2 = this.face = this.code = this.description = "";
			this.geo = this.role = this.info = this.more = this.mark = "";

			this.fullName = this.comment = this.templateId = this.termId = "";

			this.prolongationTerm = new ProlongationTerm();
			this.templateDocTerm = new TemplateDocTerm();
			this.paymentTerm = new PaymentTerm();
			this.addTerm = new AddTerm();

			this.durationDealLimit = new RangeVal(RangeVal.calendarDayInit);
		} catch (Exception ex) {
			WB.addLog("JobTerm.clear():void, ex=" + ex.getMessage(), "", "JobTerm");
		}
	}

	public static void test() throws Exception { // TODO
		// origin - 25.08.2025, last edit - 02.09.2025
		try {

//			WB.addLog2("JobTerm.test.ctor(String)", "", "JobTerm");
//			for (var tmp : new String[] { "", "PawnDoc.Template1.V1.Term1", "PawnDoc.Template1.V1.Term2" }) {
//				WB.addLog2("JobTerm.test.ctor(string)=" + new JobTerm(tmp), "", "JobTerm");
//			}

//			WB.addLog2("JobTerm.test.ctor()", "", "JobTerm");
//			WB.addLog2("JobTerm.test.ctor()=" + new JobTerm(), "", "JobTerm");

		} catch (Exception ex) {
			WB.addLog("JobTerm.test():void, ex=" + ex.getMessage(), "", "JobTerm");
		}
	}
}