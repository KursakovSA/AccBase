import java.util.ArrayList;
import java.util.List;

public final class JobTurn {
	// origin - 09.04.2025, last edit - 12.10.2025
	public boolean isValid, isExist;
	public String table, src, id, parent, code, description, geo, role, info, mark, more;
	public String jobTurnId, fullName, comment;
	public ListVal date1, date2, empId, jobCycle;
	public List<FaceDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("JobTurn.static ctor, ex=" + ex.getMessage(), "", "JobTurn");
		}
	}

	public static List<String> correctEmpId(String date1, String faceFAId, String facePointId, String faceJobTurnCode)
			throws Exception {
		// origin - 22.04.2025, last edit - 08.10.2025
		List<String> res = new ArrayList<String>();
		try {
			var jobTurnEmpId = Fmtr.listVal(JobTurn.getCurr(date1, facePointId, faceJobTurnCode).empId, ",");
			// WB.addLog2("JobTurn.correctEmpId, jobTurnEmpId=" + jobTurnEmpId, "",
			// "JobTurn");
			var staffTableEmpId = StaffTable.getCurrEmpId(date1, faceFAId);
			// WB.addLog2("JobTurn.correctEmpId, staffTableEmpId=" + staffTableEmpId, "",
			// "JobTurn");
			for (var currJobTurnEmpId : jobTurnEmpId) {
				for (var currStaffTableEmpId : staffTableEmpId) {
					if (Etc.strEquals(currJobTurnEmpId, currStaffTableEmpId)) {
						res.add(currJobTurnEmpId);
						break;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("JobTurn.correctEmpId(4String):List<String>, ex=" + ex.getMessage(), "", "JobTurn");
		}
		return res;
	}

	// full list jobTurn for any date1, date2
	public static List<FaceDto> get(String parentId) throws Exception {
		// origin - 21.04.2025, last edit - 08.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceByParentRole = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleFilter(parentId, "Role.Face.JobTurn"), "Face");
			if (faceByParentRole.size() != 0) {
				for (var currFace : faceByParentRole) {
					var curr = new JobTurn(currFace.parent, currFace.code);
					if (curr.id.isEmpty() == false) {
						for (var currFaceDto : curr.val) {
							res.add(currFaceDto);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("JobTurn.get(String):List<FaceDto>, ex=" + ex.getMessage(), "", "JobTurn");
		}
		return res;
	}

	// full list jobTurn on date1
	public static List<FaceDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 21.04.2025, last edit - 15.09.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceByParentRole = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleFilter(parentId, "Role.Face.JobTurn"), "Face");
			if (faceByParentRole.size() != 0) {
				for (var currFace : faceByParentRole) {
					var currFaceJobTurn = new JobTurn(currFace.parent, currFace.code);
					var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceJobTurn.val, "");
					if (curr.id.isEmpty() == false) {
						var tmp = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
								curr.geo, curr.role, curr.info, curr.more, curr.mark);
						tmp.jobTurnId = curr.jobTurnId;
						tmp.empId = curr.empId;
						tmp.jobCycle = curr.jobCycle;
						tmp.comment = curr.comment;
						tmp.fullName = curr.fullName;
						res.add(tmp);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("JobTurn.getCurr(2String):List<FaceDto>, ex=" + ex.getMessage(), "", "JobTurn");
		}
		return res;
	}

	// item jobTurn on date1
	public static FaceDto getCurr(String date1, String faceParentId, String faceJobTurnCode) throws Exception {
		// origin - 21.04.2025, last edit - 27.10.2025
		FaceDto res = new FaceDto();
		try {
			var currFaceJobTurn = new JobTurn(faceParentId, faceJobTurnCode);
			if (currFaceJobTurn.val.size() != 0) {
				var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceJobTurn.val, "");
				if (curr.id.isEmpty() == false) {
					res = curr;
				}
			}
		} catch (Exception ex) {
			WB.addLog("JobTurn.getCurr(3String):FaceDto, ex=" + ex.getMessage(), "", "JobTurn");
		}
		return res;
	}

	private void getVal() throws Exception {
		// origin - 20.04.2025, last edit - 27.10.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currEmpId = "";
			String currJobCycle = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currEmpId = this.empId.getByIndex(i);
				currJobCycle = this.jobCycle.getByIndex(i);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description, this.geo,
						this.role, this.info, this.more, this.mark);
				tmp.jobTurnId = this.jobTurnId;
				tmp.empId = currEmpId;
				tmp.jobCycle = currJobCycle;
				tmp.comment = this.comment;
				tmp.fullName = this.fullName;
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("JobTurn.getVal():void, ex=" + ex.getMessage(), "", "JobTurn");
		}
	}

	private void isExist() throws Exception {
		// origin - 20.04.2025, last edit - 07.10.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentCodeRoleFilter(this.parent, this.code, "Role.Face.JobTurn"), "Face");
			if (listDto.size() != 0) {
				var currDto = listDto.getFirst();
				var tmp = new SpanDate(currDto.date1, currDto.date2);
				this.date1 = new ListVal(tmp.date1);
				this.date2 = new ListVal(tmp.date2);
				this.id = DefVal.setCustom(this.id, currDto.id);
				this.parent = DefVal.setCustom(this.parent, currDto.parent);
				this.code = DefVal.setCustom(this.code, currDto.code);
				this.description = DefVal.setCustom(this.description, currDto.description);
				this.geo = DefVal.setCustom(this.geo, currDto.geo);
				this.role = DefVal.setCustom(this.role, currDto.role);
				this.info = DefVal.setCustom(this.info, currDto.info);
				this.more = DefVal.setCustom(this.more, currDto.more);
				this.mark = DefVal.setCustom(this.mark, currDto.mark);
				this.jobTurnId = MoreVal.getFieldByKey(currDto.more, "JobTurnId");
				this.fullName = MoreVal.getFieldByKey(currDto.more, "FullName");
				this.comment = MoreVal.getFieldByKey(currDto.more, "Comment");
				this.empId = new ListVal(MoreVal.getFieldByKey(currDto.more, "EmpId"), "");
				this.jobCycle = new ListVal(MoreVal.getFieldByKey(currDto.more, "jobCycle"), "");
				this.isExist = true;
				this.isValid = true;
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("JobTurn.isExist():void, ex=" + ex.getMessage(), "", "JobTurn");
		}
	}

	public JobTurn(String ParentId, String JobTurnCode) throws Exception {
		// origin - 20.04.2025, last edit - 11.08.2025
		this.clear();
		this.src = ParentId + "," + JobTurnCode;
		this.parent = ParentId;
		this.code = JobTurnCode;
		this.isExist();
		this.getVal();
	}

	private void clear() throws Exception {
		// origin - 09.04.2025, last edit - 07.10.2025
		try {
			this.isExist = this.isValid = false;
			this.table = "Face";
			this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.more = this.mark = "";
			this.jobTurnId = this.fullName = this.comment = "";
			this.date1 = this.date2 = this.empId = this.jobCycle = new ListVal();
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("JobTurn.clear():void, ex=" + ex.getMessage(), "", "JobTurn");
		}
	}

	public JobTurn() throws Exception {
		// origin - 09.04.2025, last edit - 09.04.2025
		this.clear();
	}

	public String toString() {
		// origin - 09.04.2025, last edit - 07.10.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", jobTurnId ", this.jobTurnId);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", empId ", this.empId.id);
			res = res + Fmtr.addIfNotEmpty(", jobCycle ", this.jobCycle.id);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", val.size ", this.val.size());
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 09.04.2025, last edit - 08.10.2025
		try {

//			WB.addLog2("JobTurn.test.correctEmpId(4String):List<String>", "", "JobTurn");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-20",
//					"2025-08-15" }) {
//				for (var tmp2 : new String[] {
//						"Face.FA1 , Face.FA1.AdmStaff.Point1 , Face.FA1.AdmStaff.Point1.JobTurn1" }) {
//					var tmp3 = new ThreeVal(tmp2);
//					WB.addLog2("JobTurn.test.correctEmpId(4String):List<String>, res="
//							+ JobTurn.correctEmpId(tmp1, tmp3.val1, tmp3.val2, tmp3.val3) + ", date1=" + tmp1
//							+ ", faceFAId=" + tmp3.val1 + ", facePointId=" + tmp3.val2 + ", faceJobTurnCode= "
//							+ tmp3.val3, "", "JobTurn");
//				}
//			}

//			WB.addLog2("JobTurn.test.get(String):List<FaceDto>", "", "JobTurn");
//			for (var tmp1 : new String[] { "Face.FA1.AdmStaff.Point1", "Face.kgd", "Face.Tralala.AdmStaff.Point1" }) {
//				var tmp2 = JobTurn.get(tmp1);
//				WB.addLog2("JobTurn.test.get(String):List<FaceDto>, res.size=" + tmp2.size() + ", parentId=" + tmp1, "",
//						"JobTurn");
//				WB.log(tmp2, "FaceDto");
//			}

//			WB.addLog2("JobTurn.test.getCurr(2String):List<FaceDto>", "", "JobTurn");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-31", "2025-02-20", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1.AdmStaff.Point1", "Face.kgd",
//						"Face.Tralala.AdmStaff.Point1" }) {
//					var tmp3 = JobTurn.getCurr(tmp1, tmp2);
//					WB.addLog2("JobTurn.test.getCurr(2String):List<FaceDto>, res.size=" + tmp3.size() + ", date1="
//							+ tmp1 + ", parentId=" + tmp2, "", "JobTurn");
//					WB.log(tmp3, "FaceDto");
//				}
//			}

//			WB.addLog2("JobTurn.test.getCurr(3String):FaceDto", "", "JobTurn");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-31", "2025-02-20", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1.AdmStaff.Point1 , Face.FA1.AdmStaff.Point1.JobTurn1",
//						"Face.kgd , Face.kgd.JobTurn1",
//						"Face.Tralala.AdmStaff.Point1 , Face.Tralala.AdmStaff.Point1.JobTurn1" }) {
//					var tmp3 = new TwoVal(tmp2);
//					WB.addLog2("JobTurn.test.getCurr(3String):FaceDto, res="
//							+ JobTurn.getCurr(tmp1, tmp3.val1, tmp3.val2) + ", date1=" + tmp1 + ", faceParentId="
//							+ tmp3.val1 + ", faceJobTurnCode" + tmp3.val2, "", "JobTurn");
//				}
//			}

//			WB.addLog2("JobTurn.test.ctor(2String) extra job turn", "", "JobTurn");
//			for (var tmp1 : new String[] { "Face.FA1.AdmStaff , Face.FA1.AdmStaff.ExtraJobTurn1",
//					"Face.Tralala.AdmStaff , Face.Tralala.AdmStaff.ExtraJobTurn1" }) {
//				var tmp2 = new TwoVal(tmp1);
//				var tmp3 = new JobTurn(tmp2.val1, tmp2.val2);
//				WB.addLog2("JobTurn.test.ctor(2String) extra job turn=" + tmp3, "", "JobTurn");
//				WB.log(tmp3.val, "FaceDto");
//			}

//			WB.addLog2("JobTurn.test.ctor(2String)", "", "JobTurn");
//			for (var tmp1 : new String[] { "Face.FA1.AdmStaff.Point1 , Face.FA1.AdmStaff.Point1.JobTurn1",
//					"Face.Tralala.AdmStaff.Point1 , Face.FA1.Tralala.Point1.JobTurn1" }) {
//				var tmp2 = new TwoVal(tmp1);
//				var tmp3 = new JobTurn(tmp2.val1, tmp2.val2);
//				WB.addLog2("JobTurn.test.ctor(2String)=" + tmp3, "", "JobTurn");
//				WB.log(tmp3.val, "FaceDto");
//			}

		} catch (Exception ex) {
			WB.addLog("JobTurn.test():void, ex=" + ex.getMessage(), "", "JobTurn");
		}
	}
}