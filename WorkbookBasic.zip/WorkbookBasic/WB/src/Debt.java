import java.time.LocalDate;

public class Debt extends Model {
	// origin - 28.09.2023, last edit - 15.01.2024
	public static Debt root;
	public Debt parent;
	public Geo geo;
	public Role role;
	public Info info;
	public static double rateVAT;

	static {
		root = new Debt("Debt", "Debt", "DebtData");
		rateVAT = getRateVAT(LocalDate.now());
	}

	public Debt(String Id, String Code, String Description) {
		// origin - 05.12.2023, last edit - 05.12.2023
		this.id = Id;
		this.code = Code;
		this.description = Description;
	}

	public Debt() {
		// origin - 05.12.2023, last edit - 05.12.2023
	}

	public static double getSegment(LocalDate calcDate, ModelDto filterDto) {
		// origin - 11.01.2024, last edit - 16.01.2024
		double res = 0.0;
		try {
			res = Workbook.getChronoMeterValue(calcDate, ModelDto.getSubset(WB.abcGlobal.basic, filterDto));
		} catch (Exception ex) {
			Logger.add("Debt.getSegment, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace() + ", res=" + res,
					"", "Debt");
		} finally {
			Etc.doNothing();
		}
		// Logger.add2("Debt.getSegment, res=" + res + ", calcLocalDate=" +
		// calcDate,"","Debt");
		return res;
	}

	public static double getSumTax(double sumBaseTax, double rateTax, int numberFractionalDigit) {
		// origin - 10.10.2023, last edit - 16.01.2024
		double res = 0.0;
		// double rateTax = getRateTax(currDate, codeTax);
		res = sumBaseTax * (Etc.ratio100(rateTax)); // only net sum Tax, less baseTax
		// res = Etc.roundTax(res, codeTax);
		res = Etc.setZeroOnNeg(Etc.roundCustom(res, numberFractionalDigit));
		return res;
	}

	public static double getRateTax(LocalDate currDate, String code) {
		// origin - 15.01.2024, last edit - 16.01.2024
		double res = 0.0;
		res = getSegment(currDate, ModelDto.getSegmentByCode(code));
		return res;
	}

	public static double getRateVAT(LocalDate currDate) {
		// origin - 09.10.2023, last edit - 16.01.2024
		double res = 0.0;
		// res = getSegment(currDate,
		// ModelDto.getSegmentByCode("Debt.VAT.Sell.RateBasic"));
		res = getRateTax(currDate, "Debt.VAT.Sell.RateBasic");
		return res;
	}

	public static double subtractInVAT(double sumWithVAT, double rateVAT) {
		// origin - 08.10.2023, last edit - 29.10.2023
		double res = 0.0;
		sumWithVAT = Etc.roundCustom(sumWithVAT);
		res = sumWithVAT - getInVAT(sumWithVAT, rateVAT);
		res = Etc.roundCustom(res);
		return res;
	}

	public static double addOutVAT(double sumLessVAT, double rateVAT) {
		// origin - 02.10.2023, last edit - 28.10.2023
		double res = 0.0;
		sumLessVAT = Etc.roundCustom(sumLessVAT); // with cents
		res = sumLessVAT + getOutVAT(sumLessVAT, rateVAT);
		res = Etc.roundCustom(res);
		return res;
	}

	public static double getOutVAT(double sumLessVAT, double rateVAT) {
		// origin - 08.10.2023, last edit - 28.10.2023
		double res = 0.0;
		sumLessVAT = Etc.roundCustom(sumLessVAT); // with cents
		res = getSumTax(sumLessVAT, rateVAT, Etc.round2); // with cents
		res = Etc.roundCustom(res); // with cents
		return res;
	}

	public static double getInVAT(double sumWithVAT, double rateVAT) {
		// origin - 02.10.2023, last edit - 28.10.2023
		double res = 0.0;
		sumWithVAT = Etc.roundCustom(sumWithVAT); // with cents
		res = (sumWithVAT * rateVAT) / (100.0 + rateVAT);
		res = Etc.roundCustom(res); // with cents
		return res;
	}

	public static void test() {
		// origin - 28.10.2023, last edit - 15.01.2024

		// getSegment
		for (LocalDate testArg1 : new LocalDate[] { LocalDate.now().minusYears(1), LocalDate.now() }) {
			for (ModelDto testArg2 : new ModelDto[] { ModelDto.getSegmentByCode("MinRate"),
					ModelDto.getSegmentByCode("MinSalary"), ModelDto.getSegmentByCode("Debt.VAT.Sell.MainRate") }) {
				Logger.add2("Debt.test.getSegment, res=" + getSegment(testArg1, testArg2) + ", testArg1=" + testArg1
						+ ", testArg2=" + testArg2, "", "Debt");
			}
		}

		// getSumTax
		for (double testArg11 : new double[] { 100.0, 567.43, 0.00, 323.56452 }) {
			Logger.add2("Debt.test.getSumTax, res=" + getSumTax(testArg11, rateVAT, Etc.round2) + ", baseTax="
					+ testArg11 + ", RateTax=" + rateVAT, "", "Debt");
			// reverse check
			Logger.add2("Debt.test.getOutVAT as reverse check for getSumTax, res=" + getOutVAT(testArg11, rateVAT)
					+ ", baseTax=" + testArg11 + ", RateTax=" + rateVAT, "", "Debt");
		}

		// getRateVAT
		Logger.add2("Debt.test.getRateVAT, res=" + getRateVAT(LocalDate.now()), "", "Debt");

		// subtractInVAT
		for (double testArg11 : new double[] { 112.0, 567.68, 0.00, 342.8456 }) {
			Logger.add2("Debt.test.subtractInVAT, res=" + subtractInVAT(testArg11, rateVAT) + ", sumWithVAT="
					+ testArg11 + ", rateVAT=" + rateVAT, "", "Debt");
			// reverse check
			Logger.add2("Debt.test.addOutVAT as reverse check for subtractInVAT, res="
					+ addOutVAT(subtractInVAT(testArg11, rateVAT), rateVAT) + ", sumLessVAT="
					+ subtractInVAT(testArg11, rateVAT) + ", rateVAT=" + rateVAT, "", "Debt");
		}

		// addOutVAT
		for (double testArg1 : new double[] { 100.0, 567.43, 0.00, 323.56452 }) {
			Logger.add2("Debt.test.addOutVAT, res=" + addOutVAT(testArg1, rateVAT) + ", sumLessVAT=" + testArg1
					+ ", rateVAT=" + rateVAT, "", "Debt");
		}

		// getOutVAT
		for (double testArg1 : new double[] { 100.0, 567.43, 0.00, 323.56452 }) {
			Logger.add2("Debt.test.getOutVAT, res=" + getOutVAT(testArg1, rateVAT) + ", sumLessVAT=" + testArg1
					+ ", rateVAT=" + rateVAT, "", "Debt");
		}

		// getInVAT
		for (double testArg1 : new double[] { 112.0, 567.68, 0.00, 342.8456 }) {
			Logger.add2("Debt.test.addInVAT, res=" + getInVAT(testArg1, rateVAT) + ", sumWithVAT=" + testArg1
					+ ", rateVAT=" + rateVAT, "", "Debt");
		}
	}
}
