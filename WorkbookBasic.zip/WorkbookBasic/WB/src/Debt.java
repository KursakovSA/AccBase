import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unused")
public class Debt extends ModelDto {
	// origin - 28.09.2023, last edit - 21.12.2024
	public static String rateBasicVAT;

	static {
		try {
			Debt.rateBasicVAT = "Debt.VAT.Sell.RateBasic";
		} catch (Exception ex) {
			WB.addLog("Debt.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
	}

//	private void getLower() throws Exception {
//		// origin - 18.12.2024, last edit - 19.12.2024
//		var srcList = WB.abcLast.debt;
//		List<ModelDto> tmpLower1 = new ArrayList<ModelDto>();
//		tmpLower1 = ReadSet.getEqualsByParent(srcList, this.code); // direct lower 1 level
//		List<ModelDto> tmpLower2 = new ArrayList<ModelDto>(); // lower 2 level
//		boolean foundNewLowerCode = true;
//
//		try {
//			for (;;) {
//				foundNewLowerCode = false;
//				tmpLower2.clear();
//
//				for (var currL1 : tmpLower1) {
//					tmpLower2.addAll(ReadSet.getEqualsByParent(srcList, currL1.code));
//				}
//
//				for (var currL2 : tmpLower2) {
//					if (ModelDto.isContains(tmpLower1, currL2) == false) {
//						tmpLower1.add(currL2);
////						WB.addLog2("Debt.getLower, add currL2.code=" + currL2.code + ", for this.code=" + this.code,
////								WB.strEmpty, "Debt");
//						foundNewLowerCode = true;
//					}
//				}
//
//				if (foundNewLowerCode == false) {
//					break;
//				}
//			}
//
//			this.lower.addAll(tmpLower1);
//		} catch (Exception ex) {
//			WB.addLog("Debt.getLower, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
//		} finally {
//			Etc.doNothing();
//		}
//	}

//	private void getLower() throws Exception {
//		// origin - 19.12.2024, last edit - 20.12.2024
//		try {
//			this.lower = ReadSet.getContainsByParent(WB.abcLast.debt, this.code);
//		} catch (Exception ex) {
//			WB.addLog("Debt.getLower, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
//		} finally {
//			Etc.doNothing();
//		}
//	}

//	private void getUpper() throws Exception {
//		// origin - 17.12.2024, last edit - 20.12.2024
//		var srcList = WB.abcLast.debt;
//		String tmpParentCode = this.parent;
//		List<ModelDto> tmpUpper = new ArrayList<ModelDto>();
//		boolean foundNewParentCode = true;
//
//		try {
//			for (;;) {
//				foundNewParentCode = false;
//				for (var currLst : srcList) {
//					if (Etc.strEquals(currLst.code, tmpParentCode)) {
//						if (ModelDto.isContains(tmpUpper, currLst) == false) {
//							tmpUpper.add(currLst);
////							WB.addLog2("Debt.getUpper, add currLst.code=" + currLst.code + ", tmpParentCode="
////									+ tmpParentCode + ", for this.code=" + this.code, WB.strEmpty, "Debt");
//							tmpParentCode = currLst.parent;
//							foundNewParentCode = true;
//							break;
//						}
//					}
//				}
//				if (foundNewParentCode == false) {
//					break;
//				}
//			}
//			this.upper.addAll(tmpUpper);
//		} catch (Exception ex) {
//			WB.addLog("Debt.getUpper, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("Debt.getUpper, tmpUpper.size=" + tmpUpper.size(), WB.strEmpty,
//		// "Debt");
//	}

	public void isExist() throws Exception {
		// origin - 16.12.2024, last edit - 18.12.2024
		super.isExist();
		try {
			var commonDebt = new ArrayList<ModelDto>(); // ?? join ??
			commonDebt.addAll(WB.abcLast.debt);
			commonDebt.addAll(WB.abcGlobal.debt);
			for (var currDebt : commonDebt) {// WB.abcLast.debt) {
				if (Etc.strEquals(currDebt.id, this.id)) {
					this.slice = DefVal.setCustom(this.slice, currDebt.slice);
					this.date1 = DefVal.setCustom(DateTool.getNow().toString(), currDebt.date1);// this.date1,
					this.date2 = DefVal.setCustom(this.date2, currDebt.date2);
					this.code = DefVal.setCustom(this.code, currDebt.code);
					this.parent = DefVal.setCustom(this.parent, currDebt.parent);
					this.description = DefVal.setCustom(this.description, currDebt.description);
					this.geo = DefVal.setCustom(this.geo, currDebt.geo);
					this.role = DefVal.setCustom(this.role, currDebt.role);
					this.info = DefVal.setCustom(this.info, currDebt.info);
					this.more = DefVal.setCustom(this.more, currDebt.more);

					this.isExist = true;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Debt.isExist, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Debt.isExist=" + this.isExist, WB.strEmpty,"Debt");
	}

	public void isValid() throws Exception {
		// origin - 16.12.2024, last edit - 16.12.2024
		super.isValid();
		try {
			if (this.date1.isEmpty() | this.geo.isEmpty() | this.role.isEmpty() | this.info.isEmpty()) {
				this.isValid = false;
			}
		} catch (Exception ex) {
			WB.addLog("Debt.isValid, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Debt.isValid=" + this.isValid, WB.strEmpty,"Debt");
	}

	public Debt(String Id) throws Exception {
		// origin - 05.12.2023, last edit - 20.12.2024
		this();
		this.src = Id;
		this.id = this.code = Id;
		// this.date1 = DateTool.getNow().toString();
		this.isExist();
		this.isValid();
		this.upper = super.getUpper(WB.abcLast.debt);
		this.lower = super.getLower(WB.abcLast.debt);
	}

	public Debt() throws Exception {
		// origin - 05.12.2023, last edit - 16.12.2024
		this.clear();
		this.isExist();
		var root = Abc.getRoot(this.table);
		this.id = root.id;
		this.parent = root.parent;
		this.date1 = root.date1;
		this.date2 = root.date2;
		this.code = root.code;
		this.description = root.description;
		this.geo = root.geo;
		this.role = root.role;
		this.info = root.info;
		this.more = root.more;
	}

//	private static double getVal(LocalDate calcDate, ModelDto filterDto) throws Exception {
//		// origin - 11.01.2024, last edit - 20.12.2024
//		double res = 0.0;
//		try {
//			res = ReadSet.getChrono(calcDate, ReadSet.getByFilter(WB.abcGlobal.basic, filterDto));
//		} catch (Exception ex) {
//			WB.addLog("Debt.getVal, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Debt");
//		} finally {
//			Etc.doNothing();
//		}
////		WB.addLog2("Debt.getVal, res=" + res + ", calcDate=" + calcDate + ", filterDto=" + filterDto, WB.strEmpty,
////				"Debt");
//		return res;
//	}

	private static double getSum(LocalDate currDate, double sumBase, String code) throws Exception {
		// origin - 10.10.2023, last edit - 16.12.2024
		double res = 0.0;
		try {
			double rateTax = Debt.getRate(currDate, code);
			res = sumBase * (Etc.ratio100(rateTax)); // only net sum, less base
			res = Etc.roundTax(res, code);
		} catch (Exception ex) {
			WB.addLog("Debt.getSum, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Debt.getSum, res=" + res + ", currDate=" + currDate + ", sumBase=" + sumBase + ", code=" + code,
				WB.strEmpty, "Debt");
		return res;
	}

	private static double getRate(LocalDate currDate, String code) throws Exception {
		// origin - 15.01.2024, last edit - 20.12.2024
		double res = 0.0;
		try {
			var filterDto = ReadSet.getEqualsByCode(WB.abcGlobal.debt, code).getFirst();
			res = ReadSet.getChrono(currDate, ReadSet.getByFilter(WB.abcGlobal.basic, filterDto));
		} catch (Exception ex) {
			WB.addLog("Debt.getRate, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Debt.getRate, res=" + res + ", currDate=" + currDate + ", code=" + code, WB.strEmpty, "Debt");
		return res;
	}

	private static double minusInner(LocalDate currDate, double sumWith, String code) throws Exception {
		// origin - 08.10.2023, last edit - 16.12.2024
		double res = 0.0;
		try {
			res = sumWith - Debt.getInner(currDate, sumWith, code);
			res = Etc.roundTax(res, code);
		} catch (Exception ex) {
			WB.addLog("Debt.minusInner, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Debt.minusInner, res=" + res + ", currDate=" + currDate + ", sumWith=" + sumWith + ", code=" + code,
				WB.strEmpty, "Debt");
		return res;
	}

	private static double addOutside(LocalDate currDate, double sumLess, String code) throws Exception {
		// origin - 02.10.2023, last edit - 16.12.2024
		double res = 0.0;
		try {
			res = sumLess + Debt.getSum(currDate, sumLess, code);
		} catch (Exception ex) {
			WB.addLog("Debt.addOutside, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Debt.addOutside, res=" + res + ", currDate=" + currDate + ", sumLess=" + sumLess + ", code=" + code,
				WB.strEmpty, "Debt");
		return res;
	}

	private static double getInner(LocalDate currDate, double sumWith, String code) throws Exception {
		// origin - 02.10.2023, last edit - 16.12.2024
		double res = 0.0;
		try {
			double rateTax = Debt.getRate(currDate, code);
			res = (sumWith * rateTax) / (100.0 + rateTax);
			res = Etc.roundTax(res, code);
		} catch (Exception ex) {
			WB.addLog("Debt.getInner, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Debt.getInner, res=" + res + ", currDate=" + currDate + ", sumWith=" + sumWith + ", code=" + code,
				WB.strEmpty, "Debt");
		return res;
	}

	public void clear() throws Exception {
		// origin - 17.12.2024, last edit - 20.12.2024
		try {
			super.clear();
			this.table = this.getClass().getName();
		} catch (Exception ex) {
			WB.addLog("Debt.clear, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
	}

	public String toString() {
		// origin - 25.11.2024, last edit - 20.12.2024
		String res = WB.strEmpty;
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", ", this.slice);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);

			res = res + Fmtr.addIfNotZeroSize(", upper ", this.upper);
			res = res + Fmtr.addIfNotZeroSize(", lower ", this.lower);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 20.12.2024
		try {
			double[] testArgLessTax = new double[] { 100.0, 567.43, 0.00, 323.56452 };
			double[] testArgWithTax = new double[] { 112.0, 567.68, 0.00, 342.8456 };
			double testRateTax = Debt.getRate(DateTool.getNow(), Debt.rateBasicVAT);

//			// getUpper(), getLower()
//			for (var tmp : new Debt[] { new Debt(), new Debt("Debt.GFSS"), new Debt("Debt.IncomePerson.Base"),
//					new Debt("Debt.tralala"), new Debt("Debt.Pension.OPVR.RateBasic2024") }) {
//				WB.addLog2("Debt.test, tmp.id=" + tmp.id + ", tmp.upper.size=" + tmp.upper.size() + ", tmp.lower.size="
//						+ tmp.lower.size(), WB.strEmpty, "Debt");
//			}

			// ctor (), ctor (String Id)
			for (var tmp : new Debt[] { new Debt(), new Debt("Debt.GFSS"), new Debt("Debt.IncomePerson.Base"),
					new Debt("Debt.tralala"), new Debt("Debt.Pension.OPVR.RateBasic2024") }) {
				WB.addLog2("Debt.test.ctor(String)=" + tmp, WB.strEmpty, "Debt");
			}

//			// getSum
//			for (double testArg1 : testArgLessTax) {
//				WB.addLog2("Debt.test.getSum, res=" + Debt.getSum(DateTool.getNow(), testArg1, Debt.rateBasicVAT)
//						+ ", base=" + testArg1 + ", Rate=" + testRateTax, WB.strEmpty, "Debt");
//			}

//			// minusInner
//			for (double testArg1 : testArgWithTax) {
//				WB.addLog2("Debt.test.subtractInner, res="
//						+ Debt.minusInner(DateTool.getNow(), testArg1, Debt.rateBasicVAT) + ", sumWith=" + testArg1
//						+ ", rate=" + testRateTax, WB.strEmpty, "Debt");
//			}

//			// addOutside
//			for (double testArg1 : testArgLessTax) {
//				WB.addLog2(
//						"Debt.test.addOutside, res=" + Debt.addOutside(DateTool.getNow(), testArg1, Debt.rateBasicVAT)
//								+ ", sumLess=" + testArg1 + ", rate=" + testRateTax,
//						WB.strEmpty, "Debt");
//			}

//			// getInner
//			for (double testArg1 : testArgWithTax) {
//				WB.addLog2("Debt.test.getInner, res=" + Debt.getInner(DateTool.getNow(), testArg1, Debt.rateBasicVAT)
//						+ ", sumWith=" + testArg1 + ", rate=" + testRateTax, WB.strEmpty, "Debt");
//			}
		} catch (Exception ex) {
			WB.addLog("Debt.test, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Debt.test end ", WB.strEmpty, "Debt");
	}
}
