import java.time.LocalDate;

public class Debt extends Model {
	// origin - 28.09.2023, last edit - 05.12.2023
	public static Debt root;
	public Debt parent;
	public Geo geo;
	public Role role;
	public Info info;
	public static double rateVAT;

	static {
		root = new Debt("Debt","Debt","DebtData");
		rateVAT = getRateVAT(LocalDate.now());
	}
	
	public Debt(String Id, String Code, String Description) {
		// origin - 05.12.2023, last edit - 05.12.2023
		this.id = Id;
		this.code = Code;
		this.description = Description;
	}
	
	public Debt() {
		// origin - 05.12.2023, last edit - 05.12.2023
	}

	public static double getTurn(LocalDate date1, LocalDate date2, String currContext) {
		// origin - 18.10.2023, last edit - 28.10.2023
		// find turn Debt at period from date1 to date2
		// currContext may be equals -- "VAT.Sum", "VAT.Base.Sum", "VAT.Base.MaxLimit",
		// "IncomePersonTax.Dediction".... etc.
		double res = 0.0;
		// TODO - here need do get processRateVAT from WorkDatabase.sqlite3
		res = Etc.roundCustom(res);
		return res;
	}

	public static double getRest(LocalDate date2, String currContext) {
		// origin - 18.10.2023, last edit - 28.10.2023
		// find rest Debt on currDate
		// currContext may be equals -- "VAT.Sum", "VAT.Base.Sum", "VAT.Base.MaxLimit",
		// "IncomePersonTax.Dediction".... etc.
		double res = 0.0;
		// TODO - here need do get processRateVAT from WorkDatabase.sqlite3
		res = Etc.roundCustom(res);
		return res;
	}

	public static double getSegment(LocalDate currDate, String currContext) {
		// origin - 18.10.2023, last edit - 28.10.2023
		// currContext may be equals -- "VAT.Rate", "VAT.Base.MinLimit",
		// "VAT.Base.MaxLimit", "IncomePersonTax.Dediction".... etc.
		double res = 0.0;
		// TODO - here need do get processRateVAT from DatabaseGlobal.sqlite3
		res = Etc.setZeroOnNeg(Etc.roundCustom(res));
		return res;
	}

	public static double getSumTax(double sumBaseTax, double rateTax, int numberFractionalDigit) {
		// origin - 10.10.2023, last edit - 28.10.2023
		double res = 0.0;
		// sumBaseTax = roundCustom(sumBaseTax,numberFractionalDigit);
		res = sumBaseTax * (Etc.ratio100(rateTax)); // only net sum Tax, less baseTax
		res = Etc.setZeroOnNeg(Etc.roundCustom(res, numberFractionalDigit));
		return res;
	}

	public static double getRateVAT(LocalDate currDate) {
		// origin - 09.10.2023, last edit - 25.11.2023
		double res = 0.0;
		getSegment(currDate, "Debt.VAT.Sell.RateBasic");
		// TODO get rateVAT from abcGlobal
		res = res == 0.0 ? 12.0 : res; // default stub = 12.0 when no rate vat from DatabaseGlobal.sqlite3
		res = Etc.setZeroOnNeg(Etc.roundCustom(res));
		return res;
	}

	public static double subtractInVAT(double sumWithVAT, double rateVAT) {
		// origin - 08.10.2023, last edit - 29.10.2023
		double res = 0.0;
		sumWithVAT = Etc.roundCustom(sumWithVAT);
		res = sumWithVAT - getInVAT(sumWithVAT, rateVAT);
		res = Etc.roundCustom(res);
		return res;
	}

	public static double addOutVAT(double sumLessVAT, double rateVAT) {
		// origin - 02.10.2023, last edit - 28.10.2023
		double res = 0.0;
		sumLessVAT = Etc.roundCustom(sumLessVAT); // with cents
		res = sumLessVAT + getOutVAT(sumLessVAT, rateVAT);
		res = Etc.roundCustom(res);
		return res;
	}

	public static double getOutVAT(double sumLessVAT, double rateVAT) {
		// origin - 08.10.2023, last edit - 28.10.2023
		double res = 0.0;
		sumLessVAT = Etc.roundCustom(sumLessVAT); // with cents
		res = getSumTax(sumLessVAT, rateVAT, Etc.round2); // with cents
		res = Etc.roundCustom(res); // with cents
		return res;
	}

	public static double getInVAT(double sumWithVAT, double rateVAT) {
		// origin - 02.10.2023, last edit - 28.10.2023
		double res = 0.0;
		sumWithVAT = Etc.roundCustom(sumWithVAT); // with cents
		res = (sumWithVAT * rateVAT) / (100.0 + rateVAT);
		res = Etc.roundCustom(res); // with cents
		return res;
	}

	public static void test() {
		// origin - 28.10.2023, last edit - 05.12.2023
		
		Logger.add("Debt.test, Debt.root=" + Debt.root, "", "Debt");

		// getSumTax
		for (double testArg11 : new double[] { 100.0, 567.43, 0.00, 323.56452 }) {
			Logger.add2("Debt.test.getSumTax, res=" + getSumTax(testArg11, rateVAT, Etc.round2) + ", baseTax="
					+ testArg11 + ", RateTax=" + rateVAT, "", "Debt");
			// reverse check
			Logger.add2("Debt.test.getOutVAT as reverse check for getSumTax, res=" + getOutVAT(testArg11, rateVAT)
					+ ", baseTax=" + testArg11 + ", RateTax=" + rateVAT, "", "Debt");
		}

		// getRateVAT
		Logger.add2("Debt.test.getRateVAT, res=" + getRateVAT(LocalDate.now()), "", "Debt");

		// subtractInVAT
		for (double testArg11 : new double[] { 112.0, 567.68, 0.00, 342.8456 }) {
			Logger.add2("Debt.test.subtractInVAT, res=" + subtractInVAT(testArg11, rateVAT) + ", sumWithVAT="
					+ testArg11 + ", rateVAT=" + rateVAT, "", "Debt");
			// reverse check
			Logger.add2("Debt.test.addOutVAT as reverse check for subtractInVAT, res="
					+ addOutVAT(subtractInVAT(testArg11, rateVAT), rateVAT) + ", sumLessVAT="
					+ subtractInVAT(testArg11, rateVAT) + ", rateVAT=" + rateVAT, "", "Debt");
		}

		// addOutVAT
		for (double testArg1 : new double[] { 100.0, 567.43, 0.00, 323.56452 }) {
			Logger.add2("Debt.test.addOutVAT, res=" + addOutVAT(testArg1, rateVAT) + ", sumLessVAT=" + testArg1
					+ ", rateVAT=" + rateVAT, "", "Debt");
		}

		// getOutVAT
		for (double testArg1 : new double[] { 100.0, 567.43, 0.00, 323.56452 }) {
			Logger.add2("Debt.test.getOutVAT, res=" + getOutVAT(testArg1, rateVAT) + ", sumLessVAT=" + testArg1
					+ ", rateVAT=" + rateVAT, "", "Debt");
		}

		// getInVAT
		for (double testArg1 : new double[] { 112.0, 567.68, 0.00, 342.8456 }) {
			Logger.add2("Debt.test.addInVAT, res=" + getInVAT(testArg1, rateVAT) + ", sumWithVAT=" + testArg1
					+ ", rateVAT=" + rateVAT, "", "Debt");
		}
	}
}
