import java.time.LocalDate;

public class Debt extends Model {
	// origin - 28.09.2023, last edit - 06.07.2024
	public Debt parent;
	public Geo geo;
	public Role role;
	public Info info;
	public static String rateBasicVAT;

	static {
		try {
			rateBasicVAT = "Debt.VAT.Sell.RateBasic";
		} catch (Exception ex) {
			WB.addLog("Debt.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
	}

	public Debt(String Id, String Code, String Description) throws Exception {
		// origin - 05.12.2023, last edit - 07.07.2024
		try {
			this.id = Id;
			this.code = Code;
			this.description = Description;
		} catch (Exception ex) {
			WB.addLog("Debt.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
	}

	public Debt() throws Exception {
		// origin - 05.12.2023, last edit - 07.07.2024
		try {
		} catch (Exception ex) {
			WB.addLog("Debt.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
	}

	public static double getSegment(LocalDate calcDate, ModelDto filterDto) throws Exception {
		// origin - 11.01.2024, last edit - 27.06.2024
		double res = 0.0;
		try {
			res = Workbook.getChronoMeterValueDouble(calcDate, ModelDto.getSubset(WB.abcGlobal.basic, filterDto));
		} catch (Exception ex) {
			WB.addLog("Debt.getSegment, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("Debt.getSegment, res=" + res + ", calcDate=" + calcDate + ", filterDto=" + filterDto, WB.strEmpty,
//				"DateCalendar");
		return res;
	}

	public static double getSumTax(LocalDate currDate, double sumBaseTax, String codeTax) throws Exception {
		// origin - 10.10.2023, last edit - 03.07.2024
		double res = 0.0;
		try {
			double rateTax = getRateTax(currDate, codeTax);
			res = sumBaseTax * (Etc.ratio100(rateTax)); // only net sum Tax, less baseTax
			res = Etc.roundTax(res, codeTax);
		} catch (Exception ex) {
			WB.addLog("Debt.getSumTax, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static ModelDto getSegmentByCode(String code) throws Exception {
		// origin - 12.01.2024, last edit - 03.07.2024
		ModelDto res = new ModelDto();
		try {
			for (var currSegment : WB.abcGlobal.debt) {
				if (currSegment.code == code) {// TODO --- ??? contains code ???
					res = currSegment;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Debt.getSegmentByCode, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getSegmentByCode, res=" + res + ", code=" + code,
		// WB.strEmpty,
		// "Debt");
		return res;
	}

	public static double getRateTax(LocalDate currDate, String codeTax) throws Exception {
		// origin - 15.01.2024, last edit - 03.07.2024
		double res = 0.0;
		try {
			res = getSegment(currDate, getSegmentByCode(codeTax));
		} catch (Exception ex) {
			WB.addLog("Debt.getRateTax, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static double minusInnerTax(LocalDate currDate, double sumWithTax, String codeTax) throws Exception {
		// origin - 08.10.2023, last edit - 03.07.2024
		double res = 0.0;
		try {
			res = sumWithTax - getInnerTax(currDate, sumWithTax, codeTax);
			res = Etc.roundTax(res, codeTax);
		} catch (Exception ex) {
			WB.addLog("Debt.minusInnerTax, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static double addOutsideTax(LocalDate currDate, double sumLessTax, String codeTax) throws Exception {
		// origin - 02.10.2023, last edit - 03.07.2024
		double res = 0.0;
		try {
			res = sumLessTax + getSumTax(currDate, sumLessTax, codeTax);
		} catch (Exception ex) {
			WB.addLog("Debt.addOutsideTax, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static double getInnerTax(LocalDate currDate, double sumWithVAT, String codeTax) throws Exception {
		// origin - 02.10.2023, last edit - 03.07.2024
		double res = 0.0;
		try {
			double rateTax = getRateTax(currDate, codeTax);
			res = (sumWithVAT * rateTax) / (100.0 + rateTax);
			res = Etc.roundTax(res, codeTax);
		} catch (Exception ex) {
			WB.addLog("Debt.getInnerTax, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 06.07.2024
		try {
			double[] testArgLessTax = new double[] { 100.0, 567.43, 0.00, 323.56452 };
			double[] testArgWithTax = new double[] { 112.0, 567.68, 0.00, 342.8456 };
			double testRateTax = getRateTax(DateTool.getNow(), rateBasicVAT);

			// getSegment
			for (ModelDto testArg2 : WB.abcGlobal.debt) {
				for (LocalDate testArg1 : new LocalDate[] { DateTool.getNow().minusYears(1), DateTool.getNow() }) {
					WB.addLog2("Debt.test.getSegment, res=" + getSegment(testArg1, testArg2) + ", testArg1=" + testArg1
							+ ", testArg2=" + testArg2, WB.strEmpty, "Debt");
				}
			}

			// getSumTax
			for (double testArg1 : testArgLessTax) {
				WB.addLog2("Debt.test.getSumTax, res=" + getSumTax(DateTool.getNow(), testArg1, rateBasicVAT)
						+ ", baseTax=" + testArg1 + ", RateTax=" + testRateTax, WB.strEmpty, "Debt");
			}

			// minusInnerTax
			for (double testArg1 : testArgWithTax) {
				WB.addLog2("Debt.test.subtractInnerTax, res=" + minusInnerTax(DateTool.getNow(), testArg1, rateBasicVAT)
						+ ", sumWithTax=" + testArg1 + ", rateTax=" + testRateTax, WB.strEmpty, "Debt");
			}

			// addOutsideTax
			for (double testArg1 : testArgLessTax) {
				WB.addLog2("Debt.test.addOutsideTax, res=" + addOutsideTax(DateTool.getNow(), testArg1, rateBasicVAT)
						+ ", sumLessTax=" + testArg1 + ", rateTax=" + testRateTax, WB.strEmpty, "Debt");
			}

			// getInnerTax
			for (double testArg1 : testArgWithTax) {
				WB.addLog2("Debt.test.getInnerTax, res=" + getInnerTax(DateTool.getNow(), testArg1, rateBasicVAT)
						+ ", sumWithTax=" + testArg1 + ", rateTax=" + testRateTax, WB.strEmpty, "Debt");
			}
		} catch (Exception ex) {
			WB.addLog("Debt.test, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Debt.test end ", WB.strEmpty, "Debt");
	}
}
