import java.time.LocalDate;

public class Debt extends Model {
	// origin - 28.09.2023, last edit - 24.01.2024
	public static Debt root;
	public Debt parent;
	public Geo geo;
	public Role role;
	public Info info;
	//public static List<ModelDto> segment = new ArrayList<ModelDto>();
	public static String rateBasicVAT;

	static {
		root = new Debt("Debt", "Debt", "DebtData");
		rateBasicVAT = "Debt.VAT.Sell.RateBasic";
	}

	public Debt(String Id, String Code, String Description) {
		// origin - 05.12.2023, last edit - 05.12.2023
		this.id = Id;
		this.code = Code;
		this.description = Description;
	}

	public Debt() {
		// origin - 05.12.2023, last edit - 05.12.2023
	}

	public static double getSegment(LocalDate calcDate, ModelDto filterDto) {
		// origin - 11.01.2024, last edit - 22.01.2024
		double res = 0.0;
		try {
			res = Workbook.getChronoMeterValueDouble(calcDate, ModelDto.getSubset(WB.abcGlobal.basic, filterDto));
		} catch (Exception ex) {
			WB.addLog("Debt.getSegment, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace() + ", res=" + res,
					"", "Debt");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("Debt.getSegment, res=" + res + ", calcDate=" + calcDate + ", filterDto=" + filterDto, "",
//				"DateCalendar");
		return res;
	}

	public static double getSumTax(LocalDate currDate, double sumBaseTax, String codeTax) {
		// origin - 10.10.2023, last edit - 21.01.2024
		double res = 0.0;
		double rateTax = getRateTax(currDate, codeTax);
		res = sumBaseTax * (Etc.ratio100(rateTax)); // only net sum Tax, less baseTax
		res = Etc.roundTax(res, codeTax);
		return res;
	}

	public static ModelDto getSegmentByCode(String code) {
		// origin - 12.01.2024, last edit - 22.01.2024
		ModelDto res = new ModelDto();
		for (var currSegment : Abc.segmentDebt) {
			if (currSegment.code == code) {// TODO --- ??? contains code ???
				res = currSegment;
				break;
			}
		}
		// WB.addLog2("ModelDto.getSegmentByCode, res=" + res + ", code=" + code, "",
		// "Debt");
		return res;
	}

	public static double getRateTax(LocalDate currDate, String codeTax) {
		// origin - 15.01.2024, last edit - 22.01.2024
		double res = 0.0;
		res = getSegment(currDate, getSegmentByCode(codeTax));
		return res;
	}

	public static double minusInnerTax(LocalDate currDate, double sumWithTax, String codeTax) {
		// origin - 08.10.2023, last edit - 21.01.2024
		double res = 0.0;
		res = sumWithTax - getInnerTax(currDate, sumWithTax, codeTax);
		res = Etc.roundTax(res, codeTax);
		return res;
	}

	public static double addOutsideTax(LocalDate currDate, double sumLessTax, String codeTax) {
		// origin - 02.10.2023, last edit - 21.01.2024
		double res = 0.0;
		res = sumLessTax + getSumTax(currDate, sumLessTax, codeTax);
		return res;
	}

	public static double getInnerTax(LocalDate currDate, double sumWithVAT, String codeTax) {
		// origin - 02.10.2023, last edit - 21.01.2024
		double res = 0.0;
		double rateTax = getRateTax(currDate, codeTax);
		res = (sumWithVAT * rateTax) / (100.0 + rateTax);
		res = Etc.roundTax(res, codeTax);
		return res;
	}

	public static void test() {
		// origin - 28.10.2023, last edit - 23.01.2024
		double[] testArgLessTax = new double[] { 100.0, 567.43, 0.00, 323.56452 };
		double[] testArgWithTax = new double[] { 112.0, 567.68, 0.00, 342.8456 };
		double testRateTax = getRateTax(LocalDate.now(), rateBasicVAT);

		// getSegment
		for (ModelDto testArg2 : Abc.segmentDebt) {
			for (LocalDate testArg1 : new LocalDate[] { LocalDate.now().minusYears(1), LocalDate.now() }) {
				WB.addLog2("Debt.test.getSegment, res=" + getSegment(testArg1, testArg2) + ", testArg1=" + testArg1
						+ ", testArg2=" + testArg2, "", "Debt");
			}
		}

		// getSumTax
		for (double testArg1 : testArgLessTax) {
			WB.addLog2("Debt.test.getSumTax, res=" + getSumTax(LocalDate.now(), testArg1, rateBasicVAT) + ", baseTax="
					+ testArg1 + ", RateTax=" + testRateTax, "", "Debt");
		}

		// minusInnerTax
		for (double testArg1 : testArgWithTax) {
			WB.addLog2("Debt.test.subtractInnerTax, res=" + minusInnerTax(LocalDate.now(), testArg1, rateBasicVAT)
					+ ", sumWithTax=" + testArg1 + ", rateTax=" + testRateTax, "", "Debt");
		}

		// addOutsideTax
		for (double testArg1 : testArgLessTax) {
			WB.addLog2("Debt.test.addOutsideTax, res=" + addOutsideTax(LocalDate.now(), testArg1, rateBasicVAT)
					+ ", sumLessTax=" + testArg1 + ", rateTax=" + testRateTax, "", "Debt");
		}

		// getInnerTax
		for (double testArg1 : testArgWithTax) {
			WB.addLog2("Debt.test.getInnerTax, res=" + getInnerTax(LocalDate.now(), testArg1, rateBasicVAT)
					+ ", sumWithTax=" + testArg1 + ", rateTax=" + testRateTax, "", "Debt");
		}
	}
}
