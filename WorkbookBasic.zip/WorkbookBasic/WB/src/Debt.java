import java.time.LocalDate;

public class Debt extends ModelDto {
	// origin - 28.09.2023, last edit - 16.09.2024
	public static String rateBasicVAT;

	static {
		try {
			Debt.rateBasicVAT = "Debt.VAT.Sell.RateBasic";
		} catch (Exception ex) {
			WB.addLog("Debt.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
	}

	public Debt(String Id, String Code, String Description) throws Exception {
		// origin - 05.12.2023, last edit - 11.08.2024
		super(Id, Code, Description);
		this.table = this.getClass().getName();
	}

	public Debt() throws Exception {
		// origin - 05.12.2023, last edit - 11.08.2024
		super();
		this.table = this.getClass().getName();
	}

	public static double getSegment(LocalDate calcDate, ModelDto filterDto) throws Exception {
		// origin - 11.01.2024, last edit - 05.10.2024
		double res = 0.0;
		try {
			res = ReadSet.getChrono(calcDate, ReadSet.get(WB.abcGlobal.basic, filterDto));
		} catch (Exception ex) {
			WB.addLog("Debt.getSegment, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("Debt.getSegment, res=" + res + ", calcDate=" + calcDate + ", filterDto=" + filterDto, WB.strEmpty,
//				"Debt");
		return res;
	}

	public static double getSumTax(LocalDate currDate, double sumBaseTax, String codeTax) throws Exception {
		// origin - 10.10.2023, last edit - 16.09.2024
		double res = 0.0;
		try {
			double rateTax = Debt.getRateTax(currDate, codeTax);
			res = sumBaseTax * (Etc.ratio100(rateTax)); // only net sum Tax, less baseTax
			res = Etc.roundTax(res, codeTax);
		} catch (Exception ex) {
			WB.addLog("Debt.getSumTax, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static ModelDto getSegmentByCode(String code) throws Exception {
		// origin - 12.01.2024, last edit - 19.09.2024
		ModelDto res = new ModelDto();
		try {
			for (var currSegment : WB.abcGlobal.debt) {
				if (Etc.strEquals(currSegment.code, code)) {
					res = currSegment;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Debt.getSegmentByCode, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Debt.getSegmentByCode, res=" + res + ", code=" + code,
		// WB.strEmpty, "Debt");
		return res;
	}

	public static double getRateTax(LocalDate currDate, String codeTax) throws Exception {
		// origin - 15.01.2024, last edit - 12.08.2024
		double res = 0.0;
		try {
			res = Debt.getSegment(currDate, Debt.getSegmentByCode(codeTax));
		} catch (Exception ex) {
			WB.addLog("Debt.getRateTax, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static double minusInnerTax(LocalDate currDate, double sumWithTax, String codeTax) throws Exception {
		// origin - 08.10.2023, last edit - 16.09.2024
		double res = 0.0;
		try {
			res = sumWithTax - Debt.getInnerTax(currDate, sumWithTax, codeTax);
			res = Etc.roundTax(res, codeTax);
		} catch (Exception ex) {
			WB.addLog("Debt.minusInnerTax, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static double addOutsideTax(LocalDate currDate, double sumLessTax, String codeTax) throws Exception {
		// origin - 02.10.2023, last edit - 16.09.2024
		double res = 0.0;
		try {
			res = sumLessTax + Debt.getSumTax(currDate, sumLessTax, codeTax);
		} catch (Exception ex) {
			WB.addLog("Debt.addOutsideTax, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static double getInnerTax(LocalDate currDate, double sumWithVAT, String codeTax) throws Exception {
		// origin - 02.10.2023, last edit - 16.09.2024
		double res = 0.0;
		try {
			double rateTax = Debt.getRateTax(currDate, codeTax);
			res = (sumWithVAT * rateTax) / (100.0 + rateTax);
			res = Etc.roundTax(res, codeTax);
		} catch (Exception ex) {
			WB.addLog("Debt.getInnerTax, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

//	public String toString() {
//		// origin - 27.09.2024, last edit - 28.09.2024
//		String res = WB.strEmpty;
//		try {
//			res = this.code + WB.strSpace + this.description;
//		} catch (Exception ex) {
//			// WB.addLog("Debt.toString, ex=" + ex.getMessage(), WB.strEmpty,
//			// "Debt");
//		} finally {
//			Etc.doNothing();
//		}
//		return res;
//	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 16.09.2024
		try {
			double[] testArgLessTax = new double[] { 100.0, 567.43, 0.00, 323.56452 };
			double[] testArgWithTax = new double[] { 112.0, 567.68, 0.00, 342.8456 };
			double testRateTax = Debt.getRateTax(DateTool.getNow(), Debt.rateBasicVAT);

			// getSegment
			for (ModelDto testArg2 : WB.abcGlobal.debt) {
				for (LocalDate testArg1 : new LocalDate[] { DateTool.getNow().minusYears(1), DateTool.getNow() }) {
					WB.addLog2("Debt.test.getSegment, res=" + Debt.getSegment(testArg1, testArg2) + ", testArg1="
							+ testArg1 + ", testArg2=" + testArg2, WB.strEmpty, "Debt");
				}
			}

			// getSumTax
			for (double testArg1 : testArgLessTax) {
				WB.addLog2("Debt.test.getSumTax, res=" + Debt.getSumTax(DateTool.getNow(), testArg1, Debt.rateBasicVAT)
						+ ", baseTax=" + testArg1 + ", RateTax=" + testRateTax, WB.strEmpty, "Debt");
			}

			// minusInnerTax
			for (double testArg1 : testArgWithTax) {
				WB.addLog2("Debt.test.subtractInnerTax, res="
						+ Debt.minusInnerTax(DateTool.getNow(), testArg1, Debt.rateBasicVAT) + ", sumWithTax="
						+ testArg1 + ", rateTax=" + testRateTax, WB.strEmpty, "Debt");
			}

			// addOutsideTax
			for (double testArg1 : testArgLessTax) {
				WB.addLog2("Debt.test.addOutsideTax, res="
						+ Debt.addOutsideTax(DateTool.getNow(), testArg1, Debt.rateBasicVAT) + ", sumLessTax="
						+ testArg1 + ", rateTax=" + testRateTax, WB.strEmpty, "Debt");
			}

			// getInnerTax
			for (double testArg1 : testArgWithTax) {
				WB.addLog2(
						"Debt.test.getInnerTax, res=" + Debt.getInnerTax(DateTool.getNow(), testArg1, Debt.rateBasicVAT)
								+ ", sumWithTax=" + testArg1 + ", rateTax=" + testRateTax,
						WB.strEmpty, "Debt");
			}
		} catch (Exception ex) {
			WB.addLog("Debt.test, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Debt.test end ", WB.strEmpty, "Debt");
	}
}
