import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unused")
public class Debt extends ModelDto {
	// origin - 28.09.2023, last edit - 06.03.2025
	public static String rateBasic, minRate, minSalary, contextSalaryTaxQazaqstan;
	public static String[] codePatternSalaryTaxQazaqstan;

	static {
		try {
			Debt.minRate = "Debt.MinRate";
			Debt.minSalary = "Debt.MinSalary";
			Debt.rateBasic = "RateBasic";
			Debt.codePatternSalaryTaxQazaqstan = new String[] { "SN", "GFSS", "IncomePerson", "OPVR", "OPV", "OSMS" };
			Debt.contextSalaryTaxQazaqstan = "SalaryTaxQazaqstan";
		} catch (Exception ex) {
			WB.addLog("Debt.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		}
	}

	public static UnitVal addOutside(String date1, UnitVal sumLess, String code) throws Exception {
		// origin - 28.01.2025, last edit - 06.03.2025
		UnitVal res = new UnitVal();
		double res1 = 0.0;
		try {
			res1 = sumLess.val + Debt.getByBase(date1, code, sumLess).val;
			res1 = Etc.roundDebt(res1, WB.strEmpty);
			res = new UnitVal(res1, sumLess.partUnit);
		} catch (Exception ex) {
			WB.addLog("Debt.addOutside, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		}
		return res;
	}

	public static UnitVal convToCurrUnit(String date1, UnitVal inUnitVal) throws Exception {// ex. in=5 Unit.MinSalary
		// origin - 27.01.2025, last edit - 06.03.2025
		UnitVal res = inUnitVal;// new UnitVal();
		double res1 = 0.0;
		String codePatternInUnit = WB.strEmpty;
		codePatternInUnit = inUnitVal.unit.code;
		codePatternInUnit = Etc.delStr(codePatternInUnit, "Unit.");
		try {
			if (Etc.strEquals(inUnitVal.unit.code, Unit.currCurrency.code) == false) {
				UnitVal rate = Debt.getChronoVal(date1, codePatternInUnit);// ex. rate = 85000 Unit.KZT (=Unit.currUnit)
				if (Etc.strEquals(rate.unit.code, Unit.currCurrency.code)) {
					res1 = inUnitVal.val * rate.val; // ex. res1 = 5 Unit.MinSalary * 85000 Unit.KZT (=Unit.currUnit)
					res1 = Etc.roundDebt(res1, WB.strEmpty);
					res = new UnitVal(res1, rate.partUnit); // ex. res = 425000 Unit.KZT (5 * 85000)
				}
			}
		} catch (Exception ex) {
			WB.addLog("Debt.convToCurrUnit, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		}
		return res;
	}

	public static UnitVal minusInside(String date1, UnitVal sumWith, String code) throws Exception {
		// origin - 27.01.2027, last edit - 06.03.2025
		UnitVal res = new UnitVal();
		double res1 = 0.0;
		try {
			res1 = sumWith.val - Debt.getInside(date1, sumWith, code).val;
			res1 = Etc.roundDebt(res1, WB.strEmpty);
			res = new UnitVal(res1, sumWith.partUnit);
		} catch (Exception ex) {
			WB.addLog("Debt.minusInside, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		}
		return res;
	}

	public static UnitVal getInside(String date1, UnitVal sumWith, String code) throws Exception {// ex. tax, VAT, etc.
		// origin - 02.10.2023, last edit - 06.03.2025
		UnitVal res = new UnitVal();
		double res1 = 0.0;
		try {
			UnitVal rate = Debt.getChronoVal(date1, code);
			res1 = (sumWith.val * rate.val) / (100.0 + rate.val);
			res1 = Etc.roundDebt(res1, WB.strEmpty);
			res = new UnitVal(res1, sumWith.partUnit);
		} catch (Exception ex) {
			WB.addLog("Debt.getInside, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		}
		return res;
	}

	public static List<ModelDto> build(String codePattern) throws Exception { // TODO
		// origin - 23.01.2025, last edit - 06.03.2025
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Debt dbt = new Debt();
			dbt.clear();
			// dbt.src = dbt.id = dbt.code = Id;
			dbt.isExist();
			dbt.isValid();
			dbt.fix();
			res.add(dbt);
		} catch (Exception ex) {
			WB.addLog("Debt.build, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Debt");
		}
		return res;
	}

	public static String getCodePattern(String strDebt) throws Exception {
		// origin - 21.01.2025, last edit - 06.03.2025
		String res = WB.strEmpty;
		strDebt = Etc.fixTrim(strDebt);
		String strRate = WB.strEmpty;
		try {
			res = Debt.getCodePattern(strDebt, strRate);
		} catch (Exception ex) {
			WB.addLog("Debt.getCodePattern(string), ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		}
		return res;
	}

	private static String getCodePattern(String strDebt, String strRate) throws Exception {
		// origin - 20.01.2025, last edit - 06.03.2025
		String res = WB.strEmpty;
		strDebt = Etc.fixTrim(strDebt);
		strRate = Etc.fixTrim(strRate);
		try {
			if (strRate.isEmpty()) {
				strRate = Debt.rateBasic; // default
			}
			res = res + Etc.fixTrim(strDebt) + WB.strDot + Etc.fixTrim(strRate);
		} catch (Exception ex) {
			WB.addLog("Debt.getCodePattern(string,string), ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		}
		return res;
	}

	private static String getContext(String date1, String codeRate) throws Exception {
		// origin - 22.01.2025, last edit - 06.03.2025
		String res = WB.strEmpty;
		try {
			if (codeRate.isEmpty() == false) {
				for (var tmp : Debt.codePatternSalaryTaxQazaqstan) {
					if (Etc.strContains(codeRate, tmp)) { // no cents
						res = Debt.contextSalaryTaxQazaqstan;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Debt.getContext, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		}
		return res;
	}

	public static UnitVal getByBase(String date1, UnitVal rate, UnitVal base) throws Exception { // ex. accrual pawndoc
		// origin - 26.01.2025, last edit - 06.03.2025
		UnitVal res = new UnitVal();
		double tmp = 0.0;
		try {
			tmp = base.val * Etc.ratio100(rate.val);
			tmp = Etc.roundDebt(tmp, WB.strEmpty);
			res = new UnitVal(tmp, base.unit.id);
		} catch (Exception ex) {
			WB.addLog("Debt.getByBase(UnitVal rate), ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		}
		return res;
	}

	public static UnitVal getByBase(String date1, String codeRate, UnitVal base) throws Exception {
		// origin - 15.01.2025, last edit - 06.03.2025
		UnitVal res = new UnitVal();
		double tmp = 0.0;
		try {
			double rate = Debt.getChronoVal(date1, codeRate).val; // ex. tax sell, tax salary, etc.
			tmp = base.val * Etc.ratio100(rate);
			String context = Debt.getContext(date1, codeRate);
			tmp = Etc.roundDebt(tmp, context);// WB.strEmpty);
			res = new UnitVal(tmp, base.unit.id);
		} catch (Exception ex) {
			WB.addLog("Debt.getByBase(String codeRate), ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		}
		return res;
	}

//	public void getBySpan() throws Exception { // TODO
//		// origin - 16.01.2025, last edit - 20.01.2025
//		// get sum from date1,2, span time
//		double res = 0.0;
//		try {
//			double rateTax = this.rate.val;
//			res = this.base.val * Etc.ratio100(rateTax); // only net sum, less base
//			res = Etc.roundDebt(res, WB.strEmpty);
////			WB.addLog2("Debt.getBySpan, res=" + res + ", this.base=" + this.base.id + ", this.rate=" + this.rate.id,
////					WB.strEmpty, "Debt");
//			this.sumGeneral = new UnitVal(res, Unit.currUnit.id);
//		} catch (Exception ex) {
//			WB.addLog("Debt.getBySpan, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
//		} finally {
//			Etc.doNothing();
//		}
////		WB.addLog2("Debt.getBySpan, this.sumGeneral=" + this.sumGeneral.id + ", this.base=" + this.base.id
////				+ ", this.rate=" + this.rate.id, WB.strEmpty, "Debt");
//	}

	public void isExist() throws Exception {
		// origin - 16.12.2024, last edit - 06.03.2025
		super.isExist();
		try {
			var commonDebt = new ArrayList<ModelDto>();
			commonDebt.addAll(WB.abcLast.debt);
			commonDebt.addAll(WB.abcGlobal.debt);
			for (var currDebt : commonDebt) {
				if (Etc.strEquals(currDebt.id, this.id)) {
					this.slice = DefVal.setCustom(this.slice, currDebt.slice);
					this.date1 = DefVal.setCustom(DateTool.getNow().toString(), currDebt.date1);// this.date1,
					this.date2 = DefVal.setCustom(this.date2, currDebt.date2);
					this.code = DefVal.setCustom(this.code, currDebt.code);
					this.parent = DefVal.setCustom(this.parent, currDebt.parent);
					this.description = DefVal.setCustom(this.description, currDebt.description);
					this.geo = DefVal.setCustom(this.geo, currDebt.geo);
					this.role = DefVal.setCustom(this.role, currDebt.role);
					this.info = DefVal.setCustom(this.info, currDebt.info);
					this.more = DefVal.setCustom(this.more, currDebt.more);

					this.isExist = true;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Debt.isExist, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		}
	}

	public void isValid() throws Exception {
		// origin - 16.12.2024, last edit - 06.03.2025
		super.isValid();
		try {
			if (this.date1.isEmpty() | this.geo.isEmpty() | this.role.isEmpty() | this.info.isEmpty()) {
				this.isValid = false;
			}
		} catch (Exception ex) {
			WB.addLog("Debt.isValid, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		}
	}

	public Debt(String Id) throws Exception {
		// origin - 05.12.2023, last edit - 27.12.2024
		this();
		this.src = Id;
		if (Id.isEmpty() == false) {
			this.id = this.code = Id;
		}
		// this.date1 = DateTool.getNow().toString();
		this.isExist();
		this.isValid();
		this.upper = super.getUpper(WB.abcLast.debt);
		this.lower = super.getLower(WB.abcLast.debt);
	}

	public Debt() throws Exception {
		// origin - 05.12.2023, last edit - 16.12.2024
		this.clear();
		this.isExist();
		var root = Abc.getRoot(this.table);
		this.id = root.id;
		this.parent = root.parent;
		this.date1 = root.date1;
		this.date2 = root.date2;
		this.code = root.code;
		this.description = root.description;
		this.geo = root.geo;
		this.role = root.role;
		this.info = root.info;
		this.more = root.more;
	}

	public static UnitVal getChronoVal(String date1, String code) throws Exception {
		// origin - 15.01.2024, last edit - 06.03.2025
		UnitVal res = new UnitVal();
		try {
			var listDto = ReadSet.getContainsByCode(WB.abcGlobal.debt, code);
			var dto = ReadSet.getChrono(DateTool.getLocalDate(date1), listDto);
			res = new UnitVal(Etc.fixTrim(dto.meterValue), Etc.fixTrim(dto.unit));
		} catch (Exception ex) {
			WB.addLog("Debt.getChronoVal, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		}
		return res;
	}

	public void clear() throws Exception {
		// origin - 17.12.2024, last edit - 06.03.2025
		try {
			super.clear();
			this.table = this.getClass().getName();
			// this.base = this.rate = this.sumGeneral = this.sumWith = this.sumLess =
			// this.sumInner = new UnitVal();
		} catch (Exception ex) {
			WB.addLog("Debt.clear, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		}
	}

	public String toString() {
		// origin - 25.11.2024, last edit - 06.03.2025
		String res = WB.strEmpty;
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", ", this.slice);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", meterValue ", this.meterValue);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());

			res = res + Fmtr.addIfNotEmpty(", upper.size ", this.upper.size());
			res = res + Fmtr.addIfNotEmpty(", lower.size ", this.lower.size());

			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 06.03.2025
		try {

//			// addOutside
//			for (var addOutsideArg1 : new String[] { "2025-01-03" }) {
//				for (var addOutsideArg2 : new String[] { "100.0(Unit.KZT)", "567.43(Unit.KZT)", "0.00(Unit.KZT)",
//						"323.56452(Unit.KZT)" }) {
//					for (var addOutsideArg3 : new String[] { Debt.getCodePattern("VAT.Sell") }) {
//						WB.addLog2(
//								"Debt.test.addOutside, res="
//										+ Debt.addOutside(addOutsideArg1, new UnitVal(addOutsideArg2), addOutsideArg3).id
//										+ ", sumLess=" + addOutsideArg2 + ", rate=" + addOutsideArg3,
//								WB.strEmpty, "Debt");
//					}
//				}
//			}

//			// convToCurrUnit
//			for (var convToCurrUnitArg1 : new String[] { "2023-02-04", "2024-05-06", "2025-01-03" }) {
//				for (var convToCurrUnitArg2 : new String[] { "45.0(Unit.MinRate)", "5.0(Unit.KZT)",
//						"2.56(Unit.MinSalary)" }) {
//					WB.addLog2(
//							"Debt.test.convToCurrUnit, res="
//									+ Debt.convToCurrUnit(convToCurrUnitArg1, new UnitVal(convToCurrUnitArg2)).id
//									+ ", date1=" + convToCurrUnitArg1 + ", inUnitVal=" + convToCurrUnitArg2,
//							WB.strEmpty, "Debt");
//				}
//			}

//			// minusInside
//			for (var minusInsideArg1 : new String[] { "2025-01-03" }) {
//				for (var minusInsideArg2 : new String[] { "112.0(Unit.KZT)", "567.68(Unit.KZT)", "0.00(Unit.KZT)",
//						"342.8456(Unit.KZT)" }) {
//					for (var minusInsideArg3 : new String[] { Debt.getCodePattern("VAT.Sell") }) {
//						WB.addLog2("Debt.test.minusInside, res="
//								+ Debt.minusInside(minusInsideArg1, new UnitVal(minusInsideArg2), minusInsideArg3).id
//								+ ", date1=" + minusInsideArg1 + ", sumWith=" + minusInsideArg2 + ", rate="
//								+ minusInsideArg3, WB.strEmpty, "Debt");
//					}
//				}
//			}

//			// getInside
//			for (var getInsideArg1 : new String[] { "2025-01-03" }) {
//				for (var getInsideArg2 : new String[] { "112.0(Unit.KZT)", "567.68(Unit.KZT)", "0.00(Unit.KZT)",
//						"342.8456(Unit.KZT)" }) {
//					for (var getInsideArg3 : new String[] { Debt.getCodePattern("VAT.Sell") }) {
//						WB.addLog2("Debt.test.getInside, res="
//								+ Debt.getInside(getInsideArg1, new UnitVal(getInsideArg2), getInsideArg3).id
//								+ ", date1=" + getInsideArg1 + ", sumWith=" + getInsideArg2 + ", rate=" + getInsideArg3,
//								WB.strEmpty, "Debt");
//					}
//				}
//			}

//			// getByBase (context pawndoc)
//			for (var getByBaseArg1 : new String[] { "2025-01-03" }) {
//				for (var getByBaseArg2 : new String[] { "PawnDoc.Template1.V1.Term1", "PawnDoc.Template1.V1.Term2" }) {
//					for (var getByBaseArg3 : new String[] { "12347.0(Unit.KZT)", "6733.0(Unit.KZT)" }) {
//						var term = new Term(getByBaseArg2);
//						var pawnDocRate = new Accrual(Accrual.getCodePattern(term.parent, Accrual.strAccrual),
//								Term.getCodePattern(getByBaseArg2, Accrual.strAccrual)).interestRate;
//						WB.addLog2("Debt.test.getByBase (context pawndoc), res="
//								+ Debt.getByBase(getByBaseArg1, pawnDocRate, new UnitVal(getByBaseArg3)).id + ", date1="
//								+ getByBaseArg1 + ", pawnDocRate=" + pawnDocRate.id + ", base=" + getByBaseArg3,
//								WB.strEmpty, "Debt");
//					}
//				}
//			}

//			// getByBase (context tax)
//			for (var getByBaseArg1 : new String[] { "2023-02-04", "2024-05-06", "2025-01-03" }) {
//				for (var getByBaseArg2 : new String[] { Debt.getCodePattern("SN"), Debt.getCodePattern("GFSS"),
//						Debt.getCodePattern("VAT.Sell"), Debt.getCodePattern("OPVR"),
//						Debt.getCodePattern("OSMS.EmployeePay"), Debt.getCodePattern("OSMS.EmployeeFee"),
//						Debt.getCodePattern("Pension.OPV"), Debt.getCodePattern("IncomePerson") }) {
//					for (var getByBaseArg3 : new String[] { "12346.97(Unit.KZT)", "6734.33(Unit.KZT)" }) {
//						WB.addLog2("Debt.test.getByBase (context tax), res="
//								+ Debt.getByBase(getByBaseArg1, getByBaseArg2, new UnitVal(getByBaseArg3)).id
//								+ ", date1=" + getByBaseArg1 + ", codeRate=" + getByBaseArg2 + ", base="
//								+ getByBaseArg3, WB.strEmpty, "Debt");
//					}
//				}
//			}

//			// getCodePattern
//			for (var getCodePatternArg1 : new String[] { "GFSS", "OPVR", "SN", "VAT.Sell", "OPVR" }) {
//				for (var getCodePatternArg2 : new String[] { "RateBasic", "RateReduce", "Base.MinLimit",
//						"Base.MaxLimit" }) {
//					var tmpGetCodePattern = Debt.getCodePattern(getCodePatternArg1, getCodePatternArg2);
//					WB.addLog2("Debt.test.getCodePattern, res=" + tmpGetCodePattern + ", strDebt=" + getCodePatternArg1
//							+ ", strCode=" + getCodePatternArg2, WB.strEmpty, "Debt");
//					WB.addLog2("Debt.test.getChronoVal after getCodePattern, res="
//							+ Debt.getChronoVal("2025-01-03", tmpGetCodePattern).id + ", date1=" + "2025-01-03"
//							+ ", code=" + tmpGetCodePattern, WB.strEmpty, "Debt");
//				}
//			}

//			// getChronoVal
//			for (var getChronoValArg1 : new String[] { "2023-02-04", "2024-05-06", "2025-01-03" }) {
//				for (var getChronoValArg2 : new String[] { Debt.minRate, Debt.minSalary,
//						Debt.getCodePattern("VAT.Sell"), Debt.getCodePattern("SN"),
//						Debt.getCodePattern("GFSS") }) {
//					WB.addLog2(
//							"Debt.test.getChronoVal, res=" + Debt.getChronoVal(getChronoValArg1, getChronoValArg2)
//									+ ", date1=" + getChronoValArg1 + ", code=" + getChronoValArg2,
//							WB.strEmpty, "Debt");
//				}
//			}

//			// ctor (String Id)
//			for (var ctor1StringArg1 : new String[] { WB.strEmpty, "Debt.GFSS", "Debt.IncomePerson.Base",
//					"Debt.tralala", "Debt.Pension.OPVR.RateBasic2024", "Debt.Pawnshop.Interest" }) {
//				WB.addLog2("Debt.test.ctor(String)=" + new Debt(ctor1StringArg1), WB.strEmpty, "Debt");
//			}

		} catch (Exception ex) {
			WB.addLog("Debt.test, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		}
	}

//	private void getLower() throws Exception {
//	// origin - 18.12.2024, last edit - 06.03.2025
//	var srcList = WB.abcLast.debt;
//	List<ModelDto> tmpLower1 = new ArrayList<ModelDto>();
//	tmpLower1 = ReadSet.getEqualsByParent(srcList, this.code); // direct lower 1 level
//	List<ModelDto> tmpLower2 = new ArrayList<ModelDto>(); // lower 2 level
//	boolean foundNewLowerCode = true;
//
//	try {
//		for (;;) {
//			foundNewLowerCode = false;
//			tmpLower2.clear();
//
//			for (var currL1 : tmpLower1) {
//				tmpLower2.addAll(ReadSet.getEqualsByParent(srcList, currL1.code));
//			}
//
//			for (var currL2 : tmpLower2) {
//				if (ModelDto.isContains(tmpLower1, currL2) == false) {
//					tmpLower1.add(currL2);
////					WB.addLog2("Debt.getLower, add currL2.code=" + currL2.code + ", for this.code=" + this.code,
////							WB.strEmpty, "Debt");
//					foundNewLowerCode = true;
//				}
//			}
//
//			if (foundNewLowerCode == false) {
//				break;
//			}
//		}
//
//		this.lower.addAll(tmpLower1);
//	} catch (Exception ex) {
//		WB.addLog("Debt.getLower, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
//	}
//}

//private void getUpper() throws Exception {
//	// origin - 17.12.2024, last edit - 06.03.2025
//	var srcList = WB.abcLast.debt;
//	String tmpParentCode = this.parent;
//	List<ModelDto> tmpUpper = new ArrayList<ModelDto>();
//	boolean foundNewParentCode = true;
//
//	try {
//		for (;;) {
//			foundNewParentCode = false;
//			for (var currLst : srcList) {
//				if (Etc.strEquals(currLst.code, tmpParentCode)) {
//					if (ModelDto.isContains(tmpUpper, currLst) == false) {
//						tmpUpper.add(currLst);
////						WB.addLog2("Debt.getUpper, add currLst.code=" + currLst.code + ", tmpParentCode="
////								+ tmpParentCode + ", for this.code=" + this.code, WB.strEmpty, "Debt");
//						tmpParentCode = currLst.parent;
//						foundNewParentCode = true;
//						break;
//					}
//				}
//			}
//			if (foundNewParentCode == false) {
//				break;
//			}
//		}
//		this.upper.addAll(tmpUpper);
//	} catch (Exception ex) {
//		WB.addLog("Debt.getUpper, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
//	}
//}
}
