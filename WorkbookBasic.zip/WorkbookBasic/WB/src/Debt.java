import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unused")
public class Debt extends ModelDto {
	// origin - 28.09.2023, last edit - 23.01.2025
	public static String rateBasic, minRate, minSalary, contextSalaryTaxQazaqstan;
	public static String[] codePatternSalaryTaxQazaqstan;
	public UnitVal base, rate, sumGeneral, sumWith, sumLess, sumInner;

	static {
		try {
			Debt.minRate = "Debt.MinRate";
			Debt.minSalary = "Debt.MinSalary";
			Debt.rateBasic = "RateBasic";
			Debt.codePatternSalaryTaxQazaqstan = new String[] { "SN", "GFSS", "IncomePerson", "OPVR", "OPV", "OSMS" };
			Debt.contextSalaryTaxQazaqstan = "SalaryTaxQazaqstan";
		} catch (Exception ex) {
			WB.addLog("Debt.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
	}

	public static List<ModelDto> build(String codePattern) throws Exception { // TODO
		// origin - 23.01.2025, last edit - 23.01.2025
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {

			Debt dbt = new Debt();
			dbt.clear();
			// dbt.src = dbt.id = dbt.code = Id;
			dbt.isExist();
			dbt.isValid();
			dbt.fix();
			res.add(dbt);

		} catch (Exception ex) {
			WB.addLog("Debt.build, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Debt.build, res=" + res + ", codePattern=" + codePattern,
		// WB.strEmpty, "Debt");
		return res;
	}

	public static String getCodeRatePattern(String strDebt) throws Exception {
		// origin - 21.01.2025, last edit - 21.01.2025
		String res = WB.strEmpty;
		strDebt = Etc.fixTrim(strDebt);
		String strRate = WB.strEmpty;
		try {
			res = Debt.getCodeRatePattern(strDebt, strRate);
		} catch (Exception ex) {
			WB.addLog("Debt.getCodeRatePattern(string), ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("Debt.getCodeRatePattern(string), res=" + res + ", strDebt=" + strDebt + ", strRate=" + strRate,
//				WB.strEmpty, "Debt");
		return res;
	}

	private static String getCodeRatePattern(String strDebt, String strRate) throws Exception {
		// origin - 20.01.2025, last edit - 22.01.2025
		String res = WB.strEmpty;
		strDebt = Etc.fixTrim(strDebt);
		strRate = Etc.fixTrim(strRate);
		try {
			if (strRate.isEmpty()) {
				strRate = Debt.rateBasic; // default
			}
//			res = res + "Debt" + WB.strDot + Etc.fixTrim(strDebt) + WB.strDot + Etc.fixTrim(strRate); // ??magic string
//																										// ??
			res = res + Etc.fixTrim(strDebt) + WB.strDot + Etc.fixTrim(strRate);
		} catch (Exception ex) {
			WB.addLog("Debt.getCodeRatePattern(string,string), ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("Debt.getCodeRatePattern(string,string), res=" + res + ", strDebt=" + strDebt + ", strRate=" + strRate,
//				WB.strEmpty, "Debt");
		return res;
	}

	private static String getContext(String date1, String codeRate) throws Exception {
		// origin - 22.01.2025, last edit - 26.01.2025
		String res = WB.strEmpty;
		try {
			if (codeRate.isEmpty() == false) {
				for (var tmp : Debt.codePatternSalaryTaxQazaqstan) {
					if (Etc.strContains(codeRate, tmp)) { // no cents
						res = Debt.contextSalaryTaxQazaqstan;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Debt.getContext, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("Debt.getContext, res=" + res + ", date1=" + date1 + ", codeRate=" + codeRate,
//				WB.strEmpty, "Debt");
		return res;
	}

	public static UnitVal getByBase(String date1, UnitVal rate, UnitVal base) throws Exception { // ex. accrual pawndoc
		// origin - 26.01.2025, last edit - 26.01.2025
		UnitVal res = new UnitVal();
		double tmp = 0.0;
		try {
			tmp = base.val * Etc.ratio100(rate.val);
			tmp = Etc.roundDebt(tmp, WB.strEmpty);
			res = new UnitVal(tmp, base.unit.id);
		} catch (Exception ex) {
			WB.addLog("Debt.getByBase(UnitVal rate), ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("Debt.getByBase(UnitVal rate), res=" + res.id + ", date1=" + date1 + ", base=" + base + ", rate=" + rate.id,
//				WB.strEmpty, "Debt");
		return res;
	}

	public static UnitVal getByBase(String date1, String codeRate, UnitVal base) throws Exception {
		// origin - 15.01.2025, last edit - 26.01.2025
		UnitVal res = new UnitVal();
		double tmp = 0.0;
		try {
			double rate = Debt.getChronoRate(date1, codeRate).val; // ex. tax sell, tax salary, etc.
			tmp = base.val * Etc.ratio100(rate);
			String context = Debt.getContext(date1, codeRate);
			tmp = Etc.roundDebt(tmp, context);// WB.strEmpty);
			res = new UnitVal(tmp, base.unit.id);
		} catch (Exception ex) {
			WB.addLog("Debt.getByBase(String codeRate), ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("Debt.getByBase(String codeRate), res=" + res.id + ", date1=" + date1 + ", base=" + base + ", codeRate=" + codeRate,
//				WB.strEmpty, "Debt");
		return res;
	}

	public void getBySpan() throws Exception { // TODO
		// origin - 16.01.2025, last edit - 20.01.2025
		// get sum from date1,2, span time
		double res = 0.0;
		try {
			double rateTax = this.rate.val;
			res = this.base.val * Etc.ratio100(rateTax); // only net sum, less base
			res = Etc.roundDebt(res, WB.strEmpty);
//			WB.addLog2("Debt.getBySpan, res=" + res + ", this.base=" + this.base.id + ", this.rate=" + this.rate.id,
//					WB.strEmpty, "Debt");
			this.sumGeneral = new UnitVal(res, Unit.currUnit.id);
		} catch (Exception ex) {
			WB.addLog("Debt.getBySpan, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Debt.getBySpan, this.sumGeneral=" + this.sumGeneral.id + ", this.base=" + this.base.id
				+ ", this.rate=" + this.rate.id, WB.strEmpty, "Debt");
	}

	public void isExist() throws Exception {
		// origin - 16.12.2024, last edit - 21.01.2025
		super.isExist();
		try {
			var commonDebt = new ArrayList<ModelDto>();
			commonDebt.addAll(WB.abcLast.debt);
			commonDebt.addAll(WB.abcGlobal.debt);
			for (var currDebt : commonDebt) {
				if (Etc.strEquals(currDebt.id, this.id)) {
					this.slice = DefVal.setCustom(this.slice, currDebt.slice);
					this.date1 = DefVal.setCustom(DateTool.getNow().toString(), currDebt.date1);// this.date1,
					this.date2 = DefVal.setCustom(this.date2, currDebt.date2);
					this.code = DefVal.setCustom(this.code, currDebt.code);
					this.parent = DefVal.setCustom(this.parent, currDebt.parent);
					this.description = DefVal.setCustom(this.description, currDebt.description);
					this.geo = DefVal.setCustom(this.geo, currDebt.geo);
					this.role = DefVal.setCustom(this.role, currDebt.role);
					this.info = DefVal.setCustom(this.info, currDebt.info);
					this.more = DefVal.setCustom(this.more, currDebt.more);

					this.isExist = true;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Debt.isExist, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Debt.isExist=" + this.isExist, WB.strEmpty,"Debt");
	}

	public void isValid() throws Exception {
		// origin - 16.12.2024, last edit - 16.12.2024
		super.isValid();
		try {
			if (this.date1.isEmpty() | this.geo.isEmpty() | this.role.isEmpty() | this.info.isEmpty()) {
				this.isValid = false;
			}
		} catch (Exception ex) {
			WB.addLog("Debt.isValid, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Debt.isValid=" + this.isValid, WB.strEmpty,"Debt");
	}

	public Debt(String Id) throws Exception {
		// origin - 05.12.2023, last edit - 27.12.2024
		this();
		this.src = Id;
		if (Id.isEmpty() == false) {
			this.id = this.code = Id;
		}
		// this.date1 = DateTool.getNow().toString();
		this.isExist();
		this.isValid();
		this.upper = super.getUpper(WB.abcLast.debt);
		this.lower = super.getLower(WB.abcLast.debt);
	}

	public Debt() throws Exception {
		// origin - 05.12.2023, last edit - 16.12.2024
		this.clear();
		this.isExist();
		var root = Abc.getRoot(this.table);
		this.id = root.id;
		this.parent = root.parent;
		this.date1 = root.date1;
		this.date2 = root.date2;
		this.code = root.code;
		this.description = root.description;
		this.geo = root.geo;
		this.role = root.role;
		this.info = root.info;
		this.more = root.more;
	}

	public static UnitVal getChronoRate(String date1, String code) throws Exception {
		// origin - 15.01.2024, last edit - 20.01.2025
		UnitVal res = new UnitVal();
		try {
			// var listDto = ReadSet.getStartsWithByCode(WB.abcGlobal.debt, code);
			var listDto = ReadSet.getContainsByCode(WB.abcGlobal.debt, code);
//			WB.addLog2("Debt.getChronoRate, filterDto.size=" + listDto.size() + ", code=" + code, WB.strEmpty,
//					"Debt");
			var dto = ReadSet.getChrono(DateTool.getLocalDate(date1), listDto);
//			WB.addLog2("Debt.getChronoRate, dto.meterValue=" + dto.meterValue + ", dto.unit=" + dto.unit, WB.strEmpty,
//					"Debt");
			res = new UnitVal(Etc.fixTrim(dto.meterValue), Etc.fixTrim(dto.unit));
		} catch (Exception ex) {
			WB.addLog("Debt.getChronoRate, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("Debt.getChronoRate, res=" + res + ", date1=" + date1 + ", code="
//				+ code, WB.strEmpty, "Debt");
		return res;
	}

	private static double minusInner(LocalDate currDate, double sumWith, String code) throws Exception {// TODO
		// origin - 08.10.2023, last edit - 16.01.2025
		double res = 0.0;
		try {
			res = sumWith - Debt.getInner(currDate, sumWith, code);
			res = Etc.roundDebt(res, WB.strEmpty);
		} catch (Exception ex) {
			WB.addLog("Debt.minusInner, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Debt.minusInner, res=" + res + ", currDate=" + currDate + ", sumWith=" + sumWith + ", code=" + code,
				WB.strEmpty, "Debt");
		return res;
	}

	public void addOutside() throws Exception {
		// origin - 02.10.2023, last edit - 16.01.2025
		double res = 0.0;
		try {
			// res = sumLess + this.getByBase();
		} catch (Exception ex) {
			WB.addLog("Debt.addOutside, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Debt.addOutside, this.sumWith=" + this.sumWith + ", this.sumGeneral=" + this.sumGeneral
				+ ", this.sumLess=" + this.sumLess, WB.strEmpty, "Debt");
		// return res;
	}

	private static double getInner(LocalDate currDate, double sumWith, String code) throws Exception {// TODO
		// origin - 02.10.2023, last edit - 16.01.2025
		double res = 0.0;
		try {
			// double rateTax = Debt.getChronoRate(currDate, code);
			// res = (sumWith * rateTax) / (100.0 + rateTax);
			// res = Etc.roundTax(res, WB.strEmpty);
		} catch (Exception ex) {
			WB.addLog("Debt.getInner, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Debt.getInner, res=" + res + ", currDate=" + currDate + ", sumWith=" + sumWith + ", code=" + code,
				WB.strEmpty, "Debt");
		return res;
	}

	public void clear() throws Exception {
		// origin - 17.12.2024, last edit - 16.01.2025
		try {
			super.clear();
			this.table = this.getClass().getName();
			this.base = this.rate = this.sumGeneral = this.sumWith = this.sumLess = this.sumInner = new UnitVal();
		} catch (Exception ex) {
			WB.addLog("Debt.clear, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
	}

	public String toString() {
		// origin - 25.11.2024, last edit - 16.01.2025
		String res = WB.strEmpty;
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", ", this.slice);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", meterValue ", this.meterValue);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());

			res = res + Fmtr.addIfNotEmpty(", upper.size ", this.upper.size());
			res = res + Fmtr.addIfNotEmpty(", lower.size ", this.lower.size());

			res = res + Fmtr.addIfNotEmpty(", base ", this.base.id);
			res = res + Fmtr.addIfNotEmpty(", rate ", this.rate.id);
			res = res + Fmtr.addIfNotEmpty(", sumGeneral ", this.sumGeneral.id);
			res = res + Fmtr.addIfNotEmpty(", sumWith ", this.sumWith.id);
			res = res + Fmtr.addIfNotEmpty(", sumLess ", this.sumLess.id);
			res = res + Fmtr.addIfNotEmpty(", sumInner ", this.sumInner.id);

			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 26.01.2025
		try {

			// getByBase (context pawndoc)
			for (var getByBaseArg1 : new String[] { "2025-01-03" }) {
				for (var getByBaseArg2 : new String[] { "PawnDoc.Template1.V1.Term1", "PawnDoc.Template1.V1.Term2" }) {
					for (var getByBaseArg3 : new String[] { "12347.0(Unit.KZT)", "6733.0(Unit.KZT)" }) {
						var term = new Term(getByBaseArg2);
						var pawnDocRate = new Accrual(Accrual.getCodePattern(term.parent, Accrual.strAccrual),
								Term.getCodePattern(getByBaseArg2, Accrual.strAccrual)).interestRate;
						WB.addLog2("Debt.test.getByBase (context pawndoc), res="
								+ Debt.getByBase(getByBaseArg1, pawnDocRate, new UnitVal(getByBaseArg3)).id + ", date1="
								+ getByBaseArg1 + ", pawnDocRate=" + pawnDocRate.id + ", base=" + getByBaseArg3,
								WB.strEmpty, "Debt");
					}
				}
			}

			// getByBase (context tax)
			for (var getByBaseArg1 : new String[] { "2023-02-04", "2024-05-06", "2025-01-03" }) {
				for (var getByBaseArg2 : new String[] { Debt.getCodeRatePattern("SN"), Debt.getCodeRatePattern("GFSS"),
						Debt.getCodeRatePattern("VAT.Sell"), Debt.getCodeRatePattern("OPVR"),
						Debt.getCodeRatePattern("OSMS.EmployeePay"), Debt.getCodeRatePattern("OSMS.EmployeeFee"),
						Debt.getCodeRatePattern("Pension.OPV"), Debt.getCodeRatePattern("IncomePerson") }) {
					for (var getByBaseArg3 : new String[] { "12346.97(Unit.KZT)", "6734.33(Unit.KZT)" }) {
						WB.addLog2("Debt.test.getByBase (context tax), res="
								+ Debt.getByBase(getByBaseArg1, getByBaseArg2, new UnitVal(getByBaseArg3)).id
								+ ", date1=" + getByBaseArg1 + ", codeRate=" + getByBaseArg2 + ", base="
								+ getByBaseArg3, WB.strEmpty, "Debt");
					}
				}
			}

//			// getCodeRatePattern
//			for (var getCodeRatePatternArg1 : new String[] { "GFSS", "OPVR", "SN", "VAT.Sell", "OPVR" }) {
//				for (var getCodeRatePatternArg2 : new String[] { WB.strEmpty, "RateBasic", "RateZero" }) {
//					var tmpGetCodeRatePattern = Debt.getCodeRatePattern(getCodeRatePatternArg1, getCodeRatePatternArg2);
//					WB.addLog2(
//							"Debt.test.getCodeRatePattern, res=" + tmpGetCodeRatePattern + ", strDebt="
//									+ getCodeRatePatternArg1 + ", strRate=" + getCodeRatePatternArg2,
//							WB.strEmpty, "Debt");
//					WB.addLog2("Debt.test.getChronoRate after getCodeRatePattern, res="
//							+ Debt.getChronoRate("2025-01-03", tmpGetCodeRatePattern).id + ", date1=" + "2025-01-03"
//							+ ", code=" + tmpGetCodeRatePattern, WB.strEmpty, "Debt");
//				}
//			}

//			// getChronoRate
//			for (var getChronoRateArg1 : new String[] { "2023-02-04", "2024-05-06", "2025-01-03" }) {
//				for (var getChronoRateArg2 : new String[] { Debt.minRate, Debt.minSalary,
//						Debt.getCodeRatePattern("VAT.Sell"), Debt.getCodeRatePattern("SN"),
//						Debt.getCodeRatePattern("GFSS") }) {
//					WB.addLog2(
//							"Debt.test.getChronoRate, res=" + Debt.getChronoRate(getChronoRateArg1, getChronoRateArg2)
//									+ ", date1=" + getChronoRateArg1 + ", code=" + getChronoRateArg2,
//							WB.strEmpty, "Debt");
//				}
//			}

//			// ctor (String Id)
//			for (var ctor1StringArg1 : new String[] { WB.strEmpty, "Debt.GFSS", "Debt.IncomePerson.Base",
//					"Debt.tralala", "Debt.Pension.OPVR.RateBasic2024", "Debt.Pawnshop.Interest" }) {
//				WB.addLog2("Debt.test.ctor(String)=" + new Debt(ctor1StringArg1), WB.strEmpty, "Debt");
//			}

//			// minusInner
//			for (double testArg1 : new double[] { 112.0, 567.68, 0.00, 342.8456 }) {
//				WB.addLog2("Debt.test.subtractInner, res="
//						+ Debt.minusInner(DateTool.getNow(), testArg1, Debt.rateBasicVAT) + ", sumWith=" + testArg1
//						+ ", rate=" + testRateTax, WB.strEmpty, "Debt");
//			}

			// addOutside
//			for (double testArg1 : new double[] { 100.0, 567.43, 0.00, 323.56452 }) {
//				WB.addLog2(
//						"Debt.test.addOutside, res=" + Debt.addOutside(DateTool.getNow(), testArg1, Debt.rateBasicVAT)
//								+ ", sumLess=" + testArg1 + ", rate=" + testRateTax,
//						WB.strEmpty, "Debt");
//			}

//			// getInner
//			for (double testArg1 : new double[] { 112.0, 567.68, 0.00, 342.8456 }) {
//				WB.addLog2("Debt.test.getInner, res=" + Debt.getInner(DateTool.getNow(), testArg1, Debt.rateBasicVAT)
//						+ ", sumWith=" + testArg1 + ", rate=" + testRateTax, WB.strEmpty, "Debt");
//			}
		} catch (

		Exception ex) {
			WB.addLog("Debt.test, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Debt.test end ", WB.strEmpty, "Debt");
	}

//	private void getLower() throws Exception {
//	// origin - 18.12.2024, last edit - 19.12.2024
//	var srcList = WB.abcLast.debt;
//	List<ModelDto> tmpLower1 = new ArrayList<ModelDto>();
//	tmpLower1 = ReadSet.getEqualsByParent(srcList, this.code); // direct lower 1 level
//	List<ModelDto> tmpLower2 = new ArrayList<ModelDto>(); // lower 2 level
//	boolean foundNewLowerCode = true;
//
//	try {
//		for (;;) {
//			foundNewLowerCode = false;
//			tmpLower2.clear();
//
//			for (var currL1 : tmpLower1) {
//				tmpLower2.addAll(ReadSet.getEqualsByParent(srcList, currL1.code));
//			}
//
//			for (var currL2 : tmpLower2) {
//				if (ModelDto.isContains(tmpLower1, currL2) == false) {
//					tmpLower1.add(currL2);
////					WB.addLog2("Debt.getLower, add currL2.code=" + currL2.code + ", for this.code=" + this.code,
////							WB.strEmpty, "Debt");
//					foundNewLowerCode = true;
//				}
//			}
//
//			if (foundNewLowerCode == false) {
//				break;
//			}
//		}
//
//		this.lower.addAll(tmpLower1);
//	} catch (Exception ex) {
//		WB.addLog("Debt.getLower, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
//	} finally {
//		Etc.doNothing();
//	}
//}

//private void getUpper() throws Exception {
//	// origin - 17.12.2024, last edit - 20.12.2024
//	var srcList = WB.abcLast.debt;
//	String tmpParentCode = this.parent;
//	List<ModelDto> tmpUpper = new ArrayList<ModelDto>();
//	boolean foundNewParentCode = true;
//
//	try {
//		for (;;) {
//			foundNewParentCode = false;
//			for (var currLst : srcList) {
//				if (Etc.strEquals(currLst.code, tmpParentCode)) {
//					if (ModelDto.isContains(tmpUpper, currLst) == false) {
//						tmpUpper.add(currLst);
////						WB.addLog2("Debt.getUpper, add currLst.code=" + currLst.code + ", tmpParentCode="
////								+ tmpParentCode + ", for this.code=" + this.code, WB.strEmpty, "Debt");
//						tmpParentCode = currLst.parent;
//						foundNewParentCode = true;
//						break;
//					}
//				}
//			}
//			if (foundNewParentCode == false) {
//				break;
//			}
//		}
//		this.upper.addAll(tmpUpper);
//	} catch (Exception ex) {
//		WB.addLog("Debt.getUpper, ex=" + ex.getMessage(), WB.strEmpty, "Debt");
//	} finally {
//		Etc.doNothing();
//	}
//	// WB.addLog2("Debt.getUpper, tmpUpper.size=" + tmpUpper.size(), WB.strEmpty,
//	// "Debt");
//}
}
