public final class Person {
	// origin - 26.11.2025, last edit - 05.12.2025

	public static String getDateBirth(String faceId) throws Exception {
		// origin - 29.11.2025, last edit - 05.12.2025
		String res = "";
		try {
			var face = new Face(faceId);
			res = face.getDateBirthByFaceGovId();
		} catch (Exception ex) {
			WB.addLog("Person.getDateBirth(String):String, ex=" + ex.getMessage(), "", "Person");
		}
		return res;
	}

	public static String getFIO(String faceId) throws Exception {// from "Smith John Oakland" to "Smith J. O."
		// origin - 27.11.2025, last edit - 27.11.2025
		String res = "";
		try {
			var tmp = Face.getFullName(faceId);
			res = new FIO(tmp).code; // from "Smith John Oakland" to "Smith J. O."
		} catch (Exception ex) {
			WB.addLog("Person.getFIO(String):String, ex=" + ex.getMessage(), "", "Person");
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 26.11.2025, last edit - 05.12.2025
		try {

//			WB.addLog2("Person.test.getDateBirth(String):String", "", "Face");
//			for (var tmp1 : new String[] { "Face.Person.Template", "Face.Tralala" }) {
//				WB.addLog2("Person.test.getDateBirth(String):String, res=" + Person.getDateBirth(tmp1) + ", faceId="
//						+ tmp1, "", "Person");
//			}

//			WB.addLog2("Person.test.getFIO(String):String", "", "Person");
//			for (var tmp1 : new String[] { "Face.FA1", "Face.Enterprise.Template", "Face.Person.Template",
//					"Face.Tralala" }) {
//				WB.addLog2("Person.test.getFIO(String):String, res=" + Person.getFIO(tmp1) + ", faceId=" + tmp1, "", "Person");
//			}

		} catch (Exception ex) {
			WB.addLog("Person.test():void, ex=" + ex.getMessage(), "", "Person");
		}
	}
}