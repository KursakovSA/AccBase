import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

public final class Personal {
	// origin - 12.12.2025, last edit - 19.12.2025
	// common fields
	public String src, context;
	// special fields
	public static List<String> kind;
	public LinkedHashMap<String, String> val;

	static {
		try {
			Personal.kind = Personal.getKind();
		} catch (Exception ex) {
			WB.addLog("Personal.static ctor, ex=" + ex.getMessage(), "", "Personal");
		}
	}

	public static String getByKind(LinkedHashMap<String, String> val, String kindPersonal) throws Exception {
		// origin - 17.12.2025, last edit - 19.12.2025
		String res = "";
		try {
			for (var curr : val.entrySet()) {
				// ex. kindPersonal="пол[RU]sex[EN]", curr.getKey()="пол",
				if (Etc.strContains(kindPersonal, curr.getKey())) {
					res = Etc.fixTrim(curr.getValue());
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Personal.getByKind(LinkedHashMap<2String>,String):String, ex=" + ex.getMessage(), "",
					"Personal");
		}
		return res;
	}

	private static List<String> getKind() throws Exception {
		// origin - 17.12.2025, last edit - 19.12.2025
		List<String> res = new ArrayList<String>();
		try {
			for (var curr : WB.abcLast.personal) {
				res.add(Etc.fixTrim(curr.description));
			}
		} catch (Exception ex) {
			WB.addLog("Personal.getKind():List<String>, ex=" + ex.getMessage(), "", "Personal");
		}
		return res;
	}

	private void getVal() throws Exception {
		// origin - 19.12.2024, last edit - 20.12.2025
		try {
			var tmp1 = new ListVal(this.src, "");
			for (var curr : tmp1.val) {
				var tmp2 = new AnnoVal(curr);
				// ex. key="sex", value="мужской"
				this.val.put(tmp2.anno.getFirst().toString(), tmp2.val);
			}
		} catch (Exception ex) {
			WB.addLog("Personal.getVal():void, ex=" + ex.getMessage(), "", "Personal");
		}
	}

	private void validate() throws Exception { // TODO
		// origin - 12.12.2025, last edit - 15.12.2025
		try {
		} catch (Exception ex) {
			WB.addLog("Personal.validate():void, ex=" + ex.getMessage(), "", "Personal");
		}
	}

	public Personal(String Src) throws Exception {
		// origin - 12.12.2025, last edit - 19.12.2025
		this.clear();
		this.src = Src;
		this.getVal();
		this.validate();
	}

	public Personal() throws Exception {
		// origin - 12.12.2025, last edit - 12.12.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 12.12.2025, last edit - 17.12.2025
		try {
			this.src = this.context = "";
			this.val = new LinkedHashMap<String, String>();
		} catch (Exception ex) {
			WB.addLog("Personal.clear():void, ex=" + ex.getMessage(), "", "Personal");
		}
	}

	public String toString() {
		// origin - 08.12.2025, last edit - 19.12.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway(", src ", this.src);
			res = res + Fmtr.addAnyway(" val ", this.val);
			res = res + Fmtr.addIfNotEmpty(", context ", this.context);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 12.12.2025, last edit - 20.12.2025
		try {

//			WB.addLog2("Personal.test.getByKind(LinkedHashMap<2String>,String):String", "", "Personal");
//			for (var tmp1 : new String[] { "male (sex)", "мужской (пол)", "90 (вес):180 (рост)",
//					"90 (вес):160 (рост)" }) {
//				var tmp2 = new Personal(tmp1).val;
//				for (var tmp3 : Personal.kind) {
//					WB.addLog2(
//							"Personal.test.getByKind(LinkedHashMap<2String>,String):String, res="
//									+ Personal.getByKind(tmp2, tmp3) + ", src=" + tmp1 + ", kindPersonal=" + tmp3,
//							"", "Personal");
//				}
//			}

//			WB.addLog2("Personal.test.ctor(String)", "", "Personal");
//			for (var tmp : new String[] { "male (sex)", "мужской (пол)", "90 (вес):180 (рост)",
//					"90 (вес):160 (рост)" }) {
//				WB.addLog2("Personal.test.ctor(String), res=" + new Personal(tmp), "", "Personal");
//			}

		} catch (Exception ex) {
			WB.addLog("Personal.test():void, ex=" + ex.getMessage(), "", "Personal");
		}
	}
}