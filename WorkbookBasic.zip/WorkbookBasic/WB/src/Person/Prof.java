import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

public final class Prof {
	// origin - 15.12.2025, last edit - 20.12.2025
	// common fields
	public String src, context;
	// special fields
	public static List<String> kind;
	public LinkedHashMap<String, String> val;

	static {
		try {
			Prof.kind = Prof.getKind();
		} catch (Exception ex) {
			WB.addLog("Prof.static ctor, ex=" + ex.getMessage(), "", "Prof");
		}
	}

	public static String getByKind(LinkedHashMap<String, String> val, String kindProf) throws Exception {
		// origin - 15.12.2025, last edit - 20.12.2025
		String res = "";
		try {
			for (var curr : val.entrySet()) {
				// ex. kindProf="пол[RU]sex[EN]", curr.getKey()="пол",
				if (Etc.strContains(kindProf, curr.getKey())) {
					res = Etc.fixTrim(curr.getValue());
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Prof.getByKind(LinkedHashMap<2String>,String):String, ex=" + ex.getMessage(), "", "Prof");
		}
		return res;
	}

	private static List<String> getKind() throws Exception {
		// origin - 15.12.2025, last edit - 20.12.2025
		List<String> res = new ArrayList<String>();
		try {
			for (var curr : WB.abcLast.prof) {
				res.add(Etc.fixTrim(curr.description));
			}
		} catch (Exception ex) {
			WB.addLog("Prof.getKind():List<String>, ex=" + ex.getMessage(), "", "Prof");
		}
		return res;
	}

	private void getVal() throws Exception {
		// origin - 15.12.2024, last edit - 20.12.2025
		try {
			var tmp1 = new ListVal(this.src, "");
			for (var curr : tmp1.val) {
				var tmp2 = new AnnoVal(curr);
				// ex. key="sex", value="мужской"
				this.val.put(tmp2.anno.getFirst().toString(), tmp2.val);
			}
		} catch (Exception ex) {
			WB.addLog("Prof.getVal():void, ex=" + ex.getMessage(), "", "Prof");
		}
	}

	private void validate() throws Exception { // TODO
		// origin - 15.12.2025, last edit - 20.12.2025
		try {
		} catch (Exception ex) {
			WB.addLog("Prof.validate():void, ex=" + ex.getMessage(), "", "Prof");
		}
	}

	public Prof(String Src) throws Exception {
		// origin - 15.12.2025, last edit - 20.12.2025
		this.clear();
		this.src = Src;
		this.getVal();
		this.validate();
	}

	public Prof() throws Exception {
		// origin - 15.12.2025, last edit - 20.12.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 15.12.2025, last edit - 20.12.2025
		try {
			this.src = this.context = "";
			this.val = new LinkedHashMap<String, String>();
		} catch (Exception ex) {
			WB.addLog("Prof.clear():void, ex=" + ex.getMessage(), "", "Prof");
		}
	}

	public String toString() {
		// origin - 05.12.2025, last edit - 20.12.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway(", src ", this.src);
			res = res + Fmtr.addAnyway(" val ", this.val);
			res = res + Fmtr.addIfNotEmpty(", context ", this.context);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 15.12.2025, last edit - 20.12.2025
		try {

//			WB.addLog2("Prof.test.getByKind(LinkedHashMap<2String>,String):String", "", "Prof");
//			for (var tmp1 : new String[] { "обучаемость (компетенция)", "токарь (компетенция)" }) {
//				var tmp2 = new Prof(tmp1).val;
//				for (var tmp3 : Prof.kind) {
//					WB.addLog2("Prof.test.getByKind(LinkedHashMap<2String>,String):String, res="
//							+ Prof.getByKind(tmp2, tmp3) + ", src=" + tmp1 + ", kindProf=" + tmp3, "", "Prof");
//				}
//			}

//			WB.addLog2("Prof.test.ctor(String)", "", "Prof");
//			for (var tmp : new String[] { "обучаемость (компетенция)", "токарь (компетенция)" }) {
//				WB.addLog2("Prof.test.ctor(String), res=" + new Prof(tmp), "", "Prof");
//			}

		} catch (Exception ex) {
			WB.addLog("Prof.test():void, ex=" + ex.getMessage(), "", "Prof");
		}
	}
}