public final class PrivateInfo {
	// origin - 12.12.2025, last edit - 12.12.2025
	// common fields
	public String src, id, context, defect;
	// special fields
	public UnitVal sex, weight, height;
	public String fullName, comment;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("PrivateInfo.static ctor, ex=" + ex.getMessage(), "", "PrivateInfo");
		}
	}

	private void validate() throws Exception {
		// origin - 12.12.2025, last edit - 12.12.2025
		try {
			if (this.fullName.length() < 3) {
				this.defect = this.defect + "empty fullName; ";
			}
		} catch (Exception ex) {
			WB.addLog("PrivateInfo.validate():void, ex=" + ex.getMessage(), "", "PrivateInfo");
		}
	}

	private void clear() throws Exception {
		// origin - 12.12.2025, last edit - 12.12.2025
		try {
			this.src = this.id = this.context = this.defect = this.fullName = this.comment = "";
		} catch (Exception ex) {
			WB.addLog("PrivateInfo.clear():void, ex=" + ex.getMessage(), "", "PrivateInfo");
		}
	}

	public PrivateInfo(String BIC, String FullName) throws Exception {
		// origin - 12.12.2025, last edit - 12.12.2025
		this.clear();
		this.src = this.id = BIC + " , " + FullName;
		this.fullName = Etc.fixTrim(FullName);
		this.validate();
	}

	public PrivateInfo() throws Exception {
		// origin - 12.12.2025, last edit - 12.12.2025
		this.clear();
	}

	public String toString() {
		// origin - 08.12.2025, last edit - 08.12.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", context ", this.context);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 12.12.2025, last edit - 12.12.2025
		try {

		} catch (Exception ex) {
			WB.addLog("PrivateInfo.test():void, ex=" + ex.getMessage(), "", "PrivateInfo");
		}
	}
}