import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class ModelDto {
	// origin - 30.09.2023, last edit - 19.09.2024

	// common field
	public String table = new String();
	public String id = new String();
	public String parent = new String();
	public String face1 = new String();
	public String face2 = new String();
	public String face = new String();
	public String slice = new String();
	public String date1 = new String();
	public String date2 = new String();
	public String code = new String();
	public String description = new String();
	public String sign = new String();
	public String account = new String();
	public String geo = new String();
	public String role = new String();
	public String info = new String();
	public String meter = new String();
	public String meterValue = new String();
	public String unit = new String();
	public String more = new String();
	public String mark = new String();

	// special field
	public String process = new String();
	public String asset = new String();
	public String deal = new String();
	public String item = new String();
	public String debt = new String();
	public String price = new String();

	public LocalDate startDate;
	public LocalDate endDate;

	// public static String defaultInfoBaseId = new String();

	static {
		try {
			// defaultInfoBaseId = "IB1";
		} catch (Exception ex) {
			WB.addLog("ModelDto.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
	}

	{
		this.clear();
	}

//	public boolean isMatch(ModelDto testMatch) throws Exception {
//		// origin - 18.09.2024, last edit - 18.09.2024
//		boolean res = false;
//		try {
//			if (Etc.strEquals(testMatch.id, this.id)) {
//				if (Etc.strEquals(testMatch.code, this.code)) {
//					if (Etc.strEquals(testMatch.description, this.description)) {
//						res = true;
//					}
//				}
//			}
//		} catch (Exception ex) {
//			WB.addLog("ModelDto.isMatch, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "ModelDto");
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("ModelDto.isMatch, res=" + res + ", this=" + this, WB.strEmpty,
//		// "ModelDto");
//		return res;
//	}

	public boolean isValid() throws Exception {
		// origin - 17.09.2024, last edit - 17.09.2024
		boolean res = true;
		try {
			if (this.id.isEmpty()) {
				res = false;
			}
			if (this.code.isEmpty()) {
				res = false;
			}
			if (this.description.isEmpty()) {
				res = false;
			}
		} catch (Exception ex) {
			WB.addLog("ModelDto.isValid, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.isValid, res=" + res + ", this=" + this, WB.strEmpty,
		// "ModelDto");
		return res;
	}

	public static ModelDto getRoot(String table) throws Exception {
		// origin - 23.09.2024, last edit - 23.09.2024
		ModelDto res = new ModelDto();
		try {
			res = ModelDto.getSubsetByCode(WB.abcLast.basic, table).getFirst();
		} catch (Exception ex) {
			WB.addLog("ModelDto.getRoot, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getRoot, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	public String getId() throws Exception {
		// origin - 20.08.2024, last edit - 23.09.2024
		String res = WB.strEmpty;
		try {
			// res = IdGen.getNew();
			res = new IdGen("", "").id;
		} catch (Exception ex) {
			WB.addLog("ModelDto.getId, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getId, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	public String getId(String moreId, String context) throws Exception {
		// origin - 20.08.2024, last edit - 02.09.2024
		String res = WB.strEmpty;
		try {
			context = DefVal.set(context, "idIntegerGrowingDigitalGlobal");
			// res = IdGen.getNew(moreId, context);
			res = new IdGen(moreId, context).id;
		} catch (Exception ex) {
			WB.addLog("ModelDto.getId, ex=" + ex.getMessage(), WB.strEmpty, "Face");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getId, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

//	public static List<ModelDto> removeDuplicate2(List<ModelDto> dtoBase, List<ModelDto> dtoAdd) throws Exception {
//		// origin - 12.06.2024, last edit - 27.06.2024
//		//LocalDateTime localStart = WB.getLocalStart();
//		List<ModelDto> res = new ArrayList<ModelDto>();
//		String strCurrDtoRes = WB.strEmpty;
//		String strCurrDtoAdd = WB.strEmpty;
//		boolean hasEqualsBaseAdd = false;
//		try {
//
//			if (dtoBase.isEmpty()) {
//				res.addAll(dtoAdd);
//
//			} else {
//				for (var currDtoAdd : dtoAdd) {
//					strCurrDtoAdd = currDtoAdd.toString();// strCurrDtoAdd = currDtoAdd.id;
//					for (var currDtoBase : dtoBase) {
//						strCurrDtoRes = currDtoBase.toString();// strCurrDtoRes = currDtoBase.id;
//						hasEqualsBaseAdd = false;
//						if (strCurrDtoRes.equals(strCurrDtoAdd)) {
//							hasEqualsBaseAdd = true;
//							break;
//						}
//					}
//					if (hasEqualsBaseAdd == false) {
//						res.add(new ModelDto(currDtoAdd));
//					}
//				}
//			}
//
//		} catch (Exception ex) {
//			WB.addLog("ModelDto.removeDuplicate2, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
//		} finally {
//			Etc.doNothing();
//		}
////		WB.getLocalEnd("ModelDto.removeDuplicate2 for List<ModelDto> dtoBase.size=" + dtoBase.size()
////				+ ", dtoAdd.size=" + dtoAdd.size(), localStart);
////		WB.addLog2("ModelDto.removeDuplicate2, res.size=" + res.size() + ", dtoBase.size=" + dtoBase.size()
////				+ ", dtoAdd.size=" + dtoAdd.size(), WB.strEmpty, "ModelDto");
//		return res;
//	}

	public static List<ModelDto> removeDuplicate(List<ModelDto> dtoCollector, List<ModelDto> dtoAdd) throws Exception {
		// origin - 03.06.2024, last edit - 27.06.2024
		LocalDateTime localStart = WB.getLocalStart();
		List<ModelDto> res = new ArrayList<ModelDto>();
		WB.addLog2("ModelDto.removeDuplicate, before work, res.size=" + res.size() + ", dtoCollector.size="
				+ dtoCollector.size() + ", dtoAdd.size=" + dtoAdd.size(), WB.strEmpty, "ModelDto");
		String strCurrDtoRes = WB.strEmpty;
		String strCurrDtoAdd = WB.strEmpty;
		boolean hasEqualsCollectorAdd = false;
		try {

			if (dtoCollector.isEmpty()) {
				res.addAll(dtoAdd);

			} else {
				for (var currDtoAdd : dtoAdd) {
					strCurrDtoAdd = currDtoAdd.toString();// strCurrDtoAdd = currDtoAdd.id;
					for (var currDtoRes : dtoCollector) {
						strCurrDtoRes = currDtoRes.toString();// strCurrDtoRes = currDtoRes.id;
						hasEqualsCollectorAdd = false;
						if (strCurrDtoRes.equals(strCurrDtoAdd)) {
							hasEqualsCollectorAdd = true;
							break;
						}
					}
					if (hasEqualsCollectorAdd == false) {
						res.add(new ModelDto(currDtoAdd));
					}
				}
			}
			res.addAll(dtoCollector);

		} catch (Exception ex) {
			WB.addLog("ModelDto.removeDuplicate, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		WB.getLocalEnd("ModelDto.removeDuplicate for List<ModelDto> dtoCollector.size=" + dtoCollector.size()
				+ ", dtoAdd.size=" + dtoAdd.size(), localStart);
		WB.addLog2("ModelDto.removeDuplicate, after work, res.size=" + res.size() + ", dtoCollector.size="
				+ dtoCollector.size() + ", dtoAdd.size=" + dtoAdd.size(), WB.strEmpty, "ModelDto");
		return res;
	}

//	private static List<ModelDto> getTestSubset(String table, int numberRecord) throws Exception {
//		// origin - 26.06.2024, last edit - 21.08.2024
//		List<ModelDto> res = new ArrayList<ModelDto>();
//		try {
//			for (int i = 0; i < numberRecord; i++) {
//				res.add(new ModelDto(table, IdGen.getNew("ModelDto", "idCommonCompositeRandom"), WB.strEmpty,
//						WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, getDate1(WB.strEmpty),
//						getDate2(WB.strEmpty), "Test", "Test", WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//						WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, getMore(WB.strEmpty), WB.strEmpty,
//						WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty));
//			}
//
//		} catch (Exception ex) {
//			WB.addLog("ModelDto.getTestSubset(table, numberRecord), ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("ModelDto.getTestSubset(table, numberRecord), res.size=" +
//		// res.size(), WB.strEmpty, "ModelDto");
//		return res;
//	}

	public static List<ModelDto> getTestSubset(List<List<String>> testTable) throws Exception {
		// origin - 08.02.2024, last edit - 02.09.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			for (var currTable : testTable) {
				List<ModelDto> tmp = new ArrayList<ModelDto>();
				tmp.clear();
				String table = currTable.get(0);
				int numberRecord = Integer.parseInt(currTable.get(1));

				for (int i = 0; i < numberRecord; i++) {
					tmp.add(new ModelDto(table, new IdGen().id, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, // IdGen.getNew()
							WB.strEmpty, getDate1(WB.strEmpty), getDate2(WB.strEmpty), "Test", "Test", WB.strEmpty,
							WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
							getMore(WB.strEmpty), WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
							WB.strEmpty, WB.strEmpty));
				}
				res.addAll(tmp);
				// res.addAll(ModelDto.getTestSubset(currTable.get(0),
				// Integer.parseInt(currTable.get(1))));
			}

		} catch (Exception ex) {
			WB.addLog("ModelDto.getTestSubset(numberRecord), ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getTestSubset, res.size=" + res.size(), WB.strEmpty,
		// "ModelDto");
		return res;
	}

	private static String delFieldFromMoreByKey(String initMore, String delField) throws Exception {
		// origin - 25.06.2024, last edit - 12.08.2024
		String res = WB.strEmpty;
		initMore = Etc.fixTrim(initMore);
		try {
			String[] items = {};
			items = Etc.getArrayFromStrSplit(initMore, WB.strSemiColon); // if value are diffferent in list ???
			for (var item : items) {
				if (Etc.strContains(item, delField)) {// skip deleting field
					continue;
				}
				res = res + item;
			}
		} catch (Exception ex) {
			WB.addLog("ModelDto.delFieldFromMoreByKey, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty,
					"ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.delFieldFromMoreByKey, res=" + res + ", initMore=" +
		// initMore, WB.strEmpty, "ModelDto");
		return res;
	}

	private static String getLastEdit(String initRes) throws Exception {
		// origin - 25.06.2024, last edit - 12.08.2024
		String res = Etc.fixTrim(initRes);
		try {
			res = ModelDto.delFieldFromMoreByKey(res, "LastEdit"); // ??? magic string
			res = res + "LastEdit=" + DateTool.formatter2(DateTool.getNow2()) + WB.strSemiColon;
		} catch (Exception ex) {
			WB.addLog("ModelDto.getLastEdit, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getLastEdit, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	private static String getMore(String more) throws Exception {
		// origin - 09.02.2024, last edit - 12.08.2024
		String res = Etc.fixTrim(more);
		try {
			res = res + ModelDto.getLastEdit(res);
		} catch (Exception ex) {
			WB.addLog("ModelDto.getMore, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getMore, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	private static String getDate2(String date2) throws Exception {
		// origin - 09.02.2024, last edit - 27.06.2024
		String res = Etc.fixTrim(date2);
		if (res.isEmpty()) {
			try {
				res = DateTool.getLocalDate(WB.strEmpty).toString();

			} catch (Exception ex) {
				WB.addLog("ModelDto.getIDate2, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
			} finally {
				Etc.doNothing();
			}
		}
		// WB.addLog2("ModelDto.getDate2, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	private static String getDate1(String date1) throws Exception {
		// origin - 09.02.2024, last edit - 27.06.2024
		String res = Etc.fixTrim(date1);
		if (res.isEmpty()) {
			try {
				res = DateTool.getLocalDate(WB.strEmpty).toString();

			} catch (Exception ex) {
				WB.addLog("ModelDto.getIDate1, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
			} finally {
				Etc.doNothing();
			}
		}
		// WB.addLog2("ModelDto.getDate1, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	public static String getValueByKeyFromEquation(String[] equation, String key) throws Exception {
		// origin - 16.06.2024, last edit - 01.09.2024
		String res = WB.strEmpty;
		try {
			int indexSignEquals = 0;
			String strKey = WB.strEmpty;
			String splitEquation = WB.strEquals;
			for (var currEquation : equation) {
				indexSignEquals = 0;
				indexSignEquals = currEquation.lastIndexOf(splitEquation);
				if (indexSignEquals > 0) {
					strKey = WB.strEmpty;
					strKey = currEquation.substring(0, indexSignEquals);
					if (strKey.isEmpty() == false) {
						if (Etc.strEquals(key, strKey)) {
							res = currEquation.substring(indexSignEquals + 1, currEquation.length());
						}
					}
				}

			}
		} catch (Exception ex) {
			WB.addLog("ModelDto.getValueByKeyFromEquation, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getValueByKeyFromEquation, res=" + res + ", key=" + key,
		// WB.strEmpty, "ModelDto");
		return res;
	}

//	// public static String getMaxValueFromMoreById(List<ModelDto> dto, String
//	// strId, int defaultLenght, String leftPlaceholder) throws Exception {// TODO
//	public static IdGen.idDetail getMaxValueFromMoreById(List<ModelDto> dto, String strId, int defaultLenght,
//			String leftPlaceholder) throws Exception {
//		// origin - 13.08.2024, last edit - 01.09.2024
//		//String res = WB.strEmpty;
//		String resIdActual = WB.strEmpty;
//		String currIdActual = WB.strEmpty;
//		String resIdActualPartNumber = WB.strEmpty;
//		try {
//			String[] items = {};
//			String splitValueInMore = WB.strSemiColon;
//			String currVal = WB.strEmpty;
//			int currMaxVal = 0;
//			for (var currDto : dto) {
//
//				items = Etc.getArrayFromStrSplit(currDto.more, splitValueInMore); // if value are diffferent in list ???
//				currVal = ModelDto.getValueByKeyFromEquation(items, strId);
//				currIdActual = currVal;
//				currVal = DefVal.set(currVal, defaultLenght);// cut off string on the right what hit to norm lenght
//				currVal = Etc.delLeaderPlaceholder(currVal, leftPlaceholder);// "0");
//
//				if (Etc.isDigitAll(currVal)) {// ??
//					if (Integer.parseInt(currVal) != 0) {
//						// WB.addLog2("ModelDto.getMaxValueFromMoreById, Integer.parseInt(res)!=0, =" +
//						// Integer.parseInt(res), WB.strEmpty, "ModelDto");
//						if (currMaxVal < Integer.parseInt(currVal)) {
//							currMaxVal = Integer.parseInt(currVal);
//							//res = currVal;
//							resIdActualPartNumber = currVal;
//							resIdActual = currIdActual;
//						}
//					}
//				}
//			}
//		} catch (Exception ex) {
//			WB.addLog("ModelDto.getMaxValueFromMoreById, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("ModelDto.getMaxValueFromMoreById, res=" + res, WB.strEmpty,
//		// "ModelDto");
//		return new IdGen.idDetail(resIdActual, resIdActualPartNumber);//res;
//	}

	public static String getValueFromMoreByKey(List<ModelDto> dto, String key, String code) throws Exception {
		// origin - 17.06.2024, last edit - 18.08.2024
		String res = WB.strEmpty;
		try {
			String[] items = {};
			String splitValueInMore = WB.strSemiColon;
			for (var currDto : dto) {

				// filter by code (optional)
				if (code.isEmpty() == false) {// code may be empty
					if (Etc.strEquals(currDto.code, code) == false) {
						continue;
					}
				}

				items = Etc.getArrayFromStrSplit(currDto.more, splitValueInMore); // if value are diffferent in list ???
				res = ModelDto.getValueByKeyFromEquation(items, key);
			}
		} catch (Exception ex) {
			WB.addLog("ModelDto.getValueFromMoreByKey, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getValueFromMoreByKey, res=" + res, WB.strEmpty,
		// "ModelDto");
		return res;
	}

//	public static int getLenghtField(String idField, String code) throws Exception {
//		// origin - 23.06.2024, last edit - 03.09.2024
//		int res = 0;
//		try {
//			res = Integer.parseInt(getValueFromMoreByKey(WB.abcLast.basic, idField, code)); // ??? WB.abcLast.basic as
//																							// arg get ???
//		} catch (Exception ex) {
//			WB.addLog("ModelDto.getLenghtField, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("ModelDto.getLenghtField, res=" + res + ", idField = " + idField +
//		// ", code=" + code, WB.strEmpty, "ModelDto");
//		return res;
//	}

//	public static String getValueField(List<ModelDto> listDto, String idField, String code, String defaultValue)
//			throws Exception {
//		// origin - 23.06.2024, last edit - 16.09.2024
//		String res = WB.strEmpty;
//		try {
//			res = ModelDto.getValueFromMoreByKey(listDto, idField, code);
//			res = DefVal.set(res, defaultValue);
//		} catch (Exception ex) {
//			WB.addLog("ModelDto.getValueField, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
//		} finally {
//			Etc.doNothing();
//		}
////		WB.addLog2("ModelDto.getValueField, res=" + res + ", idField =" + idField + ", code=" + code + ", defaultValue="
////				+ defaultValue, WB.strEmpty, "ModelDto");
//		return res;
//	}

	public static ModelDto getFilter(String subStrCode, String subStrMeter) throws Exception {
		// origin - 09.01.2024, last edit - 05.07.2024
		ModelDto res = new ModelDto();
		try {
			if (subStrCode.isEmpty() == false) {
				res.code = subStrCode;
			}
			if (subStrMeter.isEmpty() == false) {
				res.meter = subStrMeter;
			}
		} catch (Exception ex) {
			WB.addLog("ModelDto.getFilter, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog("ModelDto.getFilter, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	public static List<ModelDto> getSubset(List<ModelDto> set, ModelDto filter) throws Exception {
		// origin - 08.01.2024, last edit - 15.07.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		List<ModelDto> tmp = set;
		String allFilter = WB.strEmpty;
		try {
			if (filter.more.isEmpty() == false) {
				allFilter = allFilter + "filter.more=" + filter.more + WB.strCommaSpace;
				tmp = ModelDto.getSubsetByMore(tmp, filter.more);
			}
			if (filter.code.isEmpty() == false) {
				allFilter = allFilter + "filter.code=" + filter.code + WB.strCommaSpace;
				tmp = ModelDto.getSubsetByCode(tmp, filter.code);
			}
			if (filter.meter.isEmpty() == false) {
				allFilter = allFilter + "filter.meter=" + filter.meter + WB.strCommaSpace;
				tmp = ModelDto.getSubsetByMeter(tmp, filter.meter);
			}
		} catch (Exception ex) {
			WB.addLog("ModelDto.getSubset, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		res = tmp;
		// WB.addLog2("ModelDto.getSubset, res.size=" + res.size() + ", allFilter=" +
		// allFilter, WB.strEmpty, "ModelDto");
		return res;
	}

	public static List<ModelDto> getSubsetByMeter(List<ModelDto> set, String subStr) throws Exception {
		// origin - 07.01.2024, last edit - 27.06.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = set.stream();
			basicStream.filter(n -> n.meter.toLowerCase().contains(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ModelDto.getSubsetMeter, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getSubsetByMeter, res.size=" + res.size() + ", subStr="
		// +
		// subStr, WB.strEmpty, "ModelDto");
		return res;
	}

	public static List<ModelDto> getSubsetByParent(List<ModelDto> set, String subStr) throws Exception {
		// origin - 02.08.2024, last edit - 02.08.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = set.stream();
			basicStream.filter(n -> n.parent.toLowerCase().contains(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ModelDto.getSubsetByParent, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getSubsetByParent, res.size=" + res.size() + ",
		// subStr=" +
		// subStr, WB.strEmpty, "ModelDto");
		return res;
	}

	public static List<ModelDto> getSubsetByDescription(List<ModelDto> set, String subStr) throws Exception {
		// origin - 02.09.2024, last edit - 02.09.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = set.stream();
			basicStream.filter(n -> n.description.toLowerCase().contains(subStr.toLowerCase()))
					.forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ModelDto.getSubsetByDescription, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getSubsetByDescription, res.size=" + res.size() + ",
		// subStr=" +
		// subStr, WB.strEmpty, "ModelDto");
		return res;
	}

	public static List<ModelDto> getSubsetByCode(List<ModelDto> set, String subStr) throws Exception {
		// origin - 07.01.2024, last edit - 02.08.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = set.stream();
			basicStream.filter(n -> n.code.toLowerCase().contains(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ModelDto.getSubsetByCode, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getSubsetByCode, res.size=" + res.size() + ", subStr=" +
		// subStr, WB.strEmpty, "ModelDto");
		return res;
	}

	public static List<ModelDto> getSubsetByMore(List<ModelDto> set, String subStr) throws Exception {
		// origin - 29.11.2023, last edit - 27.06.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = set.stream();
			basicStream.filter(n -> n.more.toLowerCase().contains(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ModelDto.getSubsetMore, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getSubsetMore, res.size=" + res.size() + ", subStr=" +
		// subStr, WB.strEmpty, "ModelDto");
		return res;
	}

	public ModelDto(String Id, String Code, String Description) throws Exception {
		// origin - 04.08.2024, last edit - 23.09.2024
		this.id = Id;
		this.code = Code;
		this.description = Description;
	}

	public ModelDto(ModelDto in) throws Exception {
		// origin - 02.01.2024, last edit - 23.09.2024
		this.table = in.table;
		this.id = in.id;
		this.parent = in.parent;
		this.face1 = in.face1;
		this.face2 = in.face2;
		this.face = in.face;
		this.slice = in.slice;
		this.date1 = in.date1;
		this.date2 = in.date2;
		this.code = in.code;
		this.description = in.description;
		this.sign = in.sign;
		this.account = in.account;
		this.geo = in.geo;
		this.role = in.role;
		this.info = in.info;
		this.meter = in.meter;
		this.meterValue = in.meterValue;
		this.unit = in.unit;
		this.more = in.more;
		this.mark = in.mark;
		this.process = in.process;
		this.asset = in.asset;
		this.deal = in.deal;
		this.item = in.item;
		this.debt = in.debt;
		this.price = in.price;
	}

	public ModelDto(String Table, String Id, String Parent, String Face1, String Face2, String Face, String Slice,
			String Date1, String Date2, String Code, String Description, String Sign, String Account, String Geo,
			String Role, String Info, String Meter, String MeterValue, String Unit, String More, String Mark,
			String Process, String Asset, String Deal, String Item, String Debt, String Price) throws Exception {
		// origin - 02.11.2023, last edit - 23.09.2024
		this.table = Table;
		this.id = Id;
		this.parent = Parent;
		this.face1 = Face1;
		this.face2 = Face2;
		this.face = Face;
		this.slice = Slice;
		this.date1 = Date1;
		this.date2 = Date2;
		this.code = Code;
		this.description = Description;
		this.sign = Sign;
		this.account = Account;
		this.geo = Geo;
		this.role = Role;
		this.info = Info;
		this.meter = Meter;
		this.meterValue = MeterValue;
		this.unit = Unit;
		this.more = More;
		this.mark = Mark;
		this.process = Process;
		this.asset = Asset;
		this.deal = Deal;
		this.item = Item;
		this.debt = Debt;
		this.price = Price;
	}

	public void clear() throws Exception {
		// origin - 31.12.2023, last edit - 12.08.2024
		try {
			this.table = this.id = this.parent = this.face1 = this.face2 = this.face = this.slice = this.date1 = this.date2 = this.code = this.description = this.sign = this.account = this.geo = this.role = this.info = this.meter = this.meterValue = this.unit = this.more = this.mark = this.process = this.asset = this.deal = this.item = this.debt = this.price = WB.strEmpty;
		} catch (Exception ex) {
			WB.addLog("ModelDto.clear, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
	}

	public ModelDto() throws Exception {
		// origin - 02.11.2023, last edit - 23.09.2024
		this.clear();
	}

	public String toString() {
		// origin - 30.09.2023, last edit - 31.08.2024
		String res = WB.strEmpty;
		try {
			res = Formatter.reflect(this);
			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
			// WB.addLog2("ModelDto.toString, ex=" + ex.getMessage(), WB.strEmpty,
			// "ModelDto");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public boolean expectedDouble() {
		// origin - 18.09.2024, last edit - 18.09.2024
		boolean res = true;
		try {
			if (Etc.strContains(this.meter, "Meter.PublicHoliday")) { // skip public holiday
				res = false;
			}

			if (Etc.strContains(this.meter, "Meter.ExtraDayOff")) { // skip extra day off
				res = false;
			}

			if (Etc.strContains(this.meter, "Meter.Matching")) { // skip account matching
				res = false;
			}
		} catch (Exception ex) {
			// WB.addLog2("ModelDto.expectedDouble, ex=" + ex.getMessage(), WB.strEmpty,
			// "ModelDto");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static double getChrono(LocalDate calcDate, List<ModelDto> subsetGlobalBasic) throws Exception {
		// origin - 09.01.2024, last edit - 18.09.2024
		double res = 0.0;
		double tmp = 0.0;
		LocalDate currDate1;
		LocalDate currDate2;
		try {
			for (var currSubset : subsetGlobalBasic) {
				if (currSubset.expectedDouble() == false) {
					continue;
				}

				currDate1 = DateTool.getLocalDate(currSubset.date1);// left border in data
				currDate2 = DateTool.getLocalDate(currSubset.date2);// right border in data
				tmp = Conv.getDouble(currSubset.meterValue);

				if (currDate1.isAfter(calcDate)) {
					continue;
				}

				if (currDate1.isBefore(calcDate)) {// because for curr year may be not be actual data
					res = tmp;
				}

				if (currDate1 == calcDate) {// left border hit
					res = tmp;
					break;
				}
				if (currDate2 == calcDate) {// right border hit
					res = tmp;
					break;
				}

				if (currDate1.isBefore(calcDate)) {// range from left border to right border hit
					if (currDate2.isAfter(calcDate)) {
						res = tmp;
						break;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("ModelDto.getChrono, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
			res = 0.0;
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getChrono, res=" + res + ", calcDate=" +
		// calcDate, WB.strEmpty, "ModelDto");
		return res;
	}

	public static void test() throws Exception {
		// origin - 12.10.2023, last edit - 16.09.2024
		try {

//			// reflect
//			var reflectOb = new ModelDto("Id1", "Reflect code", "Reflect description");
//			reflectOb.reflect();

//			// ModelDto ctor clone
//			var res1 = new ModelDto("Id1", "Code1", "Description1");
//			WB.addLog2("ModelDto.test.ctor(Id, Code, Description), res1=" + res1, WB.strEmpty, "ModelDto");
//			var res1Clone = new ModelDto(res1);
//			WB.addLog2("ModelDto.test.ctor(res1), res1Clone=" + res1Clone, WB.strEmpty, "ModelDto");

//			// getId
//			ModelDto newModelDto = new ModelDto();
//			WB.addLog2("ModelDto.test.getId(), res=" + newModelDto.getId(), WB.strEmpty, "ModelDto");
//			WB.addLog2("ModelDto.test.getId('FaceId', 'idIntegerGrowingDigitalGlobal'), res="
//					+ newModelDto.getId("FaceId", "idIntegerGrowingDigitalGlobal"), WB.strEmpty, "ModelDto");

//		// delFieldFromMoreByKey
//		var arg1 = new String[] { "InfoBaseId=P1;", "InfoBaseId=P1;LastEdit=2024-06-25T07:52:43;", "87664gfgf",
//				"231125567453", null };
//		for (var testArg1 : arg1) {
//			WB.addLog2("ModelDto.test.delFieldFromMoreByKey, res=" + delFieldFromMoreByKey(testArg1, "LastEdit")
//					+ ", testArg1=" + testArg1, WB.strEmpty, "ModelDto");
//		}

		} catch (Exception ex) {
			WB.addLog("ModelDto.test, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.test end ", WB.strEmpty, "ModelDto");
	}
}
