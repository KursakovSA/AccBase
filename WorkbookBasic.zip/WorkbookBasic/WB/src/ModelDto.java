import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class ModelDto {
	// origin - 30.09.2023, last edit - 13.06.2024

	// common field
	public String table = new String();
	public String id = new String();
	public String parent = new String();
	public String face1 = new String();
	public String face2 = new String();
	public String face = new String();
	public String slice = new String();
	public String date1 = new String();
	public String date2 = new String();
	public String code = new String();
	public String description = new String();
	public String sign = new String();
	public String account = new String();
	public String geo = new String();
	public String role = new String();
	public String info = new String();
	public String meter = new String();
	public String meterValue = new String();
	public String unit = new String();
	public String more = new String();
	public String mark = new String();

	// special field
	public String process = new String();
	public String asset = new String();
	public String deal = new String();
	public String item = new String();
	public String debt = new String();
	public String price = new String();

	{
		this.clear();
	}

//	private static void addLog(Path p, String log) throws Exception {
//		// origin - 05.06.2024, last edit - 05.06.2024
//		try {
//			WB.writeReplace(p, log);
//		} catch (Exception ex) {
//			WB.addLog("ModelDto.addLog, ex=" + ex.getMessage(), "", "ModelDto");
//		} finally {
//			Etc.doNothing();
//		}
//	}

//	private static String getLog(List<ModelDto> dto) throws Exception {//TODO list modeldto to csv
//		// origin - 05.06.2024, last edit - 05.06.2024
//		String res = "";
//		try {
//			//WB.writeReplace(p, log);
//		} catch (Exception ex) {
//			WB.addLog("ModelDto.getLog, ex=" + ex.getMessage(), "", "ModelDto");
//		} finally {
//			Etc.doNothing();
//		}
//		return res;
//	}

//	private static Path getPathLog(String dtoKind) throws Exception {
//		// origin - 05.06.2024, last edit - 05.06.2024
//		Path res = null;
//		try {
//			String pathLog = "";
//			pathLog = pathLog + WB.startDir + File.separator + dtoKind + "_";
//			pathLog = pathLog + DateTool.getLabelDateTimeForFileName();
//			String fileName = InOut.getFileName(WB.lastConn);
//			pathLog = pathLog + fileName;
//			pathLog = pathLog + ".csv";
//			res = Paths.get(pathLog);
//		} catch (Exception ex) {
//			WB.addLog("ModelDto.getPathLog, ex=" + ex.getMessage(), "", "ModelDto");
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("ModelDto.getPathLog, res=" + res, "", "ModelDto");
//		return res;
//	}

//	public static List<ModelDto> removeDuplicate2(List<ModelDto> dtoBase, List<ModelDto> dtoAdd) throws Exception {
//		// origin - 12.06.2024, last edit - 14.06.2024
//		//LocalDateTime localStart = WB.getLocalStart();
//		List<ModelDto> res = new ArrayList<ModelDto>();
//		String strCurrDtoRes = "";
//		String strCurrDtoAdd = "";
//		boolean hasEqualsBaseAdd = false;
//		try {
//
//			if (dtoBase.isEmpty()) {
//				res.addAll(dtoAdd);
//
//			} else {
//				for (var currDtoAdd : dtoAdd) {
//					strCurrDtoAdd = currDtoAdd.toString();// strCurrDtoAdd = currDtoAdd.id;
//					for (var currDtoBase : dtoBase) {
//						strCurrDtoRes = currDtoBase.toString();// strCurrDtoRes = currDtoBase.id;
//						hasEqualsBaseAdd = false;
//						if (strCurrDtoRes.equals(strCurrDtoAdd)) {
//							hasEqualsBaseAdd = true;
//							break;
//						}
//					}
//					if (hasEqualsBaseAdd == false) {
//						res.add(new ModelDto(currDtoAdd));
//					}
//				}
//			}
//
//		} catch (Exception ex) {
//			WB.addLog("ModelDto.removeDuplicate2, ex=" + ex.getMessage(), "", "ModelDto");
//		} finally {
//			Etc.doNothing();
//		}
////		WB.getLocalEnd("ModelDto.removeDuplicate2 for List<ModelDto> dtoBase.size=" + dtoBase.size()
////				+ ", dtoAdd.size=" + dtoAdd.size(), localStart);
////		WB.addLog2("ModelDto.removeDuplicate2, res.size=" + res.size() + ", dtoBase.size=" + dtoBase.size()
////				+ ", dtoAdd.size=" + dtoAdd.size(), "", "ModelDto");
//		return res;
//	}

	public static List<ModelDto> removeDuplicate(List<ModelDto> dtoCollector, List<ModelDto> dtoAdd) throws Exception {
		// origin - 03.06.2024, last edit - 14.06.2024
		LocalDateTime localStart = WB.getLocalStart();
		List<ModelDto> res = new ArrayList<ModelDto>();
		WB.addLog2("ModelDto.removeDuplicate, before work, res.size=" + res.size() + ", dtoCollector.size="
				+ dtoCollector.size() + ", dtoAdd.size=" + dtoAdd.size(), "", "ModelDto");
		String strCurrDtoRes = "";
		String strCurrDtoAdd = "";
		boolean hasEqualsCollectorAdd = false;
		try {

			if (dtoCollector.isEmpty()) {
				res.addAll(dtoAdd);

			} else {
				for (var currDtoAdd : dtoAdd) {
					strCurrDtoAdd = currDtoAdd.toString();// strCurrDtoAdd = currDtoAdd.id;
					for (var currDtoRes : dtoCollector) {
						strCurrDtoRes = currDtoRes.toString();// strCurrDtoRes = currDtoRes.id;
						hasEqualsCollectorAdd = false;
						if (strCurrDtoRes.equals(strCurrDtoAdd)) {
							hasEqualsCollectorAdd = true;
							break;
						}
					}
					if (hasEqualsCollectorAdd == false) {
						res.add(new ModelDto(currDtoAdd));
					}
				}
			}
			res.addAll(dtoCollector);

		} catch (Exception ex) {
			WB.addLog("ModelDto.removeDuplicate, ex=" + ex.getMessage(), "", "ModelDto");
		} finally {
			Etc.doNothing();
		}
		WB.getLocalEnd("ModelDto.removeDuplicate for List<ModelDto> dtoCollector.size=" + dtoCollector.size()
				+ ", dtoAdd.size=" + dtoAdd.size(), localStart);
		WB.addLog2("ModelDto.removeDuplicate, after work, res.size=" + res.size() + ", dtoCollector.size="
				+ dtoCollector.size() + ", dtoAdd.size=" + dtoAdd.size(), "", "ModelDto");
		return res;
	}

	public static List<ModelDto> getTestSubset() throws Exception {
		// origin - 08.02.2024, last edit - 10.06.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			for (var currTable : DAL.getTableList(WB.lastConnWork)) {
				res.add(new ModelDto(currTable, getId(""), getParent(""), getFace1(""), getFace2(""), getFace(""),
						getSlice(""), getDate1(""), getDate2(""), getCode("Test"), getDescription("Test"), getSign(""),
						getAccount(""), getGeo(""), getRole(""), getInfo(""), getMeter(""), getMeterValue(""),
						getUnit(""), getMore(""), getMark(""), getProcess(""), getAsset(""), getDeal(""), getItem(""),
						getDebt(""), getPrice("")));
			}

		} catch (Exception ex) {
			WB.addLog("ModelDto.getTestSubset, ex=" + ex.getMessage(), "", "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getTestSubset, res.size=" + res.size(),"", "ModelDto");
		return res;
	}

	private static String getPrice(String price) throws Exception {
		// origin - 09.02.2024, last edit - 17.06.2024
		String res = Etc.fixTrim(price);
		if (res.isEmpty()) {
			res = Price.root.code;
		}
		// WB.addLog2("ModelDto.getPrice, res=" + res,"", "ModelDto");
		return res;
	}

	private static String getDebt(String debt) throws Exception {
		// origin - 09.02.2024, last edit - 17.06.2024
		String res = Etc.fixTrim(debt);
		if (res.isEmpty()) {
			res = Debt.root.code;
		}
		// WB.addLog2("ModelDto.getDebt, res=" + res,"", "ModelDto");
		return res;
	}

	private static String getItem(String item) throws Exception {
		// origin - 09.02.2024, last edit - 17.06.2024
		String res = Etc.fixTrim(item);
		if (res.isEmpty()) {
			res = Item.root.code;
		}
		// WB.addLog2("ModelDto.getItem, res=" + res,"", "ModelDto");
		return res;
	}

	private static String getDeal(String deal) throws Exception {
		// origin - 09.02.2024, last edit - 17.06.2024
		String res = Etc.fixTrim(deal);
		if (res.isEmpty()) {
			res = Deal.root.code;
		}
		// WB.addLog2("ModelDto.getDeal, res=" + res,"", "ModelDto");
		return res;
	}

	private static String getAsset(String asset) throws Exception {
		// origin - 09.02.2024, last edit - 17.06.2024
		String res = Etc.fixTrim(asset);
		if (res.isEmpty()) {
			res = Asset.root.code;
		}
		// WB.addLog2("ModelDto.getAsset, res=" + res,"", "ModelDto");
		return res;
	}

	private static String getProcess(String process) throws Exception {
		// origin - 09.02.2024, last edit - 17.06.2024
		String res = Etc.fixTrim(process);
		if (res.isEmpty()) {
			res = Process.root.code;
		}
		// WB.addLog2("ModelDto.getProcess, res=" + res,"", "ModelDto");
		return res;
	}

	private static String getMark(String mark) throws Exception {
		// origin - 09.02.2024, last edit - 17.06.2024
		String res = Etc.fixTrim(mark);
		if (res.isEmpty()) {
			res = Mark.root.code;
		}
		// WB.addLog2("ModelDto.getMark, res=" + res,"", "ModelDto");
		return res;
	}

	private static String getMore(String more) throws Exception {
		// origin - 09.02.2024, last edit - 17.06.2024
		String res = Etc.fixTrim(more);
		if (res.isEmpty()) {
			res = "More";
		}
		// WB.addLog2("ModelDto.getMore, res=" + res,"", "ModelDto");
		return res;
	}

	private static String getUnit(String unit) throws Exception {
		// origin - 09.02.2024, last edit - 17.06.2024
		String res = Etc.fixTrim(unit);
		if (res.isEmpty()) {
			res = Unit.root.code;
		}
		// WB.addLog2("ModelDto.getUnit, res=" + res,"", "ModelDto");
		return res;
	}

	private static String getMeterValue(String meterValue) throws Exception {
		// origin - 09.02.2024, last edit - 17.06.2024
		String res = Etc.fixTrim(meterValue);
		if (res.isEmpty()) {
			res = "MeterValue";
		}
		// WB.addLog2("ModelDto.getMeterValue, res=" + res,"", "ModelDto");
		return res;
	}

	private static String getMeter(String meter) throws Exception {
		// origin - 09.02.2024, last edit - 17.06.2024
		String res = Etc.fixTrim(meter);
		if (res.isEmpty()) {
			res = Meter.root.code;
		}
		// WB.addLog2("ModelDto.getMeter, res=" + res,"", "ModelDto");
		return res;
	}

	private static String getInfo(String info) throws Exception {
		// origin - 09.02.2024, last edit - 17.06.2024
		String res = Etc.fixTrim(info);
		if (res.isEmpty()) {
			res = Info.root.code;
		}
		// WB.addLog2("ModelDto.getInfo, res=" + res,"", "ModelDto");
		return res;
	}

	private static String getRole(String role) throws Exception {
		// origin - 09.02.2024, last edit - 17.06.2024
		String res = Etc.fixTrim(role);
		if (res.isEmpty()) {
			res = Role.root.code;
		}
		// WB.addLog2("ModelDto.getRole, res=" + res,"", "ModelDto");
		return res;
	}

	private static String getGeo(String geo) throws Exception {
		// origin - 09.02.2024, last edit - 17.06.2024
		String res = Etc.fixTrim(geo);
		if (res.isEmpty()) {
			res = Geo.root.code;
		}
		// WB.addLog2("ModelDto.getGeo, res=" + res,"", "ModelDto");
		return res;
	}

	private static String getAccount(String account) throws Exception {
		// origin - 09.02.2024, last edit - 17.06.2024
		String res = Etc.fixTrim(account);
		if (res.isEmpty()) {
			res = Account.root.code;
		}
		// WB.addLog2("ModelDto.getAccount, res=" + res,"", "ModelDto");
		return res;
	}

	private static String getSign(String sign) throws Exception {
		// origin - 09.02.2024, last edit - 17.06.2024
		String res = Etc.fixTrim(sign);
		if (res.isEmpty()) {
			res = Sign.root.code;
		}
		// WB.addLog2("ModelDto.getSign, res=" + res,"", "ModelDto");
		return res;
	}

	private static String getDescription(String description) throws Exception {
		// origin - 09.02.2024, last edit - 17.06.2024
		String res = Etc.fixTrim(description);
		if (res.isEmpty()) {
			res = "Description";
		}
		// WB.addLog2("ModelDto.getDescription, res=" + res, "", "ModelDto");
		return res;
	}

	private static String getCode(String code) throws Exception {
		// origin - 09.02.2024, last edit - 17.06.2024
		String res = Etc.fixTrim(code);
		if (res.isEmpty()) {
			res = "Code";
		}
		// WB.addLog2("ModelDto.getCode, res=" + res, "", "ModelDto");
		return res;
	}

	private static String getDate2(String date2) throws Exception {
		// origin - 09.02.2024, last edit - 17.06.2024
		String res = Etc.fixTrim(date2);
		if (res.isEmpty()) {
			try {
				res = DateTool.getLocalDate("").toString();

			} catch (Exception ex) {
				WB.addLog("ModelDto.getIDate2, ex=" + ex.getMessage(), "", "ModelDto");
			} finally {
				Etc.doNothing();
			}
		}
		// WB.addLog2("ModelDto.getDate2, res=" + res,"", "ModelDto");
		return res;
	}

	private static String getDate1(String date1) throws Exception {
		// origin - 09.02.2024, last edit - 17.06.2024
		String res = Etc.fixTrim(date1);
		if (res.isEmpty()) {
			try {
				res = DateTool.getLocalDate("").toString();

			} catch (Exception ex) {
				WB.addLog("ModelDto.getIDate1, ex=" + ex.getMessage(), "", "ModelDto");
			} finally {
				Etc.doNothing();
			}
		}
		// WB.addLog2("ModelDto.getDate1, res=" + res,"", "ModelDto");
		return res;
	}

	private static String[] getArrayFromStrSplit(String strSplit, String splitSign) throws Exception {
		// origin - 16.06.2024, last edit - 16.06.2024
		String[] res = {};
		res = strSplit.split(splitSign);
		// WB.addLog2("ModelDto.getArrayFromMore, res.lenght=" + res.length, "",
		// "ModelDto");
		return res;
	}

	private static String getValueByKeyFromEquation(String[] equation, String key) throws Exception {
		// origin - 16.06.2024, last edit - 16.06.2024
		String res = "";
		int indexSignEquals = 0;
		String strKey = "";
		String splitEquation = "=";
		for (var currEquation : equation) {
			indexSignEquals = 0;
			indexSignEquals = currEquation.lastIndexOf(splitEquation);
			if (indexSignEquals > 0) {
				strKey = "";
				strKey = currEquation.substring(0, indexSignEquals);
				if (strKey.isEmpty() == false) {
					if (Etc.strEquals(key, strKey)) {
						res = currEquation.substring(indexSignEquals + 1, currEquation.length());
					}
				}
			}

		}
		// WB.addLog2("ModelDto.getValueByKeyFromEquation, res=" + res + ", key=" + key,
		// "", "ModelDto");
		return res;
	}
	
	public static String getValueFromMoreByKey(ModelDto dto, String key) throws Exception {
		// origin - 17.06.2024, last edit - 17.06.2024
		String res = "";
		List<ModelDto> listDto = new ArrayList<ModelDto>();
		listDto.add(dto);
		res = getValueFromMoreByKey(listDto, key);
		//WB.addLog2("ModelDto.getValueFromMoreByKey, res=" + res, "", "ModelDto");
		return res;
	}
	
	public static String getValueFromMoreByKey(List<ModelDto> dto, String key) throws Exception {
		// origin - 17.06.2024, last edit - 17.06.2024
		String res = "";
		String[] items = {};
		String splitValueInMore = ";";
		for (var currDto : dto) {
			items = getArrayFromStrSplit(currDto.more, splitValueInMore);  //if value are diffferent in list ???
			res = getValueByKeyFromEquation(items, key);
		}
		//WB.addLog2("ModelDto.getValueFromMoreByKey, res=" + res, "", "ModelDto");
		return res;
	}

	private static String getInfoBaseId(String conn) throws Exception {
		// origin - 25.05.2024, last edit - 17.06.2024
		String res = "";
		res = getValueFromMoreByKey(WB.abcLast.infoBaseId, "infoBaseId");
//		String[] items = {};
//		for (var currInfoBaseId : WB.abcLast.infoBaseId) {
//			items = getArrayFromStrSplit(currInfoBaseId.more, ";");
//			res = getValueByKeyFromEquation(items, "infoBaseId");
//		}

		if (res.isEmpty()) {
			res = "IB1"; // default infoBaseId //TOTHINK - do common place when default values store
							// ?????
		}
		// WB.addLog2("ModelDto.getInfoBaseId, res=" + res, "", "ModelDto");
		return res;
	}

	private static String getId(String id) throws Exception {
		// origin - 09.02.2024, last edit - 17.06.2024
		String res = Etc.fixTrim(id);
		if (res.isEmpty()) {
			try {
				res = formatter2(res, getInfoBaseId(WB.lastConnWork));
				res = res + DateTool.formatter2(DateTool.getLocalDateTimeNow());
				res = res + "#" + Etc.getIntRnd(100000);

			} catch (Exception ex) {
				WB.addLog("ModelDto.getId, ex=" + ex.getMessage(), "", "ModelDto");
			} finally {
				Etc.doNothing();
			}
		}
		// WB.addLog2("ModelDto.getId, res=" + res, "", "ModelDto");
		return res;
	}

	private static String getParent(String parent) throws Exception {
		// origin - 09.02.2024, last edit - 17.06.2024
		String res = Etc.fixTrim(parent);
		// WB.addLog2("ModelDto.getParent, res=" + res,"", "ModelDto");
		return res;
	}

	private static String getFace1(String face1) throws Exception {
		// origin - 09.02.2024, last edit - 17.06.2024
		String res = Etc.fixTrim(face1);
		if (res.isEmpty()) {
			res = Face.root.code;
		}
		// WB.addLog2("ModelDto.getFace1, res=" + res,"", "ModelDto");
		return res;
	}

	private static String getFace2(String face2) throws Exception {
		// origin - 09.02.2024, last edit - 17.06.2024
		String res = Etc.fixTrim(face2);
		if (res.isEmpty()) {
			res = Face.root.code;
		}
		// WB.addLog2("ModelDto.getFace2, res=" + res,"", "ModelDto");
		return res;
	}

	private static String getFace(String face) throws Exception {
		// origin - 09.02.2024, last edit - 17.06.2024
		String res = Etc.fixTrim(face);
		if (res.isEmpty()) {
			res = Face.root.code;
		}
		// WB.addLog2("ModelDto.getFace, res=" + res,"", "ModelDto");
		return res;
	}

	public static String getSlice(String slice) throws Exception {
		// origin - 09.02.2024, last edit - 17.06.2024
		String res = Etc.fixTrim(slice);
		if (res.isEmpty()) {
			res = Slice.root.code;
		}
		// WB.addLog2("ModelDto.getSlice, res=" + res,"", "ModelDto");
		return res;
	}

	public static ModelDto getFilter(String subStrCode, String subStrMeter) throws Exception {
		// origin - 09.01.2024, last edit - 17.06.2024
		ModelDto res = new ModelDto();
		if (subStrCode.isEmpty() == false) {
			res.code = subStrCode;
		}
		if (subStrMeter.isEmpty() == false) {
			res.meter = subStrMeter;
		}
		// WB.addLog("ModelDto.getFilterDto, res=" + res, "", "ModelDto");
		return res;
	}

	public static List<ModelDto> getSubset(List<ModelDto> set, ModelDto filter) throws Exception {
		// origin - 08.01.2024, last edit - 23.05.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		List<ModelDto> tmp = set;
		String allFilter = "";
		try {
			if (filter.more.isEmpty() == false) {
				allFilter = allFilter + "filter.more=" + filter.more + ", ";
				tmp = getSubsetByMore(tmp, filter.more);
			}
			if (filter.code.isEmpty() == false) {
				allFilter = allFilter + "filter.code=" + filter.code + ", ";
				tmp = getSubsetByCode(tmp, filter.code);
			}
			if (filter.meter.isEmpty() == false) {
				allFilter = allFilter + "filter.meter=" + filter.meter + ", ";
				tmp = getSubsetByMeter(tmp, filter.meter);
			}
		} catch (Exception ex) {
			WB.addLog("ModelDto.getSubset, ex=" + ex.getMessage(), "", "ModelDto");
		} finally {
			Etc.doNothing();
		}
		res = tmp;
		// WB.addLog2("ModelDto.getSubset, res.size=" + res.size() + ", allFilter=" +
		// allFilter, "", "ModelDto");
		return res;
	}

	public static List<ModelDto> getSubsetByMeter(List<ModelDto> set, String subStr) throws Exception {
		// origin - 07.01.2024, last edit - 23.05.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = set.stream();
			basicStream.filter(n -> n.meter.toLowerCase().contains(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ModelDto.getSubsetMeter, ex=" + ex.getMessage(), "", "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getSubsetByMeter, res.size=" + res.size() + ", subStr="
		// +
		// subStr, "", "ModelDto");
		return res;
	}

	public static List<ModelDto> getSubsetByCode(List<ModelDto> set, String subStr) throws Exception {
		// origin - 07.01.2024, last edit - 23.05.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = set.stream();
			basicStream.filter(n -> n.code.toLowerCase().contains(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ModelDto.getSubsetCode, ex=" + ex.getMessage(), "", "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getSubsetByCode, res.size=" + res.size() + ", subStr=" +
		// subStr, "", "ModelDto");
		return res;
	}

	public static List<ModelDto> getSubsetByMore(List<ModelDto> set, String subStr) throws Exception {
		// origin - 29.11.2023, last edit - 23.05.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = set.stream();
			basicStream.filter(n -> n.more.toLowerCase().contains(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ModelDto.getSubsetMore, ex=" + ex.getMessage(), "", "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getSubsetMore, res.size=" + res.size() + ", subStr=" +
		// subStr, "", "ModelDto");
		return res;
	}

	public ModelDto(ModelDto in) {
		// origin - 02.01.2024, last edit - 02.01.2024
		this.table = in.table;
		this.id = in.id;
		this.parent = in.parent;
		this.face1 = in.face1;
		this.face2 = in.face2;
		this.face = in.face;
		this.slice = in.slice;
		this.date1 = in.date1;
		this.date2 = in.date2;
		this.code = in.code;
		this.description = in.description;
		this.sign = in.sign;
		this.account = in.account;
		this.geo = in.geo;
		this.role = in.role;
		this.info = in.info;
		this.meter = in.meter;
		this.meterValue = in.meterValue;
		this.unit = in.unit;
		this.more = in.more;
		this.mark = in.mark;
		this.process = in.process;
		this.asset = in.asset;
		this.deal = in.deal;
		this.item = in.item;
		this.debt = in.debt;
		this.price = in.price;
	}

	public ModelDto(String Table, String Id, String Parent, String Face1, String Face2, String Face, String Slice,
			String Date1, String Date2, String Code, String Description, String Sign, String Account, String Geo,
			String Role, String Info, String Meter, String MeterValue, String Unit, String More, String Mark,
			String Process, String Asset, String Deal, String Item, String Debt, String Price) {
		// origin - 02.11.2023, last edit - 25.11.2023
		this.table = Table;
		this.id = Id;
		this.parent = Parent;
		this.face1 = Face1;
		this.face2 = Face2;
		this.face = Face;
		this.slice = Slice;
		this.date1 = Date1;
		this.date2 = Date2;
		this.code = Code;
		this.description = Description;
		this.sign = Sign;
		this.account = Account;
		this.geo = Geo;
		this.role = Role;
		this.info = Info;
		this.meter = Meter;
		this.meterValue = MeterValue;
		this.unit = Unit;
		this.more = More;
		this.mark = Mark;
		this.process = Process;
		this.asset = Asset;
		this.deal = Deal;
		this.item = Item;
		this.debt = Debt;
		this.price = Price;
	}

	public void clear() {
		// origin - 31.12.2023, last edit - 31.12.2023
		this.table = "";
		this.id = "";
		this.parent = "";
		this.face1 = "";
		this.face2 = "";
		this.face = "";
		this.slice = "";
		this.date1 = "";
		this.date2 = "";
		this.code = "";
		this.description = "";
		this.sign = "";
		this.account = "";
		this.geo = "";
		this.role = "";
		this.info = "";
		this.meter = "";
		this.meterValue = "";
		this.unit = "";
		this.more = "";
		this.mark = "";
		this.process = "";
		this.asset = "";
		this.deal = "";
		this.item = "";
		this.debt = "";
		this.price = "";
	}

	public ModelDto() {
		// origin - 02.11.2023, last edit - 08.01.2024
		this.clear();
	}

	public static void test() throws Exception {
		// origin - 12.10.2023, last edit - 18.02.2024
		// getTestSubset();
		for (int i = 0; i <= 10; i++) {
			getId("");
		}
	}

	public static void toList(List<ModelDto> lst, String descr) throws Exception {
		// origin - 26.01.2024, last edit - 26.01.2024
		for (var currModelDto : lst) {
			WB.addLog2("ModelDto.toList, currModelDto=" + currModelDto.toString() + ", descr=" + descr, "", "ModelDto");
		}
	}

	public static String formatter2(String name, String strAdd) {
		// origin - 15.06.2024, last edit - 15.06.2024
		String res = "";
		strAdd = Etc.fixTrim(strAdd);
		try {
			if (strAdd.isEmpty() == false) {
				res = res + "[" + strAdd + "]"; // for PointId, InfoBase1 in ModelDto.Id
			}
		} catch (Exception ex) {
			WB.addLog2("ModelDto.formatter2, ex=" + ex.getMessage(), "", "ModelDto");
		} finally {
		}
		return res;
	}

	public static String formatter(String name, String strAdd) {
		// origin - 01.12.2023, last edit - 15.06.2024
		String res = "";
		strAdd = Etc.fixTrim(strAdd);
		try {
			if (strAdd.isEmpty() == false) {
				res = res + Etc.fixTrim(name) + "=" + strAdd + ", ";
			}
		} catch (Exception ex) {
			WB.addLog2("ModelDto.formatter, ex=" + ex.getMessage(), "", "ModelDto");
		} finally {
		}
		return res;
	}

	public static String appender(String strRes, String strAdd) {
		// origin - 01.12.2023, last edit - 26.01.2024
		String res = strRes;
		if (strAdd.isEmpty() != true) {
			res = res + strAdd;
		}
		return res;
	}

	public String toString() {
		// origin - 30.09.2023, last edit - 11.01.2024
		String res = "";
		res = appender(res, formatter("table", this.table));
		res = appender(res, formatter("id", this.id));
		res = appender(res, formatter("parent", this.parent));
		res = appender(res, formatter("face1", this.face1));
		res = appender(res, formatter("face2", this.face2));
		res = appender(res, formatter("face", this.face));
		res = appender(res, formatter("slice", this.slice));
		res = appender(res, formatter("date1", this.date1));
		res = appender(res, formatter("date2", this.date2));
		res = appender(res, formatter("code", this.code));
		res = appender(res, formatter("description", this.description));
		res = appender(res, formatter("sign", this.sign));
		res = appender(res, formatter("account", this.account));
		res = appender(res, formatter("geo", this.geo));
		res = appender(res, formatter("role", this.role));
		res = appender(res, formatter("info", this.info));
		res = appender(res, formatter("meter", this.meter));
		res = appender(res, formatter("meterValue", this.meterValue));
		res = appender(res, formatter("unit", this.unit));
		res = appender(res, formatter("more", this.more));
		res = appender(res, formatter("mark", this.mark));
		res = appender(res, formatter("process", this.process));
		res = appender(res, formatter("asset", this.asset));
		res = appender(res, formatter("deal", this.deal));
		res = appender(res, formatter("item", this.item));
		res = appender(res, formatter("debt", this.debt));
		res = appender(res, formatter("price", this.price));
		res = "{" + res + "}";
		return res;
	}
}
