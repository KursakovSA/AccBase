import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class ModelDto {
	// origin - 30.09.2023, last edit - 07.01.2024
	// common field
	public String table = new String();
	public String id = new String();
	public String parent = new String();
	public String face1 = new String();
	public String face2 = new String();
	public String face = new String();
	public String slice = new String();
	public String date1 = new String();
	public String date2 = new String();
	public String code = new String();
	public String description = new String();
	public String sign = new String();
	public String account = new String();
	public String geo = new String();
	public String role = new String();
	public String info = new String();
	public String meter = new String();
	public String meterValue = new String();
	public String unit = new String();
	public String more = new String();
	public String mark = new String();

	// special field
	public String process;
	public String asset;
	public String deal;
	public String item;
	public String debt;
	public String price;

	{
		// origin - 08.11.2023, last edit - 25.11.2023
		this.table = "";
		this.id = "";
		this.parent = "";
		this.code = "";
		this.description = "";
		this.more = "";
	}
	
	public static List<ModelDto> getSubsetMeter(List<ModelDto> set, String subStr) throws Exception {
		// origin - 07.01.2024, last edit - 07.01.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = set.stream();
			basicStream.filter(n -> n.meter.toLowerCase().contains(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			Logger.add("Abc.getSubsetMeter, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "Abc");
		} finally {
			Etc.doNothing();
		}
		// Logger.add2("Abc.getSubsetMeter, res.size=" + res.size() + ", subStr=" + subStr, "", "Abc");
		return res;
	}
	
	public static List<ModelDto> getSubsetCode(List<ModelDto> set, String subStr) throws Exception {
		// origin - 07.01.2024, last edit - 07.01.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = set.stream();
			basicStream.filter(n -> n.code.toLowerCase().contains(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			Logger.add("Abc.getSubsetCode, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "Abc");
		} finally {
			Etc.doNothing();
		}
		// Logger.add2("Abc.getSubsetCode, res.size=" + res.size() + ", subStr=" + subStr, "", "Abc");
		return res;
	}
	
	public static List<ModelDto> getSubsetMore(List<ModelDto> set, String subStr) throws Exception {
		// origin - 29.11.2023, last edit - 07.01.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = set.stream();
			basicStream.filter(n -> n.more.toLowerCase().contains(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			Logger.add("Abc.getSubsetMore, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "Abc");
		} finally {
			Etc.doNothing();
		}
		// Logger.add2("Abc.getSubsetMore, res.size=" + res.size() + ", subStr=" + subStr, "", "Abc");
		return res;
	}
	
	public ModelDto(ModelDto in) {
		// origin - 02.01.2024, last edit - 02.01.2024
		this.table = in.table;
		this.id = in.id;
		this.parent = in.parent;
		this.face1 = in.face1;
		this.face2 = in.face2;
		this.face = in.face;
		this.slice = in.slice;
		this.date1 = in.date1;
		this.date2 = in.date2;
		this.code = in.code;
		this.description = in.description;
		this.sign = in.sign;
		this.account = in.account;
		this.geo = in.geo;
		this.role = in.role;
		this.info = in.info;
		this.meter = in.meter;
		this.meterValue = in.meterValue;
		this.unit = in.unit;
		this.more = in.more;
		this.mark = in.mark;
		this.process = in.process;
		this.asset = in.asset;
		this.deal = in.deal;
		this.item = in.item;
		this.debt = in.debt;
		this.price = in.price;
	}

	public ModelDto(String Table, String Id, String Parent, String Face1, String Face2, String Face, String Slice,
			String Date1, String Date2, String Code, String Description, String Sign, String Account, String Geo,
			String Role, String Info, String Meter, String MeterValue, String Unit, String More, String Mark,
			String Process, String Asset, String Deal, String Item, String Debt, String Price) {
		// origin - 02.11.2023, last edit - 25.11.2023
		this.table = Table;
		this.id = Id;
		this.parent = Parent;
		this.face1 = Face1;
		this.face2 = Face2;
		this.face = Face;
		this.slice = Slice;
		this.date1 = Date1;
		this.date2 = Date2;
		this.code = Code;
		this.description = Description;
		this.sign = Sign;
		this.account = Account;
		this.geo = Geo;
		this.role = Role;
		this.info = Info;
		this.meter = Meter;
		this.meterValue = MeterValue;
		this.unit = Unit;
		this.more = More;
		this.mark = Mark;
		this.process = Process;
		this.asset = Asset;
		this.deal = Deal;
		this.item = Item;
		this.debt = Debt;
		this.price = Price;
	}

	public void clear() {
		// origin - 31.12.2023, last edit - 31.12.2023
		this.table = "";
		this.id = "";
		this.parent = "";
		this.face1 = "";
		this.face2 = "";
		this.face = "";
		this.slice = "";
		this.date1 = "";
		this.date2 = "";
		this.code = "";
		this.description = "";
		this.sign = "";
		this.account = "";
		this.geo = "";
		this.role = "";
		this.info = "";
		this.meter = "";
		this.meterValue = "";
		this.unit = "";
		this.more = "";
		this.mark = "";
		this.process = "";
		this.asset = "";
		this.deal = "";
		this.item = "";
		this.debt = "";
		this.price = "";
	}

	public ModelDto() {
		// origin - 02.11.2023, last edit - 22.11.2023
		this.id = "";
	}

	public static void test() throws Exception {
		// origin - 12.10.2023, last edit - 01.12.2023
//		ModelDto testModelDto = new ModelDto();
//    	Logger.add("ModelDto.test, testModelDto=" + testModelDto, "", "modelDto");
	}

	public static String formatter(String name, String strAdd) {
		// origin - 01.12.2023, last edit - 05.12.2023
		String res = "";
		strAdd = Etc.fixTrim(strAdd);
		try {
			if (strAdd.isEmpty() != true) {
				res = res + Etc.fixTrim(name) + "=" + strAdd + ", ";
			}
		} catch (Exception ex) {
			Logger.add2("ModelDto.formatter, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "",
					"ModelDto");
		} finally {
		}
		return res;
	}

	public static String appender(String strRes, String strAdd) {
		// origin - 01.12.2023, last edit - 02.12.2023
		String res = strRes;
		if (strAdd.isEmpty() != true) {
			res = res + strAdd;
		}
		return res;
	}

	public String toString() {
		// origin - 30.09.2023, last edit - 02.12.2023
		String res = "";
		res = appender(res, formatter("table", this.table));
		res = appender(res, formatter("id", this.id));
		res = appender(res, formatter("parent", this.parent));
		res = appender(res, formatter("date1", this.date1));
		res = appender(res, formatter("date2", this.date2));
		res = appender(res, formatter("code", this.code));
		res = appender(res, formatter("description", this.description));
		res = appender(res, formatter("more", this.more));
		res = "{" + res + "}";
		return res;
	}
}
