import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class ModelDto {
	// origin - 30.09.2023, last edit - 28.06.2024

	// common field
	public String table = new String();
	public String id = new String();
	public String parent = new String();
	public String face1 = new String();
	public String face2 = new String();
	public String face = new String();
	public String slice = new String();
	public String date1 = new String();
	public String date2 = new String();
	public String code = new String();
	public String description = new String();
	public String sign = new String();
	public String account = new String();
	public String geo = new String();
	public String role = new String();
	public String info = new String();
	public String meter = new String();
	public String meterValue = new String();
	public String unit = new String();
	public String more = new String();
	public String mark = new String();

	// special field
	public String process = new String();
	public String asset = new String();
	public String deal = new String();
	public String item = new String();
	public String debt = new String();
	public String price = new String();

	public static String defaultInfoBaseId = new String();

	static {
		try {
			defaultInfoBaseId = "IB1";
		} catch (Exception ex) {
			WB.addLog("ModelDto.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
	}

	{
		this.clear();
	}

//	private static void addLog(Path p, String log) throws Exception {
//		// origin - 05.06.2024, last edit - 27.06.2024
//		try {
//			WB.writeReplace(p, log);
//		} catch (Exception ex) {
//			WB.addLog("ModelDto.addLog, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
//		} finally {
//			Etc.doNothing();
//		}
//	}

//	private static String getLog(List<ModelDto> dto) throws Exception {//TODO list modeldto to csv
//		// origin - 05.06.2024, last edit - 27.06.2024
//		String res = WB.strEmpty;
//		try {
//			//WB.writeReplace(p, log);
//		} catch (Exception ex) {
//			WB.addLog("ModelDto.getLog, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
//		} finally {
//			Etc.doNothing();
//		}
//		return res;
//	}

//	private static Path getPathLog(String dtoKind) throws Exception {
//		// origin - 05.06.2024, last edit - 27.06.2024
//		Path res = null;
//		try {
//			String pathLog = WB.strEmpty;
//			pathLog = pathLog + WB.startDir + File.separator + dtoKind + "_";
//			pathLog = pathLog + DateTool.getLabelDateTimeForFileName();
//			String fileName = InOut.getFileName(WB.lastConn);
//			pathLog = pathLog + fileName;
//			pathLog = pathLog + ".csv";
//			res = Paths.get(pathLog);
//		} catch (Exception ex) {
//			WB.addLog("ModelDto.getPathLog, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("ModelDto.getPathLog, res=" + res, WB.strEmpty, "ModelDto");
//		return res;
//	}

//	public static List<ModelDto> removeDuplicate2(List<ModelDto> dtoBase, List<ModelDto> dtoAdd) throws Exception {
//		// origin - 12.06.2024, last edit - 27.06.2024
//		//LocalDateTime localStart = WB.getLocalStart();
//		List<ModelDto> res = new ArrayList<ModelDto>();
//		String strCurrDtoRes = WB.strEmpty;
//		String strCurrDtoAdd = WB.strEmpty;
//		boolean hasEqualsBaseAdd = false;
//		try {
//
//			if (dtoBase.isEmpty()) {
//				res.addAll(dtoAdd);
//
//			} else {
//				for (var currDtoAdd : dtoAdd) {
//					strCurrDtoAdd = currDtoAdd.toString();// strCurrDtoAdd = currDtoAdd.id;
//					for (var currDtoBase : dtoBase) {
//						strCurrDtoRes = currDtoBase.toString();// strCurrDtoRes = currDtoBase.id;
//						hasEqualsBaseAdd = false;
//						if (strCurrDtoRes.equals(strCurrDtoAdd)) {
//							hasEqualsBaseAdd = true;
//							break;
//						}
//					}
//					if (hasEqualsBaseAdd == false) {
//						res.add(new ModelDto(currDtoAdd));
//					}
//				}
//			}
//
//		} catch (Exception ex) {
//			WB.addLog("ModelDto.removeDuplicate2, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
//		} finally {
//			Etc.doNothing();
//		}
////		WB.getLocalEnd("ModelDto.removeDuplicate2 for List<ModelDto> dtoBase.size=" + dtoBase.size()
////				+ ", dtoAdd.size=" + dtoAdd.size(), localStart);
////		WB.addLog2("ModelDto.removeDuplicate2, res.size=" + res.size() + ", dtoBase.size=" + dtoBase.size()
////				+ ", dtoAdd.size=" + dtoAdd.size(), WB.strEmpty, "ModelDto");
//		return res;
//	}

	public static List<ModelDto> removeDuplicate(List<ModelDto> dtoCollector, List<ModelDto> dtoAdd) throws Exception {
		// origin - 03.06.2024, last edit - 27.06.2024
		LocalDateTime localStart = WB.getLocalStart();
		List<ModelDto> res = new ArrayList<ModelDto>();
		WB.addLog2("ModelDto.removeDuplicate, before work, res.size=" + res.size() + ", dtoCollector.size="
				+ dtoCollector.size() + ", dtoAdd.size=" + dtoAdd.size(), WB.strEmpty, "ModelDto");
		String strCurrDtoRes = WB.strEmpty;
		String strCurrDtoAdd = WB.strEmpty;
		boolean hasEqualsCollectorAdd = false;
		try {

			if (dtoCollector.isEmpty()) {
				res.addAll(dtoAdd);

			} else {
				for (var currDtoAdd : dtoAdd) {
					strCurrDtoAdd = currDtoAdd.toString();// strCurrDtoAdd = currDtoAdd.id;
					for (var currDtoRes : dtoCollector) {
						strCurrDtoRes = currDtoRes.toString();// strCurrDtoRes = currDtoRes.id;
						hasEqualsCollectorAdd = false;
						if (strCurrDtoRes.equals(strCurrDtoAdd)) {
							hasEqualsCollectorAdd = true;
							break;
						}
					}
					if (hasEqualsCollectorAdd == false) {
						res.add(new ModelDto(currDtoAdd));
					}
				}
			}
			res.addAll(dtoCollector);

		} catch (Exception ex) {
			WB.addLog("ModelDto.removeDuplicate, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		WB.getLocalEnd("ModelDto.removeDuplicate for List<ModelDto> dtoCollector.size=" + dtoCollector.size()
				+ ", dtoAdd.size=" + dtoAdd.size(), localStart);
		WB.addLog2("ModelDto.removeDuplicate, after work, res.size=" + res.size() + ", dtoCollector.size="
				+ dtoCollector.size() + ", dtoAdd.size=" + dtoAdd.size(), WB.strEmpty, "ModelDto");
		return res;
	}

	public static List<ModelDto> getTestSubset(String table, int numberRecord) throws Exception {
		// origin - 26.06.2024, last edit - 28.06.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			for (int i = 0; i < numberRecord; i++) {
				res.add(new ModelDto(table, getId(table, WB.strEmpty), getParent(WB.strEmpty), getFace1(WB.strEmpty),
						getFace2(WB.strEmpty), getFace(WB.strEmpty), getSlice(WB.strEmpty), getDate1(WB.strEmpty),
						getDate2(WB.strEmpty), getCode("Test"), getDescription("Test"), getSign(WB.strEmpty),
						getAccount(WB.strEmpty), getGeo(WB.strEmpty), getRole(WB.strEmpty), getInfo(WB.strEmpty),
						getMeter(WB.strEmpty), getMeterValue(WB.strEmpty), getUnit(WB.strEmpty), getMore(WB.strEmpty),
						getMark(WB.strEmpty), getProcess(WB.strEmpty), getAsset(WB.strEmpty), getDeal(WB.strEmpty),
						getItem(WB.strEmpty), getDebt(WB.strEmpty), getPrice(WB.strEmpty)));
			}

		} catch (Exception ex) {
			WB.addLog("ModelDto.getTestSubset(table, numberRecord), ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getTestSubset(table, numberRecord), res.size=" +
		// res.size(), WB.strEmpty, "ModelDto");
		return res;
	}

	public static List<ModelDto> getTestSubset(List<List<String>> testTable) throws Exception {
		// origin - 08.02.2024, last edit - 27.06.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			for (var currTable : testTable) {
				res.addAll(getTestSubset(currTable.get(0), Integer.parseInt(currTable.get(1))));
			}

		} catch (Exception ex) {
			WB.addLog("ModelDto.getTestSubset(numberRecord), ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getTestSubset, res.size=" + res.size(), WB.strEmpty,
		// "ModelDto");
		return res;
	}

	private static String getPrice(String price) throws Exception {
		// origin - 09.02.2024, last edit - 05.07.2024
		String res = Etc.fixTrim(price);
		// WB.addLog2("ModelDto.getPrice, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	private static String getDebt(String debt) throws Exception {
		// origin - 09.02.2024, last edit - 01.07.2024
		String res = Etc.fixTrim(debt);
		// WB.addLog2("ModelDto.getDebt, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	private static String getItem(String item) throws Exception {
		// origin - 09.02.2024, last edit - 01.07.2024
		String res = Etc.fixTrim(item);
		// WB.addLog2("ModelDto.getItem, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	private static String getDeal(String deal) throws Exception {
		// origin - 09.02.2024, last edit - 01.07.2024
		String res = Etc.fixTrim(deal);
		// WB.addLog2("ModelDto.getDeal, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	private static String getAsset(String asset) throws Exception {
		// origin - 09.02.2024, last edit - 01.07.2024
		String res = Etc.fixTrim(asset);
		// WB.addLog2("ModelDto.getAsset, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	private static String getProcess(String process) throws Exception {
		// origin - 09.02.2024, last edit - 01.07.2024
		String res = Etc.fixTrim(process);
		// WB.addLog2("ModelDto.getProcess, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	private static String getMark(String mark) throws Exception {
		// origin - 09.02.2024, last edit - 01.07.2024
		String res = Etc.fixTrim(mark);
		// WB.addLog2("ModelDto.getMark, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	private static String delFieldFromMoreByKey(String initMore, String delField) throws Exception {
		// origin - 25.06.2024, last edit - 27.06.2024
		String res = WB.strEmpty;
		initMore = Etc.fixTrim(initMore);
		try {
			String[] items = {};
			items = getArrayFromStrSplit(initMore, WB.strSemiColon); // if value are diffferent in list ???
			for (var item : items) {
				if (Etc.strContains(item, delField)) {// skip deleting field
					continue;
				}
				res = res + item;
			}
		} catch (Exception ex) {
			WB.addLog("Etc.delFieldFromMoreByKey, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.delFieldFromMoreByKey, res=" + res + ", initMore=" +
		// initMore, WB.strEmpty, "ModelDto");
		return res;
	}

	private static String getLastEdit(String initRes) throws Exception {
		// origin - 25.06.2024, last edit - 05.07.2024
		String res = Etc.fixTrim(initRes);
		try {
			res = delFieldFromMoreByKey(res, "LastEdit"); // ??? magic string
			res = res + "LastEdit=" + DateTool.formatter2(DateTool.getNow2()) + WB.strSemiColon;
		} catch (Exception ex) {
			WB.addLog("Etc.getLastEdit, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getLastEdit, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	private static String getMore(String more) throws Exception {
		// origin - 09.02.2024, last edit - 05.07.2024
		String res = Etc.fixTrim(more);
		try {
			res = res + getLastEdit(res);
		} catch (Exception ex) {
			WB.addLog("Etc.getMore, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Etc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getMore, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	private static String getUnit(String unit) throws Exception {
		// origin - 09.02.2024, last edit - 01.07.2024
		String res = Etc.fixTrim(unit);
		// WB.addLog2("ModelDto.getUnit, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	private static String getMeterValue(String meterValue) throws Exception {
		// origin - 09.02.2024, last edit - 05.07.2024
		String res = Etc.fixTrim(meterValue);
//		if (res.isEmpty()) {
//			res = "MeterValue";
//		}
		// WB.addLog2("ModelDto.getMeterValue, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	private static String getMeter(String meter) throws Exception {
		// origin - 09.02.2024, last edit - 01.07.2024
		String res = Etc.fixTrim(meter);
		// WB.addLog2("ModelDto.getMeter, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	private static String getInfo(String info) throws Exception {
		// origin - 09.02.2024, last edit - 01.07.2024
		String res = Etc.fixTrim(info);
		// WB.addLog2("ModelDto.getInfo, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	private static String getRole(String role) throws Exception {
		// origin - 09.02.2024, last edit - 01.07.2024
		String res = Etc.fixTrim(role);
		// WB.addLog2("ModelDto.getRole, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	private static String getGeo(String geo) throws Exception {
		// origin - 09.02.2024, last edit - 01.07.2024
		String res = Etc.fixTrim(geo);
		// WB.addLog2("ModelDto.getGeo, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	private static String getAccount(String account) throws Exception {
		// origin - 09.02.2024, last edit - 01.07.2024
		String res = Etc.fixTrim(account);
		// WB.addLog2("ModelDto.getAccount, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	private static String getSign(String sign) throws Exception {
		// origin - 09.02.2024, last edit - 01.07.2024
		String res = Etc.fixTrim(sign);
		// WB.addLog2("ModelDto.getSign, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	private static String getDescription(String description) throws Exception {
		// origin - 09.02.2024, last edit - 05.07.2024
		String res = Etc.fixTrim(description);
//		if (res.isEmpty()) {
//			res = "Description";
//		}
		// WB.addLog2("ModelDto.getDescription, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	private static String getCode(String code) throws Exception {
		// origin - 09.02.2024, last edit - 05.07.2024
		String res = Etc.fixTrim(code);
//		if (res.isEmpty()) {
//			res = "Code";
//		}
		// WB.addLog2("ModelDto.getCode, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	private static String getDate2(String date2) throws Exception {
		// origin - 09.02.2024, last edit - 27.06.2024
		String res = Etc.fixTrim(date2);
		if (res.isEmpty()) {
			try {
				res = DateTool.getLocalDate(WB.strEmpty).toString();

			} catch (Exception ex) {
				WB.addLog("ModelDto.getIDate2, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
			} finally {
				Etc.doNothing();
			}
		}
		// WB.addLog2("ModelDto.getDate2, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	private static String getDate1(String date1) throws Exception {
		// origin - 09.02.2024, last edit - 27.06.2024
		String res = Etc.fixTrim(date1);
		if (res.isEmpty()) {
			try {
				res = DateTool.getLocalDate(WB.strEmpty).toString();

			} catch (Exception ex) {
				WB.addLog("ModelDto.getIDate1, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
			} finally {
				Etc.doNothing();
			}
		}
		// WB.addLog2("ModelDto.getDate1, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	public static String[] getArrayFromStrSplit(String strSplit, String splitSign) throws Exception {
		// origin - 16.06.2024, last edit - 05.07.2024
		String[] res = {};
		try {
			res = strSplit.split(splitSign);
		} catch (Exception ex) {
			WB.addLog("ModelDto.getArrayFromStrSplit, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getArrayFromStrSplit, res.lenght=" + res.length,
		// WB.strEmpty,
		// "ModelDto");
		return res;
	}

	private static String getValueByKeyFromEquation(String[] equation, String key) throws Exception {
		// origin - 16.06.2024, last edit - 05.07.2024
		String res = WB.strEmpty;
		try {
			int indexSignEquals = 0;
			String strKey = WB.strEmpty;
			String splitEquation = "="; // ???magic string
			for (var currEquation : equation) {
				indexSignEquals = 0;
				indexSignEquals = currEquation.lastIndexOf(splitEquation);
				if (indexSignEquals > 0) {
					strKey = WB.strEmpty;
					strKey = currEquation.substring(0, indexSignEquals);
					if (strKey.isEmpty() == false) {
						if (Etc.strEquals(key, strKey)) {
							res = currEquation.substring(indexSignEquals + 1, currEquation.length());
						}
					}
				}

			}
		} catch (Exception ex) {
			WB.addLog("ModelDto.getValueByKeyFromEquation, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getValueByKeyFromEquation, res=" + res + ", key=" + key,
		// WB.strEmpty, "ModelDto");
		return res;
	}

	public static String getValueFromMoreByKey(ModelDto dto, String key, String code) throws Exception {
		// origin - 17.06.2024, last edit - 05.07.2024
		String res = WB.strEmpty;
		try {
			List<ModelDto> listDto = new ArrayList<ModelDto>();
			listDto.add(dto);
			res = getValueFromMoreByKey(listDto, key, code);
		} catch (Exception ex) {
			WB.addLog("ModelDto.getValueFromMoreByKey, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getValueFromMoreByKey, res=" + res, WB.strEmpty,
		// "ModelDto");
		return res;
	}

	public static String getValueFromMoreByKey(List<ModelDto> dto, String key, String code) throws Exception {
		// origin - 17.06.2024, last edit - 05.07.2024
		String res = WB.strEmpty;
		try {
			String[] items = {};
			String splitValueInMore = WB.strSemiColon;
			for (var currDto : dto) {

				// filter by code (optional)
				if (code.isEmpty() == false) {
					if (Etc.strEquals(currDto.code, code) == false) {
						continue;
					}
				}

				items = getArrayFromStrSplit(currDto.more, splitValueInMore); // if value are diffferent in list ???
				res = getValueByKeyFromEquation(items, key);
			}
		} catch (Exception ex) {
			WB.addLog("ModelDto.getValueFromMoreByKey, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getValueFromMoreByKey, res=" + res, WB.strEmpty,
		// "ModelDto");
		return res;
	}

	public static int getLenghtField(String idField, String code) throws Exception {
		// origin - 23.06.2024, last edit - 27.06.2024
		int res = 0;
		try {
			res = Integer.parseInt(getValueFromMoreByKey(WB.abcLast.basic, idField, code)); // ??? WB.abcLast.basic as
																							// arg get ???
		} catch (Exception ex) {
			WB.addLog("ModelDto.getLenghtField, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getLenghtField, res=" + res + ", idField = " + idField +
		// ", code=" + code, WB.strEmpty, "ModelDto");
		return res;
	}

	private static String getValueField(List<ModelDto> listDto, String idField, String code, String defaultValue)
			throws Exception {
		// origin - 23.06.2024, last edit - 05.07.2024
		String res = WB.strEmpty;
		try {
			res = getValueFromMoreByKey(listDto, idField, code);

			if (res.isEmpty()) {
				res = defaultValue;
			}
		} catch (Exception ex) {
			WB.addLog("ModelDto.getValueField, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("ModelDto.getValueField, res=" + res + ", idField =" + idField + ", code=" + code + ", defaultValue="
//				+ defaultValue, WB.strEmpty, "ModelDto");
		return res;
	}

//	private static String getInfoBaseId(String conn) throws Exception {
//		// origin - 25.05.2024, last edit - 27.06.2024
//		String res = WB.strEmpty;
//		res = getValueField(WB.abcLast.infoBaseId, "infoBaseId", "Face.FA1", ModelDto.defaultInfoBaseId); // ??? magic
//																											// string
//																											// ???
////		res = getValueFromMoreByKey(WB.abcLast.infoBaseId, "infoBaseId", "Face.FA1"); // ??? magic string ???
////
////		if (res.isEmpty()) {
////			res = ModelDto.defaultInfoBaseId;
////		}
//		// WB.addLog2("ModelDto.getInfoBaseId, res=" + res, WB.strEmpty, "ModelDto");
//		return res;
//	}

	private static String getId(String table, String id) throws Exception {
		// origin - 09.02.2024, last edit - 30.06.2024
		String res = Etc.fixTrim(id);// WB.strEmpty;
		// id = Etc.fixTrim(id);

		try {
			if (Etc.strEquals(table, "Asset")) {
				res = Asset.getId(id, null, "");
			}

			if (res.isEmpty()) {
				res = formatter2(res,
						getValueField(WB.abcLast.infoBaseId, "infoBaseId", "Face.FA1", ModelDto.defaultInfoBaseId)); // ???
																														// magic
																														// string
																														// ???
				res = res + DateTool.formatter2(DateTool.getNow2());
				res = res + "#" + Etc.getIntRnd(Etc.initRndDefault);
			}
		} catch (Exception ex) {
			WB.addLog("ModelDto.getId, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getId, res=" + res + ", table=" + table + ", id=" + id,
		// WB.strEmpty, "ModelDto");
		return res;
	}

	private static String getParent(String parent) throws Exception {
		// origin - 09.02.2024, last edit - 27.06.2024
		String res = Etc.fixTrim(parent);
		// WB.addLog2("ModelDto.getParent, res=" + res,WB.strEmpty, "ModelDto");
		return res;
	}

	private static String getFace1(String face1) throws Exception {
		// origin - 09.02.2024, last edit - 01.07.2024
		String res = Etc.fixTrim(face1);
		// WB.addLog2("ModelDto.getFace1, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	private static String getFace2(String face2) throws Exception {
		// origin - 09.02.2024, last edit - 01.07.2024
		String res = Etc.fixTrim(face2);
		// WB.addLog2("ModelDto.getFace2, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	private static String getFace(String face) throws Exception {
		// origin - 09.02.2024, last edit - 01.07.2024
		String res = Etc.fixTrim(face);
		// WB.addLog2("ModelDto.getFace, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	public static String getSlice(String slice) throws Exception {
		// origin - 09.02.2024, last edit - 01.07.2024
		String res = Etc.fixTrim(slice);
		// WB.addLog2("ModelDto.getSlice, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	public static ModelDto getFilter(String subStrCode, String subStrMeter) throws Exception {
		// origin - 09.01.2024, last edit - 05.07.2024
		ModelDto res = new ModelDto();
		try {
			if (subStrCode.isEmpty() == false) {
				res.code = subStrCode;
			}
			if (subStrMeter.isEmpty() == false) {
				res.meter = subStrMeter;
			}
		} catch (Exception ex) {
			WB.addLog("ModelDto.getFilter, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog("ModelDto.getFilter, res=" + res, WB.strEmpty, "ModelDto");
		return res;
	}

	public static List<ModelDto> getSubset(List<ModelDto> set, ModelDto filter) throws Exception {
		// origin - 08.01.2024, last edit - 28.06.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		List<ModelDto> tmp = set;
		String allFilter = WB.strEmpty;
		try {
			if (filter.more.isEmpty() == false) {
				allFilter = allFilter + "filter.more=" + filter.more + WB.strCommaSpace;
				tmp = getSubsetByMore(tmp, filter.more);
			}
			if (filter.code.isEmpty() == false) {
				allFilter = allFilter + "filter.code=" + filter.code + WB.strCommaSpace;
				tmp = getSubsetByCode(tmp, filter.code);
			}
			if (filter.meter.isEmpty() == false) {
				allFilter = allFilter + "filter.meter=" + filter.meter + WB.strCommaSpace;
				tmp = getSubsetByMeter(tmp, filter.meter);
			}
		} catch (Exception ex) {
			WB.addLog("ModelDto.getSubset, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		res = tmp;
		// WB.addLog2("ModelDto.getSubset, res.size=" + res.size() + ", allFilter=" +
		// allFilter, WB.strEmpty, "ModelDto");
		return res;
	}

	public static List<ModelDto> getSubsetByMeter(List<ModelDto> set, String subStr) throws Exception {
		// origin - 07.01.2024, last edit - 27.06.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = set.stream();
			basicStream.filter(n -> n.meter.toLowerCase().contains(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ModelDto.getSubsetMeter, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getSubsetByMeter, res.size=" + res.size() + ", subStr="
		// +
		// subStr, WB.strEmpty, "ModelDto");
		return res;
	}

	public static List<ModelDto> getSubsetByCode(List<ModelDto> set, String subStr) throws Exception {
		// origin - 07.01.2024, last edit - 27.06.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = set.stream();
			basicStream.filter(n -> n.code.toLowerCase().contains(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ModelDto.getSubsetCode, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getSubsetByCode, res.size=" + res.size() + ", subStr=" +
		// subStr, WB.strEmpty, "ModelDto");
		return res;
	}

	public static List<ModelDto> getSubsetByMore(List<ModelDto> set, String subStr) throws Exception {
		// origin - 29.11.2023, last edit - 27.06.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = set.stream();
			basicStream.filter(n -> n.more.toLowerCase().contains(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ModelDto.getSubsetMore, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ModelDto.getSubsetMore, res.size=" + res.size() + ", subStr=" +
		// subStr, WB.strEmpty, "ModelDto");
		return res;
	}

	public ModelDto(ModelDto in) throws Exception {
		// origin - 02.01.2024, last edit - 07.07.2024
		try {
			this.table = in.table;
			this.id = in.id;
			this.parent = in.parent;
			this.face1 = in.face1;
			this.face2 = in.face2;
			this.face = in.face;
			this.slice = in.slice;
			this.date1 = in.date1;
			this.date2 = in.date2;
			this.code = in.code;
			this.description = in.description;
			this.sign = in.sign;
			this.account = in.account;
			this.geo = in.geo;
			this.role = in.role;
			this.info = in.info;
			this.meter = in.meter;
			this.meterValue = in.meterValue;
			this.unit = in.unit;
			this.more = in.more;
			this.mark = in.mark;
			this.process = in.process;
			this.asset = in.asset;
			this.deal = in.deal;
			this.item = in.item;
			this.debt = in.debt;
			this.price = in.price;
		} catch (Exception ex) {
			WB.addLog("Meter.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Meter");
		} finally {
			Etc.doNothing();
		}
	}

	public ModelDto(String Table, String Id, String Parent, String Face1, String Face2, String Face, String Slice,
			String Date1, String Date2, String Code, String Description, String Sign, String Account, String Geo,
			String Role, String Info, String Meter, String MeterValue, String Unit, String More, String Mark,
			String Process, String Asset, String Deal, String Item, String Debt, String Price) throws Exception {
		// origin - 02.11.2023, last edit - 07.07.2024
		try {
			this.table = Table;
			this.id = Id;
			this.parent = Parent;
			this.face1 = Face1;
			this.face2 = Face2;
			this.face = Face;
			this.slice = Slice;
			this.date1 = Date1;
			this.date2 = Date2;
			this.code = Code;
			this.description = Description;
			this.sign = Sign;
			this.account = Account;
			this.geo = Geo;
			this.role = Role;
			this.info = Info;
			this.meter = Meter;
			this.meterValue = MeterValue;
			this.unit = Unit;
			this.more = More;
			this.mark = Mark;
			this.process = Process;
			this.asset = Asset;
			this.deal = Deal;
			this.item = Item;
			this.debt = Debt;
			this.price = Price;
		} catch (Exception ex) {
			WB.addLog("Meter.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Meter");
		} finally {
			Etc.doNothing();
		}
	}

	public void clear() throws Exception {
		// origin - 31.12.2023, last edit - 07.07.2024
		try {
			this.table = WB.strEmpty;
			this.id = WB.strEmpty;
			this.parent = WB.strEmpty;
			this.face1 = WB.strEmpty;
			this.face2 = WB.strEmpty;
			this.face = WB.strEmpty;
			this.slice = WB.strEmpty;
			this.date1 = WB.strEmpty;
			this.date2 = WB.strEmpty;
			this.code = WB.strEmpty;
			this.description = WB.strEmpty;
			this.sign = WB.strEmpty;
			this.account = WB.strEmpty;
			this.geo = WB.strEmpty;
			this.role = WB.strEmpty;
			this.info = WB.strEmpty;
			this.meter = WB.strEmpty;
			this.meterValue = WB.strEmpty;
			this.unit = WB.strEmpty;
			this.more = WB.strEmpty;
			this.mark = WB.strEmpty;
			this.process = WB.strEmpty;
			this.asset = WB.strEmpty;
			this.deal = WB.strEmpty;
			this.item = WB.strEmpty;
			this.debt = WB.strEmpty;
			this.price = WB.strEmpty;
		} catch (Exception ex) {
			WB.addLog("Meter.clear, ex=" + ex.getMessage(), WB.strEmpty, "Meter");
		} finally {
			Etc.doNothing();
		}
	}

	public ModelDto() throws Exception {
		// origin - 02.11.2023, last edit - 07.07.2024
		try {
			this.clear();
		} catch (Exception ex) {
			WB.addLog("ModelDto.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Meter");
		} finally {
			Etc.doNothing();
		}
	}

	public static void toList(List<ModelDto> lst, String descr) throws Exception {
		// origin - 26.01.2024, last edit - 05.07.2024
		try {
			for (var currModelDto : lst) {
				WB.addLog2("ModelDto.toList, currModelDto=" + currModelDto.toString() + ", descr=" + descr, WB.strEmpty,
						"ModelDto");
			}
		} catch (Exception ex) {
			WB.addLog2("ModelDto.toList, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
	}

	public static String formatter2(String name, String strAdd) throws Exception {
		// origin - 15.06.2024, last edit - 05.07.2024
		String res = WB.strEmpty;
		strAdd = Etc.fixTrim(strAdd);
		try {
			if (strAdd.isEmpty() == false) {
				res = res + "[" + strAdd + "]"; // for PointId, InfoBase1 in ModelDto.Id
			}
		} catch (Exception ex) {
			WB.addLog2("ModelDto.formatter2, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static String formatter(String name, String strAdd) throws Exception {
		// origin - 01.12.2023, last edit - 28.06.2024
		String res = WB.strEmpty;
		strAdd = Etc.fixTrim(strAdd);
		try {
			if (strAdd.isEmpty() == false) {
				res = res + Etc.fixTrim(name) + "=" + strAdd + WB.strCommaSpace;
			}
		} catch (Exception ex) {
			WB.addLog2("ModelDto.formatter, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static String appender(String strRes, String strAdd) throws Exception {
		// origin - 01.12.2023, last edit - 05.07.2024
		String res = strRes;
		try {
			if (strAdd.isEmpty() != true) {
				res = res + strAdd;
			}
		} catch (Exception ex) {
			// WB.addLog2("ModelDto.appender, ex=" + ex.getMessage(), WB.strEmpty,
			// "ModelDto");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public String toString() {
		// origin - 30.09.2023, last edit - 27.06.2024
		String res = WB.strEmpty;
		try {
			res = appender(res, formatter("table", this.table));
			res = appender(res, formatter("id", this.id));
			res = appender(res, formatter("parent", this.parent));
			res = appender(res, formatter("face1", this.face1));
			res = appender(res, formatter("face2", this.face2));
			res = appender(res, formatter("face", this.face));
			res = appender(res, formatter("slice", this.slice));
			res = appender(res, formatter("date1", this.date1));
			res = appender(res, formatter("date2", this.date2));
			res = appender(res, formatter("code", this.code));
			res = appender(res, formatter("description", this.description));
			res = appender(res, formatter("sign", this.sign));
			res = appender(res, formatter("account", this.account));
			res = appender(res, formatter("geo", this.geo));
			res = appender(res, formatter("role", this.role));
			res = appender(res, formatter("info", this.info));
			res = appender(res, formatter("meter", this.meter));
			res = appender(res, formatter("meterValue", this.meterValue));
			res = appender(res, formatter("unit", this.unit));
			res = appender(res, formatter("more", this.more));
			res = appender(res, formatter("mark", this.mark));
			res = appender(res, formatter("process", this.process));
			res = appender(res, formatter("asset", this.asset));
			res = appender(res, formatter("deal", this.deal));
			res = appender(res, formatter("item", this.item));
			res = appender(res, formatter("debt", this.debt));
			res = appender(res, formatter("price", this.price));
			res = "{" + res + "}";
		} catch (Exception ex) {
			// WB.addLog2("ModelDto.toString, ex=" + ex.getMessage(), WB.strEmpty,
			// "ModelDto");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 12.10.2023, last edit - 06.07.2024
		try {
			// getId
			WB.addLog2("ModelDto.test.getId, res=" + getId("Asset", "P1"), WB.strEmpty, "ModelDto");
			WB.addLog2("ModelDto.test.getId, res=" + getId("Workbook", "P2"), WB.strEmpty, "Model");

//		// getArrayFromStrSplit
//		var arg2 = new String[] { "InfoBaseId=P1;", "InfoBaseId=P1;LastEdit=2024-06-25T07:52:43;", "87664gfgf",
//				"231125567453" };
//		for (var testArg1 : arg2) {
//			WB.addLog2(
//					"ModelDto.test.getArrayFromStrSplit, res="
//							+ Etc.logArray(getArrayFromStrSplit(testArg1, WB.strSemiColon)) + ", testArg1=" + testArg1,
//					WB.strEmpty, "ModelDto");
//		}

//		// delFieldFromMoreByKey
//		var arg1 = new String[] { "InfoBaseId=P1;", "InfoBaseId=P1;LastEdit=2024-06-25T07:52:43;", "87664gfgf",
//				"231125567453", null };
//		for (var testArg1 : arg1) {
//			WB.addLog2("ModelDto.test.delFieldFromMoreByKey, res=" + delFieldFromMoreByKey(testArg1, "LastEdit")
//					+ ", testArg1=" + testArg1, WB.strEmpty, "ModelDto");
//		}

//		// getTestSubset();
//		for (int i = 0; i <= 10; i++) {
//			getId(WB.strEmpty);
//		}
		} catch (Exception ex) {
			WB.addLog("ModelDto.test, ex=" + ex.getMessage(), WB.strEmpty, "ModelDto");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("ModelDto.test end ", WB.strEmpty, "ModelDto");
	}
}
