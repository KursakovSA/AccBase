@SuppressWarnings("unused")
public class SimplexVal extends ModelVal {// ex. "IIN=123456789012;", "IIN=;", "IIN=?;"
	// origin - 05.10.2024, last edit - 06.10.2024
	private static final String strMiddleEquation = "=";

	public String name = WB.strEmpty; // ??
	public String val = WB.strEmpty;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("SimplexVal.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "SimplexVal");
		} finally {
			Etc.doNothing();
		}
	}

//	public static boolean matchTag(String inStr, String tag) throws Exception {
//		// origin - 26.09.2024, last edit - 05.10.2024
//		boolean res = false;
//		inStr = Etc.fixString(inStr);
//		try {
//			if (TagVal.containsTagVal(inStr)) {
//				TagVal probeTagVal = new TagVal(inStr);
//				res = Etc.strEquals(probeTagVal.tag, tag);
//			}
//
//		} catch (Exception ex) {
//			WB.addLog("TagVal.matchTag, ex=" + ex.getMessage(), WB.strEmpty, "TagVal");
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("TagVal.matchTagVal, res=" + res, WB.strEmpty, "TagVal");
//		return res;
//	}

//	public static boolean containsTagVal(String inStr) throws Exception {
//		// origin - 26.09.2024, last edit - 26.09.2024
//		boolean res = false;
//		inStr = Etc.fixString(inStr);
//		try {
//			int posLocalStrLeftSplit = 999; // ?? magic string ??
//			posLocalStrLeftSplit = inStr.indexOf(TagVal.strLeftSplit); // pos "<"
//			int posLocalStrRightSplit = inStr.indexOf(TagVal.strRightSplit) + 1; // pos ">"
//
//			if (posLocalStrLeftSplit != 999) {
//				if (posLocalStrRightSplit > 0) {
//					String probeStrTagVal = inStr.substring(posLocalStrLeftSplit, posLocalStrRightSplit);
//					// WB.addLog2("TagVal.containsTagVal, probeStrTagVal=" + probeStrTagVal,
//					// WB.strEmpty, "TagVal");
//					TagVal probeTagVal = new TagVal(probeStrTagVal);
//					res = probeTagVal.isTagVal();
//				}
//			}
//
//		} catch (Exception ex) {
//			WB.addLog("TagVal.containsTagVal, ex=" + ex.getMessage(), WB.strEmpty, "TagVal");
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("TagVal.containsTagVal, res=" + res, WB.strEmpty, "TagVal");
//		return res;
//	}

//	public static String delTagVal(String inStr) throws Exception {
//		// origin - 26.09.2024, last edit - 26.09.2024
//		String res = Etc.fixTrim(inStr);
//		try {
//			if (TagVal.containsTagVal(inStr)) {
//				int posLocalStrLeftSplit = 999; // ?? magic string ??
//				posLocalStrLeftSplit = inStr.indexOf(TagVal.strLeftSplit); // pos "<"
//				int posLocalStrRightSplit = inStr.indexOf(TagVal.strRightSplit) + 1; // pos ">"
//
//				if (posLocalStrLeftSplit != 999) {
//					if (posLocalStrRightSplit > 0) {
//						String probeStrTagVal = inStr.substring(posLocalStrLeftSplit, posLocalStrRightSplit);
//						res = Etc.delStr(res, probeStrTagVal);
//						res = Etc.fixTrim(res);
//					}
//				}
//
//			}
//
//		} catch (Exception ex) {
//			WB.addLog("TagVal.delTagVal, ex=" + ex.getMessage(), WB.strEmpty, "TagVal");
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("TagVal.delTagVal, res=" + res, WB.strEmpty, "TagVal");
//		return res;
//	}

//	private void getPart() throws Exception {
//		// origin - 26.09.2024, last edit - 30.09.2024
//		try {
//			if (this.isTagVal()) {
//				int posLocalStrMiddleEquation = this.src.indexOf(TagVal.strMiddleEquation); // pos "="
//				if (posLocalStrMiddleEquation > 0) {
//					// this is res
//					this.tag = Etc.fixTrim(this.src.substring(0, posLocalStrMiddleEquation)); // ex.
//																								// "<AnnualMeeting=CostForDinner>"
//																								// --> "<AnnualMeeting="
//					// this.tag = Etc.delStr(this.tag, TagVal.strLeftSplit);
//					// this.tag = Etc.delStr(this.tag, TagVal.strMiddleEquation);
//					// this.tag = Etc.delStr(this.tag, TagVal.strRightSplit);
//					this.tag = Etc.delStr(this.tag, TagVal.listDelStr);
//
//					this.val = Etc.fixTrim(this.src.substring(posLocalStrMiddleEquation));
//					// this.val = Etc.delStr(this.val, TagVal.strLeftSplit);
//					// this.val = Etc.delStr(this.val, TagVal.strMiddleEquation);
//					// this.val = Etc.delStr(this.val, TagVal.strRightSplit);
//					this.val = Etc.delStr(this.val, TagVal.listDelStr);
//
//					this.id = this.tag + TagVal.strMiddleEquation + this.val;
//				}
//			}
//		} catch (Exception ex) {
//			WB.addLog("TagVal.getPart, ex=" + ex.getMessage(), WB.strEmpty, "TagVal");
//		} finally {
//			Etc.doNothing();
//		}
////		WB.addLog2("TagVal.getPart, this.partVal=" + this.partVal + ", this.partUnit=" + this.partUnit + ", this.src="
////				+ this.src, WB.strEmpty, "TagVal");
//	}

	public SimplexVal(String Src) throws Exception {
		// origin - 05.10.2024, last edit - 05.10.2024
		this();
		this.src = Etc.fixTrim(Src);
		// this.getPart();
	}

	public SimplexVal() throws Exception {
		// origin - 05.10.2024, last edit - 05.10.2024
		super();
	}

	public String toString() {
		// origin - 26.09.2024, last edit - 26.09.2024
		String res = WB.strEmpty;
		try {
			res = this.id;
		} catch (Exception ex) {
			// WB.addLog("SimplexVal.toString, ex=" + ex.getMessage(), WB.strEmpty,
			// "SimplexVal");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 05.10.2024, last edit - 05.10.2024
		try {

//			// ctor1
//			TagVal tagVal1 = new TagVal("<AnnualMeeting=CostForDinner>");
//			WB.addLog2("TagVal.test.ctor1, tagVal1.id=" + tagVal1.id + ", tagVal1.tag=" + tagVal1.tag + ", tagVal1.val="
//					+ tagVal1.val + ", init str=" + tagVal1.src, WB.strEmpty, "TagVal");

//			// containsTagVal
//			WB.addLog2("TagVal.test.containsTagVal, res=" + TagVal.containsTagVal(tagVal1.src)
//					+ ", inStr=<AnnualMeeting=CostForDinner>", WB.strEmpty, "TagVal");

//			// delTagVal
//			String probeStr = "12000 Unit.KZT <AnnualMeeting=CostForDinner>";
//			WB.addLog2("TagVal.test.delTagVal, res=" + TagVal.delTagVal(probeStr) + ", probeStr=" + probeStr,
//					WB.strEmpty, "TagVal");

//			// matchTag
//			WB.addLog2("TagVal.test.matchTag, res=" + TagVal.matchTag(tagVal1.src, "AnnualMeeting") + ", tagVal1.src="
//					+ tagVal1.src + ", findTag=AnnualMeeting", WB.strEmpty, "TagVal");
//			WB.addLog2("TagVal.test.matchTag, res=" + TagVal.matchTag(tagVal1.src, "Annual") + ", tagVal1.src="
//					+ tagVal1.src + ", findTag=Annual", WB.strEmpty, "TagVal");

		} catch (Exception ex) {
			WB.addLog("SimplexVal.test, ex=" + ex.getMessage(), WB.strEmpty, "SimplexVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("SimplexVal.test end ", WB.strEmpty, "SimplexVal");
	}
}