import java.util.List;

public class SimplexVal extends ModelVal {// ex. "IIN=123456789012;", "IIN=;", "IIN=?;"
	// origin - 05.10.2024, last edit - 22.11.2024

	private static final List<String> listDelStr = List.of(WB.strEquals, WB.strQuestionMark, WB.strSemiColon);
	public String partVal, val = WB.strEmpty;

	public boolean isRequire = false; // optional
	public boolean isValid = true; // optional

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("SimplexVal.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "SimplexVal");
		} finally {
			Etc.doNothing();
		}
	}

	private void getVal() throws Exception {
		// origin - 12.11.2024, last edit - 13.11.2024
		try {
			this.name = this.partName;
			this.val = this.partVal;
			this.id = this.name + WB.strSpace + this.val;

			if ((this.isRequire) & (this.val.isEmpty())) {
				this.isValid = false;
			}

		} catch (Exception ex) {
			WB.addLog("SimplexVal.getVal, ex=" + ex.getMessage(), WB.strEmpty, "SimplexVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("SimplexVal.getVal, this.id=" + this.id, WB.strEmpty,
		// "SimplexVal");
	}

	private void getPart() throws Exception {
		// origin - 12.11.2024, last edit - 13.11.2024
		try {
			if (ModelVal.isType(this.src) == "SimplexVal") {// if (this.isSimplexVal()) {

				if (this.src.endsWith(WB.strQuestionMark)) {
					this.isRequire = true;
				}

				int posLocalStrMiddleEquation = this.src.indexOf(WB.strEquals); // pos "="
				if (posLocalStrMiddleEquation > 0) {
					this.partName = Etc.fixTrim(this.src.substring(0, posLocalStrMiddleEquation));
					this.partName = Etc.delStr(this.partName, SimplexVal.listDelStr);
					this.partVal = Etc.fixTrim(this.src.substring(posLocalStrMiddleEquation));
					this.partVal = Etc.delStr(this.partVal, SimplexVal.listDelStr);
				}
			}
		} catch (Exception ex) {
			WB.addLog("SimplexVal.getPart, ex=" + ex.getMessage(), WB.strEmpty, "SimplexVal");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("SimplexVal.getPart, this.partVal=" + this.partVal + ", this.partName=" + this.partName, WB.strEmpty, "SimplexVal");
	}

	public SimplexVal(String Src) throws Exception {
		// origin - 05.10.2024, last edit - 14.11.2024
		this();
		this.src = Etc.fixTrim(Src);
		this.getPart();
		this.getVal();
//		WB.addLog2("SimplexVal.ctor(String Src), this.id=" + this.id + ", this.src=" + this.src, WB.strEmpty,
//				"SimplexVal");
	}

	public SimplexVal() throws Exception {
		// origin - 05.10.2024, last edit - 05.10.2024
		super();
	}

	public String toString() {
		// origin - 26.09.2024, last edit - 26.09.2024
		String res = WB.strEmpty;
		try {
			res = this.id;
		} catch (Exception ex) {
			// WB.addLog("SimplexVal.toString, ex=" + ex.getMessage(), WB.strEmpty,
			// "SimplexVal");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 05.10.2024, last edit - 14.11.2024
		try {

//			// ctor
//			var arg1 = new String[] { "IIN=123456789012;", "IIN=;", "IIN=?;" };
//			for (var testArg1 : arg1) {
//				SimplexVal simplexVal1 = new SimplexVal(testArg1);
//				WB.addLog2("SimplexVal.test.ctor, simplexVal1.id=" + simplexVal1.id + ", src=" + simplexVal1.src,
//						WB.strEmpty, "SimplexVal");
//			}

		} catch (Exception ex) {
			WB.addLog("SimplexVal.test, ex=" + ex.getMessage(), WB.strEmpty, "SimplexVal");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("SimplexVal.test end ", WB.strEmpty, "SimplexVal");
	}
}