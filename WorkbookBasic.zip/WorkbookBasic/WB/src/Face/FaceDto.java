import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public final class FaceDto {
	// origin - 02.03.2025, last edit - 19.12.2025
	// common fields
	public String id, parent, date1, date2, code, description, geo, role, info, mark, more;
	// special fields
	public String crewId, deptId, storeId, pointId, jobCycle, jobTurnId, empId, cashId, paymasterEmpId, faceCatId,
			bankAccount, salary, span, docReg, faceGovId, personal, faceSign, userAccount;
	public String fullName, comment;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("FaceDto.static ctor, ex=" + ex.getMessage(), "", "FaceDto");
		}
	}

	private void fix() throws Exception { // TODO
		// origin - 02.05.2026, last edit - 02.05.2026
		try {
			this.date1 = DefVal.set(this.date1, WB.minDateSupported.toString());
			this.date2 = DefVal.set(this.date2, WB.maxDateSupported.toString());
			this.mark = DefVal.set(this.mark, "Mark.DD");
		} catch (Exception ex) {
			WB.addLog("FaceDto.fix():void, ex=" + ex.getMessage(), "", "FaceDto");
		}
	}

	public static List<FaceDto> get(List<FullDto> listFullDto) throws Exception {
		// origin - 24.11.2025, last edit - 24.11.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			for (var curr : listFullDto) {
				res.add(new FaceDto(curr));
			}
		} catch (Exception ex) {
			WB.addLog("FaceDto.get(List<FullDto>):List<FaceDto>, ex=" + ex.getMessage(), "", "FaceDto");
		}
		return res;
	}

	public static FaceDto getCodeRole(String code, String role) throws Exception {
		// origin - 28.03.2025, last edit - 26.10.2025
		FaceDto res = new FaceDto();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getCodeRoleFilter(code, role), "Face");
			if (faceList.size() != 0) {
				if (faceList.size() != 0) {
					for (var currFace : faceList) {
						res = new FaceDto(currFace);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("FaceDto.getCodeRole(2String):FaceDto, ex=" + ex.getMessage(), "", "FaceDto");
		}
		return res;
	}

	public static List<FaceDto> getChronoSpan(SpanDate spanDate, List<FaceDto> listFaceDto) throws Exception {
		// origin - 09.05.2025, last edit - 02.05.2026
		List<FaceDto> res = new ArrayList<FaceDto>();
		LocalDate currDate1;
		LocalDate currDate2;
		try {
			LocalDate spanDate1 = DateTool.getLocalDate(spanDate.date1.getFirst());
			LocalDate spanDate2 = DateTool.getLocalDate(spanDate.date2.getFirst());
			for (var currDto : listFaceDto) {
				currDto.fix();
				currDate1 = DateTool.getLocalDate(currDto.date1);// left border in data
				currDate2 = DateTool.getLocalDate(currDto.date2);// right border in data

				if (currDate1.isBefore(spanDate1)) {
					continue;
				}

				if (currDate2.isAfter(spanDate2)) {
					continue;
				}

				if ((Etc.strEquals(currDate1.toString(), spanDate1.toString()))
						& (Etc.strEquals(currDate2.toString(), spanDate2.toString()))) {
					res.add(currDto);
					continue;
				}

				if ((Etc.strEquals(currDate1.toString(), spanDate1.toString())) & (currDate2.isBefore(spanDate2))) {
					res.add(currDto);
					continue;
				}

				if ((currDate1.isAfter(spanDate1)) & (Etc.strEquals(currDate2.toString(), spanDate2.toString()))) {
					res.add(currDto);
					continue;
				}

				if ((currDate1.isAfter(spanDate1)) & (currDate2.isBefore(spanDate2))) {
					res.add(currDto);
					continue;
				}
			}
		} catch (Exception ex) {
			WB.addLog("FaceDto.getChronoSpan(SpanDate, List<FaceDto>):List<FaceDto>, ex=" + ex.getMessage(), "",
					"FaceDto");
		}
		return res;
	}

	public static List<FaceDto> getChrono(LocalDate calcDate, List<FaceDto> listFaceDto) throws Exception {
		// origin - 26.04.2025, last edit - 02.05.2026
		List<FaceDto> res = new ArrayList<FaceDto>();
		LocalDate currDate1;
		LocalDate currDate2;
		try {
			for (var currDto : listFaceDto) {
				currDto.fix();
				currDate1 = DateTool.getLocalDate(currDto.date1);// left border in data
				currDate2 = DateTool.getLocalDate(currDto.date2);// right border in data

				// left border hit or right border hit
				if ((Etc.strEquals(currDate1.toString(), calcDate.toString()))
						|| (Etc.strEquals(currDate2.toString(), calcDate.toString()))) {
					res.add(currDto);
					continue;
				}

				// range from left border to right border hit
				if ((currDate1.isBefore(calcDate)) && (currDate2.isAfter(calcDate))) {
					res.add(currDto);
					continue;
				}
			}
		} catch (Exception ex) {
			WB.addLog("FaceDto.getChrono(LocalDate, List<FaceDto>):List<FaceDto>, ex=" + ex.getMessage(), "",
					"FaceDto");
		}
		return res;
	}

	public static FaceDto getChrono(LocalDate calcDate, List<FaceDto> listFaceDto, String context) throws Exception {
		// origin - 02.03.2025, last edit - 02.05.2026
		FaceDto res = new FaceDto();
		LocalDate currDate1;
		LocalDate currDate2;
		try {
			for (var currDto : listFaceDto) {
				currDto.fix();
				if (context.isEmpty() == false) {
					if (Etc.strContains(currDto.info, context) == false) {
						continue;
					}
				}

				currDate1 = DateTool.getLocalDate(currDto.date1);// left border in data
				currDate2 = DateTool.getLocalDate(currDto.date2);// right border in data

				// left border hit or right border hit
				if ((Etc.strEquals(currDate1.toString(), calcDate.toString()))
						|| (Etc.strEquals(currDate2.toString(), calcDate.toString()))) {
					res = currDto;
					break;
				}

				// range from left border to right border hit
				if ((currDate1.isBefore(calcDate)) && (currDate2.isAfter(calcDate))) {
					res = currDto;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("FaceDto.getChrono(LocalDate, List<FaceDto>, String):FaceDto, ex=" + ex.getMessage(), "",
					"FaceDto");
		}
		return res;
	}

	private void isExist() throws Exception {
		// origin - 25.09.2025, last edit - 13.08.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), "Face");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.id = dto.id;
				this.code = dto.code;
				this.parent = dto.parent;
				this.date1 = dto.date1;
				this.date2 = dto.date2;
				this.description = dto.description;
				this.geo = DefVal.set(dto.geo, Geo.currCountry.id);
				this.role = dto.role;
				this.info = dto.info;
				this.more = dto.more;
				this.mark = DefVal.set(dto.mark, "Mark.DD");
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.clear();
			}
		} catch (Exception ex) {
			WB.addLog("FaceDto.isExist():void, ex=" + ex.getMessage(), "", "FaceDto");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 20.09.2025, last edit - 16.12.2025
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.personal = MoreVal.getFieldByKey(this.more, "Personal");
			this.storeId = MoreVal.getFieldByKey(this.more, "StoreId");
			this.cashId = MoreVal.getFieldByKey(this.more, "CashId");
			this.paymasterEmpId = MoreVal.getFieldByKey(this.more, "PaymasterEmpId");
			this.deptId = MoreVal.getFieldByKey(this.more, "DeptId");
			this.pointId = MoreVal.getFieldByKey(this.more, "PointId");
			this.jobTurnId = MoreVal.getFieldByKey(this.more, "JobTurnId");
			this.faceCatId = MoreVal.getFieldByKey(this.more, "FaceCatId");
			this.empId = MoreVal.getFieldByKey(this.more, "EmpId");
			this.crewId = MoreVal.getFieldByKey(this.more, "CrewId");
			this.faceGovId = MoreVal.getFieldByKey(this.more, "FaceGovId");
			this.faceSign = MoreVal.getFieldByKey(this.more, "FaceSign");
			this.bankAccount = MoreVal.getFieldByKey(this.more, "BankAccount");
			this.salary = MoreVal.getFieldByKey(this.more, "Salary");
			this.span = MoreVal.getFieldByKey(this.more, "Span");
			this.docReg = MoreVal.getFieldByKey(this.more, "DocReg");
			this.jobCycle = MoreVal.getFieldByKey(this.more, "JobCycle");
			this.userAccount = MoreVal.getFieldByKey(this.more, "UserAccount");
		} catch (Exception ex) {
			WB.addLog("FaceDto.getFieldFromMore():void, ex=" + ex.getMessage(), "", "FaceDto");
		}
	}

	public FaceDto(String Id) throws Exception {
		// origin - 25.09.2025, last edit - 02.05.2026
		this.clear();
		this.id = Id;
		this.isExist();
		this.fix();
	}

	public FaceDto(FullDto mDto) throws Exception {
		// origin - 24.10.2025, last edit - 02.05.2026
		this.clear();
		this.id = mDto.id;
		this.parent = mDto.parent;
		this.date1 = mDto.date1;
		this.date2 = mDto.date2;
		this.code = mDto.code;
		this.description = mDto.description;
		this.geo = mDto.geo;
		this.role = mDto.role;
		this.info = mDto.info;
		this.more = mDto.more;
		this.mark = mDto.mark;
		this.getFieldFromMore();
		this.fix();
	}

	public FaceDto(String Id, String Parent, String Date1, String Date2, String Code, String Description, String Geo,
			String Role, String Info, String More, String Mark) throws Exception {
		// origin - 02.03.2025, last edit - 02.05.2026
		this.clear();
		this.id = Id;
		this.parent = Parent;
		this.date1 = Date1;
		this.date2 = Date2;
		this.code = Code;
		this.description = Description;
		this.geo = Geo;
		this.role = Role;
		this.info = Info;
		this.more = More;
		this.mark = Mark;
		this.getFieldFromMore();
//		this.fix();
	}

	private void clear() throws Exception {
		// origin - 02.03.2025, last edit - 16.12.2025
		try {
			this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.more = "";
			this.geo = this.role = this.info = this.mark = "";
			this.crewId = this.deptId = this.storeId = this.pointId = this.jobTurnId = this.jobCycle = this.empId = this.cashId = "";
			this.salary = this.span = this.paymasterEmpId = this.faceCatId = this.faceGovId = this.bankAccount = this.faceSign = "";
			this.fullName = this.comment = this.personal = this.docReg = this.userAccount = "";
		} catch (Exception ex) {
			WB.addLog("FaceDto.clear():void, ex=" + ex.getMessage(), "", "FaceDto");
		}
	}

	public FaceDto() throws Exception {
		// origin - 02.03.2025, last edit - 02.03.2025
		this.clear();
	}

	public String toString() {
		// origin - 02.03.2025, last edit - 16.12.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addAnyway(", date1 ", this.date1);
			res = res + Fmtr.addAnyway(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", jobCycle ", this.jobCycle);
			res = res + Fmtr.addIfNotEmpty(", salary ", this.salary);
			res = res + Fmtr.addIfNotEmpty(", span ", this.span);
			res = res + Fmtr.addIfNotEmpty(", empId ", this.empId);
			res = res + Fmtr.addIfNotEmpty(", crewId ", this.crewId);
			res = res + Fmtr.addIfNotEmpty(", deptId ", this.deptId);
			res = res + Fmtr.addIfNotEmpty(", storeId ", this.storeId);
			res = res + Fmtr.addIfNotEmpty(", pointId ", this.pointId);
			res = res + Fmtr.addIfNotEmpty(", jobTurnId ", this.jobTurnId);
			res = res + Fmtr.addIfNotEmpty(", cashId ", this.cashId);
			res = res + Fmtr.addIfNotEmpty(", paymasterEmpId ", this.paymasterEmpId);
			res = res + Fmtr.addIfNotEmpty(", faceCatId ", this.faceCatId);
			res = res + Fmtr.addIfNotEmpty(", BankAccount ", this.bankAccount);
			res = res + Fmtr.addIfNotEmpty(", FaceGovId ", this.faceGovId);
			res = res + Fmtr.addIfNotEmpty(", faceSign ", this.faceSign);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", personal ", this.personal);
			res = res + Fmtr.addIfNotEmpty(", docReg ", this.docReg);
			res = res + Fmtr.addIfNotEmpty(", userAccount ", this.userAccount);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 02.03.2025, last edit - 10.12.2025
		try {

		} catch (Exception ex) {
			WB.addLog("FaceDto.test():void, ex=" + ex.getMessage(), "", "FaceDto");
		}
	}
}