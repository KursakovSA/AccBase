import java.util.ArrayList;
import java.util.List;

public final class FaceStructId {
	// origin - 16.09.2026, last edit - 16.09.2026
	public static List<String> nameList;

	static {
		try {
			FaceStructId.nameList = List.of("TemplateId", "StoreId", "CashId", "CashierEmpId", "DeptId", "PointId",
					"EmpId", "CrewId");
		} catch (Exception ex) {
			WB.addLog("FaceStructId.static ctor, ex=" + ex.getMessage(), "", "FaceStructId");
		}
	}

	public static List<String> getListByNameList(String more, List<String> partList) throws Exception {// TODO
		// origin - 16.09.2026, last edit - 16.09.2026
		List<String> res = new ArrayList<String>();
		try {
			var tmp = Fmtr.getListStrBySplit(more, ";");
			for (var currPartMore : tmp) {
				for (var currPartList : partList) {
					if (currPartMore.startsWith(currPartList)) {
						res.add(currPartMore);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("FaceStructId.getListByNameList(String,List<String>):String, ex=" + ex.getMessage(), "",
					"FaceStructId");
		}
		return res;
	}

	public static String get(String more, String faceStructId) throws Exception {
		// origin - 16.09.2026, last edit - 16.09.2026
		String res = "";
		try {
			res = MoreVal.getFieldByKey(more, faceStructId);
		} catch (Exception ex) {
			WB.addLog("FaceStructId.get(2String):String, ex=" + ex.getMessage(), "", "FaceStructId");
		}
		return res;
	}

	private FaceStructId() throws Exception {
		// origin - 16.09.2026, last edit - 16.09.2026
	}

	public static void test() throws Exception {
		// origin - 16.09.2026, last edit - 16.09.2026
		try {

//			WB.addLog2("FaceStructId.test.getListByNameList(2String):String", "", "FaceStructId");
//			WB.addLog2("FaceStructId.test.get(2String):String, FaceStructId.nameList=" + FaceStructId.nameList, "",
//					"FaceStructId");
//			for (var tmp1 : new String[] { "", "PointId=111;", "CrewId=222;FullName=333;", "CashId=444;FullName=555;",
//					"FullName=666;EmpId=777;", "StoreId=111;CashId=222;FullName=444;DeptId=555;" }) {
//				WB.addLog2(
//						"FaceStructId.test.getListByNameList(2String):String, res="
//								+ FaceStructId.getListByNameList(tmp1, FaceStructId.nameList) + ", tmp1=" + tmp1,
//						"", "FaceStructId");
//			}

//			WB.addLog2("FaceStructId.test.get(2String):String", "", "FaceStructId");
//			for (var tmp1 : new String[] { "", "PointId=111;", "CrewId=222;StoreId=333;",
//					"CashId=444;CashierEmpId=555;", "DeptId=666;EmpId=777;", "PointId=888;CrewId=999;",
//					"StoreId=111;CashId=222;CashierEmpId=444;DeptId=555;" }) {
//				for (var tmp2 : FaceStructId.nameList) {
//					WB.addLog2("FaceStructId.test.get(2String):String, res=" + FaceStructId.get(tmp1, tmp2) + ", tmp1="
//							+ tmp1 + ", tmp2=" + tmp2, "", "FaceStructId");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("FaceStructId.test():void, ex=" + ex.getMessage(), "", "FaceStructId");
		}
	}
}