import java.util.ArrayList;
import java.util.List;

public final class FaceReg {
	// origin - 16.05.2025, last edit - 28.01.2026
	// common fields
	public String table, src, id, parent, code, description, geo, role, info, more, mark, defect;
	// special fields
	public static List<String> kind;
	public String comment;
	// special timestamp fields
	public ListVal date1, date2, docReg, fullName;
	// list common + special + timestamp fields in unified val
	public List<FaceDto> val;

	static {
		try {
			kind = List.of("Info.Face.SelfEmp", "Info.Face.VAT", "Info.Face.Social", "Info.Face.Passport",
					"Info.Face.FullName");
		} catch (Exception ex) {
			WB.addLog("FaceReg.static ctor, ex=" + ex.getMessage(), "", "FaceReg");
		}
	}

	// fullName for face on date1
	public static String getCurrDocReg(String date1, String parentId, String infoId) throws Exception {
		// origin - 25.09.2025, last edit - 25.09.2025
		String res = "";
		try {
			FaceDto currFaceDto = new FaceDto();
			currFaceDto = FaceReg.getCurr(date1, parentId, infoId);
			if (currFaceDto.docReg.isEmpty() == false) {
				res = currFaceDto.docReg;
			}

			res = DefVal.set(res, parentId);
		} catch (Exception ex) {
			WB.addLog("FaceReg.getCurrDocReg(3String):String, ex=" + ex.getMessage(), "", "FaceReg");
		}
		return res;
	}

	// fullName for face on date1
	public static String getCurrFullName(String date1, String parentId, String infoId) throws Exception {
		// origin - 22.09.2025, last edit - 25.09.2025
		String res = "";
		try {
			var faceDto = new FaceDto(parentId);
			res = faceDto.fullName;
			var currFaceDto = FaceReg.getCurr(date1, parentId, infoId);
			if (currFaceDto.fullName.isEmpty() == false) {
				res = currFaceDto.fullName;
			}

			res = DefVal.set(res, parentId);
		} catch (Exception ex) {
			WB.addLog("FaceReg.getCurrFullName(3String):String, ex=" + ex.getMessage(), "", "FaceReg");
		}
		return res;
	}

	// full list face reg
	public static List<FaceDto> get() throws Exception {
		// origin - 26.10.2025, last edit - 26.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter("Role.Face.Reg"), "Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					for (var curr : new FaceReg(currFace.parent, currFace.info).val) {
						if (curr.id.isEmpty() == false) {
							res.add(curr);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("FaceReg.get():List<FaceDto>, ex=" + ex.getMessage(), "", "FaceReg");
		}
		return res;
	}

	// full list face reg for face
	public static List<FaceDto> get(String parentId) throws Exception {
		// origin - 16.05.2025, last edit - 26.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, "Role.Face.Reg"),
					"Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					for (var curr : new FaceReg(currFace.parent, currFace.info).val) {
						if (curr.id.isEmpty() == false) {
							res.add(curr);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("FaceReg.get(String):List<FaceDto>, ex=" + ex.getMessage(), "", "FaceReg");
		}
		return res;
	}

	// full list face reg for face on date1
	public static List<FaceDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 16.05.2025, last edit - 26.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, "Role.Face.Reg"),
					"Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					var currFaceReg = new FaceReg(currFace.parent, currFace.info);
					var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceReg.val, "");
					if (curr.id.isEmpty() == false) {
						res.add(curr);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("FaceReg.getCurr(2String):List<FaceDto>, ex=" + ex.getMessage(), "", "FaceReg");
		}
		return res;
	}

	// reg for face on date1
	public static FaceDto getCurr(String date1, String parentId, String infoId) throws Exception {
		// origin - 16.05.2025, last edit - 26.10.2025
		FaceDto res = new FaceDto();
		try {
			var currFaceReg = new FaceReg(parentId, infoId);
			var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceReg.val, "");
			if (curr.id.isEmpty() == false) {
				res = curr;
			}
		} catch (Exception ex) {
			WB.addLog("FaceReg.getCurr(3String):FaceDto, ex=" + ex.getMessage(), "", "FaceReg");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 20.11.2025, last edit - 20.11.2025
		try {
		} catch (Exception ex) {
			WB.addLog("FaceReg.validate():void, ex=" + ex.getMessage(), "", "FaceReg");
		}
	}

	private void getVal() throws Exception {
		// origin - 16.05.2025, last edit - 25.09.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currDocReg = "";
			String currFullName = "";
			String currMore = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currDocReg = this.docReg.getByIndex(i);
				currFullName = this.fullName.getByIndex(i);
				currMore = "";
				currMore = currMore + MoreVal.setPartMore("DocReg", currDocReg);
				currMore = currMore + MoreVal.setPartMore("FullName", currFullName);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description, this.geo,
						this.role, this.info, currMore, this.mark);
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("FaceReg.getVal():void, ex=" + ex.getMessage(), "", "FaceReg");
		}
	}

	private void isExist() throws Exception {
		// origin - 16.05.2025, last edit - 20.11.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleInfoFilter(this.parent, "Role.Face.Reg", this.info), "Face");
			if (listDto.size() != 0) {
				var currDto = listDto.getFirst();
				var tmp = new SpanDate(currDto.date1, currDto.date2);
				this.date1 = new ListVal(tmp.date1);
				this.date2 = new ListVal(tmp.date2);
				this.id = DefVal.setCustom(this.id, currDto.id);
				this.parent = DefVal.setCustom(this.parent, currDto.parent);
				this.code = DefVal.setCustom(this.code, currDto.code);
				this.description = DefVal.setCustom(this.description, currDto.description);
				this.geo = DefVal.setCustom(this.geo, currDto.geo);
				this.role = DefVal.setCustom(this.role, currDto.role);
				this.info = DefVal.setCustom(this.info, currDto.info);
				this.more = DefVal.setCustom(this.more, currDto.more);
				this.mark = DefVal.setCustom(this.mark, currDto.mark);
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("FaceReg.isExist():void, ex=" + ex.getMessage(), "", "FaceReg");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 22.09.2025, last edit - 01.10.2025
		try {
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.docReg = new ListVal(MoreVal.getFieldByKey(this.more, "DocReg"), "");
			this.fullName = new ListVal(MoreVal.getFieldByKey(this.more, "FullName"), "");
		} catch (Exception ex) {
			WB.addLog("FaceReg.getFieldFromMore():void, ex=" + ex.getMessage(), "", "FaceReg");
		}
	}

	public FaceReg(String ParentId, String InfoRegId) throws Exception {
		// origin - 16.05.2025, last edit - 20.11.2025
		this.clear();
		this.table = "Face";
		this.src = ParentId + "," + InfoRegId;
		this.parent = ParentId;
		this.info = InfoRegId;
		this.isExist();
		this.getFieldFromMore();
		this.getVal();
		this.validate();
	}

	private void clear() throws Exception {
		// origin - 16.05.2025, last edit - 20.11.2025
		try {
			this.table = "Face";
			this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.more = this.mark = "";
			this.comment = this.defect = "";
			this.date1 = this.date2 = this.docReg = this.fullName = new ListVal();
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("FaceReg.clear():void, ex=" + ex.getMessage(), "", "FaceReg");
		}
	}

	public FaceReg() throws Exception {
		// origin - 16.05.2025, last edit - 16.05.2025
		this.clear();
	}

	public String toString() {
		// origin - 16.05.2025, last edit - 20.11.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", val.size ", this.val.size());
			res = res + Fmtr.addIfNotEmpty(", docReg ", this.docReg.id);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName.id);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 16.05.2025, last edit - 26.10.2025
		try {

//			WB.addLog2("FaceReg.test.getCurrDocReg(3String):String", "", "FaceReg");
//			for (var tmp1 : new String[] { "2024-12-05", "2025-01-01", "2025-01-14", "2025-01-31", "2025-02-06",
//					"2025-08-23" }) {
//				for (var tmp2 : new String[] { "Face.FA1", "Face.FA1.StaffTable1.Boss" }) {
//					for (var tmp3 : new String[] {"Info.Face.SelfEmp", "Info.Face.VAT", "Info.Face.FullName" }) {
//						WB.addLog2("FaceReg.test.getCurrDocReg(3String):String, res="
//								+ FaceReg.getCurrDocReg(tmp1, tmp2, tmp3) + ", date1=" + tmp1 + ", parentId=" + tmp2
//								+ ", infoId=" + tmp3, "", "FaceReg");
//					}
//				}
//			}

//			WB.addLog2("FaceReg.test.getCurrFullName(3String):String", "", "FaceReg");
//			for (var tmp1 : new String[] { "2024-12-05", "2025-01-01", "2025-01-14", "2025-01-31", "2025-02-06",
//					"2025-08-23" }) {
//				for (var tmp2 : new String[] { "Face.FA1", "Face.FA1.StaffTable1.Boss" }) {
//					for (var tmp3 : new String[] { "Info.Face.FullName" }) {
//						WB.addLog2("FaceReg.test.getCurrFullName(3String):String, res="
//								+ FaceReg.getCurrFullName(tmp1, tmp2, tmp3) + ", date1=" + tmp1 + ", parentId=" + tmp2
//								+ ", infoId=" + tmp3, "", "FaceReg");
//					}
//				}
//			}

//			WB.addLog2("FaceReg.test.get():List<FaceDto>", "", "FaceReg");
//			var tmp = FaceReg.get();
//			WB.addLog2("FaceReg.test.get():List<FaceDto>, res.size=" + tmp.size(), "", "FaceReg");
//			WB.log(tmp, "FaceReg");

//			WB.addLog2("FaceReg.test.get(String):List<FaceDto>", "", "FaceReg");
//			for (var tmp1 : new String[] { "Face.Person.Template", "Face.Tralala" }) {
//				WB.addLog2(
//						"FaceReg.test.get(String):List<FaceDto>, res.size=" + FaceReg.get(tmp1).size() + ", parentId=" + tmp1,
//						"", "FaceReg");
//				WB.log(FaceReg.get(tmp1), "FaceReg");
//			}

//			WB.addLog2("FaceReg.test.getCurr(List<FaceDto>)", "", "FaceReg");
//			for (var tmp1 : new String[] { "2024-12-05", "2025-01-01", "2025-01-14", "2025-01-31", "2025-02-06" }) {
//				for (var tmp2 : new String[] { "Face.Person.Template", "Face.Tralala" }) {
//					WB.addLog2("FaceReg.test.getCurr(List<FaceDto>), res.size=" + FaceReg.getCurr(tmp1, tmp2).size()
//							+ ", date1=" + tmp1 + ", parentId=" + tmp2, "", "FaceReg");
//					WB.log(FaceReg.getCurr(tmp1, tmp2), "FaceReg");
//				}
//			}

//			WB.addLog2("FaceReg.test.getCurr(3String):FaceDto", "", "FaceReg");
//			for (var tmp1 : new String[] { "2024-12-05", "2025-01-01", "2025-01-14", "2025-01-31", "2025-02-06" }) {
//				for (var tmp2 : new String[] { "Face.Person.Template" }) {
//					for (var tmp3 : new String[] { "Info.Face.SelfEmp" }) {
//						WB.addLog2("FaceReg.test.getCurr(3String):FaceDto, res=" + FaceReg.getCurr(tmp1, tmp2, tmp3)
//								+ ", date1=" + tmp1 + ", parentId=" + tmp2 + ", infoId=" + tmp3, "", "FaceReg");
//					}
//				}
//			}

//			WB.addLog2("FaceReg.test.ctor(2String)", "", "FaceReg");
//			for (var tmp1 : new String[] { "Face.Person.Template", "Face.FA1", "Face.FA1.StaffTable1.Boss" }) {
//				for (var tmp2 : new String[] { "Info.Face.SelfEmp", "Info.Face.VAT", "Info.Face.FullName" }) {
//					var tmp3 = new FaceReg(tmp1, tmp2);
//					WB.addLog2("FaceReg.test.ctor(2String)=" + tmp3, "", "FaceReg");
//					WB.log(tmp3.val, "FaceReg");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("FaceReg.test():void, ex=" + ex.getMessage(), "", "FaceReg");
		}
	}
}