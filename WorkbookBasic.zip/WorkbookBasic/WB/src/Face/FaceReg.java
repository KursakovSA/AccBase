import java.util.ArrayList;
import java.util.List;

public class FaceReg {
	// origin - 16.05.2025, last edit - 16.05.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, code, description, geo, role, info, mark;
	// special fields
	public static List<String> kind;
	// special timestamp fields
	public ListVal date1, date2, docReg;
	// list common + special + timestamp fields in unified val
	public List<FaceDto> val;

	static {
		try {
			kind = List.of("Info.Face.SelfEmp", "Info.Face.VAT", "Info.Face.Social", "Info.Face.Passport",
					"Info.Face.TaxID");
		} catch (Exception ex) {
			WB.addLog("FaceReg.static ctor, ex=" + ex.getMessage(), "", "FaceReg");
		}
	}

	// full list face reg for person
	public static List<FaceDto> get(String parentId) throws Exception {
		// origin - 16.05.2025, last edit - 13.06.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, Role.faceReg), "Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					for (var curr : new FaceReg(currFace.parent, currFace.info).val) {
						if (curr.id.isEmpty() == false) {
							var tmp = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code,
									curr.description, curr.geo, curr.role, curr.info, curr.more, curr.mark);
							tmp.docReg = curr.docReg;
							res.add(tmp);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("FaceReg.get(String parentId):List<FaceDto>, ex=" + ex.getMessage(), "", "FaceReg");
		}
		return res;
	}

	// full list face reg for person on date1
	public static List<FaceDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 16.05.2025, last edit - 13.06.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, Role.faceReg), "Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					var currFaceReg = new FaceReg(currFace.parent, currFace.info);
					var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceReg.val, "");
					if (curr.id.isEmpty() == false) {
						var tmp = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
								curr.geo, curr.role, curr.info, curr.more, curr.mark);
						tmp.docReg = curr.docReg;
						res.add(tmp);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("FaceReg.getCurr(String date1, String parentId):List<FaceDto>, ex=" + ex.getMessage(), "",
					"FaceReg");
		}
		return res;
	}

	// item staff position for person on date1
	public static FaceDto getCurr(String date1, String parentId, String infoId) throws Exception {
		// origin - 16.05.2025, last edit - 13.06.2025
		FaceDto res = new FaceDto();
		try {
			var currFaceReg = new FaceReg(parentId, infoId);
			var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceReg.val, "");
			if (curr.id.isEmpty() == false) {
				res = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description, curr.geo,
						curr.role, curr.info, curr.more, curr.mark);
				res.docReg = curr.docReg;
			}
		} catch (Exception ex) {
			WB.addLog("FaceReg.getCurr(String date1, String parentId, String infoId):FaceDto, ex=" + ex.getMessage(),
					"", "FaceReg");
		}
		return res;
	}

	private void getVal() throws Exception {
		// origin - 16.05.2025, last edit - 13.06.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currDocReg = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currDocReg = this.docReg.getByIndex(i);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description, this.geo,
						this.role, this.info, currDocReg, this.mark);
				tmp.docReg = currDocReg;
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("FaceReg.getVal():void, ex=" + ex.getMessage(), "", "FaceReg");
		}
	}

	public void isExist() throws Exception {
		// origin - 16.05.2025, last edit - 11.08.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleInfoFilter(this.parent, Role.faceReg, this.info), "Face");
			if (listDto.size() != 0) {
				for (var currDto : listDto) {
					var tmp = new SpanDate(currDto.date1, currDto.date2);
					this.date1 = new ListVal(tmp.date1);
					this.date2 = new ListVal(tmp.date2);

					this.id = DefVal.setCustom(this.id, currDto.id);
					this.parent = DefVal.setCustom(this.parent, currDto.parent);
					this.code = DefVal.setCustom(this.code, currDto.code);
					this.description = DefVal.setCustom(this.description, currDto.description);
					this.geo = DefVal.setCustom(this.geo, currDto.geo);
					this.role = DefVal.setCustom(this.role, currDto.role);
					this.info = DefVal.setCustom(this.info, currDto.info);

					this.docReg = new ListVal(MoreVal.getFieldByKey(currDto.more, "DocReg"), "");

					this.mark = DefVal.setCustom(this.mark, currDto.mark);
					this.isExist = true;
					break;
				}
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("FaceReg.isExist():void, ex=" + ex.getMessage(), "", "FaceReg");
		}
	}

	public FaceReg(String ParentId, String InfoRegId) throws Exception {
		// origin - 16.05.2025, last edit - 11.08.2025
		this.clear();
		this.src = ParentId + "," + InfoRegId;
		this.parent = ParentId;
		this.info = InfoRegId;
		this.isExist();
		this.getVal();
	}

	public void clear() throws Exception {
		// origin - 16.05.2025, last edit - 11.08.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = "Face";
			this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.mark = "";
			this.date1 = this.date2 = this.docReg = new ListVal();
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("FaceReg.clear():void, ex=" + ex.getMessage(), "", "FaceReg");
		}
	}

	public FaceReg() throws Exception {
		// origin - 16.05.2025, last edit - 16.05.2025
		this.clear();
	}

	public String toString() {
		// origin - 16.05.2025, last edit - 16.05.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);

			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);

			res = res + Fmtr.addIfNotEmpty(", docReg ", this.docReg.id);

			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 16.05.2025, last edit - 13.06.2025
		try {

//			// test get(List<FaceDto>)
//			WB.addLog2("FaceReg.test.get(List<FaceDto>)", "", "FaceReg");
//			for (var tmp1 : new String[] { "Face.Person.Template", "Face.Tralala" }) {
//				WB.addLog2(
//						"FaceReg.test.get(List<FaceDto>), res.size=" + FaceReg.get(tmp1).size() + ", parentId=" + tmp1,
//						"", "FaceReg");
//				WB.log(FaceReg.get(tmp1), "FaceReg");
//			}

//			// test getCurr(List<FaceDto>)
//			WB.addLog2("FaceReg.test.getCurr(List<FaceDto>)", "", "FaceReg");
//			for (var tmp1 : new String[] { "2024-12-05", "2025-01-01", "2025-01-14", "2025-01-31", "2025-02-06" }) {
//				for (var tmp2 : new String[] { "Face.Person.Template", "Face.Tralala" }) {
//					WB.addLog2("FaceReg.test.getCurr(List<FaceDto>), res.size=" + FaceReg.getCurr(tmp1, tmp2).size()
//							+ ", date1=" + tmp1 + ", parentId=" + tmp2, "", "FaceReg");
//					WB.log(FaceReg.getCurr(tmp1, tmp2), "FaceReg");
//				}
//			}

//			// test getCurr(FaceDto)
//			WB.addLog2("FaceReg.test.getCurr(FaceDto)", "", "FaceReg");
//			for (var tmp1 : new String[] { "2024-12-05", "2025-01-01", "2025-01-14", "2025-01-31", "2025-02-06" }) {
//				for (var tmp2 : new String[] { "Face.Person.Template" }) {
//					for (var tmp3 : new String[] { "Info.Face.SelfEmp" }) {
//						WB.addLog2("FaceReg.test.getCurr(FaceDto), res=" + FaceReg.getCurr(tmp1, tmp2, tmp3)
//								+ ", date1=" + tmp1 + ", parentId=" + tmp2 + ", infoId=" + tmp3, "", "FaceReg");
//					}
//				}
//			}

//			// test ctor(String,String)
//			WB.addLog2("FaceReg.test.ctor(String,String)", "", "FaceReg");
//			for (var tmp1 : new String[] { "Face.Person.Template" }) {
//				for (var tmp2 : new String[] { "Info.Face.SelfEmp", "Info.Face.VAT" }) {
//					WB.addLog2("FaceReg.test.ctor(String,String)=" + new FaceReg(tmp1, tmp2), "", "FaceReg");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("FaceReg.test():void, ex=" + ex.getMessage(), "", "FaceReg");
		}
	}
}