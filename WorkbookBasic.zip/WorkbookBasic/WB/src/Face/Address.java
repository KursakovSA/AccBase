import java.util.ArrayList;
import java.util.List;

public final class Address {
	// origin - 07.03.2025, last edit - 20.11.2025
	// common fields
	public String table, src, id, parent, code, description, geo, role, info, mark, defect;
	// special fields - no
	// special timestamp fields
	private ListVal date1, date2, more;
	// list common + special + timestamp fields in unified val
	public List<FaceDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Address.static ctor, ex=" + ex.getMessage(), "", "Address");
		}
	}

	// full list address positions
	public static List<FaceDto> get() throws Exception {
		// origin - 26.10.2025, last edit - 26.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceByParentRole = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter("Role.Face.Address"), "Face");
			for (var currFace : faceByParentRole) {
				for (var curr : new Address(currFace.parent, currFace.info).val) {
					if (curr.id.isEmpty() == false) {
						res.add(curr);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Address.get():List<FaceDto>, ex=" + ex.getMessage(), "", "Address");
		}
		return res;
	}

	// full list address positions for parentId
	public static List<FaceDto> get(String parentId) throws Exception {
		// origin - 04.05.2025, last edit - 26.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceByParentRole = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleFilter(parentId, "Role.Face.Address"), "Face");
			for (var currFace : faceByParentRole) {
				for (var curr : new Address(currFace.parent, currFace.info).val) {
					if (curr.id.isEmpty() == false) {
						res.add(curr);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Address.get(String):List<FaceDto>, ex=" + ex.getMessage(), "", "Address");
		}
		return res;
	}

	// last address
	public static FaceDto getLast(String parentId) throws Exception {
		// origin - 28.09.2025, last edit - 28.09.2025
		FaceDto res = new FaceDto();
		try {
			var faceByParent = Address.get(parentId);
			if (faceByParent.size() != 0) {
				res = faceByParent.getLast();
			}
		} catch (Exception ex) {
			WB.addLog("Address.getLast(String):FaceDto, ex=" + ex.getMessage(), "", "Address");
		}
		return res;
	}

	// some address on date1
	public static FaceDto getCurrSome(String date1, String parentId) throws Exception {
		// origin - 11.03.2025, last edit - 28.09.2025
		FaceDto res = new FaceDto();
		try {
			var faceByParent = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleFilter(parentId, "Role.Face.Address"), "Face");
			for (var currFace : faceByParent) {
				var currFaceAddressNote = new Address(currFace.parent, currFace.info);
				var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceAddressNote.val, "");
				if (curr.id.isEmpty() == false) {
					res = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
							curr.geo, curr.role, curr.info, curr.more, curr.mark); // curr.more = currAddress
				}
			}

			if (res.id.isEmpty()) {
				res = Address.getLast(parentId);
			}
		} catch (Exception ex) {
			WB.addLog("Address.getCurrSome(2String):FaceDto, ex=" + ex.getMessage(), "", "Address");
		}
		return res;
	}

	// RegAddress for face on date1
	public static String getCurrRegAddress(String date1, String parentId) throws Exception {
		// origin - 14.04.2026, last edit - 14.04.2026
		String res = "";
		try {
			res = Address.getCurr(date1, parentId, "Info.Code.RegAddress").more;
		} catch (Exception ex) {
			WB.addLog("FaceReg.getCurrRegAddress(2String):String, ex=" + ex.getMessage(), "", "FaceReg");
		}
		return res;
	}

	// LawAddress for face on date1
	public static String getCurrLawAddress(String date1, String parentId) throws Exception {
		// origin - 14.04.2026, last edit - 14.04.2026
		String res = "";
		try {
			res = Address.getCurr(date1, parentId, "Info.Code.LawAddress").more;
		} catch (Exception ex) {
			WB.addLog("FaceReg.getCurrLawAddress(2String):String, ex=" + ex.getMessage(), "", "FaceReg");
		}
		return res;
	}

	// item address position on date1
	private static FaceDto getCurr(String date1, String parentFaceId, String infoAddressKindId) throws Exception {
		// origin - 10.03.2025, last edit - 14.04.2026
		FaceDto res = new FaceDto();
		try {
			var currFaceAddressNote = new Address(parentFaceId, infoAddressKindId);
			var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceAddressNote.val, "");
			if (curr.id.isEmpty() == false) {
				res = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description, curr.geo,
						curr.role, curr.info, curr.more, curr.mark); // curr.more = currAddress
			}

			// if not find than take some address, Well, at least something
			if (res.id.isEmpty()) {
				res = Address.getCurrSome(date1, parentFaceId);
			}
		} catch (Exception ex) {
			WB.addLog("Address.getCurr(3String):FaceDto, ex=" + ex.getMessage(), "", "Address");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 20.11.2025, last edit - 20.11.2025
		try {
		} catch (Exception ex) {
			WB.addLog("Address.validate():void, ex=" + ex.getMessage(), "", "Address");
		}
	}

	private void getVal() throws Exception {
		// origin - 07.03.2025, last edit - 13.06.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currMore = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currMore = this.more.getByIndex(i);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description, this.geo,
						this.role, this.info, currMore, this.mark);
				this.val.add(tmp);
				// WB.addLog2("Address.getVal, add tmp=" + tmp, "","Address");
			}
		} catch (Exception ex) {
			WB.addLog("Address.getVal():void, ex=" + ex.getMessage(), "", "Address");
		}
	}

	private void isExist() throws Exception {
		// origin - 07.03.2025, last edit - 20.11.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleInfoFilter(this.parent, "Role.Face.Address", this.info), "Face");
			if (listDto.size() != 0) {
				var currDto = listDto.getFirst();
				this.date1 = new ListVal(currDto.date1, "");
				this.date2 = new ListVal(currDto.date2, "");
				this.id = DefVal.setCustom(this.id, currDto.id);
				this.parent = DefVal.setCustom(this.parent, currDto.parent);
				this.code = DefVal.setCustom(this.code, currDto.code);
				this.description = DefVal.setCustom(this.description, currDto.description);
				this.geo = DefVal.setCustom(this.geo, currDto.geo);
				this.role = DefVal.setCustom(this.role, currDto.role);
				this.info = DefVal.setCustom(this.info, currDto.info);
				this.more = new ListVal(currDto.more, "");
				this.mark = DefVal.setCustom(this.mark, currDto.mark);
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("Address.isExist():void, ex=" + ex.getMessage(), "", "Address");
		}
	}

	public Address(String ParentFaceId, String InfoAddressKindId) throws Exception {
		// origin - 07.03.2025, last edit - 20.11.2025
		this();
		this.src = this.parent = ParentFaceId;
		this.info = InfoAddressKindId;
		this.isExist();
		this.getVal();
		this.validate();
	}

	private void clear() throws Exception {
		// origin - 07.03.2025, last edit - 20.11.2025
		try {
			this.table = "Face";
			this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.mark = this.defect = "";
			this.date1 = this.date2 = this.more = new ListVal();
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("Address.clear():void, ex=" + ex.getMessage(), "", "Address");
		}
	}

	public Address() throws Exception {
		// origin - 07.03.2025, last edit - 07.03.2025
		this.clear();
	}

	public String toString() {
		// origin - 07.03.2025, last edit - 20.11.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.id);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 07.03.2025, last edit - 26.10.2025
		try {

//			WB.addLog2("Address.test.get():List<FaceDto>", "", "Address");
//			var tmp = Address.get();
//			WB.addLog2("Address.test.getCurr():List<FaceDto>, res.size=" + tmp.size(), "", "Address");
//			WB.log(tmp, "Address");

//			WB.addLog2("Address.test.get(String):List<FaceDto>", "", "Address");
//			for (var tmp1 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
//				WB.addLog2("Address.test.getCurr(String):List<FaceDto>, res.size=" + Address.get(tmp1).size() + ", parentId="
//						+ tmp1, "", "Address");
//				WB.log(Address.get(tmp1), "Address");
//			}

//			WB.addLog2("Address.test.getCurrSome(2String):FaceDto", "", "Address");
//			for (var tmp1 : new String[] { "2024-05-24", "2025-01-31", "2025-02-20", "2025-08-15" }) {
//				var tmp2 = "Face.FA1";
//				WB.addLog2("Address.test.getCurrSome(2String):FaceDto, res.more=" + Address.getCurrSome(tmp1, tmp2).more
//						+ ", date1=" + tmp1 + ", parentId=" + tmp2, "", "Address");
//			}

//			WB.addLog2("Address.test.getCurr(3String):FaceDto", "", "Address");
//			for (var tmp1 : new String[] { "2025-01-31", "2025-02-20", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
//					for (var tmp3 : Info.kindAddress) {
//						WB.addLog2("Address.test.getCurr(3String):FaceDto, res.more="
//								+ Address.getCurr(tmp1, tmp2, tmp3).more + ", date1=" + tmp1 + ", parentId=" + tmp2
//								+ ", infoKindAddress=" + tmp3, "", "Address");
//					}
//				}
//			}

//			WB.addLog2("Address.test.ctor(2String)", "", "Address");
//			for (var tmp1 : new String[] { "Face.FA1", "Face.tralala", "Face.kgd" }) {
//				for (var tmp2 : Info.kindAddress) {
//					WB.addLog2("Address.test.ctor(2String)=" + new Address(tmp1, tmp2),"", "Address");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("Address.test():void, ex=" + ex.getMessage(), "", "Address");
		}
	}
}