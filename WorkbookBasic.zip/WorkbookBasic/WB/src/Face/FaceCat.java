import java.util.ArrayList;
import java.util.List;

public final class FaceCat {
	// origin - 01.07.2025, last edit - 15.09.2026
	// common fields
	public String table, src, id, parent, date1, date2, code, description, geo, role, info, mark, more, defect;
	// special fields
	public String fullName, comment;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("FaceCat.static ctor, ex=" + ex.getMessage(), "", "FaceCat");
		}
	}

	// full list asset cat for parent
	public static List<FaceCat> get(String parentId, String role) throws Exception {
		// origin - 01.07.2025, last edit - 04.01.2026
		List<FaceCat> res = new ArrayList<FaceCat>();
		try {
			var face = new Face(parentId);
			var faceList = face.lowerList;
			if (faceList.size() != 0) {
				for (var curr : faceList) {
					if ((curr.id.isEmpty() == false) & (Etc.strEquals(curr.role, role))) {
						var tmp = new FaceCat(new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code,
								curr.description, curr.geo, curr.role, curr.info, curr.more, curr.mark));
						res.add(tmp);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("FaceCat.get(2String):List<FaceCat>, ex=" + ex.getMessage(), "", "FaceCat");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 20.11.2025, last edit - 10.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}
		} catch (Exception ex) {
			WB.addLog("FaceCat.validate():void, ex=" + ex.getMessage(), "", "FaceCat");
		}
	}

	private void isExist() throws Exception {
		// origin - 01.07.2025, last edit - 10.10.2026
		try {
			List<FullDto> listDto = new ArrayList<FullDto>();

			if (this.id.isEmpty() == false) {
				listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdRoleInfoFilter(this.id, this.role, this.info),
						"Face");
			}

			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.date1 = DefVal.setCustom(this.date1, dto.date1);
				this.date2 = DefVal.setCustom(this.date2, dto.date2);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.id = DefVal.setCustom(this.id, dto.id);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.geo = DefVal.setCustom(this.geo, dto.geo);
				this.role = DefVal.setCustom(this.role, dto.role);
				this.info = DefVal.setCustom(this.info, dto.info);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.mark = DefVal.setCustom(this.mark, dto.mark);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.clear();
			}
		} catch (Exception ex) {
			WB.addLog("FaceCat.isExist():void, ex=" + ex.getMessage(), "", "FaceCat");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 12.08.2025, last edit - 15.09.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("FaceCat.getFieldFromMore():void, ex=" + ex.getMessage(), "", "FaceCat");
		}
	}

	public FaceCat(FaceDto fDto) throws Exception {
		// origin - 01.07.2025, last edit - 20.11.2025
		this.clear();
		this.date1 = fDto.date1;
		this.date2 = fDto.date2;
		this.code = fDto.code;
		this.id = fDto.id;
		this.description = fDto.description;
		this.geo = fDto.geo;
		this.role = fDto.role;
		this.info = fDto.info;
		this.more = fDto.more;
		this.mark = fDto.mark;
		this.getFieldFromMore();
		this.validate();
	}

	public FaceCat(String Id, String Role) throws Exception {
		// origin - 01.07.2025, last edit - 20.11.2025
		this.clear();
		this.src = Id + "," + Role;
		this.id = Id;
		this.role = Role;
		this.info = "Info.Face.Catalog";
		this.isExist();
		this.validate();
	}

	private void clear() throws Exception {
		// origin - 01.07.2025, last edit - 15.09.2026
		try {
			this.table = "Face";
			this.src = this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.geo = this.role = this.info = this.mark = this.more = "";
			this.fullName = this.comment = this.defect = "";
		} catch (Exception ex) {
			WB.addLog("FaceCat.clear():void, ex=" + ex.getMessage(), "", "FaceCat");
		}
	}

	public FaceCat() throws Exception {
		// origin - 01.07.2025, last edit - 01.07.2025
		this.clear();
	}

	public String toString() {
		// origin - 01.07.2025, last edit - 15.09.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("table ", this.table);
			res = res + Fmtr.addIfNotEmpty(" src ", this.src);
			res = res + Fmtr.addIfNotEmpty(" id ", this.id);
			res = res + Fmtr.addIfNotEmpty(" parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(" date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(" date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(" code ", this.code);
			res = res + Fmtr.addIfNotEmpty(" description ", this.description);
			res = res + Fmtr.addIfNotEmpty(" ", this.geo);
			res = res + Fmtr.addIfNotEmpty(" ", this.role);
			res = res + Fmtr.addIfNotEmpty(" ", this.info);
			res = res + Fmtr.addIfNotEmpty(" more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(" defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(" fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(" comment ", this.comment);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 01.07.2025, last edit - 01.07.2025
		try {

//			WB.addLog2("FaceCat.test.get(String parentId, String role):List<FaceCat>", "", "FaceCat");
//			for (var tmp1 : new String[] { "Face.Staff.Catalog", "Face.Tralala.Catalog" }) {
//				for (var tmp2 : new String[] { "Role.Face.Staff"}) {
//					var tmp = FaceCat.get(tmp1, tmp2);
//					WB.addLog2("FaceCat.test.get(String parentId, String role):List<FaceCat>, res.size=" + tmp.size()
//							+ ", parentId=" + tmp1 + ", role=" + tmp2, "", "FaceCat");
//					WB.log(tmp, "FaceCat");
//				}
//			}

//			WB.addLog2("FaceCat.test.ctor(String Id, String Role)", "", "FaceCat");
//			for (var tmp1 : new String[] { "Face.Staff.Catalog.1", "Face.Staff.Catalog.2", "Face.Tralala.Catalog.1" }) {
//				for (var tmp2 : new String[] { "Role.Face.Staff" }) {
//					WB.addLog2("FaceCat.test.ctor(String Id, String Role)=" + new FaceCat(tmp1, tmp2), "", "FaceCat");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("FaceCat.test():void, ex=" + ex.getMessage(), "", "FaceCat");
		}
	}
}