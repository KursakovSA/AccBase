public final class FaceSign {
	// origin - 06.12.2025, last edit - 06.12.2025
	public String id, context, src, val1, val2, defect;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("FaceSign.static ctor, ex=" + ex.getMessage(), "", "FaceSign");
		}
	}

	private void validate() throws Exception {
		// origin - 07.12.2025, last edit - 11.12.2025
		try {
			if (this.val1.length() < 3) {
				this.defect = this.defect + "empty val1; ";
			}
			if (this.val2.length() < 3) {
				this.defect = this.defect + "empty val2; ";
			}
		} catch (Exception ex) {
			WB.addLog("FaceSign.validate():void, ex=" + ex.getMessage(), "", "FaceSign");
		}
	}

	public FaceSign(String Src) throws Exception {
		// origin - 06.12.2025, last edit - 11.12.2025
		this.clear();
		this.src = Src;
		var tmp = new TwoVal(src);
		this.val1 = tmp.val1;
		this.val2 = tmp.val2;
		this.id = this.val1 + " , " + this.val2;
		this.validate();
	}

	public FaceSign() throws Exception {
		// origin - 06.12.2025, last edit - 06.12.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 06.12.2025, last edit - 06.12.2025
		try {
			this.id = this.context = this.src = this.val1 = this.val2 = this.defect = "";
		} catch (Exception ex) {
			WB.addLog("FaceSign.clear():void, ex=" + ex.getMessage(), "", "FaceSign");
		}
	}

	public String toString() {
		// origin - 06.12.2025, last edit - 07.12.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway(" src ", this.src);
			res = res + Fmtr.addIfNotEmpty(" context ", this.context);
			res = res + Fmtr.addIfNotEmpty(" val1 ", this.val1);
			res = res + Fmtr.addIfNotEmpty(" val2 ", this.val2);
			res = res + Fmtr.addIfNotEmpty(" defect ", this.defect);
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 06.12.2025, last edit - 07.12.2025
		try {

//			WB.addLog2("FaceSign.test.ctor(String)", "", "FaceSign");
//			for (var tmp1 : new String[] { "Мынбаев Н.Г. , Жилкибаев Е.Н." }) {
//				var tmp2 = new FaceSign(tmp1);
//				WB.addLog2("FaceSign.test.ctor(String), res.id=" + tmp2.id + ", tmp1=" + tmp1 + ", tmp2=" + tmp2, "",
//						"FaceSign");
//			}

		} catch (Exception ex) {
			WB.addLog("FaceSign.test():void, ex=" + ex.getMessage(), "", "FaceSign");
		}
	}
}