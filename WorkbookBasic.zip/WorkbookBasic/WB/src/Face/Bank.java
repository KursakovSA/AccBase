import java.util.ArrayList;
import java.util.List;

public class Bank {
	// origin - 24.03.2025, last edit - 03.05.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, code, description, geo, role, info, mark, more;
	// special fields
	public String IBAN, BIC, fullName, comment;
	// special timestamp fields
	public ListVal date1, date2;
	// list common + special + timestamp fields in unified val
	public List<FaceDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Bank.static ctor, ex=" + ex.getMessage(), "", "Bank");
		}
	}

	// full list bank
	public static List<FaceDto> get(String parentId) throws Exception {
		// origin - 04.05.2025, last edit - 15.09.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, "Role.Store.Bank"),
					"Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					var currFaceBank = new Bank(currFace.parent, currFace.code);
					for (var curr : currFaceBank.val) {
						if (curr.id.isEmpty() == false) {
							var tmp = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code,
									curr.description, curr.geo, curr.role, curr.info, curr.more, curr.mark);
							tmp.BIC = currFaceBank.BIC;
							tmp.IBAN = currFaceBank.IBAN;
							tmp.fullName = currFaceBank.fullName;
							tmp.comment = currFaceBank.comment;
							res.add(tmp);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Bank.get(String parentId):List<FaceDto>, ex=" + ex.getMessage(), "", "Bank");
		}
		return res;
	}

	// full list bank on date1
	public static List<FaceDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 24.03.2025, last edit - 15.09.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, "Role.Store.Bank"),
					"Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					var currFaceBank = new Bank(currFace.parent, currFace.code);
					var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceBank.val, "");
					if (curr.id.isEmpty() == false) {
						var tmp = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
								curr.geo, curr.role, curr.info, curr.more, curr.mark);
						tmp.BIC = currFaceBank.BIC;
						tmp.IBAN = currFaceBank.IBAN;
						tmp.fullName = currFaceBank.fullName;
						tmp.comment = currFaceBank.comment;
						res.add(tmp);
						// WB.addLog2("Bank.getCurr, add tmp=" + tmp, "","Bank");
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Bank.getCurr(String date1, String parentId):List<FaceDto>, ex=" + ex.getMessage(), "", "Bank");
		}
		return res;
	}

	// item bank by IBAN on date1
	public static FaceDto getByIBAN(String date1, String faceParentId, String IBAN) throws Exception {
		// origin - 25.03.2025, last edit - 13.06.2025
		FaceDto res = new FaceDto();
		try {
			var faceList = Bank.getCurr(date1, faceParentId);
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					var curr = new Bank(currFace.parent, currFace.code);
					var currIBAN = MoreVal.getFieldByKey(curr.more, "IBAN");
					if (currIBAN.isEmpty() == false) {
						if (Etc.strEquals(currIBAN, IBAN)) {
							res = new FaceDto(curr.id, curr.parent, date1, date1, curr.code, curr.description, curr.geo,
									curr.role, curr.info, curr.more, curr.mark);
							res.BIC = curr.BIC;
							res.IBAN = curr.IBAN;
							res.fullName = curr.fullName;
							res.comment = curr.comment;
							// WB.addLog2("Bank.getByIBAN, res=" + res, "","Bank");
							break;
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Bank.getByIBAN(String date1, String faceParentId, String IBAN):FaceDto, ex=" + ex.getMessage(),
					"", "Bank");
		}
		return res;
	}

	// item bank on date1
	public static FaceDto getCurr(String date1, String faceParentId, String faceBankId) throws Exception {
		// origin - 24.03.2025, last edit - 13.06.2025
		FaceDto res = new FaceDto();
		try {
			var currFaceBank = new Bank(faceParentId, faceBankId);
			if (currFaceBank.val.size() != 0) {
				var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceBank.val, "");
				if (curr.id.isEmpty() == false) {
					res = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
							curr.geo, curr.role, curr.info, curr.more, curr.mark);
					res.BIC = curr.BIC;
					res.IBAN = curr.IBAN;
					res.fullName = curr.fullName;
					res.comment = curr.comment;
					// WB.addLog2("Bank.getCurr, res=" + res, "","Bank");
				}
			}
		} catch (Exception ex) {
			WB.addLog(
					"Bank.getCurr(String date1, String faceParentId, String faceBankId):FaceDto, ex=" + ex.getMessage(),
					"", "Bank");
		}
		return res;
	}

	private void getVal() throws Exception {
		// origin - 24.03.2025, last edit - 13.06.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description, this.geo,
						this.role, this.info, this.more, this.mark);
				tmp.BIC = this.BIC;
				tmp.IBAN = this.IBAN;
				tmp.fullName = this.fullName;
				tmp.comment = this.comment;
				this.val.add(tmp);
				// WB.addLog2("Bank.getVal, add tmp=" + tmp, ","Bank");
			}
		} catch (Exception ex) {
			WB.addLog("Bank.getVal():void, ex=" + ex.getMessage(), "", "Bank");
		}
	}

	private void isExist() throws Exception {
		// origin - 24.03.2025, last edit - 15.09.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentCodeRoleFilter(this.parent, this.code, "Role.Store.Bank"), "Face");
			if (listDto.size() != 0) {
				for (var currDto : listDto) {
					var tmp = new SpanDate(currDto.date1, currDto.date2);
					this.date1 = new ListVal(tmp.date1);
					this.date2 = new ListVal(tmp.date2);

					this.id = DefVal.setCustom(this.id, currDto.id);
					this.parent = DefVal.setCustom(this.parent, currDto.parent);
					this.code = DefVal.setCustom(this.code, currDto.code);
					this.description = DefVal.setCustom(this.description, currDto.description);
					this.geo = DefVal.setCustom(this.geo, currDto.geo);
					this.role = DefVal.setCustom(this.role, currDto.role);
					this.info = DefVal.setCustom(this.info, currDto.info);
					this.more = DefVal.setCustom(this.more, currDto.more);
					this.mark = DefVal.setCustom(this.mark, currDto.mark);
					this.getFieldFromMore();
					this.isExist = true;
					break;
				}
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("Bank.isExist():void, ex=" + ex.getMessage(), "", "Bank");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 12.08.2025, last edit - 12.08.2025
		try {
			this.IBAN = MoreVal.getFieldByKey(this.more, "IBAN");
			this.BIC = MoreVal.getFieldByKey(this.more, "BIC");
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("Deal.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	public Bank(String ParentId, String BankId) throws Exception {
		// origin - 24.03.2025, last edit - 11.08.2025
		this();
		this.src = ParentId + ", " + BankId;
		this.parent = ParentId;
		this.code = BankId;
		this.isExist();
		this.getVal();
	}

	private void clear() throws Exception {
		// origin - 24.03.2025, last edit - 11.08.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = "Face";
			this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.more = this.mark = "";
			this.IBAN = this.BIC = this.fullName = this.comment = "";
			this.date1 = this.date2 = new ListVal();
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("Cash.clear():void, ex=" + ex.getMessage(), "", "Cash");
		}
	}

	public Bank() throws Exception {
		// origin - 24.03.2025, last edit - 24.03.2025
		this.clear();
	}

	public String toString() {
		// origin - 24.03.2025, last edit - 03.05.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);

			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addIfNotEmpty(", IBAN ", this.IBAN);
			res = res + Fmtr.addIfNotEmpty(", BIC ", this.BIC);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 24.03.2025, last edit - 13.06.2025
		try {

//			// get(List<FaceDto>)
//			for (var tmp1 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
//				WB.addLog2("Bank.test.getCurr(List<FaceDto>), res.size=" + Bank.get(tmp1).size() + ", parentId=" + tmp1,
//						"", "Bank");
//				WB.log(Bank.get(tmp1), "Bank");
//			}

//			// getCurr(List<FaceDto>)
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-24", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1", "Face.kgd", "Face.GCVP", "Face.Tralala" }) {
//					WB.addLog2("Bank.test.getCurr(List<FaceDto>), res.size=" + Bank.getCurr(tmp1, tmp2).size() + ", date1="
//							+ tmp1 + ", parentId=" + tmp2, "", "Bank");
//			WB.log(Bank.getCurr(tmp1, tmp2), "Bank");
//				}
//			}

//			// getByIBAN(Bank)
//			for (var tmp1 : new String[] { "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1", "Face.kgd", "Face.GCVP", "Face.Tralala" }) {
//					for (var tmp3 : new String[] { "KZ67009SS00368609110" }) {
//						WB.addLog2("Bank.test.getByIBAN, res=" + Bank.getByIBAN(tmp1, tmp2, tmp3) + ", date1=" + tmp1
//								+ ", faceParentId=" + tmp2 + ", IBAN=" + tmp3, "", "Bank");
//					}
//				}
//			}

//			// getCurr
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-24", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1", "Face.kgd", "Face.GCVP", "Face.Tralala" }) {
//					for (var tmp3 : new String[] { "Face.FA1.Bank1", "Face.GCVP-GFSS.Bank1", "Face.Tralala.Bank1" }) {
//						WB.addLog2("Bank.test.getCurr, res=" + Bank.getCurr(tmp1, tmp2, tmp3) + ", date1=" + tmp1
//								+ ", faceParentId=" + tmp2 + ", faceBankId=" + tmp3, "", "Bank");
//					}
//				}
//			}

//			// ctor()
//			WB.addLog2("Bank.test.ctor()=" + new Bank(), "", "Bank");

//			// ctor (String, String)
//			for (var tmp1 : new String[] { "Face.FA1", "Face.kgd", "Face.GCVP", "Face.Tralala" }) {
//				for (var tmp2 : new String[] { "Face.FA1.Bank1", "Face.GCVP-GFSS.Bank1", "Face.Tralala.Bank1" }) {
//					WB.addLog2("Bank.test.ctor(String,String)=" + new Bank(tmp1, tmp2), "", "Bank");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("Bank.test():void, ex=" + ex.getMessage(), "", "Bank");
		}
	}
}