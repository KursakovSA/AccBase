import java.util.ArrayList;
import java.util.List;

public class JobDaily {
	// origin - 07.05.2025, last edit - 08.05.2025
	public boolean isValid, isExist;
	public String table, src, id, parent, code, description, geo, role, info, mark, more, fullName, comment;
	public ListVal date1, date2, span;
	public List<FaceDto> val;
	public static List<String> strInfoSelect;

	static {
		try {
			JobDaily.strInfoSelect = List.of("Info.Staff.Late", "Info.Staff.Skip");
		} catch (Exception ex) {
			WB.addLog("JobDaily.static ctor, ex=" + ex.getMessage(), "", "JobDaily");
		}
	}

	public static UnitVal getTotalSpan(SpanDate spanDate, String parentId, String infoSelect) throws Exception {
		// origin - 08.05.2025, last edit - 13.06.2025
		Unit unitSpan = Unit.getExpectedFromInfo(infoSelect);
		UnitVal res = new UnitVal("0.0", unitSpan.code);
		List<UnitVal> listUnitVal = new ArrayList<UnitVal>();
		try {
			var listDto = FaceDto.getChronoSpan(spanDate, new JobDaily(parentId, infoSelect).val);
			if (listDto.size() != 0) {
				for (var curr : listDto) {
					listUnitVal.add(new UnitVal(curr.span, unitSpan.code));
				}
			}
			if (listUnitVal.size() != 0) {
				res = UnitVal.add(listUnitVal);
			}
		} catch (Exception ex) {
			WB.addLog("JobDaily.getTotalSpan(SpanDate spanDate, String parentId, String infoSelect):UnitVal, ex="
					+ ex.getMessage(), "", "JobDaily");
		}
		return res;
	}

	public static UnitVal getSpan(String date1, String parentId, String infoSelect) throws Exception {
		// origin - 08.05.2025, last edit - 13.06.2025
		Unit unitSpan = Unit.getExpectedFromInfo(infoSelect);
		UnitVal res = new UnitVal("0.0", unitSpan.code);
		List<UnitVal> listUnitVal = new ArrayList<UnitVal>();
		try {
			var val = new JobDaily(parentId, infoSelect).val;
			var listDto = FaceDto.getChrono(DateTool.getLocalDate(date1), val);
			if (listDto.size() != 0) {
				for (var curr : listDto) {
					listUnitVal.add(new UnitVal(curr.span, unitSpan.code));
				}
			}
			res = UnitVal.add(listUnitVal);
		} catch (Exception ex) {
			WB.addLog(
					"JobDaily.getSpan(String date1, String parentId, String infoSelect):UnitVal, ex=" + ex.getMessage(),
					"", "JobDaily");
		}
		return res;
	}

	// full list jobDaily for any date1, date2
	public static List<FaceDto> get(String parentId) throws Exception {
		// origin - 07.05.2025, last edit - 13.06.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			for (var currInfo : JobDaily.strInfoSelect) {
				var faceByParentRole = DAL.getByTemplate(WB.lastConnWork,
						Qry.getParentRoleInfoFilter(parentId, Role.faceJobDaily, currInfo), "Face");
				if (faceByParentRole.size() != 0) {
					for (var currFace : faceByParentRole) {
						var currJobDaily = new JobDaily(currFace.parent, currInfo);
						for (var curr : currJobDaily.val) {
							if (curr.id.isEmpty() == false) {
								res.add(curr);
							}
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("JobDaily.get(String parentId):List<FaceDto>, ex=" + ex.getMessage(), "", "JobDaily");
		}
		return res;
	}

	// full list jobDaily on date1
	public static List<FaceDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 07.05.2025, last edit - 13.06.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceByParentRole = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleFilter(parentId, Role.faceJobDaily), "Face");
			if (faceByParentRole.size() != 0) {
				for (var currFace : faceByParentRole) {
					var currFaceJobDaily = new JobDaily(currFace.parent, currFace.info);
					var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceJobDaily.val, "");
					if (curr.id.isEmpty() == false) {
						var tmp = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
								curr.geo, curr.role, curr.info, curr.more, curr.mark);
						tmp.span = curr.span;
						tmp.comment = curr.comment;
						tmp.fullName = curr.fullName;
						res.add(tmp);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("JobDaily.getCurr(String date1, String parentId):List<FaceDto>, ex=" + ex.getMessage(), "",
					"JobDaily");
		}
		return res;
	}

	// item jobDaily on date1
	public static FaceDto getCurr(String date1, String faceParentId, String infoSelect) throws Exception {
		// origin - 07.05.2025, last edit - 13.06.2025
		FaceDto res = new FaceDto();
		try {
			var currFaceJobDaily = new JobDaily(faceParentId, infoSelect);
			if (currFaceJobDaily.val.size() != 0) {
				var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceJobDaily.val, "");
				if (curr.id.isEmpty() == false) {
					res = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
							curr.geo, curr.role, curr.info, curr.more, curr.mark);
					res.span = curr.span;
					res.comment = curr.comment;
					res.fullName = curr.fullName;
				}
			}
		} catch (Exception ex) {
			WB.addLog("JobDaily.getCurr(String date1, String faceParentId, String infoSelect):FaceDto, ex="
					+ ex.getMessage(), "", "JobDaily");
		}
		return res;
	}

	private void getVal() throws Exception {
		// origin - 07.05.2025, last edit - 13.06.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currSpan = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currSpan = this.span.getByIndex(i);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description, this.geo,
						this.role, this.info, this.more, this.mark);
				tmp.span = currSpan;
				tmp.comment = this.comment;
				tmp.fullName = this.fullName;
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("JobDaily.getVal():void, ex=" + ex.getMessage(), "", "JobDaily");
		}
	}

	public void isExist() throws Exception {
		// origin - 07.05.2025, last edit - 13.06.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleInfoFilter(this.parent, Role.faceJobDaily, this.info), this.table);

			if (listDto.size() != 0) {
				for (var currDto : listDto) {
					var tmp = new SpanDate(currDto.date1, currDto.date2);
					this.date1 = new ListVal(tmp.date1);
					this.date2 = new ListVal(tmp.date2);

					this.id = DefVal.setCustom(this.id, currDto.id);
					this.parent = DefVal.setCustom(this.parent, currDto.parent);
					this.code = DefVal.setCustom(this.code, currDto.code);
					this.description = DefVal.setCustom(this.description, currDto.description);
					this.geo = DefVal.setCustom(this.geo, currDto.geo);
					this.role = DefVal.setCustom(this.role, currDto.role);
					this.info = DefVal.setCustom(this.info, currDto.info);
					this.more = DefVal.setCustom(this.more, currDto.more);
					this.mark = DefVal.setCustom(this.mark, currDto.mark);

					this.fullName = MoreVal.getFieldByKey(currDto.more, "FullName");
					this.comment = MoreVal.getFieldByKey(currDto.more, "Comment");

					this.span = new ListVal(MoreVal.getFieldByKey(currDto.more, "Span"), "");

					this.isExist = true;
					break;
				}
			}

			if (listDto.size() == 0) {
				this.parent = this.code = "";
			}
		} catch (Exception ex) {
			WB.addLog("JobDaily.isExist():void, ex=" + ex.getMessage(), "", "JobDaily");
		}
	}

	public JobDaily(String ParentId, String Info) throws Exception {
		// origin - 07.05.2025, last edit - 07.05.2025
		this.clear();
		this.table = "Face";
		this.src = ParentId + "," + Info;
		this.parent = ParentId;
		this.info = Info;// ex."Info.Staff.Late"
		this.isExist();
		this.getVal();
	}

	public void clear() throws Exception {
		// origin - 07.05.2025, last edit - 13.06.2025
		try {
			this.table = this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.more = this.mark = "";
			this.fullName = this.comment = "";
			this.date1 = this.date2 = this.span = new ListVal();
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("JobDaily.clear():void, ex=" + ex.getMessage(), "", "JobDaily");
		}
	}

	public JobDaily() throws Exception {
		// origin - 07.05.2025, last edit - 07.05.2025
		this.clear();
	}

	public String toString() {
		// origin - 07.05.2025, last edit - 07.05.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);

			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);

			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);

			res = res + Fmtr.addIfNotEmpty(", span ", this.span.id);

			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 07.05.2025, last edit - 13.06.2025
		try {

//			// test JobDaily.getTotalSpan(UnitVal)
//			WB.addLog2("JobDaily.test.getTotalSpan(UnitVal)", "", "JobDaily");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-05", "2025-02-03", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1.StaffTable1.ChiefAccountant" }) {
//					for (var tmp3 : new String[] { "Info.Staff.Late" }) {
//						WB.addLog2(
//								"JobDaily.test.getTotalSpan(UnitVal), res="
//										+ JobDaily.getTotalSpan(SpanDate.getMonth(tmp1), tmp2, tmp3) + ", spanDate="
//										+ SpanDate.getMonth(tmp1) + ", faceParentId=" + tmp2 + ", info=" + tmp3,
//								"", "JobDaily");
//					}
//				}
//			}

//			// test JobDaily.getSpan(FaceDto)
//			WB.addLog2("JobDaily.test.getSpan(UnitVal)", "", "JobDaily");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-05", "2025-02-03", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1.StaffTable1.ChiefAccountant" }) {
//					for (var tmp3 : new String[] { "Info.Staff.Late", "Info.Staff.Skip" }) {
//						WB.addLog2("JobDaily.test.getSpan(UnitVal), res=" + JobDaily.getSpan(tmp1, tmp2, tmp3)
//								+ ", date1=" + tmp1 + ", faceParentId=" + tmp2 + ", info=" + tmp3, "", "JobDaily");
//					}
//				}
//			}

//			// test JobDaily.get(List<FaceDto>)
//			WB.addLog2("JobDaily.test.get(List<FaceDto>)", "", "JobDaily");
//			for (var tmp1 : new String[] { "Face.FA1.StaffTable1.ChiefAccountant", "Face.FA1.StaffTable1.Boss" }) {
//				WB.addLog2("JobDaily.test.get(List<FaceDto>), res.size=" + JobDaily.get(tmp1).size() + ", parentId="
//						+ tmp1, "", "JobDaily");
//				WB.log(JobDaily.get(tmp1), "JobDaily");
//			}

//			// test JobDaily.getCurr(List<FaceDto>)
//			WB.addLog2("JobDaily.test.getCurr(List<FaceDto>)", "", "JobDaily");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-05", "2025-02-03", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1.StaffTable1.ChiefAccountant" }) {
//					WB.addLog2("JobDaily.test.getCurr(List<FaceDto>), res.size=" + JobDaily.getCurr(tmp1, tmp2).size()
//							+ ", date1=" + tmp1 + ", parentId=" + tmp2, "", "JobDaily");
//					WB.log(JobDaily.getCurr(tmp1, tmp2), "JobDaily");
//				}
//			}

//			// test JobDaily.getCurr(FaceDto)
//			WB.addLog2("JobDaily.test.getCurr(FaceDto)", "", "JobDaily");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-05", "2025-02-03", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1.StaffTable1.ChiefAccountant" }) {
//					for (var tmp3 : new String[] { "Info.Staff.Late", "Info.Staff.Skip" }) {
//						WB.addLog2("JobDaily.test.getCurr(FaceDto), res=" + JobDaily.getCurr(tmp1, tmp2, tmp3)
//								+ ", date1=" + tmp1 + ", faceParentId=" + tmp2 + ", info=" + tmp3, "",
//								"JobDaily");
//					}
//				}
//			}

//			// test JobDaily.ctor(String,String)
//			WB.addLog2("JobDaily.test.ctor(String,String)", "", "JobDaily");
//			for (var tmp1 : new String[] { "Face.FA1.StaffTable1.ChiefAccountant", "Face.FA1.StaffTable1.Boss" }) {
//				for (var tmp2 : new String[] { "Info.Staff.Late", "Info.Staff.Skip" }) {
//					WB.addLog2("JobDaily.test.ctor(String,String)=" + new JobDaily(tmp1, tmp2), "", "JobDaily");
//					WB.log(new JobDaily(tmp1, tmp2).val, "JobDaily");
//				}
//			}

//			// test JobDaily.ctor ()
//			WB.addLog2("JobDaily.test.ctor()", "", "JobDaily");
//			WB.addLog2("JobDaily.test.ctor()=" + new JobDaily(), "", "JobDaily");

		} catch (Exception ex) {
			WB.addLog("JobDaily.test():void, ex=" + ex.getMessage(), "", "JobDaily");
		}
	}
}