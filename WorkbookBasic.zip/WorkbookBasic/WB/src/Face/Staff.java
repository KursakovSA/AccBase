import java.util.ArrayList;
import java.util.List;

public class Staff {
	// origin - 12.03.2025, last edit - 13.08.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, code, description, geo, role, info, more, mark;
	// special fields
	public String faceCatId, fullName, comment;
	// special timestamp fields
	public ListVal date1, date2, salary, jobCycle;
	// list common + special + timestamp fields in unified val
	public List<FaceDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Staff.static ctor, ex=" + ex.getMessage(), "", "Staff");
		}
	}

	// for person total salary for all staff position on date1
	public static double getCurrSalary(String date1, String parentId) throws Exception {
		// origin - 31.03.2025, last edit - 13.06.2025
		double res = 0.00;
		try {
			var listDto = Staff.getCurr(date1, parentId);
			for (var currStaff : listDto) {
				res = res + Staff.getCurrSalary(date1, parentId, currStaff.code);
			}
		} catch (Exception ex) {
			WB.addLog("Staff.getCurrSalary(String date1, String parentId):double, ex=" + ex.getMessage(), "", "Staff");
		}
		return res;
	}

	// item Staff position salary on date1
	public static double getCurrSalary(String date1, String parentId, String staffTableId) throws Exception {
		// origin - 31.03.2025, last edit - 13.06.2025
		double res = 0.00;
		try {
			var tmp = Staff.getCurr(date1, parentId, staffTableId).salary;
			res = Conv.getDouble(tmp);
		} catch (Exception ex) {
			WB.addLog("Staff.getCurrSalary(String date1, String parentId, String staffTableId):double, ex="
					+ ex.getMessage(), "", "Staff");
		}
		return res;
	}

	// full list staff positions for all person
	public static List<FaceDto> get() throws Exception {
		// origin - 27.06.2025, last edit - 15.09.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter("Role.Face.Staff"), "Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					for (var curr : new Staff(currFace.parent, currFace.code).val) {
						if (curr.id.isEmpty() == false) {
							var tmp = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code,
									curr.description, curr.geo, curr.role, curr.info, curr.more, curr.mark);
							tmp.faceCatId = MoreVal.getFieldByKey(curr.more, "FaceCatId");
							tmp.salary = curr.salary;
							tmp.jobCycle = curr.jobCycle;
							res.add(tmp);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Staff.get(String parentId):List<FaceDto>, ex=" + ex.getMessage(), "", "Staff");
		}
		return res;
	}

	// full list staff positions for person
	public static List<FaceDto> get(String parentId) throws Exception {
		// origin - 04.05.2025, last edit - 15.09.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, "Role.Face.Staff"),
					"Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					for (var curr : new Staff(currFace.parent, currFace.code).val) {
						if (curr.id.isEmpty() == false) {
							var tmp = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code,
									curr.description, curr.geo, curr.role, curr.info, curr.more, curr.mark);
							tmp.faceCatId = MoreVal.getFieldByKey(curr.more, "FaceCatId");
							tmp.salary = curr.salary;
							tmp.jobCycle = curr.jobCycle;
							res.add(tmp);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Staff.get(String parentId):List<FaceDto>, ex=" + ex.getMessage(), "", "Staff");
		}
		return res;
	}

	// full list staff positions for person on date1 (currSalary)
	public static List<FaceDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 12.03.2025, last edit - 15.09.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, "Role.Face.Staff"),
					"Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					var currFaceStaff = new Staff(currFace.parent, currFace.code);
					var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceStaff.val, "");
					if (curr.id.isEmpty() == false) {
						var tmp = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
								curr.geo, curr.role, curr.info, curr.more, curr.mark);
						tmp.faceCatId = MoreVal.getFieldByKey(curr.more, "FaceCatId");
						tmp.salary = curr.salary;
						tmp.jobCycle = curr.jobCycle;
						res.add(tmp);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Staff.getCurr(String date1, String parentId):List<FaceDto>, ex=" + ex.getMessage(), "", "Staff");
		}
		return res;
	}

	// item staff position for person on date1 (currSalary)
	public static FaceDto getCurr(String date1, String parentId, String staffTableId) throws Exception {
		// origin - 12.03.2025, last edit - 01.07.2025
		FaceDto res = new FaceDto();
		try {
			var currFaceStaffNote = new Staff(parentId, staffTableId);
			var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceStaffNote.val, "");
			if (curr.id.isEmpty() == false) {
				res = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description, curr.geo,
						curr.role, curr.info, curr.more, curr.mark);
				res.faceCatId = MoreVal.getFieldByKey(curr.more, "FaceCatId");
				res.salary = curr.salary;
				res.jobCycle = curr.jobCycle;
			}
		} catch (Exception ex) {
			WB.addLog(
					"Staff.getCurr(String date1, String parentId, String staffTableId):FaceDto, ex=" + ex.getMessage(),
					"", "Staff");
		}
		return res;
	}

	private void getVal() throws Exception {
		// origin - 12.03.2025, last edit - 01.07.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currSalary = "";
			String currJobCycle = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currSalary = this.salary.getByIndex(i);
				currJobCycle = this.jobCycle.getByIndex(i);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description, this.geo,
						this.role, this.info, currSalary, this.mark);
				tmp.faceCatId = MoreVal.getFieldByKey(tmp.more, "FaceCatId");
				tmp.salary = currSalary;
				tmp.jobCycle = new JobCycle(currJobCycle);
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("Staff.getVal():void, ex=" + ex.getMessage(), "", "Staff");
		}
	}

	private void isExist() throws Exception {
		// origin - 12.03.2025, last edit - 15.09.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentCodeRoleFilter(this.parent, this.code, "Role.Face.Staff"), "Face");
			if (listDto.size() != 0) {
				for (var currDto : listDto) {
					var tmp = new SpanDate(currDto.date1, currDto.date2);
					this.date1 = new ListVal(tmp.date1);
					this.date2 = new ListVal(tmp.date2);

					this.id = DefVal.setCustom(this.id, currDto.id);
					this.parent = DefVal.setCustom(this.parent, currDto.parent);
					this.code = DefVal.setCustom(this.code, currDto.code);
					this.description = DefVal.setCustom(this.description, currDto.description);
					this.geo = DefVal.setCustom(this.geo, currDto.geo);
					this.role = DefVal.setCustom(this.role, currDto.role);
					this.info = DefVal.setCustom(this.info, currDto.info);
					this.more = DefVal.setCustom(this.more, currDto.more);
					this.mark = DefVal.setCustom(this.mark, currDto.mark);
					this.getFieldFromMore();
					this.isExist = true;
					break;
				}
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("Staff.isExist():void, ex=" + ex.getMessage(), "", "Staff");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 13.08.2025, last edit - 13.08.2025
		try {
			this.salary = new ListVal(MoreVal.getFieldByKey(this.more, "Salary"), "");
			this.jobCycle = new ListVal(MoreVal.getFieldByKey(this.more, "JobCycle"), "");
			this.faceCatId = MoreVal.getFieldByKey(this.more, "FaceCatId");
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("Staff.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Staff");
		}
	}

	public Staff(String ParentId, String StaffTableId) throws Exception {
		// origin - 12.03.2025, last edit - 11.08.2025
		this.clear();
		this.src = ParentId + "," + StaffTableId;
		this.parent = ParentId;
		this.code = StaffTableId;
		this.isExist();
		this.getVal();
	}

	private void clear() throws Exception {
		// origin - 12.03.2025, last edit - 06.09.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = "Face";
			this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.mark = this.more = "";
			this.faceCatId = this.comment = this.fullName = "";
			this.date1 = this.date2 = this.salary = this.jobCycle = new ListVal();
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("Staff.clear():void, ex=" + ex.getMessage(), "", "Staff");
		}
	}

	public Staff() throws Exception {
		// origin - 12.03.2025, last edit - 12.03.2025
		this.clear();
	}

	public String toString() {
		// origin - 12.03.2025, last edit - 13.08.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);

			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);

			res = res + Fmtr.addIfNotEmpty(", faceCatId ", this.faceCatId);
			res = res + Fmtr.addIfNotEmpty(", salary ", this.salary.id);
			res = res + Fmtr.addIfNotEmpty(", jobCycle ", this.jobCycle.id);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);

			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 12.03.2025, last edit - 27.06.2025
		try {

//			WB.addLog2("Staff.test.get(List<FaceDto>)", "", "Staff");
//			for (var tmp1 : new String[] { "Face.Person.Template", "Face.Tralala" }) {
//				WB.addLog2("Staff.test.get(List<FaceDto>), res.size=" + Staff.get(tmp1).size() + ", parentId=" + tmp1,
//						"", "Staff");
//				WB.log(Staff.get(tmp1), "Staff");
//			}

//			WB.addLog2("Staff.test.getCurrSalary(double) for person/all staffTable", "", "Staff");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.Person.Template" }) {
//					WB.addLog2(
//							"Staff.test.getCurrSalary(double) for person/all staffTable, res="
//									+ Staff.getCurrSalary(tmp1, tmp2) + ", date1=" + tmp1 + ", parentId=" + tmp2,
//							"", "Staff");
//				}
//			}

//			WB.addLog2("Staff.test.getCurrSalary(double) for person/staffTable", "", "Staff");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.Person.Template" }) {
//					for (var tmp3 : new String[] { "Face.FA1.StaffTable1.Boss",
//							"Face.FA1.StaffTable1.ChiefAccountant" }) {
//						WB.addLog2("Staff.test.getCurrSalary(double) for person/staffTable, res="
//								+ Staff.getCurrSalary(tmp1, tmp2, tmp3) + ", date1=" + tmp1 + ", parentId=" + tmp2
//								+ ", staffTableId=" + tmp3, "", "Staff");
//					}
//				}
//			}

//			WB.addLog2("Staff.test.getCurr(List<FaceDto>)", "", "Staff");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.Person.Template", "Face.Tralala" }) {
//					WB.addLog2("Staff.test.getCurr(List<FaceDto>), res.size=" + Staff.getCurr(tmp1, tmp2).size()
//							+ ", date1=" + tmp1 + ", parentId=" + tmp2, "", "Staff");
//			WB.log(Staff.getCurr(tmp1, tmp2), "Staff");
//				}
//			}

//			WB.addLog2("Staff.test.getCurr(FaceDto)", "", "Staff");
//			for (var tmp1 : new String[] { "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01", "2025-02-28",
//					"2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.Person.Template" }) {
//					for (var tmp3 : new String[] { "Face.FA1.StaffTable1.Boss",
//							"Face.FA1.StaffTable1.ChiefAccountant" }) {
//						WB.addLog2("Staff.test.getCurr(FaceDto), res=" + Staff.getCurr(tmp1, tmp2, tmp3) + ", date1="
//								+ tmp1 + ", parentId=" + tmp2 + ", staffTableId=" + tmp3, "", "Staff");
//					}
//				}
//			}

//			WB.addLog2("Staff.test.ctor(String,String)", "", "Staff");
//			for (var tmp1 : new String[] { "Face.Person.Template", "Face.kgd", "Face.Tralala" }) {
//				for (var tmp2 : new String[] { "Face.FA1.StaffTable1.Boss", "Face.FA1.StaffTable1.ChiefAccountant",
//						"Face.FA1.StaffTable1.Tralala" }) {
//					var tmp3 = new Staff(tmp1, tmp2);
//					WB.addLog2("Staff.test.ctor(String,String)=" + tmp3, "", "Staff");
//					WB.log(tmp3.val, "Staff");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("Staff.test():void, ex=" + ex.getMessage(), "", "Staff");
		}
	}
}