import java.util.ArrayList;
import java.util.List;

public final class Face {
	// origin - 28.09.2023, last edit - 16.09.2026
	// common fields
	public String table, src, id, parent, date1, date2, code, description, geo, role, info, more, mark, defect;
	// special fields
	public static FaceDto currFA;
	public String fullName, comment;
	public List<String> structId;
	public List<FaceDto> storeList, deptList, cashList, crewList, staffTableList, staffList, contactList, dailyList,
			pointList, addressList;
	public List<BankAccount> bankAccountList;
	public List<UserAccount> userAccountList;
	public Personal personal;
	public FaceSign faceSign;
	public FaceGovId faceGovId;
	public JobCycle jobCycle;
	public List<FullDto> lowerList, upperList;
	public static List<String> nameList;

	static {
		try {
			Face.nameList = List.of("BankAccount", "Logo");
			Face.currFA = Face.getCurrFA();
		} catch (Exception ex) {
			WB.addLog("Face.static ctor, ex=" + ex.getMessage(), "", "Face");
		}
	}

	private void fix() throws Exception { // TODO
		// origin - 01.05.2026, last edit - 17.08.2026
		try {
			if (this.id.isEmpty() == false) {
				this.date1 = DefVal.set(this.date1, WB.minDateSupported.toString());
				this.date2 = DefVal.set(this.date2, WB.maxDateSupported.toString());
				this.mark = DefVal.set(this.mark, "Mark.DD");
			}
		} catch (Exception ex) {
			WB.addLog("Face.fix():void, ex=" + ex.getMessage(), "", "Face");
		}
	}

	public static String getDateBirth(String faceId) throws Exception {
		// origin - 29.11.2025, last edit - 15.08.2026
		String res = "";
		try {
			var face = new Face(faceId);
			res = face.getDateBirthByFaceGovId();
		} catch (Exception ex) {
			WB.addLog("Face.getDateBirth(String):String, ex=" + ex.getMessage(), "", "Face");
		}
		return res;
	}

	public static String getFIO(String faceId) throws Exception {// from "Smith John Oakland" to "Smith J. O."
		// origin - 27.11.2025, last edit - 15.08.2026
		String res = "";
		try {
			var tmp = Face.getFullName(faceId);
			res = new FIO(tmp).code; // from "Smith John Oakland" to "Smith J. O."
		} catch (Exception ex) {
			WB.addLog("Face.getFIO(String):String, ex=" + ex.getMessage(), "", "Face");
		}
		return res;
	}

	public static FullDto getFullDtoByList(List<String> in) throws Exception {
		// origin - 02.03.2026, last edit - 02.03.2026
		FullDto res = new FullDto();
		try {
			res.table = "Face";
			res.id = Etc.fixTrim(in.get(0));
			res.parent = Etc.fixTrim(in.get(1));
			res.date1 = Etc.fixTrim(in.get(2));
			res.date2 = Etc.fixTrim(in.get(3));
			res.code = Etc.fixTrim(in.get(4));
			res.description = Etc.fixTrim(in.get(5));
			res.geo = Etc.fixTrim(in.get(6));
			res.role = Etc.fixTrim(in.get(7));
			res.info = Etc.fixTrim(in.get(8));
			res.more = Etc.fixTrim(in.get(9));
			res.mark = Etc.fixTrim(in.get(10));
		} catch (Exception ex) {
			WB.addLog("Face.getFullDtoByList(List<String>):FullDto, ex=" + ex.getMessage(), "", "Face");
		}
		return res;
	}

	public static List<String> getListByFullDto(FullDto in) throws Exception {
		// origin - 31.01.2026, last edit - 01.03.2026
		List<String> res = new ArrayList<String>();
		try {
			res.add(in.id);
			res.add(in.parent);
			res.add(in.date1);
			res.add(in.date2);
			res.add(in.code);
			res.add(in.description);
			res.add(in.geo);
			res.add(in.role);
			res.add(in.info);
			res.add(in.more);
			res.add(in.mark);
		} catch (Exception ex) {
			WB.addLog("Face.getByTable(FullDto):List<String>, ex=" + ex.getMessage(), "", "Face");
		}
		return res;
	}

	public static List<FullDto> getMassReg(int countFace) throws Exception { // TODO
		// origin - 30.09.2025, last edit - 30.09.2025
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			for (int i = 1; i <= countFace; i++) {
			}
		} catch (Exception ex) {
			WB.addLog("Face.getMassReg(int):List<FullDto>, ex=" + ex.getMessage(), "", "Face");
		}
		return res;
	}

	public static String getBossSign(String faceId) throws Exception {
		// origin - 26.04.2026, last edit - 26.04.2026
		String res = "";
		try {
			var tmp = new Face(faceId);
			res = tmp.faceSign.val1;
		} catch (Exception ex) {
			WB.addLog("Face.getBossSign(String):String, ex=" + ex.getMessage(), "", "Face");
		}
		return res;
	}

	public static String getChiefAccountantSign(String faceId) throws Exception {
		// origin - 26.04.2026, last edit - 26.04.2026
		String res = "";
		try {
			var tmp = new Face(faceId);
			res = tmp.faceSign.val2;
		} catch (Exception ex) {
			WB.addLog("Face.getChiefAccountantSign(String):String, ex=" + ex.getMessage(), "", "Face");
		}
		return res;
	}

	public static String getGovId(String faceId, String kindFaceGovId) throws Exception {
		// origin - 26.04.2026, last edit - 26.04.2026
		String res = "";
		try {
			var tmp = new Face(faceId);
			res = FaceGovId.getByKind(tmp.faceGovId.val, kindFaceGovId);
		} catch (Exception ex) {
			WB.addLog("Face.getGovId(2String):String, ex=" + ex.getMessage(), "", "Face");
		}
		return res;
	}

//	private String getGovId(String kindFaceGovId) throws Exception {
//		// origin - 25.09.2025, last edit - 26.04.2026
//		String res = "";
//		try {
//			res = FaceGovId.getByKind(this.faceGovId.val, kindFaceGovId);
//		} catch (Exception ex) {
//			WB.addLog("Face.getGovId(String):String, ex=" + ex.getMessage(), "", "Face");
//		}
//		return res;
//	}

	public static List<FullDto> getHistoryByTaxId() throws Exception {// TODO by IIN,BIN
		// origin - 10.09.2025, last edit - 10.09.2025
		List<FullDto> res = new ArrayList<FullDto>();
		try {
		} catch (Exception ex) {
			WB.addLog("Face.getHistoryByTaxId():List<FullDto>, ex=" + ex.getMessage(), "", "Face");
		}
		return res;
	}

	public static String getFullName(String faceId) throws Exception {
		// origin - 27.11.2025, last edit - 27.11.2025
		String res = "";
		try {
			var face = new Face(faceId);
			res = Etc.fixTrim(face.fullName);
			if (res.isEmpty()) {
				res = Etc.fixTrim(face.description);
			}
			if (res.isEmpty()) {
				res = Etc.fixTrim(face.code);
			}
			if (res.isEmpty()) {
				res = Etc.fixTrim(face.id);
			}
		} catch (Exception ex) {
			WB.addLog("Face.getFullName(String):String, ex=" + ex.getMessage(), "", "Face");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 20.11.2025, last edit - 16.09.2026
		try {
			if (this.id.isEmpty() == false) {
				this.defect = Fmtr.addIfStrEmpty(this.defect, MoreVal.getFieldByKey(this.more, "TemplateId"),
						"empty templateId; ");
			}
		} catch (Exception ex) {
			WB.addLog("Face.validate():void, ex=" + ex.getMessage(), "", "Face");
		}
	}

	public void getByTemplate() throws Exception { // TODO
		// origin - 17.05.2025, last edit - 13.06.2025
		try {
//			this.id = new IdGen("", "").id;
//			this.date1 = DateTool.getNow().toString();
//			this.date2 = "";
//			this.code = "";
//			this.description = "";
//			this.more = this.getMoreFromField();
//			this.mark = Mark.DD;
		} catch (Exception ex) {
			WB.addLog2("Face.getByTemplate():void, ex=" + ex.getMessage(), "", "Face");
		}
	}

	public String getDateBirthByFaceGovId() throws Exception {
		// origin - 13.05.2025, last edit - 26.04.2026
		String res = "";
		try {
			var tmp = FaceGovId.getByKind(this.faceGovId.val, FaceGovId.defaultKindPerson);
			// var tmp = this.getGovId(FaceGovId.defaultKindPerson);
			// WB.addLog2("Face.getDateBirthByFaceGovId(), tmp=" + tmp, "", "Face");
			res = DateTool.getDateBirthFromKZIIN(tmp, "");
		} catch (Exception ex) {
			WB.addLog("Face.getDateBirthByFaceGovId():String, ex=" + ex.getMessage(), "", "Face");
		}
		return res;
	}

	private void getPart() throws Exception {
		// origin - 06.03.2025, last edit - 15.12.2025
		try {
			this.addressList = Address.get(this.id);
			this.staffTableList = StaffTable.get(this.id);
			this.staffList = Staff.get(this.id);
			this.storeList = Store.get(this.id);
			this.deptList = Dept.get(this.id);
			this.cashList = Cash.get(this.id);
			this.bankAccountList = Bank.getAccount(this.id);
			this.userAccountList = UserAccount.getByParent(this.id);
			this.crewList = Crew.get(this.id);
			this.contactList = FaceContact.get(this.id);
			this.dailyList = FaceDaily.get(this.id);
			this.pointList = Point.get(this.id);
		} catch (Exception ex) {
			WB.addLog("Face.getPart(), ex=" + ex.getMessage(), "", "Face");
		}
	}

	public static FaceDto getCurrFA() throws Exception {
		// origin - 23.11.2024, last edit - 15.09.2025
		FaceDto res = new FaceDto();
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter("Role.Face.FA"), "Face");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst(); // TOTHINK
				res = new FaceDto(dto.id, dto.parent, dto.date1, dto.date2, dto.code, dto.description, dto.geo,
						dto.role, dto.info, dto.more, dto.mark);
				// WB.addLog2("Face.getCurrFA(), dto=" + dto + ", res=" + res,"","Face");
			}
		} catch (Exception ex) {
			WB.addLog("Face.getCurrFA():FaceDto, ex=" + ex.getMessage(), "", "Face");
		}
		return res;
	}

	private void isExist() throws Exception {
		// origin - 27.11.2024, last edit - 17.08.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), "Face");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.id = dto.id;
				this.code = dto.code;
				this.parent = dto.parent;
				this.date1 = dto.date1;
				this.date2 = dto.date2;
				this.description = dto.description;
				this.geo = DefVal.set(dto.geo, Geo.currCountry.id);
				this.role = dto.role;
				this.info = dto.info;
				this.more = dto.more;
				this.mark = DefVal.set(dto.mark, "Mark.DD");
				this.upperList = FullDto.getUpper(this.table, this.parent);
				this.lowerList = FullDto.getLower(this.table, this.id);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.clear();
			}
		} catch (Exception ex) {
			WB.addLog("Face.isExist():void, ex=" + ex.getMessage(), "", "Face");
		}
	}

	private String getMoreFromField() throws Exception {
		// origin - 18.05.2025, last edit - 16.09.2026
		String res = "";
		try {
			res = res + MoreVal.setPart("FullName", this.fullName);
			res = res + MoreVal.setPart("Comment", this.comment);
			res = res + MoreVal.setPart("Personal", this.personal.src);
			res = res + MoreVal.setPart("FaceGovId", this.faceGovId.src);
			res = res + MoreVal.setPart("FaceSign", this.faceSign.src);
			res = res + MoreVal.setPart("JobCycle", this.jobCycle.src);
		} catch (Exception ex) {
			WB.addLog("Face.getMoreFromField():String, ex=" + ex.getMessage(), "", "Face");
		}
		return res;
	}

	private void getFieldFromMore() throws Exception {
		// origin - 18.05.2025, last edit - 16.09.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.personal = new Personal(MoreVal.getFieldByKey(this.more, "Personal"));
			this.faceGovId = new FaceGovId(MoreVal.getFieldByKey(this.more, "FaceGovId"));
			this.faceSign = new FaceSign(MoreVal.getFieldByKey(this.more, "FaceSign"));
			this.jobCycle = new JobCycle(MoreVal.getFieldByKey(this.more, "JobCycle"));
			this.structId = FaceStructId.getListByNameList(more, FaceStructId.nameList);
		} catch (Exception ex) {
			WB.addLog("Face.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Face");
		}
	}

	// get new face by template
	public Face(String templateId, String Code, String Description) throws Exception {
		// origin - 21.05.2025, last edit - 01.05.2026
		this(templateId);
		this.id = new IdGen("", "").id;
		this.date1 = DateTool.getNow().toString();
		this.date2 = "";
		this.code = Code;
		this.description = Description;
		this.more = this.getMoreFromField();
		this.getFieldFromMore();
		this.mark = "Mark.DD";
		this.fix();
		this.validate();
	}

	public Face(String Id) throws Exception {
		// origin - 05.12.2023, last edit - 17.08.2026
		this.clear();
		this.src = this.id = this.code = Id;
		this.isExist();
		if (this.id.isEmpty() == false) {
			this.getPart();
			this.fix();
			this.validate();
		}
	}

	public Face() throws Exception {
		// origin - 05.12.2023, last edit - 19.05.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 25.11.2024, last edit - 16.09.2026
		try {
			this.table = "Face";
			this.src = this.id = this.parent = this.date1 = this.date2 = this.code = this.description = "";
			this.geo = this.role = this.info = this.more = this.mark = this.defect = "";
			this.fullName = this.comment = "";
			this.addressList = new ArrayList<FaceDto>();
			this.staffTableList = new ArrayList<FaceDto>();
			this.staffList = new ArrayList<FaceDto>();
			this.storeList = new ArrayList<FaceDto>();
			this.deptList = new ArrayList<FaceDto>();
			this.cashList = new ArrayList<FaceDto>();
			this.bankAccountList = new ArrayList<BankAccount>();
			this.personal = new Personal();
			this.faceSign = new FaceSign();
			this.faceGovId = new FaceGovId();
			this.userAccountList = new ArrayList<UserAccount>();
			this.crewList = new ArrayList<FaceDto>();
			this.contactList = new ArrayList<FaceDto>();
			this.dailyList = new ArrayList<FaceDto>();
			this.pointList = new ArrayList<FaceDto>();
			this.jobCycle = new JobCycle();
			this.lowerList = new ArrayList<FullDto>();
			this.upperList = new ArrayList<FullDto>();
			this.structId = new ArrayList<String>();
		} catch (Exception ex) {
			WB.addLog("Face.clear():void, ex=" + ex.getMessage(), "", "Face");
		}
	}

	public String toString() {
		// origin - 24.11.2023, last edit - 16.09.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", fullname ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", personal ", this.personal.src);
			res = res + Fmtr.addIfNotEmpty(", faceGovId ", this.faceGovId);
			res = res + Fmtr.addIfNotEmpty(", faceSign ", this.faceSign.id);
			res = res + Fmtr.addIfNotEmpty(", jobCycle ", this.jobCycle.id);
			res = res + Fmtr.addIfNotEmpty(", staffTableList ", this.staffTableList.size());
			res = res + Fmtr.addIfNotEmpty(", staffList ", this.staffList.size());
			res = res + Fmtr.addIfNotEmpty(", addressList ", this.addressList.size());
			res = res + Fmtr.addIfNotEmpty(", storeList ", this.storeList.size());
			res = res + Fmtr.addIfNotEmpty(", deptList ", this.deptList.size());
			res = res + Fmtr.addIfNotEmpty(", cashList ", this.cashList.size());
			res = res + Fmtr.addIfNotEmpty(", bankAccountList ", this.bankAccountList.size());
			res = res + Fmtr.addIfNotEmpty(", userList ", this.userAccountList.size());
			res = res + Fmtr.addIfNotEmpty(", contactList ", this.contactList.size());
			res = res + Fmtr.addIfNotEmpty(", dailyList ", this.dailyList.size());
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 17.08.2026
		try {

//			WB.addLog2("Face.test.getDateBirth(String):String", "", "Face");
//			for (var tmp1 : new String[] { "Face.Person.Template", "Face.Tralala" }) {
//				WB.addLog2("Face.test.getDateBirth(String):String, res=" + Face.getDateBirth(tmp1) + ", tmp1="
//						+ tmp1, "", "Face");
//			}

//			WB.addLog2("Face.test.getFIO(String):String", "", "Face");
//			for (var tmp1 : new String[] { "Face.FA1", "Face.Enterprise.Template", "Face.Person.Template",
//					"Face.Tralala" }) {
//				WB.addLog2("Face.test.getFIO(String):String, res=" + Face.getFIO(tmp1) + ", tmp1=" + tmp1, "", "Face");
//			}

//			WB.addLog2("Face.test.getDateBirthByFaceGovId()", "", "Face");
//			for (var tmp1 : new String[] { "Face.FA1", "Face.Enterprise.Template", "Face.Person.Template",
//					"Face.Tralala" }) {
//				var tmp2 = new Face(tmp1);
//				WB.addLog2("Face.test.getDateBirthByFaceGovId(), res=" + tmp2.getDateBirthByFaceGovId()
//						+ ", face.faceGovId=" + tmp2.faceGovId, "", "Face");
//			}

//			WB.addLog2("Face.test.getFullName(String)", "", "Face");
//			for (var tmp1 : new String[] { "Face.FA1", "Face.Enterprise.Template", "Face.Person.Template",
//					"Face.Tralala" }) {
//				WB.addLog2("Face.test.getFullName(String), res=" + Face.getFullName(tmp1) + ", faceId=" + tmp1, "",
//						"Face");
//			}

//			WB.addLog2("Face.test.getGovId(2String)", "", "Face");
//			for (var tmp1 : new String[] { "Face.FA1", "Face.Enterprise.Template", "Face.Person.Template",
//					"Face.Tralala" }) {
//				for (var tmp2 : new String[] { "БИН", "ИИН", "РНН", "Tralala" }) {
//					WB.addLog2("Face.test.getGovId(2String), res=" + Face.getGovId(tmp1, tmp2) + ", faceId=" + tmp1
//							+ ", kindFaceGovId=" + tmp2, "", "Face");
//				}
//			}

//			WB.addLog2("Face.test.ctor(3String)", "", "Face");
//			for (var tmp1 : new String[] { "Face.Enterprise.Template", "Face.Person.Template",
//					"Fact job cycle emp 002" }) {
//				WB.addLog2("Face.test.ctor(3String)=" + new Face(tmp1, "Test", "Test"), "", "Face");
//			}

//			WB.addLog2("Face.test.ctor(String)", "", "Face");
//			for (var tmp1 : new String[] { "", "Face.Enterprise.Template", "Face.FA1", "Face.Person.Template",
//					"Face.FA1.AdmStaff", "Face.kgd", "Fact job cycle emp 002", "Face.Tralala" }) {
//				WB.addLog2("Face.test.ctor(String)=" + new Face(tmp1) + ", tmp1=" + tmp1, "", "Face");
//			}

		} catch (Exception ex) {
			WB.addLog("Face.test():void, ex=" + ex.getMessage(), "", "Face");
		}
	}
}