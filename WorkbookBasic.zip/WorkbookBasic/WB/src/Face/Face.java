import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unused")
public class Face {
	// origin - 28.09.2023, last edit - 01.07.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, date1, date2, code, description, geo, role, info, more, mark;
	// special fields
	public static FaceDto currFA;
	public String templateId;
	public String storeId, cashId, cashierEmpId, userId, deptId, pointId, staffTableId, empId, crewId;
	public String fullName, comment, sex;
	public String bin, iin, rnn, idKZ, logo;
	public List<FaceDto> store, dept, cash, bank, user, crew, staffTable, staff, contact, daily, point, address;
	public JobCycle jobCycle;
	public List<ModelDto> lower, upper;

	static {
		try {
			Face.currFA = Face.getCurrFA();
			// WB.addLog2("Face.currFA=" + Face.currFA, "", "Face");
		} catch (Exception ex) {
			WB.addLog("Face.static ctor, ex=" + ex.getMessage(), "", "Face");
		}
	}

	public static List<ModelDto> getHistoryByTaxId() throws Exception {// TODO by IIN/BIN
		// origin - 10.09.2025, last edit - 10.09.2025
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
		} catch (Exception ex) {
			WB.addLog("Face.getHistoryByTaxId():List<ModelDto>, ex=" + ex.getMessage(), "", "Face");
		}
		return res;
	}

	public void getByTemplate() throws Exception {
		// origin - 17.05.2025, last edit - 13.06.2025
		try {
//			this.id = new IdGen("", "").id;
//			this.date1 = DateTool.getNow().toString();
//			this.date2 = "";
//			this.code = "";
//			this.description = "";
//			this.more = this.getMoreFromField();
//			this.mark = Mark.DD;
		} catch (Exception ex) {
			WB.addLog2("Face.getByTemplate():void, ex=" + ex.getMessage(), "", "Face");
		}
	}

	private String getDateBirth() throws Exception {// TODO calc from IIN
		// origin - 13.05.2025, last edit - 13.06.2025
		String res = "";
		try {
		} catch (Exception ex) {
			WB.addLog("Face.getDateBirth():String, ex=" + ex.getMessage(), "", "Face");
		}
		return res;
	}

	private void getPart() throws Exception {
		// origin - 06.03.2025, last edit - 13.06.2025
		try {
			this.address = Address.get(this.id);
			this.staffTable = StaffTable.get(this.id);
			this.staff = Staff.get(this.id);
			this.store = Store.get(this.id);
			this.dept = Dept.get(this.id);
			this.cash = Cash.get(this.id);
			this.bank = Bank.get(this.id);
			this.user = User.get(this.id);
			this.crew = Crew.get(this.id);
			this.contact = FaceContact.get(this.id);
			this.daily = FaceDaily.get(this.id);
			this.point = Point.get(this.id);
		} catch (Exception ex) {
			WB.addLog("Face.getPart(), ex=" + ex.getMessage(), "", "Face");
		}
	}

	public static FaceDto getCurrFA() throws Exception {
		// origin - 23.11.2024, last edit - 15.09.2025
		FaceDto res = new FaceDto();
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter("Role.Face.FA"), "Face");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst(); // TOTHINK
				res = new FaceDto(dto.id, dto.parent, dto.date1, dto.date2, dto.code, dto.description, dto.geo,
						dto.role, dto.info, dto.more, dto.mark);
				// WB.addLog2("Face.getCurrFA(), dto=" + dto + ", res=" + res,"","Face");
			}
		} catch (Exception ex) {
			WB.addLog("Face.getCurrFA():FaceDto, ex=" + ex.getMessage(), "", "Face");
		}
		return res;
	}

	private void isExist() throws Exception {
		// origin - 27.11.2024, last edit - 15.09.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getCodeFilter(this.id), "Face");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.code = dto.code;
				this.parent = dto.parent;
				this.date1 = dto.date1;
				this.date2 = dto.date2;
				this.description = dto.description;
				this.geo = DefVal.set(dto.geo, Geo.currCountry.id);
				this.role = dto.role;
				this.info = dto.info;
				this.more = dto.more;
				this.mark = DefVal.set(dto.mark, "Mark.DD");

				var listDto2 = DAL.getTable(WB.lastConnWork, Qry.getText(WB.lastConnWork, "Face", ""));
				this.upper = ModelDto.getUpper(listDto2, this.parent);
				this.lower = ModelDto.getLower(listDto2, this.code);

				this.isExist = true;
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("Face.isExist():void, ex=" + ex.getMessage(), "", "Face");
		}
	}

	private String getMoreFromField() throws Exception {
		// origin - 18.05.2025, last edit - 26.06.2025
		String res = "";
		try {
			res = res + MoreVal.setPartMore("Fullname", this.fullName);
			res = res + MoreVal.setPartMore("Comment", this.comment);
			res = res + MoreVal.setPartMore("Sex", this.sex);

			res = res + MoreVal.setPartMore("StoreId", this.storeId);
			res = res + MoreVal.setPartMore("CashId", this.cashId);
			res = res + MoreVal.setPartMore("cashierEmpId", this.cashierEmpId);
			res = res + MoreVal.setPartMore("UserId", this.userId);
			res = res + MoreVal.setPartMore("DeptId", this.deptId);
			res = res + MoreVal.setPartMore("PointId", this.pointId);
			res = res + MoreVal.setPartMore("StaffTableId", this.staffTableId);
			res = res + MoreVal.setPartMore("EmpId", this.empId);
			res = res + MoreVal.setPartMore("CrewId", this.crewId);

			res = res + MoreVal.setPartMore("bin", this.bin);
			res = res + MoreVal.setPartMore("iin", this.iin);
			res = res + MoreVal.setPartMore("rnn", this.rnn);
			res = res + MoreVal.setPartMore("idKZ", this.idKZ);
			res = res + MoreVal.setPartMore("Logo", this.logo);

			res = res + MoreVal.setPartMore("TemplateId", this.templateId);
			res = res + MoreVal.setPartMore("JobCycle", this.jobCycle.src);
		} catch (Exception ex) {
			WB.addLog("Face.getMoreFromField():String, ex=" + ex.getMessage(), "", "Face");
		}
		return res;
	}

	private void getFieldFromMore() throws Exception {
		// origin - 18.05.2025, last edit - 26.06.2025
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "Fullname");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.sex = MoreVal.getFieldByKey(this.more, "Sex");

			this.storeId = MoreVal.getFieldByKey(this.more, "StoreId");
			this.cashId = MoreVal.getFieldByKey(this.more, "CashId");
			this.cashierEmpId = MoreVal.getFieldByKey(this.more, "cashierEmpId");
			this.userId = MoreVal.getFieldByKey(this.more, "UserId");
			this.deptId = MoreVal.getFieldByKey(this.more, "DeptId");
			this.pointId = MoreVal.getFieldByKey(this.more, "PointId");
			this.staffTableId = MoreVal.getFieldByKey(this.more, "StaffTableId");
			this.empId = MoreVal.getFieldByKey(this.more, "EmpId");
			this.crewId = MoreVal.getFieldByKey(this.more, "CrewId");

			this.bin = MoreVal.getFieldByKey(this.more, "BIN");
			this.iin = MoreVal.getFieldByKey(this.more, "IIN");
			this.rnn = MoreVal.getFieldByKey(this.more, "RNN");
			this.idKZ = MoreVal.getFieldByKey(this.more, "IdKZ");
			this.logo = MoreVal.getFieldByKey(this.more, "Logo");

			this.templateId = MoreVal.getFieldByKey(this.more, "TemplateId");

			this.jobCycle = new JobCycle(MoreVal.getFieldByKey(this.more, "JobCycle"));
		} catch (Exception ex) {
			WB.addLog("Face.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Face");
		}
	}

	// get new face by template
	public Face(String templateId, String Code, String Description) throws Exception {
		// origin - 21.05.2025, last edit - 15.09.2025
		this(templateId);
		this.id = new IdGen("", "").id;
		this.date1 = DateTool.getNow().toString();
		this.date2 = "";
		this.code = Code;
		this.description = Description;
		this.more = this.getMoreFromField();
		this.getFieldFromMore();
		this.mark = "Mark.DD";
	}

	public Face(String Id) throws Exception {
		// origin - 05.12.2023, last edit - 11.08.2025
		this.clear();
		this.src = this.id = this.code = Id;
		this.isExist();
		this.getPart();
	}

	public Face() throws Exception {
		// origin - 05.12.2023, last edit - 19.05.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 25.11.2024, last edit - 06.09.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = "Face";
			this.src = this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.geo = this.role = this.info = this.mark = "";

			this.templateId = "";
			this.storeId = this.cashId = this.cashierEmpId = this.userId = this.deptId = this.pointId = this.staffTableId = this.empId = this.crewId = "";
			this.fullName = this.comment = this.sex = "";
			this.bin = this.iin = this.rnn = this.idKZ = this.logo = "";

			this.address = new ArrayList<FaceDto>();
			this.staffTable = new ArrayList<FaceDto>();
			this.staff = new ArrayList<FaceDto>();
			this.store = new ArrayList<FaceDto>();
			this.dept = new ArrayList<FaceDto>();
			this.cash = new ArrayList<FaceDto>();
			this.bank = new ArrayList<FaceDto>();
			this.user = new ArrayList<FaceDto>();
			this.crew = new ArrayList<FaceDto>();
			this.contact = new ArrayList<FaceDto>();
			this.daily = new ArrayList<FaceDto>();
			this.point = new ArrayList<FaceDto>();

			this.jobCycle = new JobCycle();

			this.lower = new ArrayList<ModelDto>();
			this.upper = new ArrayList<ModelDto>();
		} catch (Exception ex) {
			WB.addLog("Face.clear():void, ex=" + ex.getMessage(), "", "Face");
		}
	}

	public String toString() {
		// origin - 24.11.2023, last edit - 26.05.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(" id ", this.id);
			res = res + Fmtr.addIfNotEmpty(" parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(" date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(" date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(" code ", this.code);
			res = res + Fmtr.addIfNotEmpty(" description ", this.description);
			res = res + Fmtr.addIfNotEmpty(" ", this.geo);
			res = res + Fmtr.addIfNotEmpty(" ", this.role);
			res = res + Fmtr.addIfNotEmpty(" ", this.info);
			res = res + Fmtr.addIfNotEmpty(" more ", this.more);
			res = res + Fmtr.addIfNotEmpty(" ", this.mark);

			res = res + Fmtr.addIfNotEmpty(" fullname ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(" comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(" sex ", this.sex);

			res = res + Fmtr.addIfNotEmpty(" storeId ", this.storeId);
			res = res + Fmtr.addIfNotEmpty(" cashId ", this.cashId);
			res = res + Fmtr.addIfNotEmpty(" cashierEmpIdId ", this.cashierEmpId);
			res = res + Fmtr.addIfNotEmpty(" userId ", this.userId);
			res = res + Fmtr.addIfNotEmpty(" deptId ", this.deptId);
			res = res + Fmtr.addIfNotEmpty(" pointId ", this.pointId);
			res = res + Fmtr.addIfNotEmpty(" staffTableId ", this.staffTableId);
			res = res + Fmtr.addIfNotEmpty(" empId ", this.empId);
			res = res + Fmtr.addIfNotEmpty(" crewId ", this.crewId);

			res = res + Fmtr.addIfNotEmpty(" bin ", this.bin);
			res = res + Fmtr.addIfNotEmpty(" iin ", this.iin);
			res = res + Fmtr.addIfNotEmpty(" rnn ", this.rnn);
			res = res + Fmtr.addIfNotEmpty(" idKZ ", this.idKZ);
			res = res + Fmtr.addIfNotEmpty(" logo ", this.logo);

			res = res + Fmtr.addIfNotEmpty(" templateId ", this.templateId);
			res = res + Fmtr.addIfNotEmpty(" jobCycle ", this.jobCycle.id);

			res = res + Fmtr.addIfNotEmpty(" staffTable ", this.staffTable.size());
			res = res + Fmtr.addIfNotEmpty(" staff ", this.staff.size());
			res = res + Fmtr.addIfNotEmpty(" address ", this.address.size());
			res = res + Fmtr.addIfNotEmpty(" store ", this.store.size());
			res = res + Fmtr.addIfNotEmpty(" dept ", this.dept.size());
			res = res + Fmtr.addIfNotEmpty(" cash ", this.cash.size());
			res = res + Fmtr.addIfNotEmpty(" bank ", this.bank.size());
			res = res + Fmtr.addIfNotEmpty(" user ", this.user.size());
			res = res + Fmtr.addIfNotEmpty(" contact ", this.contact.size());
			res = res + Fmtr.addIfNotEmpty(" daily ", this.daily.size());

			res = res + Fmtr.addIfNotEmpty(" isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(" isValid ", this.isValid);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 26.06.2025
		try {

//			WB.addLog2("Face.test.ctor(3String)", "", "Face");
//			for (var tmp1 : new String[] { "Face.Enterprise.Template", "Face.Person.Template",
//					"Fact job cycle emp 002" }) {
//				WB.addLog2("Face.test.ctor(3String)=" + new Face(tmp1, "Test", "Test"), "", "Face");
//			}

//			WB.addLog2("Face.test.ctor(String)", "", "Face");
//			for (var tmp1 : new String[] { "", "Face.Enterprise.Template", "Face.FA1", "Face.Person.Template",
//					"Face.FA1.AdmStaff", "Face.kgd", "Fact job cycle emp 002" }) {
//				WB.addLog2("Face.test.ctor(String)=" + new Face(tmp1), "", "Face");
//			}

		} catch (Exception ex) {
			WB.addLog("Face.test():void, ex=" + ex.getMessage(), "", "Face");
		}
	}
}