import java.util.ArrayList;
import java.util.List;

public class Dept {
	// origin - 13.03.2025, last edit - 04.05.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, code, description, geo, role, info, mark, more;
	// special fields
	public String deptId, addr;
	// special timestamp fields
	public ListVal date1, date2, jobCycle;
	// list common + special + timestamp fields in unified val
	public List<FaceDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Dept.static ctor, ex=" + ex.getMessage(), "", "Dept");
		}
	}

	// full list dept
	public static List<FaceDto> get(String parentId) throws Exception {
		// origin - 04.05.2025, last edit - 13.06.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceByParentRole = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleFilter(parentId, Role.storeDepartment), "Face");
			if (faceByParentRole.size() != 0) {
				for (var currFace : faceByParentRole) {
					for (var curr : new Dept(currFace.parent, currFace.code).val) {
						if (curr.id.isEmpty() == false) {
							var tmp = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code,
									curr.description, curr.geo, curr.role, curr.info, curr.more, curr.mark);
							tmp.deptId = curr.deptId;
							tmp.jobCycle = curr.jobCycle;
							res.add(tmp);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Dept.get(String parentId):List<FaceDto>, ex=" + ex.getMessage(), "", "Dept");
		}
		return res;
	}

	// full list dept on date1
	public static List<FaceDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 13.03.2025, last edit - 13.06.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceByParentRole = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleFilter(parentId, Role.storeDepartment), "Face");
			if (faceByParentRole.size() != 0) {
				for (var currFace : faceByParentRole) {
					var currFaceDepartment = new Dept(currFace.parent, currFace.code);
					var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceDepartment.val, "");
					if (curr.id.isEmpty() == false) {
						var tmp = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
								curr.geo, curr.role, curr.info, curr.more, curr.mark);
						tmp.deptId = curr.deptId;
						tmp.jobCycle = curr.jobCycle;
						res.add(tmp);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Dept.getCurr(String date1, String parentId):List<FaceDto>, ex=" + ex.getMessage(), "", "Dept");
		}
		return res;
	}

	// item depat on date1
	public static FaceDto getCurr(String date1, String faceParentId, String faceDeptId) throws Exception {
		// origin - 13.03.2025, last edit - 13.06.2025
		FaceDto res = new FaceDto();
		try {
			var currFaceDepartment = new Dept(faceParentId, faceDeptId);
			if (currFaceDepartment.val.size() != 0) {
				var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceDepartment.val, "");
				if (curr.id.isEmpty() == false) {
					res = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
							curr.geo, curr.role, curr.info, curr.more, curr.mark);
					res.deptId = curr.deptId;
					res.jobCycle = curr.jobCycle;
				}
			}
		} catch (Exception ex) {
			WB.addLog(
					"Dept.getCurr(String date1, String faceParentId, String faceDeptId):FaceDto, ex=" + ex.getMessage(),
					"", "Dept");
		}
		return res;
	}

	private void getVal() throws Exception {
		// origin - 13.03.2025, last edit - 13.06.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currJobCycle = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currJobCycle = this.jobCycle.getByIndex(i);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description, this.geo,
						this.role, this.info, this.more, this.mark);
				tmp.deptId = this.deptId;
				tmp.jobCycle = new JobCycle(currJobCycle);
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("Dept.getVal():void, ex=" + ex.getMessage(), "", "Dept");
		}
	}

	public void isExist() throws Exception {
		// origin - 13.03.2025, last edit - 13.06.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentCodeRoleFilter(this.parent, this.code, Role.storeDepartment), this.table);
			if (listDto.size() != 0) {
				for (var currDto : listDto) {
					var tmp = new SpanDate(currDto.date1, currDto.date2);
					this.date1 = new ListVal(tmp.date1);
					this.date2 = new ListVal(tmp.date2);

					this.id = DefVal.setCustom(this.id, currDto.id);
					this.parent = DefVal.setCustom(this.parent, currDto.parent);
					this.code = DefVal.setCustom(this.code, currDto.code);
					this.description = DefVal.setCustom(this.description, currDto.description);
					this.geo = DefVal.setCustom(this.geo, currDto.geo);
					this.role = DefVal.setCustom(this.role, currDto.role);
					this.info = DefVal.setCustom(this.info, currDto.info);
					this.more = DefVal.setCustom(this.more, currDto.more);
					this.mark = DefVal.setCustom(this.mark, currDto.mark);

					this.deptId = MoreVal.getFieldByKey(currDto.more, "DeptId");
					this.addr = MoreVal.getFieldByKey(currDto.more, "Addr");
					this.jobCycle = new ListVal(MoreVal.getFieldByKey(currDto.more, "JobCycle"), "");

					this.isExist = true;
					break;
				}
			}

			if (listDto.size() == 0) {
				this.parent = this.code = "";
			}
		} catch (Exception ex) {
			WB.addLog("Dept.isExist():void, ex=" + ex.getMessage(), "", "Dept");
		}
	}

	public Dept(String ParentId, String DeptId) throws Exception {
		// origin - 13.03.2025, last edit - 29.03.2025
		this();
		this.table = "Face";
		this.src = ParentId + "," + DeptId;
		this.parent = ParentId;
		this.code = DeptId;
		this.isExist();
		this.getVal();
	}

	public void clear() throws Exception {
		// origin - 13.03.2025, last edit - 13.06.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.more = this.mark = "";
			this.deptId = this.addr = "";
			this.date1 = this.date2 = this.jobCycle = new ListVal();
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("Dept.clear():void, ex=" + ex.getMessage(), "", "Dept");
		}
	}

	public Dept() throws Exception {
		// origin - 13.03.2025, last edit - 13.03.2025
		this.clear();
	}

	public String toString() {
		// origin - 13.03.2025, last edit - 29.04.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);

			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());

			res = res + Fmtr.addIfNotEmpty(", deptId ", this.deptId);
			res = res + Fmtr.addIfNotEmpty(", addr ", this.addr);
			res = res + Fmtr.addIfNotEmpty(", jobCycle ", this.jobCycle.id);
			res = res + Fmtr.addIfNotEmpty(", department.val.size ", this.val.size());

			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 13.03.2025, last edit - 13.06.2025
		try {

//			// get(List<FaceDto>)
//			WB.addLog2("Dept.test.get(List<FaceDto>)", "", "Dept");
//			for (var tmp1 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
//				WB.addLog2("Dept.test.get(List<FaceDto>), res.size=" + Dept.get(tmp1).size() + ", parentId=" + tmp1, "",
//						"Dept");
//				WB.log(Dept.get(tmp1), "Dept");
//			}

//			// getCurr(List<FaceDto>)
//			WB.addLog2("Dept.test.getCurr(List<FaceDto>)", "", "Dept");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-31", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
//					WB.addLog2("Dept.test.getCurr(List<FaceDto>), res.size="
//							+ Dept.getCurr(tmp1, tmp2).size() + ", date1=" + tmp1 + ", parentId=" + tmp2, "",
//							"Dept");
//			WB.log(Dept.getCurr(tmp1, tmp2), "Dept");
//				}
//			}

//			// getCurr(FaceDto)
//			WB.addLog2("Dept.test.getCurr", "", "Dept");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-31", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
//					for (var tmp3 : new String[] { "Face.FA1.AdmStaff", "Face.Tralala.AdmStaff" }) {
//						WB.addLog2(
//								"Dept.test.getCurr, res=" + Dept.getCurr(tmp1, tmp2, tmp3) + ", date1="
//										+ tmp1 + ", faceParentId=" + tmp2 + ", faceDeptId=" + tmp3,
//								"", "Dept");
//					}
//				}
//			}

//			// ctor (String, String)
//			WB.addLog2("Dept.test.ctor(String,String)", "", "Dept");
//			for (var tmp1 : new String[] { "Face.FA1", "Face.Tralala" }) {
//				for (var tmp2 : new String[] { "Face.FA1.AdmStaff", "Face.Tralala.AdmStaff" }) {
//					WB.addLog2("Dept.test.ctor(String,String)=" + new Dept(tmp1, tmp2), "", "Dept");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("Dept.test():void, ex=" + ex.getMessage(), "", "Dept");
		}
	}
}