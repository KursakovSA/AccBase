import java.util.ArrayList;
import java.util.List;

public final class Dept {
	// origin - 13.03.2025, last edit - 16.09.2026
	// common fields
	public String table, src, id, parent, code, description, geo, role, info, mark, more, defect;
	// special fields
	public String fullName, comment;
	// special timestamp fields
	public ListVal date1, date2, jobCycle;
	// list common + special + timestamp fields in unified val
	public List<FaceDto> val;
	public static List<String> nameList;

	static {
		try {
			Dept.nameList = List.of("DeptId");
		} catch (Exception ex) {
			WB.addLog("Dept.static ctor, ex=" + ex.getMessage(), "", "Dept");
		}
	}

	// full list dept
	public static List<FaceDto> get() throws Exception {
		// origin - 26.10.2025, last edit - 26.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceByParentRole = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter("Role.Store.Department"),
					"Face");
			if (faceByParentRole.size() != 0) {
				for (var currFace : faceByParentRole) {
					for (var curr : new Dept(currFace.parent, currFace.code).val) {
						if (curr.id.isEmpty() == false) {
							res.add(curr);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Dept.get():List<FaceDto>, ex=" + ex.getMessage(), "", "Dept");
		}
		return res;
	}

	// full list dept for parentId
	public static List<FaceDto> get(String parentId) throws Exception {
		// origin - 04.05.2025, last edit - 26.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceByParentRole = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleFilter(parentId, "Role.Store.Department"), "Face");
			if (faceByParentRole.size() != 0) {
				for (var currFace : faceByParentRole) {
					for (var curr : new Dept(currFace.parent, currFace.code).val) {
						if (curr.id.isEmpty() == false) {
							res.add(curr);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Dept.get(String):List<FaceDto>, ex=" + ex.getMessage(), "", "Dept");
		}
		return res;
	}

	// full list dept on date1
	public static List<FaceDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 13.03.2025, last edit - 25.09.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceByParentRole = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleFilter(parentId, "Role.Store.Department"), "Face");
			if (faceByParentRole.size() != 0) {
				for (var currFace : faceByParentRole) {
					var currFaceDepartment = new Dept(currFace.parent, currFace.code);
					var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceDepartment.val, "");
					if (curr.id.isEmpty() == false) {
						var tmp = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
								curr.geo, curr.role, curr.info, curr.more, curr.mark);
						res.add(tmp);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Dept.getCurr(2String):List<FaceDto>, ex=" + ex.getMessage(), "", "Dept");
		}
		return res;
	}

	// item dept on date1
	public static FaceDto getCurr(String date1, String faceParentId, String faceDeptId) throws Exception {
		// origin - 13.03.2025, last edit - 25.09.2025
		FaceDto res = new FaceDto();
		try {
			var currFaceDepartment = new Dept(faceParentId, faceDeptId);
			if (currFaceDepartment.val.size() != 0) {
				var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceDepartment.val, "");
				if (curr.id.isEmpty() == false) {
					res = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
							curr.geo, curr.role, curr.info, curr.more, curr.mark);
				}
			}
		} catch (Exception ex) {
			WB.addLog("Dept.getCurr(3String):FaceDto, ex=" + ex.getMessage(), "", "Dept");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 20.11.2025, last edit - 15.09.2026
		try {
			this.defect = Fmtr.addIfStrEmpty(this.defect, MoreVal.getFieldByKey(this.more, "DeptId"), "empty deptId; ");
		} catch (Exception ex) {
			WB.addLog("Dept.validate():void, ex=" + ex.getMessage(), "", "Dept");
		}
	}
	
	private void getFieldFromMore() throws Exception {
		// origin - 16.09.2026, last edit - 16.09.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("Dept.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Dept");
		}
	}

	private void getVal() throws Exception {
		// origin - 13.03.2025, last edit - 15.09.2026
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currJobCycle = "";
			String currMore = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currJobCycle = this.jobCycle.getByIndex(i);
				currMore = currMore + MoreVal.setPart("JobCycle", currJobCycle);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description, this.geo,
						this.role, this.info, this.more, this.mark);
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("Dept.getVal():void, ex=" + ex.getMessage(), "", "Dept");
		}
	}

	private void isExist() throws Exception {
		// origin - 13.03.2025, last edit - 16.09.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentCodeRoleFilter(this.parent, this.code, "Role.Store.Department"), "Face");
			if (listDto.size() != 0) {
				var currDto = listDto.getFirst();
				var tmp = new SpanDate(currDto.date1, currDto.date2);
				this.date1 = new ListVal(tmp.date1);
				this.date2 = new ListVal(tmp.date2);
				this.id = DefVal.setCustom(this.id, currDto.id);
				this.parent = DefVal.setCustom(this.parent, currDto.parent);
				this.code = DefVal.setCustom(this.code, currDto.code);
				this.description = DefVal.setCustom(this.description, currDto.description);
				this.geo = DefVal.setCustom(this.geo, currDto.geo);
				this.role = DefVal.setCustom(this.role, currDto.role);
				this.info = DefVal.setCustom(this.info, currDto.info);
				this.more = DefVal.setCustom(this.more, currDto.more);
				this.mark = DefVal.setCustom(this.mark, currDto.mark);
				this.jobCycle = new ListVal(MoreVal.getFieldByKey(currDto.more, "JobCycle"), "");
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("Dept.isExist():void, ex=" + ex.getMessage(), "", "Dept");
		}
	}

	public Dept(String ParentId, String DeptId) throws Exception {
		// origin - 13.03.2025, last edit - 20.11.2025
		this();
		this.src = ParentId + "," + DeptId;
		this.parent = ParentId;
		this.code = DeptId;
		this.isExist();
		this.getVal();
		this.validate();
	}

	private void clear() throws Exception {
		// origin - 13.03.2025, last edit - 16.09.2026
		try {
			this.table = "Face";
			this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.more = this.mark = "";
			this.defect = this.fullName = this.comment = "";
			this.date1 = this.date2 = new ListVal();
			this.jobCycle = new ListVal();
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("Dept.clear():void, ex=" + ex.getMessage(), "", "Dept");
		}
	}

	public Dept() throws Exception {
		// origin - 13.03.2025, last edit - 13.03.2025
		this.clear();
	}

	public String toString() {
		// origin - 13.03.2025, last edit - 15.09.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", jobCycle ", this.jobCycle.id);
			res = res + Fmtr.addIfNotEmpty(", dept.val.size ", this.val.size());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 13.03.2025, last edit - 26.10.2025
		try {

//			WB.addLog2("Dept.test.get():List<FaceDto>", "", "Dept");
//			var tmp = Dept.get();
//			WB.addLog2("Dept.test.get():List<FaceDto>, res.size=" + tmp.size(), "", "Dept");
//			WB.log(tmp, "Dept");

//			WB.addLog2("Dept.test.get(String):List<FaceDto>", "", "Dept");
//			for (var tmp1 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
//				WB.addLog2("Dept.test.get(String):List<FaceDto>, res.size=" + Dept.get(tmp1).size() + ", parentId=" + tmp1, "",
//						"Dept");
//				WB.log(Dept.get(tmp1), "Dept");
//			}

//			WB.addLog2("Dept.test.getCurr(2String):List<FaceDto>", "", "Dept");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-31", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
//					WB.addLog2("Dept.test.getCurr(2String):List<FaceDto>, res.size="
//							+ Dept.getCurr(tmp1, tmp2).size() + ", date1=" + tmp1 + ", parentId=" + tmp2, "",
//							"Dept");
//			WB.log(Dept.getCurr(tmp1, tmp2), "Dept");
//				}
//			}

//			WB.addLog2("Dept.test.getCurr(3String):FaceDto", "", "Dept");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-31", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
//					for (var tmp3 : new String[] { "Face.FA1.AdmStaff", "Face.Tralala.AdmStaff" }) {
//						WB.addLog2(
//								"Dept.test.getCurr(3String):FaceDto, res=" + Dept.getCurr(tmp1, tmp2, tmp3) + ", date1="
//										+ tmp1 + ", faceParentId=" + tmp2 + ", faceDeptId=" + tmp3,
//								"", "Dept");
//					}
//				}
//			}

//			WB.addLog2("Dept.test.ctor(2String)", "", "Dept");
//			for (var tmp1 : new String[] { "Face.FA1", "Face.Tralala" }) {
//				for (var tmp2 : new String[] { "Face.FA1.AdmStaff", "Face.Tralala.AdmStaff" }) {
//					WB.addLog2("Dept.test.ctor(2String)=" + new Dept(tmp1, tmp2), "", "Dept");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("Dept.test():void, ex=" + ex.getMessage(), "", "Dept");
		}
	}
}