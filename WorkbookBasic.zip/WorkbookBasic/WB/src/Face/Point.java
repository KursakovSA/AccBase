import java.util.ArrayList;
import java.util.List;

public class Point {
	// origin - 12.04.2025, last edit - 13.05.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, code, description, geo, role, info, mark, more;
	// special fields
	public String pointId;
	// special timestamp fields
	public ListVal date1, date2, jobCycle;
	// list common + special + timestamp fields in unified val
	public List<FaceDto> val;
	// child lists
	public List<JobTurn> jobTurn;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Point.static ctor, ex=" + ex.getMessage(), "", "Point");
		}
	}

	private void getUp() throws Exception { // get empty fields from upper
		// origin - 29.04.2025, last edit - 13.06.2025
		try {
			FaceDto upFaceDto = FaceDto.getCodeRole(this.parent, Role.storeDepartment);
			Dept upDept = new Dept(upFaceDto.parent, upFaceDto.code);
			if ((upDept.jobCycle.val.size() != 0) && (this.jobCycle.val.size() == 0)) {
				this.jobCycle = new ListVal(upDept.jobCycle.src, ""); // getUp jobCycle from upper Dept
			}
		} catch (Exception ex) {
			WB.addLog("Point.getUp():void, ex=" + ex.getMessage(), "", "Point");
		}
	}

	// full list point
	public static List<FaceDto> get(String parentId) throws Exception {
		// origin - 04.05.2025, last edit - 13.06.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceByParentRole = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleFilter(parentId, Role.storePoint), "Face");
			if (faceByParentRole.size() != 0) {
				for (var currFace : faceByParentRole) {
					for (var curr : new Point(currFace.parent, currFace.code).val) {
						if (curr.id.isEmpty() == false) {
							var tmp = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code,
									curr.description, curr.geo, curr.role, curr.info, curr.more, curr.mark);
							tmp.pointId = curr.pointId;
							tmp.jobCycle = curr.jobCycle;
							res.add(tmp);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Point.get(String parentId):List<FaceDto>, ex=" + ex.getMessage(), "", "Point");
		}
		return res;
	}

	// full list point on date1
	public static List<FaceDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 12.04.2025, last edit - 13.06.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceByParentRole = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleFilter(parentId, Role.storePoint), "Face");
			if (faceByParentRole.size() != 0) {
				for (var currFace : faceByParentRole) {
					var currFacePoint = new Point(currFace.parent, currFace.code);
					var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFacePoint.val, "");
					if (curr.id.isEmpty() == false) {
						var tmp = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
								curr.geo, curr.role, curr.info, curr.more, curr.mark);
						tmp.pointId = curr.pointId;
						tmp.jobCycle = curr.jobCycle;
						res.add(tmp);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Point.getCurr(String date1, String parentId):List<FaceDto>, ex=" + ex.getMessage(), "", "Point");
		}
		return res;
	}

	// item point on date1
	public static FaceDto getCurr(String date1, String faceParentId, String facePointId) throws Exception {
		// origin - 12.04.2025, last edit - 13.06.2025
		FaceDto res = new FaceDto();
		try {
			var currFacePoint = new Point(faceParentId, facePointId);
			if (currFacePoint.val.size() != 0) {
				var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFacePoint.val, "");
				if (curr.id.isEmpty() == false) {
					res = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
							curr.geo, curr.role, curr.info, curr.more, curr.mark);
					res.pointId = curr.pointId;
					res.jobCycle = curr.jobCycle;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Point.getCurr(String date1, String faceParentId, String facePointId):FaceDto, ex="
					+ ex.getMessage(), "", "Point");
		}
		return res;
	}

	private void getVal() throws Exception {
		// origin - 12.04.2025, last edit - 13.06.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currJobCycle = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currJobCycle = this.jobCycle.getByIndex(i);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description, this.geo,
						this.role, this.info, this.more, this.mark);
				tmp.pointId = this.pointId;

				tmp.jobCycle = new JobCycle(currJobCycle);
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("Point.getVal():void, ex=" + ex.getMessage(), "", "Point");
		}
	}

	public void isExist() throws Exception {
		// origin - 12.04.2025, last edit - 11.08.2025
		List<ModelDto> listDto = new ArrayList<ModelDto>();
		try {
			if (this.parent.isEmpty() == false) {
				listDto = DAL.getByTemplate(WB.lastConnWork,
						Qry.getParentCodeRoleFilter(this.parent, this.code, Role.storePoint), "Face");
			}
			if (this.parent.isEmpty()) {
				listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getCodeRoleFilter(this.code, Role.storePoint), "Face");
			}
			if (listDto.size() != 0) {
				for (var currDto : listDto) {
					var tmp = new SpanDate(currDto.date1, currDto.date2);
					this.date1 = new ListVal(tmp.date1);
					this.date2 = new ListVal(tmp.date2);

					this.id = DefVal.setCustom(this.id, currDto.id);
					this.parent = DefVal.setCustom(this.parent, currDto.parent);
					this.code = DefVal.setCustom(this.code, currDto.code);
					this.description = DefVal.setCustom(this.description, currDto.description);
					this.geo = DefVal.setCustom(this.geo, currDto.geo);
					this.role = DefVal.setCustom(this.role, currDto.role);
					this.info = DefVal.setCustom(this.info, currDto.info);
					this.more = DefVal.setCustom(this.more, currDto.more);
					this.mark = DefVal.setCustom(this.mark, currDto.mark);

					this.pointId = MoreVal.getFieldByKey(currDto.more, "PointId");
					this.jobCycle = new ListVal(MoreVal.getFieldByKey(currDto.more, "JobCycle"), "");

					this.jobTurn = JobTurn.get(this.code);

					this.isExist = true;
					break;
				}
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("Point.isExist():void, ex=" + ex.getMessage(), "", "Point");
		}
	}

	public Point(String ParentId, String PointId) throws Exception {
		// origin - 12.04.2025, last edit - 11.08.2025
		this();
		this.src = ParentId + "," + PointId;
		this.parent = ParentId;
		this.code = PointId;
		this.isExist();
		this.getVal();
		this.getUp();
	}

	public void clear() throws Exception {
		// origin - 12.04.2025, last edit - 11.08.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = "Face";
			this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.more = this.mark = "";
			this.pointId = "";
			this.date1 = this.date2 = this.jobCycle = new ListVal();
			this.val = new ArrayList<FaceDto>();
			this.jobTurn = new ArrayList<JobTurn>();
		} catch (Exception ex) {
			WB.addLog("Point.clear():void, ex=" + ex.getMessage(), "", "Point");
		}
	}

	public Point() throws Exception {
		// origin - 12.04.2025, last edit - 12.04.2025
		this.clear();
	}

	public String toString() {
		// origin - 12.04.2025, last edit - 05.05.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);

			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());

			res = res + Fmtr.addIfNotEmpty(", pointId ", this.pointId);
			res = res + Fmtr.addIfNotEmpty(", jobCycle ", this.jobCycle.id);
			res = res + Fmtr.addIfNotEmpty(", point.val.size ", this.val.size());
			res = res + Fmtr.addAnyway(", jobTurn.size ", this.jobTurn.size());

			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 12.04.2025, last edit - 13.06.2025
		try {

//			// get(List<FaceDto>)
//			WB.addLog2("Point.test.get(List<FaceDto>)", "", "Point");
//			for (var tmp1 : new String[] { "Face.FA1.AdmStaff" }) {
//				WB.addLog2("Point.test.get(List<FaceDto>), res.size=" + Point.get(tmp1).size() + ", faceParentDeptId="
//						+ tmp1, "", "Point");
//				WB.log(Point.get(tmp1), "Point");
//			}

//			// getCurr(List<FaceDto>)
//			WB.addLog2("Point.test.getCurr(List<FaceDto>)", "", "Point");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1.AdmStaff" }) {
//					WB.addLog2("Point.test.getCurr(List<FaceDto>), res.size=" + Point.getCurr(tmp1, tmp2).size()
//							+ ", date1=" + tmp1 + ", faceParentDeptId=" + tmp2, "", "Point");
//					WB.log(Point.getCurr(tmp1, tmp2), "Point");
//				}
//			}

//			// getCurr(FaceDto)
//			WB.addLog2("Point.test.getCurr(FaceDto)", "", "Point");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1.AdmStaff" }) {
//					for (var tmp3 : new String[] { "Face.FA1.AdmStaff.Point1" }) {
//						WB.addLog2("Point.test.getCurr(FaceDto), res=" + Point.getCurr(tmp1, tmp2, tmp3) + ", date1="
//								+ tmp1 + ", faceParentDeptId=" + tmp2 + ", facePointId=" + tmp3, "", "Point");
//					}
//				}
//			}

//			// ctor (String,String)
//			WB.addLog2("Point.test.ctor(String,String)", "", "Point");
//			for (var tmp1 : new String[] { "", "Face.FA1.AdmStaff" }) {
//				for (var tmp2 : new String[] { "Face.FA1.AdmStaff.Point1" }) {
//					WB.addLog2("Point.test.ctor(String,String)=" + new Point(tmp1, tmp2), "", "Point");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("Point.test():void, ex=" + ex.getMessage(), "", "Point");
		}
	}
}