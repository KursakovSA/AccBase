import java.util.ArrayList;
import java.util.List;

public final class Point {
	// origin - 12.04.2025, last edit - 21.12.2025
	// common fields
	public String table, src, id, parent, code, description, geo, role, info, mark, more, defect;
	// special fields
	public String pointId;
	// special timestamp fields
	public ListVal date1, date2, jobCycle;
	// list common + special + timestamp fields in unified val
	public List<FaceDto> val;
	// child lists
	public List<FaceDto> jobTurnList;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Point.static ctor, ex=" + ex.getMessage(), "", "Point");
		}
	}

	private void getUp() throws Exception { // get empty fields from upper
		// origin - 29.04.2025, last edit - 15.09.2025
		try {
			FaceDto upFaceDto = FaceDto.getCodeRole(this.parent, "Role.Store.Department");
			Dept upDept = new Dept(upFaceDto.parent, upFaceDto.code);
			if ((upDept.jobCycle.val.size() != 0) && (this.jobCycle.val.size() == 0)) {
				this.jobCycle = new ListVal(upDept.jobCycle.src, ""); // getUp jobCycle from upper Dept
			}
		} catch (Exception ex) {
			WB.addLog("Point.getUp():void, ex=" + ex.getMessage(), "", "Point");
		}
	}

	// full list point
	public static List<FaceDto> get() throws Exception {
		// origin - 26.10.2025, last edit - 26.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceByRole = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter("Role.Store.Point"), "Face");
			if (faceByRole.size() != 0) {
				for (var currFace : faceByRole) {
					for (var curr : new Point(currFace.parent, currFace.code).val) {
						if (curr.id.isEmpty() == false) {
							res.add(curr);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Point.get():List<FaceDto>, ex=" + ex.getMessage(), "", "Point");
		}
		return res;
	}

	// full list point for parentId
	public static List<FaceDto> get(String parentId) throws Exception {
		// origin - 04.05.2025, last edit - 26.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceByParentRole = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleFilter(parentId, "Role.Store.Point"), "Face");
			if (faceByParentRole.size() != 0) {
				for (var currFace : faceByParentRole) {
					for (var curr : new Point(currFace.parent, currFace.code).val) {
						if (curr.id.isEmpty() == false) {
							res.add(curr);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Point.get(String):List<FaceDto>, ex=" + ex.getMessage(), "", "Point");
		}
		return res;
	}

	// full list point on date1
	public static List<FaceDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 12.04.2025, last edit - 26.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceByParentRole = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleFilter(parentId, "Role.Store.Point"), "Face");
			if (faceByParentRole.size() != 0) {
				for (var currFace : faceByParentRole) {
					var currFacePoint = new Point(currFace.parent, currFace.code);
					var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFacePoint.val, "");
					if (curr.id.isEmpty() == false) {
						res.add(curr);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Point.getCurr(2String):List<FaceDto>, ex=" + ex.getMessage(), "", "Point");
		}
		return res;
	}

	// item point on date1
	public static FaceDto getCurr(String date1, String faceParentId, String facePointId) throws Exception {
		// origin - 12.04.2025, last edit - 26.10.2025
		FaceDto res = new FaceDto();
		try {
			var currFacePoint = new Point(faceParentId, facePointId);
			if (currFacePoint.val.size() != 0) {
				var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFacePoint.val, "");
				if (curr.id.isEmpty() == false) {
					res = curr;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Point.getCurr(3String):FaceDto, ex=" + ex.getMessage(), "", "Point");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 20.11.2025, last edit - 23.05.2026
		try {
			this.defect = Fmtr.addIfStrEmpty(this.defect, this.pointId, "empty pointId; ");
		} catch (Exception ex) {
			WB.addLog("Point.validate():void, ex=" + ex.getMessage(), "", "Point");
		}
	}

	private void getVal() throws Exception {
		// origin - 12.04.2025, last edit - 02.10.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currJobCycle = "";
			String currMore = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currJobCycle = this.jobCycle.getByIndex(i);
				currMore = "";
				currMore = currMore + MoreVal.setPartMore("JobCycle", currJobCycle);
				currMore = currMore + MoreVal.setPartMore("PointId", this.pointId);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description, this.geo,
						this.role, this.info, currMore, this.mark);
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("Point.getVal():void, ex=" + ex.getMessage(), "", "Point");
		}
	}

	private void isExist() throws Exception {
		// origin - 12.04.2025, last edit - 20.11.2025
		List<FullDto> listDto = new ArrayList<FullDto>();
		try {
			listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentCodeRoleFilter(this.parent, this.code, "Role.Store.Point"), "Face");
			if (listDto.size() != 0) {
				var currDto = listDto.getFirst();
				var tmp = new SpanDate(currDto.date1, currDto.date2);
				this.date1 = new ListVal(tmp.date1);
				this.date2 = new ListVal(tmp.date2);
				this.id = DefVal.setCustom(this.id, currDto.id);
				this.parent = DefVal.setCustom(this.parent, currDto.parent);
				this.code = DefVal.setCustom(this.code, currDto.code);
				this.description = DefVal.setCustom(this.description, currDto.description);
				this.geo = DefVal.setCustom(this.geo, currDto.geo);
				this.role = DefVal.setCustom(this.role, currDto.role);
				this.info = DefVal.setCustom(this.info, currDto.info);
				this.more = DefVal.setCustom(this.more, currDto.more);
				this.mark = DefVal.setCustom(this.mark, currDto.mark);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("Point.isExist():void, ex=" + ex.getMessage(), "", "Point");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 02.10.2025, last edit - 21.12.2025
		try {
			this.pointId = MoreVal.getFieldByKey(this.more, "PointId");
			this.jobCycle = new ListVal(MoreVal.getFieldByKey(this.more, "JobCycle"), "");
			this.jobTurnList = JobTurn.get(this.code);
		} catch (Exception ex) {
			WB.addLog("Point.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Point");
		}
	}

	public Point(String ParentId, String PointId) throws Exception {
		// origin - 12.04.2025, last edit - 20.11.2025
		this();
		this.src = ParentId + "," + PointId;
		this.parent = ParentId;
		this.code = PointId;
		this.isExist();
		this.getVal();
		this.getUp();
		this.validate();
	}

	private void clear() throws Exception {
		// origin - 12.04.2025, last edit - 21.12.2025
		try {
			this.table = "Face";
			this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.more = this.mark = "";
			this.pointId = this.defect = "";
			this.date1 = this.date2 = this.jobCycle = new ListVal();
			this.val = new ArrayList<FaceDto>();
			this.jobTurnList = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("Point.clear():void, ex=" + ex.getMessage(), "", "Point");
		}
	}

	public Point() throws Exception {
		// origin - 12.04.2025, last edit - 12.04.2025
		this.clear();
	}

	public String toString() {
		// origin - 12.04.2025, last edit - 21.12.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", pointId ", this.pointId);
			res = res + Fmtr.addIfNotEmpty(", jobCycle ", this.jobCycle.id);
			res = res + Fmtr.addIfNotEmpty(", point.val.size ", this.val.size());
			res = res + Fmtr.addAnyway(", jobTurnList.size ", this.jobTurnList.size());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 12.04.2025, last edit - 24.08.2026
		try {

//			WB.addLog2("Point.test.get():List<FaceDto>", "", "Point");
//			var tmp = Point.get();
//			WB.addLog2("Point.test.get():List<FaceDto>, res.size=" + tmp.size(), "", "Point");
//			WB.log(tmp, "Point");

//			WB.addLog2("Point.test.get(String):List<FaceDto>", "", "Point");
//			for (var tmp1 : new String[] { "Face.FA1.AdmStaff" }) {
//				var tmp2 = Point.get(tmp1);
//				WB.addLog2(
//						"Point.test.get(String):List<FaceDto>, res.size=" + tmp2.size() + ", faceParentDeptId=" + tmp1,
//						"", "Point");
//				WB.log(tmp2, "Point");
//			}

//			WB.addLog2("Point.test.getCurr(2String):FaceDto", "", "Point");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1.AdmStaff" }) {
//					var tmp3 = Point.getCurr(tmp1, tmp2);
//					WB.addLog2("Point.test.getCurr(2String):FaceDto, res.size=" + tmp3.size() + ", date1=" + tmp1
//							+ ", faceParentDeptId=" + tmp2, "", "Point");
//					WB.log(tmp3, "Point");
//				}
//			}

//			WB.addLog2("Point.test.getCurr(3String):FaceDto", "", "Point");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "", "Face.FA1.AdmStaff , Face.FA1.AdmStaff.Point1" }) {
//					var tmp3 = new NVal(tmp2);
//					WB.addLog2("Point.test.getCurr(3String):FaceDto, res=" + Point.getCurr(tmp1, tmp3.getVal(1), tmp3.getVal(2))
//							+ ", date1=" + tmp1 + ", faceParentDeptId=" + tmp3.getVal(1) + ", facePointId=" + tmp3.getVal(2), "",
//							"Point");
//				}
//			}

//			WB.addLog2("Point.test.ctor(2String)", "", "Point");
//			for (var tmp1 : new String[] { "", "Face.FA1.AdmStaff , Face.FA1.AdmStaff.Point1" }) {
//				var tmp2 = new NVal(tmp1);
//				var tmp3 = new Point(tmp2.getVal(1), tmp2.getVal(2));
//				WB.addLog2("Point.test.ctor(2String)=" + tmp3, "", "Point");
//				WB.log(tmp3.val, "Point");
//			}

		} catch (Exception ex) {
			WB.addLog("Point.test():void, ex=" + ex.getMessage(), "", "Point");
		}
	}
}