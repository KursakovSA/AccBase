import java.util.ArrayList;
import java.util.List;

public class JobCycle {
	// origin - 11.04.2025, last edit - 13.05.2025
	public boolean isValid, isExist;
	public String table, parent, code, description, geo, role, info, mark, more, fullName, comment;
	public String id, src, jobWeek, context;
	private List<String> srcList;
	public JobDay jobDay, addSaturdayJobDay;
	public ListVal date1, date2, jobCycle;
	public List<FaceDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("JobCycle.static ctor, ex=" + ex.getMessage(), "", "JobCycle");
		}
	}

	public int getCountJobDay(String parentId) throws Exception {// TODO
		// origin - 10.05.2025, last edit - 10.05.2025
		int res = 0;
		try {

		} catch (Exception ex) {
			WB.addLog("Point.getCountJobDay, ex=" + ex.getMessage(), "", "Point");
		}
		return res;
	}

	private void getPart() throws Exception {
		// origin - 17.04.2025, last edit - 10.05.2025
		try {
			if (this.srcList.size() == 0) {// if empty src then by default
				this.jobWeek = "5-2";
				this.jobDay = new JobDay("9-18/13-14"); // by default
			}

			if (srcList.size() == 1) { // ex. "6-1 8-17 10-13"
				this.jobWeek = srcList.get(0);
				this.jobDay = new JobDay("9-18/13-14"); // by default
			}

			if (srcList.size() == 2) { // ex. "6-1 8-17 10-13", when 8-17 - this is jobDay
				this.jobWeek = srcList.get(0);
				this.jobDay = new JobDay(srcList.get(1));
			}

			if (srcList.size() == 3) { // ex. "6-1 8-17 10-13", when 10-13 - this is addSaturdayJobDay
				this.jobWeek = srcList.get(0);
				this.jobDay = new JobDay(srcList.get(1));
				this.addSaturdayJobDay = new JobDay(srcList.get(2));
			}
		} catch (Exception ex) {
			WB.addLog("JobCycle.getPart, ex=" + ex.getMessage(), "", "JobCycle");
		}
	}

	private void getId() throws Exception {
		// origin - 12.04.2025, last edit - 17.04.2025
		try {
			if (this.srcList.size() >= 1) {
				this.id = this.id + srcList.getFirst();
			}
			this.id = this.id + "/" + this.jobDay.id + "/" + this.addSaturdayJobDay.id;
		} catch (Exception ex) {
			WB.addLog("JobCycle.getId, ex=" + ex.getMessage(), "", "JobCycle");
		}
	}

	private void getVal() throws Exception {
		// origin - 06.05.2025, last edit - 06.05.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currJobCycle = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currJobCycle = this.jobCycle.getByIndex(i);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description, this.geo,
						this.role, this.info, this.more, this.mark);
				tmp.jobCycle = new JobCycle(currJobCycle);
				tmp.comment = this.comment;
				tmp.fullName = this.fullName;
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("JobCycle.getVal, ex=" + ex.getMessage(), "", "JobCycle");
		}
	}

	public void isExist() throws Exception {// get fact jobCycle for StaffTable
		// origin - 06.05.2025, last edit - 10.05.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleInfoFilter(this.parent, Role.faceJobCycle, Info.genericVariant), this.table);
			if (listDto.size() != 0) {
				for (var currDto : listDto) {
					var tmp = new SpanDate(currDto.date1, currDto.date2);
					this.date1 = new ListVal(tmp.date1);
					this.date2 = new ListVal(tmp.date2);

					this.id = DefVal.setCustom(this.id, currDto.id);
					this.parent = DefVal.setCustom(this.parent, currDto.parent);
					this.code = DefVal.setCustom(this.code, currDto.code);
					this.description = DefVal.setCustom(this.description, currDto.description);
					this.geo = DefVal.setCustom(this.geo, currDto.geo);
					this.role = DefVal.setCustom(this.role, currDto.role);
					this.info = DefVal.setCustom(this.info, currDto.info);
					this.more = DefVal.setCustom(this.more, currDto.more);
					this.mark = DefVal.setCustom(this.mark, currDto.mark);

					this.fullName = MoreVal.getFieldByKey(currDto.more, "FullName");
					this.comment = MoreVal.getFieldByKey(currDto.more, "Comment");
					this.jobCycle = new ListVal(MoreVal.getFieldByKey(currDto.more, "JobCycle"), "");

					this.isExist = true;
					break;
				}
			}

			if (listDto.size() == 0) {
				this.parent = this.code = "";
			}
		} catch (Exception ex) {
			WB.addLog("JobCycle.isExist, ex=" + ex.getMessage(), "", "JobCycle");
		}
	}

	public JobCycle(String Parent, String Context) throws Exception {// get fact jobCycle from database
		// origin - 06.05.2025, last edit - 10.05.2025
		this.clear();
		this.table = "Face";
		this.parent = Parent;
		this.context = Context;
		this.isExist();
		this.getVal();
	}

	public JobCycle(String Src) throws Exception {
		// origin - 12.04.2025, last edit - 17.04.2025
		this.clear();
		this.src = Etc.fixTrim(Src);
		this.srcList = Fmtr.listVal(this.src, " ");
		this.getPart();
		this.getId();
	}

	public JobCycle() throws Exception {
		// origin - 11.04.2025, last edit - 27.04.2025
		this.clear();
	}

	public void clear() throws Exception {
		// origin - 11.04.2025, last edit - 13.05.2025
		try {
			this.srcList = new ArrayList<String>();
			this.jobDay = new JobDay();
			this.addSaturdayJobDay = new JobDay();

			this.table = this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.more = this.mark = "";
			this.fullName = this.comment = this.jobWeek = this.context = "";
			this.date1 = this.date2 = this.jobCycle = new ListVal();
			this.val = new ArrayList<FaceDto>();

		} catch (Exception ex) {
			WB.addLog("JobCycle.clear, ex=" + ex.getMessage(), "", "JobCycle");
		}
	}

	public String toString() {
		// origin - 11.04.2025, last edit - 13.05.2025
		String res = "";
		try {
			// res = res + Fmtr.addAnyway("id ", this.id);
			res = res + Fmtr.addAnyway(", src ", this.src);
			res = res + Fmtr.addAnyway(", srcList ", this.srcList);

			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", context ", this.context);

			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);

			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);

			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addIfNotEmpty(", jobWeek ", this.jobWeek);
			res = res + Fmtr.addIfNotEmpty(", jobDay ", this.jobDay.id);
			res = res + Fmtr.addIfNotEmpty(", addSaturdayJobDay ", this.addSaturdayJobDay.id);

			res = res + Fmtr.addIfNotEmpty(", jobCycle ", this.jobCycle.id);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 11.04.2025, last edit - 13.05.2025
		try {

//			// ctor(String,String)
//			WB.addLog2("JobCycle.test.ctor(String,String)", "", "JobCycle");
//			for (var tmp1 : new String[] { "", "Face.FA1.StaffTable1.ChiefAccountant",
//					"Face.Tralala.StaffTable1.ChiefAccountant" }) {
//				WB.addLog2("JobCycle.test.ctor(String,String)=" + new JobCycle(tmp1, "from database"), "", "JobCycle");
//				for (var tmp2 : new JobCycle(tmp1, "").val) {
//					WB.addLog2("JobCycle.test.ctor(String,String), tmp2.jobCycle=" + tmp2.jobCycle, "", "JobCycle");
//				}
//			}

//			// ctor(String)
//			WB.addLog2("JobCycle.test.ctor(String)", "", "JobCycle");
//			for (var tmp1 : new String[] { "", "5-2 ", "5-2 8-18", "6-1 8-17 10-13", "7-0 9-20/14-15",
//					"7-0 9-20/14-15 10-13" }) {
//				WB.addLog2("JobCycle.test.ctor(String)=" + new JobCycle(tmp1), "", "JobCycle");
//			}

//			// ctor()
//			WB.addLog2("JobCycle.test.ctor()", "", "JobCycle");
//			WB.addLog2("JobCycle.test.ctor()=" + new JobCycle(), "", "JobCycle");

		} catch (Exception ex) {
			WB.addLog("JobCycle.test, ex=" + ex.getMessage(), "", "JobCycle");
		}
	}
}