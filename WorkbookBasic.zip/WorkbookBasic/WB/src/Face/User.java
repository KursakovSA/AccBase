import java.util.ArrayList;
import java.util.List;

public class User {
	// origin - 11.03.2025, last edit - 30.06.2025
	public boolean isValid, isExist;
	public String table, src, id, parent, code, description, geo, role, info, mark, more, staffTableId, pointId,
			fullName, comment;
	public ListVal date1, date2, permission, restriction;// TODO - permission, restriction
	public List<FaceDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("User.static ctor, ex=" + ex.getMessage(), "", "User");
		}
	}

	// full list user positions
	public static List<FaceDto> get(String parentId) throws Exception {
		// origin - 04.05.2025, last edit - 30.06.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceByParentRole = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, Role.faceUser),
					"Face");
			if (faceByParentRole.size() != 0) {
				for (var currFace : faceByParentRole) {
					for (var curr : new User(parentId, currFace.code).val) {
						if (curr.id.isEmpty() == false) {
							var tmp = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code,
									curr.description, curr.geo, curr.role, curr.info, curr.more, curr.mark);
							tmp.staffTableId = MoreVal.getFieldByKey(curr.more, "StaffTableId");
							tmp.pointId = MoreVal.getFieldByKey(curr.more, "PointId");
							tmp.fullName = MoreVal.getFieldByKey(curr.more, "FullName");
							tmp.comment = MoreVal.getFieldByKey(curr.more, "Comment");
							res.add(tmp);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("User.get(String parentId):List<FaceDto>, ex=" + ex.getMessage(), "", "User");
		}
		return res;
	}

	// full list user positions on date1
	public static List<FaceDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 11.03.2025, last edit - 30.06.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceByParentRole = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, Role.faceUser),
					"Face");
			if (faceByParentRole.size() != 0) {
				for (var currFace : faceByParentRole) {
					var currFaceUser = new User(parentId, currFace.code);
					var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceUser.val, "");
					if (curr.id.isEmpty() == false) {
						var tmp = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
								curr.geo, curr.role, curr.info, curr.more, curr.mark);
						tmp.staffTableId = MoreVal.getFieldByKey(curr.more, "StaffTableId");
						tmp.pointId = MoreVal.getFieldByKey(curr.more, "PointId");
						tmp.fullName = MoreVal.getFieldByKey(curr.more, "FullName");
						tmp.comment = MoreVal.getFieldByKey(curr.more, "Comment");
						res.add(tmp);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("User.getCurr(String date1, String parentId):List<FaceDto>, ex=" + ex.getMessage(), "", "User");
		}
		return res;
	}

	// item user position on date1
	public static FaceDto getCurr(String date1, String faceParentId, String faceUserId) throws Exception {
		// origin - 11.03.2025, last edit - 30.06.2025
		FaceDto res = new FaceDto();
		try {
			var currFaceUserNote = new User(faceParentId, faceUserId);
			if (currFaceUserNote.val.size() != 0) {
				var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceUserNote.val, "");
				if (curr.id.isEmpty() == false) {
					res = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
							curr.geo, curr.role, curr.info, curr.more, curr.mark);
					res.staffTableId = MoreVal.getFieldByKey(curr.more, "StaffTableId");
					res.pointId = MoreVal.getFieldByKey(curr.more, "PointId");
					res.fullName = MoreVal.getFieldByKey(curr.more, "FullName");
					res.comment = MoreVal.getFieldByKey(curr.more, "Comment");
				}
			}
		} catch (Exception ex) {
			WB.addLog(
					"User.getCurr(String date1, String faceParentId, String faceUserId):FaceDto, ex=" + ex.getMessage(),
					"", "User");
		}
		return res;
	}

	private void getVal() throws Exception {
		// origin - 11.03.2025, last edit - 30.06.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description, this.geo,
						this.role, this.info, this.more, this.mark);
				tmp.staffTableId = MoreVal.getFieldByKey(this.more, "StaffTableId");
				tmp.pointId = MoreVal.getFieldByKey(this.more, "PointId");
				tmp.fullName = MoreVal.getFieldByKey(this.more, "FullName");
				tmp.comment = MoreVal.getFieldByKey(this.more, "Comment");
				this.val.add(tmp);
//					WB.addLog2("User.getVal, add tmp=" + tmp, "","User");
			}
		} catch (Exception ex) {
			WB.addLog("User.getVal():void, ex=" + ex.getMessage(), "", "User");
		}
	}

	public void isExist() throws Exception {
		// origin - 11.03.2025, last edit - 30.06.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentCodeRoleFilter(this.parent, this.code, Role.faceUser), this.table);
			if (listDto.size() != 0) {
				for (var currDto : listDto) {
					var tmp = new SpanDate(currDto.date1, currDto.date2);
					this.date1 = new ListVal(tmp.date1);
					this.date2 = new ListVal(tmp.date2);

					this.id = DefVal.setCustom(this.id, currDto.id);
					this.parent = DefVal.setCustom(this.parent, currDto.parent);
					this.code = DefVal.setCustom(this.code, currDto.code);
					this.description = DefVal.setCustom(this.description, currDto.description);
					this.geo = DefVal.setCustom(this.geo, currDto.geo);
					this.role = DefVal.setCustom(this.role, currDto.role);
					this.info = DefVal.setCustom(this.info, currDto.info);
					this.more = DefVal.setCustom(this.more, currDto.more);

					this.staffTableId = MoreVal.getFieldByKey(currDto.more, "StaffTableId");
					this.pointId = MoreVal.getFieldByKey(currDto.more, "PointId");
					this.fullName = MoreVal.getFieldByKey(currDto.more, "FullName");
					this.comment = MoreVal.getFieldByKey(currDto.more, "Comment");

					this.mark = DefVal.setCustom(this.mark, currDto.mark);

					this.restriction = new ListVal(MoreVal.getFieldByKey(currDto.more, "Restriction"), "");
					this.permission = new ListVal(MoreVal.getFieldByKey(currDto.more, "Permission"), "");

					this.isExist = true;
					break;
				}
			}

			if (listDto.size() == 0) {
				this.parent = this.code = "";
			}
		} catch (Exception ex) {
			WB.addLog("User.isExist():void, ex=" + ex.getMessage(), "", "User");
		}
	}

	public User(String ParentId, String faceUserId) throws Exception {
		// origin - 24.03.2025, last edit - 28.03.2025
		this.clear();
		this.table = "Face";
		this.src = ParentId + "," + faceUserId;
		this.parent = ParentId;
		this.code = faceUserId;
		this.isExist();
		this.getVal();
	}

	public void clear() throws Exception {
		// origin - 11.03.2025, last edit - 30.06.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.more = this.mark = "";
			this.staffTableId = this.pointId = this.fullName = this.comment = "";
			this.date1 = this.date2 = this.restriction = this.permission = new ListVal();
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("User.clear():void, ex=" + ex.getMessage(), "", "User");
		}
	}

	public User() throws Exception {
		// origin - 11.03.2025, last edit - 11.03.2025
		this.clear();
	}

	public String toString() {
		// origin - 11.03.2025, last edit - 30.06.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);

			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);

			res = res + Fmtr.addIfNotEmpty(", staffTableId ", this.staffTableId);
			res = res + Fmtr.addIfNotEmpty(", pointId ", this.pointId);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);

			res = res + Fmtr.addIfNotEmpty(", restriction ", this.restriction.id);
			res = res + Fmtr.addIfNotEmpty(", permission ", this.permission.id);

			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 11.03.2025, last edit - 13.06.2025
		try {

//			// get(List<FaceDto>)
//			for (var tmp1 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
//				WB.addLog2("User.test.get(List<FaceDto>), res.size=" + User.get(tmp1).size() + ", parentId=" + tmp1, "",
//						"User");
//				WB.log(User.get(tmp1), "User");
//			}

//			// getCurr(List<FaceDto>)
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-31", "2025-02-20", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
//					WB.addLog2("User.test.getCurr(List<FaceDto>), res.size=" + User.getCurr(tmp1, tmp2).size()
//							+ ", date1=" + tmp1 + ", parentId=" + tmp2, "", "User");
//			WB.log(User.getCurr(tmp1, tmp2), "User");
//				}
//			}

//			// getCurr(FaceDto)
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-31", "2025-02-20", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
//					for (var tmp3 : new String[] { "Face.FA1.User1", "Face.FA1.User2", "Face.Tralala.User1" }) {
//						WB.addLog2("User.test.getCurr, res.id=" + User.getCurr(tmp1, tmp2, tmp3) + ", date1=" + tmp1
//								+ ", faceParentId=" + tmp2 + ", faceUserId" + tmp3, "", "User");
//					}
//				}
//			}

//			// ctor()
//			WB.addLog2("User.test.ctor()=" + new User(), "", "User");

//			// ctor (String, String)
//			for (var tmp1 : new String[] { "Face.FA1", "Face.kgd", "Face.Tralala" }) {
//				for (var tmp2 : new String[] { "Face.FA1.User1", "Face.FA1.User2", "Face.Tralala.User1" }) {
//					WB.addLog2("User.test.ctor(String,String)=" + new User(tmp1, tmp2), "", "User");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("User.test():void, ex=" + ex.getMessage(), "", "User");
		}
	}
}