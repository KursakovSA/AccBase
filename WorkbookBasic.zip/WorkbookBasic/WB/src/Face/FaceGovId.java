import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

public final class FaceGovId {
	// origin - 29.11.2025, last edit - 21.12.2025
	public String context, src;
	public static List<String> kind;
	public static String defaultKind, defaultKindPerson;
	public static int lenghtIIN;
	public LinkedHashMap<String, String> val;

	static {
		try {
			FaceGovId.defaultKind = "БИН";
			FaceGovId.defaultKindPerson = "ИИН";
			FaceGovId.kind = FaceGovId.getKind();
			FaceGovId.lenghtIIN = Conv.getInt(MoreVal.getByKey(WB.abcLast.basic, "Numeric", "Info.Code.IIN"));
		} catch (Exception ex) {
			WB.addLog("FaceGovId.static ctor, ex=" + ex.getMessage(), "", "FaceGovId");
		}
	}

	public static String set(List<String> val, List<String> kindFaceGovId) throws Exception {
		// origin - 21.12.2025, last edit - 21.12.2025
		String res = ""; // ex. "123456789012 (ИИН):5678901234 (IdKAZ)"
		try {
			var currVal = "";
			var currKey = "";
			for (int i = 0; i < val.size(); i++) {
				currVal = val.get(i);
				if (currVal.isEmpty() == false) {
					res = res + Etc.fixTrim(currVal);
					currKey = kindFaceGovId.get(i);
					res = res + " (" + Etc.fixTrim(currKey) + ")";
				}
				res = res + ":";
			}
		} catch (Exception ex) {
			WB.addLog("FaceGovId.set(2List<String>):String, ex=" + ex.getMessage(), "", "FaceGovId");
		}
		return res;
	}

	public static String getByKind(LinkedHashMap<String, String> val, String kindFaceGovId) throws Exception {
		// origin - 02.12.2025, last edit - 11.12.2025
		String res = "";
		try {
			for (var curr : val.entrySet()) {
				// ex. kindFaceGovId="ИИН[RU]IIN[EN]", curr.getKey()="ИИН",
				if (Etc.strContains(kindFaceGovId, curr.getKey())) {
					res = Etc.fixTrim(curr.getValue());
					break;
				}
			}

			// find shift
			if (res.isEmpty()) {
				for (var curr : val.entrySet()) {
					if (Etc.strEquals(curr.getKey(), FaceGovId.defaultKindPerson)) { // ex.curr.getKey()="ИИН"
						if (Etc.strContains(kindFaceGovId, FaceGovId.defaultKind)) { // then find "БИН"
							res = Etc.fixTrim(curr.getValue());
							break;
						}
					}
					if (Etc.strEquals(curr.getKey(), FaceGovId.defaultKind)) { // ex.curr.getKey()="БИН"
						if (Etc.strContains(kindFaceGovId, FaceGovId.defaultKindPerson)) {// then find "ИИН"
							res = Etc.fixTrim(curr.getValue());
							break;
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("FaceGovId.getByKind(LinkedHashMap<2String>,String):String, ex=" + ex.getMessage(), "",
					"FaceGovId");
		}
		return res;
	}

	private static List<String> getKind() throws Exception {
		// origin - 01.12.2025, last edit - 03.12.2025
		List<String> res = new ArrayList<String>();
		try {
			for (var curr : WB.abcLast.faceGovId) {
				res.add(Etc.fixTrim(curr.description));
			}
		} catch (Exception ex) {
			WB.addLog("FaceGovId.getKind():List<String>, ex=" + ex.getMessage(), "", "FaceGovId");
		}
		return res;
	}

	private void getVal() throws Exception {
		// origin - 30.11.2024, last edit - 03.12.2025
		try {
			var tmp1 = new ListVal(this.src, "");
			for (var curr : tmp1.val) {

				if (Etc.strContains(curr, "(") == false) {
					if (Etc.strContains(curr, ")") == false) {
						curr = curr + "(" + Etc.fixTrim(FaceGovId.defaultKind) + ")";
					}
				}

				if (curr.endsWith("()")) {
					curr = curr.replace("()", "(" + FaceGovId.defaultKind + ")");
				}

				var tmp2 = new AnnoVal(curr);
				// ex. key="ИИН", value="123456789012"
				this.val.put(tmp2.anno.getFirst().toString(), tmp2.val);
			}
		} catch (Exception ex) {
			WB.addLog("FaceGovId.getVal():void, ex=" + ex.getMessage(), "", "FaceGovId");
		}
	}

	public FaceGovId(String Src) throws Exception {
		// origin - 30.11.2024, last edit - 30.11.2025
		this.clear();
		this.src = Etc.fixTrim(Src);
		this.getVal();
	}

	public FaceGovId() throws Exception {
		// origin - 30.11.2024, last edit - 30.11.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 30.11.2025, last edit - 01.12.2025
		try {
			this.context = this.src = "";
			this.val = new LinkedHashMap<String, String>();
		} catch (Exception ex) {
			WB.addLog("FaceGovId.clear():void, ex=" + ex.getMessage(), "", "FaceGovId");
		}
	}

	public String toString() {
		// origin - 30.11.2025, last edit - 30.11.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway(" src ", this.src);
			res = res + Fmtr.addAnyway(" val ", this.val);
			res = res + Fmtr.addIfNotEmpty(" context ", this.context);
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 29.11.2025, last edit - 21.12.2025
		try {

//			WB.addLog2("FaceGovId.test.set(2List<String>):String", "", "FaceGovId");
//			var tmp1 = List.of("123456789012", "5678901234");
//			var tmp2 = List.of("ИИН", "IdKAZ");
//			var tmp3 = FaceGovId.set(tmp1, tmp2);
//			WB.addLog2("FaceGovId.test.set(2List<String>):String, res=" + tmp3 + ", tmp1=" + tmp1 + ", tmp2=" + tmp2,
//					"", "FaceGovId");
//			WB.addLog2("FaceGovId.test.ctor(src=FaceGovId.set(2List<String>)), res=" + new FaceGovId(tmp3), "",
//					"FaceGovId");

//			WB.addLog2("FaceGovId.test.getByKind(LinkedHashMap<2String>,String):String", "", "FaceGovId");
//			for (var tmp1 : new String[] { "123456789012 (ИИН)", "123456789012 (БИН)",
//					"123456789012 (ИИН):5678901234 (IdKAZ)", "123456789012 (ИИН):5678901234 (IDKAZ)",
//					"123456789012:5678901234 (IdKAZ)", "123456789012():5678901234 (IdKAZ)" }) {
//				for (var tmp2 : FaceGovId.kind) {
//					WB.addLog2("FaceGovId.test.getByKind(LinkedHashMap<2String>,String):String, res=" + FaceGovId.getByKind(tmp1, tmp2) + ", src=" + tmp1
//							+ ", kindFaceGovId=" + tmp2, "", "FaceGovId");
//				}
//			}

//			WB.addLog2("FaceGovId.test.ctor(String)", "", "FaceGovId");
//			for (var tmp : new String[] { "123456789012 (ИИН)", "123456789012 (ИИН):5678901234 (IdKAZ)",
//					"123456789012:5678901234 (IdKAZ)", "123456789012():5678901234 (IdKAZ)" }) {
//				WB.addLog2("FaceGovId.test.ctor(String), res=" + new FaceGovId(tmp), "", "FaceGovId");
//			}

		} catch (Exception ex) {
			WB.addLog("FaceGovId.test():void, ex=" + ex.getMessage(), "", "FaceGovId");
		}
	}
}