import java.util.ArrayList;
import java.util.List;

public final class FaceDaily {
	// origin - 26.04.2025, last edit - 12.10.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, date1, date2, code, description, geo, role, info, mark, more;
	// special fields
	public String fullName, comment;
	// special timestamp fields
	// list common + special + timestamp fields in unified val

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("FaceDaily.static ctor, ex=" + ex.getMessage(), "", "FaceDaily");
		}
	}

	public static List<FaceDto> getByIdContains(String id) throws Exception {
		// origin - 29.09.2025, last edit - 29.09.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdContainsRoleFilter(id, "Role.Face.Daily"),
					"Face");
			if (listDto.size() != 0) {
				for (var currDto : listDto) {
					res.add(new FaceDto(currDto.id, currDto.parent, currDto.date1, currDto.date2, currDto.code,
							currDto.description, currDto.geo, currDto.role, currDto.info, currDto.more, currDto.mark));
				}
			}
		} catch (Exception ex) {
			WB.addLog("FaceDaily.getByIdContains(String):List<FaceDto>, ex=" + ex.getMessage(), "", "FaceDaily");
		}
		return res;
	}

	public static List<FaceDto> getByCodeContains(String code) throws Exception {
		// origin - 29.09.2025, last edit - 29.09.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getCodeContainsRoleFilter(code, "Role.Face.Daily"),
					"Face");
			if (listDto.size() != 0) {
				for (var currDto : listDto) {
					res.add(new FaceDto(currDto.id, currDto.parent, currDto.date1, currDto.date2, currDto.code,
							currDto.description, currDto.geo, currDto.role, currDto.info, currDto.more, currDto.mark));
				}
			}
		} catch (Exception ex) {
			WB.addLog("FaceDaily.getByCodeContains(String):List<FaceDto>, ex=" + ex.getMessage(), "", "FaceDaily");
		}
		return res;
	}

	// full list face daily items
	public static List<FaceDto> get() throws Exception {
		// origin - 26.10.2025, last edit - 26.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter("Role.Face.Daily"), "Face");
			if (listDto.size() != 0) {
				for (var currDto : listDto) {
					res.add(new FaceDto(currDto));
				}
			}
		} catch (Exception ex) {
			WB.addLog("FaceDaily.get():List<FaceDto>, ex=" + ex.getMessage(), "", "FaceDaily");
		}
		return res;
	}

	// full list face daily items for parentId
	public static List<FaceDto> get(String parentId) throws Exception {
		// origin - 04.05.2025, last edit - 26.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, "Role.Face.Daily"),
					"Face");
			if (listDto.size() != 0) {
				for (var currDto : listDto) {
					res.add(new FaceDto(currDto));
				}
			}
		} catch (Exception ex) {
			WB.addLog("FaceDaily.get(String):List<FaceDto>, ex=" + ex.getMessage(), "", "FaceDaily");
		}
		return res;
	}

	// full list face daily items on date1
	public static List<FaceDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 26.04.2025, last edit - 29.09.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var listDto = FaceDaily.get(parentId);
			res.addAll(FaceDto.getChrono(DateTool.getLocalDate(date1), listDto));
		} catch (Exception ex) {
			WB.addLog("FaceDaily.getCurr(2String):List<FaceDto>, ex=" + ex.getMessage(), "", "FaceDaily");
		}
		return res;
	}

	private void isExist() throws Exception {
		// origin - 26.04.2025, last edit - 29.09.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdRoleFilter(this.id, "Role.Face.Daily"), "Face");
			if (listDto.size() != 0) {
				for (var currDto : listDto) {
					this.date1 = DefVal.setCustom(this.date1, currDto.date1);
					this.date2 = DefVal.setCustom(this.date2, currDto.date2);
					this.id = DefVal.setCustom(this.id, currDto.id);
					this.code = DefVal.setCustom(this.code, currDto.code);
					this.description = DefVal.setCustom(this.description, currDto.description);
					this.geo = DefVal.setCustom(this.geo, currDto.geo);
					this.role = DefVal.setCustom(this.role, currDto.role);
					this.info = DefVal.setCustom(this.info, currDto.info);
					this.more = DefVal.setCustom(this.more, currDto.more);
					this.mark = DefVal.setCustom(this.mark, currDto.mark);
					this.getFieldFromMore();
					this.isExist = true;
					this.isValid = true;
				}
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("FaceDaily.isExist():void, ex=" + ex.getMessage(), "", "FaceDaily");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 12.08.2025, last edit - 12.08.2025
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("Deal.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	public FaceDaily(String Id) throws Exception {
		// origin - 26.04.2025, last edit - 29.09.2025
		this.clear();
		this.src = this.id = Id;
		this.isExist();
	}

	private void clear() throws Exception {
		// origin - 26.04.2025, last edit - 29.09.2025
		try {
			this.isValid = false;
			this.isExist = false;
			this.table = "Face";
			this.src = this.id = this.parent = this.geo = this.role = this.info = this.mark = this.more = "";
			this.date1 = this.date2 = this.code = this.description = "";
			this.fullName = this.comment = "";
		} catch (Exception ex) {
			WB.addLog("FaceDaily.clear():void, ex=" + ex.getMessage(), "", "FaceDaily");
		}
	}

	public FaceDaily() throws Exception {
		// origin - 26.04.2025, last edit - 26.04.2025
		this.clear();
	}

	public String toString() {
		// origin - 26.04.2025, last edit - 29.09.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 26.04.2025, last edit - 26.10.2025
		try {

//			WB.addLog2("FaceDaily.test.getByIdContains(String):List<FaceDto>", "", "FaceDaily");
//			for (var tmp1 : new String[] { "Face.Person.Template", "Face.Person.Tralala" }) {
//				var tmp2 = FaceDaily.getByIdContains(tmp1);
//				WB.addLog2("FaceDaily.test.getByIdContains(String):List<FaceDto>, res.size=" + tmp2.size()
//						+ ", parentId=" + tmp1, "", "FaceDaily");
//				WB.log(tmp2, "FaceDaily");
//			}

//			WB.addLog2("FaceDaily.test.getByCodeContains(String):List<FaceDto>", "", "FaceDaily");
//			for (var tmp1 : new String[] { "сообщен", "tralala" }) {
//				var tmp2 = FaceDaily.getByCodeContains(tmp1);
//				WB.addLog2("FaceDaily.test.getByCodeContains(String):List<FaceDto>, res.size=" + tmp2.size()
//						+ ", parentId=" + tmp1, "", "FaceDaily");
//				WB.log(tmp2, "FaceDaily");
//			}

//			WB.addLog2("FaceDaily.test.get():List<FaceDto>", "", "FaceDaily");
//			var tmp = FaceDaily.get();
//			WB.addLog2("FaceDaily.test.get():List<FaceDto>, res.size=" + tmp.size(), "", "FaceDaily");
//			WB.log(tmp, "FaceDaily");

//			WB.addLog2("FaceDaily.test.get(String):List<FaceDto>", "", "FaceDaily");
//			for (var tmp1 : new String[] { "Face.Person.Template" }) {
//				var tmp2 = FaceDaily.get(tmp1);
//				WB.addLog2("FaceDaily.test.get(String):List<FaceDto>, res.size=" + tmp2.size() + ", parentId=" + tmp1,
//						"", "FaceDaily");
//				WB.log(tmp2, "FaceDaily");
//			}

//			WB.addLog2("FaceDaily.test.getCurr(2String):List<FaceDto>", "", "FaceDaily");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.Person.Template" }) {
//					var tmp3 = FaceDaily.getCurr(tmp1, tmp2);
//					WB.addLog2("FaceDaily.test.getCurr(2String):List<FaceDto>, res.size=" + tmp3.size() + ", date1="
//							+ tmp1 + ", parentId=" + tmp2, "", "FaceDaily");
//					WB.log(tmp3, "FaceDaily");
//				}
//			}

//			WB.addLog2("FaceDaily.test.ctor(String)", "", "FaceDaily");
//			for (var tmp1 : new String[] { "", "Face.Person.Template.Daily.1", "Face.Person.Template.Daily.2" }) {
//				WB.addLog2("FaceDaily.test.ctor(String)=" + new FaceDaily(tmp1), "", "FaceDaily");
//			}

		} catch (Exception ex) {
			WB.addLog("FaceDaily.test():void, ex=" + ex.getMessage(), "", "FaceDaily");
		}
	}
}