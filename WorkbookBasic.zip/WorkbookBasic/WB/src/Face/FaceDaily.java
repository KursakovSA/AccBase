import java.util.ArrayList;
import java.util.List;

public class FaceDaily {
	// origin - 26.04.2025, last edit - 26.04.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, geo, role, info, mark, more;
	// special fields
	public String fullName, comment;
	// special timestamp fields
	public ListVal date1, date2, code, description;
	// list common + special + timestamp fields in unified val
	public List<FaceDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("FaceDaily.static ctor, ex=" + ex.getMessage(), "", "FaceDaily");
		}
	}

	// full list face daily items
	public static List<FaceDto> get(String parentId) throws Exception {
		// origin - 04.05.2025, last edit - 13.06.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var currFaceDaily = new FaceDaily(parentId);
			res = currFaceDaily.val;
		} catch (Exception ex) {
			WB.addLog("FaceDaily.get(String parentId):List<FaceDto>, ex=" + ex.getMessage(), "", "FaceDaily");
		}
		return res;
	}

	// full list face daily items on date1
	public static List<FaceDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 26.04.2025, last edit - 13.06.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var currFaceDaily = new FaceDaily(parentId);
			res = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceDaily.val);
		} catch (Exception ex) {
			WB.addLog("FaceDaily.getCurr(String date1, String parentId):List<FaceDto>, ex=" + ex.getMessage(), "",
					"FaceDaily");
		}
		return res;
	}

	private void getVal() throws Exception {
		// origin - 26.04.2025, last edit - 13.06.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currCode = "";
			String currDescription = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currCode = this.code.getByIndex(i);
				currDescription = this.description.getByIndex(i);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, currCode, currDescription, this.geo,
						this.role, this.info, this.more, this.mark);
				tmp.comment = this.comment;
				tmp.fullName = this.fullName;
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("FaceDaily.getVal():void, ex=" + ex.getMessage(), "", "FaceDaily");
		}
	}

	public void isExist() throws Exception {
		// origin - 26.04.2025, last edit - 13.06.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(this.parent, Role.faceDaily),
					this.table);
			if (listDto.size() != 0) {
				for (var currDto : listDto) {
					var tmp = new SpanDate(currDto.date1, currDto.date2);
					this.date1 = new ListVal(tmp.date1);
					this.date2 = new ListVal(tmp.date2);

					this.id = DefVal.setCustom(this.id, currDto.id);

					this.code = new ListVal(currDto.code, "");
					this.description = new ListVal(currDto.description, "");

					this.geo = DefVal.setCustom(this.geo, currDto.geo);
					this.role = DefVal.setCustom(this.role, currDto.role);
					this.info = DefVal.setCustom(this.info, currDto.info);
					this.more = DefVal.setCustom(this.more, currDto.more);
					this.mark = DefVal.setCustom(this.mark, currDto.mark);

					this.fullName = MoreVal.getFieldByKey(currDto.more, "FullName");
					this.comment = MoreVal.getFieldByKey(currDto.more, "Comment");

					this.isExist = true;
					break;
				}
			}

			if (listDto.size() == 0) {
				this.parent = "";
			}
		} catch (Exception ex) {
			WB.addLog("FaceDaily.isExist():void, ex=" + ex.getMessage(), "", "FaceDaily");
		}
	}

	public FaceDaily(String ParentId) throws Exception {
		// origin - 26.04.2025, last edit - 26.04.2025
		this.clear();
		this.table = "Face";
		this.src = this.parent = ParentId;
		this.isExist();
		this.getVal();
	}

	public void clear() throws Exception {
		// origin - 26.04.2025, last edit - 13.06.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = this.src = this.id = this.parent = this.geo = this.role = this.info = this.mark = this.more = "";
			this.date1 = this.date2 = this.code = this.description = new ListVal();
			this.fullName = this.comment = "";
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("FaceDaily.clear():void, ex=" + ex.getMessage(), "", "FaceDaily");
		}
	}

	public FaceDaily() throws Exception {
		// origin - 26.04.2025, last edit - 26.04.2025
		this.clear();
	}

	public String toString() {
		// origin - 26.04.2025, last edit - 26.04.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);

			res = res + Fmtr.addIfNotEmpty(", code ", this.code.id);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description.id);

			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 26.04.2025, last edit - 13.06.2025
		try {

//			// get(List<FaceDto>)
//			WB.addLog2("FaceDaily.test.get(List<FaceDto>)", "", "FaceDaily");
//			for (var tmp1 : new String[] { "Face.Person.Template" }) {
//				WB.addLog2("FaceDaily.test.get(List<FaceDto>), res.size=" + FaceDaily.get(tmp1).size() + ", parentId="
//						+ tmp1, "", "FaceDaily");
//				WB.log(FaceDaily.get(tmp1), "FaceDaily");
//			}

//			// getCurr(List<FaceDto>)
//			WB.addLog2("FaceDaily.test.getCurr(List<FaceDto>)", "", "FaceDaily");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.Person.Template" }) {
//					WB.addLog2("FaceDaily.test.getCurr(List<FaceDto>), res.size=" + FaceDaily.getCurr(tmp1, tmp2).size()
//							+ ", date1=" + tmp1 + ", parentId=" + tmp2, "", "FaceDaily");
//			//WB.log(FaceDaily.getCurr(tmp1, tmp2), "FaceDaily");
//				}
//			}

//			// ctor (String)
//			WB.addLog2("FaceDaily.test.ctor(String)", "", "FaceDaily");
//			for (var tmp1 : new String[] { "", "Face.Person.Template", "Face.FA1" }) {
//				WB.addLog2("FaceDaily.test.ctor(String)=" + new FaceDaily(tmp1), "", "FaceDaily");
//			}

//			// ctor ()
//			WB.addLog2("FaceDaily.test.ctor()", "", "FaceDaily");
//			WB.addLog2("FaceDaily.test.ctor()=" + new FaceDaily(), "", "FaceDaily");

		} catch (Exception ex) {
			WB.addLog("FaceDaily.test():void, ex=" + ex.getMessage(), "", "FaceDaily");
		}
	}
}