import java.util.ArrayList;
import java.util.List;

public class Crew {
	// origin - 25.03.2025, last edit - 01.04.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, code, description, geo, role, info, more, mark;
	// special fields
	public String crewId, fullName, comment;
	// special timestamp fields
	public ListVal date1, date2, empId;
	// list common + special + timestamp fields in unified val
	public List<FaceDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Crew.static ctor, ex=" + ex.getMessage(), "", "Crew");
		}
	}

	private void getUp() throws Exception { // get empty fields from upper
		// origin - 28.04.2025, last edit - 28.04.2025
		try {
			FaceDto upFaceDto = FaceDto.getCodeRole(this.parent, Role.faceCrew);

			if ((upFaceDto.crewId.isEmpty() == false) && (this.crewId.isEmpty())) {
				this.crewId = upFaceDto.crewId;
			}
		} catch (Exception ex) {
			WB.addLog("Crew.getUp, ex=" + ex.getMessage(), "", "Crew");
		}
	}

	// full list crew member for parentCrewId
	public static List<FaceDto> get(String parentCrewId) throws Exception {
		// origin - 04.05.2025, last edit - 04.05.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentCrewId, Role.faceCrew),
					"Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					for (var curr : new Crew(currFace.parent, currFace.code).val) {
						if (curr.id.isEmpty() == false) {
							var tmp = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code,
									curr.description, curr.geo, curr.role, curr.info, curr.more, curr.mark);
							tmp.empId = curr.empId;
							// tmp.crewId = MoreVal.getFieldByKey(curr.more, "CrewId");
							tmp.fullName = MoreVal.getFieldByKey(curr.more, "FullName");
							tmp.comment = MoreVal.getFieldByKey(curr.more, "Comment");
							res.add(tmp);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Crew.get(List<FaceDto>), ex=" + ex.getMessage(), "", "Crew");
		}
		return res;
	}

	// full list crew member for parentCrewId on date1
	public static List<FaceDto> getCurr(String date1, String parentCrewId) throws Exception {
		// origin - 25.03.2025, last edit - 28.04.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentCrewId, Role.faceCrew),
					"Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					var currFaceCrew = new Crew(currFace.parent, currFace.code);
					var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceCrew.val, "");
					if (curr.id.isEmpty() == false) {
						var tmp = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
								curr.geo, curr.role, curr.info, curr.more, curr.mark);
						tmp.empId = curr.empId;
						// tmp.crewId = MoreVal.getFieldByKey(curr.more, "CrewId");
						tmp.fullName = MoreVal.getFieldByKey(curr.more, "FullName");
						tmp.comment = MoreVal.getFieldByKey(curr.more, "Comment");
						// WB.addLog2("Crew.getCurr(List<FaceDto>), add tmp=" + tmp, "", "Crew");
						res.add(tmp);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Crew.getCurr(List<FaceDto>), ex=" + ex.getMessage(), "", "Crew");
		}
		return res;
	}

	// crew member on date1
	public static FaceDto getCurr(String date1, String parentFAId, String crewMemberCode) throws Exception {
		// origin - 25.03.2025, last edit - 28.04.2025
		FaceDto res = new FaceDto();
		try {
			var currFaceCrew = new Crew(parentFAId, crewMemberCode);
			if (currFaceCrew.val.size() != 0) {
				var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceCrew.val, "");
				if (curr.id.isEmpty() == false) {
					res = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
							curr.geo, curr.role, curr.info, curr.more, curr.mark);
					res.empId = curr.empId;
					res.crewId = MoreVal.getFieldByKey(curr.more, "CrewId");
					res.fullName = MoreVal.getFieldByKey(curr.more, "FullName");
					res.comment = MoreVal.getFieldByKey(curr.more, "Comment");
					// WB.addLog2("Crew.getCurr(FaceDto), info res=" + res, "", "Crew");
				}
			}
		} catch (Exception ex) {
			WB.addLog("Crew.getCurr(FaceDto), ex=" + ex.getMessage(), "", "Crew");
		}
		return res;
	}

	private void getVal() throws Exception {
		// origin - 25.03.2025, last edit - 28.04.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currEmpId = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currEmpId = this.empId.getByIndex(i);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description, this.geo,
						this.role, this.info, this.more, this.mark);
				tmp.empId = currEmpId;
				tmp.crewId = MoreVal.getFieldByKey(this.more, "CrewId");
				tmp.fullName = MoreVal.getFieldByKey(this.more, "FullName");
				tmp.comment = MoreVal.getFieldByKey(this.more, "Comment");
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("Crew.getVal, ex=" + ex.getMessage(), "", "Crew");
		}
	}

	private void isExist() throws Exception {
		// origin - 25.03.2025, last edit - 28.04.2025
		try {
			List<ModelDto> listDto = new ArrayList<ModelDto>();

			if ((this.parent.isEmpty() == false) && (this.code.isEmpty() == false)) {
				listDto = DAL.getByTemplate(WB.lastConnWork,
						Qry.getParentCodeRoleFilter(this.parent, this.code, Role.faceCrew), this.table);
			}

			if ((this.parent.isEmpty() == false) && (this.code.isEmpty())) {
				listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(this.parent, Role.faceCrew),
						this.table);
			}

			if (listDto.size() != 0) {
				for (var currDto : listDto) {
					var tmp = new SpanDate(currDto.date1, currDto.date2);
					this.date1 = new ListVal(tmp.date1);
					this.date2 = new ListVal(tmp.date2);

					this.id = DefVal.setCustom(this.id, currDto.id);
					this.parent = DefVal.setCustom(this.parent, currDto.parent);
					this.code = DefVal.setCustom(this.code, currDto.code);
					this.description = DefVal.setCustom(this.description, currDto.description);
					this.geo = DefVal.setCustom(this.geo, currDto.geo);
					this.role = DefVal.setCustom(this.role, currDto.role);
					this.info = DefVal.setCustom(this.info, currDto.info);

					this.empId = new ListVal(MoreVal.getFieldByKey(currDto.more, "EmpId"), "");
					this.crewId = MoreVal.getFieldByKey(currDto.more, "CrewId");
					this.fullName = MoreVal.getFieldByKey(currDto.more, "FullName");
					this.comment = MoreVal.getFieldByKey(currDto.more, "Comment");

					this.more = DefVal.setCustom(this.mark, currDto.more);
					this.mark = DefVal.setCustom(this.mark, currDto.mark);
					this.isExist = true;
					break;
				}
			}

			if (listDto.size() == 0) {
				this.parent = this.code = "";
			}
		} catch (Exception ex) {
			WB.addLog("Crew.isExist, ex=" + ex.getMessage(), "", "Crew");
		}
	}

	public Crew(String ParentId, String CrewMemberCode) throws Exception {
		// origin - 25.03.2025, last edit - 28.04.2025
		this();
		this.table = "Face";
		this.src = ParentId + "," + CrewMemberCode;
		this.parent = ParentId;
		this.code = CrewMemberCode; // ex. "Face.FA1.Crew1.Head"
		this.isExist();
		this.getVal();
		this.getUp(); // only crew member
	}

	public Crew(String ParentId) throws Exception {
		// origin - 28.03.2025, last edit - 28.03.2025
		this();
		this.table = "Face";
		this.src = ParentId; // ex. "Face.FA1"
		this.parent = ParentId;
		this.isExist();
		this.getVal();
	}

	private void clear() throws Exception {
		// origin - 25.03.2025, last edit - 01.04.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.more = this.mark = "";
			this.fullName = this.comment = this.crewId = "";
			this.date1 = this.date2 = this.empId = new ListVal();
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("Crew.clear, ex=" + ex.getMessage(), "", "Crew");
		}
	}

	public Crew() throws Exception {
		// origin - 25.03.2025, last edit - 25.03.2025
		this.clear();
	}

	public String toString() {
		// origin - 25.03.2025, last edit - 01.04.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);

			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);

			res = res + Fmtr.addIfNotEmpty(", empId ", this.empId.id);
			res = res + Fmtr.addIfNotEmpty(", crewId ", this.crewId);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);

			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 25.03.2025, last edit - 24.05.2025
		try {

//			// get(List<FaceDto>)
//			WB.addLog2("Crew.test.get(List<FaceDto>)", "", "Crew");
//			for (var tmp1 : new String[] { "Face.FA1.Crew1" }) {
//				WB.addLog2("Crew.test.getCurr(List<FaceDto>), res.size=" + Crew.get(tmp1).size() + ", parentCrewId="
//						+ tmp1, "", "Crew");
//				WB.log(Crew.get(tmp1), "Crew");
//			}

//			// getCurr(List<FaceDto>)
//			WB.addLog2("Crew.test.getCurr(List<FaceDto>)", "", "Crew");
//			for (var tmp1 : new String[] { "2024-04-05", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-20",
//					"2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1.Crew1" }) {
//					WB.addLog2("Crew.test.getCurr(List<FaceDto>), res.size=" + Crew.getCurr(tmp1, tmp2).size()
//							+ ", date1=" + tmp1 + ", parentCrewId=" + tmp2, "", "Crew");
//					WB.log(Crew.getCurr(tmp1, tmp2), "Crew");
//				}
//			}

//			// getCurr(FaceDto)
//			WB.addLog2("Crew.test.getCurr(FaceDto)", "", "Crew");
//			for (var tmp1 : new String[] { "2024-04-05", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-20",
//					"2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1.Crew1" }) {
//					for (var tmp3 : new String[] { "Face.FA1.Crew1.Head" }) {
//						WB.addLog2("Crew.test.getCurr(FaceDto), res=" + Crew.getCurr(tmp1, tmp2, tmp3) + ", date1="
//								+ tmp1 + ", crewParentId=" + tmp2 + ", crewMemberId=" + tmp3, "", "Crew");
//					}
//				}
//			}

//			// ctor (String,String) for crew member
//			WB.addLog2("Crew.test.ctor(String,String) for crew member", "", "Crew");
//			for (var tmp1 : new String[] { "Face.FA1.Crew1", "Face.Tralala.Crew1" }) {
//				for (var tmp2 : new String[] { "Face.FA1.Crew1.Head", "Face.Tralala.Crew1.Head" }) {
//					WB.addLog2("Crew.test.ctor(String,String) for crew member=" + new Crew(tmp1, tmp2)
//							+ ", parentCrewId=" + tmp1 + ", codeCrewMember=" + tmp2, "", "Crew");
//				}
//			}

//			// ctor (String) for crew
//			WB.addLog2("Crew.test.ctor(String) for crew", "", "Crew");
//			for (var tmp1 : new String[] { "Face.FA1", "Face.Tralala" }) {
//				WB.addLog2("Crew.test.ctor(String,String) for crew=" + new Crew(tmp1) + ", parentId=" + tmp1, "",
//						"Crew");
//			}

		} catch (

		Exception ex) {
			WB.addLog("Crew.test, ex=" + ex.getMessage(), "", "Crew");
		}
	}
}