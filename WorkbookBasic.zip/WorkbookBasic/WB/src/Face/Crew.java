import java.util.ArrayList;
import java.util.List;

public final class Crew {
	// origin - 25.03.2025, last edit - 15.09.2026
	// common fields
	public String table, src, id, parent, code, description, geo, role, info, more, mark, defect;
	// special fields
	public String fullName, comment;
	// special timestamp fields
	public ListVal date1, date2, empId;
	// list common + special + timestamp fields in unified val
	public List<FaceDto> val;
	public static List<String> nameList;

	static {
		try {
			Crew.nameList = List.of("CrewId");
		} catch (Exception ex) {
			WB.addLog("Crew.static ctor, ex=" + ex.getMessage(), "", "Crew");
		}
	}

//	private void getUp() throws Exception { // get empty fields from upper
//		// origin - 28.04.2025, last edit - 15.09.2026
//		try {
//			FaceDto upFaceDto = FaceDto.getCodeRole(this.parent, "Role.Face.Crew");
//			var tmp = MoreVal.getFieldByKey(upFaceDto.more, "CrewId");
//			if ((tmp.isEmpty() == false) && (this.crewId.isEmpty())) {
//				this.crewId = tmp;
//			}
//		} catch (Exception ex) {
//			WB.addLog("Crew.getUp():void, ex=" + ex.getMessage(), "", "Crew");
//		}
//	}

	// full list crew member
	public static List<FaceDto> get() throws Exception {
		// origin - 26.10.2025, last edit - 26.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter("Role.Face.Crew"), "Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					for (var curr : new Crew(currFace.parent, currFace.code).val) {
						if (curr.id.isEmpty() == false) {
							res.add(curr);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Crew.get():List<FaceDto>, ex=" + ex.getMessage(), "", "Crew");
		}
		return res;
	}

	// full list crew member for parentCrewId
	public static List<FaceDto> get(String parentCrewId) throws Exception {
		// origin - 04.05.2025, last edit - 26.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentCrewId, "Role.Face.Crew"),
					"Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					for (var curr : new Crew(currFace.parent, currFace.code).val) {
						if (curr.id.isEmpty() == false) {
							res.add(curr);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Crew.get(String):List<FaceDto>, ex=" + ex.getMessage(), "", "Crew");
		}
		return res;
	}

	// full list crew member for parentCrewId on date1
	public static List<FaceDto> getCurr(String date1, String parentCrewId) throws Exception {
		// origin - 25.03.2025, last edit - 02.10.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentCrewId, "Role.Face.Crew"),
					"Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					var currFaceCrew = new Crew(currFace.parent, currFace.code);
					var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceCrew.val, "");
					if (curr.id.isEmpty() == false) {
						var tmp = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
								curr.geo, curr.role, curr.info, curr.more, curr.mark);
						res.add(tmp);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Crew.getCurr(2String):List<FaceDto>, ex=" + ex.getMessage(), "", "Crew");
		}
		return res;
	}

	// crew member on date1
	public static FaceDto getCurr(String date1, String parentFAId, String crewMemberCode) throws Exception {
		// origin - 25.03.2025, last edit - 02.10.2025
		FaceDto res = new FaceDto();
		try {
			var currFaceCrew = new Crew(parentFAId, crewMemberCode);
			if (currFaceCrew.val.size() != 0) {
				var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceCrew.val, "");
				if (curr.id.isEmpty() == false) {
					res = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code, curr.description,
							curr.geo, curr.role, curr.info, curr.more, curr.mark);
				}
			}
		} catch (Exception ex) {
			WB.addLog("Crew.getCurr(3String):FaceDto, ex=" + ex.getMessage(), "", "Crew");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 20.11.2025, last edit - 20.11.2025
		try {
		} catch (Exception ex) {
			WB.addLog("Crew.validate():void, ex=" + ex.getMessage(), "", "Crew");
		}
	}

	private void getVal() throws Exception {
		// origin - 25.03.2025, last edit - 15.09.2026
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currEmpId = "";
			String currMore = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currEmpId = this.empId.getByIndex(i);
				currMore = "";
				currMore = currMore + MoreVal.setPart("EmpId", currEmpId);
				currMore = currMore + MoreVal.setPart("FullName", this.fullName);
				currMore = currMore + MoreVal.setPart("Comment", this.comment);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description, this.geo,
						this.role, this.info, currMore, this.mark);
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("Crew.getVal():void, ex=" + ex.getMessage(), "", "Crew");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 01.10.2025, last edit - 15.09.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.empId = new ListVal(MoreVal.getFieldByKey(this.more, "empId"), "");
		} catch (Exception ex) {
			WB.addLog("Crew.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Crew");
		}
	}

	private void isExist() throws Exception {
		// origin - 25.03.2025, last edit - 15.09.2026
		try {
			List<FullDto> listDto = new ArrayList<FullDto>();
			listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentCodeRoleFilter(this.parent, this.code, "Role.Face.Crew"), "Face");

			if (listDto.size() != 0) {
				var currDto = listDto.getFirst();
				var tmp = new SpanDate(currDto.date1, currDto.date2);
				this.date1 = new ListVal(tmp.date1);
				this.date2 = new ListVal(tmp.date2);

				this.id = DefVal.setCustom(this.id, currDto.id);
				this.parent = DefVal.setCustom(this.parent, currDto.parent);
				this.code = DefVal.setCustom(this.code, currDto.code);
				this.description = DefVal.setCustom(this.description, currDto.description);
				this.geo = DefVal.setCustom(this.geo, currDto.geo);
				this.role = DefVal.setCustom(this.role, currDto.role);
				this.info = DefVal.setCustom(this.info, currDto.info);
				this.empId = new ListVal(MoreVal.getFieldByKey(currDto.more, "EmpId"), "");
				this.fullName = MoreVal.getFieldByKey(currDto.more, "FullName");
				this.comment = MoreVal.getFieldByKey(currDto.more, "Comment");
				this.more = DefVal.setCustom(this.mark, currDto.more);
				this.mark = DefVal.setCustom(this.mark, currDto.mark);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("Crew.isExist():void, ex=" + ex.getMessage(), "", "Crew");
		}
	}

	public Crew(String ParentId, String CrewMemberCode) throws Exception {
		// origin - 25.03.2025, last edit - 15.09.2026
		this();
		this.src = ParentId + "," + CrewMemberCode;
		this.parent = ParentId; // ex. "Face.FA1"
		this.code = CrewMemberCode; // ex. "Face.FA1.Crew1.Head"
		this.isExist();
		this.getVal();
		// this.getUp(); // only crew member
		this.validate();
	}

	private void clear() throws Exception {
		// origin - 25.03.2025, last edit - 15.09.2026
		try {
			this.table = "Face";
			this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.more = this.mark = "";
			this.fullName = this.comment = this.defect = "";
			this.date1 = this.date2 = this.empId = new ListVal();
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("Crew.clear():void, ex=" + ex.getMessage(), "", "Crew");
		}
	}

	public Crew() throws Exception {
		// origin - 25.03.2025, last edit - 25.03.2025
		this.clear();
	}

	public String toString() {
		// origin - 25.03.2025, last edit - 15.09.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", empId ", this.empId.id);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addAnyway(", this.val.size ", this.val.size());
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 25.03.2025, last edit - 26.10.2025
		try {

//			WB.addLog2("Crew.test.get():List<FaceDto>", "", "Crew");
//			var tmp = Crew.get();
//			WB.addLog2("Crew.test.get():List<FaceDto>, res.size=" + tmp.size(), "", "Crew");
//			WB.log(tmp, "Crew");

//			WB.addLog2("Crew.test.get(String):List<FaceDto>", "", "Crew");
//			for (var tmp1 : new String[] { "Face.FA1.Crew1", "Face.FA1.Crew2" }) {
//				WB.addLog2("Crew.test.get(String):List<FaceDto>, res.size=" + Crew.get(tmp1).size()
//						+ ", parentCrewId=" + tmp1, "", "Crew");
//				WB.log(Crew.get(tmp1), "Crew");
//			}

//			WB.addLog2("Crew.test.getCurr(2String):List<FaceDto>", "", "Crew");
//			for (var tmp1 : new String[] { "2024-04-05", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-20",
//					"2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.FA1.Crew1" }) {
//					var tmp3 = Crew.getCurr(tmp1, tmp2);
//					WB.addLog2("Crew.test.getCurr(2String):List<FaceDto>, res.size=" + tmp3.size() + ", date1=" + tmp1
//							+ ", parentCrewId=" + tmp2, "", "Crew");
//					WB.log(tmp3, "Crew");
//				}
//			}

//			WB.addLog2("Crew.test.getCurr(3String):FaceDto", "", "Crew");
//			for (var tmp1 : new String[] { "2024-04-05", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-20",
//					"2025-08-15" }) {
//				var tmp2 = new PairVal("Face.FA1.Crew1 , Face.FA1.Crew1.Head");
//				WB.addLog2("Crew.test.getCurr(3String):FaceDto, res=" + Crew.getCurr(tmp1, tmp2.val1, tmp2.val2)
//						+ ", date1=" + tmp1 + ", parent=" + tmp2.val1 + ", code=" + tmp2.val2, "", "Crew");
//			}

//			WB.addLog2("Crew.test.ctor(2String)", "", "Crew");
//			for (var tmp1 : new String[] { "Face.FA1 , Face.FA1.Crew1", "Face.Tralala , Face.Tralala.Crew1",
//					"Face.FA1.Crew1 , Face.FA1.Crew1.Head" }) {
//				var tmp2 = new PairVal(tmp1);
//				var tmp3 = new Crew(tmp2.val1, tmp2.val2);
//				WB.addLog2("Crew.test.ctor(2String)=" + tmp3 + ", parent=" + tmp2.val1 + ", code=" + tmp2.val2, "",
//						"Crew");
//				WB.log(tmp3.val, "Crew");
//			}

		} catch (

		Exception ex) {
			WB.addLog("Crew.test():void, ex=" + ex.getMessage(), "", "Crew");
		}
	}
}