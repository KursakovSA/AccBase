import java.util.ArrayList;
import java.util.List;

public final class FaceContact {
	// origin - 25.04.2025, last edit - 02.11.2026
	// common fields
	public String table, src, id, parent, geo, role, info, mark, more, defect;
	// special fields
	public String fullName, comment;
	// special timestamp fields
	public ListVal date1, date2, code, description;
	// list common + special + timestamp fields in unified val
	public List<FaceDto> val;
	public static List<String> roleList;

	static {
		try {
			FaceContact.roleList = List.of("Role.Face.Contact");
		} catch (Exception ex) {
			WB.addLog("FaceContact.static ctor, ex=" + ex.getMessage(), "", "FaceContact");
		}
	}

	// full list faceContact
	public static List<FaceDto> get() throws Exception {
		// origin - 26.10.2025, last edit - 02.11.2026
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var faceByRole = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter(FaceContact.roleList.getFirst()),
					"Face");
			for (var currFace : faceByRole) {
				for (var curr : new FaceContact(currFace.parent).val) {
					if (curr.id.isEmpty() == false) {
						res.add(curr);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("FaceContact.get():List<FaceDto>, ex=" + ex.getMessage(), "", "FaceContact");
		}
		return res;
	}

	// full list face contact items for parentId
	public static List<FaceDto> get(String parentId) throws Exception {
		// origin - 04.05.2025, last edit - 18.10.2026
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			if (Etc.strNotValid(parentId)) {
				return res;
			}
			var currFaceContact = new FaceContact(parentId);
			res = currFaceContact.val;
		} catch (Exception ex) {
			WB.addLog("FaceContact.get(String):List<FaceDto>, ex=" + ex.getMessage(), "", "FaceContact");
		}
		return res;
	}

	// full list face contact items on date1
	public static List<FaceDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 25.04.2025, last edit - 19.10.2026
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			if (Etc.strNotValid(date1, parentId)) {
				return res;
			}
			var currFaceContact = new FaceContact(parentId);
			res = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceContact.val);
		} catch (Exception ex) {
			WB.addLog("FaceContact.getCurr(2String):List<FaceDto>, ex=" + ex.getMessage(), "", "FaceContact");
		}
		return res;
	}

	private void validate() throws Exception {
		// origin - 20.11.2025, last edit - 10.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}
		} catch (Exception ex) {
			WB.addLog("FaceContact.validate():void, ex=" + ex.getMessage(), "", "FaceContact");
		}
	}

	private void getVal() throws Exception {
		// origin - 25.04.2025, last edit - 02.10.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currCode = "";
			String currDescription = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currCode = this.code.getByIndex(i);
				currDescription = this.description.getByIndex(i);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, currCode, currDescription, this.geo,
						this.role, this.info, this.more, this.mark);
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("FaceContact.getVal():void, ex=" + ex.getMessage(), "", "FaceContact");
		}
	}

	private void isExist() throws Exception {
		// origin - 25.04.2025, last edit - 02.11.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleFilter(this.parent, FaceContact.roleList.getFirst()), "Face");
			if (listDto.size() != 0) {
				var currDto = listDto.getFirst();
				var tmp = new SpanDate(currDto.date1, currDto.date2);
				this.date1 = new ListVal(tmp.date1);
				this.date2 = new ListVal(tmp.date2);
				this.id = DefVal.setCustom(this.id, currDto.id);
				this.code = new ListVal(currDto.code, "");
				this.description = new ListVal(currDto.description, "");
				this.geo = DefVal.setCustom(this.geo, currDto.geo);
				this.role = DefVal.setCustom(this.role, currDto.role);
				this.info = DefVal.setCustom(this.info, currDto.info);
				this.more = DefVal.setCustom(this.more, currDto.more);
				this.mark = DefVal.setCustom(this.mark, currDto.mark);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.clear();
			}
		} catch (Exception ex) {
			WB.addLog("FaceContact.isExist():void, ex=" + ex.getMessage(), "", "FaceContact");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 12.08.2025, last edit - 12.08.2025
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("FaceContact.getFieldFromMore():void, ex=" + ex.getMessage(), "", "FaceContact");
		}
	}

	public FaceContact(String ParentId) throws Exception {
		// origin - 25.04.2025, last edit - 20.11.2025
		this.clear();
		this.src = this.parent = ParentId;
		this.isExist();
		this.getVal();
		this.validate();
	}

	private void clear() throws Exception {
		// origin - 25.04.2025, last edit - 20.11.2025
		try {
			this.table = "Face";
			this.src = this.id = this.parent = this.geo = this.role = this.info = this.mark = this.more = this.defect = "";
			this.date1 = this.date2 = this.code = this.description = new ListVal();
			this.fullName = this.comment = "";
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("FaceContact.clear():void, ex=" + ex.getMessage(), "", "FaceContact");
		}
	}

	public FaceContact() throws Exception {
		// origin - 25.04.2025, last edit - 25.04.2025
		this.clear();
	}

	public String toString() {
		// origin - 25.04.2025, last edit - 20.11.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code.id);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description.id);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 25.04.2025, last edit - 26.10.2025
		try {

//			WB.addLog2("FaceContact.test.get():List<FaceDto>", "", "FaceContact");
//			var tmp = FaceContact.get();
//			WB.addLog2("FaceContact.test.get():List<FaceDto>, res.size=" + tmp.size(), "", "FaceContact");
//			WB.log(tmp, "FaceContact");

//			WB.addLog2("FaceContact.test.getCurr(String):List<FaceDto>", "", "FaceContact");
//			for (var tmp1 : new String[] { "Face.Person.Template" }) {
//				WB.addLog2("FaceContact.test.getCurr(String):List<FaceDto>, res.size=" + FaceContact.get(tmp1).size()
//						+ ", parentId=" + tmp1, "", "FaceContact");
//				WB.log(FaceContact.get(tmp1), "FaceContact");
//			}

//			WB.addLog2("FaceContact.test.getCurr(2String):List<FaceDto>", "", "FaceContact");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.Person.Template" }) {
//					WB.addLog2(
//							"FaceContact.test.getCurr(2String):List<FaceDto>, res.size="
//									+ FaceContact.getCurr(tmp1, tmp2).size() + ", date1=" + tmp1 + ", parentId=" + tmp2,
//							"", "FaceContact");
//			WB.log(FaceContact.getCurr(tmp1, tmp2), "FaceContact");
//				}
//			}

//			WB.addLog2("FaceContact.test.ctor(String)", "", "FaceContact");
//			for (var tmp1 : new String[] { "", "Face.Person.Template", "Face.Tralala" }) {
//				WB.addLog2("FaceContact.test.ctor(String)=" + new FaceContact(tmp1), "", "FaceContact");
//			}

		} catch (Exception ex) {
			WB.addLog("FaceContact.test():void, ex=" + ex.getMessage(), "", "FaceContact");
		}
	}
}