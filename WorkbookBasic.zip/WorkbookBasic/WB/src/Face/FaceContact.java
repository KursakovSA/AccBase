import java.util.ArrayList;
import java.util.List;

public final class FaceContact {
	// origin - 25.04.2025, last edit - 12.10.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, geo, role, info, mark, more;
	// special fields
	public String fullName, comment;
	// special timestamp fields
	public ListVal date1, date2, code, description;
	// list common + special + timestamp fields in unified val
	public List<FaceDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("FaceContact.static ctor, ex=" + ex.getMessage(), "", "FaceContact");
		}
	}

	// full list face contact items
	public static List<FaceDto> get(String parentId) throws Exception {
		// origin - 04.05.2025, last edit - 27.09.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var currFaceContact = new FaceContact(parentId);
			res = currFaceContact.val;
		} catch (Exception ex) {
			WB.addLog("FaceContact.get(String):List<FaceDto>, ex=" + ex.getMessage(), "", "FaceContact");
		}
		return res;
	}

	// full list face contact items on date1
	public static List<FaceDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 25.04.2025, last edit - 27.09.2025
		List<FaceDto> res = new ArrayList<FaceDto>();
		try {
			var currFaceContact = new FaceContact(parentId);
			res = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceContact.val);
		} catch (Exception ex) {
			WB.addLog("FaceContact.getCurr(2String):List<FaceDto>, ex=" + ex.getMessage(), "", "FaceContact");
		}
		return res;
	}

	private void getVal() throws Exception {
		// origin - 25.04.2025, last edit - 02.10.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currCode = "";
			String currDescription = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currCode = this.code.getByIndex(i);
				currDescription = this.description.getByIndex(i);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, currCode, currDescription, this.geo,
						this.role, this.info, this.more, this.mark);
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("FaceContact.getVal():void, ex=" + ex.getMessage(), "", "FaceContact");
		}
	}

	private void isExist() throws Exception {
		// origin - 25.04.2025, last edit - 02.10.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(this.parent, "Role.Face.Contact"),
					"Face");
			if (listDto.size() != 0) {
				var currDto = listDto.getFirst();
					var tmp = new SpanDate(currDto.date1, currDto.date2);
					this.date1 = new ListVal(tmp.date1);
					this.date2 = new ListVal(tmp.date2);
					this.id = DefVal.setCustom(this.id, currDto.id);
					this.code = new ListVal(currDto.code, "");
					this.description = new ListVal(currDto.description, "");
					this.geo = DefVal.setCustom(this.geo, currDto.geo);
					this.role = DefVal.setCustom(this.role, currDto.role);
					this.info = DefVal.setCustom(this.info, currDto.info);
					this.more = DefVal.setCustom(this.more, currDto.more);
					this.mark = DefVal.setCustom(this.mark, currDto.mark);
					this.getFieldFromMore();
					this.isExist = true;
					this.isValid = true;
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("FaceContact.isExist():void, ex=" + ex.getMessage(), "", "FaceContact");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 12.08.2025, last edit - 12.08.2025
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("FaceContact.getFieldFromMore():void, ex=" + ex.getMessage(), "", "FaceContact");
		}
	}

	public FaceContact(String ParentId) throws Exception {
		// origin - 25.04.2025, last edit - 1.08.2025
		this.clear();
		this.src = this.parent = ParentId;
		this.isExist();
		this.getVal();
	}

	private void clear() throws Exception {
		// origin - 25.04.2025, last edit - 02.10.2025
		try {
			this.isValid = false;
			this.isExist = false;
			this.table = "Face";
			this.src = this.id = this.parent = this.geo = this.role = this.info = this.mark = this.more = "";
			this.date1 = this.date2 = this.code = this.description = new ListVal();
			this.fullName = this.comment = "";
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("FaceContact.clear():void, ex=" + ex.getMessage(), "", "FaceContact");
		}
	}

	public FaceContact() throws Exception {
		// origin - 25.04.2025, last edit - 25.04.2025
		this.clear();
	}

	public String toString() {
		// origin - 25.04.2025, last edit - 02.10.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code.id);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description.id);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 25.04.2025, last edit - 02.10.2025
		try {

//			WB.addLog2("FaceContact.test.getCurr(String):List<FaceDto>", "", "FaceContact");
//			for (var tmp1 : new String[] { "Face.Person.Template" }) {
//				WB.addLog2("FaceContact.test.getCurr(String):List<FaceDto>, res.size=" + FaceContact.get(tmp1).size()
//						+ ", parentId=" + tmp1, "", "FaceContact");
//				WB.log(FaceContact.get(tmp1), "FaceContact");
//			}

//			WB.addLog2("FaceContact.test.getCurr(2String):List<FaceDto>", "", "FaceContact");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Face.Person.Template" }) {
//					WB.addLog2(
//							"FaceContact.test.getCurr(2String):List<FaceDto>, res.size="
//									+ FaceContact.getCurr(tmp1, tmp2).size() + ", date1=" + tmp1 + ", parentId=" + tmp2,
//							"", "FaceContact");
//			WB.log(FaceContact.getCurr(tmp1, tmp2), "FaceContact");
//				}
//			}

//			WB.addLog2("FaceContact.test.ctor(String)", "", "FaceContact");
//			for (var tmp1 : new String[] { "", "Face.Person.Template", "Face.Tralala" }) {
//				WB.addLog2("FaceContact.test.ctor(String)=" + new FaceContact(tmp1), "", "FaceContact");
//			}

		} catch (Exception ex) {
			WB.addLog("FaceContact.test():void, ex=" + ex.getMessage(), "", "FaceContact");
		}
	}
}