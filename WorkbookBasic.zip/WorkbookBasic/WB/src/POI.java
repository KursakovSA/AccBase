//import org.apache.poi.xssf.usermodel.XSSFRow;
//import org.apache.poi.xssf.usermodel.XSSFSheet;
//import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class POI {
	// origin - 29.07.2023, last edit - 29.07.2024

//	public class ExcelReadExample {
//	    public static void main(String[] args) throws Exception {
//	        try (FileInputStream fis = new FileInputStream("Example.xlsx");
//	        		XSSFWorkbook workbook = new XSSFWorkbook(fis)) {
//	            Sheet sheet = workbook.getSheetAt(0);
//	            Iterator<Row> rowIterator = sheet.iterator();
//	            
//	            while (rowIterator.hasNext()) {
//	                Row row = rowIterator.next();
//	                Iterator<Cell> cellIterator = row.cellIterator();
//	                
//	                while (cellIterator.hasNext()) {
//	                    Cell cell = cellIterator.next();
//	                    // Обработка различных типов данных в ячейках
//	                    System.out.print(cell.toString() + "; ");
//	                }
//	                System.out.println();  // Начало новой строки
//	            }
//	        }
//	    }
//	}

//	public static void main(String[] args) {
//	    try {
//	        FileInputStream file = new FileInputStream(new File("C:\\Documents and Settings\\admin\\Desktop\\imp data\\howtodoinjava_demo.xlsx"));
//
//	        //Create Workbook instance holding reference to .xlsx file
//	        XSSFWorkbook workbook = new XSSFWorkbook(file);
//
//	        //Get first/desired sheet from the workbook
//	        XSSFSheet sheet = workbook.getSheetAt(0);
//
//	        //Iterate through each rows one by one
//	        Iterator<Row> rowIterator = sheet.iterator();
//	        while (rowIterator.hasNext())
//	        {
//	            Row row = rowIterator.next();
//	            //For each row, iterate through all the columns
//	            Iterator<Cell> cellIterator = row.cellIterator();
//
//	            while (cellIterator.hasNext()) 
//	            {
//	                Cell cell = cellIterator.next();
//	                //Check the cell type and format accordingly
//	                switch (cell.getCellType()) 
//	                {
//	                    case Cell.CELL_TYPE_NUMERIC:
//	                        System.out.print(cell.getNumericCellValue() + "\t");
//	                        break;
//	                    case Cell.CELL_TYPE_STRING:
//	                        System.out.print(cell.getStringCellValue() + "\t");
//	                        break;
//	                }
//	            }
//	            System.out.println("");
//	        }
//	        file.close();
//	    } catch (Exception e) {
//	        e.printStackTrace();
//	    }
//	}

//	public class ExcelReadExample {
//	    public static void main(String[] args) throws Exception {
//	        try (FileInputStream fis = new FileInputStream("Example.xlsx");
//	        		XSSFWorkbook workbook = new XSSFWorkbook(fis)) {
//	        	XSSFSheet sheet = workbook.getSheetAt(0);
//	            Iterator<Row> rowIterator = sheet.iterator();
//	            
//	            while (rowIterator.hasNext()) {
//	                Row row = rowIterator.next();
//	                Iterator<Cell> cellIterator = row.cellIterator();
//	                
//	                while (cellIterator.hasNext()) {
//	                    Cell cell = cellIterator.next();
//	                    // Обработка различных типов данных в ячейках
//	                    System.out.print(cell.toString() + "; ");
//	                }
//	                System.out.println();  // Начало новой строки
//	            }
//	        }
//	    }
//	}

//	public static void readFromXLSX(String file) throws Exception {
//		// origin - 29.07.2024, last edit - 29.07.2024
//		try {
//			XSSFWorkbook xlsxBook = new XSSFWorkbook(new FileInputStream(file));
//			XSSFSheet xlsxSheet = xlsxBook.getSheet("Birthdays");
//			XSSFRow row = xlsxSheet.getRow(0);
//			//XSSFCell cell = row.getCell(0);
//
//			// if(row.getCell(0).getCellType() == XSSFCell.CELL_TYPE_STRING){
//			String name = row.getCell(0).getStringCellValue();
//			System.out.println("name : " + name);
//			// }
//
//			//String val = WB.strEmpty;
////			var iterRow = xlsxSheet.iterator();
////			while (iterRow.hasNext()) {
////				var iterCell = row.cellIterator();
////				while (iterCell.hasNext()) {
////					val = iterCell.next().getStringCellValue();
////					WB.addLog2("POI.readFromXLSX, val=" + val + ", row.getRowNum=" + row.getRowNum()
////							+ ", cell.getColumnIndex=" + cell.getColumnIndex(), WB.strEmpty, "POI");
////				}
////			}
//
////        if(row.getCell(1).getCellType() == XSSFCell.CELL_TYPE_NUMERIC){
////            Date birthdate = row.getCell(1).getDateCellValue();
////            System.out.println("birthdate :" + birthdate);
////        }
//
//			xlsxBook.close();
//
//		} catch (Exception ex) {
//			WB.addLog("POI.readFromXLSX, ex=" + ex.getMessage(), WB.strEmpty, "POI");
//		} finally {
//			Etc.doNothing();
//		}
//		WB.addLog2("POI.readFromXLSX ", WB.strEmpty, "POI");
//	}

	public POI() throws Exception {
		// origin - 29.07.2024, last edit - 29.07.2024
	}

	public static void test() throws Exception {
		// origin - 29.07.2024, last edit - 16.09.2024
		try {
			//POI.readFromXLSX("C:\test.xlsx");
		} catch (Exception ex) {
			WB.addLog("POI.test, ex=" + ex.getMessage(), WB.strEmpty, "POI");
		} finally {
			Etc.doNothing();
		}
		//WB.addLog2("POI.test end ", WB.strEmpty, "POI");
	}
}
