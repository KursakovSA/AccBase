import java.io.File;
import java.time.*;

public class Logger {
	// origin - 23.10.2023, last edit - 08.12.2023
	//private static StringBuilder eventLogSpecial;//TODO
	private static int eventCounter;
	private static StringBuilder eventLog;
	private static StringBuilder eventLog2;
	private static OffsetDateTime eventGlobalStart;
	private static OffsetDateTime eventGlobalEnd;
	private static OffsetDateTime eventLocalStart;
	private static OffsetDateTime eventLocalEnd;
	private static String eventLogFile;
	private static String eventLogPath;

	static {
		eventCounter = 0;
		eventLog = new StringBuilder("");
		eventLog2 = new StringBuilder("");
		eventLogFile = "eventLog.csv"; // basic log default
		eventLogPath = WB.startDir + File.separator + eventLogFile;
	}

	public static void getGlobalStart() {
		// origin - 25.10.2023, last edit - 04.12.2023
		eventGlobalStart = Etc.getOffsetDateTimeNow();
		add("Logger.getGlobalStart, eventGlobalStart=" + eventGlobalStart, "", "Logger");
	}

	public static void getLocalStart() {
		// origin - 21.10.2023, last edit - 18.12.2023
		// Logger.getLocalStart();                       //--- for copy/paste
		eventLocalStart = Etc.getOffsetDateTimeNow();
	}

	public static void getLocalEnd(String source) {
		// origin - 21.10.2023, last edit - 18.12.2023
		// Logger.getLocalEnd();                         //--- for copy/paste
		eventLocalEnd = Etc.getOffsetDateTimeNow();
		add2("Logger.getLocalEnd, durationLocal=" + Etc.getDuration(eventLocalStart, eventLocalEnd) + " ms, " +source, "","Logger");
	}

	public static void getFinish() throws Exception {
		// origin - 26.09.2023, last edit - 05.12.2023
		getEventEnd();
		WB.writeFile(eventLogPath, eventLog.toString());
		WB.openFile(eventLogPath);
	}

	private static void getEventEnd() throws Exception {
		// origin - 21.10.2023, last edit - 06.12.2023
		eventGlobalEnd = Etc.getOffsetDateTimeNow();
		add("Logger.getEventEnd, eventGlobalEnd=" + eventGlobalEnd, "", "Logger");
		add("Logger.getEventEnd, durationGlobal=" + Etc.getDuration(eventGlobalStart, eventGlobalEnd) + " ms", "",
				"Logger");
		add("Log detail");
		add(eventLog2.toString());
		add("***********************************************************************");	
	}

	public static void add2(Object EventObj, String EventCont, String EventMeth) {
		// origin - 03.11.2023, last edit - 08.12.2023
		eventCounter = eventCounter + 1;
		appender2(formatter(EventObj, EventCont, EventMeth));
	}

	public static void add(Object EventObj, String EventCont, String EventMeth) {
		// origin - 26.09.2023, last edit - 08.12.2023
		eventCounter = eventCounter + 1;
		appender(formatter(EventObj, EventCont, EventMeth));
	}

	private static void add(String str) {
		// origin - 03.11.2023, last edit - 08.12.2023
		eventCounter = eventCounter + 1;
		appender(str + System.lineSeparator());
	}

	private static String formatter(Object eventObj, String eventCont, String eventMeth) {
		// origin - 21.10.2023, last edit - 07.12.2023
		String res = "";
		res = res + "#" + eventCounter + "; " + Etc.getOffsetDateTimeNow() + "; " + eventObj + "; ";
		if (eventCont.isEmpty()) {
			res = res + WB.currUser + "; ";
		} else {
			res = res + eventCont + ", " + WB.currUser + "; ";
		}
		res = res + eventMeth + ";" + System.lineSeparator();
		return res;
	}

	private static void appender2(String currEventAdd) {
		// origin - 03.11.2023, last edit - 05.12.2023
		eventLog2.append(currEventAdd.toString());
	}

	private static void appender(String currEventAdd) {
		// origin - 21.10.2023, last edit - 05.12.2023
		eventLog.append(currEventAdd.toString());
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 28.11.2023
	}
}
