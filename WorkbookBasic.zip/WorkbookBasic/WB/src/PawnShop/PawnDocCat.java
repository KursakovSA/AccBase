import java.util.ArrayList;
import java.util.List;

public class PawnDocCat {
	// origin - 08.07.2025, last edit - 19.11.2025
	// common fields
	public String table, src, id, parent, face1, face2, face, date1, date2, code, description, geo, role, info, mark,
			more, defect;
	// special fields
	public String pawnDocCatId, fullName, comment;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("PawnDocCat.static ctor, ex=" + ex.getMessage(), "", "PawnDocCat");
		}
	}

	// full list PawnDoc cat for parent
	public static List<PawnDocCat> getByRoot(String parentId) throws Exception {
		// origin - 08.07.2025, last edit - 13.08.2025
		List<PawnDocCat> res = new ArrayList<PawnDocCat>();
		try {
			var deal = new Deal(parentId);
			var dealList = deal.lower;
//			WB.addLog2("PawnDocCat.getByRoot(String):List<PawnDocCat>, dealList.size=" + dealList.size() + ", parentId="
//					+ parentId, "", "PawnDocCat");
			if (dealList.size() != 0) {
				for (var curr : dealList) {
					if (curr.id.isEmpty() == false) {
						var tmp = new PawnDocCat(new DealDto(curr.id, curr.parent, curr.face1, curr.face2, curr.face,
								curr.date1, curr.date2, curr.code, curr.description, curr.geo, curr.role, curr.info,
								curr.more, curr.mark));
						res.add(tmp);
					}
				}
				res.addFirst(new PawnDocCat(new DealDto(deal)));
			}
		} catch (Exception ex) {
			WB.addLog("PawnDocCat.getByRoot(String):List<PawnDocCat>, ex=" + ex.getMessage(), "", "PawnDocCat");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 19.11.2025, last edit - 19.11.2025
		try {
			if (this.pawnDocCatId.isEmpty()) {
				this.defect = this.defect + "empty pawnDocCatId; ";
			}
		} catch (Exception ex) {
			WB.addLog("PawnDocCat.validate():void, ex=" + ex.getMessage(), "", "PawnDocCat");
		}
	}

	private void isExist() throws Exception {
		// origin - 08.07.2025, last edit - 19.11.2025
		try {
			List<ModelDto> listDto = new ArrayList<ModelDto>();
			listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdRoleInfoFilter(this.id, this.role, this.info),
					"Deal");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.date1 = DefVal.setCustom(this.date1, dto.date1);
				this.date2 = DefVal.setCustom(this.date2, dto.date2);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.id = DefVal.setCustom(this.id, dto.id);
				this.face1 = DefVal.setCustom(this.face1, dto.face1);
				this.face2 = DefVal.setCustom(this.face2, dto.face2);
				this.face = DefVal.setCustom(this.face, dto.face);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.geo = DefVal.setCustom(this.geo, dto.geo);
				this.role = DefVal.setCustom(this.role, dto.role);
				this.info = DefVal.setCustom(this.info, dto.info);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.mark = DefVal.setCustom(this.mark, dto.mark);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.parent = this.id = this.code = this.description = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("PawnDocCat.isExist():void, ex=" + ex.getMessage(), "", "PawnDocCat");
		}
	}

	public PawnDocCat(DealDto dDto) throws Exception {
		// origin - 08.07.2025, last edit - 19.11.2025
		this.clear();
		this.face1 = dDto.face1;
		this.face2 = dDto.face2;
		this.face = dDto.face;
		this.date1 = dDto.date1;
		this.date2 = dDto.date2;
		this.code = dDto.code;
		this.id = dDto.id;
		this.description = dDto.description;
		this.geo = dDto.geo;
		this.role = dDto.role;
		this.info = dDto.info;
		this.more = dDto.more;
		this.mark = dDto.mark;
		this.getFieldFromMore();
		this.validate();
	}

	public PawnDocCat(String Id) throws Exception {
		// origin - 08.07.2025, last edit - 19.11.2025
		this.clear();
		this.src = Id;
		this.id = Id;
		this.role = "Role.Deal.PawnDoc";
		this.info = "Info.Deal.Catalog";
		this.isExist();
		this.validate();
	}

	private void getFieldFromMore() throws Exception {
		// origin - 11.08.2025, last edit - 11.08.2025
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.pawnDocCatId = MoreVal.getFieldByKey(this.more, "PawnDocCatId");
		} catch (Exception ex) {
			WB.addLog("PawnDocCat.getFieldFromMore():void, ex=" + ex.getMessage(), "", "PawnDocCat");
		}
	}

	private void clear() throws Exception {
		// origin - 08.07.2025, last edit - 19.11.2025
		try {
			this.table = "Deal";
			this.src = this.id = this.face1 = this.face2 = this.face = this.parent = this.date1 = this.date2 = "";
			this.code = this.description = this.geo = this.role = this.info = this.mark = this.more = this.defect = "";
			this.pawnDocCatId = "";
			this.fullName = this.comment = "";
		} catch (Exception ex) {
			WB.addLog("PawnDocCat.clear():void, ex=" + ex.getMessage(), "", "PawnDocCat");
		}
	}

	public PawnDocCat() throws Exception {
		// origin - 08.07.2025, last edit - 08.07.2025
		this.clear();
	}

	public String toString() {
		// origin - 08.07.2025, last edit - 19.11.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("table ", this.table);
			res = res + Fmtr.addIfNotEmpty(" src ", this.src);
			res = res + Fmtr.addIfNotEmpty(" id ", this.id);
			res = res + Fmtr.addIfNotEmpty(" face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(" face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(" face ", this.face);
			res = res + Fmtr.addIfNotEmpty(" parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(" date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(" date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(" code ", this.code);
			res = res + Fmtr.addIfNotEmpty(" description ", this.description);
			res = res + Fmtr.addIfNotEmpty(" ", this.geo);
			res = res + Fmtr.addIfNotEmpty(" ", this.role);
			res = res + Fmtr.addIfNotEmpty(" ", this.info);
			res = res + Fmtr.addIfNotEmpty(" more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(" defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(" pawnDocCatId ", this.pawnDocCatId);
			res = res + Fmtr.addIfNotEmpty(" fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(" comment ", this.comment);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 08.07.2025, last edit - 16.08.2025
		try {

//			WB.addLog2("PawnDocCat.test.getByRoot(String):List<PawnDocCat>", "", "PawnDocCat");
//			for (var tmp1 : new String[] { "PawnDoc.Catalog", "PawnDoc.Catalog.1",
//					"PawnDoc.Catalog.2" }) {
//				var tmp = PawnDocCat.getByRoot(tmp1);
//				WB.addLog2("PawnDocCat.test.getByRoot(String):List<PawnDocCat>, res.size=" + tmp.size() + ", parentId="
//						+ tmp1, "", "PawnDocCat");
//				WB.log(tmp, "PawnDocCat");
//			}

//			WB.addLog2("PawnDocCat.test.ctor(String)", "", "PawnDocCat");
//			for (var tmp1 : new String[] { "PawnDoc.Catalog.1", "Deal.Tralala.Catalog.1" }) {
//				WB.addLog2("PawnDocCat.test.ctor(String)=" + new PawnDocCat(tmp1), "", "PawnDocCat");
//			}

		} catch (Exception ex) {
			WB.addLog("PawnDocCat.test():void, ex=" + ex.getMessage(), "", "PawnDocCat");
		}
	}
}