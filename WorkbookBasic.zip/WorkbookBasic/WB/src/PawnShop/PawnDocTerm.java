import java.util.List;

public final class PawnDocTerm { // sectoralPawnshop
	// origin - 06.11.2024, last edit - 18.11.2025
	// common fields
	public String table, src, id, parent, face1, face2, face, date1, date2, code, description, geo, role, info, more,
			mark, defect;
	// special fields
	public String fullName, comment, templateId, termId;
	// term fields
	public PawnTerm pawnTerm;
	public AccrualTerm accrualTerm;
	public ProlongationTerm prolongationTerm;
	public PoolTerm poolTerm;
	public TemplateDocTerm templateDocTerm;

	public UnitVal durationWarrantySpan;
	public RangeVal durationDealLimit, mainDebtToEstimatedValueLimit;
	// root branch fields
	public List<ModelDto> lower, upper;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("PawnDocTerm.static ctor, ex=" + ex.getMessage(), "", "PawnDocTerm");
		}
	}

//	private void isFieldValid() throws Exception {
//		// origin - 14.09.2025, last edit - 15.09.2025
//		try {
//			if ((this.mainDebtToEstimatedValueLimit.val2 != 0.0) & (this.durationDealLimit.val2 != 0.0)
//					& (this.durationWarrantySpan.val != 0.0)) {
//				this.isValid = true;
//			}
//		} catch (Exception ex) {
//			WB.addLog("PawnDocTerm.isFieldValid():void, ex=" + ex.getMessage(), "", "PawnDocTerm");
//		}
//	}

//	private void isTermValid() throws Exception {
//		// origin - 13.09.2025, last edit - 15.09.2025
//		try {
//			if ((this.accrualTerm.isValid) // || (this.prolongationTerm.isValid == false)
//					|| (this.pawnTerm.isValid) // || (this.poolTerm.isValid == false)
//					|| (this.templateDocTerm.isValid)) {
//				this.isValid = true;
//			}
//		} catch (Exception ex) {
//			WB.addLog("PawnDocTerm.isTermValid():void, ex=" + ex.getMessage(), "", "PawnDocTerm");
//		}
//	}

	private void validate() throws Exception {
		// origin - 08.09.2025, last edit - 19.11.2025
		try {
			if (this.accrualTerm.defect.isEmpty() == false) {
				this.defect = this.defect + "defect accrualTerm; ";
			}
			if (this.pawnTerm.defect.isEmpty() == false) {
				this.defect = this.defect + "defect pawnTerm; ";
			}
			if (this.templateDocTerm.isValid) {
				this.defect = this.defect + "defect templateDocTerm; ";
			}
			if (this.mainDebtToEstimatedValueLimit.val2 == 0.0) {
				this.defect = this.defect + "empty mainDebtToEstimatedValueLimit; ";
			}
			if (this.durationDealLimit.val2 == 0.0) {
				this.defect = this.defect + "empty durationDealLimit; ";
			}
			if (this.durationWarrantySpan.val == 0.0) {
				this.defect = this.defect + "empty durationWarrantySpan; ";
			}
		} catch (Exception ex) {
			WB.addLog("PawnDocTerm.validate():void, ex=" + ex.getMessage(), "", "PawnDocTerm");
		}
	}

	private void isExist() throws Exception {
		// origin - 25.01.2025, last edit - 18.11.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), "Deal");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.code = dto.code;
				this.parent = dto.parent;
				this.face1 = dto.face1;
				this.face2 = dto.face2;
				this.face = dto.face;
				this.description = dto.description;
				this.geo = dto.geo;
				this.role = dto.role;
				this.info = dto.info;
				this.more = dto.more;
				this.mark = dto.mark;
				var listDto2 = DAL.getTable(WB.lastConnWork, Qry.getText(WB.lastConnWork, "Deal", ""));
				this.upper = ModelDto.getUpper(listDto2, this.parent);
				this.lower = ModelDto.getLower(listDto2, this.code);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("PawnDocTerm.isExist():void, ex=" + ex.getMessage(), "", "PawnDocTerm");
		}
	}

	public PawnDocTerm(String Id) throws Exception {
		// origin - 25.01.2025, last edit - 18.11.2025
		this.clear();
		this.src = this.id = this.code = Id;
		this.isExist();
		this.validate();
	}

	public PawnDocTerm() throws Exception {
		// origin - 25.01.2025, last edit - 25.01.2025
		this.clear();
	}

	public String toString() {
		// origin - 25.01.2025, last edit - 19.11.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code.length());
			res = res + Fmtr.addIfNotEmpty(", description ", this.description.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", templateId ", this.templateId);
			res = res + Fmtr.addIfNotEmpty(", termId ", this.termId);
			res = res + Fmtr.addIfNotEmpty(", accrualTerm.defect ", this.accrualTerm.defect);
			res = res + Fmtr.addIfNotEmpty(", prolongationTerm.isValid ", this.prolongationTerm.isValid);
			res = res + Fmtr.addIfNotEmpty(", poolTerm.defect ", this.poolTerm.defect);
			res = res + Fmtr.addIfNotEmpty(", pawnTerm.defect ", this.pawnTerm.defect);
			res = res + Fmtr.addIfNotEmpty(", templateDocTerm.isValid ", this.templateDocTerm.isValid);
			res = res + Fmtr.addIfNotEmpty(", mainDebtToEstimatedValueLimit ", this.mainDebtToEstimatedValueLimit.id);
			res = res + Fmtr.addIfNotEmpty(", durationDealLimit ", this.durationDealLimit.id);
			res = res + Fmtr.addIfNotEmpty(", durationWarrantySpan ", this.durationWarrantySpan.id);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	private void getFieldFromMore() throws Exception {
		// origin - 25.08.2025, last edit - 16.09.2025
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.templateId = MoreVal.getFieldByKey(this.more, "TemplateId");
			this.termId = MoreVal.getFieldByKey(this.more, "TermId");
			this.accrualTerm = new AccrualTerm(this.termId + ".Accrual");
			this.prolongationTerm = new ProlongationTerm(this.termId + ".Prolongation");
			this.poolTerm = new PoolTerm(this.termId + ".Pool");
			this.pawnTerm = new PawnTerm(this.termId + ".Pawn");
			this.templateDocTerm = new TemplateDocTerm(this.templateId);
			this.durationWarrantySpan = new UnitVal(MoreVal.getFieldByKey(this.more, "DurationWarrantySpan"));
			this.durationDealLimit = new RangeVal(MoreVal.getFieldByKey(this.more, "DurationDealLimit"));
			this.mainDebtToEstimatedValueLimit = new RangeVal(
					MoreVal.getFieldByKey(this.more, "MainDebtToEstimatedValueLimit"));
		} catch (Exception ex) {
			WB.addLog("PawnDocTerm.getFieldFromMore():void, ex=" + ex.getMessage(), "", "PawnDocTerm");
		}
	}

	private void clear() throws Exception {
		// origin - 25.01.2025, last edit - 18.11.2025
		try {
			this.table = "Deal";
			this.id = this.parent = this.date1 = this.date2 = this.face1 = this.face2 = this.face = this.code = this.description = "";
			this.geo = this.role = this.info = this.more = this.mark = this.defect = "";
			this.fullName = this.comment = this.templateId = this.termId = "";
			this.accrualTerm = new AccrualTerm();
			this.prolongationTerm = new ProlongationTerm();
			this.poolTerm = new PoolTerm();
			this.pawnTerm = new PawnTerm();
			this.templateDocTerm = new TemplateDocTerm();
			this.durationWarrantySpan = new UnitVal(UnitVal.calendarDayInit);
			this.durationDealLimit = new RangeVal(RangeVal.calendarDayInit);
			this.mainDebtToEstimatedValueLimit = new RangeVal("0.0 - 0.0(Unit.Ratio)");
		} catch (Exception ex) {
			WB.addLog("PawnDocTerm.clear():void, ex=" + ex.getMessage(), "", "PawnDocTerm");
		}
	}

	public static void test() throws Exception {
		// origin - 25.01.2025, last edit - 15.09.2025
		try {

//			WB.addLog2("PawnDocTerm.test.ctor(String)", "", "PawnDocTerm");
//			for (var tmp : new String[] { "PawnDoc.Template1.V1.Term1", "PawnDoc.Template1.V1.Term2",
//					"PawnDoc.Tralala.Term1" }) {
//				WB.addLog2("PawnDocTerm.test.ctor(String)=" + new PawnDocTerm(tmp), "", "PawnDocTerm");
//			}

		} catch (Exception ex) {
			WB.addLog("PawnDocTerm.test():void, ex=" + ex.getMessage(), "", "PawnDocTerm");
		}
	}
}