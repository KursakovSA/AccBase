import java.util.List;

public final class PawnWeight { // sectoralPawnshop
	// origin - 21.05.2025, last edit - 08.01.2026
	public String src, src1, src2;
	public UnitVal gross, netto;// , goldContent;
	public static String unitWeight;// , unitGoldContent;

	static {
		try {
			PawnWeight.unitWeight = Unit.strGr;
			// PawnGold.unitGoldContent = "Unit.GoldContent";
		} catch (Exception ex) {
			WB.addLog("PawnWeight.static ctor, ex=" + ex.getMessage(), "", "PawnWeight");
		}
	}

	public static PawnWeight getTotal(List<Pawn> pawnList) throws Exception {
		// origin - 02.01.2026, last edit - 08.01.2026
		PawnWeight res = new PawnWeight();
		try {
			var tmp1 = new UnitVal("0.0(Unit.Gr)");
			var tmp2 = new UnitVal("0.0(Unit.Gr)");
			for (var currPawn : pawnList) {
				tmp1 = UnitVal.add(tmp1, currPawn.weight.gross);
				tmp2 = UnitVal.add(tmp2, currPawn.weight.netto);
			}
			res.src = tmp1.src + " " + tmp2.src;
			res.gross = tmp1;
			res.netto = tmp2;
		} catch (Exception ex) {
			WB.addLog("PawnWeight.getTotal(List<Pawn>):PawnWeight, ex=" + ex.getMessage(), "", "PawnWeight");
		}
		return res;
	}

	private void getSrc() throws Exception {
		// origin - 21.05.2025, last edit - 08.01.2026
		try {
			if (this.src.length() != 0) {
				String tmp = Etc.fixTrim(this.src); // "weightGross weightNetto"

				int posSpace1 = tmp.indexOf(" ");
				if (posSpace1 > 0) {
					this.src1 = Etc.fixTrim(tmp.substring(0, posSpace1)); // "weightGross"
					tmp = Etc.fixTrim(tmp.substring(posSpace1)); // "weightNetto"
					this.src2 = tmp;
				}
			}
		} catch (Exception ex) {
			WB.addLog("PawnWeight.getSrc():void, ex=" + ex.getMessage(), "", "PawnWeight");
		}
	}

	private void getPart() throws Exception {
		// origin - 21.05.2025, last edit - 08.01.2026
		try {
			this.gross = new UnitVal(this.src1, PawnWeight.unitWeight);
			this.netto = new UnitVal(this.src2, PawnWeight.unitWeight);
			// this.goldContent = new UnitVal(this.src3, PawnGold.unitGoldContent);
		} catch (Exception ex) {
			WB.addLog("PawnWeight.getPart():void, ex=" + ex.getMessage(), "", "PawnWeight");
		}
	}

	public PawnWeight(String Src) throws Exception {
		// origin - 21.05.2025, last edit - 08.01.2026
		this.clear();
		this.src = Etc.fixTrim(Src); // weightGross weightNetto
		this.getSrc();
		this.getPart();
	}

	public PawnWeight() throws Exception {
		// origin - 21.05.2025, last edit - 25.05.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 21.05.2025, last edit - 08.01.2026
		try {
			this.src = this.src1 = this.src2 = "";
			this.gross = this.netto = new UnitVal("0.0(Unit.Gr)");
			// this.goldContent = new UnitVal("0.0(Unit.GoldContent)");
		} catch (Exception ex) {
			WB.addLog("PawnWeight.clear():void, ex=" + ex.getMessage(), "", "PawnWeight");
		}
	}

	public String toString() {
		// origin - 21.05.2025, last edit - 08.01.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway(" src ", this.src);
			res = res + Fmtr.addIfNotEmpty(" src1 ", this.src1);
			res = res + Fmtr.addIfNotEmpty(" src2 ", this.src2);
			if (this.src.isEmpty() == false) {
				res = res + Fmtr.addIfNotEmpty(" gross ", this.gross.id);
				res = res + Fmtr.addIfNotEmpty(" netto ", this.netto.id);
				// res = res + Fmtr.addIfNotEmpty(" goldContent ", this.goldContent.id);
			}
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 21.05.2025, last edit - 08.01.2026
		try {

//			WB.addLog2("PawnWeight.test.getTotal(List<Pawn>):PawnGold", "", "PawnWeight");
//			var tmp = Pawn.get();
//			WB.addLog2("PawnWeight.test.get():List<Pawn> for getTotal, tmp.size=" + tmp.size() + ", filterless", "",
//					"PawnWeight");
//			WB.log(tmp, "PawnWeight");
//			WB.addLog2("PawnWeight.test.getTotal(List<Pawn>):PawnGold>, res=" + PawnWeight.getTotal(tmp), "",
//					"PawnWeight");

//			WB.addLog2("PawnWeight.test.ctor(String)", "", "PawnWeight");
//			for (var tmp1 : new String[] { "6.8 5.4", "8 7", "9 8", "9,3 8,5" }) {
//				WB.addLog2("PawnWeight.test.ctor(String)=" + new PawnWeight(tmp1), "", "PawnWeight");
//			}

		} catch (Exception ex) {
			WB.addLog("PawnWeight.test():void, ex=" + ex.getMessage(), "", "PawnWeight");
		}
	}
}