public class PoolTerm {
	// origin - 31.08.2025, last edit - 03.09.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, face1, face2, face, date1, date2, code, description, geo, role, info, more,
			mark;
	// special fields
	public String fullName, comment, templateId, termId;
	public UnitVal firstItemLimit;
	public RangeVal countLimit, nextItemLimit;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("PoolTerm.static ctor, ex=" + ex.getMessage(), "", "PoolTerm");
		}
	}

	public static boolean isPoolTerm(String role, String info) throws Exception {
		// origin - 31.08.2025, last edit - 15.09.2025
		boolean res = false;
		try {
			if ((Etc.strEquals(role, "Role.Deal.Pool")) && (Etc.strEquals(info, "Info.Deal.Term"))) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("PoolTerm.isPoolTerm(2string), ex=" + ex.getMessage(), "", "PoolTerm");
		}
		return res;
	}

	private void isValid() throws Exception {
		// origin - 08.09.2025, last edit - 15.09.2025
		if (this.isExist) {
			if ((this.countLimit.val2 != 0) & (this.firstItemLimit.val != 0) & (this.nextItemLimit.val2 != 0)) {
				this.isValid = true;
			}
		}
		try {
		} catch (Exception ex) {
			WB.addLog("PoolTerm.isValid():void, ex=" + ex.getMessage(), "", "PoolTerm");
		}
	}

	private void isExist() throws Exception {
		// origin - 31.08.2025, last edit - 14.09.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), "Deal");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.code = dto.code;
				this.parent = dto.parent;
				this.face1 = dto.face1;
				this.face2 = dto.face2;
				this.face = dto.face;
				this.description = dto.description;
				this.geo = dto.geo;
				this.role = dto.role;
				this.info = dto.info;
				this.more = dto.more;
				this.getFieldFromMore();
				this.isExist = true;
			}
			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("PoolTerm.isExist():void, ex=" + ex.getMessage(), "", "PoolTerm");
		}
	}

	@SuppressWarnings("unused")
	private String getMoreFromField() throws Exception {
		// origin - 31.08.2025, last edit - 31.08.2025
		String res = "";
		try {
			res = res + MoreVal.setPartMore("TemplateId", this.templateId);
			res = res + MoreVal.setPartMore("TermId", this.termId);
			res = res + MoreVal.setPartMore("CountLimit", this.countLimit.src);
			res = res + MoreVal.setPartMore("FirstItemLimit", this.firstItemLimit.src);
			res = res + MoreVal.setPartMore("NextItemLimit", this.nextItemLimit.src);
		} catch (Exception ex) {
			WB.addLog("Prolongation.getMoreFromField():String, ex=" + ex.getMessage(), "", "Prolongation");
		}
		return res;
	}

	private void getFieldFromMore() throws Exception {
		// origin - 31.08.2025, last edit - 31.08.2025
		try {
			this.templateId = MoreVal.getFieldByKey(this.more, "TemplateId");
			this.termId = MoreVal.getFieldByKey(this.more, "TermId");
			this.countLimit = new RangeVal(MoreVal.getFieldByKey(this.more, "CountLimit"));
			this.firstItemLimit = new UnitVal(MoreVal.getFieldByKey(this.more, "FirstItemLimit"));
			this.nextItemLimit = new RangeVal(MoreVal.getFieldByKey(this.more, "NextItemLimit"));
		} catch (Exception ex) {
			WB.addLog("Prolongation.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Prolongation");
		}
	}

//	// get new PoolTerm by List<ModelDto>,... without isExist
//	public PoolTerm(List<ModelDto> listModelDto) throws Exception {
//		// origin - 31.08.2025, last edit - 13.09.2025
//		this.clear();
//		for (var currModelDto : listModelDto) {
//			if (isPoolTerm(currModelDto.role, currModelDto.info)) {
//				var dDto = new DealDto(currModelDto);
//				this.src = this.id = dDto.id;
//				this.parent = dDto.parent;
//				this.face1 = dDto.face1;
//				this.face2 = dDto.face2;
//				this.face = dDto.face;
//				this.date1 = dDto.date1;
//				this.date2 = dDto.date2;
//				this.code = dDto.code;
//				this.description = dDto.description;
//				this.geo = dDto.geo;
//				this.role = dDto.role;
//				this.info = dDto.info;
//				this.more = dDto.more;
//				this.getFieldFromMore();
//				this.mark = dDto.mark;
//				this.isValid();
//			}
//		}
//	}

	public PoolTerm(String Id) throws Exception {
		// origin - 31.08.2025, last edit - 08.09.2025
		this.clear();
		this.src = this.id = this.code = Id;
		this.isExist();
		this.isValid();
	}

	public PoolTerm() throws Exception {
		// origin - 31.08.2025, last edit - 31.08.2025
		this.clear();
	}

	public String toString() {
		// origin - 31.08.2025, last edit - 31.08.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code.length());
			res = res + Fmtr.addIfNotEmpty(", description ", this.description.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addIfNotEmpty(", templateId ", this.templateId);
			res = res + Fmtr.addIfNotEmpty(", termId ", this.termId);

			res = res + Fmtr.addIfNotEmpty(", countLimit ", this.countLimit.id);
			res = res + Fmtr.addIfNotEmpty(", firstItemLimit ", this.firstItemLimit.id);
			res = res + Fmtr.addIfNotEmpty(", nextItemLimit ", this.nextItemLimit.id);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	private void clear() throws Exception {
		// origin - 31.08.2025, last edit - 15.09.2025
		try {
			this.isValid = false;
			this.isExist = false;
			this.table = "Deal";
			this.id = this.parent = this.date1 = this.date2 = this.face1 = this.face2 = this.face = this.code = this.description = "";
			this.geo = this.role = this.info = this.more = this.mark = "";
			this.fullName = this.comment = this.templateId = this.termId = "";

			this.firstItemLimit = new UnitVal(UnitVal.currCurrencyInit);
			this.countLimit = new RangeVal("1.0 - 10.0(Unit.PawnDoc)");
			this.nextItemLimit = new RangeVal(RangeVal.currCurrencyInit);
		} catch (Exception ex) {
			WB.addLog("PoolTerm.clear():void, ex=" + ex.getMessage(), "", "PoolTerm");
		}
	}

	public static void test() throws Exception {
		// origin - 31.08.2025, last edit - 15.09.2025
		try {

//			WB.addLog2("PoolTerm.test.ctor(String)", "", "PoolTerm");
//			for (var tmp1 : new String[] { "", "PawnDoc.Template1.V1.Term1.Pool" }) {
//				WB.addLog2("PoolTerm.test.ctor(String)=" + new PoolTerm(tmp1), "", "PoolTerm");
//			}

		} catch (Exception ex) {
			WB.addLog("PoolTerm.test():void, ex=" + ex.getMessage(), "", "PoolTerm");
		}
	}
}