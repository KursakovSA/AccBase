import java.util.List;

public final class PawnKind {
	// origin - 06.01.2026, last edit - 07.01.2026
	public String src, code, description;
	public static List<String> kind;
	public static String defaultKind;

	static {
		try {
			PawnKind.kind = new ListVal("Info.Code.PawnKind").val;
			PawnKind.defaultKind = PawnKind.kind.getFirst();
		} catch (Exception ex) {
			WB.addLog("PawnKind.static ctor, ex=" + ex.getMessage(), "", "PawnKind");
		}
	}

	public PawnKind(String Src) throws Exception {
		// origin - 06.01.2026, last edit - 07.01.2026
		this.clear();
		this.src = Etc.fixTrim(Src);
		if (PawnKind.kind.contains(Src)) {
			this.code = this.description = this.src;
		}
	}

	public PawnKind() throws Exception {
		// origin - 06.01.2026, last edit - 06.01.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 06.01.2026, last edit - 06.01.2026
		try {
			this.src = this.code = this.description = "";
		} catch (Exception ex) {
			WB.addLog("PawnKind.clear():void, ex=" + ex.getMessage(), "", "PawnKind");
		}
	}

	public String toString() {
		// origin - 06.01.2026, last edit - 06.01.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway(" src ", this.src);
			res = res + Fmtr.addIfNotEmpty(" code ", this.code);
			res = res + Fmtr.addIfNotEmpty(" description ", this.description);
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 06.01.2026, last edit - 07.01.2026
		try {

//			WB.addLog2("PawnKind.test.ctor(String)", "", "PawnKind");
//			for (var tmp : new String[] { "золото", "золотишко", "автомобиль", "тачка" }) {
//				WB.addLog2("PawnKind.test.ctor(String), res=" + new PawnKind(tmp), "", "PawnKind");
//			}

		} catch (Exception ex) {
			WB.addLog("PawnKind.test():void, ex=" + ex.getMessage(), "", "PawnKind");
		}
	}
}