public final class PawnReg { // sectoralPawnshop
	// origin - 25.05.2025, last edit - 08.01.2026
	public String src, src1, src2, src3;
	public String code, doc, number;
	// public String carDoc, carNumber, color, producer, VINCode, dateMFG;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("PawnReg.static ctor, ex=" + ex.getMessage(), "", "PawnReg");
		}
	}

	private void getSrc() throws Exception {
		// origin - 25.05.2025, last edit - 08.01.2026
		try {
			if (this.src.length() != 0) {
				String tmp = Etc.fixTrim(this.src); // "code, doc, number"

				int posSpace1 = tmp.indexOf(" ");
				if (posSpace1 > 0) {
					this.src1 = Etc.fixTrim(tmp.substring(0, posSpace1)); // "code"
					tmp = Etc.fixTrim(tmp.substring(posSpace1)); // "doc, number"

					int posSpace2 = tmp.indexOf(" ");
					if (posSpace2 > 0) {
						this.src2 = Etc.fixTrim(tmp.substring(0, posSpace2)); // "doc"
						this.src3 = Etc.fixTrim(tmp.substring(posSpace2)); // "number"
					} else {
						this.src2 = tmp;
					}
				} else {
					this.src1 = tmp;
				}
			}
		} catch (Exception ex) {
			WB.addLog("PawnReg.getSrc():void, ex=" + ex.getMessage(), "", "PawnReg");
		}
	}

	private void getPart() throws Exception {
		// origin - 25.05.2025, last edit - 14.06.2025
		try {
			this.code = src1;
			this.doc = src2;
			this.number = src3;
		} catch (Exception ex) {
			WB.addLog("PawnReg.getPart():void, ex=" + ex.getMessage(), "", "PawnReg");
		}
	}

	public PawnReg(String Src) throws Exception {
		// origin - 25.05.2025, last edit - 25.05.2025
		this.clear();
		this.src = Etc.fixTrim(Src); // "code, doc, number"
		this.getSrc();
		this.getPart();
	}

	public PawnReg() throws Exception {
		// origin - 25.05.2025, last edit - 25.05.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 21.05.2025, last edit - 06.09.2025
		try {
			this.src = this.src1 = this.src2 = this.src3 = "";
			this.code = this.doc = this.number = "";
		} catch (Exception ex) {
			WB.addLog("PawnReg.clear():void, ex=" + ex.getMessage(), "", "PawnReg");
		}
	}

	public String toString() {
		// origin - 25.05.2025, last edit - 08.01.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway(" src ", this.src);
			res = res + Fmtr.addIfNotEmpty(" src1 ", this.src1);
			res = res + Fmtr.addIfNotEmpty(" src2 ", this.src2);
			res = res + Fmtr.addIfNotEmpty(" src3 ", this.src3);
			res = res + Fmtr.addIfNotEmpty(" code ", this.code);
			res = res + Fmtr.addIfNotEmpty(" doc ", this.doc);
			res = res + Fmtr.addIfNotEmpty(" number ", this.number);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 25.05.2025, last edit - 08.01.2026
		try {

//			WB.addLog2("PawnReg.test.ctor(String)", "", "PawnReg");
//			for (var tmp1 : new String[] { "111 222 N222", "111 222", "111" }) {
//				WB.addLog2("PawnReg.test.ctor(String)=" + new PawnReg(tmp1), "", "PawnReg");
//			}

		} catch (Exception ex) {
			WB.addLog("PawnReg.test():void, ex=" + ex.getMessage(), "", "PawnReg");
		}
	}
}