import java.util.ArrayList;
import java.util.List;

public final class Pawn { // sectoralPawnshop
	// origin - 24.11.2024, last edit - 19.10.2025
	// common fields
	public String table, src, id, parent, face1, face2, face, date1, date2, code, description, geo, role, info, more,
			mark, defect;
	// special fields
	public String fullName, comment, templateId, termId, pawnId;
	public String productCondition, assetCatId, gem;
	public ListVal assetDefectCatId, descriptionPattern;
	public String VINCode, IMEICode, carDoc, carNumber, color, producer, dateMFG;
	public UnitVal weightGross, weightNetto, goldContent, weightCarat;
	public UnitVal estimatedValue, partMainDebt;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Pawn.static ctor, ex=" + ex.getMessage(), "", "Pawn");
		}
	}

	public void getByTemplate() throws Exception { // TODO
		// origin - 02.09.2025, last edit - 15.09.2025
		try {
			this.id = new IdGen("", "").id;
			this.date1 = DateTool.getNow().toString();
			this.date2 = "";
			this.code = "";
			this.description = "";
			this.more = this.getMoreFromField();
			this.mark = "Mark.DD";
		} catch (Exception ex) {
			WB.addLog2("Pawn.getByTemplate():void, ex=" + ex.getMessage(), "", "Pawn");
		}
	}

	public static Pawn getTotal(List<Pawn> listPawn) throws Exception {
		// origin - 17.08.2025, last edit - 19.08.2025
		Pawn res = new Pawn();
		try {
			for (var currPawn : listPawn) {
				// WB.addLog2("Pawn.getTotal(List<Pawn>):Pawn, currPawn=" + currPawn,"",
				// "Pawn");
				res.weightGross = UnitVal.add(res.weightGross, currPawn.weightGross);
				res.weightNetto = UnitVal.add(res.weightNetto, currPawn.weightNetto);
				res.weightCarat = UnitVal.add(res.weightCarat, currPawn.weightCarat);
				res.estimatedValue = UnitVal.add(res.estimatedValue, currPawn.estimatedValue);
				res.partMainDebt = UnitVal.add(res.partMainDebt, currPawn.partMainDebt);
			}
		} catch (Exception ex) {
			WB.addLog("Pawn.getTotal(List<Pawn>):Pawn, ex=" + ex.getMessage(), "", "Pawn");
		}
		return res;
	}

//	private void getId() throws Exception {
//		// origin - 19.06.2025, last edit - 02.09.2025
//		try {
//			this.id = new IdGen("", "").id;
//		} catch (Exception ex) {
//			WB.addLog("Pawn.getId():void, ex=" + ex.getMessage(), "", "Pawn");
//		}
//	}

	public static String getPawnId() throws Exception {
		// origin - 19.06.2025, last edit - 30.06.2025
		String res = "";
		try {
			res = new IdGen("PawnId", "idStringGrowingDigitalPoint").id;
		} catch (Exception ex) {
			WB.addLog("Pawn.getPawnId():String, ex=" + ex.getMessage(), "", "Pawn");
		}
		return res;
	}

	public static List<ModelDto> set(List<Pawn> listPawn) throws Exception {
		// origin - 01.09.2025, last edit - 01.09.2025
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			for (var currPawn : listPawn) {
				res.add(Pawn.set(currPawn));
			}
		} catch (Exception ex) {
			WB.addLog("Pawn.set(List<Pawn>):List<ModelDto>, ex=" + ex.getMessage(), "", "Pawn");
		}
		return res;
	}

	public static ModelDto set(Pawn pawn) throws Exception {
		// origin - 12.06.2025, last edit - 02.09.2025
		ModelDto res = new ModelDto();
		try {
			res.id = pawn.id;
			res.parent = pawn.parent;
			res.date1 = pawn.date1;
			res.date2 = pawn.date2;
			res.face1 = pawn.face1;
			res.face2 = pawn.face2;
			res.face = pawn.face;
			res.code = pawn.code;
			res.description = pawn.description;
			res.geo = pawn.geo;
			res.role = pawn.role;
			res.info = pawn.info;
			res.mark = pawn.mark;
			res.more = pawn.getMoreFromField();
		} catch (Exception ex) {
			WB.addLog("Pawn.set(Pawn):ModelDto, ex=" + ex.getMessage(), "", "Pawn");
		}
		return res;
	}

	private void correct() throws Exception { // TODO
		// origin - 11.06.2025, last edit - 11.06.2025
		try {
			if (this.code.isEmpty() == false) {
				if (this.description.isEmpty()) {
					this.description = this.code;
				}
			}

			if (this.description.isEmpty() == false) {
				if (this.code.isEmpty()) {
					this.code = this.description;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Pawn.correct():void, ex=" + ex.getMessage(), "", "Pawn");
		}
	}

	public static String getDescrByPattern(Pawn pawn) throws Exception {
		// origin - 31.05.2025, last edit - 15.09.2025
		String res = "";
		List<String> descrPattern = List.of("AssetCatId", "Gem", "GoldContent", " проба, ", " вес:", "WeightGross", "/",
				"WeightNetto", " гр. ", "AssetDefectCatId");
		if (pawn.descriptionPattern.val.size() != 0) {
			descrPattern = pawn.descriptionPattern.val;
			// WB.addLog2("Pawn.getDescrByPattern(Pawn pawn), descrPattern=" + descrPattern,
			// "", "Pawn");
		}
		try {
			for (var curr : descrPattern) {
				switch (curr) {
				case "AssetCatId" -> res = res + new AssetCat(pawn.assetCatId, "Role.Asset.Jewel").fullName;
				case "Gem" -> res = res + pawn.gem;
				case "AssetDefectCatId" -> res = res + pawn.assetDefectCatId.val;
				case "GoldContent" -> res = res + pawn.goldContent.partVal;
				case "WeightGross" -> res = res + pawn.weightGross.val;
				case "WeightNetto" -> res = res + pawn.weightNetto.val;
				default -> res = res + curr;
				}
				res = res + " ";
			}
		} catch (Exception ex) {
			WB.addLog("Pawn.getDescrByPattern(Pawn):String, ex=" + ex.getMessage(), "", "Pawn");
		}
		return res;
	}

	public static List<Pawn> getByParent(String parentId) throws Exception {
		// origin - 25.05.2025, last edit - 15.09.2025
		List<Pawn> res = new ArrayList<Pawn>();
		try {
			var pawnList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, "Role.Deal.Pawn"), "Deal");
			if (pawnList.size() != 0) {
				for (var currPawnList : pawnList) {
					var currPawn = new Pawn(currPawnList.id, currPawnList.parent, currPawnList.face1,
							currPawnList.face2, currPawnList.face, currPawnList.date1, currPawnList.date2,
							currPawnList.code, currPawnList.description, currPawnList.geo, currPawnList.role,
							currPawnList.info, currPawnList.more, currPawnList.mark);
					if (currPawn.code.isEmpty() == false) {
						res.add(currPawn);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Pawn.getByParent(String):List<Pawn>, ex=" + ex.getMessage(), "", "Pawn");
		}
		return res;
	}

	public static List<Pawn> get() throws Exception { // full list pawn
		// origin - 25.05.2025, last edit - 15.09.2025
		List<Pawn> res = new ArrayList<Pawn>();
		try {
			var pawnList = DAL.getByTemplate(WB.lastConnWork,
					Qry.getRoleMarkInFilter("Role.Deal.Pawn", Mark.qryFilter_CD_DD_TD), "Deal");
			if (pawnList.size() != 0) {
				for (var currPawnList : pawnList) {
					var currPawn = new Pawn(currPawnList.id, currPawnList.parent, currPawnList.face1,
							currPawnList.face2, currPawnList.face, currPawnList.date1, currPawnList.date2,
							currPawnList.code, currPawnList.description, currPawnList.geo, currPawnList.role,
							currPawnList.info, currPawnList.more, currPawnList.mark);
					if (currPawn.code.isEmpty() == false) {
						res.add(currPawn);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Pawn.get():List<Pawn>, ex=" + ex.getMessage(), "", "Pawn");
		}
		return res;
	}

	public static List<Pawn> getCurr(String date1, List<String> parentIdList) throws Exception {
		// origin - 22.06.2025, last edit - 02.09.2025
		List<Pawn> res = new ArrayList<Pawn>();
		try {
			List<Pawn> tmp = new ArrayList<Pawn>();
			for (var currParentId : parentIdList) {
				tmp = Pawn.getCurr(date1, currParentId);
				for (var currPawn : tmp) {
					res.add(currPawn);
				}
			}
		} catch (Exception ex) {
			WB.addLog("Pawn.getCurr(String, List<String>):List<Pawn>, ex=" + ex.getMessage(), "",
					"Pawn");
		}
		return res;
	}

	public static List<Pawn> getCurr(String date1, String parentId) throws Exception {
		// origin - 25.05.2025, last edit - 15.09.2025
		List<Pawn> res = new ArrayList<Pawn>();
		try {
			var pawnList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, "Role.Deal.Pawn"), "Deal");
			if (pawnList.size() != 0) {
				var listDealDto = DealDto.get(pawnList);
				var selectPawnList = DealDto.getChrono(DateTool.getLocalDate(date1), listDealDto);
				for (var curr : selectPawnList) {
					if (curr.code.isEmpty() == false) {
						var currPawn = new Pawn(curr.id, curr.parent, curr.face1, curr.face2, curr.face, curr.date1,
								curr.date2, curr.code, curr.description, curr.geo, curr.role, curr.info, curr.more,
								curr.mark);
						res.add(currPawn);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Pawn.getCurr(2String):List<Pawn>, ex=" + ex.getMessage(), "", "Pawn");
		}
		return res;
	}

	public static List<Pawn> getCurr(String date1) throws Exception {
		// origin - 25.05.2025, last edit - 15.09.2025
		List<Pawn> res = new ArrayList<Pawn>();
		try {
			var pawnList = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter("Role.Deal.Pawn"), "Deal");
			if (pawnList.size() != 0) {
				var listDealDto = DealDto.get(pawnList);
				var selectPawnList = DealDto.getChrono(DateTool.getLocalDate(date1), listDealDto);
				for (var curr : selectPawnList) {
					if (curr.code.isEmpty() == false) {
						var currPawn = new Pawn(curr.id, curr.parent, curr.face1, curr.face2, curr.face, curr.date1,
								curr.date2, curr.code, curr.description, curr.geo, curr.role, curr.info, curr.more,
								curr.mark);
						res.add(currPawn);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Pawn.getCurr(String):List<Pawn>, ex=" + ex.getMessage(), "", "Pawn");
		}
		return res;
	}
	
	private void validate() throws Exception { //TODO
		// origin - 19.11.2025, last edit - 19.11.2025
		try {
			if (this.pawnId.isEmpty()) {
				this.defect = this.defect + "empty pawnId; ";
			}
			if (this.termId.isEmpty()) {
				this.defect = this.defect + "empty termId; ";
			}
			if (this.templateId.isEmpty()) {
				this.defect = this.defect + "empty templateId; ";
			}	
		} catch (Exception ex) {
			WB.addLog("Pawn.validate():void, ex=" + ex.getMessage(), "", "Pawn");
		}
	}

	private String getMoreFromField() throws Exception {
		// origin - 19.05.2025, last edit - 01.09.2025
		String res = "";
		try {
			res = res + MoreVal.setPartMore("PawnId", this.pawnId);
			res = res + MoreVal.setPartMore("TemplateId", this.templateId);
			res = res + MoreVal.setPartMore("TermId", this.termId);
			res = res + MoreVal.setPartMore("PawnAuto", MoreVal.getFieldByKey(this.more, "PawnAuto"));
			res = res + MoreVal.setPartMore("PC", MoreVal.getFieldByKey(this.more, "PC"));
			res = res + MoreVal.setPartMore("ProductCondition", this.productCondition);
			res = res + MoreVal.setPartMore("AssetCatId", this.assetCatId);
			res = res + MoreVal.setPartMore("Gem", this.gem);
			res = res + MoreVal.setPartMore("AssetDefectCatId", this.assetDefectCatId.id);
			res = res + MoreVal.setPartMore("DescriptionPattern", this.descriptionPattern.id);
			res = res + MoreVal.setPartMore("PG", MoreVal.getFieldByKey(this.more, "PG"));
			res = res + MoreVal.setPartMore("PS", MoreVal.getFieldByKey(this.more, "PS"));
		} catch (Exception ex) {
			WB.addLog("Pawn.getMoreFromField():String, ex=" + ex.getMessage(), "", "Pawn");
		}
		return res;
	}

	private void isExist() throws Exception {
		// origin - 11.01.2025, last edit - 18.11.2025
		try {
			List<ModelDto> listDto = new ArrayList<ModelDto>();
			listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdRoleFilter(this.id, "Role.Deal.Pawn"), "Deal");

			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.id = DefVal.setCustom(this.id, dto.id);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.parent = DefVal.setCustom(this.parent, dto.parent);
				this.face1 = DefVal.setCustom(this.face1, dto.face1);
				this.face2 = DefVal.setCustom(this.face2, dto.face2);
				this.face = DefVal.setCustom(this.face, dto.face);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.geo = DefVal.setCustom(this.geo, dto.geo);
				this.role = DefVal.setCustom(this.role, dto.role);
				this.info = DefVal.setCustom(this.info, dto.info);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.getFieldFromMore();
			}
			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("Pawn.isExist():void, ex=" + ex.getMessage(), "", "Pawn");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 19.05.2025, last edit - 01.09.2025
		try {
			this.pawnId = MoreVal.getFieldByKey(this.more, "PawnId");
			this.templateId = MoreVal.getFieldByKey(this.more, "TemplateId");
			this.termId = MoreVal.getFieldByKey(this.more, "TermId");

			var tmp1 = new PawnAuto(MoreVal.getFieldByKey(this.more, "PawnAuto"));
			this.VINCode = tmp1.VINCode;
			this.carDoc = tmp1.carDoc;
			this.carNumber = tmp1.carNumber;

			var tmp2 = new PawnCell(MoreVal.getFieldByKey(this.more, "PC"));
			this.IMEICode = tmp2.IMEICode;

			// these fields may be in auto or in cell
			this.color = DefVal.set(tmp1.color, tmp2.color);
			this.producer = DefVal.set(tmp1.producer, tmp2.producer);
			this.dateMFG = DefVal.set(tmp1.dateMFG, tmp2.dateMFG);

			this.productCondition = MoreVal.getFieldByKey(this.more, "ProductCondition");
			this.assetCatId = MoreVal.getFieldByKey(this.more, "AssetCatId");
			this.gem = MoreVal.getFieldByKey(this.more, "Gem");
			this.descriptionPattern = new ListVal(MoreVal.getFieldByKey(this.more, "DescriptionPattern"), "");
			this.assetDefectCatId = new ListVal(MoreVal.getFieldByKey(this.more, "AssetDefectCatId"), "");

			var tmp3 = new PawnGold(MoreVal.getFieldByKey(this.more, "PG"));
			this.weightGross = tmp3.weightGross;
			this.weightNetto = tmp3.weightNetto;
			this.goldContent = tmp3.goldContent;
			this.weightCarat = tmp3.weightCarat;

			var tmp4 = new PawnSum(MoreVal.getFieldByKey(this.more, "PS"));
			this.estimatedValue = tmp4.estimatedValue;
			this.partMainDebt = tmp4.partMainDebt;
		} catch (Exception ex) {
			WB.addLog("Pawn.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Pawn");
		}
	}

	// get new pawn by DealDto.id,... without isExist
	public Pawn(String Id, String Parent, String Face1, String Face2, String Face, String Date1, String Date2,
			String Code, String Description, String Geo, String Role, String Info, String More, String Mark)
			throws Exception {
		// origin - 11.06.2025, last edit - 19.11.2025
		this.clear();
		this.src = this.id = Id;
		this.parent = Parent;
		this.face1 = Face1;
		this.face2 = Face2;
		this.face = Face;
		this.date1 = Date1;
		this.date2 = Date2;
		this.code = Code;
		this.description = Description;
		this.geo = Geo;
		this.role = Role;
		this.info = Info;
		this.more = More;
		this.getFieldFromMore();
		this.mark = Mark;
		this.correct();
		this.validate();
	}

	public Pawn(String Id) throws Exception {
		// origin - 11.01.2025, last edit - 19.11.2025
		this.clear();
		this.table = "Deal";
		this.src = this.id = Id;
		this.isExist();
		if (this.pawnId.isEmpty() == false) { // if new pawn by template
			this.getByTemplate();
		}
		this.validate();
	}

	public Pawn() throws Exception {
		// origin - 11.01.2025, last edit - 11.01.2025
		this.clear();
	}

	public String toString() {
		// origin - 11.01.2025, last edit - 19.11.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addAnyway(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(" id ", this.id);
			res = res + Fmtr.addIfNotEmpty(" parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(" face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(" face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(" face ", this.face);
			res = res + Fmtr.addIfNotEmpty(" date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(" date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(" code ", this.code);
			res = res + Fmtr.addIfNotEmpty(" description ", this.description);
			res = res + Fmtr.addIfNotEmpty(" ", this.geo);
			res = res + Fmtr.addIfNotEmpty(" ", this.role);
			res = res + Fmtr.addIfNotEmpty(" ", this.info);
			res = res + Fmtr.addIfNotEmpty(" more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(" defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(" ", this.mark);
			res = res + Fmtr.addIfNotEmpty(" pawnId ", this.pawnId);
			res = res + Fmtr.addIfNotEmpty(" templateId ", this.templateId);
			res = res + Fmtr.addIfNotEmpty(" termId ", this.termId);
			res = res + Fmtr.addIfNotEmpty(" VINCode ", this.VINCode);
			res = res + Fmtr.addIfNotEmpty(" IMEICode ", this.IMEICode);
			res = res + Fmtr.addIfNotEmpty(" carDoc ", this.carDoc);
			res = res + Fmtr.addIfNotEmpty(" carNumber ", this.carNumber);
			res = res + Fmtr.addIfNotEmpty(" color ", this.color);
			res = res + Fmtr.addIfNotEmpty(" producer ", this.producer);
			res = res + Fmtr.addIfNotEmpty(" dateMFG ", this.dateMFG);
			res = res + Fmtr.addIfNotEmpty(" productCondition ", this.productCondition);
			res = res + Fmtr.addIfNotEmpty(" assetCatId ", this.assetCatId);
			res = res + Fmtr.addIfNotEmpty(" gem ", this.gem);
			res = res + Fmtr.addIfNotEmpty(" descriptionPattern ", this.descriptionPattern.id);
			res = res + Fmtr.addIfNotEmpty(" assetDefectCatId ", this.assetDefectCatId.id);
			res = res + Fmtr.addIfNotZeroUnitVal(" weightGross ", this.weightGross);
			res = res + Fmtr.addIfNotZeroUnitVal(" weightNetto ", this.weightNetto);
			res = res + Fmtr.addIfNotZeroUnitVal(" goldContent ", this.goldContent);
			res = res + Fmtr.addIfNotZeroUnitVal(" weightCarat ", this.weightCarat);
			res = res + Fmtr.addIfNotZeroUnitVal(" estimatedValue ", this.estimatedValue);
			res = res + Fmtr.addIfNotZeroUnitVal(" partMainDebt ", this.partMainDebt);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	private void clear() throws Exception {
		// origin - 11.01.2025, last edit - 19.11.2025
		try {
			this.table = "Deal";
			this.src = this.id = this.parent = this.date1 = this.date2 = this.face1 = this.face2 = this.face = this.code = this.description = "";
			this.geo = this.role = this.info = this.more = this.mark = this.defect = "";
			this.fullName = this.comment = this.templateId = this.termId = this.pawnId = "";
			this.productCondition = this.assetCatId = this.gem = "";
			this.assetDefectCatId = this.descriptionPattern = new ListVal();
			this.IMEICode = "";
			this.VINCode = this.carDoc = this.carNumber = this.color = this.producer = this.dateMFG = "";
			this.weightGross = this.weightNetto = new UnitVal("0.0(Unit.Gr)");
			this.goldContent = new UnitVal("0.0(Unit.GoldContent)");
			this.weightCarat = new UnitVal("0.0(Unit.Carat)");
			this.estimatedValue = this.partMainDebt = new UnitVal(UnitVal.currCurrencyInit);
		} catch (Exception ex) {
			WB.addLog("Pawn.clear():void, ex=" + ex.getMessage(), "", "Pawn");
		}
	}

	public static void test() throws Exception {
		// origin - 24.09.2024, last edit - 08.10.2025
		try {

//			WB.addLog2("Pawn.test.getCurr(String, List<String>):List<Pawn>", "", "Pawn");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01" }) {
//				var tmp = Pawn.getCurr(tmp1, List.of("PawnDoc.Test1", "PawnDoc.Test2"));
//				WB.addLog2("Pawn.test.getCurr(String date1, List<String> parentIdList):List<Pawn>, res.size="
//						+ tmp.size() + ", date1=" + tmp1, "", "Pawn");
//				WB.log(tmp, "Pawn");
//			}

			{
				WB.addLog2("Pawn.test.getTotal(List<Pawn>):UnitVal", "", "Pawn");
				var tmp = Pawn.get();
				WB.addLog2("Pawn.test.getTotal(List<Pawn>):UnitVal>, res.size=" + tmp.size(), "", "Pawn");
				// WB.log(tmp, "Pawn");
				WB.addLog2("Pawn.test.getTotal(List<Pawn>):Pawn>, res=" + Pawn.getTotal(tmp), "", "Pawn");
			}

			WB.addLog2("Pawn.test.getPawnId():String", "", "Pawn");
			WB.addLog2("Pawn.test.getPawnId():String, res=" + Pawn.getPawnId(), "", "Pawn");

//			WB.addLog2("Pawn.test.set(Pawn):ModelDto", "", "Pawn");
//			for (var tmp1 : new String[] { "Pawn.Test1", "Pawn.Test2", "Pawn.Test3" }) {
//				var tmp2 = new Pawn(tmp1, "TestCode", "TestDescription");
//				var tmp3 = Pawn.set(tmp2);
//				WB.addLog2("Pawn.test.set(Pawn pawn):ModelDto, pawn=" + tmp2 + ", more=" + tmp2.more, "", "Pawn");
//				WB.addLog2("Pawn.test.set(Pawn pawn):ModelDto, res=" + tmp3, "", "Pawn");
//			}

//			WB.addLog2("Pawn.test.getCurr(List<Pawn>)", "", "Pawn");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01" }) {
//				var tmp = Pawn.getCurr(tmp1);
//				WB.addLog2("Pawn.test.getCurr(List<Pawn>), res.size=" + tmp.size() + ", date1=" + tmp1, "", "Pawn");
//				WB.log(tmp, "Pawn");
//			}

//			WB.addLog2("Pawn.test.getCurr(List<Pawn>)", "", "Pawn");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01" }) {
//				for (var tmp2 : new String[] { "PawnDoc.Test1" }) {
//					var tmp = Pawn.getCurr(tmp1, tmp2);
//					WB.addLog2("Pawn.test.getCurr(List<Pawn>), res.size=" + tmp.size() + ", date1=" + tmp1
//							+ ", parentId=" + tmp2, "", "Pawn");
//					WB.log(tmp, "Pawn");
//				}
//			}

//			WB.addLog2("Pawn.test.getByParent():List<Pawn>", "", "Pawn");
//			for (var tmp1 : new String[] { "", "PawnDoc.Test1", "PawnDoc.Tralala" }) {
//				var tmp = Pawn.get(tmp1);
//				WB.addLog2("Pawn.test.getByParent():List<Pawn>, res.size=" + tmp.size() + ", parentId=" + tmp1, "", "Pawn");
//				WB.log(tmp, "Pawn");
//			}

//			WB.addLog2("Pawn.test.get():List<Pawn>", "", "Pawn");
//			var tmp = Pawn.get();
//			WB.addLog2("Pawn.test.get():List<Pawn>, res.size=" + tmp.size() + ", filterless", "", "Pawn");
//			WB.log(tmp, "Pawn");

//			WB.addLog2("Pawn.getDescrByPattern(Pawn)", "", "Pawn");
//			for (var tmp : new String[] { "", "Pawn.Test1", "Pawn.Tralala" }) {
//				WB.addLog2("Pawn.getDescrByPattern(Pawn)=" + Pawn.getDescrByPattern(new Pawn(tmp)) + " id=" + tmp, "",
//						"Pawn");
//			}

			WB.addLog2("Pawn.test.ctor(String)", "", "Pawn");
			for (var tmp : new String[] { "PawnDoc.Template1.V1.Pawn", "Pawn.Test1", "Pawn.Test2", "Pawn.Test3",
					"Pawn.Tralala" }) {
				WB.addLog2("Pawn.test.ctor(String)=" + new Pawn(tmp), "", "Pawn");
			}

		} catch (Exception ex) {
			WB.addLog("Pawn.test():void, ex=" + ex.getMessage(), "", "Pawn");
		}
	}
}