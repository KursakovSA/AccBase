import java.util.ArrayList;
import java.util.List;

public class Pawn { // sectoralPawnshop
	// origin - 24.11.2024, last edit - 02.06.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, face1, face2, face, date1, date2, code, description, geo, role, info, more,
			mark;
	// special fields
	public String templateId, pawnId;
	public String productCondition, assetCatId, gem;
	public ListVal assetDefectCatId, descriptionPattern;
	public String VINCode, IMEICode, carDoc, carNumber, color, producer, dateMFG;
	public UnitVal weightGross, weightNetto, goldContent, weightCarat;
	public UnitVal estimatedValue, partMainDebt;
	public RangeVal weightLogicalLimit, countLogicalLimit, allowedPartialRansomIfCountActivePawn;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Pawn.static ctor, ex=" + ex.getMessage(), "", "Pawn");
		}
	}

	public static String getDescrByPattern(Pawn pawn) throws Exception {
		// origin - 31.05.2025, last edit - 02.06.2025
		String res = "";
		List<String> descrPattern = List.of("AssetCatId", "Gem", "GoldContent", " проба, ", " вес:", "WeightGross", "/",
				"WeightNetto", " гр. ", "AssetDefectCatCatId");
		if (pawn.descriptionPattern.val.size() != 0) {
			descrPattern = pawn.descriptionPattern.val;
			// WB.addLog2("Pawn.getDescrByPattern(Pawn pawn), descrPattern=" + descrPattern,
			// "", "Pawn");
		}
		try {
			for (var curr : descrPattern) {
				switch (curr) {
				case "AssetCatId" -> res = res + new AssetCat(pawn.assetCatId, Role.assetJewel).fullName;
				case "Gem" -> res = res + pawn.gem;
				case "AssetDefectCatCatId" -> res = res + pawn.assetDefectCatId.val;
				case "GoldContent" -> res = res + pawn.goldContent.partVal;
				case "WeightGross" -> res = res + pawn.weightGross.val;
				case "WeightNetto" -> res = res + pawn.weightNetto.val;
				default -> res = res + curr;
				}
				res = res + " ";
			}
		} catch (Exception ex) {
			WB.addLog("Pawn.getDescrByPattern, ex=" + ex.getMessage(), "", "Pawn");
		}
		return res;
	}

	public static List<Pawn> get(String parentId) throws Exception {// TODO
		// origin - 25.05.2025, last edit - 25.05.2025
		List<Pawn> res = new ArrayList<Pawn>();
		try {

		} catch (Exception ex) {
			WB.addLog("Pawn.get(List<Pawn>), ex=" + ex.getMessage(), "", "Pawn");
		}
		return res;
	}

	public static List<Pawn> get() throws Exception {// TODO
		// origin - 25.05.2025, last edit - 25.05.2025
		List<Pawn> res = new ArrayList<Pawn>();
		try {

		} catch (Exception ex) {
			WB.addLog("Pawn.get(List<Pawn>), ex=" + ex.getMessage(), "", "Pawn");
		}
		return res;
	}

	public static List<Pawn> getCurr(String date1, String parentId) throws Exception {// TODO
		// origin - 25.05.2025, last edit - 25.05.2025
		List<Pawn> res = new ArrayList<Pawn>();
		try {

		} catch (Exception ex) {
			WB.addLog("Pawn.getCurr(List<Pawn>), ex=" + ex.getMessage(), "", "Pawn");
		}
		return res;
	}

	public static List<Pawn> getCurr(String date1) throws Exception {// TODO
		// origin - 25.05.2025, last edit - 25.05.2025
		List<Pawn> res = new ArrayList<Pawn>();
		try {

		} catch (Exception ex) {
			WB.addLog("Pawn.getCurr(List<Pawn>), ex=" + ex.getMessage(), "", "Pawn");
		}
		return res;
	}

	public void getByTemplate() throws Exception {// TODO
		// origin - 19.05.2025, last edit - 20.05.2025
		try {
//			this.id = new IdGen("", "").id; // Asset.getId("", "");
//			this.pawnId = new IdGen("PawnId", "idStringGrowingDigitalInfobase").id; // TODO
//			this.date1 = DateTool.getNow().toString();
//			this.date2 = "";
//			this.code = "";
//			this.description = "";
//			this.more = this.getMoreFromField();
//			this.mark = Mark.DD;
		} catch (Exception ex) {
			WB.addLog2("Pawn.getByTemplate, ex=" + ex.getMessage(), "", "Pawn");
		}
	}

	@SuppressWarnings("unused")
	private String getMoreFromField() throws Exception {
		// origin - 19.05.2025, last edit - 05.06.2025
		String res = "";
		try {
			res = res + MoreVal.setPartMore("PawnId", this.pawnId);
			res = res + MoreVal.setPartMore("TemplateId", this.templateId);

			res = res + PawnCar.get(this);
			res = res + PawnCell.get(this);

			res = res + MoreVal.setPartMore("ProductCondition", this.productCondition);
			res = res + MoreVal.setPartMore("AssetCatId", this.assetCatId);
			res = res + MoreVal.setPartMore("Gem", this.gem);
			res = res + MoreVal.setPartMore("AssetDefectCatId", this.assetDefectCatId.id);
			res = res + MoreVal.setPartMore("DescriptionPattern", this.descriptionPattern.id);

			res = res + PawnGold.get(this);
			res = res + PawnSum.get(this);

			res = res + MoreVal.setPartMore("WeightLogicalLimit", this.weightLogicalLimit.src);
			res = res + MoreVal.setPartMore("CountLogicalLimit", this.countLogicalLimit.src);
			res = res + MoreVal.setPartMore("AllowedPartialRansomIfCountActivePawn",
					this.allowedPartialRansomIfCountActivePawn.src);
		} catch (Exception ex) {
			WB.addLog("Pawn.getMoreFromField, ex=" + ex.getMessage(), "", "Pawn");
		}
		// WB.addLog2("Pawn.getMoreFromField, res=" + res + ", this.code=" + this.code,
		// "", "Pawn");
		return res;
	}

	public void isExist() throws Exception {
		// origin - 11.01.2025, last edit - 05.06.2025
		try {
			List<ModelDto> listDto = new ArrayList<ModelDto>();

			// case template or test pawn
			if ((this.parent.isEmpty()) & (this.id.isEmpty() == false)) {
				listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdRoleFilter(this.id, Role.dealPawn), this.table);
			}

			// case exist pawnDoc\pawn
			if ((this.parent.isEmpty() == false) & (this.code.isEmpty() == false)) {
				listDto = DAL.getByTemplate(WB.lastConnWork,
						Qry.getParentCodeRoleFilter(this.parent, this.code, Role.dealPawn), this.table);
			}

			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.id = DefVal.setCustom(this.id, dto.id);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.parent = DefVal.setCustom(this.parent, dto.parent);
				this.face1 = DefVal.setCustom(this.face1, dto.face1);
				this.face2 = DefVal.setCustom(this.face2, dto.face2);
				this.face = DefVal.setCustom(this.face, dto.face);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.geo = DefVal.setCustom(this.geo, dto.geo);
				this.role = DefVal.setCustom(this.role, dto.role);
				this.info = DefVal.setCustom(this.info, dto.info);
				this.more = DefVal.setCustom(this.more, dto.more);

				this.isExist = true;
				this.getFieldFromMore();
			}
			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = "";
			}
		} catch (Exception ex) {
			WB.addLog("Pawn.isExist, ex=" + ex.getMessage(), "", "Pawn");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 19.05.2025, last edit - 02.06.2025
		try {
			this.pawnId = MoreVal.getFieldByKey(this.more, "PawnId");
			this.templateId = MoreVal.getFieldByKey(this.more, "TemplateId");

			var tmp1 = new PawnCar(MoreVal.getFieldByKey(this.more, "PawnCar"));
			this.VINCode = tmp1.VINCode;
			this.carDoc = tmp1.carDoc;
			this.carNumber = tmp1.carNumber;

			var tmp2 = new PawnCell(MoreVal.getFieldByKey(this.more, "PawnCell"));
			this.IMEICode = tmp2.IMEICode;

			this.color = DefVal.set(tmp1.color, tmp2.color);
			this.producer = DefVal.set(tmp1.producer, tmp2.producer);
			this.dateMFG = DefVal.set(tmp1.dateMFG, tmp2.dateMFG);

			this.productCondition = MoreVal.getFieldByKey(this.more, "ProductCondition");
			this.assetCatId = MoreVal.getFieldByKey(this.more, "AssetCatId");
			this.gem = MoreVal.getFieldByKey(this.more, "Gem");
			this.descriptionPattern = new ListVal(MoreVal.getFieldByKey(this.more, "DescriptionPattern"), "");
			this.assetDefectCatId = new ListVal(MoreVal.getFieldByKey(this.more, "AssetDefectCatId"), "");

			var tmp3 = new PawnGold(MoreVal.getFieldByKey(this.more, "PawnGold"));
			this.weightGross = tmp3.weightGross;
			this.weightNetto = tmp3.weightNetto;
			this.goldContent = tmp3.goldContent;
			this.weightCarat = tmp3.weightCarat;

			var tmp4 = new PawnSum(MoreVal.getFieldByKey(this.more, "PawnSum"));
			this.estimatedValue = tmp4.estimatedValue;
			this.partMainDebt = tmp4.partMainDebt;

			this.weightLogicalLimit = new RangeVal(MoreVal.getFieldByKey(this.more, "WeightLogicalLimit"));
			this.countLogicalLimit = new RangeVal(MoreVal.getFieldByKey(this.more, "CountLogicalLimit"));
			this.allowedPartialRansomIfCountActivePawn = new RangeVal(
					MoreVal.getFieldByKey(this.more, "AllowedPartialRansomIfCountActivePawn"));
		} catch (Exception ex) {
			WB.addLog("Pawn.getFieldFromMore, ex=" + ex.getMessage(), "", "Pawn");
		}
	}

	// get new pawn by DealDto without isExist
	public Pawn(DealDto dDto) throws Exception {
		// origin - 23.05.2025, last edit - 25.05.2025
		this.clear();
		this.src = this.id = dDto.id;
		this.parent = dDto.parent;
		this.face1 = dDto.face1;
		this.face2 = dDto.face2;
		this.face = dDto.face;
		this.date1 = dDto.date1;
		this.date2 = dDto.date2;
		this.code = dDto.code;
		this.description = dDto.description;
		this.geo = dDto.geo;
		this.role = dDto.role;
		this.info = dDto.info;
		this.more = dDto.more;
		this.getFieldFromMore();
		this.mark = dDto.mark;

		var tmp1 = new PawnGold(dDto.goldPat); // usually pawn = gold
		this.weightGross = tmp1.weightGross;
		this.weightNetto = tmp1.weightNetto;
		this.goldContent = tmp1.goldContent;
		this.weightCarat = tmp1.weightCarat;

		var tmp2 = new PawnCar(dDto.carPat); // sometimes car
		this.carDoc = tmp2.carDoc;
		this.carNumber = tmp2.carNumber;
		this.color = tmp2.color;
		this.producer = tmp2.producer;
		this.VINCode = tmp2.VINCode;
		this.dateMFG = tmp2.dateMFG;

		var tmp3 = new PawnCell(dDto.cellPat); // rarely cell phone
		this.color = DefVal.set(tmp2.color, tmp3.color);// tmp3.color;
		this.producer = DefVal.set(tmp2.producer, tmp3.producer);// tmp3.producer;
		this.IMEICode = tmp3.IMEICode;
		this.dateMFG = DefVal.set(tmp2.dateMFG, tmp3.dateMFG);// tmp3.dateMFG;
	}

	// get new pawn by template
	public Pawn(String templateId, String Code, String Description) throws Exception {
		// origin - 22.05.2025, last edit - 05.06.2025
		this(templateId);

		if (this.id.isEmpty() == false) {
			this.id = new IdGen("", "").id;
			this.date1 = DateTool.getNow().toString();
			this.date2 = "";
			this.code = Code;
			this.description = Description;
			// this.more = this.getMoreFromField();
			this.mark = Mark.DD;
		}
	}

	// read Pawn by ParentId if is exist
	public Pawn(String ParentId, String Code) throws Exception {
		// origin - 25.05.2025, last edit - 25.05.2025
		this.clear();
		this.table = "Deal";
		this.src = ParentId + "," + Code;
		this.parent = ParentId;
		this.code = Code;
		this.isExist();
	}

	// read Pawn if is exist
	public Pawn(String Id) throws Exception {
		// origin - 11.01.2025, last edit - 23.05.2025
		this.clear();
		this.table = "Deal";
		this.src = this.id = Id;
		this.isExist();
	}

	public Pawn() throws Exception {
		// origin - 11.01.2025, last edit - 11.01.2025
		this.clear();
	}

	public String toString() {
		// origin - 11.01.2025, last edit - 05.06.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addAnyway(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(" id ", this.id);
			res = res + Fmtr.addIfNotEmpty(" parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(" face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(" face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(" face ", this.face);
			res = res + Fmtr.addIfNotEmpty(" date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(" date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(" code ", this.code);
			res = res + Fmtr.addIfNotEmpty(" description ", this.description);
			res = res + Fmtr.addIfNotEmpty(" ", this.geo);
			res = res + Fmtr.addIfNotEmpty(" ", this.role);
			res = res + Fmtr.addIfNotEmpty(" ", this.info);
			res = res + Fmtr.addIfNotEmpty(" more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(" ", this.mark);

			res = res + Fmtr.addIfNotEmpty(" pawnId ", this.pawnId);
			res = res + Fmtr.addIfNotEmpty(" templateId ", this.templateId);
			res = res + Fmtr.addIfNotEmpty(" VINCode ", this.VINCode);
			res = res + Fmtr.addIfNotEmpty(" IMEICode ", this.IMEICode);
			res = res + Fmtr.addIfNotEmpty(" carDoc ", this.carDoc);
			res = res + Fmtr.addIfNotEmpty(" carNumber ", this.carNumber);
			res = res + Fmtr.addIfNotEmpty(" color ", this.color);
			res = res + Fmtr.addIfNotEmpty(" producer ", this.producer);
			res = res + Fmtr.addIfNotEmpty(" dateMFG ", this.dateMFG);

			res = res + Fmtr.addIfNotEmpty(" productCondition ", this.productCondition);
			res = res + Fmtr.addIfNotEmpty(" assetCatId ", this.assetCatId);
			res = res + Fmtr.addIfNotEmpty(" gem ", this.gem);
			res = res + Fmtr.addIfNotEmpty(" descriptionPattern ", this.descriptionPattern.id);
			res = res + Fmtr.addIfNotEmpty(" assetDefectCatId ", this.assetDefectCatId.id);

			res = res + Fmtr.addIfNotEmpty(" weightGross ", this.weightGross.id);
			res = res + Fmtr.addIfNotEmpty(" weightNetto ", this.weightNetto.id);
			res = res + Fmtr.addIfNotEmpty(" goldContent ", this.goldContent.id);
			res = res + Fmtr.addIfNotEmpty(" weightCarat ", this.weightCarat.id);

			res = res + Fmtr.addIfNotEmpty(" estimatedValue ", this.estimatedValue.id);
			res = res + Fmtr.addIfNotEmpty(" partMainDebt ", this.partMainDebt.id);

			res = res + Fmtr.addIfNotEmpty(" weightLogicalLimit ", this.weightLogicalLimit.id);
			res = res + Fmtr.addIfNotEmpty(" countLogicalLimit ", this.countLogicalLimit.id);
			res = res + Fmtr.addIfNotEmpty(" allowedPartialRansomIfCountActivePawn ",
					this.allowedPartialRansomIfCountActivePawn.id);

			res = res + Fmtr.addIfNotEmpty(" isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(" isValid ", this.isValid);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public void clear() throws Exception {
		// origin - 11.01.2025, last edit - 01.06.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = "Deal";
			this.src = this.id = this.parent = this.date1 = this.date2 = this.face1 = this.face2 = this.face = this.code = this.description = "";
			this.geo = this.role = this.info = this.more = this.mark = "";

			this.templateId = "";
			this.pawnId = "";
			this.productCondition = this.assetCatId = this.gem = "";
			this.assetDefectCatId = this.descriptionPattern = new ListVal();
			this.IMEICode = "";
			this.VINCode = this.carDoc = this.carNumber = this.color = this.producer = this.dateMFG = "";
			this.weightGross = this.weightNetto = this.goldContent = this.weightCarat = new UnitVal();
			this.estimatedValue = this.partMainDebt = new UnitVal();
			this.weightLogicalLimit = this.countLogicalLimit = this.allowedPartialRansomIfCountActivePawn = new RangeVal();

		} catch (Exception ex) {
			WB.addLog("Pawn.clear, ex=" + ex.getMessage(), "", "Pawn");
		}
	}

	public static void test() throws Exception {
		// origin - 24.09.2024, last edit - 05.06.2025
		try {

//			// test getDescrByPattern(Pawn)
//			WB.addLog2("Pawn.getDescrByPattern(Pawn)", "", "Pawn");
//			for (var tmp : new String[] { "", "Pawn.Test1", "Pawn.Tralala" }) {
//				WB.addLog2("Pawn.getDescrByPattern(Pawn)=" + Pawn.getDescrByPattern(new Pawn(tmp)) + " id=" + tmp, "",
//						"Pawn");
//			}

//			// test ctor(DealDto) //TODO
//			WB.addLog2("Pawn.test.ctor(DealDto)", "", "Pawn");
//			for (var tmp1 : new String[] { "", "PawnDoc.Test1", "PawnDoc.Tralala" }) {
//				for (var tmp2 : new String[] { "", "Pawn.Test1", "Pawn.Test2" }) {
//					WB.addLog2("Pawn.test.ctor(DealDto)=" + new Pawn(tmp1, tmp2), "", "Pawn");
//				}
//			}

			// test ctor(3String)
			WB.addLog2("Pawn.test.ctor(3String)", "", "Pawn");
			for (var tmp1 : new String[] { "", "PawnDoc.Template1.V1.Pawn", "PawnDoc.Tralala.Pawn" }) {
				WB.addLog2("Pawn.test.ctor(3String)=" + new Pawn(tmp1, "New Code", "New Description"), "", "Pawn");
			}

//			// test ctor(2String)
//			WB.addLog2("Pawn.test.ctor(2String)", "", "Pawn");
//			for (var tmp1 : new String[] { "", "PawnDoc.Test1", "PawnDoc.Tralala" }) {
//				for (var tmp2 : new String[] { "", "Pawn.Test1", "Pawn.Test2" }) {
//					WB.addLog2("Pawn.test.ctor(2String)=" + new Pawn(tmp1, tmp2), "", "Pawn");
//				}
//			}

//			// test ctor(String)
//			WB.addLog2("Pawn.test.ctor(String)", "", "Pawn");
//			for (var tmp : new String[] { "", "Pawn.Test1", "Pawn.Test2", "Pawn.Test3", "Pawn.Tralala" }) {
//				WB.addLog2("Pawn.test.ctor(String)=" + new Pawn(tmp), "", "Pawn");
//			}

		} catch (Exception ex) {
			WB.addLog("Pawn.test, ex=" + ex.getMessage(), "", "Pawn");
		}
	}
}