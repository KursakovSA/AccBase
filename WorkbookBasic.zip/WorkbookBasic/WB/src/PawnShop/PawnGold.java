//Pawn pattern
public final class PawnGold { // sectoralPawnshop
	// origin - 21.05.2025, last edit - 21.12.2025
	public String src, src1, src2, src3, src4;
	public UnitVal weightGross, weightNetto, goldContent, weightCarat;
	public static String unitWeight, unitGoldContent, unitCarat;

	static {
		try {
			PawnGold.unitWeight = Unit.strGr;
			PawnGold.unitGoldContent = "Unit.GoldContent";
			PawnGold.unitCarat = "Unit.Carat";
		} catch (Exception ex) {
			WB.addLog("PawnGold.static ctor, ex=" + ex.getMessage(), "", "PawnGold");
		}
	}

	private void getSrc() throws Exception {
		// origin - 21.05.2025, last edit - 14.06.2025
		try {
			if (this.src.length() != 0) {
				String tmp = Etc.fixTrim(this.src); // "weightGross weightNetto goldContent weightCarat"

				int posSpace1 = tmp.indexOf(" ");
				if (posSpace1 > 0) {
					this.src1 = Etc.fixTrim(tmp.substring(0, posSpace1)); // "weightGross"
					tmp = Etc.fixTrim(tmp.substring(posSpace1)); // "weightNetto goldContent weightCarat"

					int posSpace2 = tmp.indexOf(" ");
					if (posSpace2 > 0) {
						this.src2 = Etc.fixTrim(tmp.substring(0, posSpace2)); // "weightNetto"
						tmp = Etc.fixTrim(tmp.substring(posSpace2)); // "goldContent weightCarat"
					}

					int posSpace3 = tmp.indexOf(" ");
					if (posSpace3 > 0) {
						this.src3 = Etc.fixTrim(tmp.substring(0, posSpace3)); // "goldContent"
						tmp = Etc.fixTrim(tmp.substring(posSpace3)); // "weightCarat"
					} else {
						this.src3 = Etc.fixTrim(tmp); // "goldContent"
						tmp = ""; // "weightCarat"
					}

					if (tmp.length() != 0) {
						this.src4 = Etc.fixTrim(tmp); // "weightCarat"
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("PawnGold.getSrc():void, ex=" + ex.getMessage(), "", "PawnGold");
		}
	}

	private void getPart() throws Exception {
		// origin - 21.05.2025, last edit - 14.06.2025
		try {
			this.weightGross = new UnitVal(this.src1, PawnGold.unitWeight);
			this.weightNetto = new UnitVal(this.src2, PawnGold.unitWeight);
			this.goldContent = new UnitVal(this.src3, PawnGold.unitGoldContent);
			if (this.src4.isEmpty() == false) {
				this.weightCarat = new UnitVal(this.src4, PawnGold.unitCarat);
			}
		} catch (Exception ex) {
			WB.addLog("PawnGold.getPart():void, ex=" + ex.getMessage(), "", "PawnGold");
		}
	}

	public PawnGold(String Src) throws Exception {
		// origin - 21.05.2025, last edit - 25.05.2025
		this.clear();
		this.src = Etc.fixTrim(Src); // weightGross weightNetto goldContent weightCarat
		this.getSrc();
		this.getPart();
	}

	public PawnGold() throws Exception {
		// origin - 21.05.2025, last edit - 25.05.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 21.05.2025, last edit - 06.09.2025
		try {
			this.src = this.src1 = this.src2 = this.src3 = this.src4 = "";
			this.weightGross = this.weightNetto = new UnitVal("0.0(Unit.Gr)");
			this.goldContent = new UnitVal("0.0(Unit.GoldContent)");
			this.weightCarat = new UnitVal("0.0(Unit.Carat)");
		} catch (Exception ex) {
			WB.addLog("PawnGold.clear():void, ex=" + ex.getMessage(), "", "PawnGold");
		}
	}

	public String toString() {
		// origin - 21.05.2025, last edit - 25.05.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway(" src ", this.src);
			res = res + Fmtr.addIfNotEmpty(" src1 ", this.src1);
			res = res + Fmtr.addIfNotEmpty(" src2 ", this.src2);
			res = res + Fmtr.addIfNotEmpty(" src3 ", this.src3);
			res = res + Fmtr.addIfNotEmpty(" src4 ", this.src4);

			res = res + Fmtr.addIfNotEmpty(" weightGross ", this.weightGross.id);
			res = res + Fmtr.addIfNotEmpty(" weightNetto ", this.weightNetto.id);
			res = res + Fmtr.addIfNotEmpty(" ", this.goldContent.id);
			res = res + Fmtr.addIfNotEmpty(" weightCarat ", this.weightCarat.id);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 21.05.2025, last edit - 24.12.2025
		try {

//			WB.addLog2("PawnGold.test.ctor(String)", "", "PawnGold");
//			for (var tmp1 : new String[] { "6.8 5.4 585", "8 7 383", "9 8 383 1", "9,3 8,5 383 15,00" }) {
//				WB.addLog2("PawnGold.test.ctor(String)=" + new PawnGold(tmp1), "", "PawnGold");
//			}

		} catch (Exception ex) {
			WB.addLog("PawnGold.test():void, ex=" + ex.getMessage(), "", "PawnGold");
		}
	}
}