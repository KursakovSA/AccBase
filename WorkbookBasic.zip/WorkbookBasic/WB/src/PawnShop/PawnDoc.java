import java.util.ArrayList;
import java.util.List;

public class PawnDoc extends Deal { // sectoralPawnshop //TODO
	// origin - 28.09.2024, last edit - 01.05.2025
	public static String strTemplate, strPawnDoc;
	public String pawnDocId, context, termId, totalEstimatedValue;
	public RangeVal mainDebtLogicalLimit;

	// public Accrual accrual = new Accrual();
	public Term term = new Term();
	public List<Pawn> pawn = new ArrayList<Pawn>();

	public UnitVal totalAccrualInterest = new UnitVal("0.0(Unit.KZT)");
	public UnitVal totalAccrualPenalty = new UnitVal("0.0(Unit.KZT)");

	public UnitVal mainDebt = new UnitVal("0.0(Unit.KZT)");
	public UnitVal restMainDebt = new UnitVal("0.0(Unit.KZT)");

	static {
		PawnDoc.strTemplate = "Template";
		PawnDoc.strPawnDoc = "PawnDoc";
		try {
		} catch (Exception ex) {
			WB.addLog("PawnDoc.static ctor, ex=" + ex.getMessage(), "", "PawnDoc");
		}
	}

	public PawnDoc(String Id) throws Exception {
		// origin - 12.01.2025, last edit - 04.05.2025
		this.clear();
		this.table = "Deal";
		this.id = Id;

		this.context = PawnDoc.strPawnDoc; // default
		if (Etc.strContains(Id, PawnDoc.strTemplate)) { // pawndoc pawndoc
			this.context = PawnDoc.strTemplate;
		}

		this.isExist();
	}

	public PawnDoc() throws Exception {
		// origin - 12.01.2025, last edit - 12.01.2025
		this.clear();
	}

	public String toString() {
		// origin - 12.01.2025, last edit - 20.03.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			// res = res + Fmtr.addIfNotEmpty(", pawnId ", this.pawnId);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.09.2024, last edit - 14.06.2025
		try {

		} catch (Exception ex) {
			WB.addLog("PawnDoc.test():void, ex=" + ex.getMessage(), "", "PawnDoc");
		}
	}
}