import java.util.ArrayList;
import java.util.List;

public class PawnDoc { // sectoralPawnshop //TODO
	// origin - 28.09.2024, last edit - 03.09.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, face1, face2, face, code, description, geo, role, info, more, mark;
	// special fields
	public String fullName, comment, templateId, termId, pawnDocId, pawnDocCatId;
	public ListVal date1, date2, templateDoc;

	public PawnDocTerm term; // ?? init ??

	public List<Pawn> pawn;
	public List<Prolongation> prolongation;
	public UnitVal totalAccrualInterest, totalAccrualPenalty, mainDebt, restMainDebt; // TODO -- all total... do as
																						// getTotal... ????
	public List<ModelDto> lower, upper;
	
	static {
		try {
		} catch (Exception ex) {
			WB.addLog("PawnDoc.static ctor, ex=" + ex.getMessage(), "", "PawnDoc");
		}
	}
	
	public static Pawn getTotal(PawnDoc pawnDoc) throws Exception { //TODO
		// origin - 08.09.2025, last edit - 08.09.2025
		Pawn res = new Pawn();
		try {
//			for (var currPawn : listPawn) {
//				// WB.addLog2("Pawn.getTotal(List<Pawn>):Pawn, currPawn=" + currPawn,"",
//				// "Pawn");
//				res.weightGross = UnitVal.add(res.weightGross, currPawn.weightGross);
//				res.weightNetto = UnitVal.add(res.weightNetto, currPawn.weightNetto);
//				res.weightCarat = UnitVal.add(res.weightCarat, currPawn.weightCarat);
//				res.estimatedValue = UnitVal.add(res.estimatedValue, currPawn.estimatedValue);
//				res.partMainDebt = UnitVal.add(res.partMainDebt, currPawn.partMainDebt);
//			}
		} catch (Exception ex) {
			WB.addLog("PawnDoc.getTotal(PawnDoc):Pawn, ex=" + ex.getMessage(), "", "PawnDoc");
		}
		return res;
	}
	
	public static Pawn getRest(PawnDoc pawnDoc) throws Exception { //TODO
		// origin - 08.09.2025, last edit - 08.09.2025
		Pawn res = new Pawn();
		try {
//			for (var currPawn : listPawn) {
//				// WB.addLog2("Pawn.getTotal(List<Pawn>):Pawn, currPawn=" + currPawn,"",
//				// "Pawn");
//				res.weightGross = UnitVal.add(res.weightGross, currPawn.weightGross);
//				res.weightNetto = UnitVal.add(res.weightNetto, currPawn.weightNetto);
//				res.weightCarat = UnitVal.add(res.weightCarat, currPawn.weightCarat);
//				res.estimatedValue = UnitVal.add(res.estimatedValue, currPawn.estimatedValue);
//				res.partMainDebt = UnitVal.add(res.partMainDebt, currPawn.partMainDebt);
//			}
		} catch (Exception ex) {
			WB.addLog("PawnDoc.getRest(PawnDoc):Pawn, ex=" + ex.getMessage(), "", "PawnDoc");
		}
		return res;
	}

	private void getPart() throws Exception {
		// origin - 02.09.2025, last edit - 02.09.2025
		try {
			if (this.id.isEmpty() == false) {
				this.pawn = Pawn.getByParent(this.id);
				this.prolongation = Prolongation.getByParent(this.id);
			}
		} catch (Exception ex) {
			WB.addLog("PawnDoc.getPart():void, ex=" + ex.getMessage(), "", "PawnDoc");
		}
	}

	public static List<PawnDoc> getPool(String pawnDocId) throws Exception { // TODO
		// origin - 31.08.2025, last edit - 31.08.2025
		List<PawnDoc> res = new ArrayList<PawnDoc>();
		try {

		} catch (Exception ex) {
			WB.addLog("PawnDoc.getPool(String):List<PawnDoc>, ex=" + ex.getMessage(), "", "PawnDoc");
		}
		return res;
	}

	public static List<DealDto> getByPawnDocCat(String pawnDocCatId) throws Exception {
		// origin - 14.08.2025, last edit - 14.08.2025
		List<DealDto> res = new ArrayList<DealDto>();
		try {
			var listModelDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getMoreFilter(MoreVal.setPartMore("PawnDocCatId", pawnDocCatId)), "Deal");
			if (listModelDto.size() != 0) {
				res = DealDto.get(listModelDto);
			}
		} catch (Exception ex) {
			WB.addLog("PawnDoc.getByPawnDocCat(String):List<DealDto>, ex=" + ex.getMessage(), "", "PawnDoc");
		}
		return res;
	}

	public static List<DealDto> getCurr(String date1) throws Exception {
		// origin - 14.08.2025, last edit - 14.08.2025
		List<DealDto> res = new ArrayList<DealDto>();
		try {
			var listDealDto = PawnDoc.get();
			res = DealDto.getChrono(DateTool.getLocalDate(date1), listDealDto);
		} catch (Exception ex) {
			WB.addLog("PawnDoc.getCurr(String):List<DealDto>, ex=" + ex.getMessage(), "", "PawnDoc");
		}
		return res;
	}

	public static List<DealDto> get() throws Exception { // full list pawnDoc as list DealDto
		// origin - 14.08.2025, last edit - 15.09.2025
		List<DealDto> res = new ArrayList<DealDto>();
		try {
			var pawnDocList = DAL.getByTemplate(WB.lastConnWork,
					Qry.getRoleInfoFilter("Role.Deal.PawnDoc", "Info.Deal.PawnLoan"), "Deal");
			if (pawnDocList.size() != 0) {
				res = DealDto.get(pawnDocList);
			}
		} catch (Exception ex) {
			WB.addLog("PawnDoc.get():List<DealDto>, ex=" + ex.getMessage(), "", "PawnDoc");
		}
		return res;
	}

	private void getByTemplate() throws Exception { // TODO
		// origin - 14.08.2025, last edit - 15.09.2025
		try {
			this.id = new IdGen("", "").id;
			this.code = "";
			this.description = "";
			this.more = this.getMoreFromField();
			this.mark = "Mark.DD";

			this.pawnDocId = new IdGen("PawnDoclId", "idIntegerGrowingDigitalGlobal").id; // ?? tuner frm local ??
			this.pawn.clear();
			this.prolongation.clear();
		} catch (Exception ex) {
			WB.addLog2("PawnDoc.getByTemplate():void, ex=" + ex.getMessage(), "", "PawnDoc");
		}
	}

//	private LocalDate getStartDate() throws Exception {// TODO
//		// origin - 13.08.2025, last edit - 08.09.2025
//		LocalDate res = DateTool.getNow();
//		try {
//
//		} catch (Exception ex) {
//			WB.addLog("PawnDoc.getStartDate():LocalDate, ex=" + ex.getMessage(), "", "PawnDoc");
//		}
//		return res;
//	}

//	private LocalDate getEndDate() throws Exception {// TODO
//		// origin - 13.08.2025, last edit - 08.09.2025
//		LocalDate res = DateTool.getNow();
//		try {
//
//		} catch (Exception ex) {
//			WB.addLog("PawnDoc.getEndDate():LocalDate, ex=" + ex.getMessage(), "", "PawnDoc");
//		}
//		return res;
//	}

//	@SuppressWarnings("unused")
//	private boolean isExpire(String testDate) throws Exception {
//		// origin - 05.12.2024, last edit - 08.09.2025
//		boolean res = false;
//		try {
//			var testLocalDate = DateTool.getLocalDate(testDate);
//			if (this.getEndDate().isEqual(testLocalDate)) {
//				res = true;
//			}
//		} catch (Exception ex) {
//			WB.addLog("PawnDoc.isExpire():boolean, ex=" + ex.getMessage(), "", "PawnDoc");
//		}
//		return res;
//	}

//	@SuppressWarnings("unused")
//	private boolean isExpired() throws Exception {// is expired already
//		// origin - 05.12.2024, last edit - 08.09.2025
//		boolean res = false;
//		try {
//			if (this.getEndDate().isBefore(DateTool.getNow())) {
//				res = true;
//			}
//		} catch (Exception ex) {
//			WB.addLog("PawnDoc.isExpired():boolean, ex=" + ex.getMessage(), "", "PawnDoc");
//		}
//		return res;
//	}

//	@SuppressWarnings("unused")
//	private UnitVal getDuration() throws Exception {// TODO
//		// origin - 18.09.2024, last edit - 08.09.2025
//		UnitVal res = new UnitVal();
//		try {
//			var res1 = (double) ChronoUnit.DAYS.between(this.getStartDate(), this.getEndDate());
//			var res2 = this.term.durationDealLimit.partUnit;
//			res = new UnitVal(Etc.fixTrim(Etc.fixString(res1)), res2);
//		} catch (Exception ex) {
//			WB.addLog("PawnDoc.getDuration():void, ex=" + ex.getMessage(), "", "PawnDoc");
//		}
//		return res;
//	}

	@SuppressWarnings("unused")
	private boolean isOutsideDuration() throws Exception {// TODO
		// origin - 12.09.2024, last edit - 13.06.2025
		boolean res = false;
		try {
//			if ((this.term.durationDealMaxLimit.val != 0.0) && (this.duration.val != 0.0)
//					&& (this.duration.val != this.term.durationDealMaxLimit.val)) {
//				res = true;
//			}
		} catch (Exception ex) {
			WB.addLog("PawnDoc.isOutsideDuration():boolean, ex=" + ex.getMessage(), "", "PawnDoc");
		}
		return res;
	}

	@SuppressWarnings("unused")
	private void correctByDefault() throws Exception {// TODO
		// origin - 12.09.2024, last edit - 13.08.2025
		try {
		} catch (Exception ex) {
			WB.addLog("PawnDoc.correctByDefault():void, ex=" + ex.getMessage(), "", "PawnDoc");
		}
	}

//	private boolean isOutsideDefault() throws Exception {// TODO
//	// origin - 12.09.2024, last edit - 20.03.2025
//	boolean res = false;
//	try {
//	} catch (Exception ex) {
//		WB.addLog("Deal.isOutsideDefault, ex=" + ex.getMessage(), "", "Deal");
//	}
//	return res;
//}

//private void correctByDuration() throws Exception {
//	// origin - 10.09.2024, last edit - 13.06.2025
//	try {
//		if (this.isOutsideDuration()) {
////					WB.addLog2("Deal.correctEndDateByDuration, before correct this.Date2=" + this.Date2,"", "Deal");
////					this.Date2.removeLast();
////					this.Date2.add(DateTool.getEndDateFromDuration(this.startDate, this.durationCreditMaxLimit)); // this
////																													// is
////																													// res
////					WB.addLog2("Deal.correctByDuration, after correct this.Date2=" + this.Date2, "","Deal");
////					this.endDate = this.Date2.getLast(); // this is res
////					this.duration = DateTool.getDuration(this.endDate, this.startDate); // this is res
//
////					WB.addLog2("Deal.correctEndDateByDuration, before correct this.date2=" + this.date2,"", "Deal");
//
//			this.date2.removeLast();// ?? if find what last = enddate ??
//
////			this.date2
////					.add(DateTool.getEndDateFromDuration(this.startDate, (int) this.term.durationDealMaxLimit.val)); // this
//			// is
//			// res
////					WB.addLog2("Deal.correctByDuration, after correct this.date2=" + this.date2, "","Deal");
//			this.endDate = this.date2.getLast(); // this is res
//			this.getDuration(); // this is res
//		}
//		// }
//		// }
//	} catch (Exception ex) {
//		WB.addLog("Deal.correctByDuration():void, ex=" + ex.getMessage(), "", "Deal");
//	}
//}

//public void getTemplate() throws Exception {
//	// origin - 07.09.2024, last edit - 19.05.2025
//	try {
//		// WB.addLog2("Deal.getTemplate, after run, this.src.code=" +
//		// this.src.code,"","Deal");
//		var tmp1 = ReadSet.getEqualsByCode(WB.abcLast.template, this.src.code);
//		if (tmp1.size() != 0) {
//			this.src = tmp1.getFirst();
//			this.template.add(this.src); // add root template
//			var currCodeParent = this.src.code;
//
//			// unwind template tree
//			while (currCodeParent.isEmpty() == false) {
//				var template = ReadSet.getEqualsByParent(WB.abcLast.template, currCodeParent); // ??
//				currCodeParent = "";
//				for (var currTemplate : template) {
//					this.template.add(currTemplate);
//					// WB.addLog2("Deal.getTemplate, this.template.add(currTemplate)="+currTemplate,
//					// "","Deal");
//					currCodeParent = currTemplate.code;
//				}
//			}
//		}
//	} catch (Exception ex) {
//		WB.addLog("Deal.getTemplate, ex=" + ex.getMessage(), "", "Deal");
//	}
//}

//private void getDate() throws Exception {
//	// origin - 08.09.2024, last edit - 13.06.2025
//	try {
//		var lst1 = Fmtr.listVal(this.src.date1, ";");
//		this.date1 = Fmtr.listStr(lst1); // this is res
//		this.startDate = this.date1.getFirst(); // this is res
//
//		if (this.startDate == null) {
//			this.startDate = DateTool.getNow();
//		}
//
//		var lst2 = Fmtr.listVal(this.src.date2, ";");
//		this.date2 = Fmtr.listStr(lst2); // this is res
//		this.endDate = this.date2.getLast(); // this is res
//
//		if (this.endDate == null) {
//			this.endDate = DateTool.getNow();
//		}
//
//		this.getDuration(); // this is res
//		this.correctByDuration(); // ?? take outside ??
//
//		if (this.endDate != null) {
//			if (this.endDate.isBefore(DateTool.getNow())) {
//				// this.isExpired = true;
//			}
//		}
//	} catch (Exception ex) {
//		WB.addLog("Deal.getDate():void, ex=" + ex.getMessage(), "", "Deal");
//	}
//}

	private void isExist() throws Exception {
		// origin - 10.08.2025, last edit - 14.09.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), "Deal");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.id = dto.id;
				this.parent = DefVal.setCustom(this.parent, dto.parent);

				var tmp = new SpanDate(dto.date1, dto.date2);
				this.date1 = new ListVal(tmp.date1);
				this.date2 = new ListVal(tmp.date2);

				this.code = DefVal.setCustom(this.code, dto.code);
				this.code = DefVal.setCustom(this.code, dto.id);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.geo = DefVal.setCustom(this.geo, dto.geo);
				this.role = DefVal.setCustom(this.role, dto.role);
				this.info = DefVal.setCustom(this.info, dto.info);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.mark = DefVal.setCustom(this.mark, dto.mark);

				var listDto2 = DAL.getTable(WB.lastConnWork, Qry.getText(WB.lastConnWork, "Deal", ""));
				this.upper = ModelDto.getUpper(listDto2, this.parent);
				this.lower = ModelDto.getLower(listDto2, this.code);
				this.getFieldFromMore();
				this.isExist = true;
			}
			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("PawnDoc.isExist():void, ex=" + ex.getMessage(), "", "PawnDoc");
		}
	}

	private String getMoreFromField() throws Exception { // TODO
		// origin - 14.08.2025, last edit - 03.09.2025
		String res = "";
		try {
			res = res + MoreVal.setPartMore("FullName", this.fullName);
			res = res + MoreVal.setPartMore("Comment", this.comment);
			res = res + MoreVal.setPartMore("TemplateId", this.templateId);
			res = res + MoreVal.setPartMore("TermId", this.termId);
		} catch (Exception ex) {
			WB.addLog("PawnDoc.getMoreFromField():String, ex=" + ex.getMessage(), "", "PawnDoc");
		}
		return res;
	}

	private void getFieldFromMore() throws Exception { // TODO
		// origin - 13.08.2025, last edit - 03.09.2025
		try {
			this.templateId = MoreVal.getFieldByKey(this.more, "TemplateId");
			this.termId = MoreVal.getFieldByKey(this.more, "TermId");
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.templateDoc = new ListVal(MoreVal.getFieldByKey(this.more, "TemplateDoc"), "");
		} catch (Exception ex) {
			WB.addLog("PawnDoc.getFieldFromMore():void, ex=" + ex.getMessage(), "", "PawnDoc");
		}
	}

	public PawnDoc(String Id) throws Exception {// TODO
		// origin - 12.01.2025, last edit - 14.08.2025
		this.clear();
		this.src = this.id = Id;
		this.isExist();
		this.getPart();
		if (this.templateId.isEmpty() == false) {
			this.getByTemplate();
		}
	}

	public PawnDoc() throws Exception {
		// origin - 12.01.2025, last edit - 12.01.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 10.08.2025, last edit - 06.09.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = "Deal";
			this.src = this.id = this.parent = this.face1 = this.face2 = this.face = this.code = this.description = this.geo = this.role = this.info = this.more = this.mark = "";
			this.fullName = this.comment = this.templateId = this.termId = this.pawnDocId = this.pawnDocCatId = "";
			this.date1 = this.date2 = new ListVal();
			this.totalAccrualInterest = this.totalAccrualPenalty = this.mainDebt = this.restMainDebt = new UnitVal(
					UnitVal.currCurrencyInit);
			this.pawn = new ArrayList<Pawn>();
			this.prolongation = new ArrayList<Prolongation>();
			this.term = new PawnDocTerm();
		} catch (Exception ex) {
			WB.addLog("PawnDoc.clear():void, ex=" + ex.getMessage(), "", "PawnDoc");
		}
	}

	public String toString() {
		// origin - 12.01.2025, last edit - 03.09.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", templateId ", this.templateId);
			res = res + Fmtr.addIfNotEmpty(", termId ", this.termId);
			res = res + Fmtr.addIfNotEmpty(", pawnDocId ", this.pawnDocId);
			res = res + Fmtr.addIfNotEmpty(", pawnDocCatId ", this.pawnDocCatId);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.09.2024, last edit - 14.08.2025
		try {

//			WB.addLog2("PawnDoc.test.getByPawnDocCat(List<DealDto>)", "", "PawnDoc");
//			for (var tmp1 : new String[] { "Deal.PawnDoc.Catalog", "Deal.PawnDoc.Catalog.1", "Deal.PawnDoc.Catalog.2",
//					"Deal.PawnDoc.Catalog.Tralala" }) {
//				var tmp = PawnDoc.getByPawnDocCat(tmp1);
//				WB.addLog2("PawnDoc.test.getByPawnDocCat(List<DealDto>), res.size=" + tmp.size() + ", pawnDocCatId="
//						+ tmp1, "", "Pawn");
//				WB.log(tmp, "DealDto");
//			}

//			WB.addLog2("PawnDoc.test.getCurr(List<DealDto>)", "", "PawnDoc");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01" }) {
//				var tmp = PawnDoc.getCurr(tmp1);
//				WB.addLog2("PawnDoc.test.getCurr(List<DealDto>), res.size=" + tmp.size() + ", date1=" + tmp1, "",
//						"Pawn");
//				WB.log(tmp, "DealDto");
//			}

//			WB.addLog2("PawnDoc.test.get(List<DealDto>)", "", "PawnDoc");
//			var tmp = PawnDoc.get();
//			WB.addLog2("PawnDoc.test.get(List<DealDto>), res.size=" + tmp.size(), "", "PawnDoc");
//			WB.log(tmp, "DealDto");

		} catch (Exception ex) {
			WB.addLog("PawnDoc.test():void, ex=" + ex.getMessage(), "", "PawnDoc");
		}
	}
}