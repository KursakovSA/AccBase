public final class PawnCell { // sectoralPawnshop
	// origin - 30.05.2025, last edit - 12.10.2025
	public String src, src1, src2, src3, src4;
	public String color, producer, IMEICode, dateMFG;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("PawnCell.static ctor, ex=" + ex.getMessage(), "", "PawnCell");
		}
	}

	private void getSrc() throws Exception {
		// origin - 30.05.2025, last edit - 14.06.2025
		try {
			if (this.src.length() != 0) {
				String tmp = Etc.fixTrim(this.src); // "color, producer, IMEICode, dateMFG"

				int posSpace1 = tmp.indexOf(" ");
				if (posSpace1 > 0) {
					this.src1 = Etc.fixTrim(tmp.substring(0, posSpace1)); // "color"
					tmp = Etc.fixTrim(tmp.substring(posSpace1)); // "producer, IMEICode, dateMFG"

					int posSpace2 = tmp.indexOf(" ");
					if (posSpace2 > 0) {
						this.src2 = Etc.fixTrim(tmp.substring(0, posSpace2)); // "producer"
						tmp = Etc.fixTrim(tmp.substring(posSpace2)); // "IMEICode, dateMFG"
					} else {
						this.src2 = tmp;
						tmp = "";
					}

					int posSpace3 = tmp.indexOf(" ");
					if (posSpace3 > 0) {
						this.src3 = Etc.fixTrim(tmp.substring(0, posSpace3)); // "IMEICode"
						tmp = Etc.fixTrim(tmp.substring(posSpace3)); // "dateMFG"
					} else {
						this.src3 = tmp; // "IMEICode" = ""
						tmp = "";
					}

					if (tmp.length() != 0) {
						this.src4 = Etc.fixTrim(tmp); // "dateMFG"
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("PawnCar.getSrc():void, ex=" + ex.getMessage(), "", "PawnCar");
		}
	}

	private void getPart() throws Exception {
		// origin - 30.05.2025, last edit - 14.06.2025
		try {
			this.color = src1;
			this.producer = src2;
			this.IMEICode = src3;
			this.dateMFG = src4;
		} catch (Exception ex) {
			WB.addLog("PawnCell.getPart():void, ex=" + ex.getMessage(), "", "PawnCell");
		}
	}

	public PawnCell(String Src) throws Exception {
		// origin - 30.05.2025, last edit - 25.05.2025
		this.clear();
		this.src = Etc.fixTrim(Src); // "color, producer, IMEICode, dateMFG"
		this.getSrc();
		this.getPart();
	}

	public PawnCell() throws Exception {
		// origin - 30.05.2025, last edit - 30.05.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 30.05.2025, last edit - 06.09.2025
		try {
			this.src = this.src1 = this.src2 = this.src3 = this.src4 = "";
			this.color = this.producer = this.IMEICode = this.dateMFG = "";
		} catch (Exception ex) {
			WB.addLog("PawnCell.clear():void, ex=" + ex.getMessage(), "", "PawnCell");
		}
	}

	public String toString() {
		// origin - 30.05.2025, last edit - 30.05.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway(" src ", this.src);
			res = res + Fmtr.addIfNotEmpty(" src1 ", this.src1);
			res = res + Fmtr.addIfNotEmpty(" src2 ", this.src2);
			res = res + Fmtr.addIfNotEmpty(" src3 ", this.src3);
			res = res + Fmtr.addIfNotEmpty(" src4 ", this.src4);
			res = res + Fmtr.addIfNotEmpty(" color ", this.color);
			res = res + Fmtr.addIfNotEmpty(" producer ", this.producer);
			res = res + Fmtr.addIfNotEmpty(" IMEICode ", this.IMEICode);
			res = res + Fmtr.addIfNotEmpty(" dateMFG ", this.dateMFG);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 30.05.2025, last edit - 24.12.2025
		try {

//			WB.addLog2("PawnCell.test.ctor(String)", "", "PawnCell");
//			for (var tmp1 : new String[] { "красный Самсунг 333 12.11.2005", "красный Самсунг 333",
//					"красный Самсунг" }) {
//				WB.addLog2("PawnCell.test.ctor(String)=" + new PawnCell(tmp1), "", "PawnCell");
//			}

		} catch (Exception ex) {
			WB.addLog("PawnCell.test():void, ex=" + ex.getMessage(), "", "PawnCell");
		}
	}
}