import java.util.ArrayList;
import java.util.List;

public final class AccrualTerm {
	// origin - 22.12.2024, last edit - 18.11.2025
	// common fields
	public String table, src, id, parent, face1, face2, face, date1, date2, code, description, geo, role, info, more,
			mark, defect;
	// special fields
	public String fullName, comment, templateId, termId;
	public ListVal composition, pointBasicDayOff, commonExtraDayOff;
	public UnitVal performEvery, commonBasicDayOff, baseInterestContains, basePenaltyContains, interestRate,
			penaltyRate, billingCycle;
	public RangeVal totalPenaltyAccrualLimit, totalOverPaymentLimit;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("AccrualTerm.static ctor, ex=" + ex.getMessage(), "", "AccrualTerm");
		}
	}

	public static String getTemplateAccrualIdByTermId(String termId) throws Exception {
		// origin - 10.09.2025, last edit - 15.09.2025
		String res = "";
		try {
			List<ModelDto> listDto = new ArrayList<ModelDto>();
			listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getIdRoleInfoFilter(termId, "Role.Deal.Accrual", "Info.Deal.Term"), "Deal");
			String templateId = "";
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				templateId = MoreVal.getFieldByKey(dto.more, "TemplateId");
				res = templateId + ".Accrual";
			}
		} catch (Exception ex) {
			WB.addLog("AccrualTerm.getTemplateAccrualIdByTermId(String), ex=" + ex.getMessage(), "", "AccrualTerm");
		}
		return res;
	}

	public static boolean isAccrualTerm(String role, String info) throws Exception {
		// origin - 31.08.2025, last edit - 15.09.2025
		boolean res = false;
		try {
			if ((Etc.strEquals(role, "Role.Deal.Accrual")) && (Etc.strEquals(info, "Info.Deal.Term"))) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("AccrualTerm.isAccrualTerm(2string), ex=" + ex.getMessage(), "", "AccrualTerm");
		}
		return res;
	}

	private void validate() throws Exception {
		// origin - 08.09.2025, last edit - 18.11.2025
		try {
			if (this.composition.val.size() == 0) {
				this.defect = this.defect + "empty composition; ";
			}
			if (this.performEvery.src.isEmpty()) {
				this.defect = this.defect + "empty performEvery; ";
			}
			if (this.baseInterestContains.val == 0.0) {
				this.defect = this.defect + "empty baseInterestContains; ";
			}
			if (this.basePenaltyContains.val == 0.0) {
				this.defect = this.defect + "empty basePenaltyContains; ";
			}
			if (this.totalPenaltyAccrualLimit.val2 == 0.0) {
				this.defect = this.defect + "empty totalPenaltyAccrualLimit; ";
			}
			if (this.billingCycle.val == 0.0) {
				this.defect = this.defect + "empty billingCycle; ";
			}
			if (this.penaltyRate.val == 0.0) {
				this.defect = this.defect + "empty penaltyRate; ";
			}
			if (this.totalOverPaymentLimit.val2 == 0.0) {
				this.defect = this.defect + "empty totalOverPaymentLimit; ";
			}
		} catch (Exception ex) {
			WB.addLog("AccrualTerm.validate():void, ex=" + ex.getMessage(), "", "AccrualTerm");
		}
	}

	private void isExist() throws Exception {
		// origin - 22.12.2024, last edit - 18.11.2025
		try {
			var listDto1 = DAL.getByTemplate(WB.lastConnWork,
					Qry.getIdRoleInfoFilter(this.id, "Role.Deal.Accrual", "Info.Deal.Term"), "Deal");
			if (listDto1.size() != 0) {
				var dto = listDto1.getFirst();
				this.parent = dto.parent;
				this.face1 = dto.face1;
				this.face2 = dto.face2;
				this.face = dto.face;
				this.description = dto.description;
				this.geo = dto.geo;
				this.role = dto.role;
				this.info = dto.info;
				this.more = this.more + dto.more;
				this.getFieldFromMore();
			}

			var listDto2 = DAL.getByTemplate(WB.lastConnWork,
					Qry.getIdRoleInfoFilter(this.code, "Role.Deal.Accrual", "Info.Deal.Term"), "Deal");
			if (listDto2.size() != 0) {
				var dto = listDto2.getFirst();
				this.more = this.more + dto.more;
				this.getFieldFromMore();
			}

		} catch (Exception ex) {
			WB.addLog("AccrualTerm.isExist():void, ex=" + ex.getMessage(), "", "AccrualTerm");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 30.08.2025, last edit - 14.09.2025
		try {
			this.templateId = MoreVal.getFieldByKey(this.more, "TemplateId");
			this.termId = MoreVal.getFieldByKey(this.more, "TermId");
			this.composition = new ListVal(MoreVal.getFieldByKey(this.more, "Composition"), "");
			this.performEvery = new UnitVal(MoreVal.getFieldByKey(this.more, "PerformEvery"));
			this.commonBasicDayOff = new UnitVal(MoreVal.getFieldByKey(this.more, "CommonBasicDayOff"));
			this.commonExtraDayOff = new ListVal(MoreVal.getFieldByKey(this.more, "CommonExtraDayOff"), "");
			this.pointBasicDayOff = new ListVal(MoreVal.getFieldByKey(this.more, "PointBasicDayOff"), "");
			this.baseInterestContains = new UnitVal(MoreVal.getFieldByKey(this.more, "BaseInterestContains"));
			this.basePenaltyContains = new UnitVal(MoreVal.getFieldByKey(this.more, "BasePenaltyContains"));
			this.totalPenaltyAccrualLimit = new RangeVal(MoreVal.getFieldByKey(this.more, "TotalPenaltyAccrualLimit"));
			this.interestRate = new UnitVal(MoreVal.getFieldByKey(this.more, "InterestRate"));
			this.penaltyRate = new UnitVal(MoreVal.getFieldByKey(this.more, "PenaltyRate"));
			this.billingCycle = new UnitVal(MoreVal.getFieldByKey(this.more, "BillingCycle"));
			this.totalOverPaymentLimit = new RangeVal(MoreVal.getFieldByKey(this.more, "TotalOverPaymentLimit"));
		} catch (Exception ex) {
			WB.addLog("AccrualTerm.getFieldFromMore():void, ex=" + ex.getMessage(), "", "AccrualTerm");
		}
	}

//	// get new AccrualTerm by List<ModelDto>,... without isExist
//	public AccrualTerm(List<ModelDto> listModelDto) throws Exception {
//		// origin - 31.08.2025, last edit - 14.09.2025
//		this.clear();
//		for (var currModelDto : listModelDto) {
//			if (isAccrualTerm(currModelDto.role, currModelDto.info)) {
//				var dDto = new DealDto(currModelDto);
//				var tmp = MoreVal.getFieldByKey(dDto.more, "TermId");
//
//				if (tmp.isEmpty()) { // accrual level pawndoc
//					this.src = this.id = dDto.id;
//					this.id = dDto.id;
//					this.parent = dDto.parent;
//					this.face1 = dDto.face1;
//					this.face2 = dDto.face2;
//					this.face = dDto.face;
//					this.date1 = dDto.date1;
//					this.date2 = dDto.date2;
//					this.description = dDto.description;
//					this.geo = dDto.geo;
//					this.role = dDto.role;
//					this.info = dDto.info;
//					this.more = dDto.more;
//					this.getFieldFromMore();
//					this.mark = dDto.mark;
//				}
//
//				if (tmp.isEmpty() == false) { // accrual level term
//					this.src = this.src + ", " + this.id;
//					this.code = dDto.code;
//					this.getFieldFromMore();
//					this.more = this.more + dDto.more;
//				}
//			}
//		}
//	}

	// read PawnTerm if is exist
	public AccrualTerm(String TermId) throws Exception {
		// origin - 10.09.2025, last edit - 18.11.2025
		this.clear();
		this.table = "Deal";
		this.src = TermId;
		this.id = AccrualTerm.getTemplateAccrualIdByTermId(TermId);
		this.code = TermId;
		this.isExist();
		this.validate();
	}

	public AccrualTerm(String TemplateId, String TermId) throws Exception {
		// origin - 22.12.2024, last edit - 18.11.2025
		this.clear();
		this.src = TemplateId + ", " + TermId;
		this.id = TemplateId;
		this.code = TermId;
		this.isExist();
		this.validate();
	}

	public AccrualTerm() throws Exception {
		// origin - 22.12.2024, last edit - 01.01.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 28.11.2024, last edit - 18.11.2025
		try {
			this.table = "Deal";
			this.id = this.parent = this.face1 = this.face2 = this.face = this.date1 = this.date2 = this.code = this.description = "";
			this.geo = this.role = this.info = this.more = this.mark = this.defect = "";
			this.fullName = this.comment = this.templateId = this.termId = "";
			this.composition = this.pointBasicDayOff = this.commonExtraDayOff = new ListVal();
			this.performEvery = this.commonBasicDayOff = new UnitVal();
			this.baseInterestContains = this.basePenaltyContains = new UnitVal("0.0(Unit.RestMainDebt)");
			this.billingCycle = new UnitVal("0.0(Unit.CalendarDay)");
			this.interestRate = this.penaltyRate = new UnitVal("0.0(Unit.PercentPerDay)");
			this.totalPenaltyAccrualLimit = this.totalOverPaymentLimit = new RangeVal("0.0 - 0.0(Unit.MainDebt)");
		} catch (Exception ex) {
			WB.addLog("AccrualTerm.clear():void, ex=" + ex.getMessage(), "", "AccrualTerm");
		}
	}

	public String toString() {
		// origin - 22.12.2024, last edit - 18.11.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", templateId ", this.templateId);
			res = res + Fmtr.addIfNotEmpty(", termId ", this.termId);

			// level pawndoc
			res = res + Fmtr.addAnyway(", composition ", this.composition.id);
			res = res + Fmtr.addAnyway(", performEvery ", this.performEvery.id);
			res = res + Fmtr.addAnyway(", commonBasicDayOff ", this.commonBasicDayOff.id);
			res = res + Fmtr.addAnyway(", commonExtraDayOff ", this.commonExtraDayOff.id);
			res = res + Fmtr.addAnyway(", pointBasicDayOff ", this.pointBasicDayOff.id);
			res = res + Fmtr.addIfNotEmpty(", baseInterestContains ", this.baseInterestContains.id);
			res = res + Fmtr.addIfNotEmpty(", basePenaltyContains ", this.basePenaltyContains.id);
			res = res + Fmtr.addIfNotEmpty(", totalPenaltyAccrualLimit ", this.totalPenaltyAccrualLimit.id);

			// level term
			res = res + Fmtr.addIfNotEmpty(", interestRate ", this.interestRate.id);
			res = res + Fmtr.addIfNotEmpty(", penaltyRate ", this.penaltyRate.id);
			res = res + Fmtr.addIfNotEmpty(", billingCycle ", this.billingCycle.id);
			res = res + Fmtr.addIfNotEmpty(", totalOverPaymentLimit ", this.totalOverPaymentLimit.id);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 22.12.2024, last edit - 10.09.2025
		try {

//			WB.addLog2("AccrualTerm.test.ctor(String)", "", "AccrualTerm");
//			for (var tmp1 : new String[] { "PawnDoc.Template1.V1.Term1.Accrual",
//					"PawnDoc.Template1.V1.Term2.Accrual" }) {
//				WB.addLog2("AccrualTerm.test.ctor(String)=" + new AccrualTerm(tmp1), "", "AccrualTerm");
//			}

//			WB.addLog2("AccrualTerm.test.ctor(2String)", "", "AccrualTerm");
//			var tmp1 = "PawnDoc.Template1.V1.Accrual";
//			for (var tmp2 : new String[] { "PawnDoc.Template1.V1.Term1.Accrual",
//					"PawnDoc.Template1.V1.Term2.Accrual" }) {
//				WB.addLog2("AccrualTerm.test.ctor(2String)=" + new AccrualTerm(tmp1, tmp2), "", "AccrualTerm");
//			}

		} catch (Exception ex) {
			WB.addLog("AccrualTerm.test()(:void, ex=" + ex.getMessage(), "", "AccrualTerm");
		}
	}
}