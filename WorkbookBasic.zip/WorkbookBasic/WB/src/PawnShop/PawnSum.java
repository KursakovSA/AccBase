import java.util.List;

public final class PawnSum { // sectoralPawnshop
	// origin - 25.05.2025, last edit - 03.01.2026
	public String src, src1, src2;
	public UnitVal estimatedValue, mainDebt;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("PawnSum.static ctor, ex=" + ex.getMessage(), "", "PawnSum");
		}
	}

	public static PawnSum getTotal(List<Pawn> pawnList) throws Exception {
		// origin - 02.01.2026, last edit - 05.01.2026
		PawnSum res = new PawnSum();
		try {
			var tmp1 = new UnitVal(UnitVal.currCurrencyInit);
			var tmp2 = new UnitVal(UnitVal.currCurrencyInit);
			for (var currPawn : pawnList) {
				tmp1 = UnitVal.add(tmp1, currPawn.sum.estimatedValue);
				tmp2 = UnitVal.add(tmp2, currPawn.sum.mainDebt);
			}
			// WB.addLog2("PawnSum.getTotal(List<Pawn>):PawnSum, tmp1=" + tmp1, "",
			// "PawnSum");
			res.src = tmp1.src + " " + tmp2.src;
			res.estimatedValue = tmp1;
			res.mainDebt = tmp2;
		} catch (Exception ex) {
			WB.addLog("PawnSum.getTotal(List<Pawn>):PawnSum, ex=" + ex.getMessage(), "", "PawnSum");
		}
		return res;
	}

	private void getSrc() throws Exception {
		// origin - 25.05.2025, last edit - 25.12.2025
		try {
			if (this.src.length() != 0) {
				String tmp = Etc.fixTrim(this.src); // "estimatedValue partMainDebt"
				this.src1 = tmp;

				int posSpace1 = tmp.indexOf(" ");
				if (posSpace1 > 0) {
					this.src1 = Etc.fixTrim(tmp.substring(0, posSpace1)); // "estimatedValue"
					tmp = Etc.fixTrim(tmp.substring(posSpace1)); // "partMainDebt"

					if (tmp.length() != 0) {
						this.src2 = Etc.fixTrim(tmp); // "partMainDebt"
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("PawnSum.getSrc():void, ex=" + ex.getMessage(), "", "PawnSum");
		}
	}

	private void getPart() throws Exception {
		// origin - 25.05.2025, last edit - 03.01.2026
		try {
			this.estimatedValue = new UnitVal(src1, Unit.currCurrency.code);
			this.mainDebt = new UnitVal(src2, Unit.currCurrency.code);
		} catch (Exception ex) {
			WB.addLog("PawnSum.getPart():void, ex=" + ex.getMessage(), "", "PawnSum");
		}
	}

	public PawnSum(String Src) throws Exception {
		// origin - 25.05.2025, last edit - 14.06.2025
		this.clear();
		this.src = Etc.fixTrim(Src); // weightGross weightNetto estimatedValue partMainDebt
		this.getSrc();
		this.getPart();
	}

	public PawnSum() throws Exception {
		// origin - 25.05.2025, last edit - 25.05.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 25.05.2025, last edit - 03.01.2026
		try {
			this.src = this.src1 = this.src2 = "";
			this.estimatedValue = this.mainDebt = new UnitVal(UnitVal.currCurrencyInit);
		} catch (Exception ex) {
			WB.addLog("PawnSum.clear():void, ex=" + ex.getMessage(), "", "PawnSum");
		}
	}

	public String toString() {
		// origin - 25.05.2025, last edit - 05.01.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway(" src ", this.src);
			res = res + Fmtr.addIfNotEmpty(" src1 ", this.src1);
			res = res + Fmtr.addIfNotEmpty(" src2 ", this.src2);
			if (this.src.isEmpty() == false) {
				res = res + Fmtr.addIfNotEmpty(" estimatedValue ", this.estimatedValue.id);
				res = res + Fmtr.addIfNotEmpty(" mainDebt ", this.mainDebt.id);
			}
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 25.05.2025, last edit - 05.01.2026
		try {

//			WB.addLog2("PawnSum.test.getTotal(List<Pawn>):PawnSum", "", "PawnSum");
//			var tmp = Pawn.get();
//			WB.addLog2("PawnSum.test.get():List<Pawn> for getTotal, tmp.size=" + tmp.size() + ", filterless", "",
//					"PawnSum");
//			WB.log(tmp, "PawnSum");
//			WB.addLog2("PawnSum.test.getTotal(List<Pawn>):PawnSum, res=" + PawnSum.getTotal(tmp), "", "PawnSum");

//			WB.addLog2("PawnSum.test.ctor(String)", "", "PawnSum");
//			for (var tmp1 : new String[] { "12000.00 10000.00", "14000 13000", "17000 15000", "17000,00 15000,00" }) {
//				WB.addLog2("PawnSum.test.ctor(String)=" + new PawnSum(tmp1), "", "PawnSum");
//			}

		} catch (Exception ex) {
			WB.addLog("PawnSum.test():void, ex=" + ex.getMessage(), "", "PawnSum");
		}
	}
}