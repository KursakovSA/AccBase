public class PawnCat {
	// origin - 24.12.2025, last edit - 24.12.2025
	public String src, src1, src2;
	public String assetCatId;
	public ListVal assetDefectCatId;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("PawnCat.static ctor, ex=" + ex.getMessage(), "", "PawnCat");
		}
	}

	private void getSrc() throws Exception {
		// origin - 24.12.2025, last edit - 25.12.2025
		try {
			if (this.src.length() != 0) {
				String tmp = Etc.fixTrim(this.src);
				this.src1 = tmp;

				int posSpace1 = tmp.indexOf(" ");
				if (posSpace1 > 0) {
					this.src1 = Etc.fixTrim(tmp.substring(0, posSpace1));
					tmp = Etc.fixTrim(tmp.substring(posSpace1));

					if (tmp.length() > 0) {
						this.src2 = Etc.fixTrim(tmp);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("PawnCat.getSrc():void, ex=" + ex.getMessage(), "", "PawnCat");
		}
	}

	private void getPart() throws Exception {
		// origin - 24.12.2025, last edit - 24.12.2025
		try {
			this.assetCatId = this.src1;
			this.assetDefectCatId = new ListVal(this.src2, "");
		} catch (Exception ex) {
			WB.addLog("PawnCat.getPart():void, ex=" + ex.getMessage(), "", "PawnCat");
		}
	}

	public PawnCat(String Src) throws Exception {
		// origin - 24.12.2025, last edit - 24.12.2025
		this.clear();
		this.src = Etc.fixTrim(Src);
		this.getSrc();
		this.getPart();
	}

	private void clear() throws Exception {
		// origin - 24.12.2025, last edit - 24.12.2025
		try {
			this.src = this.src1 = this.src2 = "";
			this.assetCatId = "";
		} catch (Exception ex) {
			WB.addLog("PawnCat.clear():void, ex=" + ex.getMessage(), "", "PawnCat");
		}
	}

	public PawnCat() throws Exception {
		// origin - 24.12.2025, last edit - 24.12.2025
		this.clear();
	}

	public String toString() {
		// origin - 24.12.2025, last edit - 24.12.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" src ", this.src);
			res = res + Fmtr.addIfNotEmpty(" src1 ", this.src1);
			res = res + Fmtr.addIfNotEmpty(" src2 ", this.src2);
			res = res + Fmtr.addIfNotEmpty(" assetCatId ", this.assetCatId);
			res = res + Fmtr.addIfNotEmpty(" assetDefectCatId ", this.assetDefectCatId.id);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 24.12.2025, last edit - 25.12.2025
		try {

//			WB.addLog2("PawnCat.test.ctor(String)", "", "PawnCat");
//			for (var tmp1 : new String[] { "Asset.PS.Catalog.1 потертости:заусенцы", "Asset.PS.Catalog б/д",
//					"Asset.PS.Catalog" }) {
//				WB.addLog2("PawnCat.test.ctor(String)=" + new PawnCat(tmp1), "", "PawnCat");
//			}

		} catch (Exception ex) {
			WB.addLog("PawnCat.test():void, ex=" + ex.getMessage(), "", "PawnCat");
		}
	}
}