import java.util.ArrayList;
import java.util.List;

public final class PawnTerm { // sectoralPawnshop
	// origin - 01.09.2025, last edit - 19.11.2025
	// common fields
	public String table, src, id, parent, face1, face2, face, date1, date2, code, description, geo, role, info, more,
			mark, defect;
	// special fields
	public String fullName, comment, templateId, termId;
	public RangeVal weightLimit, netToGrossLimit, allowedPartialRansomIfCountCurr, countLimit;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("PawnTerm.static ctor, ex=" + ex.getMessage(), "", "PawnTerm");
		}
	}

	public static String getTemplatePawnIdByTermId(String termId) throws Exception {
		// origin - 10.09.2025, last edit - 15.09.2025
		String res = "";
		try {
			List<ModelDto> listDto = new ArrayList<ModelDto>();
			listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getIdRoleInfoFilter(termId, "Role.Deal.Pawn", "Info.Deal.Term"), "Deal");
			String templateId = "";
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				templateId = MoreVal.getFieldByKey(dto.more, "TemplateId");
				res = templateId + ".Pawn";
			}
		} catch (Exception ex) {
			WB.addLog("PawnTerm.getTemplatePawnIdByTermId(String), ex=" + ex.getMessage(), "", "PawnTerm");
		}
		return res;
	}

	public static boolean isPawnTerm(String role, String info) throws Exception {
		// origin - 01.09.2025, last edit - 15.09.2025
		boolean res = false;
		try {
			if ((Etc.strEquals(role, "Role.Deal.Pawn")) && (Etc.strEquals(info, "Info.Deal.Term"))) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("PawnTerm.isPawnTerm(2string), ex=" + ex.getMessage(), "", "PawnTerm");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 08.09.2025, last edit - 19.11.2025
		try {
			if (this.weightLimit.val2 == 0.0) {
				this.defect = this.defect + "empty weightLimit; ";
			}
			if (this.netToGrossLimit.val2 == 0.0) {
				this.defect = this.defect + "empty netToGrossLimit; ";
			}
			if (this.countLimit.val2 == 0.0) {
				this.defect = this.defect + "empty countLimit; ";
			}
		} catch (Exception ex) {
			WB.addLog("PawnTerm.validate():void, ex=" + ex.getMessage(), "", "PawnTerm");
		}
	}

	private void isExist() throws Exception {
		// origin - 01.09.2025, last edit - 19.11.2025
		try {
			List<ModelDto> listDto = new ArrayList<ModelDto>();
			listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getIdRoleInfoFilter(this.id, "Role.Deal.Pawn", "Info.Deal.Term"), "Deal");

			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				// this.id = DefVal.setCustom(this.id, dto.id);
				// this.code = DefVal.setCustom(this.code, dto.code);
				this.parent = DefVal.setCustom(this.parent, dto.parent);
				this.face1 = DefVal.setCustom(this.face1, dto.face1);
				this.face2 = DefVal.setCustom(this.face2, dto.face2);
				this.face = DefVal.setCustom(this.face, dto.face);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.geo = DefVal.setCustom(this.geo, dto.geo);
				this.role = DefVal.setCustom(this.role, dto.role);
				this.info = DefVal.setCustom(this.info, dto.info);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.getFieldFromMore();
			}

			var listDto2 = DAL.getByTemplate(WB.lastConnWork,
					Qry.getIdRoleInfoFilter(this.code, "Role.Deal.Pawn", "Info.Deal.Term"), "Deal");
			if (listDto2.size() != 0) {
				var dto = listDto2.getFirst();
				this.more = this.more + dto.more;
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("PawnTerm.isExist():void, ex=" + ex.getMessage(), "", "PawnTerm");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 01.09.2025, last edit - 14.09.2025
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.termId = MoreVal.getFieldByKey(this.more, "TermId");
			this.templateId = MoreVal.getFieldByKey(this.more, "TemplateId");
			this.weightLimit = new RangeVal(MoreVal.getFieldByKey(this.more, "WeightLimit"));
			this.netToGrossLimit = new RangeVal(MoreVal.getFieldByKey(this.more, "NetToGrossLimit"));
			this.allowedPartialRansomIfCountCurr = new RangeVal(
					MoreVal.getFieldByKey(this.more, "AllowedPartialRansomIfCountCurr"));
			this.countLimit = new RangeVal(MoreVal.getFieldByKey(this.more, "CountLimit"));
		} catch (Exception ex) {
			WB.addLog("PawnTerm.getFieldFromMore():void, ex=" + ex.getMessage(), "", "PawnTerm");
		}
	}

//	// get new PawnTerm by List<ModelDto>,... without isExist
//	public PawnTerm(List<ModelDto> listModelDto) throws Exception {
//		// origin - 01.09.2025, last edit - 13.09.2025
//		this.clear();
//		for (var currModelDto : listModelDto) {
//			if (PawnTerm.isPawnTerm(currModelDto.role, currModelDto.info)) {
//				var dDto = new DealDto(currModelDto);
//				this.src = this.id = dDto.id;
//				this.id = dDto.id;
//				this.parent = dDto.parent;
//				this.face1 = dDto.face1;
//				this.face2 = dDto.face2;
//				this.face = dDto.face;
//				this.date1 = dDto.date1;
//				this.date2 = dDto.date2;
//				this.description = dDto.description;
//				this.geo = dDto.geo;
//				this.role = dDto.role;
//				this.info = dDto.info;
//				this.more = dDto.more;
//				this.getFieldFromMore();
//				this.mark = dDto.mark;
//				this.isValid();
//			}
//		}
//	}

	// get new pawn by DealDto.id,... without isExist
	public PawnTerm(String Id, String Parent, String Face1, String Face2, String Face, String Date1, String Date2,
			String Code, String Description, String Geo, String Role, String Info, String More, String Mark)
			throws Exception {
		// origin - 01.09.2025, last edit - 19.11.2025
		this.clear();
		this.src = this.id = Id;
		this.parent = Parent;
		this.face1 = Face1;
		this.face2 = Face2;
		this.face = Face;
		this.date1 = Date1;
		this.date2 = Date2;
		this.code = Code;
		this.description = Description;
		this.geo = Geo;
		this.role = Role;
		this.info = Info;
		this.more = More;
		this.getFieldFromMore();
		this.mark = Mark;
		this.validate();
	}

	// read PawnTerm if is exist
	public PawnTerm(String TermId) throws Exception {
		// origin - 09.09.2025, last edit - 19.11.2025
		this.clear();
		this.table = "Deal";
		this.src = TermId;
		this.id = PawnTerm.getTemplatePawnIdByTermId(TermId);
		this.code = TermId;
		this.isExist();
		this.validate();
	}

	// read PawnTerm if is exist
	public PawnTerm(String TemplateId, String TermId) throws Exception {
		// origin - 01.09.2025, last edit - 19.11.2025
		this.clear();
		this.table = "Deal";
		this.src = TemplateId + "," + TermId;
		this.id = TemplateId;
		this.code = TermId;
		this.isExist();
		this.validate();
	}

	public PawnTerm() throws Exception {
		// origin - 01.09.2025, last edit - 01.09.2025
		this.clear();
	}

	public String toString() {
		// origin - 01.09.2025, last edit - 19.11.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addAnyway(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(" id ", this.id);
			res = res + Fmtr.addIfNotEmpty(" parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(" face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(" face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(" face ", this.face);
			res = res + Fmtr.addIfNotEmpty(" date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(" date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(" code ", this.code);
			res = res + Fmtr.addIfNotEmpty(" description ", this.description);
			res = res + Fmtr.addIfNotEmpty(" ", this.geo);
			res = res + Fmtr.addIfNotEmpty(" ", this.role);
			res = res + Fmtr.addIfNotEmpty(" ", this.info);
			res = res + Fmtr.addIfNotEmpty(" more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(" defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(" ", this.mark);
			res = res + Fmtr.addIfNotEmpty(" weightLimit ", this.weightLimit.id);
			res = res + Fmtr.addIfNotEmpty(" netToGrossLimit ", this.netToGrossLimit.id);
			res = res + Fmtr.addIfNotEmpty(" allowedPartialRansomIfCountCurr", this.allowedPartialRansomIfCountCurr.id);
			res = res + Fmtr.addIfNotEmpty(" countLimit ", this.countLimit.id);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	private void clear() throws Exception {
		// origin - 01.09.2025, last edit - 19.11.2025
		try {
			this.table = "Deal";
			this.src = this.id = this.parent = this.date1 = this.date2 = this.face1 = this.face2 = this.face = "";
			this.code = this.description = this.defect = "";
			this.geo = this.role = this.info = this.more = this.mark = "";
			this.fullName = this.comment = this.templateId = this.termId = "";
			this.weightLimit = new RangeVal("0.0 - 0.0(Unit.Gr)");
			this.netToGrossLimit = new RangeVal("0.0 - 0.0(Unit.Ratio)");
			this.allowedPartialRansomIfCountCurr = new RangeVal("0.0 - 0.0(Unit.Pawn)");
			this.countLimit = new RangeVal("0.0 - 0.0(Unit.Pawn)");
		} catch (Exception ex) {
			WB.addLog("PawnTerm.clear():void, ex=" + ex.getMessage(), "", "PawnTerm");
		}
	}

	public static void test() throws Exception {
		// origin - 01.09.2025, last edit - 10.09.2025
		try {

//			WB.addLog2("PawnTerm.test.ctor(String)", "", "PawnTerm");
//			for (var tmp1 : new String[] { "PawnDoc.Template1.V1.Term1.Pawn", "PawnDoc.Template1.V1.Term2.Pawn" }) {
//				WB.addLog2("PawnTerm.test.ctor(String)=" + new PawnTerm(tmp1), "", "PawnTerm");
//			}

//			WB.addLog2("PawnTerm.test.ctor(2String)", "", "PawnTerm");
//			for (var tmp1 : new String[] { "PawnDoc.Template1.V1.Pawn" }) {
//				for (var tmp2 : new String[] { "PawnDoc.Template1.V1.Term1.Pawn", "PawnDoc.Template1.V1.Term2.Pawn" }) {
//					WB.addLog2("PawnTerm.test.ctor(2String)=" + new PawnTerm(tmp1, tmp2), "", "PawnTerm");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("PawnTerm.test():void, ex=" + ex.getMessage(), "", "PawnTerm");
		}
	}
}