import java.util.ArrayList;
import java.util.List;

public class Abc {
	// origin - 28.09.2023, last edit - 07.01.2024
	public List<ModelDto> basic = new ArrayList<ModelDto>();
	public List<ModelDto> local = new ArrayList<ModelDto>();
	public List<ModelDto> table = new ArrayList<ModelDto>();
	public List<ModelDto> catalog = new ArrayList<ModelDto>();
	public List<ModelDto> codePay = new ArrayList<ModelDto>();
	public List<ModelDto> template = new ArrayList<ModelDto>();
	public List<ModelDto> sourceExtFile = new ArrayList<ModelDto>();
	public List<ModelDto> userLocal = new ArrayList<ModelDto>(); // TODO
	public List<ModelDto> templateDoc = new ArrayList<ModelDto>(); // TODO
	public List<ModelDto> report = new ArrayList<ModelDto>(); // TODO
	public List<ModelDto> segmentTax = new ArrayList<ModelDto>(); // TODO

	public Abc(String dbConn) throws Exception {
		// origin - 26.11.2023, last edit - 07.01.2024
		try {
			this.basic = DAL.getTemplateMore(dbConn, Qry.getMoreFilter("AbcBasic"));
			this.local = DAL.getTemplateMore(dbConn, Qry.getMoreFilter("AbcLocal"));
			this.sourceExtFile = ModelDto.getSubsetMore(this.local, "SourceExtFile");
			//this.table = DAL.getTemplateMore(dbConn, Qry.getMoreFilter("AbcTable"));
			this.table = ModelDto.getSubsetMore(this.basic, "AbcTable");
			//this.catalog = DAL.getTemplateMore(dbConn, Qry.getMoreFilter("AbcCatalog"));
			this.catalog = ModelDto.getSubsetMore(this.basic, "AbcCatalog");
			//this.codePay = DAL.getTemplateMore(dbConn, Qry.getMoreFilter("AbcCodePay"));
			this.codePay = ModelDto.getSubsetMore(this.basic, "AbcCodePay");
			//this.template = DAL.getTemplateMore(dbConn, Qry.getMoreFilter("AbcTemplate"));
			this.template = ModelDto.getSubsetMore(this.basic, "AbcTemplate");
		} catch (Exception ex) {
			Logger.add("Abc.ctor(dbConn), ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "Abc");
		} finally {
			Etc.doNothing();
		}
	}

	public Abc() {
		// origin - 13.11.2023, last edit - 27.11.2023
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 05.12.2023
	}

	public String toString() {
		// origin - 21.11.2023, last edit - 01.01.2024
		String res = "";
		res = appender(res, formatter("basic", this.basic));
		res = appender(res, formatter("local", this.local));
		res = appender(res, formatter("sourceExtFile", this.sourceExtFile));
		res = appender(res, formatter("table", this.table));
		res = appender(res, formatter("catalog", this.catalog));
		res = appender(res, formatter("codePay", this.codePay));
		res = appender(res, formatter("template", this.template));
		res = appender(res, formatter("user", this.userLocal));
		res = appender(res, formatter("report", this.report));
		res = appender(res, formatter("segmentTax", this.segmentTax));
		res = "{" + res + "}";
		return res;
	}

	private static String appender(String strRes, String strAdd) {
		// origin - 31.12.2023, last edit - 31.12.2023
		String res = strRes;
		if (strAdd.isEmpty() != true) {
			res = res + strAdd;
		}
		return res;
	}

	private String formatter(String componentAbcName, List<ModelDto> componentAbc) {
		// origin - 30.12.2023, last edit - 30.12.2023
		String res = "";
		try {
			if (componentAbc.isEmpty() != true) {
				res = res + componentAbcName + "=" + componentAbc.size() + ", ";
			}
		} catch (Exception ex) {
			Logger.add("Abc.addStrAbcComp, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "Abc");
		} finally {
			Etc.doNothing();
		}
		return res;
	}
}
