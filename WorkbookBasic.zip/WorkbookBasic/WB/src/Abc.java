import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class Abc {
	// origin - 28.09.2023, last edit - 08.10.2024
	public List<ModelDto> basic = new ArrayList<ModelDto>();
	public List<ModelDto> root = new ArrayList<ModelDto>();
	public List<ModelDto> table = new ArrayList<ModelDto>();
	public List<ModelDto> catalog = new ArrayList<ModelDto>();
	public List<ModelDto> codePay = new ArrayList<ModelDto>();
	public List<ModelDto> template = new ArrayList<ModelDto>();
	public List<ModelDto> sourceExtFile = new ArrayList<ModelDto>();
	public List<ModelDto> registerOrg = new ArrayList<ModelDto>();
	public List<ModelDto> workOutside = new ArrayList<ModelDto>();
	public List<ModelDto> collector = new ArrayList<ModelDto>();
	public List<ModelDto> update = new ArrayList<ModelDto>();
	public List<ModelDto> sectoral = new ArrayList<ModelDto>();
	public List<ModelDto> sectoralPawnshop = new ArrayList<ModelDto>();
	public List<ModelDto> listVal = new ArrayList<ModelDto>();
	public List<ModelDto> rule = new ArrayList<ModelDto>();
	public List<ModelDto> idGen = new ArrayList<ModelDto>();
	public List<ModelDto> expectedValue = new ArrayList<ModelDto>(); //?? not need ??

	public List<ModelDto> infoBaseId = new ArrayList<ModelDto>();

	public List<ModelDto> userManualLocal = new ArrayList<ModelDto>();
	public List<ModelDto> userLocal = new ArrayList<ModelDto>(); // TOTHINK
	public List<ModelDto> templateDoc = new ArrayList<ModelDto>(); // TOTHINK
	public List<ModelDto> report = new ArrayList<ModelDto>(); // TOTHINK

	// segment
	public List<ModelDto> debt = new ArrayList<ModelDto>();
	public List<ModelDto> publicHoliday = new ArrayList<ModelDto>();
	public List<ModelDto> extraDayOff = new ArrayList<ModelDto>();
	public List<ModelDto> unit = new ArrayList<ModelDto>();
	public List<ModelDto> meter = new ArrayList<ModelDto>();

	public List<ModelDto> defaultWorkingHour = new ArrayList<ModelDto>(); // TOTHINK
	public List<ModelDto> defaultDebtIncomePersonBaseDeductionStandard = new ArrayList<ModelDto>(); // TOTHINK
	public List<ModelDto> accountMatching = new ArrayList<ModelDto>();// TOTHINK
	public List<ModelDto> accountTableClosing = new ArrayList<ModelDto>();// TOTHINK

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Abc.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Abc");
		} finally {
			Etc.doNothing();
		}
	}

	public static ModelDto getRoot(String table) throws Exception {
		// origin - 23.09.2024, last edit - 07.10.2024
		ModelDto res = new ModelDto();
		try {
			res = ReadSet.getByCode(WB.abcLast.basic, table).getFirst();
		} catch (Exception ex) {
			WB.addLog("Abc.getRoot, ex=" + ex.getMessage(), WB.strEmpty, "Abc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Abc.getRoot, res=" + res, WB.strEmpty, "Abc");
		return res;
	}

	public static String getMeterValueByDescription(List<ModelDto> partAbc, String strFilter) throws Exception {
		// origin - 02.09.2024, last edit - 03.09.2024
		String res = WB.strEmpty;
		try {
			for (var currPartAbc : partAbc) {
				if (Etc.fixTrim(currPartAbc.meterValue).isEmpty()) {// IdGenLocal must have not empty field
																	// meterValue
					continue;
				}
				if (Etc.strContains(currPartAbc.description, strFilter)) {
					res = Etc.fixTrim(String.valueOf(Etc.fixTrim(currPartAbc.meterValue)));
				}
			}
		} catch (Exception ex) {
			WB.addLog("Abc.getMeterValueByDescription, ex=" + ex.getMessage(), WB.strEmpty, "Abc");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("Abc.getMeterValueByDescription, res=" + res + ", strFilter=" + strFilter, WB.strEmpty,
//				"IdGen.Tuner");
		return res;
	}

	public Abc(String dbConn) throws Exception {
		// origin - 26.11.2023, last edit - 08.10.2024
		try {
			// main
			this.basic = DAL.getByTemplate(dbConn, Qry.getMoreFilter("AbcBasic"));
			this.sectoral = ReadSet.getByMore(this.basic, "AbcSectoral");
			this.sectoralPawnshop = ReadSet.getByMore(this.basic, "Pawnshop");

			// segment
			this.debt = ReadSet.get(this.basic, ReadSet.getFilter("Debt", WB.strEmpty));
			this.publicHoliday = ReadSet.get(this.basic, ReadSet.getFilter("PublicHoliday", "Meter.PublicHoliday"));
			this.extraDayOff = ReadSet.get(this.basic, ReadSet.getFilter("ExtraDayOff", "Meter.ExtraDayOff"));
			this.accountMatching = ReadSet.getByCode(this.basic, "Account.Matching");
			this.accountTableClosing = ReadSet.get(this.basic,
					ReadSet.getFilter("Account.TableClosing", "Meter.Matching"));
			this.template = ReadSet.getByCode(this.basic, "Template");
			this.rule = ReadSet.getByCode(this.basic, "Rule");
			this.unit = ReadSet.getByCode(this.basic, "Unit");
			this.meter = ReadSet.getByCode(this.basic, "Meter");

			// subset
			this.infoBaseId = ReadSet.getByMore(this.basic, "InfoBaseId");
			this.userManualLocal = ReadSet.getByMore(this.basic, "UserManualLocal");
			this.sourceExtFile = ReadSet.getByMore(this.basic, "SourceExtFile");
			this.registerOrg = ReadSet.getByMore(this.basic, "RegisterOrg");
			this.workOutside = ReadSet.getByMore(this.basic, "WorkOutside");
			this.collector = ReadSet.getByMore(this.basic, "Collector");
			this.update = ReadSet.getByMore(this.basic, "AbcUpdate");
			this.table = ReadSet.getByMore(this.basic, "AbcTable");
			this.catalog = ReadSet.getByMore(this.basic, "AbcCatalog");
			this.codePay = ReadSet.getByMore(this.basic, "AbcCodePay");
			this.root = ReadSet.getByMore(this.basic, "AbcRoot");
			this.listVal = ReadSet.getByMore(this.basic, "AbcListVal");
			this.idGen = ReadSet.getByCode(this.basic, "IdGen");
			this.expectedValue = ReadSet.getByMore(this.basic, "AbcExpectedValue");

		} catch (Exception ex) {
			WB.addLog("Abc.ctor(dbConn), ex=" + ex.getMessage(), WB.strEmpty, "Abc");
		} finally {
			Etc.doNothing();
		}
	}

	public Abc() throws Exception {
		// origin - 13.11.2023, last edit - 07.07.2024
		try {
		} catch (Exception ex) {
			WB.addLog("Abc.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Abc");
		} finally {
			Etc.doNothing();
		}
	}

	@SuppressWarnings("unchecked")
	private String reflect() throws Exception {
		// origin - 21.08.2024, last edit - 26.08.2024
		String res = WB.strEmpty;
		try {
			Field[] fields = this.getClass().getFields();
			for (var currField : fields) {
				currField.setAccessible(true);
				List<ModelDto> fieldValue = (List<ModelDto>) currField.get(this);

				if (fieldValue.isEmpty() != true) {
					res = res + currField.getName() + WB.strEquals + fieldValue.size() + WB.strCommaSpace; // basic=4....etc.
				}
			}
		} catch (Exception ex) {
			WB.addLog2("Abc.reflect, ex=" + ex.getMessage(), WB.strEmpty, "Abc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Abc.reflect, res=" + res, WB.strEmpty, "Abc");
		return res;
	}

	public String toString() {
		// origin - 21.11.2023, last edit - 24.08.2024
		String res = WB.strEmpty;
		try {
			res = this.reflect();
			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
			WB.addLog("Abc.toString, ex=" + ex.getMessage(), WB.strEmpty, "Abc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Abc.toString end ", WB.strEmpty, "WB");
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 16.09.2024
		try {

//			//WB.abcLast.basic.size
//			WB.addLog2("Abc.test, WB.abcLast.basic.size=" + WB.abcLast.basic.size(), WB.strEmpty, "Abc");

		} catch (Exception ex) {
			WB.addLog("Abc.test, ex=" + ex.getMessage(), WB.strEmpty, "Abc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Abc.test end ", WB.strEmpty, "Abc");
	}
}
