import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class Abc {
	// origin - 28.09.2023, last edit - 20.12.2024
	public List<ModelDto> basic, root, table, catalog, codePay, template, sourceExtFile, registerOrg, workOutside;
	public List<ModelDto> collector, update, sectoral, sectoralPawnshop, listVal, rule, idGen, expectedValue, custom;
	public List<ModelDto> FA, currFA, infoBaseId, userManualLocal, userLocal, templateDoc, report, item;
	public List<ModelDto> debt, publicHoliday, extraDayOff, unit, meter, geo, price, role, info, slice, mark, sign;
	public List<ModelDto> defaultWorkingHour, defaultDebtIncomePersonBaseDeductionStandard;
	public List<ModelDto> account, accountMatching, accountClosing;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Abc.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Abc");
		} finally {
			Etc.doNothing();
		}
	}

	public static ModelDto getRoot(String table) throws Exception {
		// origin - 23.09.2024, last edit - 28.12.2024
		ModelDto res = new ModelDto();
		try {
			res = ReadSet.getEqualsByCode(WB.abcLast.basic, table).getFirst();
		} catch (Exception ex) {
			WB.addLog("Abc.getRoot, ex=" + ex.getMessage(), WB.strEmpty, "Abc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Abc.getRoot, res=" + res, WB.strEmpty, "Abc");
		return res;
	}

//	public static String getMeterValueByDescription(List<ModelDto> partAbc, String strFilter) throws Exception {
//		// origin - 02.09.2024, last edit - 25.11.2024
//		String res = WB.strEmpty;
//		try {
//			for (var currPartAbc : partAbc) {
//				if (Etc.fixTrim(currPartAbc.meterValue).isEmpty()) {// IdGenLocal must have not empty field
//																	// meterValue
//					continue;
//				}
//				if (Etc.strContains(currPartAbc.description, strFilter)) {
//					res = Etc.fixTrim(String.valueOf(Etc.fixTrim(currPartAbc.meterValue)));
//				}
//			}
//		} catch (Exception ex) {
//			WB.addLog("Abc.getMeterValueByDescription, ex=" + ex.getMessage(), WB.strEmpty, "Abc");
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("Abc.getMeterValueByDescription, res=" + res + ", strFilter=" +
//		// strFilter, WB.strEmpty, "Abc");
//		return res;
//	}

	public Abc(String dbConn) throws Exception {
		// origin - 26.11.2023, last edit - 20.12.2024
		this();
		try {
			this.basic = DAL.getByTemplate(dbConn, Qry.getMoreFilter("AbcBasic"));
			this.sectoral = ReadSet.getContainsByMore(this.basic, "AbcSectoral");
			this.sectoralPawnshop = ReadSet.getContainsByMore(this.basic, "Pawnshop");
			this.custom = ReadSet.getContainsByMore(this.basic, "AbcCustom");

			this.debt = ReadSet.getContainsByMore(this.basic, "Debt.Basic");
			this.item = ReadSet.getContainsByMore(this.basic, "Item.Basic");

			this.publicHoliday = ReadSet.getEqualsByMeter(this.basic, "Meter.PublicHoliday");
			this.extraDayOff = ReadSet.getEqualsByMeter(this.basic, "Meter.ExtraDayOff");
			this.account = ReadSet.getContainsByMore(this.basic, "Account.Basic");
			this.accountMatching = ReadSet.getContainsByMore(this.basic, "AbcAccountMatching");
			this.accountClosing = ReadSet.getContainsByMore(this.basic, "AbcAccountClosing");
			this.template = ReadSet.getContainsByCode(this.basic, "Template");
			this.rule = ReadSet.getContainsByCode(this.basic, "Rule");
			this.FA = ReadSet.getContainsByCode(this.basic, "Face.FA");
			this.currFA = ReadSet.getEqualsByRole(this.FA, "Role.Face.FA");

			this.unit = ReadSet.getContainsByMore(this.basic, "Unit.Basic");
			this.meter = ReadSet.getContainsByMore(this.basic, "Meter.Basic");
			this.geo = ReadSet.getContainsByMore(this.basic, "Geo.Basic");
			this.price = ReadSet.getContainsByMore(this.basic, "Price.Basic");
			this.role = ReadSet.getContainsByMore(this.basic, "Role.Basic");
			this.info = ReadSet.getContainsByMore(this.basic, "Info.Basic");
			this.slice = ReadSet.getContainsByMore(this.basic, "Slice.Basic");
			this.mark = ReadSet.getContainsByMore(this.basic, "Mark.Basic");
			this.sign = ReadSet.getContainsByMore(this.basic, "Sign.Basic");

			this.infoBaseId = ReadSet.getContainsByMore(this.basic, "InfoBaseId");
			this.userManualLocal = ReadSet.getContainsByMore(this.basic, "UserManualLocal");
			this.userLocal = ReadSet.getContainsByMore(this.basic, "UserLocal");
			this.sourceExtFile = ReadSet.getContainsByMore(this.basic, "SourceExtFile");
			this.registerOrg = ReadSet.getContainsByMore(this.basic, "RegisterOrg");
			this.workOutside = ReadSet.getContainsByMore(this.basic, "WorkOutside");
			this.collector = ReadSet.getContainsByMore(this.basic, "Collector");
			this.update = ReadSet.getContainsByMore(this.basic, "AbcUpdate");
			this.table = ReadSet.getContainsByMore(this.basic, "AbcTable");
			this.catalog = ReadSet.getContainsByMore(this.basic, "AbcCatalog");
			this.codePay = ReadSet.getContainsByMore(this.basic, "AbcCodePay");
			this.root = ReadSet.getContainsByMore(this.basic, "AbcRoot");
			this.listVal = ReadSet.getContainsByMore(this.basic, "AbcListVal");
			this.idGen = ReadSet.getContainsByCode(this.basic, "IdGen");
			this.expectedValue = ReadSet.getContainsByMore(this.basic, "AbcExpectedValue");

			// this.templateDoc = ReadSet.getContainsByMore(this.basic, "AbcTemplateDoc");
			// this.report = ReadSet.getContainsByMore(this.basic, "AbcReport");
			// this.defaultWorkingHour
			// this.defaultDebtIncomePersonBaseDeductionStandard

		} catch (Exception ex) {
			WB.addLog("Abc.ctor(dbConn), ex=" + ex.getMessage(), WB.strEmpty, "Abc");
		} finally {
			Etc.doNothing();
		}
	}

	public Abc() throws Exception {
		// origin - 13.11.2023, last edit - 25.11.2024
		try {
			this.clear();
		} catch (Exception ex) {
			WB.addLog("Abc.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Abc");
		} finally {
			Etc.doNothing();
		}
	}

	public void clear() throws Exception {
		// origin - 25.11.2024, last edit - 20.12.2024
		try {
			this.basic = this.root = this.table = this.catalog = this.codePay = this.template = this.sourceExtFile = new ArrayList<ModelDto>();
			this.registerOrg = this.workOutside = this.collector = this.update = this.sectoral = this.sectoralPawnshop = new ArrayList<ModelDto>();
			this.listVal = this.rule = this.item = this.idGen = this.expectedValue = this.custom = this.FA = this.currFA = new ArrayList<ModelDto>();
			this.infoBaseId = this.userManualLocal = this.userLocal = this.templateDoc = this.slice = this.mark = new ArrayList<ModelDto>();
			this.report = this.debt = this.publicHoliday = this.extraDayOff = this.unit = this.price = this.role = new ArrayList<ModelDto>();
			this.meter = this.defaultWorkingHour = this.defaultDebtIncomePersonBaseDeductionStandard = new ArrayList<ModelDto>();
			this.account = this.accountMatching = this.accountClosing = this.sign = new ArrayList<ModelDto>();
		} catch (Exception ex) {
			WB.addLog("Abc.clear, ex=" + ex.getMessage(), WB.strEmpty, "Abc");
		} finally {
			Etc.doNothing();
		}
	}

	@SuppressWarnings("unchecked")
	private String reflect() throws Exception {
		// origin - 21.08.2024, last edit - 25.11.2024
		String res = WB.strEmpty;
		try {
			Field[] fields = this.getClass().getFields();
			for (var currField : fields) {
				currField.setAccessible(true);
				List<ModelDto> fieldValue = (List<ModelDto>) currField.get(this);

				if (fieldValue.isEmpty() != true) {
					res = res + currField.getName() + WB.strEquals + fieldValue.size() + WB.strCommaSpace;
					// res = res + currField.getName() + WB.strSpace + fieldValue.size() +
					// WB.strCommaSpace;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Abc.reflect, ex=" + ex.getMessage(), WB.strEmpty, "Abc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Abc.reflect, res=" + res, WB.strEmpty, "Abc");
		return res;
	}

	public String toString() {
		// origin - 21.11.2023, last edit - 24.08.2024
		String res = WB.strEmpty;
		try {
			res = this.reflect();
			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
			WB.addLog("Abc.toString, ex=" + ex.getMessage(), WB.strEmpty, "Abc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Abc.toString end ", WB.strEmpty, "Abc");
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 25.11.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Abc.test, ex=" + ex.getMessage(), WB.strEmpty, "Abc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Abc.test end ", WB.strEmpty, "Abc");
	}
}
