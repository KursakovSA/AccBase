import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class Abc {
	// origin - 28.09.2023, last edit - 28.08.2024
	public List<ModelDto> basic = new ArrayList<ModelDto>();
	public List<ModelDto> root = new ArrayList<ModelDto>();
	public List<ModelDto> table = new ArrayList<ModelDto>();
	public List<ModelDto> catalog = new ArrayList<ModelDto>();
	public List<ModelDto> codePay = new ArrayList<ModelDto>();
	public List<ModelDto> template = new ArrayList<ModelDto>();
	public List<ModelDto> sourceExtFile = new ArrayList<ModelDto>();
	public List<ModelDto> registerOrg = new ArrayList<ModelDto>();
	public List<ModelDto> workOutside = new ArrayList<ModelDto>();
	public List<ModelDto> collector = new ArrayList<ModelDto>();
	public List<ModelDto> update = new ArrayList<ModelDto>();
	public List<ModelDto> sectoral = new ArrayList<ModelDto>();
	public List<ModelDto> sectoralPawnshop = new ArrayList<ModelDto>();
	public List<ModelDto> listVal = new ArrayList<ModelDto>();
	public List<ModelDto> rule = new ArrayList<ModelDto>();
	public List<ModelDto> idGen = new ArrayList<ModelDto>();// TODO

	public List<ModelDto> infoBaseId = new ArrayList<ModelDto>();

	public List<ModelDto> userManualLocal = new ArrayList<ModelDto>();
	public List<ModelDto> userLocal = new ArrayList<ModelDto>(); // TOTHINK
	public List<ModelDto> templateDoc = new ArrayList<ModelDto>(); // TOTHINK
	public List<ModelDto> report = new ArrayList<ModelDto>(); // TOTHINK

	// segment
	public List<ModelDto> debt = new ArrayList<ModelDto>();
	public List<ModelDto> publicHoliday = new ArrayList<ModelDto>();
	public List<ModelDto> extraDayOff = new ArrayList<ModelDto>();

	public List<ModelDto> defaultWorkingHour = new ArrayList<ModelDto>(); // TOTHINK
	public List<ModelDto> defaultDebtIncomePersonBaseDeductionStandard = new ArrayList<ModelDto>(); // TOTHINK
	public List<ModelDto> accountMatching = new ArrayList<ModelDto>();// TOTHINK
	public List<ModelDto> accountTableClosing = new ArrayList<ModelDto>();// TOTHINK

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Abc.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Abc");
		} finally {
			Etc.doNothing();
		}
	}

//	public static int getMeterValueByDescription(List<ModelDto> partAbc, String strFilter) throws Exception {
//		// origin - 02.09.2024, last edit - 03.09.2024
//		int res = 0;
//		try {
//			String tmp = Etc.fixTrim(Abc.getMeterValueByDescription2(partAbc, strFilter));
//			if (tmp.isEmpty() == false) {
//				res = Integer.valueOf(tmp);
//			}
////			for (var currPartAbc : partAbc) {
////				if (Etc.fixTrim(currPartAbc.meterValue).isEmpty()) {// IdGenLocal must have not empty field
////																	// meterValue
////					continue;
////				}
////				if (Etc.strContains(currPartAbc.description, strFilter)) {
////					res = Integer.valueOf(Etc.fixTrim(currPartAbc.meterValue));
////				}
////			}
//		} catch (Exception ex) {
//			WB.addLog("Abc.getMeterValueByDescription, ex=" + ex.getMessage(), WB.strEmpty, "Abc");
//		} finally {
//			Etc.doNothing();
//		}
////		WB.addLog2("Abc.getMeterValueByDescription, res=" + res + ", strFilter=" + strFilter, WB.strEmpty,
////				"IdGen.Tuner");
//		return res;
//	}

	public static String getMeterValueByDescription(List<ModelDto> partAbc, String strFilter) throws Exception {
		// origin - 02.09.2024, last edit - 03.09.2024
		String res = WB.strEmpty;
		try {
			for (var currPartAbc : partAbc) {
				if (Etc.fixTrim(currPartAbc.meterValue).isEmpty()) {// IdGenLocal must have not empty field
																	// meterValue
					continue;
				}
				if (Etc.strContains(currPartAbc.description, strFilter)) {
					res = Etc.fixTrim(String.valueOf(Etc.fixTrim(currPartAbc.meterValue)));
				}
			}
		} catch (Exception ex) {
			WB.addLog("Abc.getMeterValueByDescription, ex=" + ex.getMessage(), WB.strEmpty, "Abc");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("Abc.getMeterValueByDescription, res=" + res + ", strFilter=" + strFilter, WB.strEmpty,
//				"IdGen.Tuner");
		return res;
	}

	public Abc(String dbConn) throws Exception {
		// origin - 26.11.2023, last edit - 29.08.2024
		try {
			// main
			this.basic = DAL.getByTemplate(dbConn, Qry.getMoreFilter("AbcBasic"));
			this.sectoral = ModelDto.getSubsetByMore(this.basic, "AbcSectoral");
			this.sectoralPawnshop = ModelDto.getSubsetByMore(this.basic, "Pawnshop");

			// segment
			this.debt = ModelDto.getSubset(this.basic, ModelDto.getFilter("Debt", WB.strEmpty));
			this.publicHoliday = ModelDto.getSubset(this.basic,
					ModelDto.getFilter("PublicHoliday", "Meter.PublicHoliday"));
			this.extraDayOff = ModelDto.getSubset(this.basic, ModelDto.getFilter("ExtraDayOff", "Meter.ExtraDayOff"));
			this.accountMatching = ModelDto.getSubsetByCode(this.basic, "Account.Matching");
			this.accountTableClosing = ModelDto.getSubset(this.basic,
					ModelDto.getFilter("Account.TableClosing", "Meter.Matching"));
			this.template = ModelDto.getSubsetByCode(this.basic, "Template");
			this.rule = ModelDto.getSubsetByCode(this.basic, "Rule");

			// subset
			this.infoBaseId = ModelDto.getSubsetByMore(this.basic, "InfoBaseId");
			this.userManualLocal = ModelDto.getSubsetByMore(this.basic, "UserManualLocal");
			this.sourceExtFile = ModelDto.getSubsetByMore(this.basic, "SourceExtFile");
			this.registerOrg = ModelDto.getSubsetByMore(this.basic, "RegisterOrg");
			this.workOutside = ModelDto.getSubsetByMore(this.basic, "WorkOutside");
			this.collector = ModelDto.getSubsetByMore(this.basic, "Collector");
			this.update = ModelDto.getSubsetByMore(this.basic, "AbcUpdate");
			this.table = ModelDto.getSubsetByMore(this.basic, "AbcTable");
			this.catalog = ModelDto.getSubsetByMore(this.basic, "AbcCatalog");
			this.codePay = ModelDto.getSubsetByMore(this.basic, "AbcCodePay");
			this.root = ModelDto.getSubsetByMore(this.basic, "AbcRoot");
			this.listVal = ModelDto.getSubsetByMore(this.basic, "AbcListVal");
			this.idGen = ModelDto.getSubsetByCode(this.basic, "IdGen");
		} catch (Exception ex) {
			WB.addLog("Abc.ctor(dbConn), ex=" + ex.getMessage(), WB.strEmpty, "Abc");
		} finally {
			Etc.doNothing();
		}
	}

	public Abc() throws Exception {
		// origin - 13.11.2023, last edit - 07.07.2024
		try {
		} catch (Exception ex) {
			WB.addLog("Abc.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Abc");
		} finally {
			Etc.doNothing();
		}
	}

	@SuppressWarnings("unchecked")
	private String reflect() throws Exception {
		// origin - 21.08.2024, last edit - 26.08.2024
		String res = WB.strEmpty;
		try {
			Field[] fields = this.getClass().getFields();
			for (var currField : fields) {
				currField.setAccessible(true);
				List<ModelDto> fieldValue = (List<ModelDto>) currField.get(this);

				if (fieldValue.isEmpty() != true) {
					res = res + currField.getName() + WB.strEquals + fieldValue.size() + WB.strCommaSpace; // basic=4....etc.
				}
			}
		} catch (Exception ex) {
			WB.addLog2("Abc.reflect, ex=" + ex.getMessage(), WB.strEmpty, "Abc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Abc.reflect, res=" + res, WB.strEmpty, "Abc");
		return res;
	}

	public String toString() {
		// origin - 21.11.2023, last edit - 24.08.2024
		String res = WB.strEmpty;
		try {
			res = this.reflect();
			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
			WB.addLog("Abc.toString, ex=" + ex.getMessage(), WB.strEmpty, "Abc");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Abc.toString end ", WB.strEmpty, "WB");
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 08.07.2024
		try {
			WB.addLog2("Abc.test, WB.abcLast.basic.size=" + WB.abcLast.basic.size(), WB.strEmpty, "Abc");
		} catch (Exception ex) {
			WB.addLog("Abc.test, ex=" + ex.getMessage(), WB.strEmpty, "Abc");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Abc.test end ", WB.strEmpty, "Abc");
	}
}
