import java.util.ArrayList;
import java.util.List;

public class Abc {
	// origin - 28.09.2023, last edit - 25.01.2024
	public List<ModelDto> basic = new ArrayList<ModelDto>();
	public List<ModelDto> local = new ArrayList<ModelDto>();
	public List<ModelDto> table = new ArrayList<ModelDto>();
	public List<ModelDto> catalog = new ArrayList<ModelDto>();
	public List<ModelDto> codePay = new ArrayList<ModelDto>();
	public List<ModelDto> template = new ArrayList<ModelDto>();
	public List<ModelDto> sourceExtFile = new ArrayList<ModelDto>();
	public List<ModelDto> registerOrg = new ArrayList<ModelDto>();
	public List<ModelDto> workOutside = new ArrayList<ModelDto>();
	public List<ModelDto> collector = new ArrayList<ModelDto>();
	public List<ModelDto> userLocal = new ArrayList<ModelDto>(); // TODO
	public List<ModelDto> templateDoc = new ArrayList<ModelDto>(); // TODO
	public List<ModelDto> report = new ArrayList<ModelDto>(); // TODO
	
	public static List<ModelDto> segment = new ArrayList<ModelDto>();
	public static List<ModelDto> segmentDebt = new ArrayList<ModelDto>();
	public static List<ModelDto> segmentDefault = new ArrayList<ModelDto>();
	public static List<ModelDto> segmentPublicHoliday = new ArrayList<ModelDto>();
	public static List<ModelDto> segmentExtraDayOff = new ArrayList<ModelDto>();
	public static List<ModelDto> segmentNotWorkDay = new ArrayList<ModelDto>();
	
	static {
		segment.add(ModelDto.getFilter("PublicHoliday.NewYearDay", "Meter.PublicHoliday"));
		segment.add(ModelDto.getFilter("PublicHoliday.InternationalWomenDay", "Meter.PublicHoliday"));
		segment.add(ModelDto.getFilter("PublicHoliday.NauryzMeiramy", "Meter.PublicHoliday"));
		segment.add(ModelDto.getFilter("PublicHoliday.UnityDay", "Meter.PublicHoliday"));
		segment.add(ModelDto.getFilter("PublicHoliday.DefenderFatherland Day", "Meter.PublicHoliday"));
		segment.add(ModelDto.getFilter("PublicHoliday.VictoryDay", "Meter.PublicHoliday"));
		segment.add(ModelDto.getFilter("PublicHoliday.ConstitutionDay", "Meter.PublicHoliday"));
		segment.add(ModelDto.getFilter("PublicHoliday.IndependenceDay", "Meter.PublicHoliday"));
		segment.add(ModelDto.getFilter("PublicHoliday.FirstPresidentDay", "Meter.PublicHoliday"));
		segment.add(ModelDto.getFilter("PublicHoliday.RepublicDay", "Meter.PublicHoliday"));
		
		segment.add(ModelDto.getFilter("ExtraDayOff.OrthodoxChristmasDay", "Meter.ExtraDayOff"));
		segment.add(ModelDto.getFilter("ExtraDayOff.KurbanAit", "Meter.ExtraDayOff"));
		
		segment.add(ModelDto.getFilter("Debt.MinRate", "Meter.Amount"));
		segment.add(ModelDto.getFilter("Debt.MinSalary", "Meter.Amount"));
		
		segment.add(ModelDto.getFilter("Debt.GFSS.RateBasic", "Meter.Rate"));
		segment.add(ModelDto.getFilter("Debt.IncomePerson.RateBasic", "Meter.Rate"));
		segment.add(ModelDto.getFilter("Debt.IncomePerson.RateForeigner", "Meter.Rate"));
		segment.add(ModelDto.getFilter("Debt.Pension.OPV.RateBasic", "Meter.Rate"));
		segment.add(ModelDto.getFilter("Debt.OSMS.EmployeePay.RateBasic", "Meter.Rate"));
		segment.add(ModelDto.getFilter("Debt.OSMS.EmployerFee.RateBasic", "Meter.Rate"));
		segment.add(ModelDto.getFilter("Debt.SN.RateBasic", "Meter.Rate"));
		segment.add(ModelDto.getFilter("Debt.GFSS.Base.MaxLimit", "Meter.Quantity"));
		segment.add(ModelDto.getFilter("Debt.Pension.Base.MaxLimit", "Meter.Quantity"));
		segment.add(ModelDto.getFilter("Debt.OSMS.Base.MaxLimit", "Meter.Quantity"));
		segment.add(ModelDto.getFilter("Debt.OSMS.Base.MinLimit", "Meter.Quantity"));
		segment.add(ModelDto.getFilter("Debt.DepreciationTax.Rate.Group1", "Meter.Rate"));
		segment.add(ModelDto.getFilter("Debt.DepreciationTax.Rate.Group2", "Meter.Rate"));
		segment.add(ModelDto.getFilter("Debt.DepreciationTax.Rate.Group3", "Meter.Rate"));
		segment.add(ModelDto.getFilter("Debt.DepreciationTax.Rate.Group4", "Meter.Rate"));
		segment.add(ModelDto.getFilter("Debt.VAT.Import.RateBasic", "Meter.Rate"));
		segment.add(ModelDto.getFilter("Debt.VAT.Purchase.RateBasic", "Meter.Rate"));
		segment.add(ModelDto.getFilter("Debt.VAT.Purchase.RateReduce", "Meter.Rate"));
		segment.add(ModelDto.getFilter("Debt.VAT.Sell.RateBasic", "Meter.Rate"));
		segment.add(ModelDto.getFilter("Debt.VAT.Sell.RateReduce", "Meter.Rate"));
		
		segment.add(ModelDto.getFilter("Default.WorkHourInWorkDay", "Meter.Time"));
		segment.add(ModelDto.getFilter("Default.Debt.IncomePerson.Base.Deduction.Standard", "Meter.Quantity"));
		
		//subset segment
		try {
			Abc.segmentDebt = ModelDto.getSubsetByCode(Abc.segment, "Debt");
		} catch (Exception ex) {
			WB.addLog("Abc.static ctor Abc.segmentDebt, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "Abc");
		} finally {
			Etc.doNothing();
		}
		try {
			Abc.segmentPublicHoliday = ModelDto.getSubsetByCode(Abc.segment, "PublicHoliday");
		} catch (Exception ex) {
			WB.addLog("Abc.static ctor Abc.segmentPublicHoliday, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "Abc");
		} finally {
			Etc.doNothing();
		}
		try {
			Abc.segmentExtraDayOff = ModelDto.getSubsetByCode(Abc.segment, "ExtraDayOff");
		} catch (Exception ex) {
			WB.addLog("Abc.static ctor Abc.segmentExtraDayOff, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "Abc");
		} finally {
			Etc.doNothing();
		}
		Abc.segmentNotWorkDay.addAll(Abc.segmentPublicHoliday);
		Abc.segmentNotWorkDay.addAll(Abc.segmentExtraDayOff);
	}

	public Abc(String dbConn) throws Exception {
		// origin - 26.11.2023, last edit - 18.01.2024
		try {
			//main
			this.basic = DAL.getTemplateMore(dbConn, Qry.getMoreFilter("AbcBasic"));
			this.local = DAL.getTemplateMore(dbConn, Qry.getMoreFilter("AbcLocal"));
			
			//subset
			this.sourceExtFile = ModelDto.getSubsetByMore(this.local, "SourceExtFile");
			this.registerOrg = ModelDto.getSubsetByMore(this.local, "RegisterOrg");
			this.workOutside = ModelDto.getSubsetByMore(this.local, "WorkOutside");
			this.collector = ModelDto.getSubsetByMore(this.local, "Collector");
			this.table = ModelDto.getSubsetByMore(this.basic, "AbcTable");
			this.catalog = ModelDto.getSubsetByMore(this.basic, "AbcCatalog");
			this.codePay = ModelDto.getSubsetByMore(this.basic, "AbcCodePay");
			this.template = ModelDto.getSubsetByMore(this.basic, "AbcTemplate");
		} catch (Exception ex) {
			WB.addLog("Abc.ctor(dbConn), ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "Abc");
		} finally {
			Etc.doNothing();
		}
	}

	public Abc() {
		// origin - 13.11.2023, last edit - 27.11.2023
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 05.12.2023
	}

	public String toString() {
		// origin - 21.11.2023, last edit - 25.01.2024
		String res = "";
		
		res = appender(res, formatter("Abc.segment", Abc.segment));
		res = appender(res, formatter("Abc.segmentDebt", Abc.segmentDebt));
		res = appender(res, formatter("Abc.segmentPublicHoliday", Abc.segmentPublicHoliday));
		res = appender(res, formatter("Abc.segmentExtraDayOff", Abc.segmentExtraDayOff));
		res = appender(res, formatter("Abc.segmentNotWorkDay", Abc.segmentNotWorkDay));
		
		res = appender(res, formatter("this.basic", this.basic));
		res = appender(res, formatter("this.local", this.local));
		res = appender(res, formatter("this.sourceExtFile", this.sourceExtFile));
		res = appender(res, formatter("this.workOutside", this.workOutside));
		res = appender(res, formatter("this.collector", this.collector));
		res = appender(res, formatter("this.registerOrg", this.registerOrg));
		res = appender(res, formatter("this.table", this.table));
		res = appender(res, formatter("this.catalog", this.catalog));
		res = appender(res, formatter("this.codePay", this.codePay));
		res = appender(res, formatter("this.template", this.template));
		res = appender(res, formatter("this.user", this.userLocal));
		res = appender(res, formatter("this.report", this.report));
		
		res = "{" + res + "}";
		return res;
	}

	private static String appender(String strRes, String strAdd) {
		// origin - 31.12.2023, last edit - 31.12.2023
		String res = strRes;
		if (strAdd.isEmpty() != true) {
			res = res + strAdd;
		}
		return res;
	}

	private String formatter(String componentAbcName, List<ModelDto> componentAbc) {
		// origin - 30.12.2023, last edit - 30.12.2023
		String res = "";
		try {
			if (componentAbc.isEmpty() != true) {
				res = res + componentAbcName + "=" + componentAbc.size() + ", ";
			}
		} catch (Exception ex) {
			WB.addLog("Abc.formatter, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "Abc");
		} finally {
			Etc.doNothing();
		}
		return res;
	}
}
