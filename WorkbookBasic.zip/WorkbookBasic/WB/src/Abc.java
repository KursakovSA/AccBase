import java.util.ArrayList;
import java.util.List;

public class Abc {
	// origin - 28.09.2023, last edit - 31.05.2024
	public List<ModelDto> basic = new ArrayList<ModelDto>();
	public List<ModelDto> local = new ArrayList<ModelDto>();
	public List<ModelDto> table = new ArrayList<ModelDto>();
	public List<ModelDto> catalog = new ArrayList<ModelDto>();
	public List<ModelDto> codePay = new ArrayList<ModelDto>();
	public List<ModelDto> template = new ArrayList<ModelDto>();
	public List<ModelDto> sourceExtFile = new ArrayList<ModelDto>();
	public List<ModelDto> registerOrg = new ArrayList<ModelDto>();
	public List<ModelDto> workOutside = new ArrayList<ModelDto>();
	public List<ModelDto> collector = new ArrayList<ModelDto>();
	public List<ModelDto> update = new ArrayList<ModelDto>();
	public List<ModelDto> sectoral = new ArrayList<ModelDto>();
	public List<ModelDto> sectoralPawnshop = new ArrayList<ModelDto>();
	
	public List<ModelDto> infoBaseId = new ArrayList<ModelDto>();
	
	public List<ModelDto> userManualLocal = new ArrayList<ModelDto>();
	public List<ModelDto> userLocal = new ArrayList<ModelDto>();  // TOTHINK
	public List<ModelDto> templateDoc = new ArrayList<ModelDto>(); // TOTHINK
	public List<ModelDto> report = new ArrayList<ModelDto>(); // TOTHINK

	// segment
	public List<ModelDto> debt = new ArrayList<ModelDto>();
	public List<ModelDto> publicHoliday = new ArrayList<ModelDto>();
	public List<ModelDto> extraDayOff = new ArrayList<ModelDto>();
	//public List<ModelDto> notWorkday = new ArrayList<ModelDto>();
	
	public List<ModelDto> defaultWorkingHour = new ArrayList<ModelDto>(); // TOTHINK
	public List<ModelDto> defaultDebtIncomePersonBaseDeductionStandard = new ArrayList<ModelDto>(); // TOTHINK
	public List<ModelDto> accountMatching = new ArrayList<ModelDto>();// TOTHINK
	public List<ModelDto> accountTableClosing = new ArrayList<ModelDto>();// TOTHINK

	public Abc(String dbConn) throws Exception {
		// origin - 26.11.2023, last edit - 16.06.2024
		try {
			// main
			this.basic = DAL.getByTemplate(dbConn, Qry.getMoreFilter("AbcBasic"));
			this.local = DAL.getByTemplate(dbConn, Qry.getMoreFilter("AbcLocal"));
			this.sectoral = DAL.getByTemplate(dbConn, Qry.getMoreFilter("AbcSectoral"));
			this.sectoralPawnshop = DAL.getByTemplate(dbConn, Qry.getMoreFilter("Pawnshop"));

			// segment
			this.debt = ModelDto.getSubset(this.basic, ModelDto.getFilter("Debt", ""));
			this.publicHoliday = ModelDto.getSubset(this.basic,
					ModelDto.getFilter("PublicHoliday", "Meter.PublicHoliday"));
			this.extraDayOff = ModelDto.getSubset(this.basic, ModelDto.getFilter("ExtraDayOff", "Meter.ExtraDayOff"));
			this.accountMatching = ModelDto.getSubsetByCode(this.basic, "Account.Matching");
			this.accountTableClosing = ModelDto.getSubset(this.basic,
					ModelDto.getFilter("Account.TableClosing", "Meter.Matching"));
			this.template = ModelDto.getSubsetByCode(this.basic, "Template");

			// subset
			this.infoBaseId = ModelDto.getSubsetByMore(this.basic, "InfoBaseId");//ex. "AbcBasic=Workbook.Basic;InfoBaseId=LocalBase1;"
			this.userManualLocal = ModelDto.getSubsetByMore(this.local, "UserManualLocal");
			this.sourceExtFile = ModelDto.getSubsetByMore(this.local, "SourceExtFile");
			this.registerOrg = ModelDto.getSubsetByMore(this.local, "RegisterOrg");
			this.workOutside = ModelDto.getSubsetByMore(this.local, "WorkOutside");
			this.collector = ModelDto.getSubsetByMore(this.local, "Collector");
			this.update = ModelDto.getSubsetByMore(this.basic, "AbcUpdate");
			this.table = ModelDto.getSubsetByMore(this.basic, "AbcTable");
			this.catalog = ModelDto.getSubsetByMore(this.basic, "AbcCatalog");
			this.codePay = ModelDto.getSubsetByMore(this.basic, "AbcCodePay");
			//this.template = ModelDto.getSubsetByMore(this.basic, "AbcTemplate");
		} catch (Exception ex) {
			WB.addLog("Abc.ctor(dbConn), ex=" + ex.getMessage(), "", "Abc");
		} finally {
			Etc.doNothing();
		}
	}

	public Abc() {
		// origin - 13.11.2023, last edit - 27.11.2023
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 05.12.2023
	}

	public String toString() {
		// origin - 21.11.2023, last edit - 16.06.2024
		String res = "";
		res = appender(res, formatter("this.basic", this.basic));
		res = appender(res, formatter("this.local", this.local));
		res = appender(res, formatter("this.sectoral", this.sectoral));
		res = appender(res, formatter("this.sectoralPawnshop", this.sectoralPawnshop));
		res = appender(res, formatter("this.userManualLocal", this.userManualLocal));
		res = appender(res, formatter("this.infoBaseId", this.infoBaseId));

		res = appender(res, formatter("this.debt", this.debt));
		res = appender(res, formatter("this.publicHoliday", this.publicHoliday));
		res = appender(res, formatter("this.extraDayOff", this.extraDayOff));
		res = appender(res, formatter("this.accountMatching", this.accountMatching));
		res = appender(res, formatter("this.accountTableClosing", this.accountTableClosing));
		res = appender(res, formatter("this.template", this.template));

		res = appender(res, formatter("this.sourceExtFile", this.sourceExtFile));
		res = appender(res, formatter("this.workOutside", this.workOutside));
		res = appender(res, formatter("this.collector", this.collector));
		res = appender(res, formatter("this.update", this.update));
		res = appender(res, formatter("this.registerOrg", this.registerOrg));
		res = appender(res, formatter("this.table", this.table));
		res = appender(res, formatter("this.catalog", this.catalog));
		res = appender(res, formatter("this.codePay", this.codePay));
		res = appender(res, formatter("this.userLocal", this.userLocal));
		res = appender(res, formatter("this.report", this.report));

		res = "{" + res + "}";
		return res;
	}

	private static String appender(String strRes, String strAdd) {
		// origin - 31.12.2023, last edit - 31.12.2023
		String res = strRes;
		if (strAdd.isEmpty() != true) {
			res = res + strAdd;
		}
		return res;
	}

	private String formatter(String componentAbcName, List<ModelDto> componentAbc) {
		// origin - 30.12.2023, last edit - 23.05.2024
		String res = "";
		try {
			if (componentAbc.isEmpty() != true) {
				res = res + componentAbcName + "=" + componentAbc.size() + ", ";
			}
		} catch (Exception ex) {
			WB.addLog("Abc.formatter, ex=" + ex.getMessage(), "", "Abc");
		} finally {
			Etc.doNothing();
		}
		return res;
	}
}
