import java.util.ArrayList;
import java.util.List;

public class Abc {
	// origin - 28.09.2023, last edit - 16.01.2024
	public List<ModelDto> basic = new ArrayList<ModelDto>();
	public List<ModelDto> local = new ArrayList<ModelDto>();
	public List<ModelDto> table = new ArrayList<ModelDto>();
	public List<ModelDto> catalog = new ArrayList<ModelDto>();
	public List<ModelDto> codePay = new ArrayList<ModelDto>();
	public List<ModelDto> template = new ArrayList<ModelDto>();
	public List<ModelDto> sourceExtFile = new ArrayList<ModelDto>();
	public List<ModelDto> registerOrg = new ArrayList<ModelDto>();
	public List<ModelDto> workOutside = new ArrayList<ModelDto>();
	public List<ModelDto> collector = new ArrayList<ModelDto>();
	public List<ModelDto> userLocal = new ArrayList<ModelDto>(); // TODO
	public List<ModelDto> templateDoc = new ArrayList<ModelDto>(); // TODO
	public List<ModelDto> report = new ArrayList<ModelDto>(); // TODO
	
	public static List<ModelDto> segment = new ArrayList<ModelDto>();
	
	static {//TODO do full list segment fill
		segment.add(ModelDto.getFilter("MinRate", "Meter.Amount"));
		segment.add(ModelDto.getFilter("MinSalary", "Meter.Amount"));
		segment.add(ModelDto.getFilter("Debt.VAT.Sell.RateBasic", "Meter.Rate"));
	}

	public Abc(String dbConn) throws Exception {
		// origin - 26.11.2023, last edit - 16.01.2024
		try {
			//main
			this.basic = DAL.getTemplateMore(dbConn, Qry.getMoreFilter("AbcBasic"));
			this.local = DAL.getTemplateMore(dbConn, Qry.getMoreFilter("AbcLocal"));
			
			//subset
			this.sourceExtFile = ModelDto.getSubsetByMore(this.local, "SourceExtFile");
			this.registerOrg = ModelDto.getSubsetByMore(this.local, "RegisterOrg");
			this.workOutside = ModelDto.getSubsetByMore(this.local, "WorkOutside");
			this.collector = ModelDto.getSubsetByMore(this.local, "Collector");
			this.table = ModelDto.getSubsetByMore(this.basic, "AbcTable");
			this.catalog = ModelDto.getSubsetByMore(this.basic, "AbcCatalog");
			this.codePay = ModelDto.getSubsetByMore(this.basic, "AbcCodePay");
			this.template = ModelDto.getSubsetByMore(this.basic, "AbcTemplate");
		} catch (Exception ex) {
			Logger.add("Abc.ctor(dbConn), ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "Abc");
		} finally {
			Etc.doNothing();
		}
	}

	public Abc() {
		// origin - 13.11.2023, last edit - 27.11.2023
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 05.12.2023
	}

	public String toString() {
		// origin - 21.11.2023, last edit - 16.01.2024
		String res = "";
		res = appender(res, formatter("basic", this.basic));
		res = appender(res, formatter("local", this.local));
		res = appender(res, formatter("sourceExtFile", this.sourceExtFile));
		res = appender(res, formatter("workOutside", this.workOutside));
		res = appender(res, formatter("collector", this.collector));
		res = appender(res, formatter("registerOrg", this.registerOrg));
		res = appender(res, formatter("table", this.table));
		res = appender(res, formatter("catalog", this.catalog));
		res = appender(res, formatter("codePay", this.codePay));
		res = appender(res, formatter("template", this.template));
		res = appender(res, formatter("user", this.userLocal));
		res = appender(res, formatter("report", this.report));
		//res = appender(res, formatter("segmentTax", this.segmentTax));
		res = "{" + res + "}";
		return res;
	}

	private static String appender(String strRes, String strAdd) {
		// origin - 31.12.2023, last edit - 31.12.2023
		String res = strRes;
		if (strAdd.isEmpty() != true) {
			res = res + strAdd;
		}
		return res;
	}

	private String formatter(String componentAbcName, List<ModelDto> componentAbc) {
		// origin - 30.12.2023, last edit - 30.12.2023
		String res = "";
		try {
			if (componentAbc.isEmpty() != true) {
				res = res + componentAbcName + "=" + componentAbc.size() + ", ";
			}
		} catch (Exception ex) {
			Logger.add("Abc.addStrAbcComp, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "Abc");
		} finally {
			Etc.doNothing();
		}
		return res;
	}
}
