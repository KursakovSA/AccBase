import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;
import java.util.stream.Stream;

public class Abc {
	// origin - 28.09.2023, last edit - 08.12.2023
	public List<ModelDto> basic;
	public List<ModelDto> catalog;
	public List<ModelDto> codePay;
	public List<ModelDto> template;
	public TreeSet<String> storeFace; // TODO
	public TreeSet<String> userFace; // TODO
	public TreeSet<String> departmentFace; // TODO
	public TreeSet<String> cashFace; // TODO
	public TreeSet<String> bankFace; // TODO
	public TreeSet<String> staffTableFace; // TODO
	public TreeSet<String> templateDoc; // TODO
	public TreeSet<String> report; // TODO
	public TreeSet<String> segmentTax; // TODO

	public static Abc getBasic(String conn) {
		// origin - 28.11.2023, last edit - 12.12.2023
		Abc res = new Abc();
		try {
			res = new Abc(conn, Qry.templateMoreAbcBasic);
			//Logger.add2("getAbc, abc=" + res + ", conn=" + conn, "", "Abc");
		} catch (Exception ex) {
			Logger.add("getAbc, ex=" + ex.getMessage(), "StackTrace=" + ex.getStackTrace(), "Abc");
		}
		return res;
	}

	private static List<ModelDto> getSubsetBasic(List<ModelDto> basic, String subStrMore) throws Exception {
		// origin - 29.11.2023, last edit - 01.12.2023
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = basic.stream();
			basicStream.filter(n -> n.more.toLowerCase().contains(subStrMore.toLowerCase()))
					.forEach((x) -> res.add(x));
//			for (var currBasic : basic) {
//				if (currBasic.more.toLowerCase().contains(templateMore.toLowerCase())) {
//					res.add(currBasic);	
//				}
//			}
		} catch (Exception ex) {
			Logger.add("getSubsetAbc, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "Abc");
		}
		//Logger.add2("getSubsetAbc, res.size=" + res.size() + ", subStrMore=" + subStrMore, "", "Abc");
		return res;
	}

	public Abc(String DbConn, String qry) throws Exception {
		// origin - 26.11.2023, last edit - 04.12.2023
		try {
			List<ModelDto> tmpBasic = DAL.getBasic(DbConn, qry);
			this.basic = tmpBasic;
			this.catalog = getSubsetBasic(tmpBasic, "AbcCatalog");
			this.codePay = getSubsetBasic(tmpBasic, "AbcCodePay");
			this.template = getSubsetBasic(tmpBasic, "Template");
		} catch (Exception ex) {
			Logger.add("Abc.ctor.basic, ex=" + ex.getMessage()+ ", StackTrace=" + ex.getStackTrace(), "", "Abc");
		} finally {
		}
	}

	public Abc() {
		// origin - 13.11.2023, last edit - 27.11.2023
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 05.12.2023
	}

	public String toString() {
		// origin - 21.11.2023, last edit - 01.12.2023
		String res = "";
		if (this.basic.isEmpty() != true) {
			res = res + "basic.size=" + this.basic.size();
		}
		if (this.catalog.isEmpty() != true) {
			res = res + ", catalog.size=" + this.catalog.size();
		}
		if (this.codePay.isEmpty() != true) {
			res = res + ", codePay.size=" + this.codePay.size();
		}
		if (this.template.isEmpty() != true) {
			res = res + ", template.size=" + this.template.size();
		}
//		if (this.storeFace.isEmpty() != true) {
//			res = res + ", storeFace.size=" + this.storeFace.size();
//		}
//		if (this.userFace.isEmpty() != true) {
//			res = res + ", userFace.size=" + this.userFace.size();
//		}
//		if (this.departmentFace.isEmpty() != true) {
//			res = res + ", departmentFace.size=" + this.departmentFace.size();
//		}
//		if (this.cashFace.isEmpty() != true) {
//			res = res + ", cashFace.size=" + this.cashFace.size();
//		}
//		if (this.bankFace.isEmpty() != true) {
//			res = res + ", bankFace.size=" + this.bankFace.size();
//		}
//		if (this.staffTableFace.isEmpty() != true) {
//			res = res + ", staffTableFace.size=" + this.staffTableFace.size();
//		}
//		if (this.templateDoc.isEmpty() != true) {
//			res = res + ", templateDoc.size=" + this.templateDoc.size();
//		}
//		if (this.report.isEmpty() != true) {
//			res = res + ", report.size=" + this.report.size();
//		}
//		if (this.segmentTax.isEmpty() != true) {
//			res = res + ", segmentTax.size=" + this.segmentTax.size();
//		}
		res = "{" + res + "}";
		return res;
	}
}
