import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class ReadSet {
	// origin - 05.10.2024, last edit - 25.11.2024

	public static String getMeterValueByContainsDescription(List<ModelDto> partAbc, String strFilter) throws Exception {
		// origin - 02.09.2024, last edit - 25.11.2024
		String res = WB.strEmpty;
		try {
			for (var currPartAbc : partAbc) { // IdGenLocal must have not empty field meterValue
				if (Etc.fixTrim(currPartAbc.meterValue).isEmpty()) {
					continue;
				}
				if (Etc.strContains(currPartAbc.description, strFilter)) {
					res = Etc.fixTrim(String.valueOf(Etc.fixTrim(currPartAbc.meterValue)));
				}
			}
		} catch (Exception ex) {
			WB.addLog("ReadSet.getMeterValueByContainsDescription, ex=" + ex.getMessage(), WB.strEmpty, "ReadSet");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ReadSet.getMeterValueByContainsDescription, res=" + res + ",
		// strFilter=" + strFilter, WB.strEmpty, "ReadSet");
		return res;
	}

	public static List<ModelDto> getEqualsByRole(List<ModelDto> set, String subStr) throws Exception {
		// origin - 24.11.2024, last edit - 25.11.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = set.stream();
			basicStream.filter(n -> n.role.toLowerCase().equals(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ReadSet.getEqualsByRole, ex=" + ex.getMessage(), WB.strEmpty, "ReadSet");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ReadSet.getEqualsByRole, res.size=" + res.size() + ",
		// subStr=" + subStr, WB.strEmpty, "ReadSet");
		return res;
	}

	public static List<ModelDto> getEqualsByParent(List<ModelDto> set, String subStr) throws Exception {
		// origin - 02.08.2024, last edit - 25.11.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = set.stream();
			basicStream.filter(n -> n.parent.toLowerCase().equals(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ReadSet.getEqualsByParent, ex=" + ex.getMessage(), WB.strEmpty, "ReadSet");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ReadSet.getEqualsByParent, res.size=" + res.size() + ",
		// subStr=" + subStr, WB.strEmpty, "ReadSet");
		return res;
	}

	public static List<ModelDto> getEqualsByDescription(List<ModelDto> set, String subStr) throws Exception {
		// origin - 02.09.2024, last edit - 25.11.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = set.stream();
			basicStream.filter(n -> n.description.toLowerCase().equals(subStr.toLowerCase()))
					.forEach((x) -> res.add(x)); // contains(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ReadSet.getEqualsByDescription, ex=" + ex.getMessage(), WB.strEmpty, "ReadSet");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ReadSet.getEqualsByDescription, res.size=" + res.size() + ",
		// subStr=" +subStr, WB.strEmpty, "ReadSet");
		return res;
	}

	public static List<ModelDto> getContainsByMore(List<ModelDto> set, String subStr) throws Exception {
		// origin - 29.11.2023, last edit - 25.11.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = set.stream();
			basicStream.filter(n -> n.more.toLowerCase().contains(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ReadSet.getContainsByMore, ex=" + ex.getMessage(), WB.strEmpty, "ReadSet");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ReadSet.getContainsByMore, res.size=" + res.size() + ", subStr="
		// +subStr,
		// WB.strEmpty, "ReadSet");
		return res;
	}

	public static List<ModelDto> getContainsByCode(List<ModelDto> set, String subStr) throws Exception {
		// origin - 23.11.2024, last edit - 23.11.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = set.stream();
			basicStream.filter(n -> n.code.toLowerCase().contains(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ReadSet.getContainsByCode, ex=" + ex.getMessage(), WB.strEmpty, "ReadSet");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ReadSet.getContainsByCode, res.size=" + res.size() + ", subStr="
		// +subStr, WB.strEmpty, "ReadSet");
		return res;
	}

	public static List<ModelDto> getEqualsByCode(List<ModelDto> set, String subStr) throws Exception {
		// origin - 07.01.2024, last edit - 25.11.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = set.stream();
			basicStream.filter(n -> n.code.toLowerCase().equals(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ReadSet.getEqualsByCode, ex=" + ex.getMessage(), WB.strEmpty, "ReadSet");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ReadSet.getEqualsByCode, res.size=" + res.size() + ", subStr="
		// +subStr,
		// WB.strEmpty, "ReadSet");
		return res;
	}

	public static List<ModelDto> getEqualsByMeter(List<ModelDto> set, String subStr) throws Exception {
		// origin - 07.01.2024, last edit - 25.11.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = set.stream();
			basicStream.filter(n -> n.meter.toLowerCase().equals(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ReadSet.getEqualsByMeter, ex=" + ex.getMessage(), WB.strEmpty, "ReadSet");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ReadSet.getEqualsByMeter, res.size=" + res.size() + ", subStr="+
		// subStr, WB.strEmpty, "ReadSet");
		return res;
	}

	public static List<ModelDto> getByFilter(List<ModelDto> set, ModelDto filter) throws Exception {
		// origin - 08.01.2024, last edit - 25.11.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		List<ModelDto> tmp = set;
		String allFilter = WB.strEmpty;
		try {
			if (filter.more.isEmpty() == false) {
				allFilter = allFilter + "filter.more=" + filter.more + WB.strCommaSpace;
				tmp = ReadSet.getContainsByMore(tmp, filter.more);
			}
			if (filter.code.isEmpty() == false) {
				allFilter = allFilter + "filter.code=" + filter.code + WB.strCommaSpace;
				tmp = ReadSet.getEqualsByCode(tmp, filter.code);
			}
			if (filter.role.isEmpty() == false) {
				allFilter = allFilter + "filter.role=" + filter.role + WB.strCommaSpace;
				tmp = ReadSet.getEqualsByRole(tmp, filter.role);
			}
			if (filter.meter.isEmpty() == false) {
				allFilter = allFilter + "filter.meter=" + filter.meter + WB.strCommaSpace;
				tmp = ReadSet.getEqualsByMeter(tmp, filter.meter);
			}
		} catch (Exception ex) {
			WB.addLog("ReadSet.getByFilter, ex=" + ex.getMessage(), WB.strEmpty, "ReadSet");
		} finally {
			Etc.doNothing();
		}
		res = tmp;
		// WB.addLog2("ReadSet.getByFilter, res.size=" + res.size() + ", allFilter=" +
		// allFilter, WB.strEmpty, "ReadSet");
		return res;
	}

	private static boolean expectedDouble(ModelDto dto) throws Exception {
		// origin - 18.09.2024, last edit - 08.10.2024
		boolean res = true;
		try {
			if (Etc.strContains(dto.meter, "Meter.PublicHoliday")) { // skip public holiday
				res = false;
			}

			if (Etc.strContains(dto.meter, "Meter.ExtraDayOff")) { // skip extra day off
				res = false;
			}

			if (Etc.strContains(dto.meter, "Meter.Matching")) { // skip account matching
				res = false;
			}
		} catch (Exception ex) {
			// WB.addLog2("ReadSet.expectedDouble, ex=" + ex.getMessage(),
			// WB.strEmpty,"ReadSet");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static double getChrono(LocalDate calcDate, List<ModelDto> subsetGlobalBasic) throws Exception {
		// origin - 09.01.2024, last edit - 13.11.2024
		double res = 0.0;
		double tmp = 0.0;
		LocalDate currDate1;
		LocalDate currDate2;
		try {
			for (var currSubset : subsetGlobalBasic) {
				if (ReadSet.expectedDouble(currSubset) == false) {
					continue;
				}

				currDate1 = DateTool.getLocalDate(currSubset.date1);// left border in data
				currDate2 = DateTool.getLocalDate(currSubset.date2);// right border in data
				tmp = Conv.getDouble(currSubset.meterValue);

				if (currDate1.isAfter(calcDate)) {
					continue;
				}

				if (currDate1.isBefore(calcDate)) {// because for curr year may be not be actual data
					res = tmp;
				}

				if (currDate1 == calcDate) {// left border hit
					res = tmp;
					break;
				}
				if (currDate2 == calcDate) {// right border hit
					res = tmp;
					break;
				}

				if ((currDate1.isBefore(calcDate)) & // range from left border to right border hit
						(currDate2.isAfter(calcDate))) {
					res = tmp;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("ReadSet.getChrono, ex=" + ex.getMessage(), WB.strEmpty, "ReadSet");
			res = 0.0;
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ReadSet.getChrono, res=" + res + ", calcDate=" +
		// calcDate, WB.strEmpty, "ReadSet");
		return res;
	}

	public static ModelDto getFilter(String subStrCode, String subStrMeter) throws Exception {
		// origin - 09.01.2024, last edit - 05.10.2024
		ModelDto res = new ModelDto();
		try {
			if (subStrCode.isEmpty() == false) {
				res.code = subStrCode;
			}
			if (subStrMeter.isEmpty() == false) {
				res.meter = subStrMeter;
			}
		} catch (Exception ex) {
			WB.addLog("ReadSet.getFilter, ex=" + ex.getMessage(), WB.strEmpty, "ReadSet");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog("ReadSet.getFilter, res=" + res, WB.strEmpty, "ReadSet");
		return res;
	}

	private ReadSet() throws Exception {
		// origin - 05.10.2024, last edit - 24.11.2024
	}

	public static void test() throws Exception {
		// origin - 05.10.2024, last edit - 05.10.2024
		try {

		} catch (

		Exception ex) {
			WB.addLog("ReadSet.test, ex=" + ex.getMessage(), WB.strEmpty, "ReadSet");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("ReadSet.test end ", WB.strEmpty, "ReadSet");
	}
}
