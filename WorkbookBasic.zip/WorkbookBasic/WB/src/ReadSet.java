import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class ReadSet {
	// origin - 05.10.2024, last edit - 05.03.2025

	public static String getMeterValueByContainsDescription(List<ModelDto> partAbc, String strFilter) throws Exception {
		// origin - 02.09.2024, last edit - 25.11.2024
		String res = WB.strEmpty;
		try {
			for (var currPartAbc : partAbc) { // IdGenLocal must have not empty field meterValue
				if (Etc.fixTrim(currPartAbc.meterValue).isEmpty()) {
					continue;
				}
				if (Etc.strContains(currPartAbc.description, strFilter)) {
					res = Etc.fixTrim(String.valueOf(Etc.fixTrim(currPartAbc.meterValue)));
				}
			}
		} catch (Exception ex) {
			WB.addLog("ReadSet.getMeterValueByContainsDescription, ex=" + ex.getMessage(), WB.strEmpty, "ReadSet");
		}
		return res;
	}

	public static List<ModelDto> getEqualsByRole(List<ModelDto> set, String subStr) throws Exception {
		// origin - 24.11.2024, last edit - 05.03.2025
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = set.stream();
			basicStream.filter(n -> n.role.toLowerCase().equals(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ReadSet.getEqualsByRole, ex=" + ex.getMessage(), WB.strEmpty, "ReadSet");
		}
		return res;
	}

	public static List<ModelDto> getEqualsByParent(List<ModelDto> set, String subStr) throws Exception {
		// origin - 02.08.2024, last edit - 05.03.2025
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = set.stream();
			basicStream.filter(n -> n.parent.toLowerCase().equals(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ReadSet.getEqualsByParent, ex=" + ex.getMessage(), WB.strEmpty, "ReadSet");
		}
		return res;
	}

	public static List<ModelDto> getEqualsByDescription(List<ModelDto> set, String subStr) throws Exception {
		// origin - 02.09.2024, last edit - 05.03.2025
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = set.stream();
			basicStream.filter(n -> n.description.toLowerCase().equals(subStr.toLowerCase()))
					.forEach((x) -> res.add(x)); // contains(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ReadSet.getEqualsByDescription, ex=" + ex.getMessage(), WB.strEmpty, "ReadSet");
		}
		return res;
	}

	public static List<ModelDto> getContainsByMore(List<ModelDto> set, String subStr) throws Exception {
		// origin - 29.11.2023, last edit - 05.03.2025
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = set.stream();
			basicStream.filter(n -> n.more.toLowerCase().contains(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ReadSet.getContainsByMore, ex=" + ex.getMessage(), WB.strEmpty, "ReadSet");
		}
		return res;
	}

//	public static List<ModelDto> getContainsByParent(List<ModelDto> set, String subStr) throws Exception {
//		// origin - 19.12.2024, last edit - 02.02.2025
//		List<ModelDto> res = new ArrayList<ModelDto>();
//		try {
//			Stream<ModelDto> basicStream = set.stream();
//			basicStream.filter(n -> n.parent.toLowerCase().contains(subStr.toLowerCase())).forEach((x) -> res.add(x));
//		} catch (Exception ex) {
//			WB.addLog("ReadSet.getContainsByParent, ex=" + ex.getMessage(), WB.strEmpty, "ReadSet");
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("ReadSet.getContainsByParent, res.size=" + res.size() + ",
//		// subStr="+subStr, WB.strEmpty, "ReadSet");
//		return res;
//	}

	public static List<ModelDto> getStartsWithByCode(List<ModelDto> set, String subStr) throws Exception {
		// origin - 17.01.2025, last edit - 05.03.2025
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = set.stream();
			basicStream.filter(n -> n.code.toLowerCase().startsWith(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ReadSet.getStartsWithByCode, ex=" + ex.getMessage(), WB.strEmpty, "ReadSet");
		}
		return res;
	}

	public static List<ModelDto> getContainsByCode(List<ModelDto> set, String subStr) throws Exception {
		// origin - 23.11.2024, last edit - 05.03.2025
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = set.stream();
			basicStream.filter(n -> n.code.toLowerCase().contains(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ReadSet.getContainsByCode, ex=" + ex.getMessage(), WB.strEmpty, "ReadSet");
		}
		return res;
	}

	public static List<ModelDto> getEqualsByCode(List<ModelDto> set, String subStr) throws Exception {
		// origin - 07.01.2024, last edit - 05.03.2025
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = set.stream();
			basicStream.filter(n -> n.code.toLowerCase().equals(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ReadSet.getEqualsByCode, ex=" + ex.getMessage() + ", subStr=" + subStr, WB.strEmpty, "ReadSet");
		}
		return res;
	}

	public static List<ModelDto> getEqualsByMeter(List<ModelDto> set, String subStr) throws Exception {
		// origin - 07.01.2024, last edit - 05.03.2025
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			Stream<ModelDto> basicStream = set.stream();
			basicStream.filter(n -> n.meter.toLowerCase().equals(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ReadSet.getEqualsByMeter, ex=" + ex.getMessage(), WB.strEmpty, "ReadSet");
		}
		return res;
	}

	public static List<ModelDto> getByFilter(List<ModelDto> set, ModelDto filter) throws Exception {
		// origin - 08.01.2024, last edit - 05.03.2025
		List<ModelDto> res = new ArrayList<ModelDto>();
		List<ModelDto> tmp = set;
		String allFilter = WB.strEmpty;
		try {
			if (filter.more.isEmpty() == false) {
				allFilter = allFilter + "filter.more=" + filter.more + WB.strCommaSpace;
				tmp = ReadSet.getContainsByMore(tmp, filter.more);
			}
			if (filter.code.isEmpty() == false) {
				allFilter = allFilter + "filter.code=" + filter.code + WB.strCommaSpace;
				tmp = ReadSet.getEqualsByCode(tmp, filter.code);
			}
			if (filter.role.isEmpty() == false) {
				allFilter = allFilter + "filter.role=" + filter.role + WB.strCommaSpace;
				tmp = ReadSet.getEqualsByRole(tmp, filter.role);
			}
			if (filter.meter.isEmpty() == false) {
				allFilter = allFilter + "filter.meter=" + filter.meter + WB.strCommaSpace;
				tmp = ReadSet.getEqualsByMeter(tmp, filter.meter);
			}
		} catch (Exception ex) {
			WB.addLog("ReadSet.getByFilter, ex=" + ex.getMessage(), WB.strEmpty, "ReadSet");
		}
		res = tmp;
		return res;
	}

	public static ModelDto getChrono(LocalDate calcDate, List<ModelDto> subsetGlobalBasic) throws Exception {
		// origin - 09.01.2024, last edit - 05.03.2025
		ModelDto res = new ModelDto();
		LocalDate currDate1;
		LocalDate currDate2;
		try {
			for (var currDto : subsetGlobalBasic) {

//				if ((currDto.meter.isEmpty()) & (currDto.unit.isEmpty())) {
//					continue;
//				}

				// skip empty row-separator in DatabaseGlobal
				if ((currDto.id.isEmpty()) & (currDto.code.isEmpty()) & (currDto.description.isEmpty())) {
					continue;
				}

				if ((currDto.date1.isEmpty()) & (currDto.date2.isEmpty())) {
					res = currDto;
				}

				currDate1 = DateTool.getLocalDate(currDto.date1);// left border in data
				currDate2 = DateTool.getLocalDate(currDto.date2);// right border in data
				// tmp = currDto;

				if (currDate1.isAfter(calcDate)) {
					continue;
				}

				if (currDate1.isBefore(calcDate)) {// because for curr year may be not be actual data
					res = currDto;
				}

				if (currDate1 == calcDate) {// left border hit
					res = currDto;
					break;
				}
				if (currDate2 == calcDate) {// right border hit
					res = currDto;
					break;
				}

				if ((currDate1.isBefore(calcDate)) & (currDto.date2.isEmpty())) {
					res = currDto;
				}

				if ((currDate1.isBefore(calcDate)) & // range from left border to right border hit
						(currDate2.isAfter(calcDate))) {
					res = currDto;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("ReadSet.getChrono, ex=" + ex.getMessage(), WB.strEmpty, "ReadSet");
		}
		return res;
	}

	public static ModelDto getFilter(String subStrCode, String subStrMeter) throws Exception {
		// origin - 09.01.2024, last edit - 05.03.2025
		ModelDto res = new ModelDto();
		try {
			if (subStrCode.isEmpty() == false) {
				res.code = subStrCode;
			}
			if (subStrMeter.isEmpty() == false) {
				res.meter = subStrMeter;
			}
		} catch (Exception ex) {
			WB.addLog("ReadSet.getFilter, ex=" + ex.getMessage(), WB.strEmpty, "ReadSet");
		}
		return res;
	}

	private ReadSet() throws Exception {
		// origin - 05.10.2024, last edit - 24.11.2024
	}

	public static void test() throws Exception {
		// origin - 05.10.2024, last edit - 05.03.2025
		try {

		} catch (

		Exception ex) {
			WB.addLog("ReadSet.test, ex=" + ex.getMessage(), WB.strEmpty, "ReadSet");
		}
	}
}