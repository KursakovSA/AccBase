import java.time.LocalDate;
import java.util.List;

public class FaceDto {
	// origin - 02.03.2025, last edit - 01.04.2025
	// common fields
	public String id, parent, date1, date2, code, description, geo, role, info, mark, more;
	// special fields
	public String crewId, departmentId, empId, cashId, paymaster, IBAN, BIC, fullName, comment, salary;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("FaceDto.static ctor, ex=" + ex.getMessage(), "", "FaceDto");
		}
	}

	public static FaceDto getChrono(LocalDate calcDate, List<FaceDto> listFaceDto, String context) throws Exception {
		// origin - 02.03.2025, last edit - 31.03.2025
		FaceDto res = new FaceDto();
		LocalDate currDate1;
		LocalDate currDate2;
		try {
			for (var currDto : listFaceDto) {
				if (context.isEmpty() == false) {
					if (Etc.strContains(currDto.info, context) == false) {
						continue;
					}
				}

//				if ((currDto.date1.isEmpty()) && (currDto.date2.isEmpty())) {
//					res = currDto;
//					break;
//				}

				currDate1 = DateTool.getLocalDate(currDto.date1);// left border in data
				currDate2 = DateTool.getLocalDate(currDto.date2);// right border in data

//				if ((currDate1 == calcDate) || (currDate2 == calcDate)) {// left border hit or right border hit
//					res = currDto;
//					break;
//				}

				// left border hit or right border hit
				if ((Etc.strEquals(currDate1.toString(), calcDate.toString()))
						|| (Etc.strEquals(currDate2.toString(), calcDate.toString()))) {
					res = currDto;
					break;
				}

				// range from left border to right border hit
				if ((currDate1.isBefore(calcDate)) && (currDate2.isAfter(calcDate))) {
					res = currDto;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("FaceDto.getChrono, ex=" + ex.getMessage(), "", "FaceDto");
		}
		return res;
	}

	public FaceDto(ModelDto Dto) throws Exception {
		// origin - 06.03.2025, last edit - 26.03.2025
		this();
		this.id = Dto.id;
		this.parent = Dto.parent;
		this.date1 = Dto.date1;
		this.date2 = Dto.date2;
		this.code = Dto.code;
		this.description = Dto.description;
		this.geo = Dto.geo;
		this.role = Dto.role;
		this.info = Dto.info;
		this.more = Dto.more;
		this.mark = Dto.mark;
	}

	public FaceDto(String Id, String Parent, String Date1, String Date2, String Code, String Description, String Geo,
			String Role, String Info, String More, String Mark) throws Exception {
		// origin - 02.03.2025, last edit - 05.03.2025
		this();
		this.id = Id;
		this.parent = Parent;
		this.date1 = Date1;
		this.date2 = Date2;
		this.code = Code;
		this.description = Description;
		this.geo = Geo;
		this.role = Role;
		this.info = Info;
		this.more = More;
		this.mark = Mark;
	}

	public void clear() throws Exception {
		// origin - 02.03.2025, last edit - 01.04.2025
		try {
			this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.more = "";
			this.geo = this.role = this.info = this.mark = "";
			this.salary = this.crewId = this.departmentId = this.empId = this.cashId = this.paymaster = this.IBAN = this.BIC = this.fullName = this.comment = "";
		} catch (Exception ex) {
			WB.addLog("FaceDto.clear, ex=" + ex.getMessage(), "", "FaceDto");
		}
	}

	public FaceDto() throws Exception {
		// origin - 02.03.2025, last edit - 02.03.2025
		this.clear();
	}

	public String toString() {
		// origin - 02.03.2025, last edit - 01.04.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);

			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addIfNotEmpty(", salary ", this.salary);
			res = res + Fmtr.addIfNotEmpty(", empId ", this.empId);
			res = res + Fmtr.addIfNotEmpty(", crewId ", this.crewId);
			res = res + Fmtr.addIfNotEmpty(", departmentId ", this.departmentId);
			res = res + Fmtr.addIfNotEmpty(", cashId ", this.cashId);
			res = res + Fmtr.addIfNotEmpty(", paymaster ", this.paymaster);
			res = res + Fmtr.addIfNotEmpty(", IBAN ", this.IBAN);
			res = res + Fmtr.addIfNotEmpty(", BIC ", this.BIC);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 02.03.2025, last edit - 20.03.2025
		try {

		} catch (Exception ex) {
			WB.addLog("FaceDto.test, ex=" + ex.getMessage(), "", "FaceDto");
		}
	}
}