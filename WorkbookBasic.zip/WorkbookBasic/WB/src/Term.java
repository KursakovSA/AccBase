import java.util.ArrayList;
import java.util.List;

public class Term extends ModelDto {
	// origin - 06.10.2023, last edit - 07.10.2024

	public static UnitVal defaultDuration;

	public String paymentDescription = WB.strEmpty; // TODO
	public List<ModelDto> paymentSchedule = new ArrayList<ModelDto>();

	public UnitVal interestRate = new UnitVal(); // sectoralPawnshop
	public UnitVal penaltyRate = new UnitVal(); // sectoralPawnshop

	public UnitVal billingCycle = new UnitVal(); // sectoralPawnshop
	public UnitVal durationDealMaxLimit = new UnitVal(); // sectoralPawnshop
	public UnitVal durationWarrantyPeriod = new UnitVal(); // sectoralPawnshop

	public UnitVal amountDealMinLimit = new UnitVal(); // sectoralPawnshop
	public UnitVal amountDealMaxLimit = new UnitVal(); // sectoralPawnshop

	public UnitVal countProlongationMaxLimit = new UnitVal(); // sectoralPawnshop
	public UnitVal amountPenaltyMaxLimit = new UnitVal(); // sectoralPawnshop

	static {
		try {
			Term.defaultDuration = new UnitVal("30(Unit.CalendarDay)"); // ??magic string??
		} catch (Exception ex) {
			WB.addLog("Term.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Term");
		} finally {
			Etc.doNothing();
		}
	}

	public Term(String deal, String term) throws Exception {// TODO
		// origin - 07.10.2024, last edit - 07.10.2024
	}

	public Term(String deal) throws Exception {// TODO
		// origin - 06.10.2024, last edit - 07.10.2024
	}

	public Term() throws Exception {
		// origin - 06.10.2024, last edit - 06.10.2024
	}

	public static void test() throws Exception {
		// origin - 06.10.2024, last edit - 06.10.2024
		try {

//			// ctor ("date1", "date2") different variants
//			Deal newDeal1 = new Deal(WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					"2024-09-01", "2024-09-11", WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					WB.strEmpty);
//			WB.addLog2("Deal.test.ctor(dto), newDeal1=" + newDeal1, WB.strEmpty, "Deal");
//			Deal newDeal2 = new Deal(WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					"2024-09-01;2024-09-06", "2024-09-11;2024-09-16", WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					WB.strEmpty, WB.strEmpty, WB.strEmpty);
//			WB.addLog2("Deal.test.ctor(dto), newDeal2=" + newDeal2, WB.strEmpty, "Deal");
//			Deal newDeal3 = new Deal(WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					"2024-09-01;2024-09-06;", "2024-09-11;2024-09-16;", WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					WB.strEmpty, WB.strEmpty, WB.strEmpty);
//			WB.addLog2("Deal.test.ctor(dto), newDeal3=" + newDeal3, WB.strEmpty, "Deal");
//			// test correctByDuration
//			Deal newDeal4 = new Deal(WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					"2024-09-01", "2024-09-11;2025-09-16;", WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					WB.strEmpty, WB.strEmpty);
//			WB.addLog2("Deal.test.ctor(dto), newDeal4=" + newDeal4, WB.strEmpty, "Deal");

		} catch (Exception ex) {
			WB.addLog("Term.test, ex=" + ex.getMessage(), WB.strEmpty, "Term");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Term.test end ", WB.strEmpty, "Term");
	}

}
