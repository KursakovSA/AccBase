import java.util.ArrayList;
import java.util.List;

public class Term { // sectoralPawnshop
	// origin - 06.11.2024, last edit - 01.05.2024
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, face1, face2, face, date1, date2, code, description, geo, role, info, more,
			mark;
	// special fields
	public UnitVal durationWarrantySpan = new UnitVal();
	public RangeVal durationDealLimit, mainDebtLimit, countPawnLimit = new RangeVal();

	public Accrual accrual = new Accrual();
	public Prolongation prolongation = new Prolongation();
	public Pool pool = new Pool();

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Term.static ctor, ex=" + ex.getMessage(), "", "Term");
		}
	}

//	public static String getTemplateCodePattern(String inTermCode) throws Exception {
//		// origin - 26.01.2025, last edit - 19.03.2025
//		String res = "";
//		inTermCode = Etc.fixTrim(inTermCode);
//		try {
//			if (strObj.isEmpty() == false) {
//				res = res + inCode + "." + Etc.fixTrim(strObj);// ex. "PawnDoc.Template1.V1.Term1" + "." + "Pool"
//			}
//		} catch (Exception ex) {
//			WB.addLog("Term.getCodeRatePattern(string,string), ex=" + ex.getMessage(), "", "Term");
//		} finally {
//			Etc.doNothing();
//		}
////		WB.addLog2("Term.getCodeRatePattern(string,string), res=" + res + ", inCode=" + inCode + ", strObj=" + strObj,
////				"", "Term");
//		return res;
//	}

	public static String getCodePattern(String inCode, String strObj) throws Exception {
		// origin - 25.01.2025, last edit - 19.03.2025
		String res = "";
		inCode = Etc.fixTrim(inCode);
		strObj = Etc.fixTrim(strObj);
		try {
			if (strObj.isEmpty() == false) {
				res = res + inCode + "." + Etc.fixTrim(strObj);// ex. "PawnDoc.Template1.V1.Term1" + "." + "Pool"
			}
		} catch (Exception ex) {
			WB.addLog("Term.getCodePattern(string,string), ex=" + ex.getMessage(), "", "Term");
		}
		return res;
	}

	public void isExist() throws Exception {
		// origin - 25.01.2025, last edit - 01.05.2025
		try {
			List<ModelDto> srcDto = new ArrayList<ModelDto>();

			srcDto = WB.abcLast.template;
			var tmp1 = ReadSet.getEqualsByCode(srcDto, this.id);
			if (tmp1.size() != 0) {
				var currDto = tmp1.getFirst();
				this.code = currDto.code;
				this.parent = currDto.parent;
				this.face1 = currDto.face1;
				this.face2 = currDto.face2;
				this.face = currDto.face;
				this.description = currDto.description;
				this.geo = currDto.geo;
				this.role = currDto.role;
				this.info = currDto.info;
				this.more = currDto.more;

				this.accrual = new Accrual(Accrual.getCodePattern(this.parent, Accrual.strAccrual),
						Term.getCodePattern(this.code, Accrual.strAccrual));
				this.prolongation = new Prolongation(Term.getCodePattern(this.code, Prolongation.strProlongation));
				this.pool = new Pool(Term.getCodePattern(this.code, Pool.strPool));

				this.durationWarrantySpan = new UnitVal(MoreVal.getFieldByKey(this.more, "DurationWarrantySpan"));
				this.durationDealLimit = new RangeVal(MoreVal.getFieldByKey(this.more, "DurationDealLimit"));
				this.mainDebtLimit = new RangeVal(MoreVal.getFieldByKey(this.more, "MainDebtLimit"));
				this.countPawnLimit = new RangeVal(MoreVal.getFieldByKey(this.more, "CountPawnLimit"));

				this.isExist = true;
			}

		} catch (Exception ex) {
			WB.addLog("Term.isExist, ex=" + ex.getMessage(), "", "Term");
		}
	}

	public Term(String Id) throws Exception {
		// origin - 25.01.2025, last edit - 25.01.2025
		this.clear();
		this.src = this.id = this.code = Id;
		this.isExist();
	}

	public Term() throws Exception {
		// origin - 25.01.2025, last edit - 25.01.2025
		this.clear();
	}

	public String toString() {
		// origin - 25.01.2025, last edit - 19.03.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src.length());
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code.length());
			res = res + Fmtr.addIfNotEmpty(", description ", this.description.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addAnyway(", accrual.interestRate ", this.accrual.interestRate.id);
			res = res + Fmtr.addAnyway(", prolongation.countLimit ", this.prolongation.countLimit.id);
			res = res + Fmtr.addAnyway(", pool.coountLimit ", this.pool.countLimit.id);

			res = res + Fmtr.addAnyway(", durationWarrantySpan ", this.durationWarrantySpan.id);
			res = res + Fmtr.addAnyway(", durationDealLimit ", this.durationDealLimit.id);
			res = res + Fmtr.addAnyway(", mainDebtLimit ", this.mainDebtLimit.id);
			res = res + Fmtr.addAnyway(", countPawnLimit ", this.countPawnLimit.id);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public void clear() throws Exception {
		// origin - 25.01.2025, last edit - 01.05.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = "Deal";
			this.id = this.parent = this.date1 = this.date2 = this.face1 = this.face2 = this.face = this.code = this.description = "";
			this.geo = this.role = this.info = this.more = this.mark = "";

			this.durationWarrantySpan = new UnitVal();
			this.durationDealLimit = this.mainDebtLimit = this.countPawnLimit = new RangeVal();
		} catch (Exception ex) {
			WB.addLog("Term.clear, ex=" + ex.getMessage(), "", "Term");
		}
	}

	public static void test() throws Exception {
		// origin - 25.01.2025, last edit - 01.05.2025
		try {

//			// ctor()
//			WB.addLog2("Term.test.ctor()=" + new Term(), "", "Term");

//			// ctor(string)
//			for (var ctorStringArg1 : new String[] { "", "PawnDoc.Template1.V1.Term1", "PawnDoc.Template1.V1.Term2" }) {
//				WB.addLog2("Term.test.ctor(string)=" + new Term(ctorStringArg1), "", "Term");
//			}

		} catch (Exception ex) {
			WB.addLog("Term.test, ex=" + ex.getMessage(), "", "Term");
		}
	}
}