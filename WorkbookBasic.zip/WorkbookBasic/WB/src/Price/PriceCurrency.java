import java.util.ArrayList;
import java.util.List;

public final class PriceCurrency {
	// origin - 27.02.2025, last edit - 21.11.2025
	// common fields
	public String table, src, id, parent, code, description, defect;
	// special fields
	// special timestamp fields
	public ListVal date1, date2, more;
	// list common + special + timestamp fields in unified val
	public List<BasicDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("PriceCurrency.static ctor, ex=" + ex.getMessage(), "", "PriceCurrency");
		}
	}

	public static UnitVal getCurr(String date1, String currencyPairId) throws Exception {// curr exchange currency
		// origin - 27.02.2025, last edit - 13.07.2026
		UnitVal res = new UnitVal();
		try {
			var val = new PriceCurrency(currencyPairId).val;
			var dto = BasicDto.getChrono(DateTool.getLocalDate(date1), val);

			if (dto.more.isEmpty() == false) {
				res = new UnitVal(dto.more, Unit.currCurrency.code);
			}

			if (dto.more.isEmpty()) {
				res = new UnitVal(UnitVal.currCurrencyInit);
			}
		} catch (Exception ex) {
			WB.addLog("PriceCurrency.getCurr(2String):UnitVal, ex=" + ex.getMessage(), "", "PriceCurrency");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 21.11.2025, last edit - 21.11.2025
		try {
		} catch (Exception ex) {
			WB.addLog("PriceCurrency.validate():void, ex=" + ex.getMessage(), "", "PriceCurrency");
		}
	}

	private void getVal() throws Exception {
		// origin - 27.02.2025, last edit - 14.07.2026
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currMore = "";
			for (int i = 0; i < this.more.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currMore = this.more.getByIndex(i);
				var tmp = new BasicDto(this.id, this.parent, currDate1, currDate2, this.code, this.description,
						currMore);
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("PriceCurrency.getVal():void, ex=" + ex.getMessage(), "", "PriceCurrency");
		}
	}

	private void isExist() throws Exception {
		// origin - 27.02.2025, last edit - 13.07.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getCodeRoleFilter(this.src, "Role.ProductList.ExchangeCurrency"), "Price");
			if (listDto.size() != 0) {
				var currDto = listDto.getFirst();
				var tmp = new SpanDate(currDto.date1, currDto.date2);
				this.date1 = new ListVal(tmp.date1);
				this.date2 = new ListVal(tmp.date2);
				this.code = DefVal.setCustom(this.code, currDto.code);
				this.id = DefVal.setCustom(this.id, currDto.id);
				this.description = DefVal.setCustom(this.description, currDto.description);
				this.more = new ListVal(currDto.more, "");
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = "";
			}
		} catch (Exception ex) {
			WB.addLog("PriceCurrency.isExist():void, ex=" + ex.getMessage(), "", "PriceCurrency");
		}
	}

	public PriceCurrency(String currencyPairId) throws Exception {
		// origin - 27.02.2025, last edit - 21.11.2025
		this.clear();
		this.src = currencyPairId;
		this.isExist();
		this.getVal();
		this.validate();
	}

	private void clear() throws Exception {
		// origin - 27.02.2025, last edit - 21.11.2025
		try {
			this.table = "Price";
			this.id = this.src = this.parent = this.code = this.description = "";
			this.more = new ListVal();
			this.val = new ArrayList<BasicDto>();
		} catch (Exception ex) {
			WB.addLog("PriceCurrency.clear():void, ex=" + ex.getMessage(), "", "PriceCurrency");
		}
	}

	public PriceCurrency() throws Exception {
		// origin - 27.02.2025, last edit - 27.02.2025
		this.clear();
	}

	public String toString() {
		// origin - 27.02.2025, last edit - 21.11.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addAnyway(", val.size ", this.val.size());
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 27.02.2025, last edit - 13.07.2026
		try {

//			WB.addLog2("PriceCurrency.test.getCurr(2String)", "", "AssetPrice");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-15", "2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "USD-KZT" }) {
//					WB.addLog2("PriceCurrency.test.getCurr(2String), res=" + PriceCurrency.getCurr(tmp1, tmp2).id
//							+ ", date1=" + tmp1 + ", currency=" + tmp2, "", "PriceCurrency");
//				}
//			}

//			WB.addLog2("PriceCurrency.test.ctor(String)", "", "PriceCurrency");
//			for (var tmp1 : Price.currencyPair) {
//				WB.addLog2("PriceCurrency.test.ctor(String)=" + new PriceCurrency(tmp1), "", "PriceCurrency");
//			}

		} catch (Exception ex) {
			WB.addLog("PriceCurrency():void.test, ex=" + ex.getMessage(), "", "PriceCurrency");
		}
	}
}