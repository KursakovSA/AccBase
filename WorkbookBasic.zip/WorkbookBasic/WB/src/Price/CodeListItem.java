import java.util.ArrayList;
import java.util.List;

public final class CodeListItem {
	// origin - 10.08.2026, last edit - 10.08.2026
	public List<String> src;
	public String id, parent, code, description, defect;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("CodeListItem.static ctor, ex=" + ex.getMessage(), "", "CodeListItem");
		}
	}

	public static List<CodeListItem> getListByCode(String id, String code) throws Exception { // TODO
		// origin - 11.08.2026, last edit - 11.08.2026
		List<CodeListItem> res = new ArrayList<CodeListItem>();
		try {

		} catch (Exception ex) {
			WB.addLog("CodeListItem.getListByCode(2String):String, ex=" + ex.getMessage(), "", "CodeListItem");
		}
		return res;
	}

	public static CodeListItem getByCode(String id, String code) throws Exception { // TODO
		// origin - 11.08.2026, last edit - 11.08.2026
		CodeListItem res = new CodeListItem();
		try {

		} catch (Exception ex) {
			WB.addLog("CodeListItem.getByCode(2String):String, ex=" + ex.getMessage(), "", "CodeListItem");
		}
		return res;
	}

	private void fix() throws Exception { // TODO
		// origin - 10.08.2026, last edit - 10.08.2026
		try {
		} catch (Exception ex) {
			WB.addLog("CodeListItem.fix():void, ex=" + ex.getMessage(), "", "CodeListItem");
		}
	}

	private void validate() throws Exception {
		// origin - 10.08.2026, last edit - 10.08.2026
		try {
			if (this.code.isEmpty()) {
				this.defect = this.defect + "empty code; ";
			}
			if (this.description.isEmpty()) {
				this.defect = this.defect + "empty description; ";
			}
		} catch (Exception ex) {
			WB.addLog("CodeListItem.validate():void, ex=" + ex.getMessage(), "", "CodeListItem");
		}
	}

	private void getPart(CodeListMap map) throws Exception {
		// origin - 10.08.2026, last edit - 10.08.2026
		try {
			if (map.code.isEmpty() == false) {
				this.code = Etc.getItemListStringIfExist(src, Integer.valueOf(map.code) - 1);// src.get(Integer.valueOf(partMap.name)
																								// - 1);
			}
			if (map.description.isEmpty() == false) {
				this.description = Etc.getItemListStringIfExist(src, Integer.valueOf(map.description) - 1);// src.get(Integer.valueOf(partMap.description)
																											// - 1);
			}
		} catch (Exception ex) {
			WB.addLog("CodeListItem.getPart():void, ex=" + ex.getMessage(), "", "CodeListItem");
		}
	}

	public CodeListItem(List<String> Src, CodeListMap map) throws Exception {
		// origin - 10.08.2026, last edit - 10.08.2026
		this.clear();
		this.src.addAll(Src);
		this.getPart(map);
		this.fix();
		this.validate();
	}

	public CodeListItem() throws Exception {
		// origin - 10.08.2026, last edit - 10.08.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 10.08.2026, last edit - 10.08.2026
		try {
			this.src = new ArrayList<String>();
			this.id = this.parent = this.description = this.defect = "";
		} catch (Exception ex) {
			WB.addLog("ProductListItem.clear():void, ex=" + ex.getMessage(), "", "ProductListItem");
		}
	}

	public String toString() {
		// origin - 10.08.2026, last edit - 11.08.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src.size ", this.src.size());
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 10.08.2026, last edit - 10.08.2026
		try {

		} catch (Exception ex) {
			WB.addLog("CodeListItem.test():void, ex=" + ex.getMessage(), "", "CodeListItem");
		}
	}
}