public final class ProductList {
	// origin - 13.11.2025, last edit - 03.08.2026
	public Unit currency;
	public ProductListDescr descr;
	public String defect;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("ProductList.static ctor, ex=" + ex.getMessage(), "", "ProductList");
		}
	}

	private void fix() throws Exception { // TODO
		// origin - 29.07.2026, last edit - 29.07.2026
		try {
		} catch (Exception ex) {
			WB.addLog("ProductList.fix():void, ex=" + ex.getMessage(), "", "ProductList");
		}
	}

	private void validate() throws Exception { // TODO
		// origin - 29.07.2026, last edit - 29.07.2026
		try {
//			if (this.item.size() == 0) {
//				this.defect = this.defect + "empty item; ";
//			}
		} catch (Exception ex) {
			WB.addLog("ProductList.validate():void, ex=" + ex.getMessage(), "", "ProductList");
		}
	}

	public ProductList(String productListId) throws Exception {
		// origin - 27.05.2026, last edit - 03.08.2026
		this.clear();
		this.descr = new ProductListDescr(productListId);
		this.fix();
		this.validate();
	}

	public ProductList() throws Exception {
		// origin - 27.05.2026, last edit - 27.05.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 22.05.2026, last edit - 03.08.2026
		try {
			this.currency = Unit.currCurrency;
			this.descr = new ProductListDescr();
			this.defect = "";
		} catch (Exception ex) {
			WB.addLog("ProductList.clear():void, ex=" + ex.getMessage(), "", "ProductList");
		}
	}

	public String toString() {
		// origin - 29.07.2026, last edit - 03.08.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("currency.id ", this.currency.id);
			res = res + Fmtr.addIfNotEmpty(", descr.id ", this.descr.id);
			res = res + Fmtr.addIfNotEmpty(", descr.partList.size ", this.descr.partList.size());
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 13.11.2025, last edit - 31.07.2026
		try {

//			WB.addLog2("ProductList.test.ctor(String)", "", "ProductList");
//			for (var tmp : new String[] { "", "Price.BasicCondition", "PriceListDescription.Root",
//					"SortamentListDescription.Root", "PriceListDescription.Tralala" }) {
//				WB.addLog2("ProductList.test.ctor(String), res=" + new ProductList(tmp), "", "ProductList");
//			}

		} catch (Exception ex) {
			WB.addLog("ProductList.test():void, ex=" + ex.getMessage(), "", "ProductList");
		}
	}
}