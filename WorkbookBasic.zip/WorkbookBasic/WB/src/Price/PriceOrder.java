public final class PriceOrder { // TODO
	// origin - 27.11.2025, last edit - 27.11.2025

	public static String getByPurchase(String faceId, String kindTaxId) throws Exception { // TODO
		// origin - 27.11.2025, last edit - 27.11.2025
		String res = "";
		try {
		} catch (Exception ex) {
			WB.addLog("PriceOrder.getByPurchase(2String):String, ex=" + ex.getMessage(), "", "PriceOrder");
		}
		return res;
	}

	public static String getBySale(String faceId, String kindTaxId) throws Exception { // TODO
		// origin - 27.11.2025, last edit - 27.11.2025
		String res = "";
		try {
		} catch (Exception ex) {
			WB.addLog("PriceOrder.getBySale(2String):String, ex=" + ex.getMessage(), "", "PriceOrder");
		}
		return res;
	}

	public static void test() throws Exception { // TODO
		// origin - 27.11.2025, last edit - 27.11.2025
		try {

		} catch (Exception ex) {
			WB.addLog("PriceOrder.test():void, ex=" + ex.getMessage(), "", "PriceOrder");
		}
	}
}