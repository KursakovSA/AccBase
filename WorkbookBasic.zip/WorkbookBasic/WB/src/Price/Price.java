import java.util.ArrayList;
import java.util.List;

public final class Price {
	// origin - 28.09.2023, last edit - 01.08.2026
	// common fields
	public String table, src, id, parent, date1, date2, code, description, more, defect, fullName, comment;
	// special fields
	public UnitVal markupBasic, saleBasic;
	public static List<String> currency, currencyPair;

	static {
		try {
			Price.currency = Geo.getCurrency(); // description = "USD", "KZT", etc.
			Price.currencyPair = Geo.getCurrencyPair(); // description = "USD-KZT", "EUR-KZT", etc.
			// WB.addLog2("Price.currency=" + Price.currency, "", "Geo");
		} catch (Exception ex) {
			WB.addLog("Price.static ctor, ex=" + ex.getMessage(), "", "Price");
		}
	}

	public static FullDto getFullDtoByList(List<String> in) throws Exception {
		// origin - 02.03.2026, last edit - 02.03.2026
		FullDto res = new FullDto();
		try {
			res.table = "Price";
			res.id = Etc.fixTrim(in.get(0));
			res.parent = Etc.fixTrim(in.get(1));
			res.date1 = Etc.fixTrim(in.get(2));
			res.date2 = Etc.fixTrim(in.get(3));
			res.code = Etc.fixTrim(in.get(4));
			res.description = Etc.fixTrim(in.get(5));
			res.more = Etc.fixTrim(in.get(6));
		} catch (

		Exception ex) {
			WB.addLog("Price.getFullDtoByList(List<String>):FullDto, ex=" + ex.getMessage(), "", "Price");
		}
		return res;
	}

	public static List<String> getListByFullDto(FullDto in) throws Exception {
		// origin - 31.01.2026, last edit - 01.03.2026
		List<String> res = new ArrayList<String>();
		try {
			res.add(in.id);
			res.add(in.parent);
			res.add(in.date1);
			res.add(in.date2);
			res.add(in.code);
			res.add(in.description);
			res.add(in.more);
		} catch (Exception ex) {
			WB.addLog("Price.getListByFullDto(FullDto):List<String>, ex=" + ex.getMessage(), "", "Price");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 21.11.2025, last edit - 21.11.2025
		try {
		} catch (Exception ex) {
			WB.addLog("Price.validate():void, ex=" + ex.getMessage(), "", "Price");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 01.08.2026, last edit - 01.08.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "Fullname");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("Price.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Price");
		}
	}

	public void getBasicCondition() throws Exception {
		// origin - 21.02.2025, last edit - 13.06.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.code), "Price");
			var dto = listDto.getFirst();
			this.markupBasic = new UnitVal(MoreVal.getFieldByKey(dto.more, "MarkupBasic"));
			this.saleBasic = new UnitVal(MoreVal.getFieldByKey(dto.more, "SaleBasic"));
		} catch (Exception ex) {
			WB.addLog("Price.getBasicCondition():void, ex=" + ex.getMessage(), "", "Price");
		}
	}

	private List<FullDto> getFastListDto() throws Exception {
		// origin - 10.08.2026, last edit - 10.08.2026
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			var tmp = WB.abcLast.price;
			res = ReadSet.getEqualsByCode(tmp, this.code);
			if (res.size() == 0) {
				res = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.code), "Price");
			}
		} catch (Exception ex) {
			WB.addLog("Price.getFastListDto():void, ex=" + ex.getMessage(), "", "Price");
		}
		return res;
	}

	private void isExist() throws Exception {
		// origin - 28.11.2024, last edit - 10.08.2026
		try {
			// var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.code),
			// "Price");
			var listDto = this.getFastListDto();
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.parent = dto.parent;
				this.date1 = dto.date1;
				this.date2 = dto.date2;
				this.code = DefVal.setCustom(this.code, dto.code);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.getFieldFromMore();
				this.getBasicCondition();
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = "";
			}
		} catch (Exception ex) {
			WB.addLog("Price.isExist():void, ex=" + ex.getMessage(), "", "Price");
		}
	}

	public Price(String Id) throws Exception {
		// origin - 28.11.2024, last edit - 21.11.2025
		this.clear();
		this.src = Id;
		if (Id.isEmpty() == false) {
			this.id = this.code = Id;
		}
		this.isExist();
		this.validate();
	}

	public Price() throws Exception {
		// origin - 05.12.2023, last edit - 19.05.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 28.11.2024, last edit - 01.08.2026
		try {
			this.table = "Price";
			this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.more = this.defect = "";
			this.fullName = this.comment = "";
			this.markupBasic = this.saleBasic = new UnitVal("0.0(Unit.Percent)");
		} catch (Exception ex) {
			WB.addLog("Price.clear():void, ex=" + ex.getMessage(), "", "Price");
		}
	}

	public String toString() {
		// origin - 27.09.2024, last edit - 01.08.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addAnyway(", markupBasic ", this.markupBasic.id);
			res = res + Fmtr.addAnyway(", saleBasic ", this.saleBasic.id);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 05.10.2025
		try {

//			WB.addLog2("Price.test.ctor(String)", "", "Price");
//			for (var tmp1 : new String[] { "Price.BasicCondition", "Price.tralala" }) {
//				WB.addLog2("Price.test.ctor(String)=" + new Price(tmp1), "", "Price");
//			}

		} catch (

		Exception ex) {
			WB.addLog("Price.test():void, ex=" + ex.getMessage(), "", "Price");
		}
	}
}