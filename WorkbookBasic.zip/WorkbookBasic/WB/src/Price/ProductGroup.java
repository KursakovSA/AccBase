import java.util.ArrayList;
import java.util.List;

public final class ProductGroup {
	// origin - 22.05.2026, last edit - 03.08.2026
	public String id, parent, date1, date2, code, description, role, more, defect, unit, fullName, comment;
	public List<String> unitLimit;

	public static List<String> getUnitLimitList(String productGroupFullName) throws Exception {
		// origin - 02.07.2026, last edit - 05.07.2026
		List<String> res = new ArrayList<String>();
		try {
			var tmp = new ProductGroup(productGroupFullName);
			if (tmp.unitLimit.size() != 0) {
				res.addAll(tmp.unitLimit);
			}
		} catch (Exception ex) {
			WB.addLog("ProductGroup.getUnitLimitList(String):List<String>, ex=" + ex.getMessage(), "", "ProductGroup");
		}
		return res;
	}

	public static List<ProductGroup> getListByProductListPartId(String productListPartId) throws Exception {
		// origin - 01.07.2026, last edit - 31.07.2026
		List<ProductGroup> res = new ArrayList<ProductGroup>();
		try {
			var tmp1 = BasicDto.getLower("Price", productListPartId);
			for (var tmp2 : tmp1) {
				if (Etc.strEquals(tmp2.role, "Role.ProductList.ProductGroup")) {
					res.add(new ProductGroup(tmp2));
				}
			}
		} catch (Exception ex) {
			WB.addLog("ProductGroup.getListByProductListPartId(String):List<ProductGroup>, ex=" + ex.getMessage(), "",
					"ProductGroup");
		}
		return res;
	}

	private void fix() throws Exception { // TODO
		// origin - 22.05.2026, last edit - 05.07.2026
		try {

		} catch (Exception ex) {
			WB.addLog("ProductGroup.fix():void, ex=" + ex.getMessage(), "", "ProductGroup");
		}
	}

	private void validate() throws Exception {
		// origin - 22.05.2026, last edit - 03.08.2026
		try {
			this.defect = Fmtr.addIfStrEmpty(this.defect, this.unit, "empty unit; ");
		} catch (Exception ex) {
			WB.addLog("ProductGroup.validate():void, ex=" + ex.getMessage(), "", "ProductGroup");
		}
	}

	private void getPart() throws Exception {
		// origin - 22.05.2026, last edit - 03.08.2026
		try {
			var tmp = MoreVal.getFieldByKey(this.more, "UnitLimit");
			String[] items = tmp.split(",");
			if (items.length > 0) {
				if (items[0].isEmpty() == false) {
					this.unit = Etc.fixTrim(items[0]); // ex. "тн"
				}

				if (items.length >= 1) {
					for (int i = 1; i < items.length; i++) {
						this.unitLimit.add(items[i]);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("ProductGroup.getPart():void, ex=" + ex.getMessage(), "", "ProductGroup");
		}
	}

	private void clear() throws Exception {
		// origin - 22.05.2026, last edit - 03.08.2026
		try {
			this.id = this.date1 = this.date2 = this.code = this.description = this.more = this.defect = this.unit = "";
			this.role = this.fullName = this.comment = "";
			this.unitLimit = new ArrayList<String>();
		} catch (Exception ex) {
			WB.addLog("ProductGroup.clear():void, ex=" + ex.getMessage(), "", "ProductGroup");
		}
	}

	public ProductGroup(BasicDto bDto) throws Exception {
		// origin - 22.05.2026, last edit - 14.07.2026
		this.clear();
		this.id = bDto.id;
		this.parent = bDto.parent;
		this.date1 = bDto.date1;
		this.date2 = bDto.date2;
		this.code = bDto.code;
		this.description = bDto.description;
		this.role = bDto.role;
		this.more = bDto.more;
		this.getFieldFromMore();
		this.getPart();
		this.fix();
		this.validate();
	}

	public ProductGroup(String productGroupFullName) throws Exception {
		// origin - 03.07.2026, last edit - 14.07.2026
		this.clear();

		var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter("Role.ProductList.ProductGroup"), "Price");
		if (listDto.size() != 0) {
			for (var tmp1 : listDto) {
				var tmp2 = MoreVal.getFieldByKey(tmp1.more, "Fullname");
				if (Etc.strEquals(tmp2, productGroupFullName)) {
					var tmp3 = new BasicDto(tmp1);
					this.id = tmp3.id;
					this.parent = tmp3.parent;
					this.date1 = tmp3.date1;
					this.date2 = tmp3.date2;
					this.code = tmp3.code;
					this.description = tmp3.description;
					this.role = tmp3.role;
					this.more = tmp3.more;
					this.getFieldFromMore();
					this.getPart();
					this.fix();
					this.validate();
					break;
				}
			}
		}
	}

	public ProductGroup() throws Exception {
		// origin - 22.05.2026, last edit - 22.05.2026
		this.clear();
	}

	private void getFieldFromMore() throws Exception {
		// origin - 01.07.2026, last edit - 05.07.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "Fullname");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("ProductGroup.getFieldFromMore():void, ex=" + ex.getMessage(), "", "ProductGroup");
		}
	}

	public String toString() {
		// origin - 22.05.2026, last edit - 03.08.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", role ", this.role);
			res = res + Fmtr.addIfNotEmpty(", productUnit ", this.unit);
			res = res + Fmtr.addIfNotEmpty(", unitLimit ", this.unitLimit);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 22.05.2026, last edit - 30.07.2026
		try {

//			WB.addLog2("ProductGroup.test.getUnitLimitList(String):List<String>", "", "ProductGroup");
//			for (var tmp1 : new String[] { "", "Спецовка", "Арматура ГОСТ 5781-82, 52544-2006", "Tralala" }) {
//				var tmp2 = ProductGroup.getUnitLimitList(tmp1);
//				WB.addLog2("ProductGroup.test.getUnitLimitList(String):List<String>, res=" + tmp2 + ", tmp1=" + tmp1,
//						"", "ProductGroup");
//			}

//			WB.addLog2("ProductGroup.test.getListByProductListPartId(String):List<ProductGroup>", "",
//					"PriceListProductGroup");
//			for (var tmp1 : new String[] { "", "PriceListDescription.Root", "Tralala" }) {
//				var tmp2 = ProductGroup.getListByProductListPartId(tmp1);
//				WB.addLog2("ProductGroup.test.getListByProductListPartId(String):List<ProductGroup>, res.size="
//						+ tmp2.size() + ", tmp1=" + tmp1, "", "ProductGroup");
//				WB.log(tmp2, "ProductGroup");
//			}

//			WB.addLog2("ProductGroup.test.ctor(String)", "", "ProductGroup");
//			for (var tmp1 : new String[] { "", "Спецовка", "Арматура ГОСТ 5781-82, 52544-2006", "Tralala" }) {
//				WB.addLog2("ProductGroup.test.ctor(String), res=" + new ProductGroup(tmp1) + ", tmp1=" + tmp1, "",
//						"ProductGroup");
//			}

		} catch (Exception ex) {
			WB.addLog("ProductGroup.test():void, ex=" + ex.getMessage(), "", "ProductGroup");
		}
	}
}