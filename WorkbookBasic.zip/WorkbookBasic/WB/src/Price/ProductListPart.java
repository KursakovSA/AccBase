import java.util.ArrayList;
import java.util.List;

public final class ProductListPart {
	// origin - 09.07.2026, last edit - 01.08.2026
	public List<String> srcList;
	public String table, id, parent, date1, date2, code, description, role, more, fullName, comment, defect, context;
	public List<ProductListPartMap> mapList;
	public List<ProductGroup> groupList;
	public List<ProductVar> varList;
	public List<ProductListItem> itemList;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("ProductListPart.static ctor, ex=" + ex.getMessage(), "", "ProductListPart");
		}
	}

	private void getItemList() throws Exception {
		// origin - 27.05.2026, last edit - 03.08.2026
		try {
			String currGroupSrcList = "";
			String tmp = "";
			String currGroupPartFullName = "";
			List<String> itemSrc = new ArrayList<String>();
			for (var currMap : this.mapList) {
				for (var currGroupPart : this.groupList) {
					currGroupPartFullName = Etc.fixTrim(currGroupPart.fullName);

					if (currGroupPartFullName.isEmpty()) {
						continue;
					}

					int countRowSrcList = 0;
					for (var currRowSrcList : this.srcList) {
						countRowSrcList = countRowSrcList + 1;
						if (countRowSrcList <= Integer.valueOf(currMap.lastLineTitle)) {
							continue;
						}

						itemSrc = List.of(currRowSrcList.split("\\|"));

						tmp = ProductListPart.getGroupNameByRowSrcList(itemSrc);
						if (tmp.isEmpty() == false) {
							currGroupSrcList = tmp;
						}

						if (Etc.strEquals(currGroupPartFullName, currGroupSrcList)) {
							var tryProductItemList = new ProductListItem(itemSrc, currMap, currGroupSrcList);
							if (tryProductItemList.defect.isEmpty()) {
								this.itemList.add(tryProductItemList);
//								WB.addLog2("ProductListPart.getItemList(), new ProductListItem=" + tryProductItemList,
//										"", "ProductListPart");
							}
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("ProductListPart.getItemList():void, ex=" + ex.getMessage(), "", "ProductListPart");
		}
	}

	private static String getGroupNameByRowSrcList(List<String> itemSrc) throws Exception {
		// origin - 30.05.2026, last edit - 02.08.2026
		String res = "";
		try {
			int count = 0;
			var tmp = "";
			for (var curr : itemSrc) {
				count = count + 1;

				tmp = Etc.fixTrim(curr);
				if (tmp.isEmpty() == false) {
					if (count == 1) { // group name stand in item=1
						res = tmp;
					}

					if (count > 1) { // for line group all item="", except 1
						res = "";
					}
				}

				if (tmp.isEmpty()) {
					if (count == 1) { // group name stand in item=1
						res = "";
						break;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("ProductListPart.getGroupNameByRowSrcList(List<String>):String, ex=" + ex.getMessage(), "",
					"ProductListPart");
		}
		return res;
	}

	private void getSrcList() throws Exception {
		// origin - 30.05.2026, last edit - 12.08.2026
		try {
			var root = new Price(this.parent);
			//var tmp1 = WB.commonDocDir + File.separator + root.fullName;
			var tmp1 = InOut.getStrPathFileByFileNameInAppDir(root.fullName);

			if (root.fullName.endsWith(".csv")) {
				var tmp2 = CSV.getListByPath(tmp1);
				this.srcList.addAll(tmp2);
				// WB.log(tmp2, "ProductListPart");
			}

//			if (root.fullName.endsWith(".xlsx")) { //TODO
//				var tmp2 = ExcelReader.read(tmp1, this.fullName);
//				WB.log(tmp2, "ProductListPart");
//			}
		} catch (Exception ex) {
			WB.addLog("ProductListPart.getSrcList():void, ex=" + ex.getMessage(), "", "ProductListPart");
		}
	}

	public static List<ProductListPart> getListByProductListId(String productListId) throws Exception {
		// origin - 16.07.2026, last edit - 16.07.2026
		List<ProductListPart> res = new ArrayList<ProductListPart>();
		try {
			var tmp1 = BasicDto.getLower("Price", productListId);
			for (var tmp2 : tmp1) {
				if (Etc.strEquals(tmp2.role, "Role.ProductList.Part")) {
					res.add(new ProductListPart(tmp2));
				}
			}
		} catch (Exception ex) {
			WB.addLog("ProductListPart.getListByProductListId(String):List<ProductListPart>, ex=" + ex.getMessage(), "",
					"ProductListPart");
		}
		return res;
	}

	private void fix() throws Exception { // TODO
		// origin - 09.07.2026, last edit - 16.07.2026
		try {
		} catch (Exception ex) {
			WB.addLog("ProductListPart.fix():void, ex=" + ex.getMessage(), "", "ProductListPart");
		}
	}

	private void validate() throws Exception {
		// origin - 09.07.2026, last edit - 31.07.2026
		try {
			if (this.varList.size() == 0) {
				this.defect = this.defect + "empty product var; ";
			}
			if (this.groupList.size() == 0) {
				this.defect = this.defect + "empty group; ";
			}
		} catch (Exception ex) {
			WB.addLog("ProductListPart.validate():void, ex=" + ex.getMessage(), "", "ProductListPart");
		}
	}

	private void isExist() throws Exception {
		// origin - 09.07.2026, last edit - 01.08.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdRoleFilter(this.id, "Role.ProductList.Part"),
					this.table);
			if (listDto.size() != 0) {
				var currDto1 = listDto.getFirst();
				this.parent = DefVal.setCustom(this.parent, currDto1.parent);
				this.getSrcList();
				this.date1 = DefVal.setCustom(this.date1, currDto1.date1);
				this.date2 = DefVal.setCustom(this.date2, currDto1.date2);
				this.code = DefVal.setCustom(this.code, currDto1.code);
				this.description = DefVal.setCustom(this.description, currDto1.description);
				this.role = DefVal.setCustom(this.role, currDto1.role);
				this.more = DefVal.setCustom(this.more, currDto1.more);
				this.varList = ProductVar.getListByProductListPartId(this.id);
				this.groupList = ProductGroup.getListByProductListPartId(this.id);
			}

			if (listDto.size() == 0) {
				this.id = this.defect = "";
			}
		} catch (Exception ex) {
			WB.addLog("ProductListPart.isExist():void, ex=" + ex.getMessage(), "", "ProductListPart");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 09.07.2026, last edit - 31.07.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "Fullname");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.context = MoreVal.getFieldByKey(this.more, "Context");
			this.mapList = ProductListPartMap.getList(MoreVal.getFieldByKey(this.more, "Map"));
		} catch (Exception ex) {
			WB.addLog("ProductListPart.getFieldFromMore():void, ex=" + ex.getMessage(), "", "ProductListPart");
		}
	}

	public ProductListPart(BasicDto bDto) throws Exception {
		// origin - 09.07.2026, last edit - 31.07.2026
		this.clear();
		this.id = bDto.id;
		this.isExist();
		this.getFieldFromMore();
		this.getItemList();
		this.fix();
		this.validate();
	}

	public ProductListPart(String Id) throws Exception {
		// origin - 17.05.2026, last edit - 31.07.2026
		this.clear();
		this.id = Etc.fixTrim(Id);
		this.isExist();
		this.getFieldFromMore();
		this.getItemList();
		this.fix();
		this.validate();
	}

	private void clear() throws Exception {
		// origin - 09.07.2026, last edit - 01.08.2026
		try {
			this.table = "Price";
			this.srcList = new ArrayList<String>();
			this.id = this.parent = this.code = this.date1 = this.date2 = this.code = this.description = this.defect = "";
			this.role = this.more = this.fullName = this.comment = this.context = "";
			this.groupList = new ArrayList<ProductGroup>();
			this.varList = new ArrayList<ProductVar>();
			this.mapList = new ArrayList<ProductListPartMap>();
			this.itemList = new ArrayList<ProductListItem>();
		} catch (Exception ex) {
			WB.addLog("ProductListPart.clear():void, ex=" + ex.getMessage(), "", "ProductListPart");
		}
	}

	public ProductListPart() throws Exception {
		// origin - 09.07.2026, last edit - 09.07.2026
		this.clear();
	}

	public String toString() {
		// origin - 09.07.2026, last edit - 01.08.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", role ", this.role);
			res = res + Fmtr.addAnyway(", varList.size ", this.varList.size());
			res = res + Fmtr.addAnyway(", groupList.size ", this.groupList.size());
			res = res + Fmtr.addAnyway(", mapList.size ", this.mapList.size());
			res = res + Fmtr.addAnyway(", srcList.size ", this.srcList.size());
			res = res + Fmtr.addAnyway(", itemList.size ", this.itemList.size());
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", more.lenght ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", context ", this.context);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 09.07.2026, last edit - 03.08.2026
		try {

//			WB.addLog2("ProductListPart.test.getGroupNameByRowSrcList(List<String>)", "", "ProductListPart");
//			for (var tmp1 : new String[] { "", "Field1,,,", "Field1,,,Field4,,Field6",
//					",Field2,Field3,Field4,Field5,Field6,Field7,Field8" }) {
//				var tmp2 = List.of(tmp1.split(","));
//				WB.addLog2(
//						"ProductListPart.test.getGroupNameByRowSrcList(List<String>), res="
//								+ ProductListPart.getGroupNameByRowSrcList(tmp2) + ", tmp2=" + tmp2,
//						"", "ProductListPart");
//			}

//			WB.addLog2("ProductListPart.test.ctor(String)", "", "ProductListPart");
//			for (var tmp1 : new String[] { "", "Price.BasicCondition", "PriceListDescription.Root.Part1",
//					"SortamentListDescription.Root.Part1", "PriceListDescription.Root.Tralala" }) {
//				WB.addLog2("ProductListPart.test.ctor(String), res=" + new ProductListPart(tmp1), "",
//						"ProductListPart");
//			}

//			WB.addLog2("ProductListPart.test.ctor(BasicDto)", "", "ProductListPart");
//			for (var tmp1 : new String[] { "", "Price.BasicCondition", "PriceListDescription.Root",
//					"PriceListDescription.Tralala" }) {
//				var tmp2 = new ProductListDescr(tmp1);
//				WB.addLog2("ProductListPart.test.ctor(BasicDto), res.size=" + tmp2.part.size() + ", tmp1=" + tmp1, "",
//						"ProductListPart");
//				for (var tmp3 : tmp2.part) {
//					WB.addLog2("ProductListPart.test.ctor(BasicDto), res=" + tmp3, "", "ProductListPart");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("ProductListPart.test():void, ex=" + ex.getMessage(), "", "ProductListPart");
		}
	}
}