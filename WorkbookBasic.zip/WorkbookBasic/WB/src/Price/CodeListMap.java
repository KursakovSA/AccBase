public final class CodeListMap {
	// origin - 10.08.2026, last edit - 11.08.2026
	public String src, defect;
	public String code; // ex. 2 - column 2
	public String description; // ex. 4 - column 4

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("CodeListMap.static ctor, ex=" + ex.getMessage(), "", "CodeListMap");
		}
	}

	private void fix() throws Exception {
		// origin - 11.08.2026, last edit - 11.08.2026
		try {
		} catch (Exception ex) {
			WB.addLog("CodeListMap.fix():void, ex=" + ex.getMessage(), "", "CodeListMap");
		}
	}

	private void validate() throws Exception {
		// origin - 11.08.2026, last edit - 11.08.2026
		try {
			this.defect = Fmtr.addIfStrEmpty(this.defect, this.code, "empty code; ");
			this.defect = Fmtr.addIfStrEmpty(this.defect, this.description, "empty description; ");
		} catch (Exception ex) {
			WB.addLog("CodeListMap.validate():void, ex=" + ex.getMessage(), "", "CodeListMap");
		}
	}

	private void getPart() throws Exception {
		// origin - 11.08.2026, last edit - 11.08.2026
		try {
			String[] items = this.src.split(",");
			if (items.length > 0) {
				this.code = items[0]; // ex. 2 - 2 column

				if (items.length > 1) { // ex. 3 - 3 column
					this.description = items[1];
				}
			}
		} catch (Exception ex) {
			WB.addLog("CodeListMap.getPart():void, ex=" + ex.getMessage(), "", "CodeListMap");
		}
	}

	public CodeListMap(String Src) throws Exception {
		// origin - 11.08.2026, last edit - 11.08.2026
		this.clear();
		this.src = Etc.fixTrim(Src);
		this.getPart();
		this.fix();
		this.validate();
	}

	private void clear() throws Exception {
		// origin - 17.05.2026, last edit - 16.07.2026
		try {
			this.src = this.code = this.description = this.defect = "";
		} catch (Exception ex) {
			WB.addLog("CodeListMap.clear():void, ex=" + ex.getMessage(), "", "CodeListMap");
		}
	}

	public CodeListMap() throws Exception {
		// origin - 11.08.2026, last edit - 11.08.2026
		this.clear();
	}

	public String toString() {
		// origin - 11.08.2026, last edit - 11.08.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 10.08.2026, last edit - 10.08.2026
		try {

//			WB.addLog2("CodeListMap.test.ctor(String)", "", "CodeListMap");
//			for (var tmp : new String[] { "", "1", "1,2", "1,2,3" }) {
//				WB.addLog2("CodeListMap.test.ctor(String), res=" + new CodeListMap(tmp), "", "CodeListMap");
//			}

		} catch (Exception ex) {
			WB.addLog("CodeListMap.test():void, ex=" + ex.getMessage(), "", "CodeListMap");
		}
	}
}