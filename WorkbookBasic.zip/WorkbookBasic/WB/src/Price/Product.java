import java.util.ArrayList;
import java.util.List;

public final class Product {
	// origin - 24.05.2026, last edit - 05.07.2026
	public List<String> src;
	public String name, unit, description, id, more, defect, fullName, comment;

	private void fix() throws Exception { // TODO
		// origin - 31.05.2026, last edit - 31.05.2026
		try {
		} catch (Exception ex) {
			WB.addLog("Product.fix():void, ex=" + ex.getMessage(), "", "Product");
		}
	}

	public static UnitVal getRatioVolume(UnitVal arg1, UnitVal arg2, String toUnit) throws Exception {
		// origin - 01.09.2026, last edit - 01.09.2026
		UnitVal res = new UnitVal();
		try {
			List<UnitVal> listArg = new ArrayList<UnitVal>();
			listArg.add(arg1);
			listArg.add(arg2);
			res = UnitVal.divide(listArg, toUnit); // ratio = arg1 / arg2
		} catch (Exception ex) {
			WB.addLog("Product.getRatioVolume(2UnitVal, String):UnitVal, ex=" + ex.getMessage(), "", "Product");
		}
		return res;
	}

	public static UnitVal getTargetByNumberPiece(int NumberPiece, UnitVal piece, String toUnit) throws Exception {
		// origin - 26.07.2026, last edit - 27.07.2026
		UnitVal res = new UnitVal();
		try {
			var tmp1 = new UnitVal(NumberPiece * piece.val, piece.unit.code);
			res = UnitVal.conv(tmp1, toUnit, "");
		} catch (Exception ex) {
			WB.addLog("Product.getTargetByNumberPiece(int,UnitVal,String):UnitVal, ex=" + ex.getMessage(), "",
					"Product");
		}
		return res;
	}

	public static int getNumberPieceByTarget(UnitVal target, UnitVal piece) throws Exception {
		// origin - 18.07.2026, last edit - 27.07.2026
		int res = 0;
		try {
			var tmp1 = UnitVal.conv(target, piece.unit.code, "");
			if (piece.val != 0) {
				res = (int) Math.ceil(tmp1.val / piece.val);
			}
		} catch (Exception ex) {
			WB.addLog("Product.getNumberPieceByTarget(2UnitVal):int, ex=" + ex.getMessage(), "", "Product");
		}
		return res;
	}

	public static UnitVal getAreaRectangle(UnitVal arg1, UnitVal arg2, String toUnit) throws Exception {
		// origin - 18.07.2026, last edit - 26.07.2026
		UnitVal res = new UnitVal();
		try {
			List<UnitVal> listArg = new ArrayList<UnitVal>();
			listArg.add(arg1);
			listArg.add(arg2);
			res = UnitVal.multiply(listArg, toUnit);
		} catch (Exception ex) {
			WB.addLog("Product.getAreaRectangle(2UnitVal, String):UnitVal, ex=" + ex.getMessage(), "", "Product");
		}
		return res;
	}

	private void validate() throws Exception {
		// origin - 31.05.2026, last edit - 05.07.2026
		try {
			if (this.name.isEmpty()) {
				this.defect = this.defect + "empty name; "; // ex. "Armatura diam 20 mm standart 76-2024"
			}
			if (this.description.isEmpty()) { // ex. "use for building, agriculture, machinery"
				this.defect = this.defect + "empty description; ";
			}
		} catch (Exception ex) {
			WB.addLog("Product.validate():void, ex=" + ex.getMessage(), "", "Product");
		}
	}

	private void getPart(ProductListPartMap map) throws Exception {
		// origin - 02.07.2026, last edit - 06.07.2026
		try {
			var tmp1 = Integer.valueOf(map.name);
			if (this.src.size() > tmp1) {
				this.name = this.src.get(tmp1);
			}

			var tmp2 = Integer.valueOf(map.unit);
			if (this.src.size() > tmp2) {
				this.unit = this.src.get(tmp2);
			}

			var tmp3 = Integer.valueOf(map.description);
			if (this.src.size() > tmp3) {
				this.description = this.src.get(tmp3);
			}

			var tmp4 = Integer.valueOf(map.id);
			if (this.src.size() > tmp4) {
				this.id = this.src.get(tmp4);
			}
		} catch (Exception ex) {
			WB.addLog("Product.getPart():void, ex=" + ex.getMessage(), "", "Product");
		}
	}

	public Product(List<String> Src, ProductListPartMap map) throws Exception {
		// origin - 27.05.2026, last edit - 05.07.2026
		this.clear();
		this.src = Src;
		this.getPart(map);
		this.fix();
		this.validate();
	}

	public Product() throws Exception {
		// origin - 27.05.2026, last edit - 27.05.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 24.05.2026, last edit - 05.07.2026
		try {
			this.src = new ArrayList<String>();
			this.id = this.name = this.description = this.defect = this.unit = this.more = this.fullName = this.comment = "";
		} catch (Exception ex) {
			WB.addLog("Product.clear():void, ex=" + ex.getMessage(), "", "Product");
		}
	}

	public String toString() {
		// origin - 24.05.2026, last edit - 02.07.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("name ", this.name);
			res = res + Fmtr.addIfNotEmpty(", unit ", this.unit);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 24.05.2026, last edit - 04.09.2026
		try {

//			{
//				WB.addLog2("Product.test.getRatioVolume(2UnitVal;String)", "", "Product");
//				var tmp1 = new String[] { "6.0(Unit.CalendarDay)", "3.0(Unit.Week)", "4.2(Unit.Meter)",
//						"4.2(Unit.Kg)" };
//				var tmp2 = new String[] { "2.0(Unit.CalendarDay)", "3.0(Unit.Week)", "5.2(Unit.Meter)",
//						"3.2(Unit.Kg)" };
//				var tmp3 = new String[] { "Unit.CalendarDay", "Unit.Week", "Unit.Meter", "Unit.Kg" };
//				for (var tmp11 : tmp1) {
//					for (var tmp22 : tmp2) {
//						for (var tmp33 : tmp3) {
//							WB.addLog2(
//									"Product.test.getRatioVolume(2UnitVal,String), res="
//											+ Product.getRatioVolume(new UnitVal(tmp11), new UnitVal(tmp22), tmp33).id
//											+ ", tmp11=" + tmp11 + ", tmp22=" + tmp22 + ", tmp33=" + tmp33,
//									"", "Product");
//						}
//					}
//				}
//			}

//			{
//				WB.addLog2("Product.test.getNumberPieceByTarget(2UnitVal)", "", "UnitVal");
//				var tmp1 = new String[] { "660.0(Unit.Meter)", "354.6(Unit.Meter)", "4357.2(Unit.Meter)",
//						"5656.999(Unit.Meter)" };
//				var tmp2 = new String[] { "2.5(Unit.Meter)", "30.7(Unit.Cm)", "500.2(Unit.Mm)" };
//				for (var tmp11 : tmp1) {
//					for (var tmp22 : tmp2) {
//						System.out.println(
//								"Product.getNumberPieceByTarget(2UnitVal), tmp11=" + tmp11 + ", tmp22=" + tmp22);
//						var res = Product.getNumberPieceByTarget(new UnitVal(tmp11), new UnitVal(tmp22));
//						var factTarget = Product.getTargetByNumberPiece(res, new UnitVal(tmp22),
//								new UnitVal(tmp11).unit.code);
//						WB.addLog2("Product.test.getNumberPieceByTarget(List<UnitVal>), res=" + res + ", tmp11=" + tmp11
//								+ ", tmp22=" + tmp22 + ", fact target=" + factTarget.id, "", "UnitVal");
//					}
//				}
//				System.out.println("Product.getNumberPieceByTarget(2UnitVal) end.");
//			}

//			{
//				WB.addLog2("Product.test.getAreaRestangle(2UnitVal;String)", "", "Product");
//				var tmp1 = new String[] { "6.0(Unit.Meter)", "3.0(Unit.Cm)", "4.2(Unit.Mm)", "7.999(Unit.Mcm)" };
//				var tmp2 = new String[] { "2.0(Unit.Meter)", "3.0(Unit.Cm)", "5.2(Unit.Mm)", "6.999(Unit.Mcm)" };
//				var tmp3 = new String[] { "Unit.Meter", "Unit.Cm", "Unit.Mm", "Unit.Mcm" };
//				for (var tmp11 : tmp1) {
//					for (var tmp22 : tmp2) {
//						for (var tmp33 : tmp3) {
//							System.out.println("Product.getAreaRectangle(2UnitVal,String), tmp11=" + tmp11 + ", tmp22="
//									+ tmp22 + ", tmp33=" + tmp33);
//							WB.addLog2(
//									"Product.test.getAreaRectangle(2UnitVal,String), res="
//											+ Product.getAreaRectangle(new UnitVal(tmp11), new UnitVal(tmp22), tmp33).id
//											+ ", tmp11=" + tmp11 + ", tmp22=" + tmp22 + ", tmp33=" + tmp33,
//									"", "Product");
//						}
//					}
//				}
//				System.out.println("Product.getAreaRectangle(2UnitVal,String) end.");
//			}

//			WB.addLog2("Product.test.ctor(String)", "", "Product");
//			var tmp3 = new ProductListMap("11,1,2,3,4,5,6,7,8");
//			for (var tmp1 : new String[] { "", "date price=?,lastLineTitle=?,Product1",
//					"date price=?,lastLineTitle=?,Product1,pcs", "дата прайса=?,lastLineTitle=?,Product1,pcs,12",
//					"date price=?,lastLineTitle=?,Product1,pcs,12,10",
//					"date price=?,lastLineTitle=?,Product1,pcs,12,10,This product is good",
//					"date price=?,lastLineTitle=?,Product1,pcs,12,10,This product is good,ID234" }) {
//				var tmp2 = List.of(tmp1.split(","));
//				WB.addLog2("Product.test.ctor(String), res=" + new Product(tmp2, tmp3), "",
//						"Product");
//			}

		} catch (Exception ex) {
			WB.addLog("Product.test():void, ex=" + ex.getMessage(), "", "Product");
		}
	}
}