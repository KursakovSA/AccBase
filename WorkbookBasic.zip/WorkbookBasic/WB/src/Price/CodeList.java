import java.util.ArrayList;
import java.util.List;

public final class CodeList {
	// origin - 10.08.2026, last edit - 11.08.2026
	public List<String> srcList;
	public String table, id, parent, date1, date2, code, description, role, more, fullName, comment, defect;
	public CodeListMap map;
	public List<CodeListItem> itemList;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("CodeList.static ctor, ex=" + ex.getMessage(), "", "CodeList");
		}
	}

	public static String getCodeById(String id, String code) throws Exception { // TODO
		// origin - 11.08.2026, last edit - 11.08.2026
		String res = "";
		try {

		} catch (Exception ex) {
			WB.addLog("CodeList.getCodeById(2String):String, ex=" + ex.getMessage(), "", "CodeList");
		}
		return res;
	}

	public static String getDescriptionByCode(String id, String code) throws Exception { // TODO
		// origin - 11.08.2026, last edit - 11.08.2026
		String res = "";
		try {

		} catch (Exception ex) {
			WB.addLog("CodeList.getDescriptionByCode(2String):String, ex=" + ex.getMessage(), "", "CodeList");
		}
		return res;
	}

	private void getSrcList() throws Exception {
		// origin - 11.08.2026, last edit - 11.08.2026
		try {
			// var tmp1 = WB.commonDocDir + File.separator + this.fullName;
			var tmp1 = InOut.getStrPathFileByFileNameInAppDir(this.fullName);

			if (this.fullName.endsWith(".csv")) {
				var tmp2 = CSV.getListByPath(tmp1);
				this.srcList.addAll(tmp2);
			}

//			if (this.fullName.endsWith(".xlsx")) { //TODO
//				var tmp2 = ExcelReader.read(tmp1, this.fullName);
//				WB.log(tmp2, "CodeList");
//			}
		} catch (Exception ex) {
			WB.addLog("CodeList.getSrcList():void, ex=" + ex.getMessage(), "", "CodeList");
		}
	}

	private void getItemList() throws Exception {
		// origin - 11.08.2026, last edit - 11.08.2026
		try {
			List<String> itemSrc = new ArrayList<String>();
			for (var currRowSrcList : this.srcList) {
				itemSrc = List.of(currRowSrcList.split("\\|"));

				var tryCodeListItem = new CodeListItem(itemSrc, this.map);
				if (tryCodeListItem.defect.isEmpty()) {
					this.itemList.add(tryCodeListItem);
				}
			}
		} catch (Exception ex) {
			WB.addLog("CodeList.getItemList():void, ex=" + ex.getMessage(), "", "CodeList");
		}
	}

	private void fix() throws Exception { // TODO
		// origin - 11.08.2026, last edit - 11.08.2026
		try {
		} catch (Exception ex) {
			WB.addLog("CodeList.fix():void, ex=" + ex.getMessage(), "", "CodeList");
		}
	}

	private void validate() throws Exception {
		// origin - 11.08.2026, last edit - 11.08.2026
		try {
			if (this.srcList.size() == 0) {
				this.defect = this.defect + "empty srcList; ";
			}
			if (this.map.defect.isEmpty() == false) {
				this.defect = this.defect + "defect map; ";
			}
			if (this.itemList.size() == 0) {
				this.defect = this.defect + "empty itemList; ";
			}
		} catch (Exception ex) {
			WB.addLog("CodeList.validate():void, ex=" + ex.getMessage(), "", "CodeList");
		}
	}

	private void isExist() throws Exception {
		// origin - 11.08.2026, last edit - 11.08.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdRoleFilter(this.id, "Role.Generic.CodeList"),
					this.table);
			if (listDto.size() != 0) {
				var currDto1 = listDto.getFirst();
				this.parent = DefVal.setCustom(this.parent, currDto1.parent);
				this.date1 = DefVal.setCustom(this.date1, currDto1.date1);
				this.date2 = DefVal.setCustom(this.date2, currDto1.date2);
				this.code = DefVal.setCustom(this.code, currDto1.code);
				this.description = DefVal.setCustom(this.description, currDto1.description);
				this.role = DefVal.setCustom(this.role, currDto1.role);
				this.more = DefVal.setCustom(this.more, currDto1.more);
			}

			if (listDto.size() == 0) {
				this.clear();
			}
		} catch (Exception ex) {
			WB.addLog("CodeList.isExist():void, ex=" + ex.getMessage(), "", "CodeList");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 11.08.2026, last edit - 11.08.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "Fullname");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.map = new CodeListMap(MoreVal.getFieldByKey(this.more, "Map"));
		} catch (Exception ex) {
			WB.addLog("CodeList.getFieldFromMore():void, ex=" + ex.getMessage(), "", "CodeList");
		}
	}

	public CodeList(String Id) throws Exception {
		// origin - 11.08.2026, last edit - 11.08.2026
		this.clear();
		this.id = Etc.fixTrim(Id);
		this.isExist();
		this.getFieldFromMore();
		this.getSrcList();
		this.getItemList();
		this.fix();
		this.validate();
	}

	private void clear() throws Exception {
		// origin - 11.08.2026, last edit - 11.08.2026
		try {
			this.table = "Price";
			this.srcList = new ArrayList<String>();
			this.id = this.parent = this.code = this.date1 = this.date2 = this.code = this.description = this.defect = "";
			this.role = this.more = this.fullName = this.comment = "";
			this.map = new CodeListMap();
			this.itemList = new ArrayList<CodeListItem>();
		} catch (Exception ex) {
			WB.addLog("ProductListPart.clear():void, ex=" + ex.getMessage(), "", "ProductListPart");
		}
	}

	public String toString() {
		// origin - 11.08.2026, last edit - 11.08.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", role ", this.role);
			res = res + Fmtr.addAnyway(", srcList.size ", this.srcList.size());
			res = res + Fmtr.addAnyway(", itemList.size ", this.itemList.size());
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", more.lenght ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 10.08.2026, last edit - 13.08.2026
		try {

//			WB.addLog2("CodeList.test.ctor(String)", "", "CodeList");
//			for (var tmp1 : new String[] { "", "Price.BasicCondition", "CodeList.KPVED", "CodeList.TNVED",
//					"CodeList.Tralala" }) {
//				var tmp2 = new CodeList(tmp1);
//				WB.addLog2("CodeList.test.ctor(String), res=" + tmp2 + ", tmp1=" + tmp1, "", "CodeList");
//				WB.log3Str(tmp2.itemList, "CodeList");
//			}

		} catch (Exception ex) {
			WB.addLog("CodeList.test():void, ex=" + ex.getMessage(), "", "CodeList");
		}
	}
}