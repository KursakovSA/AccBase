import java.util.ArrayList;
import java.util.List;

public final class ProductListPartMap {
	// origin - 17.05.2026, last edit - 16.07.2026
	public String src0, src1, src2, defect;
	private static List<String> listDelStr;
	public String date1; // ex. 35 - row 3, column 5
	public String lastLineTitle; // ex. 5 - column 5
	public String name; // ex. 6 - column 6
	public String unit; // ex. 7 - column 7
	public String description; // ex. 10 - column 10
	public String id; // ex. 11 - column 11, usually not be
	public List<String> val;

	static {
		ProductListPartMap.listDelStr = List.of(" ", "(", ")");
		try {
		} catch (Exception ex) {
			WB.addLog("ProductListPartMap.static ctor, ex=" + ex.getMessage(), "", "ProductListPartMap");
		}
	}

	public static List<ProductListPartMap> getList(String in) throws Exception {
		// origin - 21.05.2026, last edit - 31.07.2026
		List<ProductListPartMap> res = new ArrayList<ProductListPartMap>();
		try {
			var tmp1 = List.of(in.split("\\|"));
			for (var tmp2 : tmp1) {
				res.add(new ProductListPartMap(tmp2));
			}
		} catch (Exception ex) {
			WB.addLog("ProductListPartMap.getList(String):List<ProductListPartMap>, ex=" + ex.getMessage(), "",
					"ProductListPartMap");
		}
		return res;
	}

	private void fix() throws Exception {
		// origin - 17.05.2026, last edit - 16.07.2026
		try {
			this.lastLineTitle = DefVal.set(this.lastLineTitle, "3");
			this.name = DefVal.set(this.name, "2"); // 1 - this code, or number
			this.unit = DefVal.set(this.unit, "3");
		} catch (Exception ex) {
			WB.addLog("ProductListPartMap.fix():void, ex=" + ex.getMessage(), "", "ProductListPartMap");
		}
	}

	private void validate() throws Exception {
		// origin - 17.05.2026, last edit - 16.07.2026
		try {
			this.defect = Fmtr.addIfStrEmpty(this.defect, this.name, "empty name; ");
			this.defect = Fmtr.addIfStrEmpty(this.defect, this.unit, "empty unit; ");
		} catch (Exception ex) {
			WB.addLog("ProductListPartMap.validate():void, ex=" + ex.getMessage(), "", "ProductListPartMap");
		}
	}

	private void getPart() throws Exception {
		// origin - 17.05.2026, last edit - 16.07.2026
		try {
			String[] items = this.src1.split(",");
			if (items.length > 0) {
				this.date1 = items[0]; // ex. 35 - 3 row, 5 column

				if (items.length > 1) { // ex. 5 - 5 column
					this.lastLineTitle = items[1];
				}

				if (items.length > 2) { // ex. 6 - 6 column
					this.name = items[2];
				}

				if (items.length > 3) { // ex. 7 - 7 column
					this.unit = items[3];
				}

				if (items.length > 4) {
					this.description = items[4];
				}

				if (items.length > 5) {
					this.id = items[5];
				}
			}

			if (this.src2.length() > 0) {
				this.val.addAll(List.of(this.src2.split(",")));
			}
		} catch (Exception ex) {
			WB.addLog("ProductListPartMap.getPart():void, ex=" + ex.getMessage(), "", "ProductListPartMap");
		}
	}

	public ProductListPartMap(String Src) throws Exception {
		// origin - 17.05.2026, last edit - 06.07.2026
		this.clear();
		this.src0 = Etc.fixTrim(Src);
		var tmp = List.of(this.src0.split("\\)"));
		this.src1 = Etc.delStr(Etc.fixTrim(tmp.getFirst()), ProductListPartMap.listDelStr);
		if (tmp.size() > 1) {
			this.src2 = Etc.delStr(Etc.fixTrim(tmp.get(1)), ProductListPartMap.listDelStr);
		}
		this.getPart();
		this.fix();
		this.validate();
	}
	
	public ProductListPartMap() throws Exception {
		// origin - 17.05.2026, last edit - 17.05.2026
		this.clear();
	}
	
	private void clear() throws Exception {
		// origin - 17.05.2026, last edit - 16.07.2026
		try {
			this.src0 = this.src1 = this.src2 = this.date1 = this.lastLineTitle = this.name = "";
			this.unit = this.description = this.defect = this.id = "";
			this.val = new ArrayList<String>();
		} catch (Exception ex) {
			WB.addLog("ProductListPartMap.clear():void, ex=" + ex.getMessage(), "", "ProductListPartMap");
		}
	}

	public String toString() {
		// origin - 17.05.2026, last edit - 06.07.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src0 ", this.src0);
			res = res + Fmtr.addAnyway(", src1 ", this.src1);
			res = res + Fmtr.addAnyway(", src2 ", this.src2);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", lastLineTitle ", this.lastLineTitle);
			res = res + Fmtr.addIfNotEmpty(", name ", this.name);
			res = res + Fmtr.addIfNotEmpty(", unit ", this.unit);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", val ", this.val);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 17.05.2026, last edit - 16.07.2026
		try {

//			WB.addLog2("ProductListPartMap.test.ctor(String)", "", "ProductListPartMap");
//			for (var tmp : new String[] { "", "(35)()", "(35,5)()", "(35,5,1)()", "(35,5,1,2)()", "(35,5,1,2,3)",
//					"(35,5,1,2,3,4)()", "(35,5,1,2,3,4)(5)", "(35, 5 , 1,2 ,   3 , 4   )(5,6)" }) {
//				WB.addLog2("ProductListPartMap.test.ctor(String), res=" + new ProductListPartMap(tmp), "",
//						"ProductListPartMap");
//			}

		} catch (Exception ex) {
			WB.addLog("ProductListPartMap.test():void, ex=" + ex.getMessage(), "", "ProductListPartMap");
		}
	}
}