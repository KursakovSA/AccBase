import java.util.ArrayList;
import java.util.List;

public final class ProductListDescr {
	// origin - 15.05.2026, last edit - 31.07.2026
	public String src, table, id, more, fullName, comment, defect, context;
	public BasicDto root;
	public List<ProductListPart> partList;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("ProductListDescr.static ctor, ex=" + ex.getMessage(), "", "ProductListDescr");
		}
	}

	private void fix() throws Exception { // TODO
		// origin - 17.05.2026, last edit - 16.07.2026
		try {
		} catch (Exception ex) {
			WB.addLog("ProductListDescr.fix():void, ex=" + ex.getMessage(), "", "ProductListDescr");
		}
	}

	private void validate() throws Exception {
		// origin - 17.05.2026, last edit - 31.07.2026
		try {
			if (this.root.id.isEmpty()) {
				this.defect = this.defect + "empty root; ";
			}
			if (this.partList.size() == 0) {
				this.defect = this.defect + "empty part; ";
			}
		} catch (Exception ex) {
			WB.addLog("ProductListDescr.validate():void, ex=" + ex.getMessage(), "", "ProductListDescr");
		}
	}

	private void isExist() throws Exception {
		// origin - 17.05.2026, last edit - 31.07.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdRoleFilter(this.id, "Role.ProductList.Root"),
					this.table);
			if (listDto.size() != 0) {
				var currDto = listDto.getFirst();
				this.root = new BasicDto(currDto);
				this.more = root.more;
				this.getFieldFromMore();
				this.partList = ProductListPart.getListByProductListId(currDto.id);
			}

			if (listDto.size() == 0) {
				this.id = this.defect = "";
			}
		} catch (Exception ex) {
			WB.addLog("ProductListDescr.isExist():void, ex=" + ex.getMessage(), "", "ProductListDescr");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 17.05.2026, last edit - 16.07.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "Fullname");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.context = MoreVal.getFieldByKey(this.more, "Context");
		} catch (Exception ex) {
			WB.addLog("ProductListDescr.getFieldFromMore():void, ex=" + ex.getMessage(), "", "ProductListDescr");
		}
	}

	public ProductListDescr(String Src) throws Exception {
		// origin - 17.05.2026, last edit - 18.05.2026
		this.clear();
		this.src = this.id = Etc.fixTrim(Src);
		this.table = "Price";
		this.isExist();
		this.fix();
		this.validate();
	}

	private void clear() throws Exception {
		// origin - 17.05.2026, last edit - 31.07.2026
		try {
			this.src = this.table = this.id = this.defect = this.fullName = this.comment = this.context = "";
			this.root = new BasicDto();
			this.partList = new ArrayList<ProductListPart>();
		} catch (Exception ex) {
			WB.addLog("ProductListDescr.clear():void, ex=" + ex.getMessage(), "", "ProductListDescr");
		}
	}

	public ProductListDescr() throws Exception {
		// origin - 17.05.2026, last edit - 17.05.2026
		this.clear();
	}

	public String toString() {
		// origin - 17.05.2026, last edit - 31.07.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", root.id ", this.root.id);
			res = res + Fmtr.addIfNotEmpty(", partList.size ", this.partList.size());
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", more.lenght ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", context ", this.context);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 15.05.2026, last edit - 16.07.2026
		try {

//			WB.addLog2("ProductListDescr.test.ctor(String)", "", "ProductListDescr");
//			for (var tmp1 : new String[] { "", "Price.BasicCondition", "PriceListDescription.Root",
//					"PriceListDescription.Tralala" }) {
//				var tmp2 = new ProductListDescr(tmp1);
//				WB.addLog2("ProductListDescr.test.ctor(String), res=" + tmp2, "", "ProductListDescr");
//				WB.log(tmp2.part, "ProductListDescr");
//			}

		} catch (Exception ex) {
			WB.addLog("ProductListDescr.test():void, ex=" + ex.getMessage(), "", "ProductListDescr");
		}
	}
}