import java.util.ArrayList;
import java.util.List;

public final class ProductVar {
	// origin - 07.07.2026, last edit - 28.07.2026
	public String id, parent, date1, date2, description, code, role, unit, more, defect, fullName, comment;

	public static UnitVal getByMapIndex(ProductListItem productListItem, String productVarFullName) throws Exception { // TODO
		// origin - 16.07.2026, last edit - 29.07.2026
		UnitVal res = new UnitVal();
		try {

		} catch (Exception ex) {
			WB.addLog("ProductVar.getBygetByMapIndex(ProductListItem,String):UnitVal, ex=" + ex.getMessage(), "",
					"ProductVar");
		}
		return res;
	}

	public static UnitVal getByFullName(ProductListItem productListItem, String productVarFullName) throws Exception { // TODO
		// origin - 16.07.2026, last edit - 29.07.2026
		UnitVal res = new UnitVal();
		try {

		} catch (Exception ex) {
			WB.addLog("ProductVar.getByFullName(ProductListItem,String):UnitVal, ex=" + ex.getMessage(), "",
					"ProductVar");
		}
		return res;
	}

//	public static List<ProductVar> getListVal(String partitionId) throws Exception { // TODO
//		// origin - 17.07.2026, last edit - 17.07.2026
//		List<ProductVar> res = new ArrayList<ProductVar>();
//		try {
//			var tmp1 = BasicDto.getLower("Price", partitionId);
//			for (var tmp2 : tmp1) {
//				if (Etc.strEquals(tmp2.role, "Role.ProductList.ProductVar")) {
//					res.add(new ProductVar(tmp2));
//				}
//			}
//		} catch (Exception ex) {
//			WB.addLog("ProductVar.getListVal(String):List<ProductVar>, ex=" + ex.getMessage(), "", "ProductVar");
//		}
//		return res;
//	}

	public static List<ProductVar> getListByProductListPartId(String productListPartId) throws Exception {
		// origin - 15.07.2026, last edit - 31.07.2026
		List<ProductVar> res = new ArrayList<ProductVar>();
		try {
			var tmp1 = BasicDto.getLower("Price", productListPartId);
			for (var tmp2 : tmp1) {
				if (Etc.strEquals(tmp2.role, "Role.ProductList.ProductVar")) {
					res.add(new ProductVar(tmp2));
				}
			}
		} catch (Exception ex) {
			WB.addLog("ProductVar.getListByProductListPartId(String):List<ProductVar>, ex=" + ex.getMessage(), "",
					"ProductVar");
		}
		return res;
	}

	private void fix() throws Exception { // TODO
		// origin - 31.05.2026, last edit - 31.05.2026
		try {
		} catch (Exception ex) {
			WB.addLog("ProductVar.fix():void, ex=" + ex.getMessage(), "", "ProductVar");
		}
	}

	private void validate() throws Exception {
		// origin - 07.07.2026, last edit - 07.07.2026
		try {
			if (this.id.isEmpty()) {
				this.defect = this.defect + "empty id; ";
			}
			if (this.code.isEmpty()) {
				this.defect = this.defect + "empty code; ";
			}
			if (this.description.isEmpty()) {
				this.defect = this.defect + "empty description; ";
			}
			if (this.fullName.isEmpty()) {
				this.defect = this.defect + "empty fullName; ";
			}
		} catch (Exception ex) {
			WB.addLog("ProductVar.validate():void, ex=" + ex.getMessage(), "", "ProductVar");
		}
	}

	public ProductVar(BasicDto bDto) throws Exception {
		// origin - 07.07.2026, last edit - 02.08.2026
		this.clear();
		if (Etc.strEquals(bDto.role, "Role.ProductList.ProductVar")) {
			this.id = bDto.id;
			this.parent = bDto.parent;
			this.date1 = bDto.date1;
			this.date2 = bDto.date2;
			this.code = bDto.code;
			this.description = bDto.description;
			this.role = bDto.role;
			this.more = bDto.more;
			this.getFieldFromMore();
		}
		this.fix();
		this.validate();
	}

	public ProductVar() throws Exception {
		// origin - 07.07.2026, last edit - 07.07.2026
		this.clear();
	}

	private void getFieldFromMore() throws Exception {
		// origin - 07.07.2026, last edit - 28.07.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "Fullname");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.unit = MoreVal.getFieldByKey(this.more, "Unit");
		} catch (Exception ex) {
			WB.addLog("ProductVar.getFieldFromMore():void, ex=" + ex.getMessage(), "", "ProductVar");
		}
	}

	private void clear() throws Exception {
		// origin - 07.07.2026, last edit - 28.07.2026
		try {
			this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.role = this.defect = this.more = "";
			this.unit = this.fullName = this.comment = "";
		} catch (Exception ex) {
			WB.addLog("ProductVar.clear():void, ex=" + ex.getMessage(), "", "ProductVar");
		}
	}

	public String toString() {
		// origin - 07.07.2026, last edit - 28.07.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", role ", this.role);
			res = res + Fmtr.addIfNotEmpty(", unit ", this.unit);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 07.07.2026, last edit - 02.08.2026
		try {

//			WB.addLog2("ProductVar.test.getListByProductListPartId(String):List<ProductVar>", "", "ProductVar");
//			for (var tmp1 : new String[] { "",
//					"PriceListDescription.Root.Part1", "PriceListDescription.Tralala" }) {
//				var tmp2 = ProductVar.getListByProductListPartId(tmp1);
//				WB.addLog2("ProductVar.test.getListByProductListPartId(String):List<ProductVar>, res.size=" + tmp2.size()
//						+ ", tmp1=" + tmp1, "", "ProductVar");
//				WB.log(tmp2, "ProductVar");
//			}

//			WB.addLog2("ProductVar.test.ctor(BasicDto)", "", "ProductVar");
//			for (var tmp1 : new String[] { "", "PriceListDescription.Root.Part1",
//					"PriceListDescription.Root.Part1.ProductVar1",
//					"PriceListDescription.Root.Part1.ProductVarTralala" }) {
//				var tmp2 = new BasicDto("Price", tmp1);
//				WB.addLog2("ProductVar.test.ctor(BasicDto), res=" + new ProductVar(tmp2) + ", tmp1=" + tmp1, "",
//						"ProductVar");
//			}

		} catch (Exception ex) {
			WB.addLog("ProductVar.test():void, ex=" + ex.getMessage(), "", "ProductVar");
		}
	}
}