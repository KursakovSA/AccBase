import java.util.ArrayList;
import java.util.List;

public final class ProductListItem {
	// origin - 21.05.2026, last edit - 31.07.2026
	public List<String> src;
	public String id, group, name, description, unit, defect;
	public List<String> varList;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("ProductListItem.static ctor, ex=" + ex.getMessage(), "", "ProductListItem");
		}
	}

	public static String getVarByNumber() throws Exception { // TODO
		// origin - 04.08.2026, last edit - 04.08.2026
		String res = "";
		try {

		} catch (Exception ex) {
			WB.addLog("ProductListItem.getValByNumber():void, ex=" + ex.getMessage(), "", "ProductListItem");
		}
		return res;
	}

	public static String getVarByFullName() throws Exception { // TODO
		// origin - 04.08.2026, last edit - 04.08.2026
		String res = "";
		try {

		} catch (Exception ex) {
			WB.addLog("ProductListItem.getValByFullName():void, ex=" + ex.getMessage(), "", "ProductListItem");
		}
		return res;
	}

	public static List<ProductListItem> getListByProductGroup() throws Exception { // TODO
		// origin - 29.07.2026, last edit - 29.07.2026
		List<ProductListItem> res = new ArrayList<ProductListItem>();
		try {

		} catch (Exception ex) {
			WB.addLog("ProductListItem.getListByProductGroup():void, ex=" + ex.getMessage(), "", "ProductListItem");
		}
		return res;
	}

	private void fix() throws Exception { // TODO
		// origin - 31.05.2026, last edit - 16.07.2026
		try {
		} catch (Exception ex) {
			WB.addLog("ProductListItem.fix():void, ex=" + ex.getMessage(), "", "ProductListItem");
		}
	}

	private void validate() throws Exception {
		// origin - 31.05.2026, last edit - 03.08.2026
		try {
			if (this.group.isEmpty()) {
				this.defect = this.defect + "empty group; ";
			}
			if (this.name.isEmpty()) {
				this.defect = this.defect + "empty name; ";
			}
			if (this.unit.isEmpty()) {
				this.defect = this.defect + "empty unit; ";
			}
			if (this.varList.size() == 0) {
				this.defect = this.defect + "empty varList; ";
			}
		} catch (Exception ex) {
			WB.addLog("ProductListItem.validate():void, ex=" + ex.getMessage(), "", "ProductListItem");
		}
	}

	private void getPart(ProductListPartMap partMap, String productGroup) throws Exception {
		// origin - 28.07.2026, last edit - 31.07.2026
		try {
			if (partMap.id.isEmpty() == false) {
				this.id = Etc.getItemListStringIfExist(src, Integer.valueOf(partMap.id) - 1);// src.get(Integer.valueOf(partMap.id)
																								// - 1);
			}
			this.group = productGroup;
			if (partMap.name.isEmpty() == false) {
				this.name = Etc.getItemListStringIfExist(src, Integer.valueOf(partMap.name) - 1);// src.get(Integer.valueOf(partMap.name)
																									// - 1);
			}
			if (partMap.unit.isEmpty() == false) {
				this.unit = Etc.getItemListStringIfExist(src, Integer.valueOf(partMap.unit) - 1);// src.get(Integer.valueOf(partMap.unit)
																									// - 1);
			}
			if (partMap.description.isEmpty() == false) {
				this.description = Etc.getItemListStringIfExist(src, Integer.valueOf(partMap.description) - 1);// src.get(Integer.valueOf(partMap.description)
																												// - 1);
			}
			for (var curr : partMap.val) {
				this.varList.add(Etc.getItemListStringIfExist(src, Integer.valueOf(curr) - 1));// src.get(Integer.valueOf(curr)
																								// - 1));
			}
		} catch (Exception ex) {
			WB.addLog("ProductListItem.getPart():void, ex=" + ex.getMessage(), "", "ProductListItem");
		}
	}

	public ProductListItem(List<String> Src, ProductListPartMap partMap, String productGroup) throws Exception {
		// origin - 27.05.2026, last edit - 29.07.2026
		this.clear();
		this.src.addAll(Src);
		this.getPart(partMap, productGroup);
		this.fix();
		this.validate();
	}

	public ProductListItem() throws Exception {
		// origin - 27.05.2026, last edit - 05.07.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 27.05.2026, last edit - 31.07.2026
		try {
			this.src = new ArrayList<String>();
			this.id = this.description = this.unit = this.group = this.name = this.defect = "";
			this.varList = new ArrayList<String>();
		} catch (Exception ex) {
			WB.addLog("ProductListItem.clear():void, ex=" + ex.getMessage(), "", "ProductListItem");
		}
	}

	public String toString() {
		// origin - 16.07.2026, last edit - 31.07.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", group ", this.group);
			res = res + Fmtr.addIfNotEmpty(", name ", this.name);
			res = res + Fmtr.addIfNotEmpty(", unit ", this.unit);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", varList ", this.varList);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 21.05.2026, last edit - 29.07.2026
		try {

//			WB.addLog2("ProductListItem.test.ctor(List<String>)", "", "ProductListItem");
//			for (var tmp1 : new String[] { "Field1,Field2,Field3,Field4", "Field1,Field2,Field3,Field4,Field5,Field6",
//					"Field1,Field2,Field3,Field4,Field5,Field6,Field7,Field8" }) {
//				var tmp2 = List.of(tmp1.split(","));
//				var tmp3 = new ProductListPartMap("(35,5,1,2,3,4)(5,6)");
//				var tmp4 = "Product group1";
//				WB.addLog2("ProductListItem.test.ctor(List<String>), res=" + new ProductListItem(tmp2, tmp3, tmp4)
//						+ ", tmp3=" + tmp3.src0, "", "ProductListItem");
//			}

		} catch (Exception ex) {
			WB.addLog("ProductListItem.test():void, ex=" + ex.getMessage(), "", "ProductListItem");
		}
	}
}