public class Access extends ModelDto { // TOTHINK
	// origin - 02.11.2024, last edit - 04.03.2025

	static {
	}

	public Access() throws Exception { // TOTHINK
		// origin - 02.11.2024, last edit - 02.11.2024
		super();
	}

	public static void test() throws Exception {
		// origin - 02.11.2024, last edit - 20.03.2025
		try {

		} catch (Exception ex) {
			WB.addLog("Access.test, ex=" + ex.getMessage(), "", "Access");
		}
	}
}