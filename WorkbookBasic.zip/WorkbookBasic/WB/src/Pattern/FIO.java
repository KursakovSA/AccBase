import java.util.List;

public class FIO {// Surname Name Patronymic
	// origin - 26.03.2025, last edit - 30.05.2025
	public String src, src1, src2, src3, code, description, surname, name, patronymic;
	private static final List<String> listDelStr = List.of(".", ",");

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("FIO.static ctor, ex=" + ex.getMessage(), "", "FIO");
		}
	}

	private void getSrc() throws Exception {
		// origin - 26.03.2025, last edit - 14.06.2025
		try {
			if (this.src.length() != 0) {
				String tmp = Etc.fixTrim(this.src); // "Smith John Oakland"

				int posSpace1 = tmp.indexOf(" ");
				if (posSpace1 > 0) {
					this.src1 = Etc.fixTrim(tmp.substring(0, posSpace1)); // "Smith"
					tmp = Etc.fixTrim(tmp.substring(posSpace1)); // "John Oakland"

					int posSpace2 = tmp.indexOf(" ");
					if (posSpace2 > 0) {
						this.src2 = Etc.fixTrim(tmp.substring(0, posSpace2)); // "John"
						tmp = Etc.fixTrim(tmp.substring(posSpace2)); // "Oakland"
					} else {
						this.src2 = tmp; // "John"
						tmp = ""; // ""
					}

					if (tmp.length() != 0) {
						this.src3 = Etc.fixTrim(tmp); // "Oakland"
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("FIO.getSrc():void, ex=" + ex.getMessage(), "", "FIO");
		}
	}

	private void getPart() throws Exception {
		// origin - 26.03.2025, last edit - 14.06.2025
		try {
			String letter1Src1 = "";
			String restSrc1 = "";
			if (this.src1.length() != 0) {
				letter1Src1 = this.src1.substring(0, 1).toUpperCase();
				restSrc1 = this.src1.substring(1).toLowerCase();
				this.surname = letter1Src1 + restSrc1;
			}

			String letter1Src2 = "";
			String restSrc2 = "";
			if (this.src2.length() != 0) {
				letter1Src2 = this.src2.substring(0, 1).toUpperCase();
				restSrc2 = this.src2.substring(1).toLowerCase();
				this.name = letter1Src2 + restSrc2;
			}

			String letter1Src3 = "";
			String restSrc3 = "";
			if (this.src3.length() != 0) {
				letter1Src3 = this.src3.substring(0, 1).toUpperCase();
				restSrc3 = this.src3.substring(1).toLowerCase();
				this.patronymic = letter1Src3 + restSrc3;
			}

			// ex. code = "Smith J.O."
			this.code = letter1Src1 + restSrc1;
			if (this.src2.isEmpty() == false) {
				this.code = this.code + " " + letter1Src2 + ".";
			}
			if (this.src3.isEmpty() == false) {
				this.code = this.code + " " + letter1Src3 + ".";
			}

			// ex. description = "Smith John Oakland"
			this.description = letter1Src1 + restSrc1;
			if (this.src2.isEmpty() == false) {
				this.description = this.description + " " + letter1Src2 + restSrc2;
			}
			if (this.src3.isEmpty() == false) {
				this.description = this.description + " " + letter1Src3 + restSrc3;
			}

		} catch (Exception ex) {
			WB.addLog("FIO.getPart():void, ex=" + ex.getMessage(), "", "FIO");
		}
	}

	public FIO(String Src) throws Exception {
		// origin - 26.03.2025, last edit - 16.05.2025
		this.clear();
		this.src = Etc.fixTrim(Src); // name surname patronymic
		this.src = Etc.delStr(this.src, FIO.listDelStr);
		this.getSrc();
		this.getPart();
	}

	public FIO(String Src1, String Src2, String Src3) throws Exception {
		// origin - 26.03.2025, last edit - 16.05.2025
		this.clear();
		this.src1 = Etc.fixTrim(Src1); // name
		this.src1 = Etc.delStr(this.src1, FIO.listDelStr);
		this.src2 = Etc.fixTrim(Src2); // surname
		this.src2 = Etc.delStr(this.src2, FIO.listDelStr);
		this.src3 = Etc.fixTrim(Src3); // patronymic name
		this.src3 = Etc.delStr(this.src3, FIO.listDelStr);
		this.getPart();
	}

	public void clear() throws Exception {
		// origin - 26.03.2025, last edit - 14.06.2025
		try {
			this.src = this.src1 = this.src2 = this.src3 = this.code = this.description = "";
		} catch (Exception ex) {
			WB.addLog("FIO.clear():void, ex=" + ex.getMessage(), "", "FIO");
		}
	}

	public FIO() throws Exception {
		// origin - 26.03.2025, last edit - 26.03.2025
		this.clear();
	}

	public String toString() {
		// origin - 26.03.2025, last edit - 14.05.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway(" src ", this.src);
			res = res + Fmtr.addAnyway(" src1 ", this.src1);
			res = res + Fmtr.addAnyway(" src2 ", this.src2);
			res = res + Fmtr.addAnyway(" src3 ", this.src3);
			res = res + Fmtr.addIfNotEmpty(" code ", this.code);
			res = res + Fmtr.addIfNotEmpty(" description ", this.description);

			res = res + Fmtr.addIfNotEmpty(" surname ", this.surname);
			res = res + Fmtr.addIfNotEmpty(" name ", this.name);
			res = res + Fmtr.addIfNotEmpty(" patronymic ", this.patronymic);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 26.03.2025, last edit - 14.06.2025
		try {

//			// test ctor(String, String, String)
//			WB.addLog2("FIO.test.ctor(String,String,String)", "", "FIO");
//			for (var tmp1 : new String[] { "Иванов", "ИВАНОВ.", "ИвАнОв" }) {
//				for (var tmp2 : new String[] { "", "Иван", "ИВАН.", "ИвАн" }) {
//					for (var tmp3 : new String[] { "", "Иванович.", "ИВАНОВИЧ", "ИвАнОвИч" }) {
//						WB.addLog2("FIO.test.ctor(String,String, String)="
//								+ new FIO(tmp1, tmp2, tmp3), "", "FIO");
//					}
//				}
//			}

//			// test ctor(String)
//			WB.addLog2("FIO.test.ctor(String)", "", "FIO");
//			for (var tmp1 : new String[] { "Иванов Иван Иванович", "Иванов Иван", "Иванов   Иван   Иванович",
//					"ИВАНОВ. ИВАН. ИВАНОВИЧ", "ИвАнОв ИвАн ИвАнОвИч" }) {
//				WB.addLog2("FIO.test.ctor(String)=" + new FIO(tmp1), "", "FIO");
//			}

		} catch (Exception ex) {
			WB.addLog("FIO.test():void, ex=" + ex.getMessage(), "", "FIO");
		}
	}
}