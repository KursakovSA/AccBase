public final class QPA {
	// origin - 03.06.2025, last edit - 12.10.2025
	public String src, src1, src2;
	public Qty q;
	public PA pa;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("QPA.static ctor, ex=" + ex.getMessage(), "", "QPA");
		}
	}

	private void correct() throws Exception {
		// origin - 03.06.2025, last edit - 14.06.2025
		try {
			if (this.q.quantity.val != 0.0) {
				if (this.pa.price.val != 0.0) {
					var tmp = Etc.multiply(this.q.quantity.val, this.pa.price.val);
					if (tmp != this.pa.amount.val) {
						pa = new PA(this.pa.src1 + " " + tmp);
//						WB.addLog2("QPA.correct()=" + ", pa.amount.val=" + this.pa.amount.val + ", q.quantity.val="
//								+ this.q.quantity.val + ", pa.price.val=" + this.pa.price.val, "", "QPA");
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("PA.correct():void, ex=" + ex.getMessage(), "", "PA");
		}
	}

	public QPA(String qty, String pa) throws Exception {
		// origin - 03.06.2025, last edit - 03.06.2025
		this.clear();
		this.src1 = qty;
		this.src2 = pa;
		this.src = this.src1 + " " + this.src2;
		this.q = new Qty(qty);
		this.pa = new PA(pa);
		this.correct();
	}

	public QPA() throws Exception {
		// origin - 03.06.2025, last edit - 03.06.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 03.06.2025, last edit - 06.09.2025
		try {
			this.src = this.src1 = this.src2 = "";
			this.q = new Qty();
			this.pa = new PA();
		} catch (Exception ex) {
			WB.addLog("QPA.clear():void, ex=" + ex.getMessage(), "", "QPA");
		}
	}

	public String toString() {
		// origin - 03.06.2025, last edit - 03.06.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" q.quantity.val ", this.q.quantity.val);
			res = res + Fmtr.addIfNotEmpty(" pa.price.val ", this.pa.price.val);
			res = res + Fmtr.addIfNotEmpty(" pa.amount.val ", this.pa.amount.val);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 03.06.2025, last edit - 14.06.2025
		try {

//			// test ctor(String)
//			WB.addLog2("QPA.test.ctor(String)", "", "QPA");
//			for (var tmp1 : new String[] { "5.00" }) {
//				for (var tmp2 : new String[] { "3000.00", "12000,00 60000,00", "12000 45000" }) {
//					WB.addLog2("QPA.test.ctor(String)=" + new QPA(tmp1, tmp2) + ", tmp1=" + tmp1 + ", tmp2=" + tmp2, "", "QPA");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("QPA.test():void, ex=" + ex.getMessage(), "", "QPA");
		}
	}
}