public final class Qty { // "quantity"
	// origin - 30.05.2025, last edit - 12.10.2025
	public String src, src1, src2;
	public UnitVal quantity;
	public static String unitDefault;

	static {
		try {
			Qty.unitDefault = Unit.strPiece;
		} catch (Exception ex) {
			WB.addLog("Qty.static ctor, ex=" + ex.getMessage(), "", "Qty");
		}
	}

	private void correct() throws Exception {// TODO
		// origin - 30.05.2025, last edit - 14.06.2025
		try {

		} catch (Exception ex) {
			WB.addLog("Qty.correct():void, ex=" + ex.getMessage(), "", "Qty");
		}
	}

	private void getSrc() throws Exception {
		// origin - 30.05.2025, last edit - 14.06.2025
		try {
			if (this.src.length() != 0) {
				String tmp = Etc.fixTrim(this.src); // "weightGross weightNetto"

				int posSpace1 = tmp.indexOf(" ");
				if (posSpace1 > 0) {
					this.src1 = Etc.fixTrim(tmp.substring(0, posSpace1)); // "weightGross"
					tmp = Etc.fixTrim(tmp.substring(posSpace1)); // "weightNetto"

					if (tmp.length() != 0) {
						this.src2 = Etc.fixTrim(tmp); // "weightNetto"
					}

				} else {
					this.src1 = tmp;
				}
			} else {
				this.src1 = "1.0";
			}

			if (this.src2.isEmpty()) {
				this.src2 = Qty.unitDefault;
			}
		} catch (Exception ex) {
			WB.addLog("Qty.getSrc():void, ex=" + ex.getMessage(), "", "Qty");
		}
	}

	private void getPart() throws Exception {
		// origin - 30.05.2025, last edit - 14.06.2025
		try {
			this.quantity = new UnitVal(this.src1, this.src2);
		} catch (Exception ex) {
			WB.addLog("Qty.getPart():void, ex=" + ex.getMessage(), "", "Qty");
		}
	}

	public Qty(String Src) throws Exception {
		// origin - 30.05.2025, last edit - 30.05.2025
		this.clear();
		this.src = Etc.fixTrim(Src); // weightGross weightNetto
		this.getSrc();
		this.getPart();
		this.correct();
	}

	public Qty() throws Exception {
		// origin - 30.05.2025, last edit - 30.05.2025
		this.clear();
		this.getSrc();
		this.getPart();
	}

	private void clear() throws Exception {
		// origin - 30.05.2025, last edit - 06.09.2025
		try {
			this.src = this.src1 = this.src2 = "";
			this.quantity = new UnitVal("Unit.Piece");
		} catch (Exception ex) {
			WB.addLog("Qty.clear():void, ex=" + ex.getMessage(), "", "Qty");
		}
	}

	public String toString() {
		// origin - 30.05.2025, last edit - 03.06.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway(" src ", this.src);
			res = res + Fmtr.addIfNotEmpty(" src1 ", this.src1);
			res = res + Fmtr.addIfNotEmpty(" src2 ", this.src2);
			res = res + Fmtr.addIfNotEmpty(" quantity.partVal ", this.quantity.partVal);
			res = res + Fmtr.addIfNotEmpty(" quantity.val ", this.quantity.val);
			res = res + Fmtr.addIfNotEmpty(" quantity.id ", this.quantity.id);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 30.05.2025, last edit - 14.06.2025
		try {

//			// test ctor(String)
//			WB.addLog2("Qty.test.ctor(String)", "", "Qty");
//			for (var tmp1 : new String[] { "", "12.00 (Unit.MinRate)", "1.7", "17,00", "4 Unit.MinRate", "12.00", "5",
//					"5.00", "5,00", "5.0", "5,0" }) {
//				WB.addLog2("Qty.test.ctor(String)=" + new Qty(tmp1), "", "Qty");
//			}

//			// test ctor()
//			WB.addLog2("Qty.test.ctor()", "", "Qty");
//			WB.addLog2("Qty.test.ctor()=" + new Qty(), "", "Qty");

		} catch (Exception ex) {
			WB.addLog("Qty.test():void, ex=" + ex.getMessage(), "", "Qty");
		}
	}
}