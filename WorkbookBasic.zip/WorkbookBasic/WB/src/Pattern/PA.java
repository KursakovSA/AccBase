public class PA { // "price amount"
	// origin - 26.05.2025, last edit - 30.05.2025
	public String src, src1, src2;
	public UnitVal price, amount;
	public static String unitDefault;

	static {
		try {
			PA.unitDefault = Unit.currCurrency.code;
		} catch (Exception ex) {
			WB.addLog("PA.static ctor, ex=" + ex.getMessage(), "", "PA");
		}
	}

	private void correct() throws Exception {
		// origin - 30.05.2025, last edit - 14.06.2025
		try {
			if ((price.val > 0) & (amount.val == 0)) {
				this.amount = new UnitVal(this.src1, PA.unitDefault);
			}
		} catch (Exception ex) {
			WB.addLog("PA.correct():void, ex=" + ex.getMessage(), "", "PA");
		}
	}

	private void getSrc() throws Exception {
		// origin - 26.05.2025, last edit - 14.06.2025
		try {
			if (this.src.length() != 0) {
				String tmp = Etc.fixTrim(this.src); // "price amount"

				int posSpace1 = tmp.indexOf(" ");
				if (posSpace1 > 0) {
					this.src1 = Etc.fixTrim(tmp.substring(0, posSpace1)); // "price"
					tmp = Etc.fixTrim(tmp.substring(posSpace1)); // "amount"

					if (tmp.length() != 0) {
						this.src2 = Etc.fixTrim(tmp); // "amount"
					}
				} else {
					this.src1 = tmp; // "price"
					this.src2 = tmp; // "amount = price"
				}
			}
		} catch (Exception ex) {
			WB.addLog("PA.getSrc():void, ex=" + ex.getMessage(), "", "PA");
		}
	}

	private void getPart() throws Exception {
		// origin - 26.05.2025, last edit - 14.06.2025
		try {
			this.price = new UnitVal(this.src1, PA.unitDefault);
			this.amount = new UnitVal(this.src2, PA.unitDefault);
		} catch (Exception ex) {
			WB.addLog("PA.getPart():void, ex=" + ex.getMessage(), "", "PA");
		}
	}

	public PA(String Src) throws Exception {
		// origin - 26.05.2025, last edit - 30.05.2025
		this.clear();
		this.src = Etc.fixTrim(Src); // price amount
		this.getSrc();
		this.getPart();
		this.correct();
	}

	public PA() throws Exception {
		// origin - 26.05.2025, last edit - 26.05.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 26.05.2025, last edit - 06.09.2025
		try {
			this.src = this.src1 = this.src2 = "";
			this.price = new UnitVal(UnitVal.currCurrencyInit);
			this.amount = new UnitVal(UnitVal.currCurrencyInit);
		} catch (Exception ex) {
			WB.addLog("PA.clear():void, ex=" + ex.getMessage(), "", "PA");
		}
	}

	public String toString() {
		// origin - 26.05.2025, last edit - 26.05.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway(" src ", this.src);
			res = res + Fmtr.addIfNotEmpty(" src1 ", this.src1);
			res = res + Fmtr.addIfNotEmpty(" src2 ", this.src2);

			res = res + Fmtr.addIfNotEmpty(" price ", this.price.id);
			res = res + Fmtr.addIfNotEmpty(" amount ", this.amount.id);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 26.05.2025, last edit - 14.06.2025
		try {

//			// test ctor(String)
//			WB.addLog2("PA.test.ctor(String)", "", "PA");
//			for (var tmp1 : new String[] { "12000.00 10000", "17000,00 15000,00", "12000.00" }) {
//				WB.addLog2("PA.test.ctor(String)=" + new PA(tmp1), "", "PA");
//			}

		} catch (Exception ex) {
			WB.addLog("PA.test():void, ex=" + ex.getMessage(), "", "PA");
		}
	}
}