public class BrutNet { // "weightBrutto weightNetto" // sectoralPawnshop
	// origin - 30.05.2025, last edit - 31.05.2025
	public String src, src1, src2;
	public UnitVal weightBrutto, weightNetto;
	public static double weightLogicalLimit;
	public static String unitDefault;

	static {
		try {
			BrutNet.weightLogicalLimit = 100.00;
			BrutNet.unitDefault = Unit.strGr;
		} catch (Exception ex) {
			WB.addLog("BrutNet.static ctor, ex=" + ex.getMessage(), "", "BrutNet");
		}
	}

	private void correct() throws Exception {
		// origin - 30.05.2025, last edit - 14.06.2025
		try {
			if (weightBrutto.val < weightNetto.val) {
				this.weightBrutto = new UnitVal(this.src1, BrutNet.unitDefault);
				this.weightNetto = new UnitVal(this.src1, BrutNet.unitDefault);
			}

			if ((weightBrutto.val > 0) & (weightNetto.val == 0)) {
				this.weightBrutto = new UnitVal(this.src1, BrutNet.unitDefault);
				this.weightNetto = new UnitVal(this.src1, BrutNet.unitDefault);
			}

			if ((weightBrutto.val == 0) & (weightNetto.val > 0)) {
				this.weightBrutto = new UnitVal(this.src2, BrutNet.unitDefault);
				this.weightNetto = new UnitVal(this.src2, BrutNet.unitDefault);
			}

			if (weightBrutto.val > BrutNet.weightLogicalLimit) {
				if (weightNetto.val < BrutNet.weightLogicalLimit) {
					this.weightBrutto = new UnitVal(this.src2, BrutNet.unitDefault);
				}
			}

			if (weightNetto.val > BrutNet.weightLogicalLimit) {
				if (weightBrutto.val < BrutNet.weightLogicalLimit) {
					this.weightNetto = new UnitVal(this.src1, BrutNet.unitDefault);
				}
			}
		} catch (Exception ex) {
			WB.addLog("BrutNet.correct():void, ex=" + ex.getMessage(), "", "BrutNet");
		}
	}

	private void getSrc() throws Exception {
		// origin - 30.05.2025, last edit - 14.06.2025
		try {
			if (this.src.length() != 0) {
				String tmp = Etc.fixTrim(this.src); // "weightBrutto weightNetto"

				int posSpace1 = tmp.indexOf(" ");
				if (posSpace1 > 0) {
					this.src1 = Etc.fixTrim(tmp.substring(0, posSpace1)); // "weightBrutto"
					tmp = Etc.fixTrim(tmp.substring(posSpace1)); // "weightNetto"

					if (tmp.length() != 0) {
						this.src2 = Etc.fixTrim(tmp); // "weightNetto"
					}

				} else {
					this.src1 = tmp;
				}
			}
		} catch (Exception ex) {
			WB.addLog("BrutNet.getSrc():void, ex=" + ex.getMessage(), "", "BrutNet");
		}
	}

	private void getPart() throws Exception {
		// origin - 30.05.2025, last edit - 14.06.2025
		try {
			this.weightBrutto = new UnitVal(this.src1, BrutNet.unitDefault);
			this.weightNetto = new UnitVal(this.src2, BrutNet.unitDefault);
		} catch (Exception ex) {
			WB.addLog("BrutNet.getPart(), ex=" + ex.getMessage(), "", "BrutNet");
		}
	}

	public BrutNet(String Src) throws Exception {
		// origin - 30.05.2025, last edit - 30.05.2025
		this.clear();
		this.src = Etc.fixTrim(Src); // weightBrutto weightNetto
		this.getSrc();
		this.getPart();
		this.correct();
	}

	public BrutNet() throws Exception {
		// origin - 30.05.2025, last edit - 26.05.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 30.05.2025, last edit - 06.09.2025
		try {
			this.src = this.src1 = this.src2 = "";
			this.weightBrutto = this.weightNetto = new UnitVal("0.0(Unit.Gr)");
		} catch (Exception ex) {
			WB.addLog("BrutNet.clear():void, ex=" + ex.getMessage(), "", "BrutNet");
		}
	}

	public String toString() {
		// origin - 30.05.2025, last edit - 31.05.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway(" src ", this.src);
			res = res + Fmtr.addIfNotEmpty(" src1 ", this.src1);
			res = res + Fmtr.addIfNotEmpty(" src2 ", this.src2);

			res = res + Fmtr.addIfNotEmpty(" weightBrutto ", this.weightBrutto.id);
			res = res + Fmtr.addIfNotEmpty(" weightNetto ", this.weightNetto.id);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 30.05.2025, last edit - 14.06.2025
		try {

//			// test ctor(String)
//			WB.addLog2("BrutNet.test.ctor(String)", "", "BrutNet");
//			for (var tmp1 : new String[] { "12.00 10.00", "14 13", "1.7", "17,00 15,00", "4 13", "230 23", "240 24" }) {
//				WB.addLog2("BrutNet.test.ctor(String)=" + new BrutNet(tmp1), "", "BrutNet");
//			}

		} catch (Exception ex) {
			WB.addLog("BrutNet.test():void, ex=" + ex.getMessage(), "", "BrutNet");
		}
	}
}