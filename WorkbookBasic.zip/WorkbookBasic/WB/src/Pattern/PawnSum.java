public class PawnSum { // sectoralPawnshop
	// origin - 25.05.2025, last edit - 30.05.2025
	public String src, src1, src2;
	public UnitVal estimatedValue, partMainDebt;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("PawnSum.static ctor, ex=" + ex.getMessage(), "", "PawnSum");
		}
	}

	public static String get(Pawn pawn) throws Exception {
		// origin - 31.05.2025, last edit - 14.06.2025
		String res = "";
		try {
			res = res + pawn.estimatedValue.partVal + " ";
			res = res + pawn.partMainDebt.partVal + " ";

			res = Etc.fixTrim(res);
			if (res.isEmpty() == false) {
				res = "PawnSum=" + res + "; ";
			}
		} catch (Exception ex) {
			WB.addLog("PawnSum.get(Pawn pawn):String, ex=" + ex.getMessage(), "", "PawnSum");
		}
		return res;
	}

	private void getSrc() throws Exception {
		// origin - 25.05.2025, last edit - 14.06.2025
		try {
			if (this.src.length() != 0) {
				String tmp = Etc.fixTrim(this.src); // "estimatedValue partMainDebt"

				int posSpace1 = tmp.indexOf(" ");
				if (posSpace1 > 0) {
					this.src1 = Etc.fixTrim(tmp.substring(0, posSpace1)); // "estimatedValue"
					tmp = Etc.fixTrim(tmp.substring(posSpace1)); // "partMainDebt"

					if (tmp.length() != 0) {
						this.src2 = Etc.fixTrim(tmp); // "partMainDebt"
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("PawnSum.getSrc():void, ex=" + ex.getMessage(), "", "PawnSum");
		}
	}

	private void getPart() throws Exception {
		// origin - 25.05.2025, last edit - 14.06.2025
		try {
			this.estimatedValue = new UnitVal(src1, Unit.currCurrency.code);
			this.partMainDebt = new UnitVal(src2, Unit.currCurrency.code);
		} catch (Exception ex) {
			WB.addLog("PawnSum.getPart():void, ex=" + ex.getMessage(), "", "PawnSum");
		}
	}

	public PawnSum(String Src) throws Exception {
		// origin - 25.05.2025, last edit - 14.06.2025
		this.clear();
		this.src = Etc.fixTrim(Src); // weightGross weightNetto estimatedValue partMainDebt
		this.getSrc();
		this.getPart();
	}

	public PawnSum() throws Exception {
		// origin - 25.05.2025, last edit - 25.05.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 25.05.2025, last edit - 06.09.2025
		try {
			this.src = this.src1 = this.src2 = "";
			this.estimatedValue = this.partMainDebt = new UnitVal(UnitVal.currCurrencyInit);
		} catch (Exception ex) {
			WB.addLog("PawnSum.clear():void, ex=" + ex.getMessage(), "", "PawnSum");
		}
	}

	public String toString() {
		// origin - 25.05.2025, last edit - 25.05.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway(" src ", this.src);
			res = res + Fmtr.addIfNotEmpty(" src1 ", this.src1);
			res = res + Fmtr.addIfNotEmpty(" src2 ", this.src2);

			res = res + Fmtr.addIfNotEmpty(" estimatedValue ", this.estimatedValue.id);
			res = res + Fmtr.addIfNotEmpty(" partMainDebt ", this.partMainDebt.id);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 25.05.2025, last edit - 14.06.2025
		try {

//			// test ctor(String)
//			WB.addLog2("PawnSumPat.test.ctor(String)", "", "PawnSumPat");
//			for (var tmp1 : new String[] { "12000.00 10000.00", "14000 13000", "17000 15000", "17000,00 15000,00" }) {
//				WB.addLog2("PawnSum.test.ctor(String)=" + new PawnSum(tmp1), "", "PawnSum");
//			}

		} catch (Exception ex) {
			WB.addLog("PawnSum.test():void, ex=" + ex.getMessage(), "", "PawnSum");
		}
	}
}