public class PawnAuto { // sectoralPawnshop
	// origin - 25.05.2025, last edit - 11.06.2025
	public String src, src1, src2, src3, src4, src5, src6;
	public String carDoc, carNumber, color, producer, VINCode, dateMFG;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("PawnAuto.static ctor, ex=" + ex.getMessage(), "", "PawnAuto");
		}
	}

	public static String get(Pawn pawn) throws Exception {
		// origin - 31.05.2025, last edit - 14.06.2025
		String res = "";
		try {
			if (pawn.carDoc.isEmpty() == false) {
				res = res + pawn.carDoc + " ";
				if (pawn.carNumber.isEmpty() == false) {
					res = res + pawn.carNumber + " ";
				}
				if (pawn.color.isEmpty() == false) {
					res = res + pawn.color + " ";
				}
				if (pawn.producer.isEmpty() == false) {
					res = res + pawn.producer + " ";
				}
				if (pawn.VINCode.isEmpty() == false) {
					res = res + pawn.VINCode + " ";
				}
				res = res + pawn.dateMFG + " ";
			}

			res = Etc.fixTrim(res);
			if (res.isEmpty() == false) {
				res = "PawnAuto=" + res + "; ";
			}
		} catch (Exception ex) {
			WB.addLog("PawnAuto.get(Pawn pawn):String, ex=" + ex.getMessage(), "", "PawnAuto");
		}
		return res;
	}

	private void getSrc() throws Exception {
		// origin - 25.05.2025, last edit - 14.06.2025
		try {
			if (this.src.length() != 0) {
				String tmp = Etc.fixTrim(this.src); // "carDoc, carNumber, color, producer, VINCode, dateMFG"

				int posSpace1 = tmp.indexOf(" ");
				if (posSpace1 > 0) {
					this.src1 = Etc.fixTrim(tmp.substring(0, posSpace1)); // "carDoc"
					tmp = Etc.fixTrim(tmp.substring(posSpace1)); // "carNumber, color, producer, VINCode, dateMFG"

					int posSpace2 = tmp.indexOf(" ");
					if (posSpace2 > 0) {
						this.src2 = Etc.fixTrim(tmp.substring(0, posSpace2)); // "carNumber"
						tmp = Etc.fixTrim(tmp.substring(posSpace2)); // "color, producer, VINCode, dateMFG"
					}

					int posSpace3 = tmp.indexOf(" ");
					if (posSpace3 > 0) {
						this.src3 = Etc.fixTrim(tmp.substring(0, posSpace3)); // "color"
						tmp = Etc.fixTrim(tmp.substring(posSpace3)); // "producer, VINCode, dateMFG"
					} else {
						this.src3 = Etc.fixTrim(tmp);
						tmp = "";
					}

					int posSpace4 = tmp.indexOf(" ");
					if (posSpace4 > 0) {
						this.src4 = Etc.fixTrim(tmp.substring(0, posSpace4)); // "producer"
						tmp = Etc.fixTrim(tmp.substring(posSpace4)); // "VINCode, dateMFG"
					} else {
						this.src4 = Etc.fixTrim(tmp);
						tmp = "";
					}

					int posSpace5 = tmp.indexOf(" ");
					if (posSpace5 > 0) {
						this.src5 = Etc.fixTrim(tmp.substring(0, posSpace5)); // "VINCode, dateMFG"
						tmp = Etc.fixTrim(tmp.substring(posSpace5)); // "dateMFG"
					} else {
						this.src5 = Etc.fixTrim(tmp);
						tmp = "";
					}

					if (tmp.length() != 0) {
						this.src6 = Etc.fixTrim(tmp); // "dateMFG"
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("PawnAuto.getSrc():void, ex=" + ex.getMessage(), "", "PawnAuto");
		}
	}

	private void getPart() throws Exception {
		// origin - 25.05.2025, last edit - 14.06.2025
		try {
			this.carDoc = src1;
			this.carNumber = src2;
			this.color = src3;
			this.producer = src4;
			this.VINCode = src5;
			this.dateMFG = src6;
		} catch (Exception ex) {
			WB.addLog("PawnAuto.getPart():void, ex=" + ex.getMessage(), "", "PawnAuto");
		}
	}

	public PawnAuto(String Src) throws Exception {
		// origin - 25.05.2025, last edit - 25.05.2025
		this.clear();
		this.src = Etc.fixTrim(Src); // "carDoc, carNumber, color, producer, VINCode, dateMFG"
		this.getSrc();
		this.getPart();
	}

	public PawnAuto() throws Exception {
		// origin - 25.05.2025, last edit - 25.05.2025
		this.clear();
	}

	public void clear() throws Exception {
		// origin - 21.05.2025, last edit - 14.06.2025
		try {
			this.src = this.src1 = this.src2 = this.src3 = this.src4 = this.src5 = this.src6 = "";
			this.carDoc = this.carNumber = this.color = this.producer = this.VINCode = this.dateMFG = "";
		} catch (Exception ex) {
			WB.addLog("PawnAuto.clear():void, ex=" + ex.getMessage(), "", "PawnAuto");
		}
	}

	public String toString() {
		// origin - 25.05.2025, last edit - 25.05.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway(" src ", this.src);
			res = res + Fmtr.addIfNotEmpty(" src1 ", this.src1);
			res = res + Fmtr.addIfNotEmpty(" src2 ", this.src2);
			res = res + Fmtr.addIfNotEmpty(" src3 ", this.src3);
			res = res + Fmtr.addIfNotEmpty(" src4 ", this.src4);
			res = res + Fmtr.addIfNotEmpty(" src5 ", this.src5);
			res = res + Fmtr.addIfNotEmpty(" src6 ", this.src6);

			res = res + Fmtr.addIfNotEmpty(" carDoc ", this.carDoc);
			res = res + Fmtr.addIfNotEmpty(" carNumber ", this.carNumber);
			res = res + Fmtr.addIfNotEmpty(" color ", this.color);
			res = res + Fmtr.addIfNotEmpty(" producer ", this.producer);
			res = res + Fmtr.addIfNotEmpty(" VINCode ", this.VINCode);
			res = res + Fmtr.addIfNotEmpty(" dateMFG ", this.dateMFG);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 25.05.2025, last edit - 14.06.2025
		try {

//			// test ctor(String) carDoc, carNumber, color, producer, VINCode, dateMFG
//			WB.addLog2("PawnAuto.test.ctor(String)", "", "PawnAuto");
//			for (var tmp1 : new String[] { "111 N222 красный Тойота 333 12.11.2005", "111 N222 красный Тойота 333",
//					"111 N222 красный Тойота" }) {
//				WB.addLog2("PawnAuto.test.ctor(String)=" + new PawnAuto(tmp1), "", "PawnAuto");
//			}

		} catch (Exception ex) {
			WB.addLog("PawnAuto.test():void, ex=" + ex.getMessage(), "", "PawnAuto");
		}
	}
}