import java.util.List;

public class SerNumDate {// Ser Number Date pattern
	// origin - 16.05.2025, last edit - 30.05.2025
	public String src, src1, src2, src3, code, description, ser, number, date;
	private static final List<String> listDelStr = List.of(",", "от");

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("SerNumDate.static ctor, ex=" + ex.getMessage(), "", "SerNumDate");
		}
	}

	private void getSrc() throws Exception {
		// origin - 16.05.2025, last edit - 30.05.2025
		try {
			if (this.src.length() != 0) {
				String tmp = Etc.fixTrim(this.src);

				int posSpace1 = tmp.indexOf(" ");
				if (posSpace1 > 0) {
					this.src1 = Etc.fixTrim(tmp.substring(0, posSpace1));
					// this.src2 = Etc.fixTrim(tmp.substring(posSpace1));
					tmp = Etc.fixTrim(tmp.substring(posSpace1));
				}

				int posSpace2 = tmp.indexOf(" ");
				if (posSpace2 > 0) {
					this.src2 = Etc.fixTrim(tmp.substring(0, posSpace2));
					tmp = Etc.fixTrim(tmp.substring(posSpace2));
				} else {
					this.src2 = tmp;
					tmp = "";
				}

				if (tmp.length() != 0) {
					this.src3 = Etc.fixTrim(tmp);
				}
			}
		} catch (Exception ex) {
			WB.addLog("SerNumDate.getSrc, ex=" + ex.getMessage(), "", "SerNumDate");
		}
	}

	private void getPart() throws Exception {
		// origin - 16.05.2025, last edit - 30.05.2025
		try {
			if (this.src1.length() != 0) {
				this.ser = this.src1;
			}

			if (this.src2.length() != 0) {
				this.number = this.src2;
			}

			if (this.src3.length() != 0) {
				this.date = this.src3;
			}

			this.code = this.description = this.src1 + " " + this.src2 + " " + this.src3;
		} catch (Exception ex) {
			WB.addLog("SerNumDate.getPart, ex=" + ex.getMessage(), "", "SerNumDate");
		}
	}

	public SerNumDate(String Src) throws Exception {
		// origin - 16.05.2025, last edit - 16.05.2025
		this.clear();
		this.src = Etc.fixTrim(Src); // ser number
		this.src = Etc.delStr(this.src, SerNumDate.listDelStr);
		this.getSrc();
		this.getPart();
	}

	public void clear() throws Exception {
		// origin - 16.05.2025, last edit - 30.05.2025
		try {
			this.src = this.src1 = this.src2 = this.src3 = this.code = this.description = "";
			this.ser = this.number = this.date = "";
		} catch (Exception ex) {
			WB.addLog("SerNumDate.clear, ex=" + ex.getMessage(), "", "SerNumDate");
		}
	}

	public SerNumDate() throws Exception {
		// origin - 16.05.2025, last edit - 16.05.2025
		this.clear();
	}

	public String toString() {
		// origin - 16.05.2025, last edit - 29.05.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway(" src ", this.src);
			res = res + Fmtr.addAnyway(" src1 ", this.src1);
			res = res + Fmtr.addAnyway(" src2 ", this.src2);
			res = res + Fmtr.addAnyway(" src3 ", this.src3);
			res = res + Fmtr.addIfNotEmpty(" code ", this.code);
			res = res + Fmtr.addIfNotEmpty(" description ", this.description);

			res = res + Fmtr.addIfNotEmpty(" ser ", this.ser);
			res = res + Fmtr.addIfNotEmpty(" number ", this.number);
			res = res + Fmtr.addIfNotEmpty(" date ", this.date);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 16.05.2025, last edit - 30.05.2025
		try {

//			// test ctor(String)
//			WB.addLog2("SerNumDatePat.test.ctor(String)", "", "SerNumDatePat");
//			for (var tmp1 : new String[] { "123 67890", "456   894357", "123 4567890 от 26.12.2025",
//					"123 4567890 26.12.2025" }) {
//				WB.addLog2("SerNumDate.test.ctor(String)=" + new SerNumDate(tmp1), "", "SerNumDate");
//			}

		} catch (Exception ex) {
			WB.addLog("SerNumDate.test, ex=" + ex.getMessage(), "", "SerNumDate");
		}
	}
}