import java.util.ArrayList;
import java.util.List;

public class Pawn extends ModelDto { // sectoralPawnshop
	// origin - 24.11.2024, last edit - 26.01.2025
	public String pawnId, goldContent, productCondition, VINCode, IMEICode, carDoc, carNumber, color, producer, dateMFG,
			context;
	public UnitVal estimatedValue, partMainDebt, weightGross, weightNetto, weightCarat;
	public RangeVal weightLogicalLimit, countLimit, allowedPartialRansomIfCountActivePawn;
	public static String strTemplate, strPawnDoc, strPawn;

	static {
		try {
			Pawn.strTemplate = "Template"; // ??magic string??
			Pawn.strPawnDoc = "PawnDoc"; // ??magic string??
			Pawn.strPawn = "Pawn"; // ??magic string??
		} catch (Exception ex) {
			WB.addLog("Pawn.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Pawn");
		} finally {
			Etc.doNothing();
		}
	}

	public void isExist() throws Exception {
		// origin - 11.01.2025, last edit - 24.01.2025
		super.isExist();
		try {
			List<ModelDto> srcDto = new ArrayList<ModelDto>();

			// case template pawn
			if (Etc.strContains(this.context, Pawn.strTemplate)) {
				srcDto = WB.abcLast.template;
				var tmp1 = ReadSet.getEqualsByCode(srcDto, this.id);
				if (tmp1.size() != 0) {
					var currDto = tmp1.getFirst();
					this.code = currDto.code;
					this.parent = currDto.parent;
					this.face1 = currDto.face1;
					this.face2 = currDto.face2;
					this.face = currDto.face;
					this.description = currDto.description;
					this.geo = currDto.geo;
					this.role = currDto.role;
					this.info = currDto.info;
					this.more = currDto.more;

					this.pawnId = MoreVal.getFieldByKey(this.more, "PawnId");
					this.goldContent = MoreVal.getFieldByKey(this.more, "GoldContent");
					this.productCondition = MoreVal.getFieldByKey(this.more, "productCondition");
					this.VINCode = MoreVal.getFieldByKey(this.more, "VINCode");
					this.IMEICode = MoreVal.getFieldByKey(this.more, "IMEICode");
					this.carDoc = MoreVal.getFieldByKey(this.more, "CarDoc");
					this.carNumber = MoreVal.getFieldByKey(this.more, "CarNumber");
					this.color = MoreVal.getFieldByKey(this.more, "Color");
					this.producer = MoreVal.getFieldByKey(this.more, "Producer");
					this.dateMFG = MoreVal.getFieldByKey(this.more, "DateMFG");

					this.estimatedValue = new UnitVal(MoreVal.getFieldByKey(this.more, "EstimatedValue"));
					this.partMainDebt = new UnitVal(MoreVal.getFieldByKey(this.more, "PartMainDebt"));
					this.weightGross = new UnitVal(MoreVal.getFieldByKey(this.more, "WeightGross"));
					this.weightNetto = new UnitVal(MoreVal.getFieldByKey(this.more, "WeightNetto"));
					this.weightCarat = new UnitVal(MoreVal.getFieldByKey(this.more, "WeightCarat"));

					this.weightLogicalLimit = new RangeVal(MoreVal.getFieldByKey(this.more, "WeightLogicalLimit"));
					this.countLimit = new RangeVal(MoreVal.getFieldByKey(this.more, "CountLimit"));
					this.allowedPartialRansomIfCountActivePawn = new RangeVal(
							MoreVal.getFieldByKey(this.more, "AllowedPartialRansomIfCountActivePawn"));
					this.isExist = true;
				}
			}

			// case pawndoc pawn //TODO

		} catch (Exception ex) {
			WB.addLog("Pawn.isExist, ex=" + ex.getMessage(), WB.strEmpty, "Pawn");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Pawn.isExist=" + this.isExist, WB.strEmpty,"Pawn");
	}

	public void fix() throws Exception {// TOTHINK
		// origin - 11.01.2025, last edit - 11.01.2025
		try {
			super.fix();
		} catch (Exception ex) {
			WB.addLog("Pawn.fix, ex=" + ex.getMessage(), WB.strEmpty, "Pawn");
		} finally {
			Etc.doNothing();
		}
	}

	public void isValid() throws Exception {// TOTHINK
		// origin - 11.01.2025, last edit - 11.01.2025
		super.isValid();
		try {

		} catch (Exception ex) {
			WB.addLog("Pawn.isValid, ex=" + ex.getMessage(), WB.strEmpty, "Pawn");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Pawn.isValid=" + this.isValid,WB.strEmpty,"Pawn");
	}

	public Pawn(String Id) throws Exception {
		// origin - 11.01.2025, last edit - 12.01.2025
		this.clear();
		this.src = this.id = Id;

		this.context = Pawn.strPawnDoc; // default
		if (Etc.strContains(Id, Pawn.strTemplate)) { // pawndoc pawn
			this.context = Pawn.strTemplate;
		}

		this.isExist();
		this.isValid();
		this.fix();
	}

	public Pawn() throws Exception {
		// origin - 11.01.2025, last edit - 11.01.2025
		this.clear();
	}

	public String toString() {
		// origin - 11.01.2025, last edit - 11.01.2025
		String res = WB.strEmpty;
		try {
			res = res + Fmtr.addAnyway("src ", this.src.length());
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code.length());
			res = res + Fmtr.addIfNotEmpty(", description ", this.description.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addIfNotEmpty(", pawnId ", this.pawnId);
			res = res + Fmtr.addIfNotEmpty(", goldContent ", this.goldContent);
			res = res + Fmtr.addIfNotEmpty(", productCondition ", this.productCondition);
			res = res + Fmtr.addIfNotEmpty(", VINCode ", this.VINCode);
			res = res + Fmtr.addIfNotEmpty(", IMEICode ", this.IMEICode);
			res = res + Fmtr.addIfNotEmpty(", carDoc ", this.carDoc);
			res = res + Fmtr.addIfNotEmpty(", carNumber ", this.carNumber);
			res = res + Fmtr.addIfNotEmpty(", color ", this.color);
			res = res + Fmtr.addIfNotEmpty(", producer ", this.producer);
			res = res + Fmtr.addIfNotEmpty(", dateMFG ", this.dateMFG);

			res = res + Fmtr.addAnyway(", estimatedValue ", this.estimatedValue.id);
			res = res + Fmtr.addAnyway(", partMainDebt ", this.partMainDebt.id);
			res = res + Fmtr.addAnyway(", weightGross ", this.weightGross.id);
			res = res + Fmtr.addAnyway(", weightNetto ", this.weightNetto.id);
			res = res + Fmtr.addAnyway(", weightCarat ", this.weightCarat.id);
			res = res + Fmtr.addAnyway(", weightLogicalLimit ", this.weightLogicalLimit.id);
			res = res + Fmtr.addAnyway(", countLimit ", this.countLimit.id);
			res = res + Fmtr.addAnyway(", allowedPartialRansomIfCountActivePawn ",
					this.allowedPartialRansomIfCountActivePawn.id);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public void clear() throws Exception {
		// origin - 11.01.2025, last edit - 25.01.2025
		try {
			super.clear();
			this.table = "Deal"; // ??magic string ??

			this.pawnId = this.goldContent = this.productCondition = this.VINCode = this.IMEICode = this.carDoc = this.carNumber = this.color = this.producer = this.dateMFG = this.context = WB.strEmpty;
			this.estimatedValue = this.partMainDebt = this.weightGross = this.weightNetto = this.weightCarat = new UnitVal();
			this.weightLogicalLimit = this.countLimit = this.allowedPartialRansomIfCountActivePawn = new RangeVal();

		} catch (Exception ex) {
			WB.addLog("Pawn.clear, ex=" + ex.getMessage(), WB.strEmpty, "Pawn");
		} finally {
			Etc.doNothing();
		}
	}

	public static void test() throws Exception {
		// origin - 24.09.2024, last edit - 26.01.2025
		try {

//			// ctor()
//			WB.addLog2("Pawn.test.ctor()=" + new Pawn(), WB.strEmpty, "Pawn");

//			// ctor(string)
//			for (var tmp : new String[] { WB.strEmpty, "PawnDoc.Template1.V1.Pawn" }) {
//				WB.addLog2("Pawn.test.ctor(string)=" + new Pawn(tmp), WB.strEmpty, "Pawn");
//			}

		} catch (Exception ex) {
			WB.addLog("Pawn.test, ex=" + ex.getMessage(), WB.strEmpty, "Pawn");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Pawn.test end ", WB.strEmpty, "Pawn");
	}

}