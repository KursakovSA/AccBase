import java.time.LocalDate;

public class Pawn extends Deal { // sectoralPawnshop
	// origin - 24.09.2023, last edit - 25.09.2024
	public UnitVal weightGross;  // sectoralPawnshop // TODO
	public UnitVal weightNetto;  // sectoralPawnshop // TODO
	public UnitVal weightCarat;  // sectoralPawnshop // TODO
	public UnitVal goldContent;  // sectoralPawnshop // TODO
	public LocalDate dateMFG; //TODO
	public String yearVehicleManufacture;  // sectoralPawnshop // TODO
	public UnitVal amountPropertyValuation;  // sectoralPawnshop // TODO
	public UnitVal amountLoan;  // sectoralPawnshop //TODO
	
	public Pawn() throws Exception { // TODO
		// origin - 24.09.2024, last edit - 24.09.2024
		super();
		// this.durationWarrantyPeriod = Deal.defaultDurationWarrantySpan;
		// this.durationCreditMaxLimit = Deal.defaultDurationCreditMaxLimit;
		// this.billingCycle = Deal.defaultBillingCycle;
	}

	public static void test() throws Exception { // TODO
		// origin - 24.09.2024, last edit - 24.09.2024
		try {

//			// ctor ("date1", "date2") different variants
//			Deal newDeal1 = new Deal(WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					"2024-09-01", "2024-09-11", WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					WB.strEmpty);
//			WB.addLog2("Deal.test.ctor(dto), newDeal1=" + newDeal1, WB.strEmpty, "Deal");
//			Deal newDeal2 = new Deal(WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					"2024-09-01;2024-09-06", "2024-09-11;2024-09-16", WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					WB.strEmpty, WB.strEmpty, WB.strEmpty);
//			WB.addLog2("Deal.test.ctor(dto), newDeal2=" + newDeal2, WB.strEmpty, "Deal");
//			Deal newDeal3 = new Deal(WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					"2024-09-01;2024-09-06;", "2024-09-11;2024-09-16;", WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					WB.strEmpty, WB.strEmpty, WB.strEmpty);
//			WB.addLog2("Deal.test.ctor(dto), newDeal3=" + newDeal3, WB.strEmpty, "Deal");
//			// test correctByDuration
//			Deal newDeal4 = new Deal(WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					"2024-09-01", "2024-09-11;2025-09-16;", WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
//					WB.strEmpty, WB.strEmpty);
//			WB.addLog2("Deal.test.ctor(dto), newDeal4=" + newDeal4, WB.strEmpty, "Deal");

//			// getId
//			Deal newDeal = new Deal();
//			WB.addLog2("Deal.getId(), res=" + newDeal.getId(), WB.strEmpty, "Face");
//			WB.addLog2("Deal.getId('', ''), res=" + newDeal.getId("", ""), WB.strEmpty, "Face");
//			WB.addLog2("Deal.getId('DealId', ''), res=" + newDeal.getId("DealId", ""), WB.strEmpty, "Deal");
//			WB.addLog2("Deal.getId('DealId', 'idStringGrowingDigitalInfobase'), res="
//					+ newDeal.getId("DealId", "idStringGrowingDigitalInfobase"), WB.strEmpty, "Deal");
//			WB.addLog2("Deal.getId('DealId', 'idStringGrowingDigitalGlobal'), res="
//					+ newDeal.getId("DealId", "idStringGrowingDigitalGlobal"), WB.strEmpty, "Deal");
//			WB.addLog2("Deal.getId('DealId', 'idIntegerGrowingDigitalGlobal'), res="
//					+ newDeal.getId("DealId", "idIntegerGrowingDigitalGlobal"), WB.strEmpty, "Deal");
//			WB.addLog2("Deal.getId('PawnId', ''), res=" + newDeal.getId("PawnId", ""), WB.strEmpty, "Deal");
//			WB.addLog2("Deal.getId('PawnId', 'idStringGrowingDigitalInfobase'), res="
//					+ newDeal.getId("PawnId", "idStringGrowingDigitalInfobase"), WB.strEmpty, "Deal");
//			WB.addLog2("Deal.getId('PawnId', 'idStringGrowingDigitalGlobal'), res="
//					+ newDeal.getId("PawnId", "idStringGrowingDigitalGlobal"), WB.strEmpty, "Deal");
//			WB.addLog2("Deal.getId('PawnId', 'idIntegerGrowingDigitalGlobal'), res="
//					+ newDeal.getId("PawnId", "idIntegerGrowingDigitalGlobal"), WB.strEmpty, "Deal");

		} catch (Exception ex) {
			WB.addLog("Pawn.test, ex=" + ex.getMessage(), WB.strEmpty, "Pawn");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Pawn.test end ", WB.strEmpty, "Pawn");
	}

}