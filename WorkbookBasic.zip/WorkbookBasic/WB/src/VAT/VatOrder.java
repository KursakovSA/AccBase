public final class VatOrder { // TODO
	// origin - 09.11.2025, last edit - 16.11.2025
	public static void test() throws Exception { // TODO
		// origin - 09.11.2025, last edit - 16.11.2025
		try {

		} catch (Exception ex) {
			WB.addLog("VatOrder.test():void, ex=" + ex.getMessage(), "", "VatOrder");
		}
	}
}