import java.util.List;

public class Price {
	// origin - 28.09.2023, last edit - 30.04.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, date1, date2, code, description, more;
	// special fields
	public UnitVal markupBasic, saleBasic;
	public static List<String> currency, currencyPair;

	static {
		try {
			Price.currency = Geo.getCurrency(); // description = "USD", "KZT", etc.
			Price.currencyPair = Geo.getCurrencyPair(); // description = "USD-KZT", "EUR-KZT", etc.
			// WB.addLog2("Price.currency=" + Price.currency, "", "Geo");
		} catch (Exception ex) {
			WB.addLog("Price.static ctor, ex=" + ex.getMessage(), "", "Price");
		}
	}

	public void getBasicCondition() throws Exception {
		// origin - 21.02.2025, last edit - 19.03.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.code), "Price");
			var dto = listDto.getFirst();
			this.markupBasic = new UnitVal(MoreVal.getFieldByKey(dto.more, "MarkupBasic"));
			this.saleBasic = new UnitVal(MoreVal.getFieldByKey(dto.more, "SaleBasic"));
		} catch (Exception ex) {
			WB.addLog("Price.getBasicCondition, ex=" + ex.getMessage(), "", "Price");
		}
	}

	public void isExist() throws Exception {
		// origin - 28.11.2024, last edit - 30.04.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.code), "Price");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.parent = dto.parent;
				this.date1 = dto.date1;
				this.date2 = dto.date2;
				this.code = DefVal.setCustom(this.code, dto.code);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.getBasicCondition();

				this.isExist = true;
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = "";
			}
		} catch (Exception ex) {
			WB.addLog("Price.isExist, ex=" + ex.getMessage(), "", "Price");
		}
	}

	public Price(String Id) throws Exception {
		// origin - 28.11.2024, last edit - 30.04.2025
		this.clear();
		this.src = Id;
		if (Id.isEmpty() == false) {
			this.id = this.code = Id;
		}
		this.isExist();
	}

	public Price() throws Exception {
		// origin - 05.12.2023, last edit - 30.04.2025
		this.clear();
		this.isExist();
		var root = Abc.getRoot(this.table); // get root from WB.abcLast
		this.id = root.id;
		this.code = root.code;
		this.description = root.description;
		this.more = root.more;
	}

	public void clear() throws Exception {
		// origin - 28.11.2024, last edit - 30.04.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = this.getClass().getName();
			this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.more = "";
			this.markupBasic = this.saleBasic = new UnitVal();
		} catch (Exception ex) {
			WB.addLog("Price.clear, ex=" + ex.getMessage(), "", "Price");
		}
	}

	public String toString() {
		// origin - 27.09.2024, last edit - 30.04.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());

			res = res + Fmtr.addAnyway(", markupBasic ", this.markupBasic.id);
			res = res + Fmtr.addAnyway(", saleBasic ", this.saleBasic.id);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 30.04.2025
		try {

//			// ctor (String)
//			WB.addLog2("Price.test.ctor(String)", "", "Price");
//			for (var tmp1 : new String[] { "Price.BasicCondition", "Price.tralala" }) {
//				WB.addLog2("Price.test.ctor(String)=" + new Price(tmp1), "", "Price");
//			}

//			// ctor ()
//			WB.addLog2("Price.test.ctor()", "", "Price");
//			WB.addLog2("Price.test.ctor()=" + new Price(), "", "Price");

		} catch (

		Exception ex) {
			WB.addLog("Price.test, ex=" + ex.getMessage(), "", "Price");
		}
	}
}