import java.util.List;

public class Price extends ModelDto {
	// origin - 28.09.2023, last edit - 04.03.2025
	public UnitVal markupBasic, saleBasic;
	public static List<String> currency;
	public static List<String> currencyPair;

	static {
		try {
			Price.currency = Geo.getCurrency(); // description = "USD", "KZT", etc.
			Price.currencyPair = Geo.getCurrencyPair(); // description = "USD-KZT", "EUR-KZT", etc.
			// WB.addLog2("Price.currency=" + Price.currency, WB.strEmpty, "Geo");
		} catch (Exception ex) {
			WB.addLog("Price.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Price");
		}
	}

	public void getBasicCondition() throws Exception {
		// origin - 21.02.2025, last edit - 04.03.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.code), "Price");
			var dto = listDto.getFirst();
			this.markupBasic = new UnitVal(MoreVal.getFieldByKey(dto.more, "MarkupBasic"));
			this.saleBasic = new UnitVal(MoreVal.getFieldByKey(dto.more, "SaleBasic"));
		} catch (Exception ex) {
			WB.addLog("Price.getBasicCondition, ex=" + ex.getMessage(), WB.strEmpty, "Price");
		}
	}

	public void fix() throws Exception {
		// origin - 29.12.2024, last edit - 04.03.2025
		try {
			super.fix();
		} catch (Exception ex) {
			WB.addLog("Price.fix, ex=" + ex.getMessage(), WB.strEmpty, "Price");
		}
	}

	public void isValid() throws Exception {
		// origin - 28.11.2024, last edit - 04.03.2025
		super.isValid();
		try {
			if (this.parent.isEmpty()) {
				this.isValid = false;
			}
		} catch (Exception ex) {
			WB.addLog("Price.isValid, ex=" + ex.getMessage(), WB.strEmpty, "Price");
		}
	}

	public void isExist() throws Exception {
		// origin - 28.11.2024, last edit - 04.03.2025
		super.isExist();
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.code), "Price");
			if (listDto.size() != WB.intZero) {
				var dto = listDto.getFirst();
				this.parent = dto.parent;
				this.date1 = dto.date1;
				this.date2 = dto.date2;
				this.description = dto.description;
				this.more = dto.more;
				this.getBasicCondition();

				this.isExist = true;
			}

		} catch (Exception ex) {
			WB.addLog("Price.isExist, ex=" + ex.getMessage(), WB.strEmpty, "Price");
		}
	}

	public Price(String Id) throws Exception {
		// origin - 28.11.2024, last edit - 04.03.2025
		this();
		this.src = Id;
		if (Id.isEmpty() == false) {
			this.id = this.code = Id;
		}
		this.isExist();
		this.isValid();
		this.fix();
	}

	public Price() throws Exception {
		// origin - 05.12.2023, last edit - 21.02.2025
		this.clear();
		this.isExist();
		var root = Abc.getRoot(this.table); // get root from WB.abcLast
		this.id = root.id;
		this.code = root.code;
		this.description = root.description;
		this.more = root.more;
		this.fix();
	}

	public void clear() throws Exception {
		// origin - 28.11.2024, last edit -04.03.2025
		try {
			super.clear();
			this.table = this.getClass().getName();
			this.markupBasic = this.saleBasic = new UnitVal();
		} catch (Exception ex) {
			WB.addLog("Price.clear, ex=" + ex.getMessage(), WB.strEmpty, "Price");
		}
	}

	public String toString() {
		// origin - 27.09.2024, last edit - 04.03.2025
		String res = WB.strEmpty;
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", ", this.slice);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());

			res = res + Fmtr.addAnyway(", markupBasic ", this.markupBasic.id);
			res = res + Fmtr.addAnyway(", saleBasic ", this.saleBasic.id);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 04.03.2025
		try {

//			// ctor ()
//			WB.addLog2("Price.test.ctor()=" + new Price(), WB.strEmpty, "Price");

//			// ctor (String Id)
//			for (var tmp1 : new String[] { "Price.BasicCondition", "Price.tralala" }) {
//				WB.addLog2("Price.test.ctor(String)=" + new Price(tmp1), WB.strEmpty, "Price");
//			}

		} catch (

		Exception ex) {
			WB.addLog("Price.test, ex=" + ex.getMessage(), WB.strEmpty, "Price");
		}
	}
}