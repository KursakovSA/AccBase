public class Price extends ModelDto {
	// origin - 28.09.2023, last edit - 29.12.2024
	public static Price basic, markupBasic, saleBasic;

	static {
		try {
			Price.basic = new Price("Price.Basic");
			Price.markupBasic = new Price("Price.MarkupBasic");
			Price.saleBasic = new Price("Price.SaleBasic");
		} catch (Exception ex) {
			WB.addLog("Price.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Price");
		} finally {
			Etc.doNothing();
		}
	}

	public void fix() throws Exception {
		// origin - 29.12.2024, last edit - 01.01.2025
		try {
			super.fix();
			this.role = DefVal.set(this.role, Role.priceBasic);
			this.info = DefVal.set(this.info, Info.genericBasic);
			this.unit = DefVal.set(this.unit, Unit.currUnit.id);
		} catch (Exception ex) {
			WB.addLog("Price.fix, ex=" + ex.getMessage(), WB.strEmpty, "Price");
		} finally {
			Etc.doNothing();
		}
	}

	public void isValid() throws Exception {
		// origin - 28.11.2024, last edit - 11.12.2024
		super.isValid();
		try {
			if (this.parent.isEmpty() | this.role.isEmpty() | this.info.isEmpty() | this.unit.isEmpty()) {
				this.isValid = false;
			}
		} catch (Exception ex) {
			WB.addLog("Price.isValid, ex=" + ex.getMessage(), WB.strEmpty, "Price");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Price.isValid=" + this.isValid,WB.strEmpty,"Price");
	}

	public void isExist() throws Exception {
		// origin - 28.11.2024, last edit - 22.12.2024
		super.isExist();
		try {
			for (var currPrice : WB.abcLast.price) {
				if (Etc.strEquals(currPrice.id, this.id)) {
					this.code = currPrice.code;
					this.parent = currPrice.parent;
					this.description = currPrice.description;
					this.role = currPrice.role;
					this.info = currPrice.info;
					this.unit = currPrice.unit;
					this.isExist = true;
					break;
				}
			}

		} catch (Exception ex) {
			WB.addLog("Price.isExist, ex=" + ex.getMessage(), WB.strEmpty, "Price");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Price.isExist=" + this.isExist, WB.strEmpty,"Price");
	}

	public Price(String Id) throws Exception {
		// origin - 28.11.2024, last edit - 29.12.2024
		this();
		this.src = Id;
		if (Id.isEmpty() == false) {
			this.id = this.code = Id;
		}
		this.isExist();
		this.isValid();
		this.fix();
	}

	public Price() throws Exception {
		// origin - 05.12.2023, last edit - 29.12.2024
		this.clear();
		this.isExist();
		var root = Abc.getRoot(this.table); // get root from WB.abcLast
		this.id = root.id;
		this.code = root.code;
		this.description = root.description;
		this.role = root.role;
		this.info = root.info;
		this.unit = root.unit;
		this.fix();
	}

	public void clear() throws Exception {
		// origin - 28.11.2024, last edit - 28.11.2024
		try {
			super.clear();
			this.table = this.getClass().getName();
		} catch (Exception ex) {
			WB.addLog("Price.clear, ex=" + ex.getMessage(), WB.strEmpty, "Price");
		} finally {
			Etc.doNothing();
		}
	}

	public String toString() {
		// origin - 27.09.2024, last edit - 16.12.2024
		String res = WB.strEmpty;
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", ", this.slice);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", ", this.unit);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 04.01.2025
		try {

//			// ctor ()
//			WB.addLog2("Price.test.ctor()=" + new Price(), WB.strEmpty, "Price");

//			// ctor (String Id)
//			for (var tmp : new String[] { "Price.Basic", "Price.tralala", "Price.KZT-USD" }) {
//				WB.addLog2("Price.test.ctor(String Id)=" + new Price(tmp), WB.strEmpty, "Price");
//			}

		} catch (Exception ex) {
			WB.addLog("Price.test, ex=" + ex.getMessage(), WB.strEmpty, "Price");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Price.test end ", WB.strEmpty, "Price");
	}
}
