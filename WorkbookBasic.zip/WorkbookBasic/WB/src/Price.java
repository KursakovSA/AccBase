import java.util.List;
import java.util.TreeSet;

public class Price extends ModelDto {
	// origin - 28.09.2023, last edit - 09.09.2024
	public static TreeSet<String> standard = new TreeSet<String>();
	public static TreeSet<String> sectoral = new TreeSet<String>();
	public static TreeSet<String> custom = new TreeSet<String>();

	static {
		try {
			Price.standard = new TreeSet<String>(List.of(WB.strEmpty, WB.strEmpty, WB.strEmpty));
			Price.sectoral = new TreeSet<String>(List.of(WB.strEmpty, WB.strEmpty, WB.strEmpty));
			Price.custom = new TreeSet<String>(List.of(WB.strEmpty, WB.strEmpty, WB.strEmpty));
		} catch (Exception ex) {
			WB.addLog("Price.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Price");
		} finally {
			Etc.doNothing();
		}
	}

	public Price(String Id, String Code, String Description) throws Exception {
		// origin - 05.12.2023, last edit - 11.08.2024
		super(Id, Code, Description);
		this.table = this.getClass().getName();
	}

	public Price() throws Exception {
		// origin - 05.12.2023, last edit - 11.08.2024
		super();
		this.table = this.getClass().getName();
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 16.09.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Price.test, ex=" + ex.getMessage(), WB.strEmpty, "Price");
		} finally {
			Etc.doNothing();
		}
		//WB.addLog2("Price.test end ", WB.strEmpty, "Price");
	}
}
