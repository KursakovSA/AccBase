import java.util.Arrays;
import java.util.TreeSet;

public class Price extends Model {
	// origin - 28.09.2023, last edit - 06.12.2023
	public static Price root;
	public Price parent;
	public Role role;
    public Info info;
    public Unit unit;
    
    static {
		root = new Price("Price","Price","PriceData");
		sectoral = new TreeSet<String>(Arrays.asList("", "", ""));
		custom = new TreeSet<String>(Arrays.asList("", "", ""));
	}
    
    public Price(String Id, String Code, String Description) {
		// origin - 05.12.2023, last edit - 05.12.2023
		this.id = Id;
		this.code = Code;
		this.description = Description;
	}
    
    public Price() {
		// origin - 05.12.2023, last edit - 05.12.2023
	}
    
    public static void test() {
		// origin - 28.10.2023, last edit - 05.12.2023
    	Logger.add("Price.test, Price.root=" + Price.root, "", "Price");
	}
}
