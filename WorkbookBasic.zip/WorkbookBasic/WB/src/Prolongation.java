import java.util.ArrayList;
import java.util.List;

public class Prolongation extends ModelDto {
	// origin - 31.10.2024, last edit - 26.01.2025
	public RangeVal countLimit;
	public String context;
	public static String strTerm, strPawnDoc, strProlongation;

	static {
		try {
			Prolongation.strTerm = "Term"; // ??magic string??
			Prolongation.strPawnDoc = "PawnDoc"; // ??magic string??
			Prolongation.strProlongation = "Prolongation"; // ??magic string??
		} catch (Exception ex) {
			WB.addLog("Prolongation.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Prolongation");
		} finally {
			Etc.doNothing();
		}
	}

	public void isExist() throws Exception {
		// origin - 10.01.2025, last edit - 12.01.2025
		super.isExist();
		try {
			List<ModelDto> srcDto = new ArrayList<ModelDto>();

			// case term prolongation
			if (Etc.strContains(this.context, Prolongation.strTerm)) {
				srcDto = WB.abcLast.template;
				var tmp1 = ReadSet.getEqualsByCode(srcDto, this.id);
				if (tmp1.size() != 0) {
					var currDto = tmp1.getFirst();
					this.code = currDto.code;
					this.parent = currDto.parent;
					this.face1 = currDto.face1;
					this.face2 = currDto.face2;
					this.face = currDto.face;
					this.description = currDto.description;
					this.geo = currDto.geo;
					this.role = currDto.role;
					this.info = currDto.info;
					this.more = currDto.more;
					this.countLimit = new RangeVal(MoreVal.getFieldByKey(this.more, "CountLimit"));
					this.isExist = true;
				}
			}

			// case pawndoc prolongation //TODO

		} catch (Exception ex) {
			WB.addLog("Prolongation.isExist, ex=" + ex.getMessage(), WB.strEmpty, "Prolongation");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Prolongation.isExist=" + this.isExist,
		// WB.strEmpty,"Prolongation);
	}

	public void fix() throws Exception {// TOTHINK
		// origin - 10.01.2025, last edit - 11.01.2025
		try {
			super.fix();
		} catch (Exception ex) {
			WB.addLog("Prolongation.fix, ex=" + ex.getMessage(), WB.strEmpty, "Prolongation");
		} finally {
			Etc.doNothing();
		}
	}

	public void isValid() throws Exception {// TOTHINK
		// origin - 10.01.2025, last edit - 11.01.2025
		super.isValid();
		try {

		} catch (Exception ex) {
			WB.addLog("Prolongation.isValid, ex=" + ex.getMessage(), WB.strEmpty, "Prolongation");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Prolongation.isValid=" +
		// this.isValid,WB.strEmpty,"Prolongation");
	}

	public Prolongation(String Id) throws Exception {
		// origin - 10.01.2025, last edit - 12.01.2025
		this.clear();
		this.src = this.id = Id;

		this.context = Prolongation.strPawnDoc; // default
		if (Etc.strContains(Id, Prolongation.strTerm)) { // term prolongation
			this.context = Prolongation.strTerm;
		}

		this.isExist();
		this.isValid();
		this.fix();
	}

	public Prolongation() throws Exception {
		// origin - 10.01.2025, last edit - 10.01.2025
		this.clear();
	}

	public String toString() {
		// origin - 10.01.2025, last edit - 10.01.2025
		String res = WB.strEmpty;
		try {
			res = res + Fmtr.addAnyway("src ", this.src.length());
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code.length());
			res = res + Fmtr.addIfNotEmpty(", description ", this.description.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addAnyway(", countLimit ", this.countLimit.id);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public void clear() throws Exception {
		// origin - 10.01.2025, last edit - 10.01.2025
		try {
			super.clear();
			this.table = "Deal"; // ??magic string ??
			this.countLimit = new RangeVal();

		} catch (Exception ex) {
			WB.addLog("Prolongation.clear, ex=" + ex.getMessage(), WB.strEmpty, "Prolongation");
		} finally {
			Etc.doNothing();
		}
	}

	public static void test() throws Exception {
		// origin - 31.10.2024, last edit - 25.01.2025
		try {

//			// ctor()
//			WB.addLog2("Prolongation.test.ctor()=" + new Prolongation(), WB.strEmpty, "Prolongation");

//			// ctor(string)
//			for (var tmp : new String[] { WB.strEmpty, "PawnDoc.Template1.V1.Term1.Prolongation",
//					"PawnDoc.Template1.V1.Term2.Prolongation" }) {
//				WB.addLog2("Prolongation.test.ctor(string)=" + new Prolongation(tmp), WB.strEmpty, "Prolongation");
//			}

		} catch (Exception ex) {
			WB.addLog("Prolongation.test, ex=" + ex.getMessage(), WB.strEmpty, "Prolongation");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Prolongation.test end ", WB.strEmpty, "Prolongation");
	}

}