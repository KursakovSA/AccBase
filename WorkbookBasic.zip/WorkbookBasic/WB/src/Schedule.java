public class Schedule extends Model {
	// origin - 14.01.2024, last edit - 14.01.2024
	public String everyYear = new String();
	public String everyQuartier = new String();
	public String everyMonth = new String();
	public String everyWeek = new String();
	public String everyDay = new String();
	public String everyHour = new String();
	public String everyMinute = new String();
	public String everySecond = new String();
	
	public Schedule() {
		// origin - 14.01.2024, last edit - 14.01.2024
	}

	public static void test() {
		// origin - 14.01.2024, last edit - 14.01.2024
	}

}
