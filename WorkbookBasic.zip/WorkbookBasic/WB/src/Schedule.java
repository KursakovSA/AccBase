public class Schedule extends ModelDto {
	// origin - 14.01.2024, last edit - 04.08.2024

	public String everyYear = new String();// TOTHINK
	public String everyQuartier = new String();// TOTHINK
	public String everyMonth = new String();// TOTHINK
	public String everyWeek = new String();// TOTHINK
	public String everyDay = new String();// TOTHINK
	public String everyHour = new String();// TOTHINK
	public String everyMinute = new String();// TOTHINK
	public String everySecond = new String();// TOTHINK

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Schedule.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Schedule");
		} finally {
			Etc.doNothing();
		}
	}

	public Schedule() throws Exception {
		// origin - 14.01.2024, last edit - 04.08.2024
		super();
	}

	public static void test() throws Exception {
		// origin - 14.01.2024, last edit - 06.07.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Schedule.test, ex=" + ex.getMessage(), WB.strEmpty, "Schedule");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Schedule.test end ", WB.strEmpty, "Schedule");
	}

}
