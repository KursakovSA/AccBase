import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class TemplateDocTerm {
	// origin - 04.09.2025, last edit - 18.10.2026
	// common fields
	public String table, src, id, parent, date1, date2, face1, face2, face, code, description, geo, role, info, more,
			mark, defect;
	// special fields
	public String fullName, comment;
	public Map<String, List<String>> templateDocMap;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("TemplateDocTerm.static ctor, ex=" + ex.getMessage(), "", "TemplateDocTerm");
		}
	}

	public static List<String> getByParentCode(String parentId, String code) throws Exception {
		// origin - 13.10.2026, last edit - 19.10.2026
		List<String> res = new ArrayList<String>();
		try {
			if (Etc.strNotValid(parentId, code)) {
				return res;
			}

			var tmp = TemplateDocTerm.getByParent(parentId);
			if (tmp.isEmpty() == false) {
				if (tmp.containsKey(code)) {
					res = tmp.get(code);
				}
			}
		} catch (Exception ex) {
			WB.addLog("TemplateDocTerm.getByParentCode(2String):List<String>, ex=" + ex.getMessage(), "",
					"TemplateDocTerm");
		}
		return res;
	}

	private static Map<String, List<String>> getByParent(String parentId) throws Exception {
		// origin - 13.10.2026, last edit - 19.10.2026
		Map<String, List<String>> res = new HashMap<>();
		try {
			if (Etc.strNotValid(parentId)) {
				return res;
			}
			var tmp = new TemplateDocTerm(parentId);
			if (tmp.templateDocMap.isEmpty() == false) {
				res = tmp.templateDocMap;
			}
		} catch (Exception ex) {
			WB.addLog("TemplateDocTerm.getByParent(String):Map<String, List<String>>, ex=" + ex.getMessage(), "",
					"TemplateDocTerm");
		}
		return res;
	}

	private Map<String, List<String>> getMap() throws Exception {
		// origin - 13.10.2026, last edit - 13.10.2026
		Map<String, List<String>> res = new HashMap<>();
		try {
			if (this.code.isEmpty()) {
				return res;
			}
			if (this.description.isEmpty()) {
				return res;
			}
			var tmp = List.of(this.description.split(";"));
			int count = 0;
			for (var currCode : this.code.split(";")) {
				if (tmp.size() >= count + 1) {
					res.put(currCode, List.of(tmp.get(count).split(",")));
				}
				count = count + 1;
			}
		} catch (Exception ex) {
			WB.addLog("TemplateDocTerm.getMap():Map<String, List<String>>, ex=" + ex.getMessage(), "",
					"TemplateDocTerm");
		}
		return res;
	}

	private void getByParentTemplate(String parentId) throws Exception {
		// origin - 13.10.2026, last edit - 19.10.2026
		try {
			if (Etc.strNotValid(parentId)) {
				return;
			}

			BasicDto bDto = new BasicDto("Deal", parentId);
			var templateId = MoreVal.getFieldByKey(bDto.more, "TemplateId");
			if (templateId.isEmpty() == false) {
				this.src = this.parent = templateId;
				this.isExist();
			}
		} catch (Exception ex) {
			WB.addLog("TemplateDocTerm.getByParentTemplate(String):void, ex=" + ex.getMessage(), "", "TemplateDocTerm");
		}
	}

	private void fix() throws Exception {
		// origin - 11.10.2026, last edit - 11.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}

			this.date1 = DefVal.set(this.date1, WB.minDateSupported.toString());
			this.date2 = DefVal.set(this.date2, WB.maxDateSupported.toString());
			this.mark = DefVal.set(this.mark, "Mark.DD");
		} catch (Exception ex) {
			WB.addLog("TemplateDocTerm.fix():void, ex=" + ex.getMessage(), "", "TemplateDocTerm");
		}
	}

	private void validate() throws Exception {
		// origin - 08.09.2025, last edit - 10.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}

			this.defect = Fmtr.addIfStrEmpty(this.defect, this.description, "empty description; ");
		} catch (Exception ex) {
			WB.addLog("TemplateDocTerm.validate():void, ex=" + ex.getMessage(), "", "TemplateDocTerm");
		}
	}

	private void isExist() throws Exception {
		// origin - 04.09.2025, last edit - 13.10.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleInfoFilter(this.parent, "Role.Deal.TemplateDoc", "Info.Deal.Term"), "Deal");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.id = dto.id;
				this.code = dto.code;
				this.face1 = dto.face1;
				this.face2 = dto.face2;
				this.face = dto.face;
				this.description = dto.description;
				this.geo = dto.geo;
				this.role = dto.role;
				this.info = dto.info;
				this.more = dto.more;
				this.templateDocMap = this.getMap();
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.clear();
			}
		} catch (Exception ex) {
			WB.addLog("TemplateDocTerm.isExist():void, ex=" + ex.getMessage(), "", "TemplateDocTerm");
		}
	}

	public TemplateDocTerm(String ParentId) throws Exception {
		// origin - 04.09.2025, last edit - 13.10.2026
		this.clear();
		ParentId = Etc.fixTrim(ParentId);
		this.src = this.parent = ParentId;
		this.isExist();

		if (this.id.isEmpty()) {
			this.getByParentTemplate(ParentId);
		}

		this.fix();
		this.validate();
	}

	public TemplateDocTerm() throws Exception {
		// origin - 04.09.2025, last edit - 05.09.2025
		this.clear();
	}

	public String toString() {
		// origin - 04.09.2025, last edit - 13.10.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", templateDocMap ", this.templateDocMap);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	private void getFieldFromMore() throws Exception {
		// origin - 04.09.2025, last edit - 13.10.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("TemplateDocTerm.getFieldFromMore():void, ex=" + ex.getMessage(), "", "TemplateDocTerm");
		}
	}

	private void clear() throws Exception {
		// origin - 04.09.2025, last edit - 13.10.2026
		try {
			this.table = "Deal";
			this.src = this.id = this.parent = this.date1 = this.date2 = this.face1 = this.face2 = this.face = this.code = "";
			this.description = this.geo = this.role = this.info = this.more = this.mark = this.defect = "";
			this.fullName = this.comment = "";
			this.templateDocMap = new LinkedHashMap<>();
		} catch (Exception ex) {
			WB.addLog("TemplateDocTerm.clear():void, ex=" + ex.getMessage(), "", "TemplateDocTerm");
		}
	}

	public static void test() throws Exception {
		// origin - 04.09.2025, last edit - 14.10.2025
		try {

//			WB.addLog2("TemplateDocTerm.test.getCurr(2String):List<String>", "", "TemplateDocTerm");
//			for (var tmp1 : new String[] { null, "", "Deal.Face.Template1", "лс 000000", "лс 111111",
//					"лс 000000, усл 100", "лс 111111, усл 100", "Deal.tralala", "Deal.Test1" }) {
//				for (var tmp2 : new String[] { null, "", "Deal", "Specification", "", "Tralala" }) {
//					var tmp3 = TemplateDocTerm.getByParentCode(tmp1, tmp2);
//					WB.addLog2("TemplateDocTerm.test.getByParentCode(2String):List<String>, res=" + tmp3 + ", tmp1="
//							+ tmp1 + ", tmp2=" + tmp2, "", "TemplateDocTerm");
//				}
//			}

//			WB.addLog2("TemplateDocTerm.test.ctor(String)", "", "TemplateDocTerm");
//			for (var tmp1 : new String[] { null, "", "Deal.Face.Template1", "лс 000000", "лс 111111",
//					"лс 000000, усл 100", "лс 111111, усл 100", "Deal.tralala", "Deal.Test1" }) {
//				WB.addLog2("TemplateDocTerm.test.ctor(String)=" + new TemplateDocTerm(tmp1) + ", tmp1=" + tmp1, "",
//						"TemplateDocTerm");
//			}

		} catch (Exception ex) {
			WB.addLog("TemplateDocTerm.test():void, ex=" + ex.getMessage(), "", "TemplateDocTerm");
		}
	}
}