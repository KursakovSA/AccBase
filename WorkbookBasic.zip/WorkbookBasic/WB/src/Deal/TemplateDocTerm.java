import java.util.ArrayList;
import java.util.List;

public final class TemplateDocTerm {
	// origin - 04.09.2025, last edit - 16.09.2026
	// common fields
	public String table, src, id, parent, date1, date2, face1, face2, face, code, description, geo, role, info, more,
			mark, defect;
	// special fields
	public String fullName, comment;
	public static List<String> nameList;

	static {
		try {
			TemplateDocTerm.nameList = List.of("TemplateId", "TermId");
		} catch (Exception ex) {
			WB.addLog("TemplateDocTerm.static ctor, ex=" + ex.getMessage(), "", "TemplateDocTerm");
		}
	}

	public static List<String> getCurrById(String date1, String templateDealId) throws Exception {
		// origin - 16.09.2025, last edit - 14.09.2026
		List<String> res = new ArrayList<String>();
		try {
			var modelDtoList = DAL.getByTemplate(WB.lastConnWork, Qry.getIdInfoFilter(templateDealId, "Info.Deal.Term"),
					"Deal");
			var dealDtoList = DealDto.get(modelDtoList);
			var tmp = DealDto.getChrono(DateTool.getLocalDate(date1), dealDtoList);
			if (tmp.size() != 0) {
				for (var curr : tmp) {
					var tmp2 = new TemplateDocTerm(curr);
					if (tmp2.description.isEmpty() == false) {
						res.addAll(Fmtr.getListStrBySplit(tmp2.description, " "));
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("TemplateDocTerm.getCurrById(2String):List<String>, ex=" + ex.getMessage(), "",
					"TemplateDocTerm");
		}
		return res;
	}

	public static List<String> getCurr(String date1) throws Exception { // ?? is need ??
		// origin - 05.09.2025, last edit - 14.09.2026
		List<String> res = new ArrayList<String>();
		try {
			var modelDtoList = DAL.getByTemplate(WB.lastConnWork, Qry.getInfoFilter("Info.Deal.Term"), "Deal");
			var dealDtoList = DealDto.get(modelDtoList);
			var tmp = DealDto.getChrono(DateTool.getLocalDate(date1), dealDtoList);
			if (tmp.size() != 0) {
				for (var curr : tmp) {
					var tmp2 = new TemplateDocTerm(curr);
					if (tmp2.description.isEmpty() == false) {
						res.addAll(Fmtr.getListStrBySplit(tmp2.description, " "));
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("TemplateDocTerm.getCurr(String):List<String>, ex=" + ex.getMessage(), "", "TemplateDocTerm");
		}
		return res;
	}

	public static List<String> get(String templateDealId) throws Exception {
		// origin - 05.09.2025, last edit - 14.09.2026
		List<String> res = new ArrayList<String>();
		try {
			var templateDocTerm = new TemplateDocTerm(templateDealId);
			res = Fmtr.getListStrBySplit(templateDocTerm.description, " ");
		} catch (Exception ex) {
			WB.addLog("TemplateDocTerm.get(String):List<String>, ex=" + ex.getMessage(), "", "TemplateDocTerm");
		}
		return res;
	}

	private void fix() throws Exception {
		// origin - 11.10.2026, last edit - 11.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}

			this.date1 = DefVal.set(this.date1, WB.minDateSupported.toString());
			this.date2 = DefVal.set(this.date2, WB.maxDateSupported.toString());
			this.mark = DefVal.set(this.mark, "Mark.DD");
		} catch (Exception ex) {
			WB.addLog("TemplateDocTerm.fix():void, ex=" + ex.getMessage(), "", "TemplateDocTerm");
		}
	}

	private void validate() throws Exception {
		// origin - 08.09.2025, last edit - 10.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}

			this.defect = Fmtr.addIfStrEmpty(this.defect, this.description, "empty description; ");
		} catch (Exception ex) {
			WB.addLog("TemplateDocTerm.validate():void, ex=" + ex.getMessage(), "", "TemplateDocTerm");
		}
	}

	private void isExist() throws Exception {
		// origin - 04.09.2025, last edit - 11.10.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdInfoFilter(this.id, "Info.Deal.Term"), "Deal");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.code = dto.code;
				this.parent = dto.parent;
				var tmp = new SpanDate(dto.date1, dto.date2);
				this.date1 = tmp.date1.getFirst();
				this.date2 = tmp.date2.getFirst();
				this.face1 = dto.face1;
				this.face2 = dto.face2;
				this.face = dto.face;
				// this.description = dto.description;
				this.geo = dto.geo;
				this.role = dto.role;
				this.info = dto.info;
				this.more = this.more + dto.more;
				this.getFieldFromMore();
			}
			if (listDto.size() == 0) {
				this.clear();
			}
		} catch (Exception ex) {
			WB.addLog("TemplateDocTerm.isExist():void, ex=" + ex.getMessage(), "", "TemplateDocTerm");
		}
	}

	// get new TemplateDocTerm by DealDto,... without isExist
	public TemplateDocTerm(DealDto mDto) throws Exception {
		// origin - 05.09.2025, last edit - 11.10.2026
		this.clear();
		this.src = mDto.id + "," + mDto.code;
		this.id = mDto.id;
		this.parent = mDto.parent;
		this.date1 = mDto.date1;
		this.date2 = mDto.date2;
		this.face1 = mDto.face1;
		this.face2 = mDto.face2;
		this.face = mDto.face;
		this.description = mDto.description;
		this.geo = mDto.geo;
		this.role = mDto.role;
		this.info = mDto.info;
		this.more = mDto.more;
		this.getFieldFromMore();
		this.mark = mDto.mark;
		this.fix();
		this.validate();
	}

	public TemplateDocTerm(String TemplateDealId) throws Exception {
		// origin - 04.09.2025, last edit - 11.10.2026
		this.clear();
		this.src = TemplateDealId;
		this.id = TemplateDealId;
		this.isExist();
		this.fix();
		this.validate();
	}

	public TemplateDocTerm() throws Exception {
		// origin - 04.09.2025, last edit - 05.09.2025
		this.clear();
	}

	public String toString() {
		// origin - 04.09.2025, last edit - 16.09.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	private void getFieldFromMore() throws Exception {
		// origin - 04.09.2025, last edit - 16.09.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.description = MoreVal.getFieldByKey(this.more, "TemplateDoc");
		} catch (Exception ex) {
			WB.addLog("TemplateDocTerm.getFieldFromMore():void, ex=" + ex.getMessage(), "", "TemplateDocTerm");
		}
	}

	private void clear() throws Exception {
		// origin - 04.09.2025, last edit - 11.10.2026
		try {
			this.table = "Deal";
			this.src = this.id = this.parent = this.date1 = this.date2 = this.face1 = this.face2 = this.face = this.code = "";
			this.description = this.geo = this.role = this.info = this.more = this.mark = this.defect = "";
			this.fullName = this.comment = "";
		} catch (Exception ex) {
			WB.addLog("TemplateDocTerm.clear():void, ex=" + ex.getMessage(), "", "TemplateDocTerm");
		}
	}

	public static void test() throws Exception {
		// origin - 04.09.2025, last edit - 16.09.2025
		try {

//			WB.addLog2("TemplateDocTerm.test.getCurrById(2String):List<String>", "", "TemplateDocTerm");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-24", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "", "Deal.Face.Template1", "Deal.Tralala" }) {
//					WB.addLog2("TemplateDocTerm.test.getCurrById(2String):List<String>, res="
//							+ TemplateDocTerm.getCurrById(tmp1, tmp2) + ", date1=" + tmp1 + ", templateDealId=" + tmp2,
//							"", "TemplateDocTerm");
//				}
//			}

//			WB.addLog2("TemplateDocTerm.test.getCurr(String):List<String>", "", "TemplateDocTerm");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-24", "2025-08-15" }) {
//				WB.addLog2("TemplateDocTerm.test.getCurr(String):List<String>, res=" + TemplateDocTerm.getCurr(tmp1)
//						+ ", date1=" + tmp1, "", "TemplateDocTerm");
//			}

//			WB.addLog2("TemplateDocTerm.test.get(String):List<String>", "", "TemplateDocTerm");
//			for (var tmp1 : new String[] { "Deal.Face.Template1" }) {
//				WB.addLog2("TemplateDocTerm.test.get(String):List<String>, res=" + TemplateDocTerm.get(tmp1)
//						+ ", templateId=" + tmp1, "", "TemplateDocTerm");
//			}

//			WB.addLog2("TemplateDocTerm.test.ctor(String)", "", "TemplateDocTerm");
//			for (var tmp1 : new String[] { "", "Deal.Face.Template1", "Deal.Tralala" }) {
//				WB.addLog2("TemplateDocTerm.test.ctor(String)=" + new TemplateDocTerm(tmp1), "", "TemplateDocTerm");
//			}

		} catch (Exception ex) {
			WB.addLog("TemplateDocTerm.test():void, ex=" + ex.getMessage(), "", "TemplateDocTerm");
		}
	}
}