public final class DeliveryTerm { // TODO
	// origin - 28.08.2025, last edit -20.11.2025
	// common fields
	public String table, src, id, parent, face1, face2, face, date1, date2, code, description, geo, role, info, more,
			mark, defect;
	// special fields
	public String fullName, comment, templateId, termId;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("DeliveryTerm.static ctor, ex=" + ex.getMessage(), "", "DeliveryTerm");
		}
	}

//	public static String getCodePattern(String inCode, String strObj) throws Exception {// TODO
//		// origin - 28.08.2025, last edit - 02.09.2025
//		String res = "";
//		inCode = Etc.fixTrim(inCode);
//		strObj = Etc.fixTrim(strObj);
//		try {
//			if (strObj.isEmpty() == false) {
//				res = res + inCode + "." + Etc.fixTrim(strObj);// ex. "PawnDoc.Template1.V1.Term1" + "." + "Pool"
//			}
//		} catch (Exception ex) {
//			WB.addLog("DeliveryTerm.getCodePattern(2String):String, ex=" + ex.getMessage(), "", "DeliveryTerm");
//		}
//		return res;
//	}

	private void validate() throws Exception { // TODO
		// origin - 20.11.2025, last edit - 23.05.2026
		try {
			if (this.src.isEmpty() == false) {
				this.defect = Fmtr.addIfStrEmpty(this.defect, this.termId, "empty termId; ");
				this.defect = Fmtr.addIfStrEmpty(this.defect, this.templateId, "empty templateId; ");
			}
		} catch (Exception ex) {
			WB.addLog("DeliveryTerm.validate():void, ex=" + ex.getMessage(), "", "DeliveryTerm");
		}
	}

	private void isExist() throws Exception {// TODO
		// origin - 28.08.2025, last edit -20.11.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), "Deal");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.code = dto.code;
				this.parent = dto.parent;
				this.face1 = dto.face1;
				this.face2 = dto.face2;
				this.face = dto.face;
				this.description = dto.description;
				this.geo = dto.geo;
				this.role = dto.role;
				this.info = dto.info;
				this.more = dto.more;
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("DeliveryTerm.isExist():void, ex=" + ex.getMessage(), "", "DeliveryTerm");
		}
	}

	public DeliveryTerm(String Id) throws Exception {// TODO
		// origin - 28.08.2025, last edit - 20.11.2025
		this.clear();
		this.src = this.id = this.code = Id;
		this.isExist();
		this.validate();
	}

	public DeliveryTerm() throws Exception {// TODO
		// origin - 28.08.2025, last edit - 28.08.2025
		this.clear();
	}

	public String toString() {// TODO
		// origin - 28.08.2025, last edit - 20.11.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code.length());
			res = res + Fmtr.addIfNotEmpty(", description ", this.description.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", templateId ", this.templateId);
			res = res + Fmtr.addIfNotEmpty(", termId ", this.termId);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	private void getFieldFromMore() throws Exception {// TODO
		// origin - 28.08.2025, last edit - 28.08.2025
		try {
			this.templateId = MoreVal.getFieldByKey(this.more, "TemplateId");
			this.termId = MoreVal.getFieldByKey(this.more, "TermId");
		} catch (Exception ex) {
			WB.addLog("DeliveryTerm.getFieldFromMore():void, ex=" + ex.getMessage(), "", "DeliveryTerm");
		}
	}

	@SuppressWarnings("unused")
	private String getMoreFromField() throws Exception {// TODO
		// origin - 28.08.2025, last edit - 28.08.2025
		String res = "";
		try {
			res = res + MoreVal.setPartMore("TemplateId", this.templateId);
			res = res + MoreVal.setPartMore("TermId", this.termId);
		} catch (Exception ex) {
			WB.addLog("DeliveryTerm.getMoreFromField():String, ex=" + ex.getMessage(), "", "DeliveryTerm");
		}
		return res;
	}

	private void clear() throws Exception {
		// origin - 28.08.2025, last edit - 26.01.2026
		try {
			this.table = "Deal";
			this.src = this.id = this.parent = this.date1 = this.date2 = this.face1 = this.face2 = this.face = this.code = this.description = "";
			this.geo = this.role = this.info = this.more = this.mark = this.defect = "";
			this.fullName = this.comment = this.templateId = this.termId = "";
		} catch (Exception ex) {
			WB.addLog("DeliveryTerm.clear():void, ex=" + ex.getMessage(), "", "DeliveryTerm");
		}
	}

	public static void test() throws Exception {// TODO
		// origin - 28.08.2025, last edit - 08.10.2025
		try {

//			WB.addLog2("DeliveryTerm.test.ctor(String)", "", "PaymentDeliveryTerm");
//			for (var tmp : new String[] { "PawnDoc.Template1.V1.Term1", "PawnDoc.Template1.V1.Term2" }) {
//				WB.addLog2("DeliveryTerm.test.ctor(string)=" + new DeliveryTerm(tmp), "", "DeliveryTerm");
//			}

		} catch (Exception ex) {
			WB.addLog("DeliveryTerm.test():void, ex=" + ex.getMessage(), "", "DeliveryTerm");
		}
	}
}