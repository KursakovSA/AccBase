import java.util.ArrayList;
import java.util.List;

public final class Move {
	// origin - 26.05.2025, last edit - 02.11.2026
	// common fields
	public String table, src, id, parent, face1, face2, face, code, description, geo, role, info, more, mark, defect;
	// special fields
	public ListVal date1, date2, qty, pa;
	// list common + special + timestamp fields in unified val
	public List<DealDto> val;
	public static List<String> roleList;

	static {
		try {
			Move.roleList = List.of("Role.Deal.Move");
		} catch (Exception ex) {
			WB.addLog("Move.static ctor, ex=" + ex.getMessage(), "", "Move");
		}
	}

	private boolean isMoveRole() throws Exception {
		// origin - 26.10.2026, last edit - 31.10.2026
		boolean res = true;
		try {
			if (Etc.strNotContains(this.role, Move.roleList)) {
				res = false;
			}
		} catch (Exception ex) {
			WB.addLog("Move.isMoveRole():boolean, ex=" + ex.getMessage(), "", "Move");
		}
		return res;
	}

	private void addNameToMoreByParent() throws Exception {
		// origin - 03.10.2026, last edit - 02.11.2026
		try {
			BasicDto bDto = new BasicDto("Deal", this.parent); // for parent.more
			for (var curr : NameVar.getListByClass("Move")) {
				var tmp1 = BasicDto.getValName(this.more, curr);
				if (tmp1.isEmpty()) {
					var tmp2 = BasicDto.getValName(bDto.more, curr);
					if (tmp2.isEmpty() == false) {
						this.more = MoreVal.reset(this.more, curr, tmp2);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Move.addNameToMoreByParent():void, ex=" + ex.getMessage(), "", "Move");
		}
	}

	private boolean isPropertyManagement() throws Exception {
		// origin - 08.09.2026, last edit - 12.10.2026
		boolean res = false;
		try {
			var tmp = new DealDto(this.parent);
			if ((Etc.strEquals(tmp.role, "Role.Deal.Frame"))
					&& (Etc.strEquals(tmp.info, "Info.Deal.PropertyManagement"))) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("Move.isPropertyManagement():boolean, ex=" + ex.getMessage(), "", "Move");
		}
		return res;
	}

	private boolean isTemplate() throws Exception {
		// origin - 08.09.2026, last edit - 01.11.2026
		boolean res = false;
		try {
			if ((BasicDto.getValName(this.more, "TemplateId").isEmpty() == false)
					&& (Etc.strEquals(this.mark, "Mark.MD"))) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("Move.isTemplate():boolean, ex=" + ex.getMessage(), "", "Move");
		}
		return res;
	}

	public static List<DealDto> getByParentGeo(String parentId, String geoId) throws Exception { // for Sectoral.PM
		// origin - 05.09.2026, last edit - 01.11.2026
		List<DealDto> res = new ArrayList<DealDto>();
		try {
			if (Etc.strNotValid(parentId, geoId)) {
				return res;
			}
			var moveList = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleGeoFilter(parentId, Move.roleList.getFirst(), geoId), "Deal");
			if (moveList.size() != 0) {
				for (var curr : moveList) {
					var currMove = new Move(curr.id, curr.parent, curr.face1, curr.face2, curr.face, curr.date1,
							curr.date2, curr.code, curr.description, curr.geo, curr.role, curr.info, curr.more,
							curr.mark);
					res.addAll(currMove.val);
				}
			}
		} catch (Exception ex) {
			WB.addLog("Move.getByParentGeo(2String):List<DealDto>, ex=" + ex.getMessage(), "", "Move");
		}
		return res;
	}

	public static List<DealDto> get() throws Exception {
		// origin - 08.06.2025, last edit - 01.11.2026
		List<DealDto> res = new ArrayList<DealDto>();
		try {
			var moveList = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter(Move.roleList.getFirst()), "Deal");
			if (moveList.size() != 0) {
				for (var currMoveList : moveList) {
					var currMove = new Move(currMoveList.id, currMoveList.parent, currMoveList.face1,
							currMoveList.face2, currMoveList.face, currMoveList.date1, currMoveList.date2,
							currMoveList.code, currMoveList.description, currMoveList.geo, currMoveList.role,
							currMoveList.info, currMoveList.more, currMoveList.mark);
					res.addAll(currMove.val);
				}
			}
		} catch (Exception ex) {
			WB.addLog("Move.get():List<DealDto>, ex=" + ex.getMessage(), "", "Move");
		}
		return res;
	}

	public static List<DealDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 08.06.2025, last edit - 01.11.2026
		List<DealDto> res = new ArrayList<DealDto>();
		try {
			if (Etc.strNotValid(parentId, date1)) {
				return res;
			}
			var moveList = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleFilter(parentId, Move.roleList.getFirst()), "Deal");
			for (var currMoveList : moveList) {
				var currMove = new Move(currMoveList.id, currMoveList.parent, currMoveList.face1, currMoveList.face2,
						currMoveList.face, currMoveList.date1, currMoveList.date2, currMoveList.code,
						currMoveList.description, currMoveList.geo, currMoveList.role, currMoveList.info,
						currMoveList.more, currMoveList.mark);
				var selectMoveList = DealDto.getChrono(DateTool.getLocalDate(date1), currMove.val);
				for (var curr : selectMoveList) {
					if (curr.code.isEmpty() == false) {
						res.add(curr);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Move.getCurr(2String):List<DealDto>, ex=" + ex.getMessage(), "", "Move");
		}
		return res;
	}

	public static List<DealDto> getByParentRole(String parentId, String roleId) throws Exception {
		// origin - 08.06.2025, last edit - 31.10.2026
		List<DealDto> res = new ArrayList<DealDto>();
		try {
			if (Etc.strNotValid(parentId)) {
				return res;
			}
			var moveList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, roleId), "Deal");
			for (var currMoveList : moveList) {
				var currMove = new Move(currMoveList.id, currMoveList.parent, currMoveList.face1, currMoveList.face2,
						currMoveList.face, currMoveList.date1, currMoveList.date2, currMoveList.code,
						currMoveList.description, currMoveList.geo, currMoveList.role, currMoveList.info,
						currMoveList.more, currMoveList.mark);
				res.addAll(currMove.val);
			}
		} catch (Exception ex) {
			WB.addLog("Move.getByParentRole(2String):List<DealDto>, ex=" + ex.getMessage(), "", "Move");
		}
		return res;
	}

	public static List<DealDto> getCurr(String date1) throws Exception {
		// origin - 26.05.2025, last edit - 01.11.2026
		List<DealDto> res = new ArrayList<DealDto>();
		try {
			if (Etc.strNotValid(date1)) {
				return res;
			}
			var moveList = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter(Move.roleList.getFirst()), "Deal");
			for (var currMoveList : moveList) {
				var currMove = new Move(currMoveList.id, currMoveList.parent, currMoveList.face1, currMoveList.face2,
						currMoveList.face, currMoveList.date1, currMoveList.date2, currMoveList.code,
						currMoveList.description, currMoveList.geo, currMoveList.role, currMoveList.info,
						currMoveList.more, currMoveList.mark);
				var selectMoveList = DealDto.getChrono(DateTool.getLocalDate(date1), currMove.val);
				for (var curr : selectMoveList) {
					if (curr.code.isEmpty() == false) {
						res.add(curr);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Move.getCurr(String):List<DealDto>, ex=" + ex.getMessage(), "", "Move");
		}
		return res;
	}

	public static List<DealDto> getById(String id) throws Exception { // get exist move as list dealdto
		// origin - 31.10.2026, last edit - 01.11.2026
		List<DealDto> res = new ArrayList<DealDto>();
		try {
			if (Etc.strNotValid(id)) {
				return res;
			}
			var moveList = DAL.getByTemplate(WB.lastConnWork, Qry.getIdRoleFilter(id, Move.roleList.getFirst()),
					"Deal");
			for (var currMoveList : moveList) {
				var currMove = new Move(currMoveList.id, currMoveList.parent, currMoveList.face1, currMoveList.face2,
						currMoveList.face, currMoveList.date1, currMoveList.date2, currMoveList.code,
						currMoveList.description, currMoveList.geo, currMoveList.role, currMoveList.info,
						currMoveList.more, currMoveList.mark);
				res.addAll(currMove.val);
			}
		} catch (Exception ex) {
			WB.addLog("Move.getById(String):List<DealDto>, ex=" + ex.getMessage(), "", "Move");
		}
		return res;
	}

	private void validate() throws Exception {
		// origin - 18.11.2025, last edit - 10.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}

			this.defect = Fmtr.addIfStrEmpty(this.defect, MoreVal.getFieldByKey(this.more, "TemplateId"),
					"empty templateId; ");
		} catch (Exception ex) {
			WB.addLog("Move.validate():void, ex=" + ex.getMessage(), "", "Move");
		}
	}

	private void getVal() throws Exception {
		// origin - 07.06.2025, last edit - 02.11.2026
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currQty = "";
			String currPA = "";
			String currMore = this.more;
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currQty = this.qty.getByIndex(i);
				currPA = this.pa.getByIndex(i);
				currMore = MoreVal.resetPart(currMore, MoreVal.setPart("Qty", currQty));
				currMore = MoreVal.resetPart(currMore, MoreVal.setPart("PA", currPA));
				var tmp = new DealDto(this.id, this.parent, this.face1, this.face2, this.face, currDate1, currDate2,
						this.code, this.description, this.geo, this.role, this.info, currMore, this.mark);
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("Move.getVal():void, ex=" + ex.getMessage(), "", "Move");
		}
	}

	private void fix() throws Exception {
		// origin - 02.06.2025, last edit - 10.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}

			if (this.code.isEmpty() == false) {
				if (this.description.isEmpty()) {
					this.description = this.code;
				}
			}

			if (this.description.isEmpty() == false) {
				if (this.code.isEmpty()) {
					this.code = this.description;
				}
			}

			this.mark = DefVal.set(this.mark, "Mark.DD");
		} catch (Exception ex) {
			WB.addLog("Move.fix():void, ex=" + ex.getMessage(), "", "Move");
		}
	}

	private void isExist() throws Exception {
		// origin - 26.05.2025, last edit - 31.10.2026
		try {
			List<FullDto> listDto = new ArrayList<FullDto>();
			listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), "Deal");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.id = DefVal.setCustom(this.id, dto.id);
				var tmp = new SpanDate(dto.date1, dto.date2);
				this.date1 = new ListVal(tmp.date1);
				this.date2 = new ListVal(tmp.date2);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.parent = DefVal.setCustom(this.parent, dto.parent);
				this.face1 = DefVal.setCustom(this.face1, dto.face1);
				this.face2 = DefVal.setCustom(this.face2, dto.face2);
				this.face = DefVal.setCustom(this.face, dto.face);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.geo = DefVal.setCustom(this.geo, dto.geo);
				this.role = DefVal.setCustom(this.role, dto.role);
				this.info = DefVal.setCustom(this.info, dto.info);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.getFieldFromMore();
			}

			if (this.isMoveRole() == false) {
				this.clear();
			}

			if (listDto.size() == 0) {
				this.clear();
			}
		} catch (Exception ex) {
			WB.addLog("Move.isExist():void, ex=" + ex.getMessage(), "", "Move");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 26.05.2025, last edit - 02.11.2026
		try {
			this.addNameToMoreByParent();
			this.qty = new ListVal(MoreVal.getFieldByKey(this.more, "Qty"), "");
			this.qty = ListVal.ext(this.qty, this.date1.val.size());
			this.pa = new ListVal(MoreVal.getFieldByKey(this.more, "PA"), "");
			this.pa = ListVal.ext(this.pa, this.date1.val.size());
		} catch (Exception ex) {
			WB.addLog("Move.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Move");
		}
	}

	private void getByTemplate() throws Exception { // TODO
		// origin - 09.09.2026, last edit - 01.11.2026
		try {
			this.id = new IdGen("", "").id;
			this.date1 = new ListVal(DateTool.getNow().toString(), "");
			// this.more = this.getMoreFromField();
			this.mark = "Mark.DD";

			if ((this.isPropertyManagement()) && (this.parent.isEmpty() == false)) {
				List<FullDto> listDto = new ArrayList<FullDto>();
				listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.parent), "Deal");
				if (listDto.size() != 0) {
					var dto = listDto.getFirst();
					this.face1 = dto.face1;
					this.face2 = dto.face2;
					this.geo = dto.geo;
					this.id = this.geo + ", " + BasicDto.getValName(dto.more, "Context");// context="кв.52"
				}
			}
		} catch (Exception ex) {
			WB.addLog2("Move.getByTemplate():void, ex=" + ex.getMessage(), "", "Move");
		}
	}

	// get new move by DealDto.id,... less isExist
	public Move(String Id, String Parent, String Face1, String Face2, String Face, String Date1, String Date2,
			String Code, String Description, String Geo, String Role, String Info, String More, String Mark)
			throws Exception {
		// origin - 08.06.2025, last edit - 03.09.2026
		this.clear();
		this.src = this.id = Id;
		this.parent = Parent;
		this.face1 = Face1;
		this.face2 = Face2;
		this.face = Face;
		this.date1 = new ListVal(Date1, "");
		this.date2 = new ListVal(Date2, "");
		this.code = Code;
		this.description = Description;
		this.geo = Geo;
		this.role = Role;
		this.info = Info;
		this.more = More;
		this.getFieldFromMore();
		this.mark = Mark;
		this.getVal();
		this.fix();
		this.validate();
	}

	public Move(String TemplateMoveId, String ParentDealId) throws Exception { // get new move by template or exist move
		// origin - 26.05.2025, last edit - 01.11.2026
		this.clear();
		this.src = TemplateMoveId + ", " + ParentDealId;
		this.id = TemplateMoveId;
		this.isExist();
		this.getVal();

		if (this.isTemplate()) { // get new move by template
			this.getByTemplate();
			this.parent = ParentDealId;
			this.fix();
			this.validate();
		}
	}

	public Move(String Id) throws Exception { // get exist move
		// origin - 26.05.2025, last edit - 01.11.2026
		this.clear();
		this.src = this.id = Id;
		this.isExist();
		if (this.id.isEmpty() == false) {
			this.getVal();
			this.fix();
			this.validate();
		}
	}

	public Move() throws Exception {
		// origin - 26.05.2025, last edit - 26.05.2025
		this.clear();
	}

	public String toString() {
		// origin - 26.05.2025, last edit - 03.10.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addAnyway(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", val ", this.val.size());
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	private void clear() throws Exception {
		// origin - 26.05.2025, last edit - 02.11.2026
		try {
			this.table = "Deal";
			this.src = this.id = this.parent = this.face1 = this.face2 = this.face = this.code = this.description = "";
			this.geo = this.role = this.info = this.more = this.mark = this.defect = "";
			this.date1 = this.date2 = this.qty = this.pa = new ListVal();
			this.val = new ArrayList<DealDto>();
		} catch (Exception ex) {
			WB.addLog("Move.clear():void, ex=" + ex.getMessage(), "", "Move");
		}
	}

	public static void test() throws Exception {
		// origin - 26.05.2025, last edit - 01.11.2026
		try {

//			WB.addLog2("Move.test.getById(String):List<DealDto>", "", "Move");
//			for (var tmp1 : new String[] { "лс 000000", "лс 000000, усл 100", "лс 111111", "лс 111111, усл 100" }) {
//				var tmp2 = Move.getById(tmp1);
//				WB.addLog2("Move.test.getById(String):List<DealDto>, res=" + tmp2 + ",tmp1=" + tmp1, "", "Move");
//				WB.log(tmp2, "Move");
//			}

//			WB.addLog2("Move.test.addNameToMore():void", "", "Move");
//			for (var tmp1 : new String[] { "лс 000000", "лс 000000, усл 100", "лс 111111", "лс 111111, усл 100" }) {
//				var tmp2 = new Move(tmp1);
//				tmp2.addNameToMore();
//				WB.addLog2("Move.test.addNameToMore():void, res.more=" + tmp2.more + ",tmp1=" + tmp1, "", "Move");
//			}

//			WB.addLog2("Move.test.getByParentGeo(2String):List<DealDto>", "", "Move");
//			for (var tmp1 : new String[] { "", "Deal.Test1", "лс 000000", "лс 111111", "Deal.Tralala" }) {
//				for (var tmp2 : new String[] { "", "Geo.Somewhere", "Geo.SaryArka.Майлина,789", "Geo.Tralala" }) {
//					var tmp3 = Move.getByParentGeo(tmp1, tmp2);
//					WB.addLog2("Move.test.getByParentGeo(2String):List<DealDto>, res.size=" + tmp3.size() + ", tmp1="
//							+ tmp1 + ", tmp2=" + tmp2, "", "Move");
//					WB.log(tmp3, "Move");
//				}
//			}

//			{
//				WB.addLog2("Move.test.get():List<DealDto>", "", "Move");
//				var tmp1 = Move.get();
//				WB.addLog2("Move.test.get():List<DealDto>, res.size=" + tmp1.size(), "", "Move");
//				WB.log(tmp1, "Move");
//			}

//			WB.addLog2("Move.test.getByParentRole(String):List<DealDto>", "", "Move");
//			for (var tmp1 : new String[] { "", "Deal.Test1", "Deal.Tralala" }) {
//				var tmp2 = Move.getByParentRole(tmp1, Move.roleList.getFirst());
//				WB.addLog2(
//						"Move.test.getByParentRole(String):List<DealDto>, res.size=" + tmp2.size() + ", tmp1=" + tmp1,
//						"", "Move");
//				WB.log(tmp2, "Move");
//			}

//			WB.addLog2("Move.test.getCurr(2String):List<DealDto>", "", "Move");
//			for (var tmp1 : new String[] { "1812-01-01", "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31",
//					"2025-02-01", "2025-02-28", "2025-08-15", "2100-01-01" }) {
//				for (var tmp2 : new String[] { "Deal.Test1" }) {
//					var tmp3 = Move.getCurr(tmp1, tmp2);
//					WB.addLog2("Move.test.getCurr(2String):List<DealDto>, res.size=" + tmp3.size() + ", tmp1=" + tmp1
//							+ ", correct tmp1=" + DateTool.getLocalDate(tmp1) + ", tmp2=" + tmp2, "", "Move");
//					WB.log(tmp3, "Move");
//				}
//			}

//			WB.addLog2("Move.test.getCurr(String):List<DealDto>", "", "Move");
//			for (var tmp1 : new String[] { "1812-01-01", "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31",
//					"2025-02-01", "2025-02-28", "2025-08-15", "2100-01-01" }) {
//				var tmp = Move.getCurr(tmp1);
//				WB.addLog2("Move.test.getCurr(String):List<DealDto>, res.size=" + tmp.size() + ", tmp1=" + tmp1
//						+ ", correct tmp1=" + DateTool.getLocalDate(tmp1), "", "Move");
//				WB.log(tmp, "Move");
//			}

//			WB.addLog2("Move.test.ctor(2String)", "", "Move");
//			for (var tmp1 : new String[] { "Deal.Move.Test1", "Deal.Move.Test2", "Deal.Move.Tralala", "лс 000000",
//					"лс 000000, усл 100", "лс 111111", "лс 111111, усл 100", "лс 9999999999" }) {
//				var tmp2 = new Move(tmp1, "лс 257564");
//				WB.addLog2("Move.test.ctor(2String), res=" + tmp2 + ", tmp1=" + tmp1, "", "Move");
//				WB.log(tmp2.val, "Move");
//			}

//			WB.addLog2("Move.test.ctor(String)", "", "Move");
//			for (var tmp1 : new String[] { "Deal.Move.Test1", "Deal.Move.Test2", "Deal.Move.Tralala", "лс 111111",
//					"лс 111111, усл 100", "лс 9999999999" }) {
//				var tmp2 = new Move(tmp1);
//				WB.addLog2("Move.test.ctor(String), res=" + tmp2 + ", tmp1=" + tmp1, "", "Move");
//				WB.log(tmp2.val, "Move");
//			}

		} catch (Exception ex) {
			WB.addLog("Move.test():void, ex=" + ex.getMessage(), "", "Move");
		}
	}
}