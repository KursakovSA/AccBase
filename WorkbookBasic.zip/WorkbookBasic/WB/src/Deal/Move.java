import java.util.ArrayList;
import java.util.List;

public final class Move {
	// origin - 26.05.2025, last edit - 18.09.2026
	// common fields
	public String table, src, id, parent, face1, face2, face, code, description, geo, role, info, more, mark, defect;
	// special fields
	public String fullName, comment;
	public ListVal date1, date2, qty, pa;
	// list common + special + timestamp fields in unified val
	public List<DealDto> val;
	public static List<String> nameList;

	static {
		try {
			Move.nameList = List.of("TemplateId", "TermId", "AssetCatId");
		} catch (Exception ex) {
			WB.addLog("Move.static ctor, ex=" + ex.getMessage(), "", "Move");
		}
	}

	public boolean isPropertyManagement() throws Exception {
		// origin - 08.09.2026, last edit - 09.09.2026
		boolean res = false;
		try {
			var tmp = new Deal(this.parent);
			if (tmp.isPropertyManagement()) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("Move.isPropertyManagement():boolean, ex=" + ex.getMessage(), "", "Move");
		}
		return res;
	}

	public boolean isTemplate() throws Exception {
		// origin - 08.09.2026, last edit - 16.09.2026
		boolean res = false;
		try {
			if ((MoreVal.getFieldByKey(this.more, "TemplateId").isEmpty() == false)
					&& (Etc.strEquals(this.mark, "Mark.MD"))) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("Move.isTemplate():boolean, ex=" + ex.getMessage(), "", "Move");
		}
		return res;
	}

	public static String getCode(Move move) throws Exception {// TODO
		// origin - 10.06.2025, last edit - 13.06.2025
		String res = move.code;
		try {
			// если договор инфо = проперти менеджемент то для кск оси
//			if () {
			// get IIN For Customer
			// get DealId for parent deal, dealId = personal account
//				get ServiceCode for AssetCatId
//			}
		} catch (Exception ex) {
			WB.addLog("Move.getCode(Move):String, ex=" + ex.getMessage(), "", "Move");
		}
		return res;
	}

	public static FullDto set(Move move) throws Exception {
		// origin - 09.06.2025, last edit - 13.06.2025
		FullDto res = new FullDto();
		try {
			res.id = move.id;
			res.parent = move.parent;
			res.date1 = move.date1.src;
			res.date2 = move.date2.src;
			res.face1 = move.face1;
			res.face2 = move.face2;
			res.face = move.face;
			res.code = move.code;
			res.description = move.description;
			res.geo = move.geo;
			res.role = move.role;
			res.info = move.info;
			res.mark = move.mark;
			res.more = move.getMoreFromField();
		} catch (Exception ex) {
			WB.addLog("Move.set(Move):FullDto, ex=" + ex.getMessage(), "", "Move");
		}
		return res;
	}

	public static List<DealDto> getByParentRoleGeo(String parentId, String geoId) throws Exception {
		// origin - 05.09.2026, last edit - 07.09.2026
		List<DealDto> res = new ArrayList<DealDto>();
		try {
			var moveList = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleGeoFilter(parentId, "Role.Deal.Move", geoId), "Deal");
			if (moveList.size() != 0) {
				for (var curr : moveList) {
					var currMove = new Move(curr.id, curr.parent, curr.face1, curr.face2, curr.face, curr.date1,
							curr.date2, curr.code, curr.description, curr.geo, curr.role, curr.info, curr.more,
							curr.mark);
					for (var currVal : currMove.val) {
						if (currVal.code.isEmpty() == false) {
							res.add(currVal);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Move.getByParentRoleGeo(2String):List<DealDto>, ex=" + ex.getMessage(), "", "Move");
		}
		return res;
	}

	public static List<DealDto> getByParentRole(String parentId) throws Exception {
		// origin - 08.06.2025, last edit - 05.09.2026
		List<DealDto> res = new ArrayList<DealDto>();
		try {
			var moveList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, "Role.Deal.Move"),
					"Deal");
			if (moveList.size() != 0) {
				for (var currMoveList : moveList) {
					var currMove = new Move(currMoveList.id, currMoveList.parent, currMoveList.face1,
							currMoveList.face2, currMoveList.face, currMoveList.date1, currMoveList.date2,
							currMoveList.code, currMoveList.description, currMoveList.geo, currMoveList.role,
							currMoveList.info, currMoveList.more, currMoveList.mark);
					for (var curr : currMove.val) {
						if (curr.code.isEmpty() == false) {
							res.add(curr);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Move.getByParentRole(String):List<DealDto>, ex=" + ex.getMessage(), "", "Move");
		}
		return res;
	}

	public static List<DealDto> get() throws Exception { // full list move filterless
		// origin - 08.06.2025, last edit - 15.09.2025
		List<DealDto> res = new ArrayList<DealDto>();
		try {
			var moveList = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter("Role.Deal.Move"), "Deal");
			if (moveList.size() != 0) {
				for (var currMoveList : moveList) {
					var currMove = new Move(currMoveList.id, currMoveList.parent, currMoveList.face1,
							currMoveList.face2, currMoveList.face, currMoveList.date1, currMoveList.date2,
							currMoveList.code, currMoveList.description, currMoveList.geo, currMoveList.role,
							currMoveList.info, currMoveList.more, currMoveList.mark);
					for (var curr : currMove.val) {
						if (curr.code.isEmpty() == false) {
							res.add(curr);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Move.get():List<DealDto>, ex=" + ex.getMessage(), "", "Move");
		}
		return res;
	}

	public static List<DealDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 08.06.2025, last edit - 15.09.2025
		List<DealDto> res = new ArrayList<DealDto>();
		try {
			var moveList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, "Role.Deal.Move"),
					"Deal");
			if (moveList.size() != 0) {
				for (var currMoveList : moveList) {
					var currMove = new Move(currMoveList.id, currMoveList.parent, currMoveList.face1,
							currMoveList.face2, currMoveList.face, currMoveList.date1, currMoveList.date2,
							currMoveList.code, currMoveList.description, currMoveList.geo, currMoveList.role,
							currMoveList.info, currMoveList.more, currMoveList.mark);
					var selectMoveList = DealDto.getChrono(DateTool.getLocalDate(date1), currMove.val);
					for (var curr : selectMoveList) {
						if (curr.code.isEmpty() == false) {
							res.add(curr);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Move.getCurr(2String):List<DealDto>, ex=" + ex.getMessage(), "", "Move");
		}
		return res;
	}

	public static List<DealDto> getCurr(String date1) throws Exception {
		// origin - 26.05.2025, last edit - 15.09.2025
		List<DealDto> res = new ArrayList<DealDto>();
		try {
			var moveList = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter("Role.Deal.Move"), "Deal");
			if (moveList.size() != 0) {
				for (var currMoveList : moveList) {
					var currMove = new Move(currMoveList.id, currMoveList.parent, currMoveList.face1,
							currMoveList.face2, currMoveList.face, currMoveList.date1, currMoveList.date2,
							currMoveList.code, currMoveList.description, currMoveList.geo, currMoveList.role,
							currMoveList.info, currMoveList.more, currMoveList.mark);
					var selectMoveList = DealDto.getChrono(DateTool.getLocalDate(date1), currMove.val);
					for (var curr : selectMoveList) {
						if (curr.code.isEmpty() == false) {
							res.add(curr);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Move.getCurr(String):List<DealDto>, ex=" + ex.getMessage(), "", "Move");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 18.11.2025, last edit - 16.09.2026
		try {
			this.defect = Fmtr.addIfStrEmpty(this.defect, MoreVal.getFieldByKey(this.more, "TemplateId"),
					"empty templateId; ");
		} catch (Exception ex) {
			WB.addLog("Move.validate():void, ex=" + ex.getMessage(), "", "Move");
		}
	}

	private void getVal() throws Exception {
		// origin - 07.06.2025, last edit - 12.09.2026
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currQty = "";
			String currPA = "";
			String currMore = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currQty = this.qty.getByIndex(i);
				currPA = this.pa.getByIndex(i);
				currMore = "";
				currMore = currMore + MoreVal.setPart("Qty", currQty);
				currMore = currMore + MoreVal.setPart("PA", currPA);
				currMore = currMore + MoreVal.setPart("FullName", this.fullName);
				currMore = currMore + MoreVal.setPart("Comment", this.comment);
				var tmp = new DealDto(this.id, this.parent, this.face1, this.face2, this.face, currDate1, currDate2,
						this.code, this.description, this.geo, this.role, this.info, currMore, this.mark);
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("Move.getVal():void, ex=" + ex.getMessage(), "", "Move");
		}
	}

	private void fix() throws Exception {
		// origin - 02.06.2025, last edit - 07.09.2026
		try {
			if (this.code.isEmpty() == false) {
				if (this.description.isEmpty()) {
					this.description = this.code;
				}
			}

			if (this.description.isEmpty() == false) {
				if (this.code.isEmpty()) {
					this.code = this.description;
				}
			}

			this.mark = DefVal.set(this.mark, "Mark.DD");
		} catch (Exception ex) {
			WB.addLog("Move.correct():void, ex=" + ex.getMessage(), "", "Move");
		}
	}

	private String getMoreFromField() throws Exception {
		// origin - 26.05.2025, last edit - 16.09.2026
		String res = "";
		try {
			this.qty = ListVal.reduce(this.qty);
			res = res + MoreVal.setPart("Qty", this.qty.src);

			this.pa = ListVal.reduce(this.pa);
			res = res + MoreVal.setPart("PA", this.pa.src);
			// TODO - split pa on price and amount and after reduce separate price and
			// amount ???
		} catch (Exception ex) {
			WB.addLog("Move.getMoreFromField():void, ex=" + ex.getMessage(), "", "Move");
		}
		return res;
	}

	private void isExist() throws Exception {
		// origin - 26.05.2025, last edit - 09.09.2026
		try {
			List<FullDto> listDto = new ArrayList<FullDto>();
			listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), "Deal");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.id = DefVal.setCustom(this.id, dto.id);
				var tmp = new SpanDate(dto.date1, dto.date2);
				this.date1 = new ListVal(tmp.date1);
				this.date2 = new ListVal(tmp.date2);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.parent = DefVal.setCustom(this.parent, dto.parent);
				this.face1 = DefVal.setCustom(this.face1, dto.face1);
				this.face2 = DefVal.setCustom(this.face2, dto.face2);
				this.face = DefVal.setCustom(this.face, dto.face);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.geo = DefVal.setCustom(this.geo, dto.geo);
				this.role = DefVal.setCustom(this.role, dto.role);
				this.info = DefVal.setCustom(this.info, dto.info);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.clear();
			}
		} catch (Exception ex) {
			WB.addLog("Move.isExist():void, ex=" + ex.getMessage(), "", "Move");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 26.05.2025, last edit - 13.06.2025
		try {
			this.qty = new ListVal(MoreVal.getFieldByKey(this.more, "Qty"), "");
			this.qty = ListVal.ext(this.qty, this.date1.val.size());
			this.pa = new ListVal(MoreVal.getFieldByKey(this.more, "PA"), "");
			this.pa = ListVal.ext(this.pa, this.date1.val.size());
		} catch (Exception ex) {
			WB.addLog("Move.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Move");
		}
	}

	private void getByTemplate() throws Exception { // TODO
		// origin - 09.09.2026, last edit - 09.09.2026
		try {
			this.id = new IdGen("", "").id;
			this.date1 = new ListVal(DateTool.getNow().toString(), "");
			this.more = this.getMoreFromField();
			this.mark = "Mark.DD";

			if ((this.isPropertyManagement()) && (this.parent.isEmpty() == false)) {
				List<FullDto> listDto = new ArrayList<FullDto>();
				listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.parent), "Deal");
				if (listDto.size() != 0) {
					var dto = listDto.getFirst();
					this.face1 = dto.face1;
					this.face2 = dto.face2;
					this.geo = dto.geo;
					this.id = this.geo + ", " + MoreVal.getFieldByKey(dto.more, "Context");// context="кв.52"
				}
			}
		} catch (Exception ex) {
			WB.addLog2("Move.getByTemplate():void, ex=" + ex.getMessage(), "", "Move");
		}
	}

	// get new move by DealDto.id,... without isExist
	public Move(String Id, String Parent, String Face1, String Face2, String Face, String Date1, String Date2,
			String Code, String Description, String Geo, String Role, String Info, String More, String Mark)
			throws Exception {
		// origin - 08.06.2025, last edit - 03.09.2026
		this.clear();
		this.src = this.id = Id;
		this.parent = Parent;
		this.face1 = Face1;
		this.face2 = Face2;
		this.face = Face;
		this.date1 = new ListVal(Date1, "");
		this.date2 = new ListVal(Date2, "");
		this.code = Code;
		this.description = Description;
		this.geo = Geo;
		this.role = Role;
		this.info = Info;
		this.more = More;
		this.getFieldFromMore();
		this.mark = Mark;
		this.getVal();
		this.fix();
		this.validate();
	}

	// get new Move by template
	public Move(String TemplateId, String ParentId) throws Exception {
		// origin - 26.05.2025, last edit - 09.09.2026
		this.clear();
		this.src = TemplateId + ", " + ParentId;
		this.id = TemplateId;
		this.isExist();
		if (this.isTemplate()) {
			this.getByTemplate();
		}
		this.fix();
		this.validate();
	}

	public Move(String Id) throws Exception {
		// origin - 26.05.2025, last edit - 09.09.2026
		this.clear();
		this.src = this.id = Id;
		this.isExist();
		this.getVal();
		this.fix();
		this.validate();
	}

	public Move() throws Exception {
		// origin - 26.05.2025, last edit - 26.05.2025
		this.clear();
	}

	public String toString() {
		// origin - 26.05.2025, last edit - 16.09.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addAnyway(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", qty ", this.qty.id);
			res = res + Fmtr.addIfNotEmpty(", pa ", this.pa.id);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", val ", this.val.size());
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	private void clear() throws Exception {
		// origin - 26.05.2025, last edit - 16.09.2026
		try {
			this.table = "Deal";
			this.src = this.id = this.parent = this.face1 = this.face2 = this.face = this.code = this.description = "";
			this.geo = this.role = this.info = this.more = this.mark = this.defect = "";
			this.comment = this.fullName = "";
			this.date1 = this.date2 = this.qty = this.pa = new ListVal();
			this.val = new ArrayList<DealDto>();
		} catch (Exception ex) {
			WB.addLog("Move.clear():void, ex=" + ex.getMessage(), "", "Move");
		}
	}

	public static void test() throws Exception {
		// origin - 26.05.2025, last edit - 08.09.2026
		try {

//			WB.addLog2("Move.test.getByParentRoleGeo(2String):List<DealDto>", "", "Move");
//			for (var tmp1 : new String[] { "", "Deal.PropertyManagement.Template1.Address1",
//					"ОСИ, ул.Майлина, д.789, кв.52", "Deal.Tralala" }) {
//				for (var tmp2 : new String[] { "", "Geo.Somewhere", "Geo.SaryArka.Майлина,789", "Geo.Tralala" }) {
//					var tmp3 = Move.getByParentRoleGeo(tmp1, tmp2);
//					WB.addLog2("Move.test.getByParentRoleGeo(2String):List<DealDto>, res.size=" + tmp3.size()
//							+ ", tmp1=" + tmp1 + ", tmp2=" + tmp2, "", "Move");
//					WB.log(tmp3, "Move");
//				}
//			}

//			{
//				WB.addLog2("Move.test.set(Move):FullDto", "", "Move");
//				var tmp1 = new Move("Deal.Move.Test1", "TestCode", "TestDescription");
//				var tmp2 = Move.set(tmp1);
//				WB.addLog2("Move.test.set(Move):FullDto, res=" + tmp2 + ", more=" + tmp2.more, "", "Move");
//				WB.log(tmp1.val, "Move");
//			}

			{
				WB.addLog2("Move.test.get():List<DealDto>", "", "Move");
				var tmp1 = Move.get();
				WB.addLog2("Move.test.get():List<DealDto>, res.size=" + tmp1.size() + ", filterless", "", "Move");
				WB.log(tmp1, "Move");
			}

//			WB.addLog2("Move.test.getByParentRole(String):List<DealDto>", "", "Move");
//			for (var tmp1 : new String[] { "", "Deal.Test1", "Deal.Tralala" }) {
//				var tmp2 = Move.getByParentRole(tmp1);
//				WB.addLog2(
//						"Move.test.getByParentRole(String):List<DealDto>, res.size=" + tmp2.size() + ", parentId=" + tmp1,
//						"", "Move");
//				WB.log(tmp2, "Move");
//			}

//			WB.addLog2("Move.test.getCurr(2String):List<DealDto>", "", "Move");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Deal.Test1" }) {
//					var tmp3 = Move.getCurr(tmp1, tmp2);
//					WB.addLog2("Move.test.getCurr(2String):List<DealDto>, res.size=" + tmp3.size() + ", date1=" + tmp1
//							+ ", parentId=" + tmp2, "", "Move");
//					WB.log(tmp3, "Move");
//				}
//			}

//			WB.addLog2("Move.test.getCurr(String):List<DealDto>", "", "Move");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-08-15" }) {
//				var tmp = Move.getCurr(tmp1);
//				WB.addLog2("Move.test.getCurr(String):List<DealDto>, res.size=" + tmp.size() + ", date1=" + tmp1, "",
//						"Move");
//				WB.log(tmp, "Move");
//			}

//			WB.addLog2("Move.test.ctor(3String)", "", "Move");
//			for (var tmp1 : new String[] { "Deal.Move.Template", "Deal.Move.Tralala" }) {
//				var tmp2 = new NVal("TestCode , TestDescription");
//				var tmp3 = new Move(tmp1, tmp2.getVal(1), tmp2.getVal(2));
//				WB.addLog2("Move.test.ctor(3String)=" + tmp3 + ", tmp1=" + tmp1 + ", tmp2=" + tmp2.getVal(1) + ", tmp3="
//						+ tmp2.getVal(2), "", "Move");
//				WB.log(tmp3.val, "Move");
//			}

//			WB.addLog2("Move.test.ctor(2String)", "", "Move");
//			for (var tmp1 : new String[] { "Deal.Test1 , Deal.Move.Test1", "Deal.Tralala , Deal.Move.Tralala" }) {
//				var tmp2 = new NVal(tmp1);
//				var tmp3 = new Move(tmp2.getVal(1), tmp2.getVal(2));
//				WB.addLog2("Move.test.ctor(2String)=" + tmp3, "", "Move");
//				WB.log(tmp3.val, "Move");
//			}

//			WB.addLog2("Move.test.ctor(String)", "", "Move");
//			for (var tmp1 : new String[] { "Deal.Move.Test1", "Deal.Move.Test2", "Deal.Move.Tralala" }) {
//				var tmp2 = new Move(tmp1);
//				WB.addLog2("Move.test.ctor(String)=" + tmp2, "", "Move");
//				WB.log(tmp2.val, "Move");
//			}

		} catch (Exception ex) {
			WB.addLog("Move.test():void, ex=" + ex.getMessage(), "", "Move");
		}
	}
}