import java.util.ArrayList;
import java.util.List;

public final class Move {
	// origin - 26.05.2025, last edit - 18.11.2025
	// common fields
	public String table, src, id, parent, face1, face2, face, code, description, geo, role, info, more, mark, defect;
	// special fields
	public String fullName, comment, templateId, termId, assetCatId;
	public ListVal date1, date2, qty, pa;
	// list common + special + timestamp fields in unified val
	public List<DealDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Move.static ctor, ex=" + ex.getMessage(), "", "Move");
		}
	}

	public static String getCode(Move move) throws Exception {// TODO
		// origin - 10.06.2025, last edit - 13.06.2025
		String res = move.code;
		try {
			// если договор инфо = проперти менеджемент то для кск оси
//			if () {
			// get IIN For Customer
			// get DealId for parent deal, dealId = personal account
//				get ServiceCode for AssetCatId
//			}
		} catch (Exception ex) {
			WB.addLog("Move.getCode(Move):String, ex=" + ex.getMessage(), "", "Move");
		}
		return res;
	}

	public static ModelDto set(Move move) throws Exception {
		// origin - 09.06.2025, last edit - 13.06.2025
		ModelDto res = new ModelDto();
		try {
			res.id = move.id;
			res.parent = move.parent;
			res.date1 = move.date1.src;
			res.date2 = move.date2.src;
			res.face1 = move.face1;
			res.face2 = move.face2;
			res.face = move.face;
			res.code = move.code;
			res.description = move.description;
			res.geo = move.geo;
			res.role = move.role;
			res.info = move.info;
			res.mark = move.mark;
			res.more = move.getMoreFromField();
		} catch (Exception ex) {
			WB.addLog("Move.set(Move):ModelDto, ex=" + ex.getMessage(), "", "Move");
		}
		return res;
	}

	public static List<DealDto> getByParent(String parentId) throws Exception {
		// origin - 08.06.2025, last edit - 15.09.2025
		List<DealDto> res = new ArrayList<DealDto>();
		try {
			var moveList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, "Role.Deal.Move"),
					"Deal");
			if (moveList.size() != 0) {
				for (var currMoveList : moveList) {
					var currMove = new Move(currMoveList.id, currMoveList.parent, currMoveList.face1,
							currMoveList.face2, currMoveList.face, currMoveList.date1, currMoveList.date2,
							currMoveList.code, currMoveList.description, currMoveList.geo, currMoveList.role,
							currMoveList.info, currMoveList.more, currMoveList.mark);
					for (var curr : currMove.val) {
						if (curr.code.isEmpty() == false) {
							res.add(curr);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Move.getByParent(String):List<DealDto>, ex=" + ex.getMessage(), "", "Move");
		}
		return res;
	}

	public static List<DealDto> get() throws Exception { // full list move filterless
		// origin - 08.06.2025, last edit - 15.09.2025
		List<DealDto> res = new ArrayList<DealDto>();
		try {
			var moveList = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter("Role.Deal.Move"), "Deal");
			if (moveList.size() != 0) {
				for (var currMoveList : moveList) {
					var currMove = new Move(currMoveList.id, currMoveList.parent, currMoveList.face1,
							currMoveList.face2, currMoveList.face, currMoveList.date1, currMoveList.date2,
							currMoveList.code, currMoveList.description, currMoveList.geo, currMoveList.role,
							currMoveList.info, currMoveList.more, currMoveList.mark);
					for (var curr : currMove.val) {
						if (curr.code.isEmpty() == false) {
							res.add(curr);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Move.get():List<DealDto>, ex=" + ex.getMessage(), "", "Move");
		}
		return res;
	}

	public static List<DealDto> getCurr(String date1, String parentId) throws Exception {
		// origin - 08.06.2025, last edit - 15.09.2025
		List<DealDto> res = new ArrayList<DealDto>();
		try {
			var moveList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, "Role.Deal.Move"),
					"Deal");
			if (moveList.size() != 0) {
				for (var currMoveList : moveList) {
					var currMove = new Move(currMoveList.id, currMoveList.parent, currMoveList.face1,
							currMoveList.face2, currMoveList.face, currMoveList.date1, currMoveList.date2,
							currMoveList.code, currMoveList.description, currMoveList.geo, currMoveList.role,
							currMoveList.info, currMoveList.more, currMoveList.mark);
					var selectMoveList = DealDto.getChrono(DateTool.getLocalDate(date1), currMove.val);
					for (var curr : selectMoveList) {
						if (curr.code.isEmpty() == false) {
							res.add(curr);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Move.getCurr(2String):List<DealDto>, ex=" + ex.getMessage(), "", "Move");
		}
		return res;
	}

	public static List<DealDto> getCurr(String date1) throws Exception {
		// origin - 26.05.2025, last edit - 15.09.2025
		List<DealDto> res = new ArrayList<DealDto>();
		try {
			var moveList = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter("Role.Deal.Move"), "Deal");
			if (moveList.size() != 0) {
				for (var currMoveList : moveList) {
					var currMove = new Move(currMoveList.id, currMoveList.parent, currMoveList.face1,
							currMoveList.face2, currMoveList.face, currMoveList.date1, currMoveList.date2,
							currMoveList.code, currMoveList.description, currMoveList.geo, currMoveList.role,
							currMoveList.info, currMoveList.more, currMoveList.mark);
					var selectMoveList = DealDto.getChrono(DateTool.getLocalDate(date1), currMove.val);
					for (var curr : selectMoveList) {
						if (curr.code.isEmpty() == false) {
							res.add(curr);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Move.getCurr(String):List<DealDto>, ex=" + ex.getMessage(), "", "Move");
		}
		return res;
	}
	
	private void validate() throws Exception { //TODO
		// origin - 18.11.2025, last edit - 18.11.2025
		try {
			if (this.templateId.isEmpty()) {
				this.defect = this.defect + "empty templateId; ";
			}
			if (this.termId.isEmpty()) {
				this.defect = this.defect + "empty termId; ";
			}	
		} catch (Exception ex) {
			WB.addLog("Move.validate():void, ex=" + ex.getMessage(), "", "Move");
		}
	}

	private void getVal() throws Exception {
		// origin - 07.06.2025, last edit - 06.10.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			String currQty = "";
			String currPA = "";
			String currMore = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				currQty = this.qty.getByIndex(i);
				currPA = this.pa.getByIndex(i);
				currMore = "";
				currMore = currMore + MoreVal.setPartMore("Qty", currQty);
				currMore = currMore + MoreVal.setPartMore("PA", currPA);
				currMore = currMore + MoreVal.setPartMore("FullName", this.fullName);
				currMore = currMore + MoreVal.setPartMore("Comment", this.comment);
				var tmp = new DealDto(this.id, this.parent, this.face1, this.face2, this.face, currDate1, currDate2,
						this.code, this.description, this.geo, this.role, this.info, currMore, this.mark);
//				var qty = new Qty(currQty);
//				var pa = new PA(currPA);
//				var qpa = new QPA(qty.src, pa.src);
//				tmp.quantity = qpa.q.quantity;
//				tmp.price = qpa.pa.price;
//				tmp.amount = qpa.pa.amount;
//				tmp.comment = this.comment;
//				tmp.fullName = this.fullName;
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("Move.getVal():void, ex=" + ex.getMessage(), "", "Move");
		}
	}

	private void correct() throws Exception {
		// origin - 02.06.2025, last edit - 13.06.2025
		try {
			if (this.code.isEmpty() == false) {
				if (this.description.isEmpty()) {
					this.description = this.code;
				}
			}

			if (this.description.isEmpty() == false) {
				if (this.code.isEmpty()) {
					this.code = this.description;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Move.correct():void, ex=" + ex.getMessage(), "", "Move");
		}
	}

	private String getMoreFromField() throws Exception {
		// origin - 26.05.2025, last edit - 13.06.2025
		String res = "";
		try {
			res = res + MoreVal.setPartMore("TemplateId", this.templateId);

			this.qty = ListVal.reduce(this.qty);
			res = res + MoreVal.setPartMore("Qty", this.qty.src);

			this.pa = ListVal.reduce(this.pa);
			res = res + MoreVal.setPartMore("PA", this.pa.src);
			// TODO - split pa on price and amount and after reduce separate price and
			// amount ???
		} catch (Exception ex) {
			WB.addLog("Move.getMoreFromField():void, ex=" + ex.getMessage(), "", "Move");
		}
		return res;
	}

	private void isExist() throws Exception {
		// origin - 26.05.2025, last edit - 18.11.2025
		try {
			List<ModelDto> listDto = new ArrayList<ModelDto>();

			// case template move
			if ((this.id.isEmpty() == false) & (this.code.isEmpty())) {
				listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), "Deal");
			}

			// case exist deal\move
			if ((this.parent.isEmpty() == false) & (this.code.isEmpty() == false)) {
				listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getParentCodeFilter(this.parent, this.code), "Deal");
			}

			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.id = DefVal.setCustom(this.id, dto.id);
				var tmp = new SpanDate(dto.date1, dto.date2);
				this.date1 = new ListVal(tmp.date1);
				this.date2 = new ListVal(tmp.date2);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.parent = DefVal.setCustom(this.parent, dto.parent);
				this.face1 = DefVal.setCustom(this.face1, dto.face1);
				this.face2 = DefVal.setCustom(this.face2, dto.face2);
				this.face = DefVal.setCustom(this.face, dto.face);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.geo = DefVal.setCustom(this.geo, dto.geo);
				this.role = DefVal.setCustom(this.role, dto.role);
				this.info = DefVal.setCustom(this.info, dto.info);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("Move.isExist():void, ex=" + ex.getMessage(), "", "Move");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 26.05.2025, last edit - 13.06.2025
		try {
			this.templateId = MoreVal.getFieldByKey(this.more, "TemplateId");
			this.qty = new ListVal(MoreVal.getFieldByKey(this.more, "Qty"), "");
			this.qty = ListVal.ext(this.qty, this.date1.val.size());
			this.pa = new ListVal(MoreVal.getFieldByKey(this.more, "PA"), "");
			this.pa = ListVal.ext(this.pa, this.date1.val.size());
		} catch (Exception ex) {
			WB.addLog("Move.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Move");
		}
	}

	// get new move by DealDto.id,... without isExist
	public Move(String Id, String Parent, String Face1, String Face2, String Face, String Date1, String Date2,
			String Code, String Description, String Geo, String Role, String Info, String More, String Mark)
			throws Exception {
		// origin - 08.06.2025, last edit - 18.11.2025
		this.clear();
		this.src = this.id = Id;
		this.parent = Parent;
		this.face1 = Face1;
		this.face2 = Face2;
		this.face = Face;
		this.date1 = new ListVal(Date1, "");
		this.date2 = new ListVal(Date2, "");
		this.code = Code;
		this.description = Description;
		this.geo = Geo;
		this.role = Role;
		this.info = Info;
		this.more = More;
		this.getFieldFromMore();
		this.mark = Mark;
		this.getVal();
		this.correct();
		this.validate();
	}

	// get new Move by template
	public Move(String templateId, String Code, String Description) throws Exception {
		// origin - 26.05.2025, last edit - 18.11.2025
		this(templateId);
		if (this.id.isEmpty() == false) {
			this.id = new IdGen("", "").id;
			this.date1 = ListVal.add(this.date1, DateTool.getNow().toString());
			this.date2 = new ListVal();
			this.code = Code;
			this.code = Move.getCode(this);
			this.description = Description;
			this.mark = "Mark.DD";
			this.validate();
		}
	}

	// read Move by ParentId if is exist
	public Move(String ParentId, String Code) throws Exception {
		// origin - 26.05.2025, last edit - 18.11.2025
		this.clear();
		this.src = ParentId + "," + Code;
		this.parent = ParentId;
		this.code = Code;
		this.isExist();
		this.getVal();
		this.correct();
		this.validate();
	}

	// read Move if is exist
	public Move(String Id) throws Exception {
		// origin - 26.05.2025, last edit - 18.11.2025
		this.clear();
		this.src = this.id = Id;
		this.isExist();
		this.getVal();
		this.correct();
		this.validate();
	}

	public Move() throws Exception {
		// origin - 26.05.2025, last edit - 26.05.2025
		this.clear();
	}

	public String toString() {
		// origin - 26.05.2025, last edit - 18.11.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addAnyway(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(" id ", this.id);
			res = res + Fmtr.addIfNotEmpty(" parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(" face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(" face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(" face ", this.face);
			res = res + Fmtr.addIfNotEmpty(" date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(" date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(" code ", this.code);
			res = res + Fmtr.addIfNotEmpty(" description ", this.description);
			res = res + Fmtr.addIfNotEmpty(" ", this.geo);
			res = res + Fmtr.addIfNotEmpty(" ", this.role);
			res = res + Fmtr.addIfNotEmpty(" ", this.info);
			res = res + Fmtr.addIfNotEmpty(" more ", this.more);
			res = res + Fmtr.addIfNotEmpty(" ", this.mark);
			res = res + Fmtr.addIfNotEmpty(" templateId ", this.templateId);
			res = res + Fmtr.addIfNotEmpty(" qty ", this.qty.id);
			res = res + Fmtr.addIfNotEmpty(" pa ", this.pa.id);
			res = res + Fmtr.addIfNotEmpty(" comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(" fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(" val ", this.val.size());
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	private void clear() throws Exception {
		// origin - 26.05.2025, last edit - 18.11.2025
		try {
			this.table = "Deal";
			this.src = this.id = this.parent = this.face1 = this.face2 = this.face = this.code = this.description = "";
			this.geo = this.role = this.info = this.more = this.mark = this.defect = "";
			this.comment = this.fullName = this.templateId = this.termId = this.assetCatId = "";
			this.date1 = this.date2 = this.qty = this.pa = new ListVal();
			this.val = new ArrayList<DealDto>();
		} catch (Exception ex) {
			WB.addLog("Move.clear():void, ex=" + ex.getMessage(), "", "Move");
		}
	}

	public static void test() throws Exception {
		// origin - 26.05.2025, last edit - 06.10.2025
		try {

//			{
//				WB.addLog2("Move.test.set(Move):ModelDto", "", "Move");
//				var tmp1 = new Move("Deal.Move.Test1", "TestCode", "TestDescription");
//				var tmp2 = Move.set(tmp1);
//				WB.addLog2("Move.test.set(Move):ModelDto, res=" + tmp2 + ", more=" + tmp2.more, "", "Move");
//				WB.log(tmp1.val, "Move");
//			}

//			{
//				WB.addLog2("Move.test.get():List<DealDto>", "", "Move");
//				var tmp1 = Move.get();
//				WB.addLog2("Move.test.get():List<DealDto>, res.size=" + tmp1.size() + ", filterless", "", "Move");
//				WB.log(tmp1, "Move");
//			}

//			WB.addLog2("Move.test.getByParent(String):List<DealDto>", "", "Move");
//			for (var tmp1 : new String[] { "", "Deal.Test1", "Deal.Tralala" }) {
//				var tmp2 = Move.getByParent(tmp1);
//				WB.addLog2(
//						"Move.test.getByParent(String):List<DealDto>, res.size=" + tmp2.size() + ", parentId=" + tmp1,
//						"", "Move");
//				WB.log(tmp2, "Move");
//			}

//			WB.addLog2("Move.test.getCurr(2String):List<DealDto>", "", "Move");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "Deal.Test1" }) {
//					var tmp3 = Move.getCurr(tmp1, tmp2);
//					WB.addLog2("Move.test.getCurr(2String):List<DealDto>, res.size=" + tmp3.size() + ", date1=" + tmp1
//							+ ", parentId=" + tmp2, "", "Move");
//					WB.log(tmp3, "Move");
//				}
//			}

//			WB.addLog2("Move.test.getCurr(String):List<DealDto>", "", "Move");
//			for (var tmp1 : new String[] { "2024-06-18", "2025-01-01", "2025-01-15", "2025-01-31", "2025-02-01",
//					"2025-02-28", "2025-08-15" }) {
//				var tmp = Move.getCurr(tmp1);
//				WB.addLog2("Move.test.getCurr(String):List<DealDto>, res.size=" + tmp.size() + ", date1=" + tmp1, "",
//						"Move");
//				WB.log(tmp, "Move");
//			}

//			WB.addLog2("Move.test.ctor(3String)", "", "Move");
//			for (var tmp1 : new String[] { "Deal.Move.Template", "Deal.Move.Tralala" }) {
//				var tmp2 = new TwoVal("TestCode , TestDescription");
//				var tmp3 = new Move(tmp1, tmp2.val1, tmp2.val2);
//				WB.addLog2("Move.test.ctor(3String)=" + tmp3 + ", tmp1=" + tmp1 + ", tmp2=" + tmp2.val1 + ", tmp3="
//						+ tmp2.val2, "", "Move");
//				WB.log(tmp3.val, "Move");
//			}

//			WB.addLog2("Move.test.ctor(2String)", "", "Move");
//			for (var tmp1 : new String[] { "Deal.Test1 , Deal.Move.Test1", "Deal.Tralala , Deal.Move.Tralala" }) {
//				var tmp2 = new TwoVal(tmp1);
//				var tmp3 = new Move(tmp2.val1, tmp2.val2);
//				WB.addLog2("Move.test.ctor(2String)=" + tmp3, "", "Move");
//				WB.log(tmp3.val, "Move");
//			}

//			WB.addLog2("Move.test.ctor(String)", "", "Move");
//			for (var tmp1 : new String[] { "Deal.Move.Test1", "Deal.Move.Test2", "Deal.Move.Tralala" }) {
//				var tmp2 = new Move(tmp1);
//				WB.addLog2("Move.test.ctor(String)=" + tmp2, "", "Move");
//				WB.log(tmp2.val, "Move");
//			}

		} catch (Exception ex) {
			WB.addLog("Move.test():void, ex=" + ex.getMessage(), "", "Move");
		}
	}
}