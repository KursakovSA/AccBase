import java.util.ArrayList;
import java.util.List;

public final class Prolongation {
	// origin - 31.10.2024, last edit - 18.10.2026
	// common fields
	public String table, src, id, parent, face1, face2, face, date1, date2, code, description, geo, role, info, more,
			mark, defect;
	// special fields
	public String fullName, comment;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Prolongation.static ctor, ex=" + ex.getMessage(), "", "Prolongation");
		}
	}

	public static List<FullDto> getMassReg(List<FullDto> listDeal, int countPerDeal) throws Exception { // TODO
		// origin - 30.09.2025, last edit - 30.09.2025
		List<FullDto> res = new ArrayList<FullDto>();
		try {
//			for (var curr : listDeal) {
//				for (int i = 1; i <= countPerDeal; i++) {
//				}
//			}
		} catch (Exception ex) {
			WB.addLog("Prolongation.getMassReg(List<FullDto>, int):List<FullDto>, ex=" + ex.getMessage(), "",
					"Prolongation");
		}
		return res;
	}

	// ?? get, getCurr ?? it need ??

	public static List<Prolongation> getByParentRole(String parentId) throws Exception {
		// origin - 30.08.2025, last edit - 19.10.2026
		List<Prolongation> res = new ArrayList<Prolongation>();
		try {
			if (Etc.strNotValid(parentId)) {
				return res;
			}

			var dealList = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleFilter(parentId, "Role.Deal.Prolongation"), "Deal");

			for (var currDeal : dealList) {
				var dDto = new DealDto(currDeal);
				var currProlongation = new Prolongation(dDto);
				res.add(currProlongation);
			}
		} catch (Exception ex) {
			WB.addLog("Prolongation.getByParentRole(String):List<Prolongation>, ex=" + ex.getMessage(), "",
					"Prolongation");
		}
		return res;
	}

	public static List<Prolongation> getCurrByParentRole(String date1, String parentId) throws Exception {
		// origin - 30.08.2025, last edit - 19.10.2026
		List<Prolongation> res = new ArrayList<Prolongation>();
		try {
			if (Etc.strNotValid(date1, parentId)) {
				return res;
			}

			var dealList = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleFilter(parentId, "Role.Deal.Prolongation"), "Deal");
			List<DealDto> tmp1 = new ArrayList<DealDto>();
			for (var currDeal : dealList) {
				tmp1.add(new DealDto(currDeal));
			}
			var tmp2 = DealDto.getChrono(DateTool.getLocalDate(date1), tmp1);
			for (var currDealDto : tmp2) {
				res.add(new Prolongation(currDealDto));
			}
		} catch (Exception ex) {
			WB.addLog("Prolongation.getCurrByParentRole(2String):List<Prolongation>, ex=" + ex.getMessage(), "",
					"Prolongation");
		}
		return res;
	}

	private void fix() throws Exception {
		// origin - 11.10.2026, last edit - 11.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}

			this.date1 = DefVal.set(this.date1, WB.minDateSupported.toString());
			this.date2 = DefVal.set(this.date2, WB.maxDateSupported.toString());
			this.mark = DefVal.set(this.mark, "Mark.DD");
		} catch (Exception ex) {
			WB.addLog("Prolongation.fix():void, ex=" + ex.getMessage(), "", "Prolongation");
		}
	}

	private void validate() throws Exception {
		// origin - 18.11.2025, last edit - 10.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}

			this.defect = Fmtr.addIfStrEmpty(this.defect, MoreVal.getFieldByKey(this.more, "TermId"), "empty termId; ");
			this.defect = Fmtr.addIfStrEmpty(this.defect, MoreVal.getFieldByKey(this.more, "TemplateId"),
					"empty templateId; ");
		} catch (Exception ex) {
			WB.addLog("Prolongation.validate():void, ex=" + ex.getMessage(), "", "Prolongation");
		}
	}

	private void isExist() throws Exception {
		// origin - 10.01.2025, last edit - 10.10.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdRoleFilter(this.id, "Role.Deal.Prolongation"),
					"Deal");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.code = dto.code;
				this.parent = dto.parent;
				this.face1 = dto.face1;
				this.face2 = dto.face2;
				this.face = dto.face;
				this.description = dto.description;
				this.geo = dto.geo;
				this.role = dto.role;
				this.info = dto.info;
				this.more = dto.more;
				this.mark = dto.mark;
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.clear();
			}
		} catch (Exception ex) {
			WB.addLog("Prolongation.isExist():void, ex=" + ex.getMessage(), "", "Prolongation");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 30.08.2025, last edit - 16.09.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("Prolongation.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Prolongation");
		}
	}

	// get new Prolongation by DealDto.id,... without isExist
	public Prolongation(DealDto dDto) throws Exception {
		// origin - 30.08.2025, last edit - 11.10.2026
		this.clear();
		this.src = this.id = dDto.id;
		this.parent = dDto.parent;
		this.face1 = dDto.face1;
		this.face2 = dDto.face2;
		this.face = dDto.face;
		this.date1 = dDto.date1;
		this.date2 = dDto.date2;
		this.code = dDto.code;
		this.description = dDto.description;
		this.geo = dDto.geo;
		this.role = dDto.role;
		this.info = dDto.info;
		this.more = dDto.more;
		this.getFieldFromMore();
		this.mark = dDto.mark;
		this.fix();
		this.validate();
	}

	public Prolongation(String Id) throws Exception {
		// origin - 10.01.2025, last edit - 11.10.2026
		this.clear();
		this.src = this.id = Id;
		this.isExist();
		this.fix();
		this.validate();
	}

	public Prolongation() throws Exception {
		// origin - 10.01.2025, last edit - 10.01.2025
		this.clear();
	}

	public String toString() {
		// origin - 10.01.2025, last edit - 16.09.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	private void clear() throws Exception {
		// origin - 10.01.2025, last edit - 14.10.2026
		try {
			this.table = "Deal";
			this.id = this.parent = this.date1 = this.date2 = this.face1 = this.face2 = this.face = this.code = this.description = "";
			this.src = this.geo = this.role = this.info = this.more = this.mark = this.defect = "";
			this.fullName = this.comment = "";
		} catch (Exception ex) {
			WB.addLog("Prolongation.clear():void, ex=" + ex.getMessage(), "", "Prolongation");
		}
	}

	public static void test() throws Exception {
		// origin - 31.10.2024, last edit - 15.10.2025
		try {

//			WB.addLog2("Prolongation.test.getCurrByParentRole(List<Prolongation>)", "", "Prolongation");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-24", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "", "Deal.Test1", "Deal.Tralala" }) {
//					var tmp3 = Prolongation.getCurrByParentRole(tmp1, tmp2);
//					WB.addLog2("Prolongation.test.getCurrByParentRole(List<Prolongation>), res.size=" + tmp3.size()
//							+ ", date1=" + tmp1 + ", parentId=" + tmp2, "", "Prolongation");
//					WB.log(tmp3, "Prolongation");
//				}
//			}

//			WB.addLog2("Prolongation.test.getByParentRole(List<Prolongation>)", "", "Prolongation");
//			for (var tmp1 : new String[] { "", "Deal.Test1", "Deal.Tralala" }) {
//				var tmp2 = Prolongation.getByParentRole(tmp1);
//				WB.addLog2("Prolongation.test.getByParentRole(List<Prolongation>), res.size=" + tmp2.size() + ", parentId="
//						+ tmp1, "", "Prolongation");
//				WB.log(tmp2, "Prolongation");
//			}

//			WB.addLog2("Prolongation.test.ctor(String)", "", "Prolongation");
//			for (var tmp : new String[] { "", "Deal.Prolongation.Test1", "Deal.Prolongation.Test2",
//					"Deal.Prolongation.Tralala" }) {
//				WB.addLog2("Prolongation.test.ctor(string)=" + new Prolongation(tmp), "", "Prolongation");
//			}

		} catch (Exception ex) {
			WB.addLog("Prolongation.test():void, ex=" + ex.getMessage(), "", "Prolongation");
		}
	}
}