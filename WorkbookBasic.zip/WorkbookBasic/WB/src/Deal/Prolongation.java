import java.util.ArrayList;
import java.util.List;

public final class Prolongation {
	// origin - 31.10.2024, last edit - 12.10.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, face1, face2, face, date1, date2, code, description, geo, role, info, more,
			mark;
	// special fields
	public String fullName, comment, templateId, termId;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Prolongation.static ctor, ex=" + ex.getMessage(), "", "Prolongation");
		}
	}

	@SuppressWarnings("unused")
	public static List<ModelDto> getMassReg(List<ModelDto> listDeal, int countPerDeal) throws Exception { // TODO
		// origin - 30.09.2025, last edit - 30.09.2025
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			for (var curr : listDeal) {
				for (int i = 1; i <= countPerDeal; i++) {
				}
			}
		} catch (Exception ex) {
			WB.addLog("Prolongation.getMassReg(List<ModelDto>, int):List<ModelDto>, ex=" + ex.getMessage(), "",
					"Prolongation");
		}
		return res;
	}

	// ?? get, getCurr ?? it need ??

	// full list Prolongation for this deal
	public static List<Prolongation> getByParent(String parentId) throws Exception {
		// origin - 30.08.2025, last edit - 15.09.2025
		List<Prolongation> res = new ArrayList<Prolongation>();
		try {
			var dealList = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleFilter(parentId, "Role.Deal.Prolongation"), "Deal");
			if (dealList.size() != 0) {
				for (var currDeal : dealList) {
					var dDto = new DealDto(currDeal);
					var currProlongation = new Prolongation(dDto);
					res.add(currProlongation);
				}
			}
		} catch (Exception ex) {
			WB.addLog("Prolongation.getByParent(String):List<Prolongation>, ex=" + ex.getMessage(), "", "Prolongation");
		}
		return res;
	}

	// full list Prolongation on date1
	public static List<Prolongation> getCurrByParent(String date1, String parentId) throws Exception {
		// origin - 30.08.2025, last edit - 15.09.2025
		List<Prolongation> res = new ArrayList<Prolongation>();
		try {
			var dealList = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleFilter(parentId, "Role.Deal.Prolongation"), "Deal");

			if (dealList.size() != 0) {
				List<DealDto> tmp1 = new ArrayList<DealDto>();

				for (var currDeal : dealList) {
					tmp1.add(new DealDto(currDeal));
				}

				var tmp2 = DealDto.getChrono(DateTool.getLocalDate(date1), tmp1);
				for (var currDealDto : tmp2) {
					res.add(new Prolongation(currDealDto));
				}

			}
		} catch (Exception ex) {
			WB.addLog("Prolongation.getCurrByParent(2String):List<Prolongation>, ex=" + ex.getMessage(), "",
					"Prolongation");
		}
		return res;
	}

	private void isExist() throws Exception {
		// origin - 10.01.2025, last edit - 06.10.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdRoleFilter(this.id, "Role.Deal.Prolongation"),
					"Deal");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.code = dto.code;
				this.parent = dto.parent;
				this.face1 = dto.face1;
				this.face2 = dto.face2;
				this.face = dto.face;
				this.description = dto.description;
				this.geo = dto.geo;
				this.role = dto.role;
				this.info = dto.info;
				this.more = dto.more;
				this.mark = dto.mark;
				this.getFieldFromMore();
				this.isExist = true;
				this.isValid = true;
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("Prolongation.isExist():void, ex=" + ex.getMessage(), "", "Prolongation");
		}
	}

	@SuppressWarnings("unused")
	private String getMoreFromField() throws Exception {
		// origin - 30.08.2025, last edit - 31.08.2025
		String res = "";
		try {
			res = res + MoreVal.setPartMore("TemplateId", this.templateId);
			res = res + MoreVal.setPartMore("TermId", this.termId);
		} catch (Exception ex) {
			WB.addLog("Prolongation.getMoreFromField():String, ex=" + ex.getMessage(), "", "Prolongation");
		}
		return res;
	}

	private void getFieldFromMore() throws Exception {
		// origin - 30.08.2025, last edit - 31.08.2025
		try {
			this.templateId = MoreVal.getFieldByKey(this.more, "TemplateId");
			this.termId = MoreVal.getFieldByKey(this.more, "TermId");
		} catch (Exception ex) {
			WB.addLog("Prolongation.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Prolongation");
		}
	}

	// get new Prolongation by DealDto.id,... without isExist
	public Prolongation(DealDto dDto) throws Exception {
		// origin - 30.08.2025, last edit - 30.08.2025
		this.clear();
		this.src = this.id = dDto.id;
		this.parent = dDto.parent;
		this.face1 = dDto.face1;
		this.face2 = dDto.face2;
		this.face = dDto.face;
		this.date1 = dDto.date1;
		this.date2 = dDto.date2;
		this.code = dDto.code;
		this.description = dDto.description;
		this.geo = dDto.geo;
		this.role = dDto.role;
		this.info = dDto.info;
		this.more = dDto.more;
		this.getFieldFromMore();
		this.mark = dDto.mark;
	}

	public Prolongation(String Id) throws Exception {
		// origin - 10.01.2025, last edit - 11.08.2025
		this.clear();
		this.src = this.id = Id;
		this.isExist();
	}

	public Prolongation() throws Exception {
		// origin - 10.01.2025, last edit - 10.01.2025
		this.clear();
	}

	public String toString() {
		// origin - 10.01.2025, last edit - 06.10.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", templateId ", this.templateId);
			res = res + Fmtr.addIfNotEmpty(", termId ", this.termId);
			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	private void clear() throws Exception {
		// origin - 10.01.2025, last edit - 06.10.2025
		try {
			this.isValid = false;
			this.isExist = false;
			this.table = "Deal";
			this.id = this.parent = this.date1 = this.date2 = this.face1 = this.face2 = this.face = this.code = this.description = "";
			this.geo = this.role = this.info = this.more = this.mark = "";
			this.fullName = this.comment = this.templateId = this.termId = "";
		} catch (Exception ex) {
			WB.addLog("Prolongation.clear():void, ex=" + ex.getMessage(), "", "Prolongation");
		}
	}

	public static void test() throws Exception {
		// origin - 31.10.2024, last edit - 06.10.2025
		try {

//			WB.addLog2("Prolongation.test.getCurrByParent(List<Prolongation>)", "", "Prolongation");
//			for (var tmp1 : new String[] { "2023-04-05", "2025-01-24", "2025-08-15" }) {
//				for (var tmp2 : new String[] { "", "Deal.Test1", "Deal.Tralala" }) {
//					var tmp3 = Prolongation.getCurrByParent(tmp1, tmp2);
//					WB.addLog2("Prolongation.test.getCurrByParent(List<Prolongation>), res.size=" + tmp3.size()
//							+ ", date1=" + tmp1 + ", parentId=" + tmp2, "", "Prolongation");
//					WB.log(tmp3, "Prolongation");
//				}
//			}

//			WB.addLog2("Prolongation.test.getByParent(List<Prolongation>)", "", "Prolongation");
//			for (var tmp1 : new String[] { "", "Deal.Test1", "Deal.Tralala" }) {
//				var tmp2 = Prolongation.getByParent(tmp1);
//				WB.addLog2("Prolongation.test.getByParent(List<Prolongation>), res.size=" + tmp2.size() + ", parentId="
//						+ tmp1, "", "Prolongation");
//				WB.log(tmp2, "Prolongation");
//			}

//			WB.addLog2("Prolongation.test.ctor(String)", "", "Prolongation");
//			for (var tmp : new String[] { "", "Deal.Prolongation.Test1", "Deal.Prolongation.Test2",
//					"Deal.Prolongation.Tralala" }) {
//				WB.addLog2("Prolongation.test.ctor(string)=" + new Prolongation(tmp), "", "Prolongation");
//			}

		} catch (Exception ex) {
			WB.addLog("Prolongation.test():void, ex=" + ex.getMessage(), "", "Prolongation");
		}
	}
}