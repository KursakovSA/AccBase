import java.util.List;

public final class AccrualTerm {
	// origin - 12.10.2026, last edit - 25.10.2026
	// common fields
	public String table, src, id, parent, face1, face2, face, date1, date2, code, description, geo, role, info, more,
			mark, defect;
	// special fields
	public static List<String> roleList;

	static {
		try {
			AccrualTerm.roleList = List.of("Role.Deal.Accrual");
		} catch (Exception ex) {
			WB.addLog("AccrualTerm.static ctor, ex=" + ex.getMessage(), "", "AccrualTerm");
		}
	}

	private void getByParentTemplate(String parentId) throws Exception {
		// origin - 12.10.2026, last edit - 19.10.2026
		try {
			if (Etc.strNotValid(parentId)) {
				return;
			}

			BasicDto bDto = new BasicDto("Deal", parentId);
			var templateId = MoreVal.getFieldByKey(bDto.more, "TemplateId");
			if (templateId.isEmpty() == false) {
				this.src = this.parent = templateId;
				this.isExist();
			}
		} catch (Exception ex) {
			WB.addLog("AccrualTerm.getByParentTemplate(String):void, ex=" + ex.getMessage(), "", "AccrualTerm");
		}
	}

	private void fix() throws Exception {
		// origin - 12.10.2026, last edit - 12.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}

			this.date1 = DefVal.set(this.date1, WB.minDateSupported.toString());
			this.date2 = DefVal.set(this.date2, WB.maxDateSupported.toString());
			this.mark = DefVal.set(this.mark, "Mark.DD");
		} catch (Exception ex) {
			WB.addLog("AccrualTerm.fix():void, ex=" + ex.getMessage(), "", "AccrualTerm");
		}
	}

	private void validate() throws Exception {
		// origin - 12.10.2026, last edit - 12.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}

			this.defect = Fmtr.addIfStrEmpty(this.defect, MoreVal.getFieldByKey(this.more, "TemplateId"),
					"empty templateId; ");
		} catch (Exception ex) {
			WB.addLog("AccrualTerm.validate():void, ex=" + ex.getMessage(), "", "AccrualTerm");
		}
	}

	private void isExist() throws Exception {
		// origin - 12.10.2026, last edit - 02.11.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleInfoFilter(this.parent, AccrualTerm.roleList.getFirst(), "Info.Deal.Term"),
					"Deal");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.id = dto.id;
				this.code = dto.code;
				this.face1 = dto.face1;
				this.face2 = dto.face2;
				this.face = dto.face;
				this.description = dto.description;
				this.geo = dto.geo;
				this.role = dto.role;
				this.info = dto.info;
				this.more = dto.more;
			}

			if (listDto.size() == 0) {
				this.clear();
			}
		} catch (Exception ex) {
			WB.addLog("AccrualTerm.isExist():void, ex=" + ex.getMessage(), "", "AccrualTerm");
		}
	}

	public AccrualTerm(String ParentId) throws Exception {
		// origin - 12.10.2026, last edit - 12.10.2026
		this.clear();
		ParentId = Etc.fixTrim(ParentId);
		this.src = this.parent = ParentId;
		this.isExist();

		if (this.id.isEmpty()) {
			this.getByParentTemplate(ParentId);
		}

		this.fix();
		this.validate();
	}

	public AccrualTerm() throws Exception {
		// origin - 12.10.2026, last edit - 12.10.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 12.10.2026, last edit - 25.10.2026
		try {
			this.table = "Deal";
			this.id = this.parent = this.face1 = this.face2 = this.face = this.date1 = this.date2 = this.code = this.description = "";
			this.src = this.geo = this.role = this.info = this.more = this.mark = this.defect = "";
		} catch (Exception ex) {
			WB.addLog("AccrualTerm.clear():void, ex=" + ex.getMessage(), "", "AccrualTerm");
		}
	}

	public String toString() {
		// origin - 12.10.2026, last edit - 12.10.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 12.10.2026, last edit - 12.10.2026
		try {

//			WB.addLog2("AccrualTerm.test.ctor(String)", "", "AccrualTerm");
//			for (var tmp1 : new String[] { null, "", "Deal.Face.Template1", "лс 000000", "лс 111111",
//					"лс 000000, усл 100", "лс 111111, усл 100", "Deal.tralala", "Deal.Test1" }) {
//				WB.addLog2("AccrualTerm.test.ctor(String)=" + new AccrualTerm(tmp1) + ", tmp1=" + tmp1, "",
//						"AccrualTerm");
//			}

		} catch (Exception ex) {
			WB.addLog("AccrualTerm.test()(:void, ex=" + ex.getMessage(), "", "AccrualTerm");
		}
	}
}