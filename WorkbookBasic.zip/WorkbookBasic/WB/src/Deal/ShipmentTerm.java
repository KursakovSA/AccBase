import java.util.List;

public final class ShipmentTerm {
	// origin - 28.08.2025, last edit - 11.10.2026
	// common fields
	public String table, src, id, parent, face1, face2, face, date1, date2, code, description, geo, role, info, more,
			mark, defect;
	// special fields
	public String fullName, comment;
	public static List<String> nameList;

	static {
		try {
			ShipmentTerm.nameList = List.of("TemplateId", "TermId");
		} catch (Exception ex) {
			WB.addLog("ShipmentTerm.static ctor, ex=" + ex.getMessage(), "", "ShipmentTerm");
		}
	}

	private void getByParentTemplate(String parentId) throws Exception {
		// origin - 11.10.2026, last edit - 11.10.2026
		try {
			BasicDto bDto = new BasicDto("Deal", parentId);
			var templateId = MoreVal.getFieldByKey(bDto.more, "TemplateId");
			if (templateId.isEmpty() == false) {
				this.src = this.parent = templateId;
				this.isExist();
			}
		} catch (Exception ex) {
			WB.addLog("ShipmentTerm.getByParentTemplate(String):void, ex=" + ex.getMessage(), "", "ShipmentTerm");
		}
	}

	private void fix() throws Exception {
		// origin - 11.10.2026, last edit - 11.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}

			this.date1 = DefVal.set(this.date1, WB.minDateSupported.toString());
			this.date2 = DefVal.set(this.date2, WB.maxDateSupported.toString());
			this.mark = DefVal.set(this.mark, "Mark.DD");
		} catch (Exception ex) {
			WB.addLog("ShipmentTerm.fix():void, ex=" + ex.getMessage(), "", "ShipmentTerm");
		}
	}

	private void validate() throws Exception {
		// origin - 20.11.2025, last edit - 12.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}

			this.defect = Fmtr.addIfStrEmpty(this.defect, MoreVal.getFieldByKey(this.more, "TemplateId"),
					"empty templateId; ");
		} catch (Exception ex) {
			WB.addLog("ShipmentTerm.validate():void, ex=" + ex.getMessage(), "", "ShipmentTerm");
		}
	}

	private void isExist() throws Exception {
		// origin - 28.08.2025, last edit - 11.10.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentRoleInfoFilter(this.parent, "Role.Deal.Shipment", "Info.Deal.Term"), "Deal");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.id = dto.id;
				this.code = dto.code;
				this.face1 = dto.face1;
				this.face2 = dto.face2;
				this.face = dto.face;
				this.description = dto.description;
				this.geo = dto.geo;
				this.role = dto.role;
				this.info = dto.info;
				this.more = dto.more;
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.clear();
			}
		} catch (Exception ex) {
			WB.addLog("ShipmentTerm.isExist():void, ex=" + ex.getMessage(), "", "ShipmentTerm");
		}
	}

	public ShipmentTerm(String ParentId) throws Exception {
		// origin - 28.08.2025, last edit - 11.10.2026
		this.clear();
		ParentId = Etc.fixTrim(ParentId);
		this.src = this.parent = ParentId;
		this.isExist();

		if (this.id.isEmpty()) {
			this.getByParentTemplate(ParentId);
		}

		this.fix();
		this.validate();
	}

	public ShipmentTerm() throws Exception {// TODO
		// origin - 28.08.2025, last edit - 28.08.2025
		this.clear();
	}

	public String toString() {
		// origin - 28.08.2025, last edit - 11.10.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	private void getFieldFromMore() throws Exception {
		// origin - 28.08.2025, last edit - 16.09.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("ShipmentTerm.getFieldFromMore():void, ex=" + ex.getMessage(), "", "ShipmentTerm");
		}
	}

	private void clear() throws Exception {
		// origin - 28.08.2025, last edit - 11.10.2026
		try {
			this.table = "Deal";
			this.src = this.id = this.parent = this.date1 = this.date2 = this.face1 = this.face2 = this.face = this.code = "";
			this.description = this.geo = this.role = this.info = this.more = this.mark = this.defect = "";
			this.fullName = this.comment = "";
		} catch (Exception ex) {
			WB.addLog("ShipmentTerm.clear():void, ex=" + ex.getMessage(), "", "ShipmentTerm");
		}
	}

	public static void test() throws Exception {
		// origin - 28.08.2025, last edit - 11.10.2026
		try {

//			WB.addLog2("ShipmentTerm.test.ctor(String)", "", "ShipmentTerm");
//			for (var tmp1 : new String[] { null, "", "Deal.Face.Template1", "лс 000000", "лс 111111",
//					"лс 000000, усл 100", "лс 111111, усл 100", "Deal.tralala", "Deal.Test1" }) {
//				WB.addLog2("ShipmentTerm.test.ctor(String)=" + new ShipmentTerm(tmp1) + ", tmp1=" + tmp1, "",
//						"ShipmentTerm");
//			}

		} catch (Exception ex) {
			WB.addLog("ShipmentTerm.test():void, ex=" + ex.getMessage(), "", "ShipmentTerm");
		}
	}
}