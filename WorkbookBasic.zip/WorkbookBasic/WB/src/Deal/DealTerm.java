public final class DealTerm {
	// origin - 25.08.2025, last edit - 19.10.2026
	// common fields
	public String table, src, id, parent, face1, face2, face, date1, date2, code, description, geo, role, info, more,
			mark, defect;
	// special fields
	public String fullName, comment;
	// term fields
	public DurationTerm duration;
	public ShipmentTerm shipment;
	public DeliveryTerm delivery;
	public PaymentTerm payment;
	public PriceTerm price;
	public AddTerm add;
	public TemplateDocTerm templateDoc;
	public AccrualTerm accrual;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("DealTerm.static ctor, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}

	private void getTerm() throws Exception {
		// origin - 14.10.2026, last edit - 14.10.2026
		try {
			this.payment = new PaymentTerm(this.id);
			this.price = new PriceTerm(this.id);
			this.delivery = new DeliveryTerm(this.id);
			this.shipment = new ShipmentTerm(this.id);
			this.duration = new DurationTerm(this.id);
			this.templateDoc = new TemplateDocTerm(this.id);
			this.add = new AddTerm(this.id);
			this.accrual = new AccrualTerm(this.id);
		} catch (Exception ex) {
			WB.addLog("DealTerm.getTerm():void, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}

	private void fix() throws Exception {
		// origin - 14.10.2026, last edit - 14.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}

			this.date1 = DefVal.set(this.date1, WB.minDateSupported.toString());
			this.date2 = DefVal.set(this.date2, WB.maxDateSupported.toString());
			this.mark = DefVal.set(this.mark, "Mark.DD");
		} catch (Exception ex) {
			WB.addLog("DealTerm.fix():void, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}

	private void validate() throws Exception {
		// origin - 14.09.2025, last edit - 14.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}

			this.defect = Fmtr.addIfStrNotEmpty(this.defect, this.shipment.defect, "defect shipment; ");
			this.defect = Fmtr.addIfStrNotEmpty(this.defect, this.delivery.defect, "defect delivery; ");
			this.defect = Fmtr.addIfStrNotEmpty(this.defect, this.payment.defect, "defect payment; ");
			this.defect = Fmtr.addIfStrNotEmpty(this.defect, this.price.defect, "defect price; ");
			this.defect = Fmtr.addIfStrNotEmpty(this.defect, this.add.defect, "defect add; ");
			this.defect = Fmtr.addIfStrNotEmpty(this.defect, this.templateDoc.defect, "defect templateDoc; ");
			this.defect = Fmtr.addIfStrNotEmpty(this.defect, this.accrual.defect, "defect accrual; ");
		} catch (Exception ex) {
			WB.addLog("DealTerm.validate():void, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}

	private void isExist() throws Exception {
		// origin - 25.08.2025, last edit - 12.10.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), "Deal");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.code = dto.code;
				this.parent = dto.parent;
				this.face1 = dto.face1;
				this.face2 = dto.face2;
				this.face = dto.face;
				this.description = dto.description;
				this.geo = dto.geo;
				this.role = dto.role;
				this.info = dto.info;
				this.more = dto.more;
				this.mark = dto.mark;
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.clear();
			}
		} catch (Exception ex) {
			WB.addLog("DealTerm.isExist():void, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 30.08.2025, last edit - 14.10.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("DealTerm.getFieldFromMore():void, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}

	public DealTerm(String TemplateId) throws Exception {
		// origin - 25.08.2025, last edit - 14.10.2026
		this.clear();
		this.src = this.id = TemplateId;
		this.isExist();
		this.getTerm();
		this.fix();
		this.validate();
	}

	public DealTerm() throws Exception {
		// origin - 25.08.2025, last edit - 25.08.2025
		this.clear();
	}

	public String toString() {
		// origin - 25.08.2025, last edit - 14.10.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", shipment.id ", this.shipment.id);
			res = res + Fmtr.addIfNotEmpty(", delivery.id ", this.delivery.id);
			res = res + Fmtr.addIfNotEmpty(", payment.id ", this.payment.id);
			res = res + Fmtr.addIfNotEmpty(", duration.id ", this.duration.id);
			res = res + Fmtr.addIfNotEmpty(", price.id ", this.price.id);
			res = res + Fmtr.addIfNotEmpty(", add.id ", this.add.id);
			res = res + Fmtr.addIfNotEmpty(", accrual.id ", this.accrual.id);
			res = res + Fmtr.addIfNotEmpty(", templateDoc.id ", this.templateDoc.id);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	private void clear() throws Exception {
		// origin - 25.08.2025, last edit - 14.10.2026
		try {
			this.table = "Deal";
			this.id = this.parent = this.date1 = this.date2 = this.face1 = this.face2 = this.face = this.code = this.description = "";
			this.src = this.geo = this.role = this.info = this.more = this.mark = this.defect = "";
			this.fullName = this.comment = "";
			this.duration = new DurationTerm();
			this.templateDoc = new TemplateDocTerm();
			this.shipment = new ShipmentTerm();
			this.delivery = new DeliveryTerm();
			this.payment = new PaymentTerm();
			this.price = new PriceTerm();
			this.add = new AddTerm();
			this.accrual = new AccrualTerm();
		} catch (Exception ex) {
			WB.addLog("DealTerm.clear():void, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}

	public static void test() throws Exception {
		// origin - 25.08.2025, last edit - 14.10.2026
		try {

//			WB.addLog2("DealTerm.test.ctor(String)", "", "DealTerm");
//			for (var tmp1 : new String[] { null, "", "Deal.Face.Template1", "лс 000000", "лс 111111",
//					"лс 000000, усл 100", "лс 111111, усл 100", "Deal.tralala", "Deal.Test1" }) {
//				WB.addLog2("DealTerm.test.ctor(String), res=" + new DealTerm(tmp1) + ", tmp1=" + tmp1, "", "DealTerm");
//			}

		} catch (Exception ex) {
			WB.addLog("DealTerm.test():void, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}
}