import java.util.List;

public final class DealTerm {
	// origin - 25.08.2025, last edit - 16.09.2026
	// common fields
	public String table, src, id, parent, face1, face2, face, date1, date2, code, description, geo, role, info, more,
			mark, defect;
	// special fields
	public String fullName, comment;
	// term fields
	public DurationTerm duration;
	public ShipmentTerm shipment;
	public DeliveryTerm delivery;
	public PaymentTerm payment;
	public PriceTerm price;
	public AddTerm add;
	public TemplateDocTerm templateDoc;
	// root branch fields
	public List<FullDto> lowerList, upperList;
	public static List<String> nameList;

	static {
		try {
			DealTerm.nameList = List.of("TemplateId", "TermId");
		} catch (Exception ex) {
			WB.addLog("DealTerm.static ctor, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}

	private void validate() throws Exception {
		// origin - 14.09.2025, last edit - 11.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}
			
			this.defect = Fmtr.addIfStrNotEmpty(this.defect, this.shipment.defect, "defect shipment; ");
			this.defect = Fmtr.addIfStrNotEmpty(this.defect, this.delivery.defect, "defect delivery; ");
			this.defect = Fmtr.addIfStrNotEmpty(this.defect, this.payment.defect, "defect payment; ");
			this.defect = Fmtr.addIfStrNotEmpty(this.defect, this.price.defect, "defect price; ");
			this.defect = Fmtr.addIfStrNotEmpty(this.defect, this.add.defect, "defect add; ");
			this.defect = Fmtr.addIfStrNotEmpty(this.defect, this.templateDoc.defect, "defect templateDoc; ");
			this.defect = Fmtr.addIfStrEmpty(this.defect, MoreVal.getFieldByKey(this.more, "TermId"), "empty termId; ");
			this.defect = Fmtr.addIfStrEmpty(this.defect, MoreVal.getFieldByKey(this.more, "TemplateId"),
					"empty templateId; ");
		} catch (Exception ex) {
			WB.addLog("DealTerm.validate():void, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}

	private void isExist() throws Exception {
		// origin - 25.08.2025, last edit - 10.10.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), "Deal");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.code = dto.code;
				this.parent = dto.parent;
				this.face1 = dto.face1;
				this.face2 = dto.face2;
				this.face = dto.face;
				this.description = dto.description;
				this.geo = dto.geo;
				this.role = dto.role;
				this.info = dto.info;
				this.more = dto.more;
				this.mark = dto.mark;
				this.upperList = FullDto.getUpper(this.table, this.parent);
				this.lowerList = FullDto.getLower(this.table, this.id);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.clear();
			}
		} catch (Exception ex) {
			WB.addLog("DealTerm.isExist():void, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}

	private void getFieldFromMore() throws Exception { // TODO
		// origin - 30.08.2025, last edit - 16.09.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.payment = new PaymentTerm(MoreVal.getFieldByKey(this.more, "TermId")); // TODO
			this.price = new PriceTerm(MoreVal.getFieldByKey(this.more, "TermId")); // TODO
			this.delivery = new DeliveryTerm(MoreVal.getFieldByKey(this.more, "TermId")); // TODO
			this.shipment = new ShipmentTerm(MoreVal.getFieldByKey(this.more, "TermId")); // TODO
			this.duration = new DurationTerm(MoreVal.getFieldByKey(this.more, "TermId"));
			this.templateDoc = new TemplateDocTerm(MoreVal.getFieldByKey(this.more, "TemplateId"));
			this.add = new AddTerm(MoreVal.getFieldByKey(this.more, "TermId"));
		} catch (Exception ex) {
			WB.addLog("DealTerm.getFieldFromMore():void, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}

	public DealTerm(String Id) throws Exception { // TODO
		// origin - 25.08.2025, last edit - 20.11.2025
		this.clear();
		this.src = this.id = this.code = Id;
		this.isExist();
		this.validate();
	}

	public DealTerm() throws Exception {
		// origin - 25.08.2025, last edit - 25.08.2025
		this.clear();
	}

	public String toString() {
		// origin - 25.08.2025, last edit - 11.10.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", shipment ", this.shipment.id);
			res = res + Fmtr.addIfNotEmpty(", delivery ", this.delivery.id);
			res = res + Fmtr.addIfNotEmpty(", payment ", this.payment.id);
			res = res + Fmtr.addIfNotEmpty(", duration ", this.duration.id);
			res = res + Fmtr.addIfNotEmpty(", price ", this.price.id);
			res = res + Fmtr.addIfNotEmpty(", add.description ", this.add.description);
			res = res + Fmtr.addIfNotEmpty(", templateDoc ", this.templateDoc.id);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	private void clear() throws Exception {
		// origin - 25.08.2025, last edit - 16.09.2026
		try {
			this.table = "Deal";
			this.id = this.parent = this.date1 = this.date2 = this.face1 = this.face2 = this.face = this.code = this.description = "";
			this.geo = this.role = this.info = this.more = this.mark = this.defect = "";
			this.fullName = this.comment = "";
			this.duration = new DurationTerm();
			this.templateDoc = new TemplateDocTerm();
			this.shipment = new ShipmentTerm();
			this.delivery = new DeliveryTerm();
			this.payment = new PaymentTerm();
			this.price = new PriceTerm();
			this.add = new AddTerm();
		} catch (Exception ex) {
			WB.addLog("DealTerm.clear():void, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}

	public static void test() throws Exception {
		// origin - 25.08.2025, last edit - 05.01.2026
		try {

		} catch (Exception ex) {
			WB.addLog("DealTerm.test():void, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}
}