import java.util.List;

public final class DealTerm {
	// origin - 25.08.2025, last edit - 28.01.2026
	// common fields
	public String table, src, id, parent, face1, face2, face, date1, date2, code, description, geo, role, info, more,
			mark, defect;
	// special fields
	public String fullName, comment, templateId, termId;
	// term fields
	public DurationTerm duration;
	public ShipmentTerm shipment;
	public DeliveryTerm delivery;
	public PaymentTerm payment;
	public PriceTerm price;
	public AddTerm add;
	public TemplateDocTerm templateDoc;
	// root branch fields
	public List<ModelDto> lowerList, upperList;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("DealTerm.static ctor, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}

	private void validate() throws Exception {
		// origin - 14.09.2025, last edit - 01.01.2026
		try {
			if (this.src.isEmpty() == false) {
				if (this.shipment.defect.isEmpty()) {
					this.defect = this.defect + "defect shipment; ";
				}
				if (this.delivery.defect.isEmpty() == false) {
					this.defect = this.defect + "defect delivery; ";
				}
				if (this.payment.defect.isEmpty() == false) {
					this.defect = this.defect + "defect payment; ";
				}
				if (this.price.defect.isEmpty() == false) {
					this.defect = this.defect + "defect price; ";
				}
				if (this.add.defect.isEmpty() == false) {
					this.defect = this.defect + "defect add; ";
				}
				if (this.templateDoc.defect.isEmpty() == false) {
					this.defect = this.defect + "defect templateDoc; ";
				}
				if (this.termId.isEmpty()) {
					this.defect = this.defect + "empty termId; ";
				}
				if (this.templateId.isEmpty()) {
					this.defect = this.defect + "empty templateId; ";
				}
			}
		} catch (Exception ex) {
			WB.addLog("DealTerm.validate():void, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}

	private void isExist() throws Exception {
		// origin - 25.08.2025, last edit - 04.01.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), "Deal");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.code = dto.code;
				this.parent = dto.parent;
				this.face1 = dto.face1;
				this.face2 = dto.face2;
				this.face = dto.face;
				this.description = dto.description;
				this.geo = dto.geo;
				this.role = dto.role;
				this.info = dto.info;
				this.more = dto.more;
				this.mark = dto.mark;
				var listDto2 = DAL.getTable(WB.lastConnWork, Qry.getText(WB.lastConnWork, "Deal", ""));
				this.upperList = ModelDto.getUpper(listDto2, this.parent);
				this.lowerList = ModelDto.getLower(listDto2, this.code);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("DealTerm.isExist():void, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}

	private void getFieldFromMore() throws Exception { // TODO
		// origin - 30.08.2025, last edit - 28.01.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.templateId = MoreVal.getFieldByKey(this.more, "TemplateId");
			this.termId = MoreVal.getFieldByKey(this.more, "TermId");
			this.payment = new PaymentTerm(this.termId); // TODO
			this.price = new PriceTerm(this.termId); // TODO
			this.delivery = new DeliveryTerm(this.termId); // TODO
			this.shipment = new ShipmentTerm(this.termId); // TODO
			this.duration = new DurationTerm(this.termId);
			this.templateDoc = new TemplateDocTerm(this.templateId);
			this.add = new AddTerm(this.termId);
		} catch (Exception ex) {
			WB.addLog("DealTerm.getFieldFromMore():void, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}

	public DealTerm(String Id) throws Exception { // TODO
		// origin - 25.08.2025, last edit - 20.11.2025
		this.clear();
		this.src = this.id = this.code = Id;
		this.isExist();
		this.validate();
	}

	public DealTerm() throws Exception {
		// origin - 25.08.2025, last edit - 25.08.2025
		this.clear();
	}

	public String toString() {
		// origin - 25.08.2025, last edit - 28.01.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code.length());
			res = res + Fmtr.addIfNotEmpty(", description ", this.description.length());
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", shipment ", this.shipment);
			res = res + Fmtr.addIfNotEmpty(", delivery ", this.delivery);
			res = res + Fmtr.addIfNotEmpty(", payment ", this.payment);
			res = res + Fmtr.addIfNotEmpty(", duration ", this.duration);
			res = res + Fmtr.addIfNotEmpty(", price ", this.price);
			res = res + Fmtr.addIfNotEmpty(", add.description ", this.add.description);
			res = res + Fmtr.addIfNotEmpty(", templateDoc ", this.templateDoc);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	private void clear() throws Exception {
		// origin - 25.08.2025, last edit - 28.01.2026
		try {
			this.table = "Deal";
			this.id = this.parent = this.date1 = this.date2 = this.face1 = this.face2 = this.face = this.code = this.description = "";
			this.geo = this.role = this.info = this.more = this.mark = this.defect = "";
			this.fullName = this.comment = this.templateId = this.termId = "";
			this.duration = new DurationTerm();
			this.templateDoc = new TemplateDocTerm();
			this.shipment = new ShipmentTerm();
			this.delivery = new DeliveryTerm();
			this.payment = new PaymentTerm();
			this.price = new PriceTerm();
			this.add = new AddTerm();
		} catch (Exception ex) {
			WB.addLog("DealTerm.clear():void, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}

	public static void test() throws Exception {
		// origin - 25.08.2025, last edit - 05.01.2026
		try {

//			WB.addLog2("DealTerm.test.ctor(String)", "", "DealTerm");
//			for (var tmp1 : new String[] { "", "PawnDoc.Template1.V1.Term1", "PawnDoc.Template1.V1.Term2",
//					"Term.tralala" }) {
//				WB.addLog2("DealTerm.test.ctor(String)=" + new DealTerm(tmp1), "", "DealTerm");
//			}

		} catch (Exception ex) {
			WB.addLog("DealTerm.test():void, ex=" + ex.getMessage(), "", "DealTerm");
		}
	}
}