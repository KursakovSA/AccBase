import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public final class DealDto {
	// origin - 01.03.2025, last edit - 30.12.2025
	public String id, table, parent, date1, date2, code, description, more;
	public String face1, face2, face, geo, role, info, mark;
	// special fields
	public String fullName, comment;
	// public String PA, qty, PG, PC, PawnAuto;
	// public UnitVal quantity, price, amount;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("DealDto.static ctor, ex=" + ex.getMessage(), "", "DealDto");
		}
	}

	public static List<String> getId(List<DealDto> listDealDto) throws Exception {
		// origin - 23.06.2025, last edit - 23.06.2025
		List<String> res = new ArrayList<String>();
		try {
			for (var currDealDto : listDealDto) {
				if (currDealDto.id.isEmpty() == false) {
					res.add(currDealDto.id);
				}
			}
		} catch (Exception ex) {
			WB.addLog("DealDto.getId(List<DealDto>):List<String>, ex=" + ex.getMessage(), "", "DealDto");
		}
		return res;
	}

//	public static List<DealDto> get(List<Pawn> listPawn, String context) throws Exception {
//		// origin - 18.08.2025, last edit - 18.08.2025
//		List<DealDto> res = new ArrayList<DealDto>();
//		try {
//			for (var currPawn : listPawn) {
//				res.add(new DealDto(currPawn));
//			}
//		} catch (Exception ex) {
//			WB.addLog("DealDto.get(List<Pawn>):List<DealDto>, ex=" + ex.getMessage(), "", "DealDto");
//		}
//		return res;
//	}

	public static List<DealDto> get(List<ModelDto> listModelDto) throws Exception {
		// origin - 22.05.2025, last edit - 13.06.2025
		List<DealDto> res = new ArrayList<DealDto>();
		try {
			for (var currModelDto : listModelDto) {
				res.add(new DealDto(currModelDto));
			}
		} catch (Exception ex) {
			WB.addLog("DealDto.get(List<ModelDto>):List<DealDto>, ex=" + ex.getMessage(), "", "DealDto");
		}
		return res;
	}

	public static List<DealDto> getChrono(LocalDate calcDate, List<DealDto> listDealDto) throws Exception {
		// origin - 22.05.2025, last edit - 13.06.2025
		List<DealDto> res = new ArrayList<DealDto>();
		LocalDate currDate1;
		LocalDate currDate2;
		try {
			for (var currDto : listDealDto) {
				currDate1 = DateTool.getLocalDate(currDto.date1);// left border in data
				currDate2 = DateTool.getLocalDate(currDto.date2);// right border in data

				// left border hit or right border hit
				if ((Etc.strEquals(currDate1.toString(), calcDate.toString()))
						|| (Etc.strEquals(currDate2.toString(), calcDate.toString()))) {
					res.add(currDto);
					continue;
				}

				// range from left border to right border hit
				if ((currDate1.isBefore(calcDate)) && (currDate2.isAfter(calcDate))) {
					res.add(currDto);
					continue;
				}
			}
		} catch (Exception ex) {
			WB.addLog("DealDto.getChrono(LocalDate, List<DealDto>):List<DealDto>, ex=" + ex.getMessage(), "",
					"DealDto");
		}
		return res;
	}

	private void isExist() throws Exception {
		// origin - 25.05.2025, last edit - 07.09.2025
		try {
			List<ModelDto> listDto = new ArrayList<ModelDto>();

			if (this.id.isEmpty() == false) {
				listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), "Deal");
			}

			if (this.code.isEmpty() == false) {
				listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getCodeFilter(this.code), "Deal");
			}

			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.id = DefVal.setCustom(this.id, dto.id);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.parent = DefVal.setCustom(this.parent, dto.parent);
				this.face1 = DefVal.setCustom(this.face1, dto.face1);
				this.face2 = DefVal.setCustom(this.face2, dto.face2);
				this.face = DefVal.setCustom(this.face, dto.face);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.geo = DefVal.setCustom(this.geo, dto.geo);
				this.role = DefVal.setCustom(this.role, dto.role);
				this.info = DefVal.setCustom(this.info, dto.info);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("DealDto.isExist():void, ex=" + ex.getMessage(), "", "DealDto");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 07.06.2025, last edit - 30.12.2025
		try {
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			// this.PA = MoreVal.getFieldByKey(this.more, "PA");
			// this.qty = MoreVal.getFieldByKey(this.more, "Qty");
			// var qpa = new QPA(this.qty, this.PA);
			// this.quantity = qpa.q.quantity;
			// this.price = qpa.pa.price;
			// this.amount = qpa.pa.amount;
			// this.PG = MoreVal.getFieldByKey(this.more, "PG");
			// this.PawnAuto = MoreVal.getFieldByKey(this.more, "PawnAuto");
			// this.PC = MoreVal.getFieldByKey(this.more, "PC");
		} catch (Exception ex) {
			WB.addLog("DealDto.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Move");
		}
	}

	public DealDto(String Id, String Parent, String Face1, String Face2, String Face, String Date1, String Date2,
			String Code, String Description, String Geo, String Role, String Info, String More, String Mark)
			throws Exception {
		// origin - 01.03.2025, last edit - 09.08.2025
		this.clear();
		this.id = Id;
		this.face1 = Face1;
		this.face2 = Face2;
		this.face = Face;
		this.parent = Parent;
		this.date1 = Date1;
		this.date2 = Date2;
		this.code = Code;
		this.description = Description;
		this.geo = Geo;
		this.role = Role;
		this.info = Info;
		this.more = More;
		this.mark = Mark;
		this.getFieldFromMore();
	}

	public DealDto(Deal d) throws Exception {
		// origin - 13.08.2025, last edit - 13.08.2025
		this.clear();
		this.id = d.id;
		this.parent = d.parent;
		this.face1 = d.face1;
		this.face2 = d.face2;
		this.face = d.face;
		this.date1 = d.date1;
		this.date2 = d.date2;
		this.code = d.code;
		this.description = d.description;
		this.geo = d.geo;
		this.role = d.role;
		this.info = d.info;
		this.more = d.more;
		this.mark = d.mark;
		this.getFieldFromMore();
	}

	public DealDto(ModelDto mDto) throws Exception {
		// origin - 22.05.2025, last edit - 07.06.2025
		this.clear();
		this.id = mDto.id;
		this.parent = mDto.parent;
		this.face1 = mDto.face1;
		this.face2 = mDto.face2;
		this.face = mDto.face;
		this.date1 = mDto.date1;
		this.date2 = mDto.date2;
		this.code = mDto.code;
		this.description = mDto.description;
		this.geo = mDto.geo;
		this.role = mDto.role;
		this.info = mDto.info;
		this.more = mDto.more;
		this.mark = mDto.mark;
		this.getFieldFromMore();
	}

	// read DealDto if is exist or Id or Code is empty or unknown
	public DealDto(String Id, String Code) throws Exception {
		// origin - 23.06.2025, last edit - 23.06.2025
		this.clear();
		if (Id.isEmpty() == false) {
			this.id = Id;
		}
		if (Code.isEmpty() == false) {
			this.code = Code;
		}
		this.isExist();
	}

	// read DealDto if is exist
	public DealDto(String Id) throws Exception {
		// origin - 25.05.2025, last edit - 06.06.2025
		this.clear();
		this.id = Id;
		this.isExist();
	}

	private void clear() throws Exception {
		// origin - 01.03.2025, last edit - 30.12.2025
		try {
			this.table = "Deal";
			this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.more = "";
			this.face1 = this.face2 = this.face = this.geo = this.role = this.info = this.mark = "";
			this.comment = this.fullName = "";
			// this.PA = this.qty = this.PG = this.PawnAuto = this.PC = "";
		} catch (Exception ex) {
			WB.addLog("DealDto.clear():void, ex=" + ex.getMessage(), "", "DealDto");
		}
	}

	public DealDto() throws Exception {
		// origin - 01.03.2025, last edit - 01.03.2025
		this.clear();
	}

	public String toString() {
		// origin - 01.03.2025, last edit - 30.12.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("id ", this.id);
			res = res + Fmtr.addIfNotEmpty("table ", this.table);
			res = res + Fmtr.addIfNotEmpty(" parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(" face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(" face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(" face ", this.face);
			res = res + Fmtr.addIfNotEmpty(" date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(" date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(" code ", this.code);
			res = res + Fmtr.addIfNotEmpty(" description ", this.description);
			res = res + Fmtr.addIfNotEmpty(" ", this.geo);
			res = res + Fmtr.addIfNotEmpty(" ", this.role);
			res = res + Fmtr.addIfNotEmpty(" ", this.info);
			res = res + Fmtr.addIfNotEmpty(" more ", this.more);
			// res = res + Fmtr.addIfNotEmpty(" PA ", this.PA);
			// res = res + Fmtr.addIfNotEmpty(" qty ", this.qty);
			// res = res + Fmtr.addIfNotEmpty(" quantity ", this.quantity.id);
			// res = res + Fmtr.addIfNotEmpty(" price ", this.price.id);
			// res = res + Fmtr.addIfNotEmpty(" amount ", this.amount.id);
			// res = res + Fmtr.addIfNotEmpty(" PG ", this.PG);
			// res = res + Fmtr.addIfNotEmpty(" PawnAuto ", this.PawnAuto);
			// res = res + Fmtr.addIfNotEmpty(" PC ", this.PC);
			res = res + Fmtr.addIfNotEmpty(" comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(" fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(" ", this.mark);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 01.03.2025, last edit - 23.06.2025
		try {

//			WB.addLog2("DealDto.test.getId(List<DealDto> listDealDto):List<String>", "", "DealDto");
//			var tmp1 = List.of(new DealDto("", "PawnDoc.Test1"), new DealDto("", "Pawn.Test1"),
//					new DealDto("", "PawnDoc.Test2"));
//			WB.log(tmp1, "DealDto");
//			var tmp2 = DealDto.getId(tmp1);
//			WB.addLog2("Pawn.test.getId(List<DealDto> listDealDto):List<String>, res=" + tmp2, "", "DealDto");

		} catch (Exception ex) {
			WB.addLog("DealDto.test():void, ex=" + ex.getMessage(), "", "DealDto");
		}
	}
}