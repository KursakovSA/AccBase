import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public final class DealDto {
	// origin - 01.03.2025, last edit - 10.09.2026
	public String id, table, parent, date1, date2, code, description, more;
	public String face1, face2, face, geo, role, info, mark;
	// special fields
	public String fullName, comment;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("DealDto.static ctor, ex=" + ex.getMessage(), "", "DealDto");
		}
	}

	private void fix() throws Exception {
		// origin - 02.05.2026, last edit - 10.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}

			this.date1 = DefVal.set(this.date1, WB.minDateSupported.toString());
			this.date2 = DefVal.set(this.date2, WB.maxDateSupported.toString());
			this.mark = DefVal.set(this.mark, "Mark.DD");
		} catch (Exception ex) {
			WB.addLog("DealDto.fix():void, ex=" + ex.getMessage(), "", "DealDto");
		}
	}

	private void validate() throws Exception {
		// origin - 14.10.2026, last edit - 14.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}
		} catch (Exception ex) {
			WB.addLog("DealDto.validate():void, ex=" + ex.getMessage(), "", "DealDto");
		}
	}

	public static List<DealDto> get(List<FullDto> listFullDto) throws Exception {
		// origin - 22.05.2025, last edit - 13.06.2025
		List<DealDto> res = new ArrayList<DealDto>();
		try {
			for (var currFullDto : listFullDto) {
				res.add(new DealDto(currFullDto));
			}
		} catch (Exception ex) {
			WB.addLog("DealDto.get(List<FullDto>):List<DealDto>, ex=" + ex.getMessage(), "", "DealDto");
		}
		return res;
	}

	public static List<DealDto> getChrono(LocalDate calcDate, List<DealDto> listDealDto) throws Exception {
		// origin - 22.05.2025, last edit - 02.05.2026
		List<DealDto> res = new ArrayList<DealDto>();
		LocalDate currDate1;
		LocalDate currDate2;
		try {
			for (var currDto : listDealDto) {
				currDto.fix();
				currDate1 = DateTool.getLocalDate(currDto.date1);// left border in data
				currDate2 = DateTool.getLocalDate(currDto.date2);// right border in data

				// left border hit or right border hit
				if ((Etc.strEquals(currDate1.toString(), calcDate.toString()))
						|| (Etc.strEquals(currDate2.toString(), calcDate.toString()))) {
					res.add(currDto);
					continue;
				}

				// range from left border to right border hit
				if ((currDate1.isBefore(calcDate)) && (currDate2.isAfter(calcDate))) {
					res.add(currDto);
					continue;
				}
			}
		} catch (Exception ex) {
			WB.addLog("DealDto.getChrono(LocalDate, List<DealDto>):List<DealDto>, ex=" + ex.getMessage(), "",
					"DealDto");
		}
		return res;
	}

	private void isExist() throws Exception {
		// origin - 25.05.2025, last edit - 09.10.2026
		try {
			List<FullDto> listDto = new ArrayList<FullDto>();

			if (this.id.isEmpty() == false) {
				listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), "Deal");
			}

			if (this.code.isEmpty() == false) {
				listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getCodeFilter(this.code), "Deal");
			}

			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.id = DefVal.setCustom(this.id, dto.id);
				this.parent = DefVal.setCustom(this.parent, dto.parent);
				this.face1 = DefVal.setCustom(this.face1, dto.face1);
				this.face2 = DefVal.setCustom(this.face2, dto.face2);
				this.face = DefVal.setCustom(this.face, dto.face);
				this.date1 = DefVal.setCustom(this.date1, dto.date1);
				this.date2 = DefVal.setCustom(this.date2, dto.date2);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.geo = DefVal.setCustom(this.geo, dto.geo);
				this.role = DefVal.setCustom(this.role, dto.role);
				this.info = DefVal.setCustom(this.info, dto.info);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.clear();
			}
		} catch (Exception ex) {
			WB.addLog("DealDto.isExist():void, ex=" + ex.getMessage(), "", "DealDto");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 07.06.2025, last edit - 03.10.2026
		try {
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
		} catch (Exception ex) {
			WB.addLog("DealDto.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Move");
		}
	}

	public DealDto(String Id, String Parent, String Face1, String Face2, String Face, String Date1, String Date2,
			String Code, String Description, String Geo, String Role, String Info, String More, String Mark)
			throws Exception {
		// origin - 01.03.2025, last edit - 14.10.2026
		this.clear();
		this.id = Id;
		this.face1 = Face1;
		this.face2 = Face2;
		this.face = Face;
		this.parent = Parent;
		this.date1 = Date1;
		this.date2 = Date2;
		this.code = Code;
		this.description = Description;
		this.geo = Geo;
		this.role = Role;
		this.info = Info;
		this.more = More;
		this.mark = Mark;
		this.getFieldFromMore();
		this.fix();
		this.validate();
	}

	public DealDto(FullDto fDto) throws Exception {
		// origin - 22.05.2025, last edit - 14.10.2026
		this.clear();
		this.id = fDto.id;
		this.parent = fDto.parent;
		this.face1 = fDto.face1;
		this.face2 = fDto.face2;
		this.face = fDto.face;
		this.date1 = fDto.date1;
		this.date2 = fDto.date2;
		this.code = fDto.code;
		this.description = fDto.description;
		this.geo = fDto.geo;
		this.role = fDto.role;
		this.info = fDto.info;
		this.more = fDto.more;
		this.mark = fDto.mark;
		this.getFieldFromMore();
		this.fix();
		this.validate();
	}

	public DealDto(String Id) throws Exception {
		// origin - 25.05.2025, last edit - 14.10.2026
		this.clear();
		this.id = Id;
		this.isExist();
		this.fix();
		this.validate();
	}

	private void clear() throws Exception {
		// origin - 01.03.2025, last edit - 10.09.2026
		try {
			this.table = "Deal";
			this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.more = "";
			this.face1 = this.face2 = this.face = this.geo = this.role = this.info = this.mark = "";
			this.comment = this.fullName = "";
		} catch (Exception ex) {
			WB.addLog("DealDto.clear():void, ex=" + ex.getMessage(), "", "DealDto");
		}
	}

	public DealDto() throws Exception {
		// origin - 01.03.2025, last edit - 01.03.2025
		this.clear();
	}

	public String toString() {
		// origin - 01.03.2025, last edit - 09.10.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("id ", this.id);
			res = res + Fmtr.addIfNotEmpty("table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 01.03.2025, last edit - 09.10.2026
		try {

//			WB.addLog2("DealDto.test.ctor(String)", "", "DealDto");
//			for (var tmp1 : new String[] { "Deal.Face.FA1.boss", "лс 000000", "лс 111111", "лс 000000, усл 100",
//					"лс 111111, усл 100", "Deal.tralala" }) {
//				WB.addLog2("DealDto.test.ctor(String)=" + new DealDto(tmp1) + ", tmp1=" + tmp1, "", "DealDto");
//			}

		} catch (Exception ex) {
			WB.addLog("DealDto.test():void, ex=" + ex.getMessage(), "", "DealDto");
		}
	}
}