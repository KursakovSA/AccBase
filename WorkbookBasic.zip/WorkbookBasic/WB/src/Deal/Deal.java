import java.util.ArrayList;
import java.util.List;

public final class Deal {
	// origin - 28.09.2023, last edit - 12.10.2026
	// common fields
	public String src, table, id, parent, date1, date2, face1, face2, face, code, description, geo, role, info, more,
			mark, defect;
	// special fields
	public String fullName, comment;
	public DealTerm dealTerm;
	public List<DealDto> moveList;
	public List<Prolongation> prolongationList;
	public List<FullDto> lowerList, upperList;
	public static List<String> nameList;
	public static List<String> roleList;

	static {
		try {
			Deal.nameList = List.of("TemplateId", "TermId", "DealId", "OutsideDealId", "Context");
			Deal.roleList = List.of("Role.Deal.Basic", "Role.Deal.Frame", "Role.Deal.AdditionalAgreement",
					"Role.Deal.Spec");
		} catch (Exception ex) {
			WB.addLog("Deal.static ctor, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	private boolean isDeal() throws Exception {
		// origin - 12.10.2026, last edit - 12.10.2026
		boolean res = true;
		try {
			if (Etc.strContainsOneTime(this.role, Deal.roleList) == false) {
				res = false;
			}
		} catch (Exception ex) {
			WB.addLog("Deal.isDeal():boolean, ex=" + ex.getMessage(), "", "Deal");
		}
		return res;
	}

//	private void addNameToMore() throws Exception {
//		// origin - 04.10.2026, last edit - 12.10.2026
//		try {
//			BasicDto bDto = new BasicDto("Deal", this.parent); // for parent.more
//			for (var currField : Deal.nameList) {
//				var tmp1 = MoreVal.getFieldByKey(this.more, currField);
//				if (tmp1.isEmpty()) {
//					var tmp2 = this.getName(bDto.more, currField);
//					if (tmp2.isEmpty() == false) {
//						this.more = MoreVal.reset(this.more, currField, tmp2);
//					}
//				}
//			}
//		} catch (Exception ex) {
//			WB.addLog("Deal.addNameToMore():void, ex=" + ex.getMessage(), "", "Deal");
//		}
//	}

	private String getName(String more, String field) throws Exception {
		// origin - 04.10.2026, last edit - 04.10.2026
		String res = "";
		try {
			if (more.isEmpty()) {
				return res;
			}
			if (field.isEmpty()) {
				return res;
			}

			if (Etc.strEquals(field, "DealId")) {
				var tmp = new NVal(this.code);
				return res = tmp.val.getFirst(); // ex. this.code="1234, YT-6574", that DealId=1234
			}

			if (Etc.strEquals(field, "OutsideDealId")) {
				var tmp = new NVal(this.code);
				return res = tmp.val.getLast(); // ex. this.code="1234, YT-6574", that OutsideDealId=YT-6574
			}

			var tmp = MoreVal.getFieldByKey(more, field);
			if (tmp.isEmpty() == false) {
				res = tmp;
			}
		} catch (Exception ex) {
			WB.addLog("Deal.getName(String):String, ex=" + ex.getMessage(), "", "Deal");
		}
		return res;
	}

	private void fix() throws Exception {
		// origin - 01.05.2026, last edit - 09.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}

			this.date1 = DefVal.set(this.date1, WB.minDateSupported.toString());
			this.date2 = DefVal.set(this.date2, WB.maxDateSupported.toString());
			this.mark = DefVal.set(this.mark, "Mark.DD");
		} catch (Exception ex) {
			WB.addLog("Deal.fix():void, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	public static FullDto getFullDtoByList(List<String> in) throws Exception {
		// origin - 02.03.2026, last edit - 02.03.2026
		FullDto res = new FullDto();
		try {
			res.table = "Deal";
			res.id = Etc.fixTrim(in.get(0));
			res.parent = Etc.fixTrim(in.get(1));
			res.face1 = Etc.fixTrim(in.get(2));
			res.face2 = Etc.fixTrim(in.get(3));
			res.face = Etc.fixTrim(in.get(4));
			res.date1 = Etc.fixTrim(in.get(5));
			res.date2 = Etc.fixTrim(in.get(6));
			res.code = Etc.fixTrim(in.get(7));
			res.description = Etc.fixTrim(in.get(8));
			res.geo = Etc.fixTrim(in.get(9));
			res.role = Etc.fixTrim(in.get(10));
			res.info = Etc.fixTrim(in.get(11));
			res.more = Etc.fixTrim(in.get(12));
			res.mark = Etc.fixTrim(in.get(13));
		} catch (Exception ex) {
			WB.addLog("Deal.getFullDtoByList(List<String>):FullDto, ex=" + ex.getMessage(), "", "Deal");
		}
		return res;
	}

	public static List<String> getListByFullDto(FullDto in) throws Exception {
		// origin - 31.01.2026, last edit - 01.03.2026
		List<String> res = new ArrayList<String>();
		try {
			res.add(in.id);
			res.add(in.parent);
			res.add(in.face1);
			res.add(in.face2);
			res.add(in.face);
			res.add(in.date1);
			res.add(in.date2);
			res.add(in.code);
			res.add(in.description);
			res.add(in.geo);
			res.add(in.role);
			res.add(in.info);
			res.add(in.more);
			res.add(in.mark);
		} catch (Exception ex) {
			WB.addLog("Deal.getByTable(FullDto):List<String>, ex=" + ex.getMessage(), "", "Deal");
		}
		return res;
	}

	public static List<FullDto> getMassReg(List<FullDto> listFace, int countPerFace) throws Exception { // TODO
		// origin - 30.09.2025, last edit - 30.09.2025
		List<FullDto> res = new ArrayList<FullDto>();
		try {
//			for (var curr : listFace) {
//				for (int i = 1; i <= countPerFace; i++) {
//				}
//			}
		} catch (Exception ex) {
			WB.addLog("Deal.getMassReg(List<FullDto>, int):List<FullDto>, ex=" + ex.getMessage(), "", "Deal");
		}
		return res;
	}

	public static List<DealDto> getCurr(String date1, List<DealDto> listDealDto) throws Exception {
		// origin - 19.08.2025, last edit - 19.08.2025
		List<DealDto> res = new ArrayList<DealDto>();
		try {
			res = DealDto.getChrono(DateTool.getLocalDate(date1), listDealDto);
		} catch (Exception ex) {
			WB.addLog("Deal.getCurr(String, List<DealDto>):List<DealDto>, ex=" + ex.getMessage(), "", "Deal");
		}
		return res;
	}

	public static List<DealDto> getCurrByParent(String date1, String parentId) throws Exception {
		// origin - 03.09.2025, last edit - 03.09.2025
		List<DealDto> res = new ArrayList<DealDto>();
		try {
			var listDealDto = Deal.getByParent(parentId);
			res = DealDto.getChrono(DateTool.getLocalDate(date1), listDealDto);
		} catch (Exception ex) {
			WB.addLog("Deal.getCurrByParent(2String):List<DealDto>, ex=" + ex.getMessage(), "", "Deal");
		}
		return res;
	}

	public static List<DealDto> getByParent(String parentId) throws Exception {
		// origin - 19.08.2025, last edit - 19.08.2025
		List<DealDto> res = new ArrayList<DealDto>();
		try {
			var dealList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentFilter(parentId), "Deal");
			if (dealList.size() != 0) {
				for (var curr : dealList) {
					var currDealDto = new DealDto(curr.id, curr.parent, curr.face1, curr.face2, curr.face, curr.date1,
							curr.date2, curr.code, curr.description, curr.geo, curr.role, curr.info, curr.more,
							curr.mark);
					if (currDealDto.code.isEmpty() == false) {
						res.add(currDealDto);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Deal.getByParent(String):List<DealDto>, ex=" + ex.getMessage(), "", "Deal");
		}
		return res;
	}

	public static List<DealDto> getByRole(String role) throws Exception {
		// origin - 16.08.2025, last edit - 16.08.2025
		List<DealDto> res = new ArrayList<DealDto>();
		try {
			var dealList = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter(role), "Deal");
			res = DealDto.get(dealList);
		} catch (Exception ex) {
			WB.addLog("Deal.getByRole(String):List<DealDto>, ex=" + ex.getMessage(), "", "Deal");
		}
		return res;
	}

	private void validate() throws Exception {
		// origin -22.11.2025, last edit - 12.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}
			
			this.defect = Fmtr.addIfStrEmpty(this.defect, MoreVal.getFieldByKey(this.more, "TemplateId"),
					"empty templateId; ");
		} catch (Exception ex) {
			WB.addLog("Deal.validate():void, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	private void getByTemplate() throws Exception {
		// origin - 14.08.2025, last edit - 11.09.2026
		try {
			this.id = new IdGen("", "").id;
			this.date1 = DateTool.getNow().toString();
			this.code = new IdGen("DealId", "idIntegerGrowingDigitalGlobal").id; // ?? tuner frm local ??;
			this.description = "";
			this.more = this.getMoreFromField();
			this.mark = "Mark.DD";
			this.moveList.clear(); // or copy from template ??
		} catch (Exception ex) {
			WB.addLog2("Deal.getByTemplate():void, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	private void isExist() throws Exception {
		// origin - 18.09.2024, last edit - 12.10.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), "Deal");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.id = dto.id;
				this.parent = DefVal.setCustom(this.parent, dto.parent);
				this.date1 = DefVal.setCustom(this.date1, dto.date1);
				this.date2 = DefVal.setCustom(this.date2, dto.date2);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.geo = DefVal.setCustom(this.geo, dto.geo);
				this.role = DefVal.setCustom(this.role, dto.role);
				this.info = DefVal.setCustom(this.info, dto.info);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.mark = DefVal.setCustom(this.mark, dto.mark);
				this.upperList = FullDto.getUpper(this.table, this.parent);
				this.lowerList = FullDto.getLower(this.table, this.id);
				this.getFieldFromMore();
			}

			if (this.isDeal() == false) {
				this.clear();
			}

			if (listDto.size() == 0) {
				this.clear();
			}
		} catch (Exception ex) {
			WB.addLog("Deal.isExist():void, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	private String getMoreFromField() throws Exception {
		// origin - 11.08.2025, last edit - 12.09.2026
		String res = "";
		try {
			res = res + MoreVal.setPart("FullName", this.fullName);
			res = res + MoreVal.setPart("Comment", this.comment);
		} catch (Exception ex) {
			WB.addLog("Deal.getMoreFromField():String, ex=" + ex.getMessage(), "", "Deal");
		}
		return res;
	}

	private void getFieldFromMore() throws Exception {
		// origin - 11.08.2025, last edit - 04.10.2026
		try {
			// this.addNameToMore();
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.dealTerm = new DealTerm(MoreVal.getFieldByKey(this.more, "TermId"));
		} catch (Exception ex) {
			WB.addLog("Deal.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	private void getPart() throws Exception {
		// origin - 14.08.2025, last edit - 05.09.2026
		try {
			if (this.id.isEmpty() == false) {
				this.moveList = Move.getByParentRole(this.id);
				this.prolongationList = Prolongation.getByParent(this.id);
			}
		} catch (Exception ex) {
			WB.addLog("Deal.getPart():void, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	private boolean isTemplate() throws Exception {
		// origin - 09.09.2026, last edit - 12.10.2026
		boolean res = false;
		try {
			if (this.id.isEmpty()) {
				return res = false;
			}

			var tmp = MoreVal.getFieldByKey(this.more, "TemplateId");
			if ((tmp.isEmpty() == false) && (Etc.strEquals(this.mark, "Mark.MD"))) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("Deal.isTemplate():boolean, ex=" + ex.getMessage(), "", "Deal");
		}
		return res;
	}

	public Deal(DealDto dDto) throws Exception { // TODO
		// origin - 16.08.2025, last edit - 01.05.2026
		this.clear();
		this.date1 = dDto.date1;
		this.date2 = dDto.date2;
		this.code = dDto.code;
		this.id = dDto.id;
		this.description = dDto.description;
		this.geo = dDto.geo;
		this.role = dDto.role;
		this.info = dDto.info;
		this.more = dDto.more;
		this.mark = dDto.mark;
		this.getFieldFromMore();
		this.fix();
		this.validate();
	}

	public Deal(String Id) throws Exception {
		// origin - 11.08.2025, last edit - 09.09.2026
		this.clear();
		this.src = this.id = Id;
		this.isExist();
		this.getPart();
		if (this.isTemplate()) {
			this.getByTemplate();
		}
		this.fix();
		this.validate();
	}

	public Deal() throws Exception {
		// origin - 05.12.2023, last edit - 25.11.2024
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 25.11.2024, last edit - 10.09.2026
		try {
			this.table = "Deal";
			this.src = this.id = this.parent = this.date1 = this.date2 = this.face1 = this.face2 = this.face = this.code = this.description = this.geo = this.role = this.info = this.more = this.mark = "";
			this.fullName = this.comment = this.defect = "";
			this.lowerList = new ArrayList<FullDto>();
			this.upperList = new ArrayList<FullDto>();
			this.moveList = new ArrayList<DealDto>();
			this.prolongationList = new ArrayList<Prolongation>();
			this.dealTerm = new DealTerm();
		} catch (Exception ex) {
			WB.addLog("Deal.clear():void, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	public String toString() {
		// origin - 24.11.2023, last edit - 11.09.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", dealTerm ", this.dealTerm);
			res = res + Fmtr.addAnyway(", upperList ", this.upperList.size());
			res = res + Fmtr.addAnyway(", lowerList ", this.lowerList.size());
			res = res + Fmtr.addIfNotEmpty(", moveList ", this.moveList.size());
			res = res + Fmtr.addIfNotEmpty(", prolongationList ", this.prolongationList.size());
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 08.10.2026
		try {

			WB.addLog2("Deal.test.getName(2String):String", "", "Deal");
			for (var tmp1 : new String[] { "", "лс 000000", "лс 111111", "лс 000000, усл 100", "лс 111111, усл 100" }) {
				for (var tmp2 : Deal.nameList) {
					var tmp3 = new Deal(tmp1);
					WB.addLog2("Deal.test.getName(2String):String, res=" + tmp3.getName(tmp3.more, tmp2) + ", tmp1="
							+ tmp1 + ", tmp2=" + tmp2, "", "Deal");
				}
			}

//			WB.addLog2("Deal.test.getByParent(String):List<DealDto>", "", "Deal");
//			for (var tmp1 : new String[] { "Deal.Test1", "Deal.Tralala" }) {
//				var tmp = Deal.getByParent(tmp1);
//				WB.addLog2("Deal.test.getByParent(String):List<DealDto>, res.size=" + tmp.size() + ", role=" + tmp1, "",
//						"Deal");
//				WB.log(tmp, "DealDto");
//			}

//			WB.addLog2("Deal.test.getByRole(String):List<DealDto>", "", "Deal");
//			for (var tmp1 : new String[] { "Role.Deal.Basic", "Role.Deal.Tralala" }) {
//				var tmp = Deal.getByRole(tmp1);
//				WB.addLog2("Deal.test.getByRole(String):List<DealDto>, res.size=" + tmp.size() + ", role=" + tmp1, "",
//						"Deal");
//				WB.log(tmp, "DealDto");
//			}

			WB.addLog2("Deal.test.ctor(String)", "", "Deal");
			for (var tmp1 : new String[] { "Deal.Face.FA1.boss", "лс 000000", "лс 111111", "лс 000000, усл 100",
					"лс 111111, усл 100", "Deal.tralala" }) {
				WB.addLog2("Deal.test.ctor(String)=" + new Deal(tmp1) + ", tmp1=" + tmp1, "", "Deal");
			}

//			WB.addLog2("Deal new IdGen", "", "Deal");
//			WB.addLog2("Deal new IdGen('', ''), res=" + new IdGen("", "").id, "", "Face");
//			WB.addLog2("Deal new IdGen('DealId', ''), res=" + new IdGen("DealId", "").id, "", "Deal");
//			WB.addLog2("Deal new IdGen('DealId', 'idStringGrowingDigitalInfobase'), res="
//					+ new IdGen("DealId", "idStringGrowingDigitalInfobase").id, "", "Deal");
//			WB.addLog2("Deal new IdGen('DealId', 'idStringGrowingDigitalGlobal'), res="
//					+ new IdGen("DealId", "idStringGrowingDigitalGlobal").id, "", "Deal");
//			WB.addLog2("Deal new IdGen('DealId', 'idIntegerGrowingDigitalGlobal'), res="
//					+ new IdGen("DealId", "idIntegerGrowingDigitalGlobal").id, "", "Deal");

		} catch (Exception ex) {
			WB.addLog("Deal.test():void, ex=" + ex.getMessage(), "", "Deal");
		}
	}
}