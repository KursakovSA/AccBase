import java.util.ArrayList;
import java.util.List;

public class Deal {
	// origin - 28.09.2023, last edit - 16.08.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String src, table, id, parent, date1, date2, face1, face2, face, code, description, geo, role, info, more,
			mark;
	// special fields
	public String fullName, comment;
	public String dealId, outsideDealId, templateId;
	public ListVal templateDoc, additionalAgreement;
	public List<DealDto> move;
	public List<ModelDto> lower, upper;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Deal.static ctor, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	public static List<DealDto> getCurr(String date1, List<DealDto> listDealDto) throws Exception {
		// origin - 19.08.2025, last edit - 19.08.2025
		List<DealDto> res = new ArrayList<DealDto>();
		try {
			res = DealDto.getChrono(DateTool.getLocalDate(date1), listDealDto);
		} catch (Exception ex) {
			WB.addLog("Deal.getCurr(String, List<DealDto>):List<DealDto>, ex=" + ex.getMessage(), "", "Deal");
		}
		return res;
	}

	public static List<DealDto> getByParent(String parentId) throws Exception {
		// origin - 19.08.2025, last edit - 19.08.2025
		List<DealDto> res = new ArrayList<DealDto>();
		try {
			var dealList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentFilter(parentId), "Deal");
			if (dealList.size() != 0) {
				for (var curr : dealList) {
					var currDealDto = new DealDto(curr.id, curr.parent, curr.face1, curr.face2, curr.face, curr.date1,
							curr.date2, curr.code, curr.description, curr.geo, curr.role, curr.info, curr.more,
							curr.mark);
					if (currDealDto.code.isEmpty() == false) {
						res.add(currDealDto);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Deal.getByParent(String):List<Pawn>, ex=" + ex.getMessage(), "", "Deal");
		}
		return res;
	}

	// full list deal for selected role
	public static List<DealDto> getByRole(String role) throws Exception {
		// origin - 16.08.2025, last edit - 16.08.2025
		List<DealDto> res = new ArrayList<DealDto>();
		try {
			var dealList = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter(role), "Deal");
			res = DealDto.get(dealList);
		} catch (Exception ex) {
			WB.addLog("Deal.getByRole(String):List<DealDto>, ex=" + ex.getMessage(), "", "Deal");
		}
		return res;
	}

	public void getByTemplate() throws Exception {
		// origin - 14.08.2025, last edit - 16.08.2025
		try {
			this.id = new IdGen("", "").id;
			this.date1 = DateTool.getNow().toString();
			this.date2 = "";
			this.code = "";
			this.description = "";
			this.more = this.getMoreFromField();
			this.mark = Mark.DD;

			this.dealId = new IdGen("DealId", "idIntegerGrowingDigitalGlobal").id; // ?? tuner frm local ??
			this.move.clear(); // or copy from template ??
		} catch (Exception ex) {
			WB.addLog2("Deal.getByTemplate():void, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	public void isExist() throws Exception {
		// origin - 18.09.2024, last edit - 16.08.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), "Deal");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.id = dto.id;
				this.parent = DefVal.setCustom(this.parent, dto.parent);
				this.date1 = DefVal.setCustom(this.date1, dto.date1);
				this.date2 = DefVal.setCustom(this.date2, dto.date2);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.code = DefVal.setCustom(this.code, dto.id);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.geo = DefVal.setCustom(this.geo, dto.geo);
				this.role = DefVal.setCustom(this.role, dto.role);
				this.info = DefVal.setCustom(this.info, dto.info);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.mark = DefVal.setCustom(this.mark, dto.mark);

				var listDto2 = DAL.getTable(WB.lastConnWork, Qry.getText(WB.lastConnWork, "Deal", ""));
				this.upper = ModelDto.getUpper(listDto2, this.parent);
				this.lower = ModelDto.getLower(listDto2, this.code);

				this.getFieldFromMore();

				this.isExist = true;
			}
			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("Deal.isExist():void, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	private String getMoreFromField() throws Exception {
		// origin - 11.08.2025, last edit - 16.08.2025
		String res = "";
		try {
			res = res + MoreVal.setPartMore("FullName", this.fullName);
			res = res + MoreVal.setPartMore("Comment", this.comment);
			res = res + MoreVal.setPartMore("TemplateId", this.templateId);
			res = res + MoreVal.setPartMore("DealId", this.dealId);
			res = res + MoreVal.setPartMore("OutsideDealId", this.outsideDealId);
			// res = res + MoreVal.setPartMore("AdditionalAgreement",
			// this.additionalAgreement); //???
		} catch (Exception ex) {
			WB.addLog("Deal.getMoreFromField():String, ex=" + ex.getMessage(), "", "Deal");
		}
		return res;
	}

	private void getFieldFromMore() throws Exception {
		// origin - 11.08.2025, last edit - 16.08.2025
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.templateId = MoreVal.getFieldByKey(this.more, "TemplateId");
			this.dealId = MoreVal.getFieldByKey(this.more, "DealId");
			this.outsideDealId = MoreVal.getFieldByKey(this.more, "OutsideDealId");
			this.templateDoc = new ListVal(MoreVal.getFieldByKey(this.more, "TemplateDoc"), "");
			this.additionalAgreement = new ListVal(MoreVal.getFieldByKey(this.more, "AdditionalAgreement"), "");
		} catch (Exception ex) {
			WB.addLog("Deal.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	private void getPart() throws Exception {
		// origin - 14.08.2025, last edit - 14.08.2025
		try {
			if (this.id.isEmpty() == false) {
				this.move = Move.get(this.id);
			}
		} catch (Exception ex) {
			WB.addLog("Deal.getPart():void, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	public Deal(DealDto dDto) throws Exception { // TODO
		// origin - 16.08.2025, last edit - 16.08.2025
		this.clear();
		this.date1 = dDto.date1;
		this.date2 = dDto.date2;
		this.code = dDto.code;
		this.id = dDto.id;
		this.description = dDto.description;
		this.geo = dDto.geo;
		this.role = dDto.role;
		this.info = dDto.info;
		this.more = dDto.more;
		this.mark = dDto.mark;
		this.getFieldFromMore();
	}

	public Deal(String Id) throws Exception {
		// origin - 11.08.2025, last edit - 12.08.2025
		this.clear();
		this.src = this.id = Id;
		this.isExist();
		this.getPart();
		if (this.templateId.isEmpty() == false) {
			this.getByTemplate();
		}
	}

	public Deal() throws Exception {
		// origin - 05.12.2023, last edit - 25.11.2024
		this.clear();
	}

	public void clear() throws Exception {
		// origin - 25.11.2024, last edit - 16.08.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = "Deal";
			this.src = this.id = this.parent = this.date1 = this.date2 = this.face1 = this.face2 = this.face = this.code = this.description = this.geo = this.role = this.info = this.more = this.mark = "";
			this.fullName = this.comment = "";
			this.lower = new ArrayList<ModelDto>();
			this.upper = new ArrayList<ModelDto>();
			this.templateDoc = this.additionalAgreement = new ListVal();
			this.dealId = this.outsideDealId = this.templateId = "";
			this.move = new ArrayList<DealDto>();
		} catch (Exception ex) {
			WB.addLog("Deal.clear():void, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	public String toString() {
		// origin - 24.11.2023, last edit - 16.08.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = res + Fmtr.addIfNotEmpty(" dealId ", this.dealId);
			res = res + Fmtr.addIfNotEmpty(" outsideDealId ", this.outsideDealId);
			res = res + Fmtr.addIfNotEmpty(" templateId ", this.templateId);

			res = res + Fmtr.addIfNotEmpty(" templateDoc ", this.templateDoc.id);
			res = res + Fmtr.addIfNotEmpty(" additionalAgreement ", this.additionalAgreement.id);

			res = res + Fmtr.addAnyway(" upper ", this.upper.size());
			res = res + Fmtr.addAnyway(" lower ", this.lower.size());

			res = res + Fmtr.addIfNotEmpty(" move ", this.move.size());

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 19.08.2025
		try {

//			WB.addLog2("Deal.test.getByParent(String):List<DealDto>", "", "Deal");
//			for (var tmp1 : new String[] { "PawnDoc.Template1.V1", "Deal.Test1", "Deal.Tralala" }) {
//				var tmp = Deal.getByParent(tmp1);
//				WB.addLog2("Deal.test.getByParent(String):List<DealDto>, res.size=" + tmp.size() + ", role=" + tmp1, "",
//						"Deal");
//				WB.log(tmp, "DealDto");
//			}

//			WB.addLog2("Deal.test.getByRole(String):List<DealDto>", "", "Deal");
//			for (var tmp1 : new String[] { "Role.Deal.Basic", "Role.Deal.PawnDoc", "Role.Deal.Tralala" }) {
//				var tmp = Deal.getByRole(tmp1);
//				WB.addLog2("Deal.test.getByRole(String):List<DealDto>, res.size=" + tmp.size() + ", role=" + tmp1, "",
//						"Deal");
//				WB.log(tmp, "DealDto");
//			}

//			WB.addLog2("Deal.test.ctor(String)", "", "Deal");
//			for (var tmp1 : new String[] { "PawnDoc.Template1.V1", "Deal.Face.FA1.boss", "PawnDoc.Test1",
//					"PawnDoc.Catalog", "Deal.tralala" }) {
//				WB.addLog2("Deal.test.ctor(String)=" + new Deal(tmp1), "", "Deal");
//			}

//			WB.addLog2("Deal new IdGen", "", "Deal");
//			WB.addLog2("Deal new IdGen('', ''), res=" + new IdGen("", "").id, "", "Face");
//			WB.addLog2("Deal new IdGen('DealId', ''), res=" + new IdGen("DealId", "").id, "", "Deal");
//			WB.addLog2("Deal new IdGen('DealId', 'idStringGrowingDigitalInfobase'), res="
//					+ new IdGen("DealId", "idStringGrowingDigitalInfobase").id, "", "Deal");
//			WB.addLog2("Deal new IdGen('DealId', 'idStringGrowingDigitalGlobal'), res="
//					+ new IdGen("DealId", "idStringGrowingDigitalGlobal").id, "", "Deal");
//			WB.addLog2("Deal new IdGen('DealId', 'idIntegerGrowingDigitalGlobal'), res="
//					+ new IdGen("DealId", "idIntegerGrowingDigitalGlobal").id, "", "Deal");
//			WB.addLog2("Deal new IdGen('PawnId', ''), res=" + new IdGen("PawnId", "").id, "", "Deal");
//			WB.addLog2("Deal new IdGen('PawnId', 'idStringGrowingDigitalInfobase'), res="
//					+ new IdGen("PawnId", "idStringGrowingDigitalInfobase").id, "", "Deal");
//			WB.addLog2("Deal new IdGen('PawnId', 'idStringGrowingDigitalGlobal'), res="
//					+ new IdGen("PawnId", "idStringGrowingDigitalGlobal").id, "", "Deal");
//			WB.addLog2("Deal new IdGen('PawnId', 'idIntegerGrowingDigitalGlobal'), res="
//					+ new IdGen("PawnId", "idIntegerGrowingDigitalGlobal").id, "", "Deal");

		} catch (Exception ex) {
			WB.addLog("Deal.test():void, ex=" + ex.getMessage(), "", "Deal");
		}
	}
}