import java.util.ArrayList;
import java.util.List;

public final class Deal {
	// origin - 28.09.2023, last edit - 26.10.2026
	// common fields
	public String src, table, id, parent, date1, date2, face1, face2, face, code, description, geo, role, info, more,
			mark, defect;
	// special fields
	public DurationTerm durationTerm;
	public TemplateDocTerm templateDocTerm;
	public AccrualTerm accrualTerm;
	public Term term;

	public List<DealDto> moveList;
	public List<Prolongation> prolongationList;

	public static List<String> roleList;

	static {
		try {
			Deal.roleList = List.of("Role.Deal.Basic", "Role.Deal.Frame", "Role.Deal.AdditionalAgreement",
					"Role.Deal.Spec");
		} catch (Exception ex) {
			WB.addLog("Deal.static ctor, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	private boolean isDealRole() throws Exception {
		// origin - 12.10.2026, last edit - 25.10.2026
		boolean res = true;
		try {
			if (Etc.strNotContains(this.role, Deal.roleList)) {
				res = false;
			}
		} catch (Exception ex) {
			WB.addLog("Deal.isDealRole():boolean, ex=" + ex.getMessage(), "", "Deal");
		}
		return res;
	}

	private void addNameToMoreByParent() throws Exception {
		// origin - 04.10.2026, last edit - 02.11.2026
		try {
			if (Etc.strNotValid(this.parent)) {
				return;
			}

			BasicDto bDto = new BasicDto("Deal", this.parent); // for parent.more
			for (var currField : NameVar.getListByClass("Deal")) {
				var tmp1 = MoreVal.getFieldByKey(this.more, currField);
				if (tmp1.isEmpty()) {
					var tmp2 = MoreVal.getFieldByKey(bDto.more, currField);
					if (tmp2.isEmpty() == false) {
						this.more = MoreVal.reset(this.more, currField, tmp2);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Deal.addNameToMore():void, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	public String getValName(String field) throws Exception {
		// origin - 04.10.2026, last edit - 25.10.2026
		String res = "";
		try {
			if (Etc.strNotValid(field)) {
				return res;
			}

			if (Etc.strEquals(field, "DealId")) {
				var tmp = new NVal(this.code);
				return res = tmp.val.getFirst(); // ex. this.code="1234, YT-6574", that DealId=1234
			}

			if (Etc.strEquals(field, "OutsideDealId")) {
				var tmp = new NVal(this.code);
				return res = tmp.val.getLast(); // ex. this.code="1234, YT-6574", that OutsideDealId=YT-6574
			}

			res = BasicDto.getValName(this.more, field);
		} catch (Exception ex) {
			WB.addLog("Deal.getValName(String):String, ex=" + ex.getMessage(), "", "Deal");
		}
		return res;
	}

	private void fix() throws Exception {
		// origin - 01.05.2026, last edit - 09.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}

			this.date1 = DefVal.set(this.date1, WB.minDateSupported.toString());
			this.date2 = DefVal.set(this.date2, WB.maxDateSupported.toString());
			this.mark = DefVal.set(this.mark, "Mark.DD");
		} catch (Exception ex) {
			WB.addLog("Deal.fix():void, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	public static FullDto getFullDtoByList(List<String> in) throws Exception { // for CSV
		// origin - 02.03.2026, last edit - 02.03.2026
		FullDto res = new FullDto();
		try {
			res.table = "Deal";
			res.id = Etc.fixTrim(in.get(0));
			res.parent = Etc.fixTrim(in.get(1));
			res.face1 = Etc.fixTrim(in.get(2));
			res.face2 = Etc.fixTrim(in.get(3));
			res.face = Etc.fixTrim(in.get(4));
			res.date1 = Etc.fixTrim(in.get(5));
			res.date2 = Etc.fixTrim(in.get(6));
			res.code = Etc.fixTrim(in.get(7));
			res.description = Etc.fixTrim(in.get(8));
			res.geo = Etc.fixTrim(in.get(9));
			res.role = Etc.fixTrim(in.get(10));
			res.info = Etc.fixTrim(in.get(11));
			res.more = Etc.fixTrim(in.get(12));
			res.mark = Etc.fixTrim(in.get(13));
		} catch (Exception ex) {
			WB.addLog("Deal.getFullDtoByList(List<String>):FullDto, ex=" + ex.getMessage(), "", "Deal");
		}
		return res;
	}

	public static List<String> getListByFullDto(FullDto in) throws Exception { // for CSV
		// origin - 31.01.2026, last edit - 01.03.2026
		List<String> res = new ArrayList<String>();
		try {
			res.add(in.id);
			res.add(in.parent);
			res.add(in.face1);
			res.add(in.face2);
			res.add(in.face);
			res.add(in.date1);
			res.add(in.date2);
			res.add(in.code);
			res.add(in.description);
			res.add(in.geo);
			res.add(in.role);
			res.add(in.info);
			res.add(in.more);
			res.add(in.mark);
		} catch (Exception ex) {
			WB.addLog("Deal.getByTable(FullDto):List<String>, ex=" + ex.getMessage(), "", "Deal");
		}
		return res;
	}

	public static List<FullDto> getMassReg(List<FullDto> listFace, int countPerFace) throws Exception { // TODO
		// origin - 30.09.2025, last edit - 30.09.2025
		List<FullDto> res = new ArrayList<FullDto>();
		try {
//			for (var curr : listFace) {
//				for (int i = 1; i <= countPerFace; i++) {
//				}
//			}
		} catch (Exception ex) {
			WB.addLog("Deal.getMassReg(List<FullDto>, int):List<FullDto>, ex=" + ex.getMessage(), "", "Deal");
		}
		return res;
	}

	private void validate() throws Exception {
		// origin -22.11.2025, last edit - 25.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}

			this.defect = Fmtr.addIfStrEmpty(this.defect, MoreVal.getFieldByKey(this.more, "TemplateId"),
					"empty templateId; ");
			this.defect = Fmtr.addIfStrNotEmpty(this.defect, this.term.defect, "defect term; ");
			this.defect = Fmtr.addIfStrNotEmpty(this.defect, this.durationTerm.defect, "defect duration; ");
			this.defect = Fmtr.addIfStrNotEmpty(this.defect, this.templateDocTerm.defect, "defect templateDoc; ");
			this.defect = Fmtr.addIfStrNotEmpty(this.defect, this.accrualTerm.defect, "defect accrual; ");
		} catch (Exception ex) {
			WB.addLog("Deal.validate():void, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	private void getByTemplate() throws Exception {
		// origin - 14.08.2025, last edit - 25.10.2026
		try {
			this.id = new IdGen("", "").id;
			this.date1 = DateTool.getNow().toString();
			this.code = new IdGen("DealId", "idIntegerGrowingDigitalGlobal").id; // ?? tuner frm local ??;
			this.description = "";
			this.setMoreByTemplate();
			this.mark = "Mark.DD";
			this.moveList.clear();
			this.prolongationList.clear();
		} catch (Exception ex) {
			WB.addLog2("Deal.getByTemplate():void, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	private void isExist() throws Exception {
		// origin - 18.09.2024, last edit - 25.10.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.id), "Deal");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.id = dto.id;
				this.parent = DefVal.setCustom(this.parent, dto.parent);
				this.date1 = DefVal.setCustom(this.date1, dto.date1);
				this.date2 = DefVal.setCustom(this.date2, dto.date2);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.geo = DefVal.setCustom(this.geo, dto.geo);
				this.role = DefVal.setCustom(this.role, dto.role);
				this.info = DefVal.setCustom(this.info, dto.info);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.mark = DefVal.setCustom(this.mark, dto.mark);
			}

			if (this.isDealRole() == false) {
				this.clear();
			}

			if (listDto.size() == 0) {
				this.clear();
			}
		} catch (Exception ex) {
			WB.addLog("Deal.isExist():void, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	public void resetMoreByPartList(List<String> inList) throws Exception {
		// origin - 25.10.2026, last edit - 25.10.2026
		try {
			if (Etc.strNotValid(this.more)) {
				return;
			}
			var tmpMore = this.more;
			for (var curr : inList) { // inList is "FullName=килограмм" etc.
				var name = MoreVal.getNameByPart(curr);
				if (Etc.strNotContains(name, NameVar.getListByClass("Deal"))) {
					continue;
				}
				var val = MoreVal.getValueByPart(curr);
				if (Etc.strNotValid(name, val)) {
					continue;
				}
				tmpMore = MoreVal.resetPart(tmpMore, MoreVal.setPart(name, val));
			}
			this.more = tmpMore;
		} catch (Exception ex) {
			WB.addLog("Deal.resetMoreByPartList(List<String>):String, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	private void setMoreByTemplate() throws Exception {
		// origin - 25.10.2026, last edit - 02.11.2026
		try {
			this.addNameToMoreByParent();
			this.more = MoreVal.resetByVarList(this.more, NameVar.getListByClass("Deal"));
		} catch (Exception ex) {
			WB.addLog("Deal.setMoreByTemplate():String, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	private void getPart() throws Exception {
		// origin - 14.08.2025, last edit - 01.11.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}

			this.term = new Term(this.id);
			this.durationTerm = new DurationTerm(this.id);
			this.templateDocTerm = new TemplateDocTerm(this.id);
			this.accrualTerm = new AccrualTerm(this.id);
			this.moveList = Move.getByParentRole(this.id, Move.roleList.getFirst());
			this.prolongationList = Prolongation.getByParentRole(this.id, Prolongation.roleList.getFirst());
		} catch (Exception ex) {
			WB.addLog("Deal.getPart():void, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	private boolean isTemplate() throws Exception {
		// origin - 09.09.2026, last edit - 01.11.2026
		boolean res = false;
		try {
			if (this.id.isEmpty()) {
				return res = false;
			}

			var tmp = BasicDto.getValName(this.more, "TemplateId");// MoreVal.getFieldByKey(this.more, "TemplateId");
			if (Etc.strNotValid(tmp, this.mark)) {
				return res;
			}
			if (Etc.strEquals(this.mark, "Mark.MD")) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("Deal.isTemplate():boolean, ex=" + ex.getMessage(), "", "Deal");
		}
		return res;
	}

	public Deal(String Id) throws Exception {
		// origin - 11.08.2025, last edit - 15.10.2026
		this.clear();
		this.src = this.id = Id;
		this.isExist();
		this.getPart();
		if (this.isTemplate()) {
			this.getByTemplate();
		}
		this.fix();
		this.validate();
	}

	public Deal() throws Exception {
		// origin - 05.12.2023, last edit - 25.11.2024
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 25.11.2024, last edit - 25.10.2026
		try {
			this.table = "Deal";
			this.src = this.id = this.parent = this.date1 = this.date2 = this.face1 = this.face2 = this.face = this.code = "";
			this.description = this.geo = this.role = this.info = this.more = this.mark = this.defect = "";
			this.moveList = new ArrayList<DealDto>();
			this.prolongationList = new ArrayList<Prolongation>();
			this.durationTerm = new DurationTerm();
			this.templateDocTerm = new TemplateDocTerm();
			this.accrualTerm = new AccrualTerm();
			this.term = new Term();
		} catch (Exception ex) {
			WB.addLog("Deal.clear():void, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	public String toString() {
		// origin - 24.11.2023, last edit - 26.10.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res
					+ Fmtr.addAnyway(", terms ", this.durationTerm.id.length() + "," + this.templateDocTerm.id.length()
							+ "," + this.accrualTerm.id.length() + "," + this.term.id.length());
			res = res + Fmtr.addAnyway(", move, prolong=", this.moveList.size() + "," + this.prolongationList.size());
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 25.10.2026
		try {

//			WB.addLog2("Deal.test.resetMoreByPartList(List<String>):String", "", "Deal");
//			for (var tmp1 : new String[] { "", "FullName=литр;", "FullName=килограмм;BillingCycle=1000.00(Unit.Gr);",
//					"BillingCycle=1000.00(Unit.Gr);FullName=килограмм;" }) {
//				for (var tmp2 : new String[] { "", "FullName=100 грамм;",
//						"FullName=услуга;BillingCycle=999.00(Unit.Gr);",
//						"BillingCycle=999.00(Unit.Gr);FullName=услуга;", "MKEI=800;Lenght=1870.00(Unit.Meter);",
//						"Tralala=метр;" }) {
//					var tmp3 = List.of(tmp2.split(";"));
//					var tmp4 = new Deal();
//					tmp4.more = tmp1;
//					tmp4.resetMoreByPartList(tmp3);
//					WB.addLog2("Deal.test.resetMoreByPartList(List<String>):String, tmp4.more=" + tmp4.more + ", tmp1="
//							+ tmp1 + ", tmp2=" + tmp2, "", "Deal");
//				}
//			}

//			WB.addLog2("Deal.test.getValName(2String):String", "", "Deal");
//			for (var tmp1 : new String[] { null, "", "лс 000000", "лс 111111", "лс 000000, усл 100",
//					"лс 111111, усл 100", "Deal.tralala" }) {
//				for (var tmp2 : Deal.nameList) {
//					var tmp3 = new Deal(tmp1);
//					WB.addLog2("Deal.test.getValName(2String):String, res=" + tmp3.getValName(tmp2) + ", tmp1=" + tmp1
//							+ ", tmp2=" + tmp2 + ", tmp3.more=" + tmp3.more, "", "Deal");
//				}
//			}

			WB.addLog2("Deal.test.ctor(String)", "", "Deal");
			for (var tmp1 : new String[] { null, "", "Deal.Face.FA1.boss", "лс 000000", "лс 111111",
					"лс 000000, усл 100", "лс 111111, усл 100", "Deal.tralala" }) {
				WB.addLog2("Deal.test.ctor(String)=" + new Deal(tmp1) + ", tmp1=" + tmp1, "", "Deal");
			}

		} catch (Exception ex) {
			WB.addLog("Deal.test():void, ex=" + ex.getMessage(), "", "Deal");
		}
	}
}