import java.util.List;

public class Item extends ModelDto {
	// origin - 06.12.2023, last edit - 20.12.2024

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Item.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Item");
		} finally {
			Etc.doNothing();
		}
	}

	public void isExist() throws Exception {
		// origin - 20.12.2024, last edit - 20.12.2024
		super.isExist();
		try {
			for (var currItem : WB.abcLast.item) {
				if (Etc.strEquals(currItem.id, this.id)) {
					this.date1 = DefVal.setCustom(DateTool.getNow().toString(), currItem.date1);// this.date1,
					this.date2 = DefVal.setCustom(this.date2, currItem.date2);
					this.code = DefVal.setCustom(this.code, currItem.code);
					this.parent = DefVal.setCustom(this.parent, currItem.parent);
					this.description = DefVal.setCustom(this.description, currItem.description);
					this.more = DefVal.setCustom(this.more, currItem.more);

					this.isExist = true;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Item.isExist, ex=" + ex.getMessage(), WB.strEmpty, "Item");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Item.isExist=" + this.isExist, WB.strEmpty,"Item");
	}

	public void isValid() throws Exception {
		// origin - 20.12.2024, last edit - 20.12.2024
		super.isValid();
		try {
			if (this.date1.isEmpty()) {
				this.isValid = false;
			}
		} catch (Exception ex) {
			WB.addLog("Sign.isValid, ex=" + ex.getMessage(), WB.strEmpty, "Sign");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Sign.isValid=" + this.isValid, WB.strEmpty,"Sign");
	}

	public Item(String Id) throws Exception {
		// origin - 06.12.2023, last edit - 27.12.2024
		this();
		this.src = Id;
		if (Id.isEmpty() == false) {
			this.id = this.code = Id;
		}
		// this.date1 = DateTool.getNow().toString();
		this.isExist();
		this.isValid();
	}

	public Item() throws Exception {
		// origin - 06.12.2023, last edit - 20.12.2024
		this.clear();
		this.isExist();
		var root = Abc.getRoot(this.table); // get root from WB.abcLast
		this.id = root.id;
		this.parent = root.parent;
		this.slice = root.slice;
		this.date1 = root.date1;
		this.date2 = root.date2;
		this.code = root.code;
		this.description = root.description;
		this.more = root.more;
	}

	public void clear() throws Exception {
		// origin - 20.12.2024, last edit - 20.12.2024
		try {
			super.clear();
			this.table = this.getClass().getName();
		} catch (Exception ex) {
			WB.addLog("Item.clear, ex=" + ex.getMessage(), WB.strEmpty, "Item");
		} finally {
			Etc.doNothing();
		}
	}

	public String toString() {
		// origin - 20.12.2024, last edit - 20.12.2024
		String res = WB.strEmpty;
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = WB.strBraceLeft + res + WB.strBraceRight;
		} catch (Exception ex) {
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	@SuppressWarnings("unused")
	public static void test() throws Exception {
		// origin - 06.12.2023, last edit - 27.12.2024
		try {
			var tmpList = List.of(WB.strEmpty, "Item.Advance", "Item.tralala", "Item.Impress");

//			// ctor (String Id)
//			for (var tmp : tmpList) {
//				WB.addLog2("Item.test.ctor(String)=" + new Item(tmp.id), WB.strEmpty, "Item");
//			}

		} catch (Exception ex) {
			WB.addLog("Item.test, ex=" + ex.getMessage(), WB.strEmpty, "Item");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Item.test end ", WB.strEmpty, "Item");
	}
}
