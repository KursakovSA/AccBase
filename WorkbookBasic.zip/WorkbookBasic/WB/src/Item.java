public class Item extends Model {
	// origin - 06.12.2023, last edit - 06.12.2023
	public static Item root;
	public Item parent;
    
    static {
		root = new Item("Item","Item","ItemData");
	}
    
    public Item(String Id, String Code, String Description) {
		// origin - 06.12.2023, last edit - 06.12.2023
		this.id = Id;
		this.code = Code;
		this.description = Description;
	}
    
    public Item() {
		// origin - 06.12.2023, last edit - 06.12.2023
	}
    
    public static void test() {
		// origin - 06.12.2023, last edit - 06.12.2023
    	Logger.add("Item.test, Item.root=" + Item.root, "", "Item");
	}
}
