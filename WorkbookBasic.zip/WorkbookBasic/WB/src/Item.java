public class Item extends Model {
	// origin - 06.12.2023, last edit - 06.07.2024
	public Item parent;

	public Item(String Id, String Code, String Description) throws Exception {
		// origin - 06.12.2023, last edit - 07.07.2024
		try {
			this.id = Id;
			this.code = Code;
			this.description = Description;
		} catch (Exception ex) {
			WB.addLog("Item.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Item");
		} finally {
			Etc.doNothing();
		}
	}

	public Item() throws Exception {
		// origin - 06.12.2023, last edit - 07.07.2024
		try {
		} catch (Exception ex) {
			WB.addLog("Item.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Item");
		} finally {
			Etc.doNothing();
		}
	}

	public static void test() throws Exception {
		// origin - 06.12.2023, last edit - 06.07.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Item.test, ex=" + ex.getMessage(), WB.strEmpty, "Item");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Item.test end ", WB.strEmpty, "Item");
	}
}
