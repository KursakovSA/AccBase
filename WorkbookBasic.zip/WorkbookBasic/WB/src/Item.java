public class Item extends ModelDto {
	// origin - 06.12.2023, last edit - 04.08.2024
	
	static {
		try {
		} catch (Exception ex) {
			WB.addLog("InOut.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "InOut");
		} finally {
			Etc.doNothing();
		}
	}

	public Item(String Id, String Code, String Description) throws Exception {
		// origin - 06.12.2023, last edit - 11.08.2024
		super(Id, Code, Description);
		this.table = this.getClass().getName();
	}

	public Item() throws Exception {
		// origin - 06.12.2023, last edit - 11.08.2024
		super();
		this.table = this.getClass().getName();
	}

	public static void test() throws Exception {
		// origin - 06.12.2023, last edit - 06.07.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Item.test, ex=" + ex.getMessage(), WB.strEmpty, "Item");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Item.test end ", WB.strEmpty, "Item");
	}
}
