import java.util.ArrayList;
import java.util.List;

public final class Bank {
	// origin - 24.03.2025, last edit - 09.12.2025
	// common fields
	public String table, src, id, parent, code, description, geo, role, info, mark, more, defect;
	// special fields
	public String fullName, comment;
	// special timestamp fields
	public ListVal date1, date2;
	// list common + special + timestamp fields in unified val
	public List<FaceDto> val;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Bank.static ctor, ex=" + ex.getMessage(), "", "Bank");
		}
	}

	// full list bankAccount
	public static List<BankAccount> getAccount() throws Exception {
		// origin - 26.10.2025, last edit - 11.12.2025
		List<BankAccount> res = new ArrayList<BankAccount>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter("Role.Store.Bank"), "Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					var currFaceBank = new Bank(currFace.parent, currFace.code);
					for (var curr : currFaceBank.val) {
						var tmp = BankAccount.getById(curr.id);
						if (tmp.defect.isEmpty()) {
							res.add(tmp);
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Bank.getAccount():List<BankAccount>, ex=" + ex.getMessage(), "", "Bank");
		}
		return res;
	}

	// full list bankAccount for parentId
	public static List<BankAccount> getAccount(String parentId) throws Exception {
		// origin - 04.05.2025, last edit - 11.12.2025
		List<BankAccount> res = new ArrayList<BankAccount>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, "Role.Store.Bank"),
					"Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					var currFaceBank = new Bank(currFace.parent, currFace.code);
					for (var curr : currFaceBank.val) {
						var tmp = BankAccount.getById(curr.id);
						if (tmp.defect.isEmpty()) {
							res.add(tmp);
						}
					}
				}
			}

			// default bankAccount (in more.bankAccount)
			var tmp1 = new FaceDto(parentId);
			var tmp2 = new BankAccount(tmp1.bankAccount);
			if (tmp2.defect.isEmpty()) {
				res.add(tmp2);
			}
		} catch (Exception ex) {
			WB.addLog("Bank.getAccount(String):List<BankAccount>, ex=" + ex.getMessage(), "", "Bank");
		}
		return res;
	}

	// full list bank on date1
	public static List<BankAccount> getCurrAccount(String date1, String parentId) throws Exception {
		// origin - 24.03.2025, last edit - 11.12.2025
		List<BankAccount> res = new ArrayList<BankAccount>();
		try {
			var faceList = DAL.getByTemplate(WB.lastConnWork, Qry.getParentRoleFilter(parentId, "Role.Store.Bank"),
					"Face");
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					var currFaceBank = new Bank(currFace.parent, currFace.code);
					var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceBank.val, "");
					if (curr.id.isEmpty() == false) {
						var tmp1 = new FaceDto(curr.id, curr.parent, curr.date1, curr.date2, curr.code,
								curr.description, curr.geo, curr.role, curr.info, curr.more, curr.mark);
						var tmp2 = new BankAccount(tmp1.bankAccount);
						if (tmp2.defect.isEmpty()) {
							res.add(tmp2);
						}
					}
				}
			}

			// default bankAccount (in more.bankAccount)
			var tmp1 = new FaceDto(parentId);
			var tmp2 = new BankAccount(tmp1.bankAccount);
			if (tmp2.defect.isEmpty()) {
				res.add(tmp2);
			}
		} catch (Exception ex) {
			WB.addLog("Bank.getCurrAccount(2String):List<BankAccount>, ex=" + ex.getMessage(), "", "Bank");
		}
		return res;
	}

	// item bank by IBAN on date1
	public static BankAccount getAccountByIBAN(String date1, String parentId, String IBAN) throws Exception {
		// origin - 25.03.2025, last edit - 11.12.2025
		BankAccount res = new BankAccount();
		try {
			var bankAccountList = Bank.getCurrAccount(date1, parentId);
			if (bankAccountList.size() != 0) {
				for (var currBankAccount : bankAccountList) {
					if (Etc.strEquals(currBankAccount.IBAN, IBAN)) {
						res = currBankAccount;
						break;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Bank.getAccountByIBAN(3String):BankAccount, ex=" + ex.getMessage(), "", "Bank");
		}
		return res;
	}

	// item bank on date1
	public static BankAccount getCurrAccount(String date1, String faceParentId, String faceBankId) throws Exception {
		// origin - 24.03.2025, last edit - 11.12.2025
		BankAccount res = new BankAccount();
		try {
			var currFaceBank = new Bank(faceParentId, faceBankId);
			if (currFaceBank.val.size() != 0) {
				var curr = FaceDto.getChrono(DateTool.getLocalDate(date1), currFaceBank.val, "");
				if (curr.id.isEmpty() == false) {
					var tmp = new BankAccount(curr.bankAccount);
					if (tmp.defect.isEmpty()) {
						res = tmp;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Bank.getCurrAccount(3String):BankAccount, ex=" + ex.getMessage(), "", "Bank");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 21.11.2025, last edit - 11.12.2025
		try {
			if (this.val.size() == 0) {
				this.defect = this.defect + "empty val; ";
			}
		} catch (Exception ex) {
			WB.addLog("Bank.validate():void, ex=" + ex.getMessage(), "", "Bank");
		}
	}

	private void getVal() throws Exception {
		// origin - 24.03.2025, last edit - 01.10.2025
		try {
			String currDate1 = "";
			String currDate2 = "";
			for (int i = 0; i < this.date1.val.size(); i++) {
				currDate1 = this.date1.getByIndex(i);
				currDate2 = this.date2.getByIndex(i);
				var tmp = new FaceDto(this.id, this.parent, currDate1, currDate2, this.code, this.description, this.geo,
						this.role, this.info, this.more, this.mark);
				this.val.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("Bank.getVal():void, ex=" + ex.getMessage(), "", "Bank");
		}
	}

	private void isExist() throws Exception {
		// origin - 24.03.2025, last edit - 09.12.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork,
					Qry.getParentCodeRoleFilter(this.parent, this.code, "Role.Store.Bank"), "Face");
			if (listDto.size() != 0) {
				var currDto = listDto.getFirst();
				var tmp = new SpanDate(currDto.date1, currDto.date2);
				this.date1 = new ListVal(tmp.date1);
				this.date2 = new ListVal(tmp.date2);
				this.id = DefVal.setCustom(this.id, currDto.id);
				this.parent = DefVal.setCustom(this.parent, currDto.parent);
				this.code = DefVal.setCustom(this.code, currDto.code);
				this.description = DefVal.setCustom(this.description, currDto.description);
				this.geo = DefVal.setCustom(this.geo, currDto.geo);
				this.role = DefVal.setCustom(this.role, currDto.role);
				this.info = DefVal.setCustom(this.info, currDto.info);
				this.more = DefVal.setCustom(this.more, currDto.more);
				this.mark = DefVal.setCustom(this.mark, currDto.mark);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = "";
			}
		} catch (Exception ex) {
			WB.addLog("Bank.isExist():void, ex=" + ex.getMessage(), "", "Bank");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 12.08.2025, last edit - 09.12.2025
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("Bank.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Bank");
		}
	}

	public Bank(String ParentId, String BankId) throws Exception {
		// origin - 24.03.2025, last edit - 21.11.2025
		this.clear();
		this.src = ParentId + ", " + BankId;
		this.parent = ParentId;
		this.code = BankId;
		this.isExist();
		this.getVal();
		this.validate();
	}

	private void clear() throws Exception {
		// origin - 24.03.2025, last edit - 09.12.2025
		try {
			this.table = "Face";
			this.src = this.id = this.parent = this.code = this.description = this.geo = this.role = this.info = this.more = this.mark = "";
			this.fullName = this.comment = "";
			this.date1 = this.date2 = new ListVal();
			this.val = new ArrayList<FaceDto>();
		} catch (Exception ex) {
			WB.addLog("Bank.clear():void, ex=" + ex.getMessage(), "", "Bank");
		}
	}

	public Bank() throws Exception {
		// origin - 24.03.2025, last edit - 24.03.2025
		this.clear();
	}

	public String toString() {
		// origin - 24.03.2025, last edit - 09.12.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(" table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1.id);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2.id);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 24.03.2025, last edit - 09.12.2025
		try {

			WB.addLog2("Bank.test.getAccount():List<FaceDto>", "", "Bank");
			var tmp = Bank.getAccount();
			WB.addLog2("Bank.test.getAccount():List<FaceDto>, res.size=" + tmp.size(), "", "Bank");
			WB.log(tmp, "Bank");

			WB.addLog2("Bank.test.getCurrAccount(String):List<FaceDto>", "", "Bank");
			for (var tmp1 : new String[] { "Face.FA1", "Face.GCVP", "Face.Tralala" }) {
				var tmp2 = Bank.getAccount();
				WB.addLog2("Bank.test.getCurrAccount(String):List<FaceDto>, res.size=" + tmp2.size() + ", parentId="
						+ tmp1, "", "Bank");
				WB.log(tmp2, "Bank");
			}

			WB.addLog2("Bank.test.getCurrAcount(2String):List<FaceDto>", "", "Bank");
			for (var tmp1 : new String[] { "2023-04-05", "2025-01-24", "2025-08-15" }) {
				for (var tmp2 : new String[] { "Face.FA1", "Face.kgd", "Face.GCVP", "Face.Tralala" }) {
					var tmp3 = Bank.getCurrAccount(tmp1, tmp2);
					WB.addLog2("Bank.test.getCurrAccount(2String):List<FaceDto>, res.size=" + tmp3.size() + ", date1="
							+ tmp1 + ", parentId=" + tmp2, "", "Bank");
					WB.log(tmp3, "Bank");
				}
			}

			WB.addLog2("Bank.test.getAccountByIBAN(3String):FaceDto", "", "Bank");
			for (var tmp1 : new String[] { "2025-08-15" }) {
				for (var tmp2 : new String[] { "Face.FA1", "Face.kgd", "Face.GCVP", "Face.Tralala" }) {
					for (var tmp3 : new String[] { "KZ67009SS00368609110" }) {
						WB.addLog2("Bank.test.getAccountByIBAN(3String):FaceDto, res="
								+ Bank.getAccountByIBAN(tmp1, tmp2, tmp3) + ", date1=" + tmp1 + ", faceParentId=" + tmp2
								+ ", IBAN=" + tmp3, "", "Bank");
					}
				}
			}

			WB.addLog2("Bank.test.getCurrAccount(3String):FaceDto", "", "Bank");
			for (var tmp1 : new String[] { "2023-04-05", "2025-01-24", "2025-08-15" }) {
				for (var tmp2 : new String[] { "Face.FA1", "Face.kgd", "Face.GCVP", "Face.Tralala" }) {
					for (var tmp3 : new String[] { "Face.FA1.Bank1", "Face.GCVP-GFSS.Bank1", "Face.Tralala.Bank1" }) {
						WB.addLog2("Bank.test.getCurrAccount(3String):FaceDto, res="
								+ Bank.getCurrAccount(tmp1, tmp2, tmp3) + ", date1=" + tmp1 + ", faceParentId=" + tmp2
								+ ", faceBankId=" + tmp3, "", "Bank");
					}
				}
			}

			WB.addLog2("Bank.test.ctor(2String)", "", "Bank");
			for (var tmp1 : new String[] { "Face.FA1", "Face.kgd", "Face.GCVP", "Face.Tralala" }) {
				for (var tmp2 : new String[] { "Face.FA1.Bank1", "Face.GCVP-GFSS.Bank1", "Face.Tralala.Bank1" }) {
					var tmp3 = new Bank(tmp1, tmp2);
					WB.addLog2("Bank.test.ctor(2String)=" + tmp3, "", "Bank");
					WB.log(tmp3.val, "Bank");
				}
			}

		} catch (Exception ex) {
			WB.addLog("Bank.test():void, ex=" + ex.getMessage(), "", "Bank");
		}
	}
}