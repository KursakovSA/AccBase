public final class BankAccount {
	// origin - 08.12.2025, last edit - 10.12.2025
	// common fields
	public String src, id, context, defect;
	// special fields
	public String IBAN, fullName, comment;
	public BankId bankId;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("BankAccount.static ctor, ex=" + ex.getMessage(), "", "BankAccount");
		}
	}

	public static BankAccount getByFaceId(String faceId) throws Exception {
		// origin - 08.12.2025, last edit - 17.12.2025
		BankAccount res = new BankAccount();
		try {
			var faceDto = new FaceDto(faceId);
			res = new BankAccount(faceDto.bankAccount);
		} catch (Exception ex) {
			WB.addLog("BankAccount.getByFaceId(String):BankAccount, ex=" + ex.getMessage(), "", "BankAccount");
		}
		return res;
	}

	public String toDoc() throws Exception {
		// origin - 21.12.2025, last edit - 21.12.2025
		String res = "";
		try {
			res = res + "IBAN: " + Etc.fixTrim(this.IBAN) + ", ";
			res = res + this.bankId.toDoc();
		} catch (Exception ex) {
			WB.addLog("BankAccount.toDoc():String, ex=" + ex.getMessage(), "", "BankAccount");
		}
		return res;
	}

	private void validate() throws Exception {
		// origin - 08.12.2025, last edit - 16.12.2025
		try {
			if (this.IBAN.length() < 4) {
				this.defect = this.defect + "empty IBAN; ";
			}
			if (this.bankId.defect.isEmpty() == false) {
				this.defect = this.defect + "defect bankId; ";
			}
		} catch (Exception ex) {
			WB.addLog("BankAccount.validate():void, ex=" + ex.getMessage(), "", "BankAccount");
		}
	}

	private void clear() throws Exception {
		// origin - 08.12.2025, last edit - 10.12.2025
		try {
			this.src = this.id = this.context = this.defect = this.IBAN = this.fullName = this.comment = "";
			this.bankId = new BankId();
		} catch (Exception ex) {
			WB.addLog("BankAccount.clear():void, ex=" + ex.getMessage(), "", "BankAccount");
		}
	}

	public BankAccount(String Src) throws Exception {
		// origin - 08.12.2025, last edit - 16.12.2025
		this.clear();
		this.src = this.id = Src;
		if (this.src.isEmpty() == false) {
			var tmp1 = new ThreeVal(Src);
			var tmp2 = Etc.fixTrim(tmp1.val1);
			if (tmp2.isEmpty() == false) {
				this.IBAN = tmp2;
			}
			var tmp3 = Etc.fixTrim(tmp1.val2);
			var tmp4 = Etc.fixTrim(tmp1.val3);
			if ((tmp3.isEmpty() == false) & (tmp4.isEmpty() == false)) {
				this.bankId = new BankId(tmp3, tmp4);
			}
			// this.validate();
		}
		this.validate();
	}

	public BankAccount() throws Exception {
		// origin - 08.12.2025, last edit - 08.12.2025
		this.clear();
	}

	public String toString() {
		// origin - 08.12.2025, last edit - 11.12.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway(", IBAN ", this.IBAN);
			res = res + Fmtr.addAnyway(", bankId ", this.bankId.id);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", context ", this.context);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 08.12.2025, last edit - 22.12.2025
		try {

//			WB.addLog2("BankAccount.test.toDoc('Face.GCVP-GFSS.Bank1'):String", "", "BankAccount");
//			WB.addLog2("BankAccount.test.toDoc('Face.GCVP-GFSS.Bank1'):String, res="
//					+ BankAccount.getByFaceId("Face.GCVP-GFSS.Bank1").toDoc(), "", "BankAccount");

//			WB.addLog2("BankAccount.test.getByFaceId(String):BankAccount", "", "BankAccount");
//			for (var tmp1 : new String[] { "Face.GCVP-GFSS.Bank1", "Face.FA1", "Face.Enterprise.Template", "Face.Person.Template",
//					"Face.Tralala" }) {
//				WB.addLog2("BankAccount.test.getByFaceId(String):BankAccount, res=" + BankAccount.getByFaceId(tmp1)
//						+ ", faceId=" + tmp1, "", "BankAccount");
//			}

		} catch (Exception ex) {
			WB.addLog("BankAccount.test():void, ex=" + ex.getMessage(), "", "BankAccount");
		}
	}
}