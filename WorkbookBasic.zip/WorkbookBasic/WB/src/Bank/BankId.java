import java.util.ArrayList;
import java.util.List;

public final class BankId {
	// origin - 08.12.2025, last edit - 08.12.2025
	// common fields
	public String src, id, context, defect;
	// special fields
	public String BIC, fullName, comment;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("BankId.static ctor, ex=" + ex.getMessage(), "", "BankId");
		}
	}

	// full list bankId
	public static List<BankId> get() throws Exception {
		// origin - 08.12.2025, last edit - 08.12.2025
		List<BankId> res = new ArrayList<BankId>();
		try {
			var faceListGlobal = DAL.getByTemplate(Conn.globalPath,
					Qry.getRoleInfoFilter("Role.Store.Bank", "Info.Code.BankId"), "Face");
			var faceListWork = DAL.getByTemplate(WB.lastConnWork,
					Qry.getRoleInfoFilter("Role.Store.Bank", "Info.Code.BankId"), "Face");
			var faceList = new ArrayList<ModelDto>();
			faceList.addAll(faceListGlobal);
			faceList.addAll(faceListWork);
			if (faceList.size() != 0) {
				for (var currFace : faceList) {
					var listFullName = new ListVal(currFace.description, "");
					for (var currFullName : listFullName.val) {
						if (currFullName.isEmpty() == false) {
							res.add(new BankId(currFace.code, currFullName));
						}
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("BankId.get():List<BankId>, ex=" + ex.getMessage(), "", "BankId");
		}
		return res;
	}

	// full list bankId for BIC
	public static List<BankId> getByBIC(String BIC) throws Exception {
		// origin - 08.12.2025, last edit - 08.12.2025
		List<BankId> res = new ArrayList<BankId>();
		try {
			var bankIdList = BankId.get();
			if (bankIdList.size() != 0) {
				for (var currBankId : bankIdList) {
					if (Etc.strContains(currBankId.BIC, BIC)) {
						res.add(currBankId);
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("BankId.getByBIC(String):List<BankId>, ex=" + ex.getMessage(), "", "BankId");
		}
		return res;
	}
	
	public String toDoc() throws Exception {
		// origin - 21.12.2025, last edit - 21.12.2025
		String res = "";
		try {
			res = res + "BIC: " + Etc.fixTrim(this.BIC) + ", ";
			res = res + Etc.fixTrim(this.fullName);
		} catch (Exception ex) {
			WB.addLog("BankId.toDoc():String, ex=" + ex.getMessage(), "", "BankId");
		}
		return res;
	}

	private void validate() throws Exception {
		// origin - 08.12.2025, last edit - 11.12.2025
		try {
			if (this.BIC.length() < 4) {
				this.defect = this.defect + "empty BIC; ";
			}
			if (this.fullName.length() < 4) {
				this.defect = this.defect + "empty fullName; ";
			}
		} catch (Exception ex) {
			WB.addLog("BankId.validate():void, ex=" + ex.getMessage(), "", "BankId");
		}
	}

	private void clear() throws Exception {
		// origin - 08.12.2025, last edit - 08.12.2025
		try {
			this.src = this.id = this.context = this.defect = this.BIC = this.fullName = this.comment = "";
		} catch (Exception ex) {
			WB.addLog("BankId.clear():void, ex=" + ex.getMessage(), "", "BankId");
		}
	}

	public BankId(String BIC, String FullName) throws Exception {
		// origin - 08.12.2025, last edit - 08.12.2025
		this.clear();
		this.src = this.id = BIC + " , " + FullName;
		this.BIC = Etc.fixTrim(BIC);
		this.fullName = Etc.fixTrim(FullName);
		this.validate();
	}

	public BankId() throws Exception {
		// origin - 08.12.2025, last edit - 17.12.2025
		this.clear();
		this.validate();
	}

	public String toString() {
		// origin - 08.12.2025, last edit - 08.12.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway(", BIC ", this.BIC);
			res = res + Fmtr.addAnyway(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", context ", this.context);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 08.12.2025, last edit - 08.12.2025
		try {

//			WB.addLog2("BankId.test.get():List<BankId>", "", "BankId");
//			var tmp = BankId.get();
//			WB.addLog2("BankId.test.get():List<BankId>, res.size=" + tmp.size(), "", "BankId");
//			WB.log(tmp, "BankId");

//			WB.addLog2("BankId.test.getByBIC(String):List<BankId>", "", "BankId");
//			for (var tmp1 : new String[] { "HSBKKZKX", "KPSTKZKA", "BankId.Tralala" }) {
//				var tmp2 = BankId.getByBIC(tmp1);
//				WB.addLog2("BankId.test.getByBIC(String):List<BankId>, res.size=" + tmp2.size() + ", BIC=" + tmp1, "",
//						"BankId");
//				WB.log(tmp2, "BankId");
//			}

		} catch (Exception ex) {
			WB.addLog("BankId.test():void, ex=" + ex.getMessage(), "", "BankId");
		}
	}
}