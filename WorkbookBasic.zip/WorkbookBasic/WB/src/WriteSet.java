import java.util.ArrayList;
import java.util.List;

public class WriteSet {
	// origin - 05.10.2024, last edit - 05.10.2024

	public static List<ModelDto> getTest(List<List<String>> testTable) throws Exception {
		// origin - 08.02.2024, last edit - 05.10.2024
		List<ModelDto> res = new ArrayList<ModelDto>();
		try {
			for (var currTable : testTable) {
				List<ModelDto> tmp = new ArrayList<ModelDto>();
				tmp.clear();
				String table = currTable.get(0);
				int numberRecord = Integer.parseInt(currTable.get(1));

				for (int i = 0; i < numberRecord; i++) {
					tmp.add(new ModelDto(table, new IdGen().id, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, // IdGen.getNew()
							WB.strEmpty, ModelDto.getDate1(WB.strEmpty), ModelDto.getDate2(WB.strEmpty), "Test", "Test",
							WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
							WB.strEmpty, MoreVal.lastEdit(WB.strEmpty), WB.strEmpty, WB.strEmpty, WB.strEmpty,
							WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty));
				}
				res.addAll(tmp);
				// res.addAll(ModelDto.getTestSubset(currTable.get(0),
				// Integer.parseInt(currTable.get(1))));
			}

		} catch (Exception ex) {
			WB.addLog("WriteSet.getTestSubset(numberRecord), ex=" + ex.getMessage(), WB.strEmpty, "WriteSet");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("WriteSet.getTestSubset, res.size=" + res.size(), WB.strEmpty,
		// "WriteSet");
		return res;
	}

	public WriteSet() throws Exception {
		// origin - 05.10.2024, last edit - 05.10.2024
	}

	public static void test() throws Exception {
		// origin - 05.10.2024, last edit - 05.10.2024
		try {

		} catch (

		Exception ex) {
			WB.addLog("WriteSet.test, ex=" + ex.getMessage(), WB.strEmpty, "WriteSet");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("WriteSet.test end ", WB.strEmpty, "WriteSet");
	}
}
