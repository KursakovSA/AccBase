import java.io.File;

public class Qry {
	// origin - 09.11.2023, last edit - 19.12.2023
	public static String getTableListSQLite;
	public static String templateMoreAbcBasic;
	public String table = new String();
	public String templateMore = new String();
	private static String workbookTableName;
	private static String backupCmd;
	private static String integrityCheckCmd;
	private static String reindexCmd;
	private static String shortTestCmd;
	private static String vacuumCmd;

	static {
		// origin - 09.11.2023, last edit - 19.12.2023
		getTableListSQLite = "SELECT name FROM sqlite_master WHERE type = 'table'";
		templateMoreAbcBasic = "More LIKE '%AbcBasic%'";
		workbookTableName = "Workbook";
		backupCmd = "vacuum into";
		integrityCheckCmd = "PRAGMA integrity_check;";
		reindexCmd = "reindex;";
		shortTestCmd = integrityCheckCmd + reindexCmd;
		vacuumCmd = "vacuum;";
	}

	{
		// origin - 14.11.2023, last edit - 27.11.2023
		this.table = workbookTableName; // usually this table need
		this.templateMore = "";
	}
	
	public static String getShortTest(String conn) {
		// origin - 19.12.2023, last edit - 19.12.2023
		String res = shortTestCmd;
		Logger.add("Qry.getShortTest, res=" + res, "", "Qry");
		return res;
	}
	
	public static String getVacuum(String conn) {
		// origin - 19.12.2023, last edit - 19.12.2023
		String res = vacuumCmd;
		Logger.add("Qry.getVacuum, res=" + res, "", "Qry");
		return res;
	}
	
	public static String getReindex(String conn) {
		// origin - 19.12.2023, last edit - 19.12.2023
		String res = reindexCmd;
		Logger.add("Qry.getReindex, res=" + res, "", "Qry");
		return res;
	}
	
	public static String getIntegrityCheck(String conn) {
		// origin - 19.12.2023, last edit - 19.12.2023
		String res = integrityCheckCmd;
		Logger.add("Qry.getIntegrityCheck, res=" + res, "", "Qry");
		return res;
	}

	public static String getBackup(String conn) {
		// origin - 18.12.2023, last edit - 18.12.2023
		String res = backupCmd;
		res = res + " '" + WB.backupDir + File.separator + "backup_";
		String labelDateTimeForFileName = Etc.fixTrim(Etc.getLocalDateTimeNow().toString());
		//labelDateTimeForFileName = Etc.delStr(labelDateTimeForFileName, "-");
		labelDateTimeForFileName = labelDateTimeForFileName.replaceAll("-","_");
		//labelDateTimeForFileName = Etc.delStr(labelDateTimeForFileName, ":");
		labelDateTimeForFileName = labelDateTimeForFileName.replaceAll(":","_");
		res = res + labelDateTimeForFileName + "_";
		res = res + Etc.delStr(conn, Conn.prefixJdbcSqlite) + "'";
		Logger.add("Qry.getBackup, res=" + res, "", "Qry");
		return res;
	}

	public String getText(String currConn) {
		// origin - 25.10.2023, last edit - 23.11.2023
		String res = "";
		res = appender(res, "SELECT * FROM");
		res = appender(res, this.table);
		if (this.templateMore.isEmpty() != true) {
			res = appender(res, "WHERE");
			res = appender(res, this.templateMore);
		}
		return res;
	}

	public Qry(String Table, String TemplateMore) {
		// origin - 14.11.2023, last edit - 14.11.2023
		this.table = Table;
		this.templateMore = TemplateMore;
	}

	public Qry(String Table) {
		// origin - 14.11.2023, last edit - 14.11.2023
		this.table = Table;
	}

	public Qry() {
		// origin - 14.11.2023, last edit - 16.11.2023
		this.table = workbookTableName; // usually this table need
	}

	private static String appender(String qry, String add) {
		// origin - 15.11.2023, last edit - 25.11.2023
		String res = qry; // less fixTrim !!!
		res = res + Etc.fixString(add) + " "; // with right space !!!
		return res;
	}

	public static void test() throws Exception {
		// origin - 12.10.2023, last edit - 28.11.2023
	}
}
