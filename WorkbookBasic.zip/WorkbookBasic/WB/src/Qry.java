import java.io.File;

public class Qry {
	// origin - 09.11.2023, last edit - 08.06.2024
	public static String getTableListSQLite;
	private static String backupCmd;
	private static String integrityCheckCmd;
	private static String reindexCmd;
	private static String vacuumCmd;
	private static String getWorkbookLastRecordSQLite;

	static {
		getTableListSQLite = "SELECT name FROM sqlite_master WHERE type = 'table'";
		backupCmd = "vacuum into";
		integrityCheckCmd = "PRAGMA integrity_check;";
		reindexCmd = "reindex;";
		vacuumCmd = "vacuum;";
		getWorkbookLastRecordSQLite = "SELECT * FROM Workbook ORDER BY Id Desc LIMIT 1000";
	}

//	private static void addLog(Path p, String log) throws Exception {
//		// origin - 05.06.2024, last edit - 05.06.2024
//		try {
//			WB.writeReplace(p, log);
//		} catch (Exception ex) {
//			WB.addLog("Qry.addLog, ex=" + ex.getMessage(), "", "Qry");
//		} finally {
//			Etc.doNothing();
//		}
//	}

//	private static Path getPathLog(String qryKind) throws Exception {
//		// origin - 05.06.2024, last edit - 05.06.2024
//		Path res = null;
//		try {
//			String pathLog = "";
//			pathLog = pathLog + WB.startDir + File.separator + qryKind + "_";
//			pathLog = pathLog + DateTool.getLabelDateTimeForFileName();
//			String fileName = InOut.getFileName(WB.lastConn);
//			pathLog = pathLog + fileName;
//			pathLog = pathLog + ".txt";
//			res = Paths.get(pathLog);
//		} catch (Exception ex) {
//			WB.addLog("Qry.getPathLog, ex=" + ex.getMessage(), "", "Qry");
//		} finally {
//			Etc.doNothing();
//		}
//		// WB.addLog2("Qry.getPathLog, res=" + res, "", "Qry");
//		return res;
//	}

//	public static String setReplaceInto(List<ModelDto> dtoList) throws Exception {
//		// origin - 02.06.2024, last edit - 07.06.2024
//		String res = "";
//		try {
//			for (var currDto : dtoList) {
//				res = res + getReplaceInto(currDto) + System.getProperty("line.separator");
//			}
//		} catch (Exception ex) {
//			WB.addLog("Qry.setReplaceInto, ex=" + ex.getMessage(), "", "Qry");
//		} finally {
//			Etc.doNothing();
//		}
//		addLog(getPathLog("setReplaceInto"), res);
//		WB.addLog2("Qry.setReplaceInto, dtoList.size=" + dtoList.size(), "", "Qry");
//		return res;
//	}

	public static String getReplaceInto(ModelDto dto) throws Exception {
		// origin - 02.02.2024, last edit - 07.06.2024
		String res = "";
		res = appender(res, formatterReplaceInto(dto));
		//WB.addLog2("Qry.getReplaceInto, res=" + res, "", "Qry");
		return res;
	}

	public static String formatterReplaceInto(ModelDto dto) throws Exception {
		// origin - 04.02.2024, last edit - 07.06.2024
		String res = "REPLACE into " + Etc.fixTrim(dto.table);
		// String res = "INSERT into " + Etc.fixTrim(dto.table); //??variant??
		// String res = "INSERT OR REPLACE into " + dto.table; //??variant??
		try {
			res = res + getColumnList(dto.table);
			res = res + getValueList(dto.table, dto);
		} catch (Exception ex) {
			WB.addLog("Qry.formatterReplaceInto, ex=" + ex.getMessage(), "", "Qry");
		} finally {
			Etc.doNothing();
		}
		//WB.addLog2("Qry.formatterReplaceInto, res=" + res, "", "Qry");
		return res;
	}

	private static String getValueList(String table, ModelDto dto) throws Exception {
		// origin - 06.06.2024, last edit - 08.06.2024
		String res = "";
		res = res + "values(";

		try {
			if (Etc.strEquals(table, "Account")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtRel(dto.slice) + fmtVal(dto.date1)
						+ fmtVal(dto.date2) + fmtVal(dto.code) + fmtVal(dto.description) + fmtRel(dto.role)
						+ fmtRel(dto.sign) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Asset")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtRel(dto.geo) + fmtRel(dto.role)
						+ fmtRel(dto.info) + fmtRel(dto.unit) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Deal")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtRel(dto.face1) + fmtRel(dto.face2)
						+ fmtRel(dto.face) + fmtVal(dto.date1) + fmtVal(dto.date2) + fmtVal(dto.code)
						+ fmtVal(dto.description) + fmtRel(dto.geo) + fmtRel(dto.role) + fmtRel(dto.info)
						+ fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Debt")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtRel(dto.geo) + fmtRel(dto.role)
						+ fmtRel(dto.info) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Face")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtRel(dto.geo) + fmtRel(dto.role)
						+ fmtRel(dto.info) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Geo")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtRel(dto.role) + fmtRel(dto.unit)
						+ fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Info")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Item")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Mark")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Meter")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtRel(dto.unit) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Price")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtRel(dto.role) + fmtRel(dto.info)
						+ fmtRel(dto.unit) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Process")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtRel(dto.face1) + fmtRel(dto.face2)
						+ fmtRel(dto.face) + fmtRel(dto.slice) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtRel(dto.geo) + fmtRel(dto.sign)
						+ fmtRel(dto.account) + fmtRel(dto.asset) + fmtRel(dto.deal) + fmtRel(dto.item)
						+ fmtRel(dto.debt) + fmtRel(dto.price) + fmtRel(dto.role) + fmtRel(dto.info) + fmtRel(dto.meter)
						+ fmtVal(dto.meterValue) + fmtRel(dto.unit) + fmtVal(dto.more) + fmtRel(dto.mark);
			}
			if (Etc.strEquals(table, "Role")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Sign")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Slice")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtVal(dto.more);
			}
			if (Etc.strEquals(dto.table, "Unit")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtRel(dto.role) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Workbook")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtRel(dto.face1) + fmtRel(dto.face2)
						+ fmtRel(dto.face) + fmtRel(dto.slice) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtRel(dto.geo) + fmtRel(dto.sign)
						+ fmtRel(dto.account) + fmtRel(dto.process) + fmtRel(dto.asset) + fmtRel(dto.deal)
						+ fmtRel(dto.item) + fmtRel(dto.debt) + fmtRel(dto.price) + fmtRel(dto.role) + fmtRel(dto.info)
						+ fmtRel(dto.meter) + fmtVal(dto.meterValue) + fmtRel(dto.unit) + fmtVal(dto.more)
						+ fmtRel(dto.mark);
			}
		} catch (Exception ex) {
			WB.addLog("Qry.getValueList, ex=" + ex.getMessage(), "", "Qry");
		} finally {
			Etc.doNothing();
		}
		
		//res = res + ");";
		res = res + ")";
		// WB.addLog2("Qry.getValueList, res=" + res + ", table=" + table, "", "Qry");
		return res;
	}

	private static String fmtVal(String maybeValue) throws Exception {
		// origin - 07.06.2024, last edit - 07.06.2024
		String res = "";
		res = res + ",";
		maybeValue = Etc.fixTrim(maybeValue);
		res = res + "'" + maybeValue + "'";
		// WB.addLog2("Qry.fmtValMid, res=" + res + ", maybeValue=" + maybeValue, "",
		// "Qry");
		return res;
	}

	private static String fmtId(String maybeValue) throws Exception {
		// origin - 07.06.2024, last edit - 07.06.2024
		String res = "";
		maybeValue = Etc.fixTrim(maybeValue);
		res = res + "'" + maybeValue + "'";
		// WB.addLog2("Qry.fmtId, res=" + res + ", maybeValue=" + maybeValue, "",
		// "Qry");
		return res;
	}

	private static String fmtRel(String maybeValue) throws Exception {
		// origin - 06.06.2024, last edit - 07.06.2024
		String res = "";
		maybeValue = Etc.fixTrim(maybeValue);
		res = res + ",";
		if (maybeValue.isEmpty()) {
			res = res + "null";
		} else {
			res = res + "'" + maybeValue + "'";
		}
		// WB.addLog2("Qry.fmtRel, res=" + res + ", maybeValue=" + maybeValue, "",
		// "Qry");
		return res;
	}

	private static String getColumnList(String table) throws Exception {
		// origin - 06.06.2024, last edit - 06.06.2024
		String res = "";
		if (Etc.strContains(table, "Account")) {
			res = res + "(Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) ";
		}
		if (Etc.strContains(table, "Asset")) {
			res = res + "(Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, Unit, More) ";
		}
		if (Etc.strContains(table, "Deal")) {
			res = res + "(Id, Parent, Face1, Face2, Face, Date1, Date2, Code, Description, Geo, Role, Info, More) ";
		}
		if (Etc.strContains(table, "Debt")) {
			res = res + "(Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) ";
		}
		if (Etc.strContains(table, "Face")) {
			res = res + "(Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) ";
		}
		if (Etc.strContains(table, "Geo")) {
			res = res + "(Id, Parent, Date1, Date2, Code, Description, Role, Unit, More) ";
		}
		if (Etc.strContains(table, "Info")) {
			res = res + "(Id, Parent, Date1, Date2, Code, Description, More) ";
		}
		if (Etc.strContains(table, "Item")) {
			res = res + "(Id, Parent, Date1, Date2, Code, Description, More) ";
		}
		if (Etc.strContains(table, "Mark")) {
			res = res + "(Id, Parent, Date1, Date2, Code, Description, More) ";
		}
		if (Etc.strContains(table, "Meter")) {
			res = res + "(Id, Parent, Date1, Date2, Code, Description, Unit, More) ";
		}
		if (Etc.strContains(table, "Price")) {
			res = res + "(Id, Parent, Date1, Date2, Code, Description, Role, Info, Unit, More) ";
		}
		if (Etc.strContains(table, "Process")) {
			res = res
					+ "(Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Geo, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) ";
		}
		if (Etc.strContains(table, "Role")) {
			res = res + "(Id, Parent, Date1, Date2, Code, Description, More) ";
		}
		if (Etc.strContains(table, "Sign")) {
			res = res + "(Id, Parent, Date1, Date2, Code, Description, More) ";
		}
		if (Etc.strContains(table, "Slice")) {
			res = res + "(Id, Parent, Date1, Date2, Code, Description, More) ";
		}
		if (Etc.strContains(table, "Unit")) {
			res = res + "(Id, Parent, Date1, Date2, Code, Description, Role, More) ";
		}
		if (Etc.strContains(table, "Workbook")) {
			res = res
					+ "(Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Geo, Sign, Account, Process, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) ";
		}
		// WB.addLog2("Qry.getColumnList, res=" + res + ", table=" + table, "", "Qry");
		return res;
	}

	public static String getMoreFilter(String variableStr) throws Exception {
		// origin - 30.12.2023, last edit - 04.06.2024
		String res = "More LIKE '%" + variableStr + "%'";
		return res;
	}

	public static String getWorkbookLastRecord() throws Exception {
		// origin - 27.12.2023, last edit - 04.06.2024
		String res = getWorkbookLastRecordSQLite;
		return res;
	}

	public static String getVacuum(String conn) throws Exception {
		// origin - 19.12.2023, last edit - 04.06.2024
		String res = vacuumCmd;
		return res;
	}

	public static String getReindex(String conn) throws Exception {
		// origin - 19.12.2023, last edit - 04.06.2024
		String res = reindexCmd;
		return res;
	}

	public static String getIntegrityCheck(String conn) throws Exception {
		// origin - 19.12.2023, last edit - 04.06.2024
		String res = integrityCheckCmd;
		return res;
	}

	public static String getOutputBackup(String conn) throws Exception {
		// origin - 28.05.2024, last edit - 03.06.2024
		String res = "";
		try {
			res = res + backupCmd;
			res = res + " '" + WB.inputOutputDir + File.separator + "output_";
			res = res + DateTool.getLabelDateTimeForFileName();
			res = res + "_to_all_";
			String fileName = InOut.getFileName(conn);
			res = res + fileName + "'";
		} catch (Exception ex) {
			WB.addLog("Qry.getOutputBackup, ex=" + ex.getMessage(), "", "Qry");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Qry.getOutputBackup, res=" + res + ", conn=" + conn, "", "Qry");
		return res;
	}

	public static String getBackup(String conn) throws Exception {
		// origin - 18.12.2023, last edit - 04.06.2024
		String res = "";
		try {
			res = res + backupCmd;
			res = res + " '" + WB.backupDir + File.separator + "backup_";
			res = res + DateTool.getLabelDateTimeForFileName();
			String fileName = InOut.getFileName(conn);
			res = res + fileName + "'";
		} catch (Exception ex) {
			WB.addLog("Qry.getBackup, ex=" + ex.getMessage(), "", "Qry");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Qry.getBackup, res=" + res + ", conn=" + conn, "", "Qry");
		return res;
	}

	public static String getText(String currConn, String table, String templateMore) throws Exception {
		// origin - 25.10.2023, last edit - 04.06.2024
		String res = "";
		res = appender(res, "SELECT * FROM");
		res = appender(res, table);
		if (templateMore.isEmpty() != true) {
			res = appender(res, "WHERE");
			res = appender(res, templateMore);
		}
		res = res + ";";
//		WB.addLog2("Qry.getText, res=" + res + ", currConn=" + currConn + ", table="
//		+ table + ", templateMore=" + templateMore, "", "Qry");
		return res;
	}

	public Qry() {
		// origin - 14.11.2023, last edit - 27.12.2023
	}

	private static String appender(String qry, String add) throws Exception {
		// origin - 15.11.2023, last edit - 04.06.2024
		String res = qry; // less fixTrim !!!
		res = res + Etc.fixString(add) + " "; // with right space !!!
		// WB.addLog2("Qry.appender, res=" + res + ", add=" + add, "", "Qry");
		return res;
	}

	public static void test() throws Exception {
		// origin - 12.10.2023, last edit - 28.11.2023
	}
}
