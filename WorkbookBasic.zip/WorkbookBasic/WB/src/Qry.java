import java.io.File;

public class Qry {
	// origin - 09.11.2023, last edit - 01.01.2024
	public static String getTableListSQLite;
	private static String backupCmd;
	private static String integrityCheckCmd;
	private static String reindexCmd;
	private static String vacuumCmd;
	private static String getWorkbookLastRecordSQLite;

	static {
		getTableListSQLite = "SELECT name FROM sqlite_master WHERE type = 'table'";
		backupCmd = "vacuum into";
		integrityCheckCmd = "PRAGMA integrity_check;";
		reindexCmd = "reindex;";
		vacuumCmd = "vacuum;";
		getWorkbookLastRecordSQLite = "SELECT * FROM Workbook ORDER BY Id Desc LIMIT 1000";
	}

	public static String getMoreFilter(String variableStr) {
		// origin - 30.12.2023, last edit - 30.12.2023
		String res = "More LIKE '%" + variableStr + "%'";
		return res;
	}

	public static String getWorkbookLastRecord() {
		// origin - 27.12.2023, last edit - 27.12.2023
		String res = getWorkbookLastRecordSQLite;
		return res;
	}

	public static String getVacuum(String conn) {
		// origin - 19.12.2023, last edit - 21.12.2023
		String res = vacuumCmd;
		return res;
	}

	public static String getReindex(String conn) {
		// origin - 19.12.2023, last edit - 20.12.2023
		String res = reindexCmd;
		return res;
	}

	public static String getIntegrityCheck(String conn) {
		// origin - 19.12.2023, last edit - 20.12.2023
		String res = integrityCheckCmd;
		return res;
	}

	public static String getBackup(String conn) {
		// origin - 18.12.2023, last edit - 06.01.2024
		String res = backupCmd;
		res = res + " '" + WB.backupDir + File.separator + "backup_";
		res = res + Etc.getLabelDateTimeForFileName();
		res = res + Etc.delStr(conn, Conn.prefixJdbcSqlite) + "'";
		return res;
	}

	public static String getText(String currConn, String table, String templateMore) {
		// origin - 25.10.2023, last edit - 01.01.2024
		String res = "";
		res = appender(res, "SELECT * FROM");
		res = appender(res, table);
		if (templateMore.isEmpty() != true) {
			res = appender(res, "WHERE");
			res = appender(res, templateMore);
		}
		// Logger.add("Qry.getText, res=" + res + ", currConn=" + currConn + ", table="
		// + table + ", templateMore=" + templateMore, "", "WB");
		return res;
	}

	public Qry() {
		// origin - 14.11.2023, last edit - 27.12.2023
	}

	private static String appender(String qry, String add) {
		// origin - 15.11.2023, last edit - 25.11.2023
		String res = qry; // less fixTrim !!!
		res = res + Etc.fixString(add) + " "; // with right space !!!
		return res;
	}

	public static void test() throws Exception {
		// origin - 12.10.2023, last edit - 28.11.2023
	}
}
