import java.io.File;

public class Qry {
	// origin - 09.11.2023, last edit - 24.08.2024
	public static String getTableListSQLite;
	public static String backupCmdSQLite;
	public static String integrityCheckCmdSQLite;
	public static String reindexCmdSQLite;
	public static String vacuumCmdSQLite;
	public static String getWorkbookLastRecordSQLite;

	static {
		try {
			Qry.getTableListSQLite = "SELECT name FROM sqlite_master WHERE type = 'table'";
			Qry.backupCmdSQLite = "vacuum into";
			Qry.integrityCheckCmdSQLite = "PRAGMA integrity_check;";
			Qry.reindexCmdSQLite = "reindex;";
			Qry.vacuumCmdSQLite = "vacuum;";
			Qry.getWorkbookLastRecordSQLite = "SELECT * FROM Workbook ORDER BY Id Desc LIMIT 1000";
		} catch (Exception ex) {
			WB.addLog("Qry.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Qry");
		} finally {
			Etc.doNothing();
		}
	}

	public static String getReplaceInto(ModelDto dto) throws Exception {
		// origin - 02.02.2024, last edit - 24.08.2024
		String res = WB.strEmpty;
		try {
			res = Qry.appender(res, formatterReplaceInto(dto));
		} catch (Exception ex) {
			WB.addLog("Qry.getReplaceInto, ex=" + ex.getMessage(), WB.strEmpty, "Qry");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Qry.getReplaceInto, res=" + res, WB.strEmpty, "Qry");
		return res;
	}

	public static String formatterReplaceInto(ModelDto dto) throws Exception {
		// origin - 04.02.2024, last edit - 24.08.2024
		String res = "REPLACE into " + Etc.fixTrim(dto.table);
		// String res = "INSERT into " + Etc.fixTrim(dto.table); //??variant??
		// String res = "INSERT OR REPLACE into " + dto.table; //??variant??
		try {
			res = res + Qry.getColumnList(dto.table);
			res = res + Qry.getValueList(dto.table, dto);
		} catch (Exception ex) {
			WB.addLog("Qry.formatterReplaceInto, ex=" + ex.getMessage(), WB.strEmpty, "Qry");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Qry.formatterReplaceInto, res=" + res, WB.strEmpty, "Qry");
		return res;
	}

	private static String getValueList(String table, ModelDto dto) throws Exception {
		// origin - 06.06.2024, last edit - 27.06.2024
		String res = WB.strEmpty;
		res = res + "values(";

		try {
			if (Etc.strEquals(table, "Account")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtRel(dto.slice) + fmtVal(dto.date1)
						+ fmtVal(dto.date2) + fmtVal(dto.code) + fmtVal(dto.description) + fmtRel(dto.role)
						+ fmtRel(dto.sign) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Asset")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtRel(dto.geo) + fmtRel(dto.role)
						+ fmtRel(dto.info) + fmtRel(dto.unit) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Deal")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtRel(dto.face1) + fmtRel(dto.face2)
						+ fmtRel(dto.face) + fmtVal(dto.date1) + fmtVal(dto.date2) + fmtVal(dto.code)
						+ fmtVal(dto.description) + fmtRel(dto.geo) + fmtRel(dto.role) + fmtRel(dto.info)
						+ fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Debt")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtRel(dto.geo) + fmtRel(dto.role)
						+ fmtRel(dto.info) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Face")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtRel(dto.geo) + fmtRel(dto.role)
						+ fmtRel(dto.info) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Geo")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtRel(dto.role) + fmtRel(dto.unit)
						+ fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Info")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Item")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Mark")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Meter")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtRel(dto.unit) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Price")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtRel(dto.role) + fmtRel(dto.info)
						+ fmtRel(dto.unit) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Process")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtRel(dto.face1) + fmtRel(dto.face2)
						+ fmtRel(dto.face) + fmtRel(dto.slice) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtRel(dto.geo) + fmtRel(dto.sign)
						+ fmtRel(dto.account) + fmtRel(dto.asset) + fmtRel(dto.deal) + fmtRel(dto.item)
						+ fmtRel(dto.debt) + fmtRel(dto.price) + fmtRel(dto.role) + fmtRel(dto.info) + fmtRel(dto.meter)
						+ fmtVal(dto.meterValue) + fmtRel(dto.unit) + fmtVal(dto.more) + fmtRel(dto.mark);
			}
			if (Etc.strEquals(table, "Role")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Sign")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Slice")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtVal(dto.more);
			}
			if (Etc.strEquals(dto.table, "Unit")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtRel(dto.role) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Workbook")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtRel(dto.face1) + fmtRel(dto.face2)
						+ fmtRel(dto.face) + fmtRel(dto.slice) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtRel(dto.geo) + fmtRel(dto.sign)
						+ fmtRel(dto.account) + fmtRel(dto.process) + fmtRel(dto.asset) + fmtRel(dto.deal)
						+ fmtRel(dto.item) + fmtRel(dto.debt) + fmtRel(dto.price) + fmtRel(dto.role) + fmtRel(dto.info)
						+ fmtRel(dto.meter) + fmtVal(dto.meterValue) + fmtRel(dto.unit) + fmtVal(dto.more)
						+ fmtRel(dto.mark);
			}
		} catch (Exception ex) {
			WB.addLog("Qry.getValueList, ex=" + ex.getMessage(), WB.strEmpty, "Qry");
		} finally {
			Etc.doNothing();
		}

		// res = res + ");";
		res = res + ")";
		// WB.addLog2("Qry.getValueList, res=" + res + ", table=" + table, WB.strEmpty,
		// "Qry");
		return res;
	}

	private static String fmtVal(String maybeValue) throws Exception {
		// origin - 07.06.2024, last edit - 05.07.2024
		String res = WB.strEmpty;
		try {
			res = res + WB.strComma;
			maybeValue = Etc.fixTrim(maybeValue);
			res = res + WB.strApostrophe + maybeValue + WB.strApostrophe;
		} catch (Exception ex) {
			WB.addLog("Qry.fmtVal, ex=" + ex.getMessage(), WB.strEmpty, "Qry");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Qry.fmtValMid, res=" + res + ", maybeValue=" + maybeValue,
		// WB.strEmpty,
		// "Qry");
		return res;
	}

	private static String fmtId(String maybeValue) throws Exception {
		// origin - 07.06.2024, last edit - 05.07.2024
		String res = WB.strEmpty;
		try {
			maybeValue = Etc.fixTrim(maybeValue);
			res = res + WB.strApostrophe + maybeValue + WB.strApostrophe;
		} catch (Exception ex) {
			WB.addLog("Qry.fmtId, ex=" + ex.getMessage(), WB.strEmpty, "Qry");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Qry.fmtId, res=" + res + ", maybeValue=" + maybeValue,
		// WB.strEmpty,
		// "Qry");
		return res;
	}

	private static String fmtRel(String maybeValue) throws Exception {
		// origin - 06.06.2024, last edit - 05.07.2024
		String res = WB.strEmpty;
		try {
			maybeValue = Etc.fixTrim(maybeValue);
			res = res + WB.strComma;
			if (maybeValue.isEmpty()) {
				res = res + "null";
			} else {
				res = res + WB.strApostrophe + maybeValue + WB.strApostrophe;
			}
		} catch (Exception ex) {
			WB.addLog("Qry.fmtRel, ex=" + ex.getMessage(), WB.strEmpty, "Qry");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Qry.fmtRel, res=" + res + ", maybeValue=" + maybeValue,
		// WB.strEmpty,
		// "Qry");
		return res;
	}

	private static String getColumnList(String table) throws Exception {
		// origin - 06.06.2024, last edit - 05.07.2024
		String res = WB.strEmpty;
		try {
			if (Etc.strContains(table, "Account")) {
				res = res + "(Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) ";
			}
			if (Etc.strContains(table, "Asset")) {
				res = res + "(Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, Unit, More) ";
			}
			if (Etc.strContains(table, "Deal")) {
				res = res + "(Id, Parent, Face1, Face2, Face, Date1, Date2, Code, Description, Geo, Role, Info, More) ";
			}
			if (Etc.strContains(table, "Debt")) {
				res = res + "(Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) ";
			}
			if (Etc.strContains(table, "Face")) {
				res = res + "(Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) ";
			}
			if (Etc.strContains(table, "Geo")) {
				res = res + "(Id, Parent, Date1, Date2, Code, Description, Role, Unit, More) ";
			}
			if (Etc.strContains(table, "Info")) {
				res = res + "(Id, Parent, Date1, Date2, Code, Description, More) ";
			}
			if (Etc.strContains(table, "Item")) {
				res = res + "(Id, Parent, Date1, Date2, Code, Description, More) ";
			}
			if (Etc.strContains(table, "Mark")) {
				res = res + "(Id, Parent, Date1, Date2, Code, Description, More) ";
			}
			if (Etc.strContains(table, "Meter")) {
				res = res + "(Id, Parent, Date1, Date2, Code, Description, Unit, More) ";
			}
			if (Etc.strContains(table, "Price")) {
				res = res + "(Id, Parent, Date1, Date2, Code, Description, Role, Info, Unit, More) ";
			}
			if (Etc.strContains(table, "Process")) {
				res = res
						+ "(Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Geo, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) ";
			}
			if (Etc.strContains(table, "Role")) {
				res = res + "(Id, Parent, Date1, Date2, Code, Description, More) ";
			}
			if (Etc.strContains(table, "Sign")) {
				res = res + "(Id, Parent, Date1, Date2, Code, Description, More) ";
			}
			if (Etc.strContains(table, "Slice")) {
				res = res + "(Id, Parent, Date1, Date2, Code, Description, More) ";
			}
			if (Etc.strContains(table, "Unit")) {
				res = res + "(Id, Parent, Date1, Date2, Code, Description, Role, More) ";
			}
			if (Etc.strContains(table, "Workbook")) {
				res = res
						+ "(Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Geo, Sign, Account, Process, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) ";
			}
		} catch (Exception ex) {
			WB.addLog("Qry.getColumnList, ex=" + ex.getMessage(), WB.strEmpty, "Qry");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Qry.getColumnList, res=" + res + ", table=" + table, WB.strEmpty,
		// "Qry");
		return res;
	}

	public static String getMoreFilter(String variableStr) throws Exception {
		// origin - 30.12.2023, last edit - 04.06.2024
		String res = "More LIKE '%" + variableStr + "%'";
		return res;
	}

//	public static String getWorkbookLastRecord() throws Exception {
//		// origin - 27.12.2023, last edit - 24.06.2024
//		String res = getWorkbookLastRecordSQLite;
//		return res;
//	}

//	public static String getVacuum(String conn) throws Exception {
//		// origin - 19.12.2023, last edit - 24.06.2024
//		String res = vacuumCmdSQLite;
//		return res;
//	}

//	public static String getReindex(String conn) throws Exception {
//		// origin - 19.12.2023, last edit - 24.08.2024
//		String res = reindexCmdSQLite;
//		return res;
//	}

//	public static String getIntegrityCheck(String conn) throws Exception {
//		// origin - 19.12.2023, last edit - 24.06.2024
//		String res = integrityCheckCmdSQLite;
//		return res;
//	}

	public static String getOutputBackup(String conn) throws Exception {
		// origin - 28.05.2024, last edit - 24.08.2024
		String res = WB.strEmpty;
		try {
			res = res + Qry.backupCmdSQLite;
			res = res + " '" + WB.inputOutputDir + File.separator + "output_";
			res = res + DateTool.getLabelDateTimeForFileName();
			res = res + "_to_all_";
			String fileName = InOut.getFileName(conn);
			res = res + fileName + WB.strApostrophe;
		} catch (Exception ex) {
			WB.addLog("Qry.getOutputBackup, ex=" + ex.getMessage(), WB.strEmpty, "Qry");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Qry.getOutputBackup, res=" + res + ", conn=" + conn, WB.strEmpty,
		// "Qry");
		return res;
	}

	public static String getBackup(String conn) throws Exception {
		// origin - 18.12.2023, last edit - 24.08.2024
		String res = WB.strEmpty;
		try {
			res = res + Qry.backupCmdSQLite;
			res = res + " '" + WB.backupDir + File.separator + "backup_";
			res = res + DateTool.getLabelDateTimeForFileName();
			String fileName = InOut.getFileName(conn);
			res = res + fileName + WB.strApostrophe;
		} catch (Exception ex) {
			WB.addLog("Qry.getBackup, ex=" + ex.getMessage(), WB.strEmpty, "Qry");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Qry.getBackup, res=" + res + ", conn=" + conn, WB.strEmpty,
		// "Qry");
		return res;
	}

	public static String getText(String currConn, String table, String templateMore) throws Exception {
		// origin - 25.10.2023, last edit - 24.08.2024
		String res = WB.strEmpty;
		try {
			res = Qry.appender(res, "SELECT * FROM");
			res = Qry.appender(res, table);
			if (templateMore.isEmpty() != true) {
				res = Qry.appender(res, "WHERE");
				res = Qry.appender(res, templateMore);
			}
			res = res + WB.strSemiColon;
		} catch (Exception ex) {
			WB.addLog("Qry.getText, ex=" + ex.getMessage(), WB.strEmpty, "Qry");
		} finally {
			Etc.doNothing();
		}
//		WB.addLog2("Qry.getText, res=" + res + ", currConn=" + currConn + ", table="
//		+ table + ", templateMore=" + templateMore, WB.strEmpty, "Qry");
		return res;
	}

	public Qry() throws Exception {
		// origin - 14.11.2023, last edit - 07.07.2024
		try {
		} catch (Exception ex) {
			WB.addLog("Qry.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Qry");
		} finally {
			Etc.doNothing();
		}
	}

	private static String appender(String qry, String add) throws Exception {
		// origin - 15.11.2023, last edit - 05.07.2024
		String res = qry; // less fixTrim !!!
		try {
			res = res + Etc.fixString(add) + WB.strSpace; // with right space !!!
		} catch (Exception ex) {
			WB.addLog("Qry.appender, ex=" + ex.getMessage(), WB.strEmpty, "Qry");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Qry.appender, res=" + res + ", add=" + add, WB.strEmpty, "Qry");
		return res;
	}

	public static void test() throws Exception {
		// origin - 12.10.2023, last edit - 06.07.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Qry.test, ex=" + ex.getMessage(), WB.strEmpty, "Qry");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Qry.test end ", WB.strEmpty, "Qry");
	}
}
