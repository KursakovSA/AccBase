import java.io.File;

public class Qry {
	// origin - 09.11.2023, last edit - 20.02.2024
	public static String getTableListSQLite;
	private static String backupCmd;
	private static String integrityCheckCmd;
	private static String reindexCmd;
	private static String vacuumCmd;
	private static String getWorkbookLastRecordSQLite;

	static {
		getTableListSQLite = "SELECT name FROM sqlite_master WHERE type = 'table'";
		backupCmd = "vacuum into";
		integrityCheckCmd = "PRAGMA integrity_check;";
		reindexCmd = "reindex;";
		vacuumCmd = "vacuum;";
		getWorkbookLastRecordSQLite = "SELECT * FROM Workbook ORDER BY Id Desc LIMIT 1000";
	}

	public static String getReplaceInto(ModelDto dto) {
		// origin - 02.02.2024, last edit - 05.02.2024
		String res = "";
		// for (var currReplaceInto : set) {
		// WB.addLog2("Qry.getReplaceInto, currReplaceInto=" + currReplaceInto, "",
		// "WB");
		res = appender(res, formatterReplaceInto(dto));
		// }
		// WB.addLog2("Qry.getReplaceInto, res=" + res, "", "WB");
		return res;
	}

	public static String formatterReplaceInto(ModelDto dto) {
		// origin - 04.02.2024, last edit - 20.02.2024
		String res = "REPLACE into " + Etc.fixTrim(dto.table);
		// String res = "INSERT into " + Etc.fixTrim(dto.table);
		// String res = "INSERT OR REPLACE into " + dto.table;
		try {

			if (Etc.strContains(dto.table, "Account")) {
				// TODO get column list
				res = res + "(" + "Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) ";
				// TODO get value list
				res = res + "values('" + dto.id + "', '" + dto.parent + "', '" + dto.slice + "', '" + dto.date1 + "', '"
						+ dto.date2 + "', '" + dto.code + "', '" + dto.description + "', '" + dto.role + "', '"
						+ dto.sign + "', '" + dto.more + "');";
			}

			if (Etc.strContains(dto.table, "Asset")) {
				// TODO get column list
				res = res + "(" + "Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, Unit, More) ";
				// TODO get value list
				res = res + "values('" + dto.id + "', '" + dto.parent + "', '" + dto.date1 + "', '" + dto.date2 + "', '"
						+ dto.code + "', '" + dto.description + "', '" + dto.geo + "', '" + dto.role + "', '" + dto.info
						+ "', '" + dto.unit + "', '" + dto.more + "');";
			}

			if (Etc.strContains(dto.table, "Deal")) {
				// TODO get column list
				res = res + "("
						+ "Id, Parent, Face1, Face2, Face, Date1, Date2, Code, Description, Geo, Role, Info, More) ";
				// TODO get value list
				res = res + "values('" + dto.id + "', '" + dto.parent + "', '" + dto.face1 + "', '" + dto.face2 + "', '"
						+ dto.face + "', '" + dto.date1 + "', '" + dto.date2 + "', '" + dto.code + "', '"
						+ dto.description + "', '" + dto.geo + "', '" + dto.role + "', '" + dto.info + "', '" + dto.more
						+ "');";
			}

			if (Etc.strContains(dto.table, "Debt")) {
				// TODO get column list
				res = res + "(" + "Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) ";
				// TODO get value list
				res = res + "values('" + dto.id + "', '" + dto.parent + "', '" + dto.date1 + "', '" + dto.date2 + "', '"
						+ dto.code + "', '" + dto.description + "', '" + dto.geo + "', '" + dto.role + "', '" + dto.info
						+ "', '" + dto.more + "');";
			}

			if (Etc.strContains(dto.table, "Face")) {
				// TODO get column list
				res = res + "(" + "Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) ";
				// TODO get value list
				res = res + "values('" + dto.id + "', '" + dto.parent + "', '" + dto.date1 + "', '" + dto.date2 + "', '"
						+ dto.code + "', '" + dto.description + "', '" + dto.geo + "', '" + dto.role + "', '" + dto.info
						+ "', '" + dto.more + "');";
			}

			if (Etc.strContains(dto.table, "Geo")) {
				// TODO get column list
				res = res + "(" + "Id, Parent, Date1, Date2, Code, Description, Role, Unit, More) ";
				// TODO get value list
				res = res + "values('" + dto.id + "', '" + dto.parent + "', '" + dto.date1 + "', '" + dto.date2 + "', '"
						+ dto.code + "', '" + dto.description + "', '" + dto.role + "', '" + dto.unit + "', '"
						+ dto.more + "');";
			}

			if (Etc.strContains(dto.table, "Info")) {
				// TODO get column list
				res = res + "(" + "Id, Parent, Date1, Date2, Code, Description, More) ";
				// TODO get value list
				res = res + "values('" + dto.id + "', '" + dto.parent + "', '" + dto.date1 + "', '" + dto.date2 + "', '"
						+ dto.code + "', '" + dto.description + "', '" + dto.more + "');";
			}

			if (Etc.strContains(dto.table, "Item")) {
				// TODO get column list
				res = res + "(" + "Id, Parent, Date1, Date2, Code, Description, More) ";
				// TODO get value list
				res = res + "values('" + dto.id + "', '" + dto.parent + "', '" + dto.date1 + "', '" + dto.date2 + "', '"
						+ dto.code + "', '" + dto.description + "', '" + dto.more + "');";
			}

			if (Etc.strContains(dto.table, "Mark")) {
				// TODO get column list
				res = res + "(" + "Id, Parent, Date1, Date2, Code, Description, More) ";
				// TODO get value list
				res = res + "values('" + dto.id + "', '" + dto.parent + "', '" + dto.date1 + "', '" + dto.date2 + "', '"
						+ dto.code + "', '" + dto.description + "', '" + dto.more + "');";
			}

			if (Etc.strContains(dto.table, "Meter")) {
				// TODO get column list
				res = res + "(" + "Id, Parent, Date1, Date2, Code, Description, Unit, More) ";
				// TODO get value list
				res = res + "values('" + dto.id + "', '" + dto.parent + "', '" + dto.date1 + "', '" + dto.date2 + "', '"
						+ dto.code + "', '" + dto.description + "', '" + dto.unit + "', '" + dto.more + "');";
			}

			if (Etc.strContains(dto.table, "Price")) {
				// TODO get column list
				res = res + "(" + "Id, Parent, Date1, Date2, Code, Description, Role, Info, Unit, More) ";
				// TODO get value list
				res = res + "values('" + dto.id + "', '" + dto.parent + "', '" + dto.date1 + "', '" + dto.date2 + "', '"
						+ dto.code + "', '" + dto.description + "', '" + dto.role + "', '" + dto.info + "', '"
						+ dto.unit + "', '" + dto.more + "');";
			}

			if (Etc.strContains(dto.table, "Process")) {
				// TODO get column list
				res = res + "("
						+ "Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Geo, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) ";
				// TODO get value list
				res = res + "values('" + dto.id + "', '" + dto.parent + "', '" + dto.face1 + "', '" + dto.face2 + "', '"
						+ dto.face + "', '" + dto.slice + "', '" + dto.date1 + "', '" + dto.date2 + "', '" + dto.code
						+ "', '" + dto.description + "', '" + dto.geo + "', '" + dto.sign + "', '" + dto.account
						+ "', '" + dto.asset + "', '" + dto.deal + "', '" + dto.item + "', '" + dto.debt + "', '" + dto.price + "', '"
						+ dto.role + "', '" + dto.info + "', '" + dto.meter + "', '" + dto.meterValue + "', '" + dto.unit + "', '" + dto.more + "', '" + dto.mark + "');";
			}

			if (Etc.strContains(dto.table, "Role")) {
				// TODO get column list
				res = res + "(" + "Id, Parent, Date1, Date2, Code, Description, More) ";
				// TODO get value list
				res = res + "values('" + dto.id + "', '" + dto.parent + "', '" + dto.date1 + "', '" + dto.date2 + "', '"
						+ dto.code + "', '" + dto.description + "', '" + dto.more + "');";
			}

			if (Etc.strContains(dto.table, "Sign")) {
				// TODO get column list
				res = res + "(" + "Id, Parent, Date1, Date2, Code, Description, More) ";
				// TODO get value list
				res = res + "values('" + dto.id + "', '" + dto.parent + "', '" + dto.date1 + "', '" + dto.date2 + "', '"
						+ dto.code + "', '" + dto.description + "', '" + dto.more + "');";
			}

			if (Etc.strContains(dto.table, "Slice")) {
				// TODO get column list
				res = res + "(" + "Id, Parent, Date1, Date2, Code, Description, More) ";
				// TODO get value list
				res = res + "values('" + dto.id + "', '" + dto.parent + "', '" + dto.date1 + "', '" + dto.date2 + "', '"
						+ dto.code + "', '" + dto.description + "', '" + dto.more + "');";
			}

			if (Etc.strContains(dto.table, "Unit")) {
				// TODO get column list
				res = res + "(" + "Id, Parent, Date1, Date2, Code, Description, Role, More) ";
				// TODO get value list
				res = res + "values('" + dto.id + "', '" + dto.parent + "', '" + dto.date1 + "', '" + dto.date2 + "', '"
						+ dto.code + "', '" + dto.description + "', '" + dto.role + "', '" + dto.more + "');";
			}
			
			if (Etc.strContains(dto.table, "Workbook")) {
				// TODO get column list
				res = res + "("
						+ "Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Geo, Sign, Account, Process, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) ";
				// TODO get value list
				res = res + "values('" + dto.id + "', '" + dto.parent + "', '" + dto.face1 + "', '" + dto.face2 + "', '"
						+ dto.face + "', '" + dto.slice + "', '" + dto.date1 + "', '" + dto.date2 + "', '" + dto.code
						+ "', '" + dto.description + "', '" + dto.geo + "', '" + dto.sign + "', '" + dto.account
						+ "', '" + dto.process + "', '" + dto.asset + "', '" + dto.deal + "', '" + dto.item + "', '" + dto.debt + "', '" + dto.price + "', '"
						+ dto.role + "', '" + dto.info + "', '" + dto.meter + "', '" + dto.meterValue + "', '" + dto.unit + "', '" + dto.more + "', '" + dto.mark + "');";
			}

		} catch (Exception ex) {
			WB.addLog2("Qry.formatterReplaceInto, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "",
					"Qry");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Qry.formatterReplaceInto, res=" + res, "", "WB");
		return res;
	}

	public static String getMoreFilter(String variableStr) {
		// origin - 30.12.2023, last edit - 30.12.2023
		String res = "More LIKE '%" + variableStr + "%'";
		return res;
	}

	public static String getWorkbookLastRecord() {
		// origin - 27.12.2023, last edit - 27.12.2023
		String res = getWorkbookLastRecordSQLite;
		return res;
	}

	public static String getVacuum(String conn) {
		// origin - 19.12.2023, last edit - 21.12.2023
		String res = vacuumCmd;
		return res;
	}

	public static String getReindex(String conn) {
		// origin - 19.12.2023, last edit - 20.12.2023
		String res = reindexCmd;
		return res;
	}

	public static String getIntegrityCheck(String conn) {
		// origin - 19.12.2023, last edit - 20.12.2023
		String res = integrityCheckCmd;
		return res;
	}

	public static String getBackup(String conn) {
		// origin - 18.12.2023, last edit - 06.01.2024
		String res = backupCmd;
		res = res + " '" + WB.backupDir + File.separator + "backup_";
		res = res + DateTool.getLabelDateTimeForFileName();
		res = res + Etc.delStr(conn, Conn.prefixJdbcSqlite) + "'";
		return res;
	}

	public static String getText(String currConn, String table, String templateMore) {
		// origin - 25.10.2023, last edit - 02.02.2024
		String res = "";
		res = appender(res, "SELECT * FROM");
		res = appender(res, table);
		if (templateMore.isEmpty() != true) {
			res = appender(res, "WHERE");
			res = appender(res, templateMore);
		}
		// WB.addLog("Qry.getText, res=" + res + ", currConn=" + currConn + ", table="
		// + table + ", templateMore=" + templateMore, "", "WB");
		return res;
	}

	public Qry() {
		// origin - 14.11.2023, last edit - 27.12.2023
	}

	private static String appender(String qry, String add) {
		// origin - 15.11.2023, last edit - 25.11.2023
		String res = qry; // less fixTrim !!!
		res = res + Etc.fixString(add) + " "; // with right space !!!
		return res;
	}

	public static void test() throws Exception {
		// origin - 12.10.2023, last edit - 28.11.2023
	}
}
