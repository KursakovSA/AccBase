import java.util.ArrayList;
import java.util.List;

public final class WriteSet {
	// origin - 05.10.2024, last edit - 12.10.2025

	public static List<FullDto> getTest(List<List<String>> testTable) throws Exception {
		// origin - 08.02.2024, last edit - 13.09.2026
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			for (var currTable : testTable) {
				List<FullDto> tmp = new ArrayList<FullDto>();
				tmp.clear();
				String table = currTable.get(0);
				int numberRecord = Integer.parseInt(currTable.get(1));

				for (int i = 0; i < numberRecord; i++) {
					tmp.add(new FullDto(table, new IdGen(table, "idCommonCompositeRandom").id, "", "", "", "", // IdGen.getNew()
							"", FullDto.getDate1(""), FullDto.getDate2(""), "Test", "Test", "", "", "", "", "", "", "",
							// "", MoreVal.resetLastEdit(""), "", "", "", ""));
							"", MoreVal.setPart("LastEdit", DateTool.formatter2(DateTool.getNow2())), "", "", "", ""));
				}
				res.addAll(tmp);
			}

		} catch (Exception ex) {
			WB.addLog("WriteSet.getTest(List<List<String>>):List<FullDto>, ex=" + ex.getMessage(), "", "WriteSet");
		}
		// WB.addLog2("WriteSet.getTest, res.size=" + res.size(), "", "WriteSet");
		return res;
	}

	private WriteSet() throws Exception {
		// origin - 05.10.2024, last edit - 04.11.2024
	}

	public static void test() throws Exception {
		// origin - 05.10.2024, last edit - 13.06.2025
		try {

		} catch (

		Exception ex) {
			WB.addLog("WriteSet.test():void, ex=" + ex.getMessage(), "", "WriteSet");
		}
	}
}