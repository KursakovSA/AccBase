import java.util.ArrayList;
import java.util.List;

public class ModelDto {
	// origin - 30.09.2023, last edit - 01.05.2025
	public String src, table, id, parent, face1, face2, face, slice, date1, date2, code, description, sign, account;
	public String geo, role, info, debt, item, meter, meterValue, unit, more, mark, process, asset, deal, templateId;
	public boolean isValid, isExist;
	public List<ModelDto> lower, upper;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("ModelDto.static ctor, ex=" + ex.getMessage(), "", "ModelDto");
		}
	}

//	public static List<ModelDto> getLower(String id, String table) throws Exception {// NOT WORK
//		// origin - 11.05.2025, last edit - 12.05.2025
//		List<ModelDto> res = new ArrayList<ModelDto>();
//		try {
//			res = DAL.getByTemplate(WB.lastConnWork, Qry.getLower(id, table), table);
//		} catch (Exception ex) {
//			WB.addLog("ModelDto.getLower, ex=" + ex.getMessage(), "", "ModelDto");
//		}
//		return res;
//	}

	public static List<ModelDto> getLower(List<ModelDto> srcList, String code) throws Exception {
		// origin - 18.12.2024, last edit - 14.06.2025
		List<ModelDto> res = new ArrayList<ModelDto>();
		List<ModelDto> tmpLower1 = new ArrayList<ModelDto>();
		tmpLower1 = ReadSet.getEqualsByParent(srcList, code); // direct lower 1 level
		List<ModelDto> tmpLower2 = new ArrayList<ModelDto>(); // lower 2 level
		boolean foundNewLowerCode = true;

		try {
			for (;;) { // endless cycle
				foundNewLowerCode = false;
				tmpLower2.clear();

				for (var currL1 : tmpLower1) {
					tmpLower2.addAll(ReadSet.getEqualsByParent(srcList, currL1.code));
				}

				for (var currL2 : tmpLower2) {
					if (ModelDto.isContains(tmpLower1, currL2) == false) {
						tmpLower1.add(currL2);
//					WB.addLog2("ModelDto.getLower, add currL2.code=" + currL2.code + ", for this.code=" + this.code,"", "Debt");
						foundNewLowerCode = true;
					}
				}

				if (foundNewLowerCode == false) {
					break;
				}
			}

			res.addAll(tmpLower1);
		} catch (Exception ex) {
			WB.addLog("ModelDto.getLower(List<ModelDto> srcList, String code):List<ModelDto>, ex=" + ex.getMessage(),
					"", "ModelDto");
		}
		return res;
	}

//	public List<ModelDto> getLower(List<ModelDto> srcList) throws Exception {
//		// origin - 18.12.2024, last edit - 01.05.2025
//		List<ModelDto> res = new ArrayList<ModelDto>();
//		List<ModelDto> tmpLower1 = new ArrayList<ModelDto>();
//		tmpLower1 = ReadSet.getEqualsByParent(srcList, this.code); // direct lower 1 level
//		List<ModelDto> tmpLower2 = new ArrayList<ModelDto>(); // lower 2 level
//		boolean foundNewLowerCode = true;
//
//		try {
//			for (;;) { // endless cycle
//				foundNewLowerCode = false;
//				tmpLower2.clear();
//
//				for (var currL1 : tmpLower1) {
//					tmpLower2.addAll(ReadSet.getEqualsByParent(srcList, currL1.code));
//				}
//
//				for (var currL2 : tmpLower2) {
//					if (ModelDto.isContains(tmpLower1, currL2) == false) {
//						tmpLower1.add(currL2);
////					WB.addLog2("ModelDto.getLower, add currL2.code=" + currL2.code + ", for this.code=" + this.code,"", "Debt");
//						foundNewLowerCode = true;
//					}
//				}
//
//				if (foundNewLowerCode == false) {
//					break;
//				}
//			}
//
//			res.addAll(tmpLower1);
//		} catch (Exception ex) {
//			WB.addLog("ModelDto.getLower, ex=" + ex.getMessage(), "", "Debt");
//		}
//		return res;
//	}

	public static List<ModelDto> getUpper(List<ModelDto> srcList, String parent) throws Exception {
		// origin - 17.12.2024, last edit - 14.06.2025
		List<ModelDto> res = new ArrayList<ModelDto>();
		String tmpParentCode = Etc.fixString(parent);
		List<ModelDto> tmpUpper = new ArrayList<ModelDto>();
		boolean foundNewParentCode = true;

		try {
			for (;;) {// endless cycle
				foundNewParentCode = false;
				for (var currLst : srcList) {
					if (Etc.strEquals(currLst.code, tmpParentCode)) {
						// if (ModelDto.isContains(tmpUpper, currLst) == false) {
						if (tmpUpper.contains(currLst) == false) {
							tmpUpper.add(currLst);
//							WB.addLog2("ModelDto.getUpper, add currLst.code=" + currLst.code + ", tmpParentCode="
//									+ tmpParentCode + ", for currLst.code=" + currLst.code, "", "ModelDto");
							tmpParentCode = Etc.fixString(currLst.parent);
							foundNewParentCode = true;
							break;
						}
					}
				}
				if (foundNewParentCode == false) {
					break;
				}
			}
			// this.upper.addAll(tmpUpper);
			res.addAll(tmpUpper);
		} catch (Exception ex) {
			WB.addLog("ModelDto.getUpper(List<ModelDto> srcList, String parent):List<ModelDto>, ex=" + ex.getMessage(),
					"", "ModelDto");
		}
		return res;
	}

//	public List<ModelDto> getUpper(List<ModelDto> srcList) throws Exception {
//		// origin - 17.12.2024, last edit - 01.05.2025
//		List<ModelDto> res = new ArrayList<ModelDto>();
//		String tmpParentCode = this.parent;
//		List<ModelDto> tmpUpper = new ArrayList<ModelDto>();
//		boolean foundNewParentCode = true;
//
//		try {
//			for (;;) {// endless cycle
//				foundNewParentCode = false;
//				for (var currLst : srcList) {
//					if (Etc.strEquals(currLst.code, tmpParentCode)) {
//						if (ModelDto.isContains(tmpUpper, currLst) == false) {
//							tmpUpper.add(currLst);
////							WB.addLog2("Debt.getUpper, add currLst.code=" + currLst.code + ", tmpParentCode="
////									+ tmpParentCode + ", for this.code=" + this.code, "", "Debt");
//							tmpParentCode = currLst.parent;
//							foundNewParentCode = true;
//							break;
//						}
//					}
//				}
//				if (foundNewParentCode == false) {
//					break;
//				}
//			}
//			// this.upper.addAll(tmpUpper);
//			res.addAll(tmpUpper);
//		} catch (Exception ex) {
//			WB.addLog("ModelDto.getUpper, ex=" + ex.getMessage(), "", "ModelDto");
//		}
//		return res;
//	}

	public static boolean isContains(List<ModelDto> lst, ModelDto dto) throws Exception {
		// origin - 17.12.2024, last edit - 14.06.2025
		boolean res = false;
		try {
			for (var curr : lst) {
				if (Etc.strEquals(curr.code, dto.code)) {
					res = true;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("ModelDto.isContains(List<ModelDto> lst, ModelDto dto):boolean, ex=" + ex.getMessage() + ", res="
					+ res, "", "ModelDto");
		}
		return res;
	}

//	public String getId() throws Exception {
//		// origin - 20.08.2024, last edit - 18.05.2025
//		String res = "";
//		try {
//			res = new IdGen("", "").id;
//		} catch (Exception ex) {
//			WB.addLog("ModelDto.getId, ex=" + ex.getMessage(), "", "ModelDto");
//		}
//		return res;
//	}

//	public String getId(String moreId, String context) throws Exception {
//		// origin - 20.08.2024, last edit - 18.05.2025
//		String res = "";
//		try {
//			context = DefVal.set(context, "idIntegerGrowingDigitalGlobal");
//			// res = IdGen.getNew(moreId, context);
//			res = new IdGen(moreId, context).id;
//		} catch (Exception ex) {
//			WB.addLog("ModelDto.getId, ex=" + ex.getMessage(), "", "ModelDto");
//		}
//		return res;
//	}

//	public static List<ModelDto> removeDuplicate2(List<ModelDto> dtoBase, List<ModelDto> dtoAdd) throws Exception {
//		// origin - 12.06.2024, last edit - 20.03.2025
//		//LocalDateTime localStart = WB.getLocalStart();
//		List<ModelDto> res = new ArrayList<ModelDto>();
//		String strCurrDtoRes = "";
//		String strCurrDtoAdd = "";
//		boolean hasEqualsBaseAdd = false;
//		try {
//
//			if (dtoBase.isEmpty()) {
//				res.addAll(dtoAdd);
//
//			} else {
//				for (var currDtoAdd : dtoAdd) {
//					strCurrDtoAdd = currDtoAdd.toString();// strCurrDtoAdd = currDtoAdd.id;
//					for (var currDtoBase : dtoBase) {
//						strCurrDtoRes = currDtoBase.toString();// strCurrDtoRes = currDtoBase.id;
//						hasEqualsBaseAdd = false;
//						if (strCurrDtoRes.equals(strCurrDtoAdd)) {
//							hasEqualsBaseAdd = true;
//							break;
//						}
//					}
//					if (hasEqualsBaseAdd == false) {
//						res.add(new ModelDto(currDtoAdd));
//					}
//				}
//			}
//
//		} catch (Exception ex) {
//			WB.addLog("ModelDto.removeDuplicate2, ex=" + ex.getMessage(), "", "ModelDto");
//		}
////		WB.getLocalEnd("ModelDto.removeDuplicate2 for List<ModelDto> dtoBase.size=" + dtoBase.size()
////				+ ", dtoAdd.size=" + dtoAdd.size(), localStart);
////		WB.addLog2("ModelDto.removeDuplicate2, res.size=" + res.size() + ", dtoBase.size=" + dtoBase.size()
////				+ ", dtoAdd.size=" + dtoAdd.size(), "", "ModelDto");
//		return res;
//	}

//	public static List<ModelDto> removeDuplicate(List<ModelDto> dtoCollector, List<ModelDto> dtoAdd) throws Exception {
//		// origin - 03.06.2024, last edit - 20.03.2025
//		LocalDateTime localStart = WB.getLocalStart();
//		List<ModelDto> res = new ArrayList<ModelDto>();
//		WB.addLog2("ModelDto.removeDuplicate, before work, res.size=" + res.size() + ", dtoCollector.size="
//				+ dtoCollector.size() + ", dtoAdd.size=" + dtoAdd.size(), "", "ModelDto");
//		String strCurrDtoRes = "";
//		String strCurrDtoAdd = "";
//		boolean hasEqualsCollectorAdd = false;
//		try {
//
//			if (dtoCollector.isEmpty()) {
//				res.addAll(dtoAdd);
//
//			} else {
//				for (var currDtoAdd : dtoAdd) {
//					strCurrDtoAdd = currDtoAdd.toString();// strCurrDtoAdd = currDtoAdd.id;
//					for (var currDtoRes : dtoCollector) {
//						strCurrDtoRes = currDtoRes.toString();// strCurrDtoRes = currDtoRes.id;
//						hasEqualsCollectorAdd = false;
//						if (strCurrDtoRes.equals(strCurrDtoAdd)) {
//							hasEqualsCollectorAdd = true;
//							break;
//						}
//					}
//					if (hasEqualsCollectorAdd == false) {
//						res.add(new ModelDto(currDtoAdd));
//					}
//				}
//			}
//			res.addAll(dtoCollector);
//
//		} catch (Exception ex) {
//			WB.addLog("ModelDto.removeDuplicate, ex=" + ex.getMessage(), "", "ModelDto");
//		}
//		WB.getLocalEnd("ModelDto.removeDuplicate for List<ModelDto> dtoCollector.size=" + dtoCollector.size()
//				+ ", dtoAdd.size=" + dtoAdd.size(), localStart);
//		WB.addLog2("ModelDto.removeDuplicate, after work, res.size=" + res.size() + ", dtoCollector.size="
//				+ dtoCollector.size() + ", dtoAdd.size=" + dtoAdd.size(), "", "ModelDto");
//		return res;
//	}

	public static String getDate2(String date2) throws Exception {
		// origin - 09.02.2024, last edit - 14.06.2025
		String res = Etc.fixTrim(date2);
		if (res.isEmpty()) {
			try {
				res = DateTool.getLocalDate("").toString();

			} catch (Exception ex) {
				WB.addLog("ModelDto.getIDate2(String date2):String, ex=" + ex.getMessage(), "", "ModelDto");
			}
		}
		return res;
	}

	public static String getDate1(String date1) throws Exception {
		// origin - 09.02.2024, last edit - 14.06.2025
		String res = Etc.fixTrim(date1);
		if (res.isEmpty()) {
			try {
				res = DateTool.getLocalDate("").toString();

			} catch (Exception ex) {
				WB.addLog("ModelDto.getIDate1(String date1):String, ex=" + ex.getMessage(), "", "ModelDto");
			}
		}
		return res;
	}

	public static String getFieldByKey(String inStr, String key) throws Exception {
		// origin - 15.11.2024, last edit - 14.06.2025
		String res = "";
		inStr = Etc.fixTrim(inStr);
		try {
			String[] items = inStr.split(" " + "\\|" + " ");
			// res = ModelDto.getFromEquation(items, key);

			int indexSignEquals = 0;
			String strKey = "";
			String splitEquation = "@";
			for (var currEquation : items) {
				indexSignEquals = 0;
				indexSignEquals = currEquation.lastIndexOf(splitEquation);
				if (indexSignEquals > 0) {
					strKey = "";
					strKey = currEquation.substring(0, indexSignEquals);
					strKey = Etc.fixTrim(strKey);
					if ((strKey.isEmpty() == false) && (Etc.strEquals(key, strKey))) {
						res = currEquation.substring(indexSignEquals + 1, currEquation.length());
						res = Etc.fixTrim(res);
					}
				}
			}

		} catch (Exception ex) {
			WB.addLog("ModelDto.getFieldByKey(String inStr, String key):String, ex=" + ex.getMessage() + ", res=" + res,
					"", "ModelDto");
		}
		return res;
	}

//	public ModelDto(String Id, String Code, String Description) throws Exception {
//		// origin - 04.08.2024, last edit - 01.05.2025
//		this();
//		this.id = Id;
//		this.code = Code;
//		this.description = Description;
//	}

	public ModelDto(ModelDto in) throws Exception {
		// origin - 02.01.2024, last edit - 05.09.2025
		this.clear();
		this.src = in.src;
		this.table = in.table;
		this.id = in.id;
		this.parent = in.parent;
		this.face1 = in.face1;
		this.face2 = in.face2;
		this.face = in.face;
		this.slice = in.slice;
		this.date1 = in.date1;
		this.date2 = in.date2;
		this.code = in.code;
		this.description = in.description;
		this.sign = in.sign;
		this.account = in.account;
		this.geo = in.geo;
		this.role = in.role;
		this.info = in.info;
		this.meter = in.meter;
		this.meterValue = in.meterValue;
		this.unit = in.unit;
		this.more = in.more;
		this.mark = in.mark;
		this.process = in.process;
		this.asset = in.asset;
		this.deal = in.deal;
	}

	public ModelDto(DealDto dDto) throws Exception {
		// origin - 05.09.2025, last edit - 05.09.2025
		this.clear();
		this.table = "Deal";
		this.id = dDto.id;
		this.parent = dDto.parent;
		this.face1 = dDto.face1;
		this.face2 = dDto.face2;
		this.face = dDto.face;
		this.date1 = dDto.date1;
		this.date2 = dDto.date2;
		this.code = dDto.code;
		this.description = dDto.description;
		this.geo = dDto.geo;
		this.role = dDto.role;
		this.info = dDto.info;
		this.more = dDto.more;
		this.mark = dDto.mark;
	}

	public ModelDto(String Table, String Id, String Parent, String Face1, String Face2, String Face, String Slice,
			String Date1, String Date2, String Code, String Description, String Sign, String Account, String Geo,
			String Role, String Info, String Meter, String MeterValue, String Unit, String More, String Mark,
			String Process, String Asset, String Deal) throws Exception {
		// origin - 02.11.2023, last edit - 05.09.2025
		this.clear();
		this.table = Table;
		this.id = Id;
		this.parent = Parent;
		this.face1 = Face1;
		this.face2 = Face2;
		this.face = Face;
		this.slice = Slice;
		this.date1 = Date1;
		this.date2 = Date2;
		this.code = Code;
		this.description = Description;
		this.sign = Sign;
		this.account = Account;
		this.geo = Geo;
		this.role = Role;
		this.info = Info;
		this.meter = Meter;
		this.meterValue = MeterValue;
		this.unit = Unit;
		this.more = More;
		this.mark = Mark;
		this.process = Process;
		this.asset = Asset;
		this.deal = Deal;
	}

	public void clear() throws Exception {
		// origin - 31.12.2023, last edit - 06.09.2025
		try {
			this.src = this.table = this.id = this.parent = this.face1 = this.face2 = "";
			this.face = this.slice = this.date1 = this.date2 = this.code = this.description = "";
			this.sign = this.account = this.geo = this.role = this.info = this.meter = this.meterValue = "";
			this.unit = this.more = this.mark = this.process = this.asset = this.deal = this.templateId = "";
			this.isValid = true;
			this.isExist = false;
			this.lower = new ArrayList<ModelDto>();
			this.upper = new ArrayList<ModelDto>();
		} catch (Exception ex) {
			WB.addLog("ModelDto.clear():void, ex=" + ex.getMessage(), "", "ModelDto");
		}
	}

	public ModelDto() throws Exception {
		// origin - 02.11.2023, last edit - 24.11.2024
		this.clear();
	}

	public String toString() {
		// origin - 30.09.2023, last edit - 20.03.2025
		String res = "";
		try {
			// res = res + Fmtr.addIfNotEmpty("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", ", this.slice);

			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.sign);
			res = res + Fmtr.addIfNotEmpty(", ", this.account);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", ", this.process);
			res = res + Fmtr.addIfNotEmpty(", ", this.asset);
			res = res + Fmtr.addIfNotEmpty(", ", this.deal);
			res = res + Fmtr.addIfNotEmpty(", ", this.meter);
			res = res + Fmtr.addIfNotEmpty(", meterValue ", this.meterValue);
			res = res + Fmtr.addIfNotEmpty(", ", this.unit);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 12.10.2023, last edit - 14.06.2025
		try {

//			// isContains
//			var tmp1 = new Debt("Debt.GFSS");
//			WB.addLog2("ModelDto.test.isContains()=" + ModelDto.isContains(WB.abcLast.debt, tmp1)
//					+ ", Debt.GFSS in WB.abcLast.debt", "", "ModelDto");
//			var tmp2 = new Debt("Debt.tralala");
//			WB.addLog2("ModelDto.test.isContains()=" + ModelDto.isContains(WB.abcLast.debt, tmp2)
//					+ ", Debt.tralala in WB.abcLast.debt", "", "ModelDto");

//			// ctor()
//			WB.addLog2("ModelDto.test.ctor()=" + new ModelDto(), "", "ModelDto");

//			// ModelDto ctor clone
//			var res1 = new ModelDto("Id1", "Code1", "Description1");
//			WB.addLog2("ModelDto.test.ctor(Id, Code, Description), res1=" + res1, "", "ModelDto");
//			var res1Clone = new ModelDto(res1);
//			WB.addLog2("ModelDto.test.ctor(res1), res1Clone=" + res1Clone, "", "ModelDto");

		} catch (Exception ex) {
			WB.addLog("ModelDto.test():void, ex=" + ex.getMessage(), "", "ModelDto");
		}
	}
}