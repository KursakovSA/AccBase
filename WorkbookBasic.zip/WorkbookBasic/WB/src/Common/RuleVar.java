import java.util.ArrayList;
import java.util.List;

public final class RuleVar {
	// origin - 28.10.2026, last edit - 29.10.2026
	public String src, name;
	public UnitVal value;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("RuleVar.static ctor, ex=" + ex.getMessage(), "", "RuleVar");
		}
	}

	public static boolean check(String strCheck) throws Exception {
		// origin - 29.10.2026, last edit - 29.10.2026
		boolean res = false;
		try {
			if (Etc.strNotValid(strCheck)) {
				return res;
			}
			for (var curr : RuleVar.getListByName(strCheck)) {
				res = RuleVar.check(strCheck, curr);
			}
		} catch (Exception ex) {
			WB.addLog("RuleVar.check(String):boolean, ex=" + ex.getMessage(), "", "RuleVar");
		}
		return res;
	}

	public static boolean check(String strCheck, RuleVar ruleVar) throws Exception {
		// origin - 28.10.2026, last edit - 29.10.2026
		boolean res = false;
		try {
			if (Etc.strNotValid(strCheck)) {
				return res;
			}

			if (strCheck.startsWith(ruleVar.name) == false) {
				return res;
			}

			var nameStrCheck = MoreVal.getNameByPart(strCheck);
			var valStrCheck = MoreVal.getValueByPart(strCheck);
			var checkPattern = ruleVar.value.unit.code;
			if (Etc.strNotValid(nameStrCheck, valStrCheck, checkPattern)) {
				return res;
			}

			if (valStrCheck.length() != ruleVar.value.val) { // check lenght
				return res = false;
			}

			switch (checkPattern) { // check content
			case "Unit.Alfanumeric" -> res = Etc.isLetterOrDigitAll(valStrCheck);
			case "Unit.Numeric" -> res = Etc.isDigitAll(valStrCheck);
			default -> res = false;
			}
		} catch (Exception ex) {
			WB.addLog("RuleVar.check(String,RuleVar):boolean, ex=" + ex.getMessage(), "", "RuleVar");
		}
		return res;
	}

	public static List<RuleVar> getListByName(String name) throws Exception {
		// origin - 29.10.2026, last edit - 29.10.2026
		List<RuleVar> res = new ArrayList<RuleVar>();
		try {
			name = MoreVal.getNameByPart(name);
			if (Etc.strNotValid(name)) {
				return res;
			}
			for (var curr : RuleVar.getList()) {
				if (Etc.strEquals(name, curr.name)) {
					res.add(curr);
				}
			}
		} catch (Exception ex) {
			WB.addLog("RuleVar.getListByName(String):List<RuleVar>, ex=" + ex.getMessage(), "", "RuleVar");
		}
		return res;
	}

	public static List<String> getListMoreVal(String more, List<RuleVar> ruleList) throws Exception {
		// origin - 28.10.2026, last edit - 29.10.2026
		List<String> res = new ArrayList<String>();
		try {
			if (Etc.strNotValid(more)) {
				return res;
			}

			var tmp = Fmtr.getListStrBySplit(more, ";");
			for (var currPartMore : tmp) {
				for (var currPartList : ruleList) {
					if (currPartMore.startsWith(currPartList.name)) {
						res.add(currPartMore);
					}
				}
			}
			res = Etc.removeDuplicate(res);
		} catch (Exception ex) {
			WB.addLog("RuleVar.getListMoreVal(String,List<RuleVar>):List<String>, ex=" + ex.getMessage(), "",
					"RuleVar");
		}
		return res;
	}

	private static List<RuleVar> getList() throws Exception {
		// origin - 28.10.2026, last edit - 29.10.2026
		List<RuleVar> res = new ArrayList<RuleVar>();
		try {
			for (var curr1 : WB.abcGlobal.rule) {
				var tmp1 = List.of(curr1.meterValue.split(";"));
				var tmp2 = curr1.unit;

				if (Etc.strNotValid(curr1.unit)) {
					continue;
				}

				for (var curr2 : tmp1) {
					var name = MoreVal.getNameByPart(curr2);
					var val = MoreVal.getValueByPart(curr2);

					if (Etc.strNotValid(name, val)) {
						continue;
					}

					var tmp4 = new UnitVal(val, tmp2);
					res.add(new RuleVar(curr2, name, tmp4));
				}
			}
		} catch (Exception ex) {
			WB.addLog("RuleVar.getList():List<RuleVar>, ex=" + ex.getMessage(), "", "RuleVar");
		}
		return res;
	}

	public RuleVar(String Src, String Name, UnitVal Val) throws Exception {
		// origin - 29.10.2026, last edit - 29.10.2026
		this.clear();
		this.src = Src;
		this.name = Etc.fixTrim(Name);
		this.value = Val;
	}

	public RuleVar() throws Exception {
		// origin - 28.10.2026, last edit - 29.10.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 21.10.2026, last edit - 21.10.2026
		try {
			this.src = this.name = "";
			this.value = new UnitVal("Unit.Alfanumeric");
		} catch (Exception ex) {
			WB.addLog("RuleVar.clear():void, ex=" + ex.getMessage(), "", "RuleVar");
		}
	}

	public String toString() {
		// origin - 29.10.2026, last edit - 29.10.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addAnyway(", name ", this.name);
			res = res + Fmtr.addIfNotEmpty(", value ", this.value.id);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2026, last edit - 29.10.2026
		try {

//			WB.addLog2("RuleVar.test.check(String;RuleVar):boolean", "", "RuleVar");
//			for (var tmp1 : new String[] { "BIC=111", "GSVS=222", "IIN=555", "FullName=666", "IIN=111222333444" }) {
//				for (var tmp2 : RuleVar.getList()) {
//					WB.addLog2("RuleVar.test.check(String,RuleVar):boolean, res=" + RuleVar.check(tmp1, tmp2)
//							+ ", tmp1 " + tmp1 + ", tmp2.src " + tmp2.src, "", "RuleVar");
//				}
//			}

//			WB.addLog2("RuleVar.test.check(String):boolean", "", "RuleVar");
//			for (var tmp1 : new String[] { "BIC=111", "GSVS=222", "IIN=555", "FullName=666", "IIN=111222333444" }) {
//				WB.addLog2("RuleVar.test.check(String):boolean, res=" + RuleVar.check(tmp1) + ", tmp1 " + tmp1, "",
//						"RuleVar");
//			}

//			WB.addLog2("RuleVar.test.getListByName(String):List<RuleVar>", "", "RuleVar");
//			for (var tmp1 : new String[] { "BIC=111", "GSVS=222", "IIN=555", "FullName=666" }) {
//				var tmp2 = RuleVar.getListByName(tmp1);
//				WB.addLog2(
//						"RuleVar.test.getListByName(String):List<RuleVar>, res.size=" + tmp2.size() + ", tmp1 " + tmp1,
//						"", "RuleVar");
//				WB.log(tmp2, "RuleVar");
//			}

//			WB.addLog2("RuleVar.test.getListMoreVal(2String):List<String>", "", "RuleVar");
//			for (var tmp1 : new String[] { null, "", "BIC=111;", "GSVS=222;FullName=333;", "CashId=444;IIN=555;",
//					"FullName=666;EmpId=777;", "StoreId=111;IIN=111222333444;FullName=444;DeptId=555;" }) {
//				var tmp2 = RuleVar.getList();
//				WB.addLog2("RuleVar.test.getListMoreVal(2String):List<String>, res="
//						+ RuleVar.getListMoreVal(tmp1, tmp2) + ", tmp1=" + tmp1, "", "RuleVar");
//			}

//			{
//				WB.addLog2("RuleVar.test.getList():List<RuleVar>", "", "RuleVar");
//				var tmp1 = RuleVar.getList();
//				WB.log(tmp1, "RuleVar");
//			}

		} catch (Exception ex) {
			WB.addLog("RuleVar.test():void, ex=" + ex.getMessage(), "", "RuleVar");
		}
	}
}