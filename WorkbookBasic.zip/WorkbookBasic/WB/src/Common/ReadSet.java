import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public final class ReadSet {
	// origin - 05.10.2024, last edit - 12.10.2025

	public static String getMeterValueByContainsDescription(List<FullDto> partAbc, String strFilter) throws Exception {
		// origin - 02.09.2024, last edit - 13.06.2025
		String res = "";
		try {
			for (var currPartAbc : partAbc) { // IdGenLocal must have not empty field meterValue
				if (Etc.fixTrim(currPartAbc.meterValue).isEmpty()) {
					continue;
				}
				if (Etc.strContains(currPartAbc.description, strFilter)) {
					res = Etc.fixTrim(String.valueOf(Etc.fixTrim(currPartAbc.meterValue)));
				}
			}
		} catch (Exception ex) {
			WB.addLog(
					"ReadSet.getMeterValueByContainsDescription(List<FullDto>, String):String, ex=" + ex.getMessage(),
					"", "ReadSet");
		}
		return res;
	}

	public static List<FullDto> getEqualsByRole(List<FullDto> set, String subStr) throws Exception {
		// origin - 24.11.2024, last edit - 13.06.2025
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			Stream<FullDto> basicStream = set.stream();
			basicStream.filter(n -> n.role.toLowerCase().equals(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ReadSet.getEqualsByRole(List<FullDto>, String):List<FullDto>, ex=" + ex.getMessage(), "",
					"ReadSet");
		}
		return res;
	}

	public static List<FullDto> getEqualsByParent(List<FullDto> set, String subStr) throws Exception {
		// origin - 02.08.2024, last edit - 13.06.2025
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			Stream<FullDto> basicStream = set.stream();
			basicStream.filter(n -> n.parent.toLowerCase().equals(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ReadSet.getEqualsByParent(List<FullDto>, String):List<FullDto>, ex=" + ex.getMessage(), "",
					"ReadSet");
		}
		return res;
	}

	public static List<FullDto> getEqualsByDescription(List<FullDto> set, String subStr) throws Exception {
		// origin - 02.09.2024, last edit - 13.06.2025
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			Stream<FullDto> basicStream = set.stream();
			basicStream.filter(n -> n.description.toLowerCase().equals(subStr.toLowerCase()))
					.forEach((x) -> res.add(x)); // contains(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ReadSet.getEqualsByDescription(List<FullDto>, String):List<FullDto>, ex=" + ex.getMessage(),
					"", "ReadSet");
		}
		return res;
	}

	public static List<FullDto> getContainsByMore(List<FullDto> set, String subStr) throws Exception {
		// origin - 29.11.2023, last edit - 13.06.2025
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			Stream<FullDto> basicStream = set.stream();
			basicStream.filter(n -> n.more.toLowerCase().contains(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ReadSet.getContainsByMore(List<FullDto>, String):List<FullDto>, ex=" + ex.getMessage(), "",
					"ReadSet");
		}
		return res;
	}

//	public static List<FullDto> getContainsByParent(List<FullDto> set, String subStr) throws Exception {
//		// origin - 19.12.2024, last edit - 20.03.2025
//		List<FullDto> res = new ArrayList<FullDto>();
//		try {
//			Stream<FullDto> basicStream = set.stream();
//			basicStream.filter(n -> n.parent.toLowerCase().contains(subStr.toLowerCase())).forEach((x) -> res.add(x));
//		} catch (Exception ex) {
//			WB.addLog("ReadSet.getContainsByParent, ex=" + ex.getMessage(), "", "ReadSet");
//		}
//		return res;
//	}

	public static List<FullDto> getStartsWithByCode(List<FullDto> set, String subStr) throws Exception {
		// origin - 17.01.2025, last edit - 13.06.2025
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			Stream<FullDto> basicStream = set.stream();
			basicStream.filter(n -> n.code.toLowerCase().startsWith(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ReadSet.getStartsWithByCode(List<FullDto>, String):List<FullDto>, ex=" + ex.getMessage(), "",
					"ReadSet");
		}
		return res;
	}

	public static List<FullDto> getContainsByCode(List<FullDto> set, String subStr) throws Exception {
		// origin - 23.11.2024, last edit - 13.06.2025
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			Stream<FullDto> basicStream = set.stream();
			basicStream.filter(n -> n.code.toLowerCase().contains(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ReadSet.getContainsByCode(List<FullDto>, String):List<FullDto>, ex=" + ex.getMessage(), "",
					"ReadSet");
		}
		return res;
	}

	public static List<FullDto> getEqualsByCode(List<FullDto> set, String subStr) throws Exception {
		// origin - 07.01.2024, last edit - 13.06.2025
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			Stream<FullDto> basicStream = set.stream();
			basicStream.filter(n -> n.code.toLowerCase().equals(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ReadSet.getEqualsByCode(List<FullDto>, String):List<FullDto>, ex=" + ex.getMessage()
					+ ", subStr=" + subStr, "", "ReadSet");
		}
		return res;
	}

	public static List<FullDto> getEqualsByMeter(List<FullDto> set, String subStr) throws Exception {
		// origin - 07.01.2024, last edit - 13.06.2025
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			Stream<FullDto> basicStream = set.stream();
			basicStream.filter(n -> n.meter.toLowerCase().equals(subStr.toLowerCase())).forEach((x) -> res.add(x));
		} catch (Exception ex) {
			WB.addLog("ReadSet.getEqualsByMeter(List<FullDto>, String):List<FullDto>, ex=" + ex.getMessage(), "",
					"ReadSet");
		}
		return res;
	}

	public static List<FullDto> getByFilter(List<FullDto> set, FullDto filter) throws Exception {
		// origin - 08.01.2024, last edit - 13.06.2025
		List<FullDto> res = new ArrayList<FullDto>();
		List<FullDto> tmp = set;
		String allFilter = "";
		try {
			if (filter.more.isEmpty() == false) {
				allFilter = allFilter + "filter.more=" + filter.more + ", ";
				tmp = ReadSet.getContainsByMore(tmp, filter.more);
			}
			if (filter.code.isEmpty() == false) {
				allFilter = allFilter + "filter.code=" + filter.code + ", ";
				tmp = ReadSet.getEqualsByCode(tmp, filter.code);
			}
			if (filter.role.isEmpty() == false) {
				allFilter = allFilter + "filter.role=" + filter.role + ", ";
				tmp = ReadSet.getEqualsByRole(tmp, filter.role);
			}
			if (filter.meter.isEmpty() == false) {
				allFilter = allFilter + "filter.meter=" + filter.meter + ", ";
				tmp = ReadSet.getEqualsByMeter(tmp, filter.meter);
			}
		} catch (Exception ex) {
			WB.addLog("ReadSet.getByFilter(List<FullDto>, FullDto):List<FullDto>, ex=" + ex.getMessage(), "",
					"ReadSet");
		}
		res = tmp;
		return res;
	}

	public static FullDto getChrono(LocalDate calcDate, List<FullDto> subsetGlobalBasic) throws Exception {
		// origin - 09.01.2024, last edit - 02.05.2026
		FullDto res = new FullDto();
		LocalDate currDate1;
		LocalDate currDate2;
		try {
			for (var currDto : subsetGlobalBasic) {
				currDto.fix();
//				if ((currDto.meter.isEmpty()) && (currDto.unit.isEmpty())) {
//					continue;
//				}

				// skip empty row-separator in DatabaseGlobal
				if ((currDto.id.isEmpty()) && (currDto.code.isEmpty()) && (currDto.description.isEmpty())) {
					continue;
				}

				if ((currDto.date1.isEmpty()) && (currDto.date2.isEmpty())) {
					res = currDto;
				}

				currDate1 = DateTool.getLocalDate(currDto.date1);// left border in data
				currDate2 = DateTool.getLocalDate(currDto.date2);// right border in data
				// tmp = currDto;

				if (currDate1.isAfter(calcDate)) {
					continue;
				}

				if (currDate1.isBefore(calcDate)) {// because for curr year may be not be actual data
					res = currDto;
				}

				if (currDate1 == calcDate) {// left border hit
					res = currDto;
					break;
				}
				if (currDate2 == calcDate) {// right border hit
					res = currDto;
					break;
				}

				if ((currDate1.isBefore(calcDate)) && (currDto.date2.isEmpty())) {
					res = currDto;
				}

				if ((currDate1.isBefore(calcDate)) && // range from left border to right border hit
						(currDate2.isAfter(calcDate))) {
					res = currDto;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("ReadSet.getChrono(LocalDate, List<FullDto>):FullDto, ex=" + ex.getMessage(), "", "ReadSet");
		}
		return res;
	}

	public static FullDto getFilter(String subStrCode, String subStrMeter) throws Exception {
		// origin - 09.01.2024, last edit - 13.06.2025
		FullDto res = new FullDto();
		try {
			if (subStrCode.isEmpty() == false) {
				res.code = subStrCode;
			}
			if (subStrMeter.isEmpty() == false) {
				res.meter = subStrMeter;
			}
		} catch (Exception ex) {
			WB.addLog("ReadSet.getFilter(String, String):FullDto, ex=" + ex.getMessage(), "", "ReadSet");
		}
		return res;
	}

	private ReadSet() throws Exception {
		// origin - 05.10.2024, last edit - 24.11.2024
	}

	public static void test() throws Exception {
		// origin - 05.10.2024, last edit - 13.06.2025
		try {

		} catch (

		Exception ex) {
			WB.addLog("ReadSet.test():void, ex=" + ex.getMessage(), "", "ReadSet");
		}
	}
}