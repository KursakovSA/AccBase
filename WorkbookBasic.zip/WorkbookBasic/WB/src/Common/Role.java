public class Role {
	// origin - 06.12.2023, last edit - 15.09.2025
	// service fields
	public boolean isValid, isExist;
	// common fields
	public String table, src, id, parent, date1, date2, code, description, more, fullName, comment;
	// special fields
	public static String priceExchangeCurrency, accountStandardTable;
	public String expectedUnit;

	static {
		Role.priceExchangeCurrency = "Role.Price.ExchangeCurrency";
		Role.accountStandardTable = "Role.Account.AccTable";
		//Role.dealMove = "Role.Deal.Move";
		//Role.dealProlongation = "Role.Deal.Prolongation";
		//Role.dealTerm = "Role.Deal.Term";
		//Role.dealPool = "Role.Deal.Pool";
		//Role.dealAccrual = "Role.Deal.Accrual";
		//Role.assetJewel = "Role.Asset.Jewel"; // sectoral Pawnshop
		//Role.assetDefect = "Role.Asset.Defect";
		//Role.faceFA = "Role.Face.FA";
		//Role.faceAddress = "Role.Face.Address";
		//Role.faceStaffTable = "Role.Face.StaffTable";
		//Role.faceStaff = "Role.Face.Staff";
		//Role.faceUser = "Role.Face.User";
		//Role.faceCrew = "Role.Face.Crew";
		//Role.faceJobTurn = "Role.Face.JobTurn";
		//Role.faceJobMap = "Role.Face.JobMap";
		//Role.faceJobDaily = "Role.Face.JobDaily";
		//Role.faceContact = "Role.Face.Contact";
		//Role.faceDaily = "Role.Face.Daily";
		//Role.faceReg = "Role.Face.Reg";
		//Role.dealPawn = "Role.Deal.Pawn";
		//Role.dealPawnDoc = "Role.Deal.PawnDoc";
		//Role.storeBasic = "Role.Store.Basic";
		//Role.storeDepartment = "Role.Store.Department";
		//Role.storeCash = "Role.Store.Cash";
		//Role.storeBank = "Role.Store.Bank";
		//Role.storePoint = "Role.Store.Point";
		try {
		} catch (Exception ex) {
			WB.addLog("Role.static ctor, ex=" + ex.getMessage(), "", "Role");
		}
	}

	private void isExist() throws Exception {
		// origin - 17.12.2024, last edit - 07.09.2025
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdFilter(this.code), "Role");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.date1 = DefVal.setCustom(DateTool.getNow().toString(), dto.date1);// this.date1,
				this.date2 = DefVal.setCustom(this.date2, dto.date2);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.parent = DefVal.setCustom(this.parent, dto.parent);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.getFieldFromMore();

				this.isExist = true;
			}
		} catch (Exception ex) {
			WB.addLog("Role.isExist():void, ex=" + ex.getMessage(), "", "Role");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 12.08.2025, last edit - 12.08.2025
		try {
			this.expectedUnit = MoreVal.getFieldByKey(this.more, "ExpectedUnit");
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("Deal.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Deal");
		}
	}

	public Role(String Id) throws Exception {
		// origin - 06.12.2023, last edit - 11.08.2025
		this.clear();
		this.src = Id;
		if (Id.isEmpty() == false) {
			this.id = this.code = Id;
		}
		this.isExist();
	}

	public Role() throws Exception {
		// origin - 06.12.2023, last edit - 19.05.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 09.12.2024, last edit - 06.09.2025
		try {
			this.isValid = true;
			this.isExist = false;
			this.table = "Role";
			this.fullName = this.comment = this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.more = "";
			this.expectedUnit = "";
		} catch (Exception ex) {
			WB.addLog("Role.clear()(:void, ex=" + ex.getMessage(), "", "Role");
		}
	}

	public String toString() {
		// origin - 27.09.2024, last edit - 12.08.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 06.12.2023, last edit - 14.06.2025
		try {

//			// ctor (String)
//			WB.addLog2("Role.test.ctor(String)", "", "Role");
//			for (var tmp : new String[] { "", "Role.Asset", "Role.tralala", "Role.Deal" }) {
//				WB.addLog2("Role.test.ctor(String)=" + new Role(tmp), "", "Role");
//			}

		} catch (Exception ex) {
			WB.addLog("Role.test():void, ex=" + ex.getMessage(), "", "Role");
		}
	}
}