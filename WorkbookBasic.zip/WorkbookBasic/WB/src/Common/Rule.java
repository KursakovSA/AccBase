import java.util.ArrayList;
import java.util.List;

public final class Rule { // TODO
	// origin - 11.04.2026, last edit - 11.04.2026
	// common fields
	public String table, src, id, parent, date1, date2, face1, face2, face, slice, code, description;
	public String geo, sign, account, asset, deal, item, debt, role, info, meter, meterValue, unit, more, mark, defect;
	// special fields
	public List<FullDto> lowerList, upperList;
	public String fullName, comment;

	public boolean check(List<String> listStrCheck) throws Exception {
		// origin - 12.04.2026, last edit - 12.04.2026
		boolean res = false;
		try {
			var count = 0;
			for (var curr : listStrCheck) {
				if (this.check(curr) == true) {
					count = count + 1;
				}
			}

			if (count == listStrCheck.size()) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("Rule.check(List<String>):boolean, ex=" + ex.getMessage(), "", "Rule");
		}
		return res;
	}

	public boolean check(String strCheck) throws Exception {
		// origin - 01.08.2024, last edit - 16.04.2026
		boolean res = false;
		try {
			var checkPattern = this.info + "+" + this.unit;
			switch (checkPattern) {
			case "Info.Process.Contains+Unit.TextFile" -> res = this.checkContainsTextFile(strCheck);
			case "Info.Process.Contains+Unit.TextList" -> res = this.checkContainsTextList(strCheck);
			// default -> res = "";
			}
		} catch (Exception ex) {
			WB.addLog("Rule.check(String):boolean, ex=" + ex.getMessage(), "", "Rule");
		}
		return res;
	}

	private boolean checkContainsTextList(String strCheck) throws Exception {
		// origin - 16.04.2026, last edit - 16.04.2026
		boolean res = false;
		try {
			var tmp = List.of(this.meterValue.split(";"));
			var checkPattern = this.meter + "+" + tmp.contains(strCheck);

			switch (checkPattern) {
			case "Meter.Listed+true" -> res = true;
			case "Meter.NotListed+false" -> res = true;
			// default -> res = "";
			}
		} catch (Exception ex) {
			WB.addLog("Rule.checkContainsTextList(String):boolean, ex=" + ex.getMessage(), "", "Rule");
		}
		return res;
	}

	private boolean checkContainsTextFile(String strCheck) throws Exception {
		// origin - 12.04.2026, last edit - 12.08.2026
		boolean res = false;
		try {
			//var tmp = WB.commonDocDir + File.separator + this.meterValue;
			var tmp = InOut.getStrPathFileByFileNameInAppDir(this.meterValue);
			var checkPattern = this.meter + "+" + CSV.contains(tmp, strCheck);

			switch (checkPattern) {
			case "Meter.Listed+true" -> res = true;
			case "Meter.NotListed+false" -> res = true;
			// default -> res = "";
			}
		} catch (Exception ex) {
			WB.addLog("Rule.checkContainsTextFile(String):boolean, ex=" + ex.getMessage(), "", "Rule");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 11.04.2026, last edit - 11.04.2026
		try {
		} catch (Exception ex) {
			WB.addLog("Rule.validate():void, ex=" + ex.getMessage(), "", "Rule");
		}
	}

	private void isExist() throws Exception {
		// origin - 11.04.2026, last edit - 12.08.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdRoleFilter(this.id, "Role.Process.Rule"),
					"Process");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.id = dto.id;
				this.parent = dto.parent;
				this.date1 = dto.date1;
				this.date2 = dto.date2;
				this.face1 = dto.face1;
				this.face2 = dto.face2;
				this.slice = dto.slice;
				this.code = dto.code;
				this.description = dto.description;
				this.geo = dto.geo;
				this.sign = dto.sign;
				this.account = dto.account;
				this.asset = dto.asset;
				this.deal = dto.deal;
				this.item = dto.item;
				this.debt = dto.debt;
				this.role = dto.role;
				this.info = dto.info;
				this.meter = dto.meter;
				this.meterValue = dto.meterValue;
				this.unit = dto.unit;
				this.more = dto.more;
				this.mark = dto.mark;
				this.upperList = FullDto.getUpper(this.table, this.parent);
				this.lowerList = FullDto.getLower(this.table, this.id);
				this.getFieldFromMore();
			} else {
				this.clear();
			}
		} catch (Exception ex) {
			WB.addLog("Rule.isExist():void, ex=" + ex.getMessage(), "", "Rule");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 11.04.2026, last edit - 11.04.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
		} catch (Exception ex) {
			WB.addLog("Rule.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Rule");
		}
	}

	public Rule(String Src) throws Exception {
		// origin - 11.04.2026, last edit - 11.04.2026
		this.clear();
		this.src = Src;
		if (Src.isEmpty() == false) {
			this.id = Etc.fixTrim(Src);
		}
		this.isExist();
		this.validate();
	}

	public Rule() throws Exception {
		// origin - 11.04.2026, last edit - 11.04.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 11.04.2026, last edit - 11.04.2026
		try {
			this.table = "Process";
			this.src = this.id = this.parent = this.face1 = this.face2 = "";
			this.face = this.slice = this.date1 = this.date2 = this.code = this.description = "";
			this.sign = this.account = this.geo = this.role = this.info = this.meter = this.meterValue = "";
			this.unit = this.more = this.mark = this.asset = this.deal = this.defect = "";
			this.fullName = this.comment = "";
			this.lowerList = new ArrayList<FullDto>();
			this.upperList = new ArrayList<FullDto>();
		} catch (Exception ex) {
			WB.addLog("Rule.clear():void, ex=" + ex.getMessage(), "", "Rule");
		}
	}

	public String toString() {
		// origin - 11.04.2026, last edit - 11.04.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", face1 ", this.face1);
			res = res + Fmtr.addIfNotEmpty(", face2 ", this.face2);
			res = res + Fmtr.addIfNotEmpty(", face ", this.face);
			res = res + Fmtr.addIfNotEmpty(", slice ", this.slice);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", sign ", this.sign);
			res = res + Fmtr.addIfNotEmpty(", account ", this.account);
			res = res + Fmtr.addIfNotEmpty(", geo ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", role ", this.role);
			res = res + Fmtr.addIfNotEmpty(", info ", this.info);
			res = res + Fmtr.addIfNotEmpty(", meter ", this.meter);
			res = res + Fmtr.addIfNotEmpty(", meterValue ", this.meterValue);
			res = res + Fmtr.addIfNotEmpty(", unit ", this.unit);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", mark ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", asset ", this.asset);
			res = res + Fmtr.addIfNotEmpty(", deal ", this.deal);
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", upperList ", this.upperList.size());
			res = res + Fmtr.addIfNotEmpty(", lowerList ", this.lowerList.size());
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 11.04.2026, last edit - 16.04.2026
		try {

//			WB.addLog2("Rule.test.checkContainsTextList(List<String>):boolean", "", "Rule");
//			for (var tmp1 : new String[] { "Process.Rule.Text.Listed1", "Process.Rule.Text.NotListed1" }) {
//				var tmp2 = new Rule(tmp1);
//				WB.addLog2("Rule.test.ctor(tmp1)=" + tmp2 + ", tmp1=" + tmp1, "", "Rule");
//				for (var tmp3 : List.of("", "100", "206", "333")) {
//					WB.addLog2("Rule.test.check(tmp3)=" + tmp2.check(tmp3) + ", tmp3=" + tmp3 + ", tmp2.meterValue="
//							+ tmp2.meterValue, "", "Rule");
//				}
//			}

//			WB.addLog2("Rule.test.check(List<String>):boolean", "", "Rule");
//			for (var tmp1 : new String[] { "Process.Rule.Face.NotListed1", "Process.Rule.Face.Listed1" }) {
//				WB.addLog2("Rule.test.ctor(tmp1)=" + new Rule(tmp1) + ", tmp1=" + tmp1, "", "Rule");
//				for (var tmp2 : List.of("111,222", "333,444", "111", "444")) {
//					var tmp3 = List.of(tmp2.split(","));
//					WB.addLog2("Rule.test.check(tmp2)=" + new Rule(tmp1).check(tmp3) + ", tmp3=" + tmp3, "", "Rule");
//				}
//			}

//			WB.addLog2("Rule.test.check(String):boolean", "", "Rule");
//			for (var tmp1 : new String[] { "Process.Rule.Face.NotListed1", "Process.Rule.Face.Listed1" }) {
//				WB.addLog2("Rule.test.ctor(tmp1)=" + new Rule(tmp1) + ", tmp1=" + tmp1, "", "Rule");
//				for (var tmp2 : new String[] { "111", "222", "333", "444" }) {
//					WB.addLog2("Rule.test.check(tmp2)=" + new Rule(tmp1).check(tmp2) + ", tmp2=" + tmp2, "", "Rule");
//				}
//			}

//			WB.addLog2("Rule.test.ctor(String)", "", "Rule");
//			for (var tmp1 : new String[] { "", "Process.Rule.Face.NotListed1", "Process.Rule.Face.Listed1",
//					"Process.Rule.tralala", "Process.Rule.Face.NotStopListed1", "Process.Rule.Face.StopListed1",
//					"Process.Rule.Text.Listed1" }) {
//				WB.addLog2("Rule.test.ctor(String)=" + new Rule(tmp1) + ", tmp1=" + tmp1, "", "Rule");
//			}

		} catch (Exception ex) {
			WB.addLog("Rule.test():void, ex=" + ex.getMessage(), "", "rule");
		}
	}
}