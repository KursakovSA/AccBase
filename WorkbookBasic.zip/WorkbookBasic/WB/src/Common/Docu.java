import java.util.ArrayList;
import java.util.List;

public final class Docu {
	// origin - 12.04.2026, last edit - 26.04.2026
	public String table, src, id, parent, date1, date2, code, description, geo, role, info, unit, more, mark;
	public String defect, fullName, comment;
	public List<TagVal> tagList; // TOTHINK
	public List<FullDto> lowerList, upperList;
	public String cat; // TOTHINK
	public boolean isNew;
	public static List<String> srcDir;

	static {
		try {
			Docu.srcDir = List.of(WB.mediaDir, WB.commonDocDir, WB.docuDir);
		} catch (Exception ex) {
			WB.addLog("Docu.static ctor, ex=" + ex.getMessage(), "", "Docu");
		}
	}

	public static List<Docu> getByDir() throws Exception {
		// origin - 15.04.2026, last edit - 16.04.2026
		List<Docu> res = new ArrayList<Docu>();
		try {
			for (var curr : Docu.srcDir) {
				res.addAll(Docu.getByDir(curr));
			}
		} catch (Exception ex) {
			WB.addLog("Docu.getByDir():List<Docu>, ex=" + ex.getMessage(), "", "Docu");
		}
		return res;
	}

	public static List<Docu> getByDir(String dir) throws Exception {
		// origin - 16.04.2026, last edit - 25.04.2026
		List<Docu> res = new ArrayList<Docu>();
		try {
			var tmp = InOut.getPathFileByDir(dir);
			for (var path : tmp) {
				res.add(new Docu(path));
			}
		} catch (Exception ex) {
			WB.addLog("Docu.getByDir(String):List<Docu>, ex=" + ex.getMessage(), "", "Docu");
		}
		return res;
	}

	public static List<Docu> getByTag(String tag) throws Exception {
		// origin - 14.04.2026, last edit - 15.04.2026
		List<Docu> res = new ArrayList<Docu>();
		try {
			var docuList = Docu.get();
			for (var curr1 : docuList) {
				for (var curr2 : curr1.tagList) {
					if (Etc.strContains(curr2.id, tag)) {
						res.add(curr1);
						break;
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Docu.getByTag(String):List<Docu>, ex=" + ex.getMessage(), "", "Docu");
		}
		return res;
	}

	public static List<Docu> get() throws Exception {
		// origin - 14.04.2026, last edit - 14.04.2026
		List<Docu> res = new ArrayList<Docu>();
		try {
			var assetList = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleFilter("Role.Asset.Docu"), "Asset");
			if (assetList.size() != 0) {
				for (var curr : assetList) {
					if (curr.id.isEmpty() == false) {
						res.add(new Docu(curr.id));
					}
				}
			}
		} catch (Exception ex) {
			WB.addLog("Docu.get():List<Docu>, ex=" + ex.getMessage(), "", "Docu");
		}
		return res;
	}

	private void validate() throws Exception { // TODO
		// origin - 14.04.2026, last edit - 23.05.2026
		try {
			this.defect = Fmtr.addIfStrEmpty(this.defect, this.code, "empty code; ");
			this.defect = Fmtr.addIfStrEmpty(this.defect, this.description, "empty description; ");
		} catch (Exception ex) {
			WB.addLog("Docu.validate():void, ex=" + ex.getMessage(), "", "Docu");
		}
	}

	private FullDto getFullDto() throws Exception {
		// origin - 25.04.2026, last edit - 25.04.2026
		FullDto res = new FullDto();
		try {
			res.table = this.table;
			res.id = this.id;
			res.date1 = this.date1;
			res.code = this.code;
			res.description = this.description;
			res.geo = this.geo;
			res.role = this.role;
			res.info = this.info;
			res.unit = this.unit;
			res.mark = this.mark;
		} catch (Exception ex) {
			WB.addLog("Docu.getFullDto():FullDto, ex=" + ex.getMessage(), "", "Docu");
		}
		return res;
	}

	public static List<Docu> writeNew(List<Docu> docuList) throws Exception { // TODO
		// origin - 25.04.2026, last edit - 26.04.2026
		List<Docu> res = new ArrayList<Docu>();
		List<FullDto> updateDtoList = new ArrayList<FullDto>();
		try {
			for (var curr : docuList) {
				if (curr.isNew) {
					res.add(curr);
					updateDtoList.add(curr.getFullDto());
				}
			}

			if (updateDtoList.size() != 0) {
				DAL.setReplaceInto(WB.lastConnWork, updateDtoList);
			}
		} catch (Exception ex) {
			WB.addLog("Docu.writeNew(List<Docu>):List<Docu>, ex=" + ex.getMessage(), "", "Docu");
		}
		return res;
	}

	private void getNew() throws Exception {
		// origin - 25.04.2026, last edit - 25.04.2026
		try {
			this.isNew = true;
			this.table = "Asset";
			this.id = this.src;
			this.date1 = DateTool.formatter2(DateTool.getNow2()).toString(); // ex. "2026-12-25T12:45:54"
			this.code = InOut.getFileName(this.id);
			this.description = this.id;
			this.geo = Geo.currCountry.id;
			this.role = "Role.Asset.Docu";
			this.info = "Info.Generic.Basic";
			this.unit = "Unit.DocFile";
			this.mark = "Mark.CD";
		} catch (Exception ex) {
			WB.addLog("Docu.getNew():void, ex=" + ex.getMessage(), "", "Docu");
		}
	}

	private void isExist() throws Exception {
		// origin - 14.04.2026, last edit - 25.04.2026
		try {
			var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getIdRoleFilter(this.id, "Role.Asset.Docu"), "Asset");
			if (listDto.size() != 0) {
				var dto = listDto.getFirst();
				this.date1 = DefVal.setCustom(this.date1, dto.date1);
				this.date2 = DefVal.setCustom(this.date2, dto.date2);
				this.code = DefVal.setCustom(this.code, dto.code);
				this.code = DefVal.setCustom(this.code, dto.id);
				this.parent = DefVal.setCustom(this.parent, dto.parent);
				this.description = DefVal.setCustom(this.description, dto.description);
				this.geo = DefVal.setCustom(this.geo, dto.geo);
				this.role = DefVal.setCustom(this.role, dto.role);
				this.info = DefVal.setCustom(this.info, dto.info);
				this.unit = DefVal.setCustom(this.unit, dto.unit);
				this.more = DefVal.setCustom(this.more, dto.more);
				this.mark = DefVal.setCustom(this.mark, dto.mark);
				this.upperList = FullDto.getUpper(this.table, this.parent);
				this.lowerList = FullDto.getLower(this.table, this.id);
				this.getFieldFromMore();
			}

			if (listDto.size() == 0) {
				this.parent = this.code = this.description = this.geo = this.role = this.info = this.unit = "";
				this.getNew();
			}
		} catch (Exception ex) {
			WB.addLog("Docu.isExist():void, ex=" + ex.getMessage(), "", "Docu");
		}
	}

	private void getFieldFromMore() throws Exception {
		// origin - 14.04.2026, last edit - 15.04.2026
		try {
			this.fullName = MoreVal.getFieldByKey(this.more, "FullName");
			this.comment = MoreVal.getFieldByKey(this.more, "Comment");
			this.tagList = TagVal.getList(this.more);
			this.cat = MoreVal.getFieldByKey(this.more, "Cat");
		} catch (Exception ex) {
			WB.addLog("Docu.getFieldFromMore():void, ex=" + ex.getMessage(), "", "Docu");
		}
	}

	public Docu(String Id) throws Exception {
		// origin - 14.04.2026, last edit - 14.04.2026
		this.clear();
		this.src = this.id = Id;
		this.isExist();
		this.validate();
	}

	public Docu() throws Exception {
		// origin - 14.04.2026, last edit - 14.04.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 14.04.2026, last edit - 25.04.2026
		try {
			this.table = "Asset";
			this.src = this.table = this.id = this.parent = this.date1 = this.date2 = this.code = this.description = "";
			this.geo = this.role = this.info = this.unit = this.more = this.mark = this.defect = this.cat = "";
			this.lowerList = new ArrayList<FullDto>();
			this.upperList = new ArrayList<FullDto>();
			this.tagList = new ArrayList<TagVal>();
			this.fullName = this.comment = "";
			this.isNew = false;
		} catch (Exception ex) {
			WB.addLog("Docu.clear():void, ex=" + ex.getMessage(), "", "Docu");
		}
	}

	public String toString() {
		// origin - 14.04.2026, last edit - 15.04.2026
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", ", this.unit);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more.length());
			res = res + Fmtr.addIfNotEmpty(", defect ", this.defect);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = res + Fmtr.addIfNotEmpty(", upperList ", this.upperList.size());
			res = res + Fmtr.addIfNotEmpty(", lowerList ", this.lowerList.size());
			res = res + Fmtr.addIfNotEmpty(", tagList ", this.tagList.size());
			res = res + Fmtr.addIfNotEmpty(" cat ", this.cat);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 12.04.2026, last edit - 26.04.2026
		try {

//			{
//				WB.addLog2("Docu.test.writeNew(List<Docu>):List<Docu>", "", "Docu");
//				var tmp1 = Docu.getByDir();
//				var tmp2 = Docu.writeNew(tmp1);
//				WB.addLog2("Docu.test.writeNew(List<Docu>):List<Docu>, res.size=" + tmp2.size(), "", "Docu");
//				WB.log(tmp2, "Docu");
//			}

//			{
//				WB.addLog2("Docu.test.getByDir():List<Docu>", "", "Docu");
//				var tmp1 = Docu.getByDir();
//				WB.addLog2("Docu.test.getByDir():List<Docu>, res.size=" + tmp1.size(), "", "Docu");
//				WB.log(tmp1, "Docu");
//			}

//			WB.addLog2("Docu.test.getByTag(String):List<Docu>", "", "Docu");
//			for (var tmp1 : new String[] { "AnnualMeeting", "Арматура12", "Docu.tralala" }) {
//				var tmp2 = Docu.getByTag(tmp1);
//				WB.addLog2("Docu.test.getByTag(String):List<Docu>, res.size=" + tmp2.size() + ", tmp1=" + tmp1, "",
//						"Docu");
//				WB.log(tmp2, "Docu");
//			}

//			WB.addLog2("Docu.test.ctor(String)", "", "Docu");
//			for (var tmp1 : new String[] { "Asset.Docu.Test.1", "Asset.Docu.Test.2", "Asset.Docu.tralala" }) {
//				WB.addLog2("Docu.test.ctor(String)=" + new Docu(tmp1), "", "Docu");
//			}

		} catch (Exception ex) {
			WB.addLog("Docu.test():void, ex=" + ex.getMessage(), "", "Docu");
		}
	}
}