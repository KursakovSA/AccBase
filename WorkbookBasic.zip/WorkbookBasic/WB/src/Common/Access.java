public final class Access {
	// origin - 02.11.2024, last edit - 12.10.2025
	public String src, id, parent, date1, date2, code, description, geo, role, info, mark, more;
	public String fullName, comment;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Access.static ctor, ex=" + ex.getMessage(), "", "Access");
		}
	}

	public static boolean getCurr(String date1, String userId, String actionId) throws Exception {
		// origin - 09.10.2025, last edit - 12.10.2025
		boolean res = false;
		try {
			var userFaceDto = User.getCurr(date1, Face.currFA.code, userId);

			switch (userFaceDto.access.code) {
			case "FullAccess" : return res = true;
			//default : res = false;
			}

			switch (actionId) {
			case "Write":
				// if (actionId == "Write") {
				switch (userFaceDto.access.description) {
				case "NoRestriction" -> res = true;
				case "OnLyRead" -> res = false;
				case "DocRead" -> res = false;
				//default -> res = false;
				}

				// if (actionId == "Read") {
			case "Read":
				res = true;
				// default:
				// res = false;
				// }
				
			//default : res = true;
			}
		} catch (Exception ex) {
			WB.addLog("Access.getCurr(3String):boolean, ex=" + ex.getMessage(), "", "Access");
		}
		return res;
	}

	private void correct() throws Exception { // TODO
		// origin - 10.10.2025, last edit - 10.10.2025
		try {
			if (this.code.isEmpty()) {
				this.code = "FullAccess";
				// WB.addLog2("Access.correct(), this.code=" + this.code, "", "Access");
			}

			if ((Etc.strEquals(this.code, "FullAccess")) & (this.description.isEmpty())) {
				this.description = "NoRestriction";
				// WB.addLog2("Access.correct(), this.description=" + this.description, "",
				// "Access");
			}

			if ((Etc.strEquals(this.code, "FullAccess") == false) & (this.description.isEmpty())) {
				this.description = this.code;
			}
		} catch (Exception ex) {
			WB.addLog("Access.correct():void, ex=" + ex.getMessage(), "", "Access");
		}
	}

	public Access(String Code, String Description) throws Exception {
		// origin - 09.10.2025, last edit - 10.10.2025
		this.clear();
		this.src = Code + "," + Description;
		this.code = Code;
		this.description = Description;
		this.id = this.code + "," + this.description;
		this.correct();
	}

	public Access(String CodeDescription) throws Exception {
		// origin - 09.10.2025, last edit - 10.10.2025
		this.clear();
		this.src = CodeDescription;
		var tmp = new TwoVal(CodeDescription);
		this.code = tmp.val1;
		this.description = tmp.val2;
		this.id = this.code + "," + this.description;
		this.correct();
	}

	public Access() throws Exception {
		// origin - 09.10.2025, last edit - 09.10.2025
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 09.10.2025, last edit - 10.10.2025
		try {
			this.src = this.id = this.parent = this.date1 = this.date2 = this.code = this.description = this.geo = this.role = "";
			this.info = this.more = this.mark = "";
			this.fullName = this.comment = "";
		} catch (Exception ex) {
			WB.addLog("Access.clear():void, ex=" + ex.getMessage(), "", "Access");
		}
	}

	public String toString() {
		// origin - 09.10.2025, last edit - 10.10.2025
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.geo);
			res = res + Fmtr.addIfNotEmpty(", ", this.role);
			res = res + Fmtr.addIfNotEmpty(", ", this.info);
			res = res + Fmtr.addIfNotEmpty(", fullName ", this.fullName);
			res = res + Fmtr.addIfNotEmpty(", comment ", this.comment);
			res = res + Fmtr.addIfNotEmpty(", ", this.mark);
			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 02.11.2024, last edit - 10.10.2025
		try {

			WB.addLog2("Access.test.getCurr(3String):boolean", "", "Access");
			for (var tmp1 : new String[] { "2023-04-05", "2025-01-31", "2025-02-20", "2025-08-15" }) {
				for (var tmp2 : new String[] { "Face.FA1.User1 , Write", "Face.FA1.User2 , Write",
						"Face.FA1.User1 , Read", "Face.FA1.User2 , Read" }) {
					var tmp3 = new TwoVal(tmp2);
					WB.addLog2(
							"Access.test.getCurr(3String):boolean, res=" + Access.getCurr(tmp1, tmp3.val1, tmp3.val2)
									+ ", date1=" + tmp1 + ", userId=" + tmp3.val1 + ", actionId=" + tmp3.val2,
							"", "Access");
				}
			}

//			WB.addLog2("Access.test.ctor(2String)", "", "Access");
//			for (var tmp1 : new String[] { "", "FullAccess", "OnlyRead", "DocRead" }) {
//				for (var tmp2 : new String[] { "", "NoRestriction" }) {
//					WB.addLog2("Access.test.ctor(2String)=" + new Access(tmp1, tmp2), "", "Access");
//				}
//			}

		} catch (Exception ex) {
			WB.addLog("Access.test():void, ex=" + ex.getMessage(), "", "Access");
		}
	}
}