import java.io.File;
import java.util.List;

public final class Qry {
	// origin - 09.11.2023, last edit - 12.10.2025
	public static String getTableListSQLite, backupCmdSQLite, integrityCheckCmdSQLite, reindexCmdSQLite,
			vacuumCmdSQLite, getWorkbookLastRecordSQLite;

	static {
		try {
			Qry.getTableListSQLite = "SELECT name FROM sqlite_master WHERE type = 'table'";
			Qry.backupCmdSQLite = "vacuum into";
			Qry.integrityCheckCmdSQLite = "PRAGMA integrity_check;";
			Qry.reindexCmdSQLite = "reindex;";
			Qry.vacuumCmdSQLite = "vacuum;";
			Qry.getWorkbookLastRecordSQLite = "SELECT * FROM Workbook ORDER BY Id Desc LIMIT 1000";
		} catch (Exception ex) {
			WB.addLog("Qry.static ctor, ex=" + ex.getMessage(), "", "Qry");
		}
	}

	public static String getUpper(String table, String parent) throws Exception {
		// origin - 03.03.2026, last edit - 03.03.2026
		table = Etc.fixTrim(table);
		parent = Etc.fixTrim(parent);
		String res = " WITH RECURSIVE upper(Id, Parent) AS ( SELECT Id, Parent FROM " + table + " WHERE Id = '" + parent
				+ "' UNION ALL SELECT t.Id, t.Parent FROM " + table + " t "
				+ " JOIN upper a ON t.Id = a.Parent ) SELECT * FROM upper; ";

		return res;
	}

	public static String getLower(String table, String id) throws Exception {
		// origin - 11.05.2025, last edit - 03.03.2026
		table = Etc.fixTrim(table);
		id = Etc.fixTrim(id);
		String res = "WITH RECURSIVE lower AS ( " + "SELECT * FROM " + table + " WHERE Parent = '" + id + "' "
				+ " UNION ALL SELECT t.* FROM " + table + " t JOIN lower s ON t.Parent = s.Id )"
				+ " SELECT * FROM lower;";

		return res;
	}

	public static String getReplaceInto(FullDto dto) throws Exception {
		// origin - 02.02.2024, last edit - 13.06.2025
		String res = "";
		try {
			res = Qry.appender(res, Qry.formatterReplaceInto(dto));
		} catch (Exception ex) {
			WB.addLog("Qry.getReplaceInto(FullDto):String, ex=" + ex.getMessage(), "", "Qry");
		}
		return res;
	}

	public static String formatterReplaceInto(FullDto dto) throws Exception {
		// origin - 04.02.2024, last edit - 13.06.2025
		String res = "REPLACE into " + Etc.fixTrim(dto.table);
		// String res = "INSERT into " + Etc.fixTrim(dto.table); //??variant??
		// String res = "INSERT OR REPLACE into " + dto.table; //??variant??
		try {
			res = res + Qry.getColumnList(dto.table);
			res = res + Qry.getValueList(dto.table, dto);
		} catch (Exception ex) {
			WB.addLog("Qry.formatterReplaceInto(FullDto):String, ex=" + ex.getMessage(), "", "Qry");
		}
		return res;
	}

	private static String getValueList(String table, FullDto dto) throws Exception {
		// origin - 06.06.2024, last edit - 13.07.2026
		String res = "";
		res = res + "values(";

		try {
			if (Etc.strEquals(table, "Account")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtRel(dto.role) + fmtRel(dto.sign)
						+ fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Asset")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtRel(dto.geo) + fmtRel(dto.role)
						+ fmtRel(dto.info) + fmtRel(dto.unit) + fmtVal(dto.more) + fmtRel(dto.mark);
			}
			if (Etc.strEquals(table, "Deal")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtRel(dto.face1) + fmtRel(dto.face2)
						+ fmtRel(dto.face) + fmtVal(dto.date1) + fmtVal(dto.date2) + fmtVal(dto.code)
						+ fmtVal(dto.description) + fmtRel(dto.geo) + fmtRel(dto.role) + fmtRel(dto.info)
						+ fmtVal(dto.more) + fmtRel(dto.mark);
			}
			if (Etc.strEquals(table, "Debt")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtRel(dto.geo) + fmtRel(dto.role)
						+ fmtRel(dto.info) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Face")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtRel(dto.geo) + fmtRel(dto.role)
						+ fmtRel(dto.info) + fmtVal(dto.more) + fmtRel(dto.mark);
			}
			if (Etc.strEquals(table, "Geo")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtRel(dto.role) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Info")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Item")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Mark")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Meter")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtRel(dto.unit) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Price")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtVal(dto.role) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Process")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtRel(dto.face1) + fmtRel(dto.face2)
						+ fmtRel(dto.face) + fmtRel(dto.slice) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtRel(dto.geo) + fmtRel(dto.sign)
						+ fmtRel(dto.account) + fmtRel(dto.asset) + fmtRel(dto.deal) + fmtRel(dto.debt)
						+ fmtRel(dto.item) + fmtRel(dto.role) + fmtRel(dto.info) + fmtRel(dto.meter)
						+ fmtVal(dto.meterValue) + fmtRel(dto.unit) + fmtVal(dto.more) + fmtRel(dto.mark);
			}
			if (Etc.strEquals(table, "Role")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Sign")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Slice")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtVal(dto.more);
			}
			if (Etc.strEquals(dto.table, "Unit")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtRel(dto.role) + fmtVal(dto.more);
			}
			if (Etc.strEquals(table, "Workbook")) {
				res = res + fmtId(dto.id) + fmtRel(dto.parent) + fmtRel(dto.face1) + fmtRel(dto.face2)
						+ fmtRel(dto.face) + fmtRel(dto.slice) + fmtVal(dto.date1) + fmtVal(dto.date2)
						+ fmtVal(dto.code) + fmtVal(dto.description) + fmtRel(dto.geo) + fmtRel(dto.sign)
						+ fmtRel(dto.account) + fmtRel(dto.process) + fmtRel(dto.asset) + fmtRel(dto.deal)
						+ fmtRel(dto.role) + fmtRel(dto.info) + fmtRel(dto.meter) + fmtVal(dto.meterValue)
						+ fmtRel(dto.unit) + fmtVal(dto.more) + fmtRel(dto.mark);
			}
		} catch (Exception ex) {
			WB.addLog("Qry.getValueList(String, FullDto):String, ex=" + ex.getMessage(), "", "Qry");
		}

		res = res + ")";
		return res;
	}

	private static String fmtVal(String maybeValue) throws Exception {
		// origin - 07.06.2024, last edit - 13.06.2025
		String res = "";
		try {
			res = res + ",";
			maybeValue = Etc.fixTrim(maybeValue);
			res = res + "'" + maybeValue + "'";
		} catch (Exception ex) {
			WB.addLog("Qry.fmtVal(String):String, ex=" + ex.getMessage(), "", "Qry");
		}
		return res;
	}

	private static String fmtId(String maybeValue) throws Exception {
		// origin - 07.06.2024, last edit - 13.06.2025
		String res = "";
		try {
			maybeValue = Etc.fixTrim(maybeValue);
			res = res + "'" + maybeValue + "'";
		} catch (Exception ex) {
			WB.addLog("Qry.fmtId(String):String, ex=" + ex.getMessage(), "", "Qry");
		}
		return res;
	}

	private static String fmtRel(String maybeValue) throws Exception {
		// origin - 06.06.2024, last edit - 13.06.2025
		String res = "";
		try {
			maybeValue = Etc.fixTrim(maybeValue);
			res = res + ",";
			if (maybeValue.isEmpty()) {
				res = res + "null";
			} else {
				res = res + "'" + maybeValue + "'";
			}
		} catch (Exception ex) {
			WB.addLog("Qry.fmtRel(String):String, ex=" + ex.getMessage(), "", "Qry");
		}
		return res;
	}

	private static String getColumnList(String table) throws Exception {
		// origin - 06.06.2024, last edit - 13.07.2026
		String res = "";
		try {
			if (Etc.strContains(table, "Account")) {
				res = res + "(Id, Parent, Date1, Date2, Code, Description, Role, Sign, More) ";
			}
			if (Etc.strContains(table, "Asset")) {
				res = res + "(Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, Unit, More, Mark) ";
			}
			if (Etc.strContains(table, "Deal")) {
				res = res
						+ "(Id, Parent, Face1, Face2, Face, Date1, Date2, Code, Description, Geo, Role, Info, More, Mark) ";
			}
			if (Etc.strContains(table, "Debt")) {
				res = res + "(Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) ";
			}
			if (Etc.strContains(table, "Face")) {
				res = res + "(Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More, Mark) ";
			}
			if (Etc.strContains(table, "Geo")) {
				res = res + "(Id, Parent, Date1, Date2, Code, Description, Role, More) ";
			}
			if (Etc.strContains(table, "Info")) {
				res = res + "(Id, Parent, Date1, Date2, Code, Description, More) ";
			}
			if (Etc.strContains(table, "Item")) {
				res = res + "(Id, Parent, Date1, Date2, Code, Description, More) ";
			}
			if (Etc.strContains(table, "Mark")) {
				res = res + "(Id, Parent, Date1, Date2, Code, Description, More) ";
			}
			if (Etc.strContains(table, "Meter")) {
				res = res + "(Id, Parent, Date1, Date2, Code, Description, Unit, More) ";
			}
			if (Etc.strContains(table, "Price")) {
				res = res + "(Id, Parent, Date1, Date2, Code, Description, Role, More) ";
			}
			if (Etc.strContains(table, "Process")) {
				res = res
						+ "(Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Geo, Sign, Account, Asset, Deal, Item, Debt, Role, Info, Meter, MeterValue, Unit, More, Mark) ";
			}
			if (Etc.strContains(table, "Role")) {
				res = res + "(Id, Parent, Date1, Date2, Code, Description, More) ";
			}
			if (Etc.strContains(table, "Sign")) {
				res = res + "(Id, Parent, Date1, Date2, Code, Description, More) ";
			}
			if (Etc.strContains(table, "Slice")) {
				res = res + "(Id, Parent, Date1, Date2, Code, Description, More) ";
			}
			if (Etc.strContains(table, "Unit")) {
				res = res + "(Id, Parent, Date1, Date2, Code, Description, Role, More) ";
			}
			if (Etc.strContains(table, "Workbook")) {
				res = res
						+ "(Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Geo, Sign, Account, Process, Asset, Deal, Role, Info, Meter, MeterValue, Unit, More, Mark) ";
			}
		} catch (Exception ex) {
			WB.addLog("Qry.getColumnList(String):String, ex=" + ex.getMessage(), "", "Qry");
		}
		return res;
	}

	public static String getKindAnalyst1Filter(String kindAnalyst) throws Exception {
		// origin - 30.04.2026, last edit - 30.04.2026
		String res = kindAnalyst + " IS NOT NULL AND " + kindAnalyst + " != ''";
		return res;
	}

	public static String getCodeRoleFilter(String variableStr1, String variableStr2) throws Exception {
		// origin - 28.04.2025, last edit - 28.04.2025
		String res = "Code = '" + variableStr1 + "'" + " AND " + "Role = '" + variableStr2 + "'";
		return res;
	}

	public static String getParentCodeInfoFilter(String variableStr1, String variableStr2, String variableStr3)
			throws Exception {
		// origin - 30.04.2025, last edit - 30.04.2025
		String res = "Parent = '" + variableStr1 + "'" + " AND " + "Code = '" + variableStr2 + "'" + " AND "
				+ "Info = '" + variableStr3 + "'";
		return res;
	}

	public static String getParentCodeRoleInfoFilter(String variableStr1, String variableStr2, String variableStr3,
			String variableStr4) throws Exception {
		// origin - 10.05.2025, last edit - 10.05.2025
		String res = "Parent = '" + variableStr1 + "'" + " AND " + "Code = '" + variableStr2 + "'" + " AND "
				+ "Role = '" + variableStr3 + "'" + " AND " + "Info = '" + variableStr4 + "'";
		return res;
	}

	public static String getParentCodeRoleFilter(String variableStr1, String variableStr2, String variableStr3)
			throws Exception {
		// origin - 16.03.2025, last edit - 19.03.2025
		String res = "Parent = '" + variableStr1 + "'" + " AND " + "Code = '" + variableStr2 + "'" + " AND "
				+ "Role = '" + variableStr3 + "'";
		return res;
	}

	public static String getParentInfoUnitFilter(String variableStr1, String variableStr2, String variableStr3)
			throws Exception {
		// origin - 30.04.2025, last edit - 30.04.2025
		String res = "Parent = '" + variableStr1 + "'" + " AND " + "Info = '" + variableStr2 + "'" + " AND "
				+ "Unit = '" + variableStr3 + "'";
		return res;
	}

	public static String getParentRoleUnitFilter(String variableStr1, String variableStr2, String variableStr3)
			throws Exception {
		// origin - 05.10.2025, last edit - 05.10.2025
		String res = "Parent = '" + variableStr1 + "'" + " AND " + "Role = '" + variableStr2 + "'" + " AND "
				+ "Unit = '" + variableStr3 + "'";
		return res;
	}

	public static String getParentInfoFilter(String variableStr1, String variableStr2) throws Exception {
		// origin - 07.04.2025, last edit - 07.04.2025
		String res = "Parent = '" + variableStr1 + "' AND Info = '" + variableStr2 + "'";
		return res;
	}

	public static String getParentRoleGeoFilter(String varStr1, String varStr2, String varStr3) throws Exception {
		// origin - 07.09.2026, last edit - 07.09.2026
		String res = "Parent = '" + varStr1 + "' AND Role = '" + varStr2 + "' AND Geo = '" + varStr3 + "'";
		return res;
	}

	public static String getParentRoleInfoFilter(String variableStr1, String variableStr2, String variableStr3)
			throws Exception {
		// origin - 06.05.2025, last edit - 06.05.2025
		String res = "Parent = '" + variableStr1 + "' AND Role = '" + variableStr2 + "' AND Info = '" + variableStr3
				+ "'";
		return res;
	}

	public static String getParentRoleFilter(String variableStr1, String variableStr2) throws Exception {
		// origin - 16.03.2025, last edit - 23.03.2025
		String res = "Parent = '" + variableStr1 + "' AND Role = '" + variableStr2 + "'";
		return res;
	}

	public static String getParentIdFilter(String variableStr1, String variableStr2) throws Exception {
		// origin - 08.10.2025, last edit - 08.10.2025
		String res = "Parent = '" + variableStr1 + "' AND Id = '" + variableStr2 + "'";
		return res;
	}

	public static String getParentCodeFilter(String variableStr1, String variableStr2) throws Exception {
		// origin - 25.05.2025, last edit - 25.05.2025
		String res = "Parent = '" + variableStr1 + "' AND Code = '" + variableStr2 + "'";
		return res;
	}

	public static String getParentFilter(String variableStr) throws Exception {
		// origin - 23.02.2025, last edit - 23.02.2025
		String res = "Parent = '" + variableStr + "'";
		return res;
	}

	public static String getInList(List<String> lst) throws Exception {
		// origin - 25.06.2025, last edit - 25.06.2025
		String res = "";
		if (lst.size() != 0) {
			res = res + " (";
			for (var currLst : lst) {
				res = res + " '" + currLst + "' ";
				if (Etc.strEquals(lst.getLast(), currLst) == false) {
					res = res + ",";
				}
			}
			res = res + ") ";
		}
		return res;
	}

	public static String getRoleMarkInFilter(String role, List<String> markList) throws Exception {
		// origin - 18.08.2025, last edit - 18.08.2025
		String res = "";
		if (role.isEmpty() == false) {
			res = res + "Role = '" + role + "'";
		}
		if (markList.size() != 0) {
			if (role.isEmpty() == false) {
				res = res + " AND ";
			}
			res = res + " Mark IN " + Qry.getInList(markList);
		}
		return res;
	}

	public static String getRoleMarkInFilter(List<String> roleList, List<String> markList) throws Exception {
		// origin - 25.06.2025, last edit - 26.06.2025
		String res = "";
		if (roleList.size() != 0) {
			res = res + " Role IN " + Qry.getInList(roleList);
		}
		if (markList.size() != 0) {
			if (roleList.size() != 0) {
				res = res + " AND ";
			}
			res = res + " Mark IN " + Qry.getInList(markList);
		}
		return res;
	}

	public static String getRoleMarkFilter(String variableStr1, String variableStr2) throws Exception {
		// origin - 23.05.2025, last edit - 23.05.2025
		String res = "Role = '" + variableStr1 + "' AND Mark = '" + variableStr2 + "'";
		return res;
	}

	public static String getRoleFilter(String variableStr) throws Exception {
		// origin - 17.02.2025, last edit - 17.02.2025
		String res = "Role = '" + variableStr + "'";
		return res;
	}

//	public static String getCodeRoleFilter(String variableStr1, String variableStr2) throws Exception {
//		// origin - 28.03.2025, last edit - 28.03.2025
//		String res = "Code = '" + variableStr1 + "' AND Role = '" + variableStr2 + "'";
//		return res;
//	}

	public static String getCodeContainsRoleFilter(String variableStr1, String variableStr2) throws Exception {
		// origin - 29.09.2025, last edit - 29.09.2025
		String res = "Code LIKE '%" + variableStr1 + "%' AND Role = '" + variableStr2 + "'";
		return res;
	}

	public static String getCodeFilter(String variableStr) throws Exception {
		// origin - 16.02.2025, last edit - 09.06.2025
		String res = "Code = '" + variableStr + "'";
		return res;
	}

	public static String getIdRoleInfoFilter(String variableStr1, String variableStr2, String variableStr3)
			throws Exception {
		// origin - 28.05.2025, last edit - 28.05.2025
		String res = "Id = '" + variableStr1 + "' AND Role = '" + variableStr2 + "' AND Info = '" + variableStr3 + "'";
		return res;
	}

	public static String getInfoFilter(String variableStr1) throws Exception {
		// origin - 05.09.2025, last edit - 05.09.2025
		String res = "Info = '" + variableStr1 + "'";
		return res;
	}

	public static String getRoleInfoFilter(String variableStr1, String variableStr2) throws Exception {
		// origin - 14.08.2025, last edit - 14.08.2025
		String res = "Role = '" + variableStr1 + "' AND Info = '" + variableStr2 + "'";
		return res;
	}

	public static String getIdInfoFilter(String variableStr1, String variableStr2) throws Exception {
		// origin - 27.05.2025, last edit - 27.05.2025
		String res = "Id = '" + variableStr1 + "' AND Info = '" + variableStr2 + "'";
		return res;
	}

	public static String getIdRoleFilter(String variableStr1, String variableStr2) throws Exception {
		// origin - 27.05.2025, last edit - 05.06.2025
		String res = "Id = '" + variableStr1 + "' AND Role = '" + variableStr2 + "'";
		return res;
	}

	public static String getIdContainsFilter(String variableStr1) throws Exception {
		// origin - 03.07.2026, last edit - 03.07.2026
		String res = "Id LIKE '%" + variableStr1 + "%'";
		return res;
	}

	public static String getIdContainsRoleFilter(String variableStr1, String variableStr2) throws Exception {
		// origin - 29.09.2025, last edit - 29.09.2025
		String res = "Id LIKE '%" + variableStr1 + "%' AND Role = '" + variableStr2 + "'";
		return res;
	}

	public static String getIdFilter(String variableStr) throws Exception {
		// origin - 28.11.2024, last edit - 28.11.2024
		String res = "Id = '" + variableStr + "'";
		return res;
	}

	public static String getRoleMoreFilter(String variableStr1, String variableStr2) throws Exception {
		// origin - 02.07.2025, last edit - 02.07.2025
		String res = "Role = '" + variableStr1 + "' AND More LIKE '%" + variableStr2 + "%'";
		return res;
	}

	public static String getMoreFilter(String variableStr) throws Exception {
		// origin - 30.12.2023, last edit - 04.06.2024
		String res = "More LIKE '%" + variableStr + "%'";
		return res;
	}

	public static String getOutputBackup(String conn) throws Exception {
		// origin - 28.05.2024, last edit - 13.06.2025
		String res = "";
		try {
			res = res + Qry.backupCmdSQLite;
			res = res + " '" + WB.inputOutputDir + File.separator + "output_";
			res = res + DateTool.getLabelDateTimeForFileName();
			res = res + "_to_all_";
			String fileName = InOut.getFileName(conn);
			res = res + fileName + "'";
		} catch (Exception ex) {
			WB.addLog("Qry.getOutputBackup(String):String, ex=" + ex.getMessage(), "", "Qry");
		}
		return res;
	}

	public static String getBackup(String conn) throws Exception {
		// origin - 18.12.2023, last edit - 13.06.2025
		String res = "";
		try {
			res = res + Qry.backupCmdSQLite;
			res = res + " '" + WB.backupDir + File.separator + "backup_";
			res = res + DateTool.getLabelDateTimeForFileName();
			String fileName = InOut.getFileName(conn);
			res = res + fileName + "'";
		} catch (Exception ex) {
			WB.addLog("Qry.getBackup(String):String, ex=" + ex.getMessage(), "", "Qry");
		}
		return res;
	}

	public static String getText(String currConn, String table, String templateMore) throws Exception {
		// origin - 25.10.2023, last edit - 13.06.2025
		String res = "";
		try {
			res = Qry.appender(res, "SELECT * FROM");
			res = Qry.appender(res, table);
			if (templateMore.isEmpty() != true) {
				res = Qry.appender(res, "WHERE");
				res = Qry.appender(res, templateMore);
			}
			res = res + ";";
		} catch (Exception ex) {
			WB.addLog("Qry.getText(3String):String, ex=" + ex.getMessage(), "", "Qry");
		}
		return res;
	}

	private Qry() throws Exception {
		// origin - 14.11.2023, last edit - 13.06.2025
	}

	private static String appender(String qry, String add) throws Exception {
		// origin - 15.11.2023, last edit - 13.06.2025
		String res = qry; // less fixTrim !!!
		try {
			res = res + Etc.fixString(add) + " "; // with right space !!!
		} catch (Exception ex) {
			WB.addLog("Qry.appender(2String):String, ex=" + ex.getMessage(), "", "Qry");
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 12.10.2023, last edit - 03.03.2026
		try {

//			{
//				WB.addLog2("Qry.test.getLower(2String):List<String>", "", "Qry");
//				var tmp1 = Qry.getLower("Geo", "Geo.Qazaqstan");
//				var listDto = DAL.getTable(WB.lastConnWork, tmp1);
//				WB.addLog2("DAL.test.getLower(2String):List<String>, res.size=" + listDto.size()
//						+ ", tmp1=Geo, tmp2=Geo.Qazaqstan", "", "Qry");
//				WB.log(listDto, "Qry");
//			}

//			{
//				WB.addLog2("Qry.test.getRoleMarkInFilter(2List<String>):String", "", "Qry");
//				var tmp1 = List.of("Role.Deal.Pawn".split(","));
//				var tmp2 = List.of("Mark.TD,Mark.MD".split(","));
//				WB.addLog2("Qry.test.getRoleMarkInFilter(2List<String>):String, res="
//						+ Qry.getRoleMarkInFilter(tmp1, tmp2) + ", tmp1=" + tmp1 + ", tmp2=" + tmp2, "", "Qry");
//			}

//			WB.addLog2("Qry.test.getInList(List<String>):String", "", "Qry");
//			for (var tmp1 : new String[] { "one", "one,two", "one,two,three" }) {
//				var tmp2 = List.of(tmp1.split(","));
//				WB.addLog2("Qry.test.getInList(List<String>):String, res=" + Qry.getInList(tmp2) + ", tmp1=" + tmp1
//						+ ", tmp2=" + tmp2, "", "Qry");
//			}

		} catch (Exception ex) {
			WB.addLog("Qry.test():void, ex=" + ex.getMessage(), "", "Qry");
		}
	}
}