import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public final class Abc {
	// origin - 28.09.2023, last edit - 13.08.2026
	public List<FullDto> basic;
	public List<FullDto> catalog, codePay, faceGovId, assetCodeId, personal, prof, sourceExtFile;
	public List<FullDto> update, sectoral, listVal, idGen, custom;
	public List<FullDto> userManualLocal;
	public List<FullDto> debt, publicHoliday, extraDayOff;
	public List<FullDto> accountMatching, accountClosing, workDay;
	public List<FullDto> account, geo, info, item, mark, meter, process, price, role, sign, slice, unit;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Abc.static ctor, ex=" + ex.getMessage(), "", "Abc");
		}
	}

	public static List<FullDto> getUpper(String targetId) throws Exception { // ex. "Unit.Kg" etc.
		// origin - 13.08.2026, last edit - 13.08.2026
		List<FullDto> res = new ArrayList<>();
		try {
			int index = targetId.indexOf(".");
			if (index != -1) {
				String table = Etc.fixTrim(targetId.substring(0, index));
				res = Abc.getUpper(table, targetId);
			}
		} catch (Exception ex) {
			WB.addLog("Abc.getUpper(String):List<FullDto>, ex=" + ex.getMessage(), "", "Abc");
		}
		return res;
	}

	public static List<FullDto> getUpper(String table, String targetId) throws Exception {
		// origin - 13.08.2026, last edit - 13.08.2026
		List<FullDto> res = new ArrayList<>();
		try {
			var tmp = Abc.get(table);
			res = Abc.getUpper(tmp, targetId);
		} catch (Exception ex) {
			WB.addLog("Abc.getUpper(2String):List<FullDto>, ex=" + ex.getMessage(), "", "Abc");
		}
		return res;
	}

	private static List<FullDto> getUpper(List<FullDto> allRows, String targetId) {
		// origin - 13.08.2026, last edit - 13.08.2026
		List<FullDto> res = new ArrayList<>();

		// 1. Индексируем список в Map для быстрого поиска O(1) по ID
		Map<String, FullDto> rowMap = new HashMap<>();
		for (FullDto row : allRows) {
			rowMap.put(row.getId(), row);
		}

		// 2. Ищем стартовую строку
		FullDto current = rowMap.get(targetId);
		if (current == null) {
			return res; // Возвращаем пустой список, если ID не найден
		}

		// 3. Поднимаемся вверх по цепочке Parent
		String currentParentId = current.getParent();
		while (currentParentId != null) {
			FullDto parentRow = rowMap.get(currentParentId);

			if (parentRow != null) {
				res.add(parentRow);
				currentParentId = parentRow.getParent(); // Шаг вверх
			} else {
				break; // Защита на случай битых ссылок в БД
			}
		}
		return res;
	}

	public static List<FullDto> getLower(String targetId) throws Exception { // ex. "Unit.Kg" etc.
		// origin - 13.08.2026, last edit - 13.08.2026
		List<FullDto> res = new ArrayList<>();
		try {
			int index = targetId.indexOf(".");
			if (index != -1) {
				String table = Etc.fixTrim(targetId.substring(0, index));
				res = Abc.getLower(table, targetId);
			}
		} catch (Exception ex) {
			WB.addLog("Abc.getLower(String):List<FullDto>, ex=" + ex.getMessage(), "", "Abc");
		}
		return res;
	}

	public static List<FullDto> getLower(String table, String targetId) throws Exception {
		// origin - 13.08.2026, last edit - 13.08.2026
		List<FullDto> res = new ArrayList<>();
		try {
			var tmp = Abc.get(table);
			res = Abc.getLower(tmp, targetId);
		} catch (Exception ex) {
			WB.addLog("Abc.getLower(2String):List<FullDto>, ex=" + ex.getMessage(), "", "Abc");
		}
		return res;
	}

	private static List<FullDto> getLower(List<FullDto> allRows, String targetId) throws Exception {
		// origin - 13.08.2026, last edit - 13.08.2026
		List<FullDto> res = new ArrayList<>();
		try {
			// 1. Группируем строки: Ключ = ParentId, Значение = Список прямых детей
			Map<String, List<FullDto>> parentToChildrenMap = allRows.stream().filter(row -> row.getParent() != null)
					.collect(Collectors.groupingBy(FullDto::getParent));
			// 2. Запускаем рекурсивный сборщик
			Abc.collectLowerRecursive(targetId, parentToChildrenMap, res);
		} catch (Exception ex) {
			WB.addLog("Abc.getLower(...):List<FullDto>, ex=" + ex.getMessage(), "", "Abc");
		}
		return res;
	}

	private static void collectLowerRecursive(String currentParentId, Map<String, List<FullDto>> map, List<FullDto> res)
			throws Exception {
		// origin - 13.08.2026, last edit - 13.08.2026
		// Получаем только прямых детей для текущего ID
		List<FullDto> directChildren = map.get(currentParentId);
		try {
			if (directChildren != null) {
				for (FullDto child : directChildren) {
					res.add(child); // Добавляем в общий список
					// Рекурсивно ищем детей для текущего ребенка (уходим глубже)
					Abc.collectLowerRecursive(child.getId(), map, res);
				}
			}
		} catch (Exception ex) {
			WB.addLog("Abc.collectLowerRecursive(...):void, ex=" + ex.getMessage(), "", "Abc");
		}
	}

	public static List<FullDto> get(String table) throws Exception {
		// origin - 12.08.2026, last edit - 13.08.2026
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			switch (table) {
			case "Account" -> res = WB.abcLast.account;
			case "Debt" -> res = WB.abcLast.debt;
			case "Geo" -> res = WB.abcLast.geo;
			case "Info" -> res = WB.abcLast.info;
			case "Item" -> res = WB.abcLast.item;
			case "Mark" -> res = WB.abcLast.mark;
			case "Meter" -> res = WB.abcLast.meter;
			case "Price" -> res = WB.abcLast.price;
			case "Process" -> res = WB.abcLast.process;
			case "Role" -> res = WB.abcLast.role;
			case "Sign" -> res = WB.abcLast.sign;
			case "Slice" -> res = WB.abcLast.slice;
			case "Unit" -> res = WB.abcLast.unit;

			default -> res = new ArrayList<FullDto>();
			}
		} catch (Exception ex) {
			WB.addLog("Abc.get(String):String, ex=" + ex.getMessage() + ", table=" + table, "", "Abc");
		}
		return res;
	}

	public Abc(String dbConn) throws Exception {
		// origin - 26.11.2023, last edit - 10.08.2026
		this();
		try {
			this.basic = DAL.getByTemplate(dbConn, Qry.getMoreFilter("AbcBasic"));
			this.sectoral = ReadSet.getContainsByMore(this.basic, "AbcSectoral");
			this.custom = ReadSet.getContainsByMore(this.basic, "AbcCustom");
			this.debt = ReadSet.getContainsByMore(this.basic, "Debt.Basic");
			this.publicHoliday = ReadSet.getEqualsByMeter(this.basic, "Meter.PublicHoliday");
			this.extraDayOff = ReadSet.getEqualsByMeter(this.basic, "Meter.ExtraDayOff");
			this.accountMatching = ReadSet.getContainsByMore(this.basic, "AbcAccountMatching");
			this.accountClosing = ReadSet.getContainsByMore(this.basic, "AbcAccountClosing");
			this.workDay = ReadSet.getContainsByMore(this.basic, "AbcWorkDay");
			this.userManualLocal = ReadSet.getContainsByMore(this.basic, "UserManualLocal");
			this.sourceExtFile = ReadSet.getContainsByMore(this.basic, "SourceExtFile");
			this.update = ReadSet.getContainsByMore(this.basic, "AbcUpdate");
			this.catalog = ReadSet.getContainsByMore(this.basic, "AbcCatalog");
			this.codePay = ReadSet.getContainsByMore(this.basic, "AbcCodePay");
			this.faceGovId = ReadSet.getContainsByMore(this.basic, "AbcFaceGovId");
			this.assetCodeId = ReadSet.getContainsByMore(this.basic, "AbcAssetCodeId");
			this.personal = ReadSet.getContainsByMore(this.basic, "AbcPersonal");
			this.prof = ReadSet.getContainsByMore(this.basic, "AbcProf");
			this.listVal = ReadSet.getContainsByMore(this.basic, "AbcListVal");
			this.idGen = ReadSet.getContainsByCode(this.basic, "IdGen");

			this.account = DAL.getTable(dbConn, Qry.getText(WB.lastConnWork, "Account", ""));
			this.geo = DAL.getTable(dbConn, Qry.getText(WB.lastConnWork, "Geo", ""));
			this.info = DAL.getTable(dbConn, Qry.getText(WB.lastConnWork, "Info", ""));
			this.item = DAL.getTable(dbConn, Qry.getText(WB.lastConnWork, "Item", ""));
			this.mark = DAL.getTable(dbConn, Qry.getText(WB.lastConnWork, "Mark", ""));
			this.meter = DAL.getTable(dbConn, Qry.getText(WB.lastConnWork, "Meter", ""));
			this.process = DAL.getTable(dbConn, Qry.getText(WB.lastConnWork, "Process", ""));
			this.price = DAL.getTable(dbConn, Qry.getText(WB.lastConnWork, "Price", ""));
			this.role = DAL.getTable(dbConn, Qry.getText(WB.lastConnWork, "Role", ""));
			this.sign = DAL.getTable(dbConn, Qry.getText(WB.lastConnWork, "Sign", ""));
			this.slice = DAL.getTable(dbConn, Qry.getText(WB.lastConnWork, "Slice", ""));
			this.unit = DAL.getTable(dbConn, Qry.getText(WB.lastConnWork, "Unit", ""));
		} catch (Exception ex) {
			WB.addLog("Abc.ctor(dbConn), ex=" + ex.getMessage(), "", "Abc");
		}
	}

	public Abc() throws Exception {
		// origin - 13.11.2023, last edit - 20.03.2025
		try {
			this.clear();
		} catch (Exception ex) {
			WB.addLog("Abc.ctor(), ex=" + ex.getMessage(), "", "Abc");
		}
	}

	private void clear() throws Exception {
		// origin - 25.11.2024, last edit - 10.08.2026
		try {
			this.basic = this.catalog = this.faceGovId = this.assetCodeId = this.codePay = this.sourceExtFile = new ArrayList<FullDto>();
			this.update = this.sectoral = new ArrayList<FullDto>();
			this.listVal = this.idGen = this.custom = new ArrayList<FullDto>();
			this.userManualLocal = this.personal = this.prof = new ArrayList<FullDto>();
			this.debt = this.publicHoliday = this.extraDayOff = new ArrayList<FullDto>();
			this.accountMatching = this.accountClosing = this.workDay = new ArrayList<FullDto>();
			this.account = this.geo = this.info = this.item = this.mark = this.meter = this.process = new ArrayList<FullDto>();
			this.price = this.role = this.sign = this.slice = this.unit = new ArrayList<FullDto>();
		} catch (Exception ex) {
			WB.addLog("Abc.clear():void, ex=" + ex.getMessage(), "", "Abc");
		}
	}

	@SuppressWarnings("unchecked")
	private String reflect() throws Exception {
		// origin - 21.08.2024, last edit - 14.06.2025
		String res = "";
		try {
			Field[] fields = this.getClass().getFields();
			for (var currField : fields) {
				currField.setAccessible(true);
				List<FullDto> fieldValue = (List<FullDto>) currField.get(this);

				if (fieldValue.isEmpty() != true) {
					res = res + currField.getName() + "=" + fieldValue.size() + ", ";
					// res = res + currField.getName() + " " + fieldValue.size() +", ";
				}
			}
		} catch (Exception ex) {
			WB.addLog("Abc.reflect():String, ex=" + ex.getMessage() + ", this.getClass()=" + this.getClass(), "",
					"Abc");
		}
		return res;
	}

	public String toString() {
		// origin - 21.11.2023, last edit - 20.03.2025
		String res = "";
		try {
			res = this.reflect();
			res = "{" + res + "}";
		} catch (Exception ex) {
			WB.addLog("Abc.toString, ex=" + ex.getMessage(), "", "Abc");
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 13.06.2025
		try {

//			WB.addLog2("Abc.test.getUpper(String):", "", "Unit");
//			for (var tmp1 : new String[] { "Unit.Face", "Unit.KZT", "Unit.tralala", "Unit.ExactDate",
//					"Unit.Service/Login/Password", "Unit.EveryDayOnTime", "Unit.Month", "Unit.Meter" }) {
//				var tmp2 = new Unit(tmp1);
//				var tmp3 = Abc.getUpper(tmp1);
//				WB.addLog2("Abc.test.getUpper(String):List<FullDto>, upperList.size=" + tmp3.size(), "", "Abc");
//				WB.addLog2("Abc.test.ctor(String), res=" + tmp2, "", "Abc");
//			}

//			WB.addLog2("Abc.test.getUpper(2String):", "", "Unit");
//			for (var tmp1 : new String[] { "Unit.Face", "Unit.KZT", "Unit.tralala", "Unit.ExactDate",
//					"Unit.Service/Login/Password", "Unit.EveryDayOnTime", "Unit.Month", "Unit.Meter" }) {
//				var tmp2 = new Unit(tmp1);
//				var tmp3 = Abc.getUpper("Unit", tmp1);
//				WB.addLog2("Abc.test.getUpper(2String):List<FullDto>, upperList.size=" + tmp3.size(), "", "Abc");
//				WB.addLog2("Abc.test.ctor(String), res=" + tmp2, "", "Abc");
//			}

//			WB.addLog2("Abc.test.getLower(String):", "", "Unit");
//			for (var tmp1 : new String[] { "Unit.Face", "Unit.KZT", "Unit.tralala", "Unit.ExactDate",
//					"Unit.Service/Login/Password", "Unit.EveryDayOnTime", "Unit.Month", "Unit.Meter" }) {
//				var tmp2 = new Unit(tmp1);
//				var tmp3 = Abc.getLower(tmp1);
//				WB.addLog2("Abc.test.getLower(String):List<FullDto>, lowerList.size=" + tmp3.size(), "", "Abc");
//				WB.addLog2("Abc.test.ctor(String), res=" + tmp2, "", "Abc");
//			}

//			WB.addLog2("Abc.test.getLower(2String):", "", "Unit");
//			for (var tmp1 : new String[] { "Unit.Face", "Unit.KZT", "Unit.tralala", "Unit.ExactDate",
//					"Unit.Service/Login/Password", "Unit.EveryDayOnTime", "Unit.Month", "Unit.Meter" }) {
//				var tmp2 = new Unit(tmp1);
//				var tmp3 = Abc.getLower("Unit", tmp1);
//				WB.addLog2("Abc.test.getLower(2String):List<FullDto>, lowerList.size=" + tmp3.size(), "", "Abc");
//				WB.addLog2("Abc.test.ctor(String), res=" + tmp2, "", "Abc");
//			}

		} catch (Exception ex) {
			WB.addLog("Abc.test():void, ex=" + ex.getMessage(), "", "Abc");
		}
	}
}