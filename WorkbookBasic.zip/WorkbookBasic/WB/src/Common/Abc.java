import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public final class Abc {
	// origin - 28.09.2023, last edit - 20.12.2025
	public List<ModelDto> basic;
	public List<ModelDto> catalog, codePay, faceGovId, personal, prof, sourceExtFile, workOutside;
	public List<ModelDto> update, sectoral, sectoralPawnshop, listVal, idGen, custom;
	public List<ModelDto> userManualLocal;
	public List<ModelDto> debt, publicHoliday, extraDayOff;
	public List<ModelDto> accountMatching, accountClosing;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Abc.static ctor, ex=" + ex.getMessage(), "", "Abc");
		}
	}

//	public static ModelDto getRoot(String table) throws Exception {
//		// origin - 23.09.2024, last edit - 19.05.2025
//		ModelDto res = new ModelDto();
//		try {
//			res = ReadSet.getEqualsByCode(WB.abcLast.basic, table).getFirst();
//		} catch (Exception ex) {
//			WB.addLog("Abc.getRoot, ex=" + ex.getMessage(), "", "Abc");
//		}
//		return res;
//	}

	public Abc(String dbConn) throws Exception {
		// origin - 26.11.2023, last edit - 20.12.2025
		this();
		try {
			this.basic = DAL.getByTemplate(dbConn, Qry.getMoreFilter("AbcBasic"));
			this.sectoral = ReadSet.getContainsByMore(this.basic, "AbcSectoral");
			this.sectoralPawnshop = ReadSet.getContainsByMore(this.basic, "Pawnshop");
			this.custom = ReadSet.getContainsByMore(this.basic, "AbcCustom");
			this.debt = ReadSet.getContainsByMore(this.basic, "Debt.Basic");
			this.publicHoliday = ReadSet.getEqualsByMeter(this.basic, "Meter.PublicHoliday");
			this.extraDayOff = ReadSet.getEqualsByMeter(this.basic, "Meter.ExtraDayOff");
			this.accountMatching = ReadSet.getContainsByMore(this.basic, "AbcAccountMatching");
			this.accountClosing = ReadSet.getContainsByMore(this.basic, "AbcAccountClosing");
			this.userManualLocal = ReadSet.getContainsByMore(this.basic, "UserManualLocal");
			this.sourceExtFile = ReadSet.getContainsByMore(this.basic, "SourceExtFile");
			this.workOutside = ReadSet.getContainsByMore(this.basic, "WorkOutside");
			this.update = ReadSet.getContainsByMore(this.basic, "AbcUpdate");
			this.catalog = ReadSet.getContainsByMore(this.basic, "AbcCatalog");
			this.codePay = ReadSet.getContainsByMore(this.basic, "AbcCodePay");
			this.faceGovId = ReadSet.getContainsByMore(this.basic, "AbcFaceGovId");
			this.personal = ReadSet.getContainsByMore(this.basic, "AbcPersonal");
			this.prof = ReadSet.getContainsByMore(this.basic, "AbcProf");
			this.listVal = ReadSet.getContainsByMore(this.basic, "AbcListVal");
			this.idGen = ReadSet.getContainsByCode(this.basic, "IdGen");
		} catch (Exception ex) {
			WB.addLog("Abc.ctor(dbConn), ex=" + ex.getMessage(), "", "Abc");
		}
	}

	public Abc() throws Exception {
		// origin - 13.11.2023, last edit - 20.03.2025
		try {
			this.clear();
		} catch (Exception ex) {
			WB.addLog("Abc.ctor(), ex=" + ex.getMessage(), "", "Abc");
		}
	}

	private void clear() throws Exception {
		// origin - 25.11.2024, last edit - 20.12.2025
		try {
			this.basic = this.catalog = this.faceGovId = this.codePay = this.sourceExtFile = new ArrayList<ModelDto>();
			this.workOutside = this.update = this.sectoral = this.sectoralPawnshop = new ArrayList<ModelDto>();
			this.listVal = this.idGen = this.custom = new ArrayList<ModelDto>();
			this.userManualLocal = this.personal = this.prof = new ArrayList<ModelDto>();
			this.debt = this.publicHoliday = this.extraDayOff = new ArrayList<ModelDto>();
			this.accountMatching = this.accountClosing = new ArrayList<ModelDto>();
		} catch (Exception ex) {
			WB.addLog("Abc.clear():void, ex=" + ex.getMessage(), "", "Abc");
		}
	}

	@SuppressWarnings("unchecked")
	private String reflect() throws Exception {
		// origin - 21.08.2024, last edit - 14.06.2025
		String res = "";
		try {
			Field[] fields = this.getClass().getFields();
			for (var currField : fields) {
				currField.setAccessible(true);
				List<ModelDto> fieldValue = (List<ModelDto>) currField.get(this);

				if (fieldValue.isEmpty() != true) {
					res = res + currField.getName() + "=" + fieldValue.size() + ", ";
					// res = res + currField.getName() + " " + fieldValue.size() +", ";
				}
			}
		} catch (Exception ex) {
			WB.addLog("Abc.reflect():String, ex=" + ex.getMessage() + ", this.getClass()=" + this.getClass(), "",
					"Abc");
		}
		return res;
	}

	public String toString() {
		// origin - 21.11.2023, last edit - 20.03.2025
		String res = "";
		try {
			res = this.reflect();
			res = "{" + res + "}";
		} catch (Exception ex) {
			WB.addLog("Abc.toString, ex=" + ex.getMessage(), "", "Abc");
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 13.06.2025
		try {

		} catch (Exception ex) {
			WB.addLog("Abc.test():void, ex=" + ex.getMessage(), "", "Abc");
		}
	}
}