import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class ChatBot extends JFrame {
	// origin - 26.08.2026, last edit - 27.08.2026
	private static final long serialVersionUID = -2982641476073086783L;
	// UI Компоненты
	private JTextArea chatArea;
	private JPanel buttonPanel;
	private JTextField keywordField;
	private JComboBox<Product> productComboBox;

	// Структуры данных (база знаний)
	private Map<String, DialogNode> dialogGraph = new HashMap<>();
	private List<Product> productList = new ArrayList<>();
	private DialogNode currNode;

	// Узел графа диалога
	static class DialogNode {
		// origin - 26.08.2026, last edit - 27.08.2026
		String id;
		String botText;
		String[] buttonIds;

		public DialogNode(String id, String botText, String[] buttonIds) {
			// origin - 26.08.2026, last edit - 27.08.2026
			this.id = id;
			this.botText = botText;
			this.buttonIds = buttonIds;
		}
	}

	// Сущность товара для ComboBox
	static class Product {
		// origin - 26.08.2026, last edit - 27.08.2026
		String id;
		String name;
		double price;
		String description;

		public Product(String id, String name, double price, String description) {
			// origin - 26.08.2026, last edit - 27.08.2026
			try {
				this.id = id;
				this.name = name;
				this.price = price;
				this.description = description;
			} catch (Exception ex) {
				WB.addLog("ChatBot.Product.ctor(String,double,String):void, ex=" + ex.getMessage(), "", "ChatBot");
			}
		}

		public String toString() {
			// origin - 26.08.2026, last edit - 26.08.2026
			return this.name; // Определяет, что будет написано в выпадающем списке
		}
	}

	public ChatBot() {
		// origin - 26.08.2026, last edit - 29.08.2026
		try {
			this.setTitle("Rule-Based ChatBot");
			this.setSize(750, 550);
			// this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			this.setLocationRelativeTo(null);

			this.loadProduct(InOut.getStrPathFileByFileNameInAppDir("chatbot_product.csv"));
			this.loadDialogGraph(InOut.getStrPathFileByFileNameInAppDir("chatbot_dialog_graph.csv"));

			this.initUI();
			this.switchToNode("START");
		} catch (Exception ex) {
			WB.addLog("ChatBot.ctor():void, ex=" + ex.getMessage(), "", "ChatBot");
		}
	}

	private void initUI() throws Exception {
		// origin - 26.08.2026, last edit - 29.08.2026
		try {
			this.setLayout(new BorderLayout());

			// 1. Центральное окно чата
			this.chatArea = new JTextArea();
			this.chatArea.setEditable(false);
			this.chatArea.setLineWrap(true);
			this.chatArea.setWrapStyleWord(true);
			this.chatArea.setFont(new Font("Arial", Font.PLAIN, 14));
			this.add(new JScrollPane(chatArea), BorderLayout.CENTER);

			// 2. Многоуровневая нижняя панель
			JPanel controlPanel = new JPanel();
			controlPanel.setLayout(new BoxLayout(controlPanel, BoxLayout.Y_AXIS));

			// Верхний ярус: Поля ввода/выбора (Уточняющие параметры)
			JPanel inputModifierPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
			inputModifierPanel.setBorder(BorderFactory.createTitledBorder("Параметры уточнения"));

			inputModifierPanel.add(new JLabel("  Товар:"));
			this.productComboBox = new JComboBox<>();
			this.productComboBox.addItem(new Product("0", "-- Выберите из списка --", 0, ""));
			for (Product p : this.productList) {
				this.productComboBox.addItem(p);
			}
			inputModifierPanel.add(this.productComboBox);

			inputModifierPanel.add(new JLabel("Ключевое слово:"));
			this.keywordField = new JTextField(12);
			inputModifierPanel.add(keywordField);

			controlPanel.add(inputModifierPanel);

			// Нижний ярус: Динамические кнопки навигации по графу
			this.buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
			controlPanel.add(this.buttonPanel);
			this.add(controlPanel, BorderLayout.SOUTH);
		} catch (Exception ex) {
			WB.addLog("ChatBot.initUI():void, ex=" + ex.getMessage(), "", "ChatBot");
		}
	}

	private void switchToNode(String nodeId) throws Exception { // Метод навигации по узлам графа
		// origin - 26.08.2026, last edit - 27.08.2026
		try {
			if ("BACK".equals(nodeId)) {
				nodeId = "START";
			}

			this.currNode = this.dialogGraph.get(nodeId);
			if (this.currNode == null) {
				this.appendBotText("Ошибка навигации. Узел '" + nodeId + "' отсутствует.");
				return;
			}

			this.appendBotText("Бот: " + this.currNode.botText);
			this.updateButton(this.currNode.buttonIds);
		} catch (Exception ex) {
			WB.addLog("ChatBot.switchToNode(String):void, ex=" + ex.getMessage(), "", "ChatBot");
		}
	}

	// Перерисовка кнопок под текущий шаг диалога
	private void updateButton(String[] buttonIds) throws Exception {
		// origin - 26.08.2026, last edit - 27.08.2026
		try {
			this.buttonPanel.removeAll();

			for (String id : buttonIds) {
				JButton button = new JButton(this.getButtonLabel(id));
				button.addActionListener(e -> this.handleButtonClick(id));
				button.setFont(new Font("Arial", Font.BOLD, 12));
				this.buttonPanel.add(button);
			}

			this.buttonPanel.revalidate();
			this.buttonPanel.repaint();
		} catch (Exception ex) {
			WB.addLog("ChatBot.updateButton(String[]):void, ex=" + ex.getMessage(), "", "ChatBot");
		}
	}

	private String getButtonLabel(String id) throws Exception { // Локализация названий системных кнопок
		// origin - 26.08.2026, last edit - 27.08.2026
		String res = "";
		try {
			switch (id) {
			case "PRODUCT_INFO" -> res = "Справка о товаре";
			case "PRODUCT_PRICE" -> res = "Цена товара";
			case "HELP" -> res = "Помощь";
			case "BACK" -> res = "Назад";
			default -> res = id;
			}
		} catch (Exception ex) {
			WB.addLog("ChatBot.getButtonLabel(String):String, ex=" + ex.getMessage(), "", "ChatBot");
		}
		return res;
	}

	// Центральный метод обработки действий (Перехватчик жесткой логики)
	private void handleButtonClick(String actionId) {
		// origin - 26.08.2026, last edit - 31.08.2026
		try {
			String keyword = this.keywordField.getText().trim();
			Product selectedProduct = (Product) this.productComboBox.getSelectedItem();
			boolean isProductSelected = selectedProduct != null && !"0".equals(selectedProduct.id);

			this.appendUserText("Нажата кнопка: " + this.getButtonLabel(actionId));

			// Вызов жестко заданных методов-инструментов в обход стандартной смены узлов
			switch (actionId) {
			case "PRODUCT_INFO" -> {
				this.executeProductInfoTool(keyword, selectedProduct, isProductSelected);
				return;
			}
			case "PRODUCT_PRICE" -> {
				this.executeProductPriceTool(selectedProduct, isProductSelected);
				return;
			}
			}

			// Обычный переход по графу, если это не сервисная кнопка с инструментом
			this.switchToNode(actionId);
		} catch (Exception ex) {
			WB.addLog("ChatBot.handleButtonClick(String):void, ex=" + ex.getMessage(), "", "ChatBot");
		}
	}

	// ИНСТРУМЕНТЫ-МЕТОДЫ (Бизнес-логика)
	private void executeProductInfoTool(String keyword, Product product, boolean isProductSelected) throws Exception {
		// origin - 26.08.2026, last edit - 27.08.2026
		try {
			// Приоритет 1: Поиск по текстовому ключевому слову
			if (!keyword.isEmpty()) {
				this.appendBotText("Бот [Поиск]: Обработка ключевого слова '" + keyword + "'...");
				Product found = this.findProductByKeyword(keyword);
				if (found != null) {
					this.appendBotText("Бот [Инструмент]: Найдено точное совпадение! Товар: " + found.name
							+ "Описание: " + found.description);
				} else {
					this.appendBotText("Бот [Инструмент]: По ключевому слову '" + keyword + "' ничего не найдено.");
				}
			}
			// Приоритет 2: Использование выбранного элемента из ComboBox
			else if (isProductSelected) {
				this.appendBotText("Бот [Инструмент]: Описание '" + product.name + "': " + product.description);
			}
			// Если ничего не заполнено
			else {
				this.appendBotText(
						"Бот: Невозможно получить справку. Выберите товар из списка или введите ключевое слово.");
			}
			this.switchToNode("START");
		} catch (Exception ex) {
			WB.addLog("ChatBot.executeProductInfoTool(String,Product,boolean):void, ex=" + ex.getMessage(), "",
					"ChatBot");
		}
	}

	private void executeProductPriceTool(Product product, boolean isProductSelected) throws Exception {
		// origin - 26.08.2026, last edit - 27.08.2026
		try {
			if (isProductSelected) {
				this.appendBotText("Бот [Инструмент]: Стоимость товара '" + product.name + "' составляет "
						+ product.price + " руб.");
			} else {
				this.appendBotText("Бот: Для вывода цены необходимо выбрать конкретный товар из списка.");
			}
			this.switchToNode("START");
		} catch (Exception ex) {
			WB.addLog("ChatBot.executeProductPriceTool(Product,boolean):void, ex=" + ex.getMessage(), "", "ChatBot");
		}
	}

	// Вспомогательный алгоритм жесткого поиска без ИИ
	private Product findProductByKeyword(String keyword) throws Exception {
		// origin - 26.08.2026, last edit - 27.08.2026
		try {
			for (Product p : this.productList) {
				if (p.name.toLowerCase().contains(keyword.toLowerCase())
						|| p.description.toLowerCase().contains(keyword.toLowerCase())) {
					return p;
				}
			}
		} catch (Exception ex) {
			WB.addLog("ChatBot.findProductByKeyword(String):Product, ex=" + ex.getMessage(), "", "ChatBot");
		}
		return null;
	}

//	private void clearInput() throws Exception {
//		// origin - 26.08.2026, last edit - 29.08.2026
//		try {
//			this.keywordField.setText("");
//			this.productComboBox.setSelectedIndex(0);
//		} catch (Exception ex) {
//			WB.addLog("ChatBot.clearInput():void, ex=" + ex.getMessage(), "", "ChatBot");
//		}
//	}

	private void appendBotText(String text) {
		// origin - 26.08.2026, last edit - 27.08.2026
		this.chatArea.append(text + System.lineSeparator());
	}

	private void appendUserText(String text) {
		// origin - 26.08.2026, last edit - 29.08.2026
		this.chatArea.append("Вы: " + text + System.lineSeparator());
	}

	private void loadDialogGraph(String filePath) throws Exception {
		// origin - 26.08.2026, last edit - 29.08.2026
		try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
			String line;
			br.readLine(); // Пропускаем заголовок csv
			while ((line = br.readLine()) != null) {
				String[] tokens = line.split("\\|"); // ",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
				if (tokens.length >= 3) {
					String id = tokens[0].trim();
					String text = tokens[1].replace("\"", "").trim();
					String[] buttons = tokens[2].replace("\"", "").trim().split(";");
					this.dialogGraph.put(id, new DialogNode(id, text, buttons));
				}
			}
		} catch (Exception ex) {
			WB.addLog("ChatBot.loadDialogGraph(String):void, ex=" + ex.getMessage(), "", "ChatBot");
		}
	}

	private void loadProduct(String filePath) throws Exception {
		// origin - 26.08.2026, last edit - 29.08.2026
		try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
			String line;
			br.readLine();
			while ((line = br.readLine()) != null) {
				String[] tokens = line.split("\\|"); // ",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
				if (tokens.length >= 4) {
					String id = tokens[0].trim();
					String name = tokens[1].trim();
					double price = Double.parseDouble(tokens[2].trim());
					String desc = tokens[3].trim();
					this.productList.add(new Product(id, name, price, desc));
				}
			}
		} catch (Exception ex) {
			WB.addLog("ChatBot.loadProduct(String):void, ex=" + ex.getMessage(), "", "ChatBot");
		}
	}

	public static void init() throws Exception {
		// origin - 26.08.2026, last edit - 29.08.2026
		try {
			SwingUtilities.invokeLater(() -> new ChatBot().setVisible(true));
		} catch (Exception ex) {
			WB.addLog("ChatBot.init():void, ex=" + ex.getMessage(), "", "ChatBot");
		}
	}
}