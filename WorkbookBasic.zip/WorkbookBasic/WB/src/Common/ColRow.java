import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public final class ColRow {
	// origin - 15.02.2026, last edit - 30.09.2026
	public String id, code, description, defect;
	public List<String> src;
	public List<List<String>> row;
	public static String delimiter, delimiterForWrite;
	public static List<String> operList;
	public static List<String> filterList;
	public static List<String> terminalList;

	static {
		try {
			ColRow.filterList = List.of("noteqv", "eqv");
			ColRow.terminalList = List.of("total");
			ColRow.operList = new ArrayList<>(ColRow.filterList);
			ColRow.operList.addAll(ColRow.terminalList);

			ColRow.delimiter = "\\|"; // "\\" this is protective shielding
			ColRow.delimiterForWrite = "|";
		} catch (Exception ex) {
			WB.addLog("ColRow.static ctor, ex=" + ex.getMessage(), "", "ColRow");
		}
	}

	public static boolean isFilter(String str) throws Exception {
		// origin - 30.09.2026, last edit - 19.10.2026
		boolean res = false;
		try {
			if (Etc.strNotValid(str)) {
				return res;
			}

			str = Etc.fixTrim(str);
			// res = Etc.strContains(str, ColRow.filterList);
			for (var curr : ColRow.filterList) {
				if (str.startsWith(curr)) {
					return res = true;
				}
			}
		} catch (Exception ex) {
			WB.addLog("ColRow.isFilter(String):boolean, ex=" + ex.getMessage(), "", "ColRow");
		}
		return res;
	}

	public static Map<Integer, Double> sum(List<List<String>> inColVal) throws Exception {
		// origin - 28.09.2026, last edit - 28.09.2026
		Map<Integer, Double> res = new HashMap<>();
		try {
			var tmp1 = new ColRow();
			tmp1.row.addAll(inColVal);
			res = tmp1.sum();
		} catch (Exception ex) {
			WB.addLog("ColRow.sum(List<List<String>>):Map<Integer, Double>, ex=" + ex.getMessage(), "", "ColRow");
		}
		return res;
	}

	public static Map<Integer, Double> sum(List<List<String>> inColVal, int colSum[]) throws Exception {
		// origin - 27.09.2026, last edit - 28.09.2026
		Map<Integer, Double> res = new HashMap<>();
		try {
			if (colSum.length == 0) {
				return res;
			}

			var tmp1 = new ColRow();
			tmp1.row.addAll(inColVal);
			res = tmp1.sum(colSum);
		} catch (Exception ex) {
			WB.addLog("ColRow.sum(List<List<String>>,int[]):Map<Integer, Double>, ex=" + ex.getMessage(), "", "ColRow");
		}
		return res;
	}

	public static List<List<String>> filterRowByColValAndOper(List<List<String>> inColVal, int col, String colVal,
			String oper) throws Exception {
		// origin - 27.09.2026, last edit - 19.10.2026
		List<List<String>> res = new ArrayList<>();
		try {
			if (Etc.strNotValid(colVal, oper)) {
				return res;
			}

			var tmp1 = new ColRow();
			tmp1.row.addAll(inColVal);
			var tmp2 = tmp1.filterRowByColValAndOper(col, colVal, oper);

			if (tmp2.size() != 0) {
				res.addAll(tmp2);
			}
		} catch (Exception ex) {
			WB.addLog("ColRow.filterRowByColValAndOper(List<List<String>>,int, 2String):List<List<String>>, ex="
					+ ex.getMessage(), "", "ColRow");
		}
		return res;
	}

	public static List<List<String>> separateByFirstRow(List<List<String>> inColVal, int separateStartIndexRow)
			throws Exception {
		// origin - 24.09.2026, last edit - 26.09.2026
		List<List<String>> res = new ArrayList<>();
		try {
			if (separateStartIndexRow <= 0) {
				return res = inColVal;
			}

			var tmp1 = new ColRow();
			tmp1.row.addAll(inColVal);
			var tmp2 = tmp1.separateByFirstRow(separateStartIndexRow);

			if (tmp2.size() != 0) {
				res.addAll(tmp2);
			}
		} catch (Exception ex) {
			WB.addLog("ColRow.separateByFirstRow(List<List<String>>,int):List<List<String>>, ex=" + ex.getMessage(), "",
					"ColRow");
		}
		return res;
	}

	public static List<List<String>> separateCol(List<List<String>> inColVal, int[] separateIndexCol) throws Exception {
		// origin - 21.09.2026, last edit - 24.09.2026
		List<List<String>> res = new ArrayList<>();
		try {
			if (separateIndexCol.length == 0) {
				return res;
			}

			var tmp1 = new ColRow();
			tmp1.row.addAll(inColVal);
			var tmp2 = tmp1.separateCol(separateIndexCol);

			if (tmp2.size() != 0) {
				res.addAll(tmp2);
			}
		} catch (Exception ex) {
			WB.addLog("ColRow.separateCol(List<List<String>>,int[]):List<List<String>>, ex=" + ex.getMessage(), "",
					"ColRow");
		}
		return res;
	}

	private List<List<String>> filter(int innerIndexCol, String colVal, String oper) throws Exception {
		// origin - 27.09.2026, last edit - 19.10.2026
		List<List<String>> res = new ArrayList<>();
		try {
			if (Etc.strNotValid(colVal, oper)) {
				return res;
			}

			List<List<String>> filteredRow = new ArrayList<>();
			filteredRow = this.row.stream().filter(row -> {
				try {
					var tmp = true;
					if (Etc.strEquals(oper, "eqv")) { // filter eqv
						tmp = Etc.strEquals(row.get(innerIndexCol), colVal);
					}
					if (Etc.strEquals(oper, "noteqv")) { // filter noteqv
						tmp = Etc.strNotEquals(row.get(innerIndexCol), colVal);
					}
					return tmp;
				} catch (Exception ex) {
					WB.addLog("ColRow.filter(int, 2String):List<List<String>>, ex=" + ex.getMessage(), "", "ColRow");
				}
				return false;
			}).collect(Collectors.toList());

			if (filteredRow.size() != 0) {
				res.addAll(filteredRow);
			}
		} catch (Exception ex) {
			WB.addLog("ColRow.filter(int, 2String):List<List<String>>, ex=" + ex.getMessage(), "", "ColRow");
		}
		return res;
	}

	public List<List<String>> filterRowByColValAndOper(int col, String colVal, String oper) throws Exception {
		// origin - 26.09.2026, last edit - 19.10.2026
		List<List<String>> res = new ArrayList<>();
		try {
			int innerIndexCol = this.getInnerIndexCol(col);
			if (innerIndexCol < 0) {
				return res = this.row;
			}
			if (Etc.strNotValid(colVal, oper)) {
				return res = this.row;
			}

			List<List<String>> filteredRow = new ArrayList<>();
			filteredRow = this.filter(innerIndexCol, colVal, oper);

			if (filteredRow.size() != 0) {
				res.addAll(filteredRow);
			}
		} catch (Exception ex) {
			WB.addLog("ColRow.filterRowByColValAndOper(int, 2String):List<List<String>>, ex=" + ex.getMessage(), "",
					"ColRow");
		}
		return res;
	}

	private List<List<String>> separateByFirstRow(int separateStartIndexRow) throws Exception {
		// origin - 24.09.2026, last edit - 26.09.2026
		List<List<String>> res = new ArrayList<>();
		try {
			if ((separateStartIndexRow <= 0) || (separateStartIndexRow > this.countRow())) {
				return res = this.row;
			}

			if (separateStartIndexRow == 1) {
				return res = this.row;
			}

			int innerSeparateStartIndexRow = separateStartIndexRow - 1;
			if (innerSeparateStartIndexRow <= 0) {
				return res = this.row;
			}

			List<List<String>> filteredRow = this.row.stream().skip(innerSeparateStartIndexRow)
					.collect(Collectors.toList());
			if (filteredRow.size() != 0) {
				res.addAll(filteredRow);
			}
		} catch (Exception ex) {
			WB.addLog("ColRow.separateByFirstRow(int):List<List<String>>, ex=" + ex.getMessage(), "", "ColRow");
		}
		return res;
	}

	public List<List<String>> separateCol(int[] separateIndexCol) throws Exception {
		// origin - 20.09.2026, last edit - 21.09.2026
		List<List<String>> res = new ArrayList<>();
		try {
			if (separateIndexCol.length == 0) {
				return res;
			}

			int[] innerSeparateIndexCol = this.getInnerIndexCol(separateIndexCol);
			if (innerSeparateIndexCol.length == 0) {
				return res;
			}

			Set<Integer> targetColumns = Arrays.stream(innerSeparateIndexCol).boxed().collect(Collectors.toSet());
			List<List<String>> filteredRow = this.row.stream().map(row -> targetColumns.stream()
					.filter(index -> index >= 0 && index < row.size()).map(row::get).collect(Collectors.toList()))
					.collect(Collectors.toList());

			if (filteredRow.size() != 0) {
				res.addAll(filteredRow);
			}
		} catch (Exception ex) {
			WB.addLog("ColRow.separateCol(int[]):List<List<String>>, ex=" + ex.getMessage(), "", "ColRow");
		}
		return res;
	}

	private int[] getInnerIndexCol(int[] outerIndexCol) throws Exception {
		// origin - 21.09.2026, last edit - 27.09.2026
		int[] res = {};
		try {
			int maxCol = this.countCol();
			List<Integer> tmpList = new ArrayList<>();
			int testValue = 0;
			for (int i = 0; i < outerIndexCol.length; i++) {
				testValue = outerIndexCol[i];
				if (testValue > maxCol) {
					continue;
				}
				if (testValue <= 0) {
					continue;
				}
				tmpList.add(testValue - 1); // to inner index
			}
			int[] innerSeparateIndexCol = new int[tmpList.size()];
			for (int i = 0; i < tmpList.size(); i++) {
				innerSeparateIndexCol[i] = tmpList.get(i);
			}

			if (innerSeparateIndexCol.length != 0) {
				res = innerSeparateIndexCol;
			}
		} catch (Exception ex) {
			WB.addLog("ColRow.getInnerIndexCol(int[]):int[], ex=" + ex.getMessage(), "", "ColRow");
		}
		return res;
	}

	private int getInnerIndexCol(int outerIndexCol) throws Exception {
		// origin - 26.09.2026, last edit - 26.09.2026
		int res = -1;
		try {
			if (outerIndexCol > this.countCol()) {
				return res;
			}
			if (outerIndexCol <= 0) {
				return res;
			}
			res = outerIndexCol - 1; // to inner index
		} catch (Exception ex) {
			WB.addLog("ColRow.getInnerIndexCol(int):int, ex=" + ex.getMessage(), "", "ColRow");
		}
		return res;
	}

	private int countRow() throws Exception {
		// origin - 20.09.2026, last edit - 27.09.2026
		int res = 0;
		try {
			res = this.row.size();
		} catch (Exception ex) {
			WB.addLog("ColRow.countRow():int, ex=" + ex.getMessage(), "", "ColRow");
		}
		return res;
	}

	private int countCol() throws Exception {
		// origin - 20.09.2026, last edit - 27.09.2026
		int res = 0;
		try {
			res = this.row.isEmpty() ? 0 : this.row.get(0).size();
		} catch (Exception ex) {
			WB.addLog("ColRow.countCol():int, ex=" + ex.getMessage(), "", "ColRow");
		}
		return res;
	}

	private Map<Integer, Double> sum() throws Exception {
		// origin - 28.09.2026, last edit - 28.09.2026
		Map<Integer, Double> res = new HashMap<>();
		try {
			List<BigDecimal> columnSums = new ArrayList<>();

			if (this.row == null || this.row.isEmpty()) {
				return res;
			}

			// Находим максимальное количество колонок, чтобы обработать неровные матрицы
			int maxCols = 0;
			for (List<String> row : this.row) {
				if (row != null && row.size() > maxCols) {
					maxCols = row.size();
				}
			}

			for (int i = 0; i < maxCols; i++) {
				columnSums.add(BigDecimal.ZERO); // init cols by zero
			}

			for (List<String> row : this.row) { // Идем по каждой строке матрицы
				if (row == null) {
					continue;
				}
				for (int col = 0; col < row.size(); col++) {
					String value = row.get(col);
					// Пытаемся распарсить значение. Если это не число — просто пропускаем.
					BigDecimal parsedValue = Num.parseBigDecimal(value);
					if (parsedValue != null) {
						BigDecimal currentSum = columnSums.get(col);
						columnSums.set(col, currentSum.add(parsedValue));
					}
				}
			}

			return IntStream.range(0, columnSums.size()).boxed()
					.collect(Collectors.toMap(index -> index, index -> columnSums.get(index).doubleValue()));
		} catch (Exception ex) {
			WB.addLog("ColRow.sum():Map<Integer, Double>, ex=" + ex.getMessage(), "", "ColRow");
		}
		return res;
	}

	public Map<Integer, Double> sum(int colSum[]) throws Exception {
		// origin - 31.08.2026, last edit - 28.09.2026
		Map<Integer, Double> res = new HashMap<>();
		try {
			if (colSum.length == 0) {
				return res;
			}

			int[] innerSeparateIndexCol = this.getInnerIndexCol(colSum);
			if (innerSeparateIndexCol.length == 0) {
				return res;
			}

			var tmp1 = this.sum();
			for (var i = 0; i < innerSeparateIndexCol.length; i++) {
				var tmp2 = innerSeparateIndexCol[i];
				var tmp3 = tmp1.get(tmp2);
				res.put(tmp2, tmp3);
			}
		} catch (Exception ex) {
			WB.addLog("ColRow.sum(int[]):Map<Integer, Double>, ex=" + ex.getMessage(), "", "ColRow");
		}
		return res;
	}

	public Map<Integer, Double> sum(int colSum) throws Exception {
		// origin - 31.08.2026, last edit - 31.08.2026
		Map<Integer, Double> res = new HashMap<>();
		try {
			int[] tmp = { colSum };
			res = this.sum(tmp);
		} catch (Exception ex) {
			WB.addLog("ColRow.sum(int):Map<Integer, Double>, ex=" + ex.getMessage(), "", "ColRow");
		}
		return res;
	}

	public Map<List<String>, List<Double>> groupingWithSum(int[] colGrouping, int[] colSum) throws Exception {
		// origin - 31.08.2026, last edit - 21.09.2026
		Map<List<String>, List<Double>> res = new HashMap<>();
		try {
			if (colGrouping.length == 0) {
				return res;
			}

			int[] innerGroupingIndexCol = this.getInnerIndexCol(colGrouping);
			if (innerGroupingIndexCol.length == 0) {
				return res;
			}
			int[] innerSumIndexCol = this.getInnerIndexCol(colSum);

			List<Integer> colGroupingList = Arrays.stream(innerGroupingIndexCol).map(x -> x).boxed().toList();
			List<Integer> colSumList = Arrays.stream(innerSumIndexCol).map(x -> x).boxed().toList();
			Map<List<String>, List<Double>> tmp = this.row.stream().collect(Collectors.groupingBy(
					row -> colGroupingList.stream().map(row::get).collect(Collectors.toList()),
					Collectors.reducing(
							new ArrayList<>(Collections.nCopies(colSumList.size(), 0.0)), row -> colSumList.stream()
									.map(idx -> Double.parseDouble(row.get(idx))).collect(Collectors.toList()),
							(list1, list2) -> {
								List<Double> sum = new ArrayList<>();
								for (int i = 0; i < list1.size(); i++) {
									sum.add(list1.get(i) + list2.get(i));
								}
								return sum;
							})));
			res = tmp;
		} catch (Exception ex) {
			WB.addLog("ColRow.groupingWithSum(2int[]):Map<List<String>, List<Double>>, ex=" + ex.getMessage(), "",
					"ColRow");
		}
		return res;
	}

	public Map<Object, Double> groupingWithSum(int[] colGrouping, int colSum) throws Exception {
		// origin - 30.08.2026, last edit - 21.09.2026
		Map<Object, Double> res = new HashMap<>();
		try {
			if (colGrouping.length == 0) {
				return res;
			}

			int[] innerGroupingIndexCol = this.getInnerIndexCol(colGrouping);
			if (innerGroupingIndexCol.length == 0) {
				return res;
			}
			int innerColSum = colSum - 1;

			List<Integer> colList = Arrays.stream(innerGroupingIndexCol).map(x -> x).boxed().toList();
			Map<Object, Double> tmp = this.row.stream()
					.collect(Collectors.groupingBy(row -> colList.stream().map(row::get).collect(Collectors.toList()),
							Collectors.summingDouble(row -> {
								String val = row.get(innerColSum);
								return (val == null || val.isEmpty()) ? 0.0 : Double.parseDouble(val);
							})));
			res = tmp;
		} catch (Exception ex) {
			WB.addLog("ColRow.groupingWithSum(int[],int):Map<Object, Double>, ex=" + ex.getMessage(), "", "ColRow");
		}
		return res;
	}

	public Map<Object, List<List<String>>> grouping(int[] col) throws Exception {
		// origin - 24.08.2026, last edit - 21.09.2026
		Map<Object, List<List<String>>> res = new HashMap<>();
		try {
			if (col.length == 0) {
				return res;
			}

			int[] innerGroupingIndexCol = this.getInnerIndexCol(col);
			if (innerGroupingIndexCol.length == 0) {
				return res;
			}

			List<Integer> colList = Arrays.stream(innerGroupingIndexCol).map(x -> x).boxed().toList();
			Map<Object, List<List<String>>> tmp = this.row.stream()
					.collect(Collectors.groupingBy(row -> colList.stream().map(row::get).collect(Collectors.toList())));
			res = tmp;
		} catch (Exception ex) {
			WB.addLog("ColRow.grouping(int[]):Map<Object, List<List<String>>>, ex=" + ex.getMessage(), "", "ColRow");
		}
		return res;
	}

	public Map<String, List<List<String>>> grouping(int col) throws Exception {
		// origin - 24.08.2026, last edit - 21.09.2026
		Map<String, List<List<String>>> res = new HashMap<>();
		try {
			int innerGroupingIndexCol = col - 1;
			Map<String, List<List<String>>> tmp = this.row.stream()
					.collect(Collectors.groupingBy(row -> row.get(innerGroupingIndexCol)));
			res = tmp;
		} catch (Exception ex) {
			WB.addLog("ColRow.grouping(int):Map<String, List<List<String>>>, ex=" + ex.getMessage(), "", "ColRow");
		}
		return res;
	}

	public void sort(int col) throws Exception {
		// origin - 31.08.2026, last edit - 31.08.2026
		try {
			int[] tmp = { col };
			this.sort(tmp);
		} catch (Exception ex) {
			WB.addLog("ColRow.sort(int):void, ex=" + ex.getMessage(), "", "ColRow");
		}
	}

	public void sort(int[] col) throws Exception {
		// origin - 23.08.2026, last edit - 21.09.2026
		try {
			if (col.length == 0) {
				return;
			}

			int[] innerSortIndexCol = this.getInnerIndexCol(col);
			if (innerSortIndexCol.length == 0) {
				return;
			}

			// start comparator
			Comparator<List<String>> multiComparator = Comparator.comparing(row -> row.get(innerSortIndexCol[0]));
			// add next comparators
			for (int i = 1; i < col.length; i++) {
				int index = innerSortIndexCol[i]; // Создаем effectively final переменную для лямбды
				multiComparator = multiComparator.thenComparing(row -> row.get(index));
			}
			// sort by chain comparators
			var tmp = this.row.stream().sorted(multiComparator).collect(Collectors.toList());
			this.row.clear();
			this.row.addAll(tmp);
		} catch (Exception ex) {
			WB.addLog("ColRow.sort(int[]):void, ex=" + ex.getMessage(), "", "ColRow");
		}
	}

	public List<String> getRowByIndex(int index) throws Exception { // userindex start on 1
		// origin - 19.02.2026, last edit - 24.02.2026
		List<String> res = new ArrayList<String>();
		try {
			res = this.row.get(index - 1); // innerIndex start on 0
		} catch (Exception ex) {
			WB.addLog("ColRow.getRowByIndex(int):List<String>, ex=" + ex.getMessage(), "", "ColRow");
		}
		return res;
	}

	private List<List<String>> getRowList(List<String> in) throws Exception {
		// origin - 23.08.2026, last edit - 24.08.2026
		List<List<String>> res = new ArrayList<>();
		try {
			for (var curr : in) {
				// get row
				List<String> tmp = new ArrayList<String>();
				var tmp1 = Etc.delTailStr(curr, ColRow.delimiter);
				var tmp2 = List.of(tmp1.split(ColRow.delimiter));
				tmp.addAll(Etc.fixTrim(tmp2));

				res.add(tmp);
			}
		} catch (Exception ex) {
			WB.addLog("ColRow.getRowList(List<String>):List<List<String>>, ex=" + ex.getMessage(), "", "ColRow");
		}
		return res;
	}

	public void fix() throws Exception {
		// origin - 19.08.2026, last edit - 10.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}
		} catch (Exception ex) {
			WB.addLog("ColRow.fix():void, ex=" + ex.getMessage(), "", "ColRow");
		}
	}

	private void validate() throws Exception {
		// origin - 18.02.2026, last edit - 10.10.2026
		try {
			if (this.id.isEmpty()) {
				return;
			}
		} catch (Exception ex) {
			WB.addLog("ColRow.validate():void, ex=" + ex.getMessage(), "", "ColRow");
		}
	}

	public ColRow(List<String> Src) throws Exception {
		// origin - 16.02.2026, last edit - 23.08.2026
		this.clear();
		this.src = Etc.fixTrim(Src);
		this.row.addAll(this.getRowList(this.src));
		this.fix();
		this.validate();
	}

	public ColRow() throws Exception {
		// origin - 15.02.2026, last edit - 15.02.2026
		this.clear();
	}

	private void clear() throws Exception {
		// origin - 15.02.2026, last edit - 24.08.2026
		try {
			this.id = this.code = this.description = this.defect = "";
			this.src = new ArrayList<String>();
			this.row = new ArrayList<>();
		} catch (Exception ex) {
			WB.addLog("ColRow.clear():void, ex=" + ex.getMessage(), "", "ColRow");
		}
	}

	public String toString() {
		// origin - 15.02.2026, last edit - 01.09.2026
		String res = "";
		try {
			res = res + Fmtr.addIfNotEmpty("id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", src.size ", this.src.size());
			res = res + Fmtr.addIfNotEmpty(", src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", row.size ", this.row.size());
			res = res + Fmtr.addIfNotEmpty(", row ", this.row);
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 15.02.2026, last edit - 30.09.2026
		try {

//			{
//				WB.addLog2("ColRow.test.isFilter(String;List<String>):boolean", "", "ColRow");
//				var tmp1 = List.of("eqv", "noteqv", "tralala", "eqv19", "noteqv856");
//				for (var tmp2 : tmp1) {
//					WB.addLog2("ColRow.test.isFilter(String,List<String>):boolean, res=" + ColRow.isFilter(tmp2)
//							+ ", tmp2=" + tmp2, "", "ColRow");
//				}
//			}

//			{
//				WB.addLog2("ColRow.test.filterRowByColValAndOper(int;2String):List<List<String>>;", "", "ColRow");
//				var tmp1 = List.of("Face1|W12|Unit.Kg|100|200|", "Face2|W13|Unit.Kg|300|400|",
//						"Face1|W13|Unit.Gr|500|600|", "Face1|W12|Unit.Kg|700|800|");
//				var tmp2 = new ColRow(tmp1);
//				WB.addLog2(
//						"ColRow.test.filterRowByColValAndOper(int,2String):List<List<String>>, source for filterRowByColVal",
//						"", "ColRow");
//				WB.log(tmp2.row, "ColRow");
//				for (var tmp3 : new int[] { 1, 2, 3, 4, 8, 0, -2 }) {
//					for (var tmp4 : new String[] { "", "Face1", "W12", "Unit.Kg", "100", "200" }) {
//						for (var tmp5 : new String[] { "", "eqv", "noteqv", "tralala" }) {
//							var tmp6 = tmp2.filterRowByColValAndOper(tmp3, tmp4, tmp5);
//							WB.addLog2(
//									"ColRow.test.filterRowByColValAndOper(int,2String):List<List<String>>, res.size="
//											+ tmp6.size() + ", tmp3=" + tmp3 + ", tmp4=" + tmp4 + ", tmp5=" + tmp5,
//									"", "ColRow");
//							WB.log(tmp6, "ColRow");
//						}
//					}
//				}
//			}

//			{
//				WB.addLog2("ColRow.test.separateByFirstRow(int):List<List<String>>;", "", "ColRow");
//				var tmp1 = List.of("Face1|W12|Unit.Kg|100|200|", "Face2|W13|Unit.Kg|300|400|",
//						"Face1|W13|Unit.Gr|500|600|", "Face1|W12|Unit.Kg|700|800|");
//				var tmp2 = new ColRow(tmp1);
//				WB.addLog2("ColRow.test.separateByFirstRow(int):List<List<String>>, before separateRowStartWith",
//						"", "ColRow");
//				WB.log(tmp2.row, "ColRow");
//				for (var tmp3 : new int[] { 1, 2, 3, 4, 8, 0, -2 }) {
//					var tmp4 = tmp2.separateByFirstRow(tmp3);
//					WB.addLog2("ColRow.test.separateByFirstRow(int):List<List<String>>, res.size=" + tmp4.size()
//							+ ", tmp3=" + tmp3, "", "ColRow");
//					WB.log(tmp4, "ColRow");
//				}
//			}

//			{
//				WB.addLog2("ColRow.test.separateCol(int[]):List<List<String>>;", "", "ColRowVal");
//				var tmp1 = List.of("Face1|W12|Unit.Kg|100|200|", "Face2|W13|Unit.Kg|300|400|",
//						"Face1|W13|Unit.Gr|500|600|", "Face1|W12|Unit.Kg|700|800|");
//				var tmp2 = new ColRow(tmp1);
//				WB.addLog2("ColRow.test.separateCol(int[]):List<List<String>>, before separateCol", "", "ColRow");
//				WB.log(tmp2.row, "ColRow");
//				for (var tmp3 : new int[][] { {}, { 1 }, { 1, 2 }, { 1, 2, 3 }, { 2, 4 }, { 8 } }) {
//					var tmp4 = tmp2.separateCol(tmp3);
//					WB.addLog2("ColRow.test.separateCol(int[]):List<List<String>>, res.size=" + tmp4.size()
//							+ ", tmp3=" + Fmtr.listVal(tmp3), "", "ColRow");
//					WB.log(tmp4, "ColRow");
//				}
//			}

//			{
//				WB.addLog2("ColRow.test.sum():Map<Integer; Double>", "", "ColRow");
//				var tmp1 = List.of("Face1|W12|Unit.Kg|-100|200|", "Face2|W13|Unit.Kg|Face5|400|",
//						"Face1|W13|Unit.Gr|500|600|", "Face1|W12|Unit.Kg|700|800.07|");
//				var tmp2 = new ColRow(tmp1);
//				WB.log(tmp2.row, "ColRow");
//				WB.addLog2("ColRow.test.sum():Map<Integer, Double>, res=" + tmp2.sum(), "", "ColRow");
//			}

//			{
//				WB.addLog2("ColRow.test.sum(int[]):Map<Integer; Double>", "", "ColRow");
//				var tmp1 = List.of("Face1|W12|Unit.Kg|-100|200|", "Face2|W13|Unit.Kg|Face5|400|",
//						"Face1|W13|Unit.Gr|500|600|", "Face1|W12|Unit.Kg|700|800.07|");
//				var tmp2 = new ColRow(tmp1);
//				WB.log(tmp2.row, "ColRow");
//				for (var tmp3 : new int[][] { {}, { 1 }, { 1, 2 }, { 1, 2, 3 }, { 2, 4 }, { 4, 5 }, { 4, 8 }, { 6, 7 },
//						{ 8 } }) {
//					WB.addLog2("ColRow.test.sum(int[]):Map<Integer, Double>, res=" + tmp2.sum(tmp3) + ", tmp3="
//							+ Fmtr.listVal(tmp3), "", "ColRow");
//				}
//			}

//			{
//				WB.addLog2("ColRow.test.groupingWithSum(2int[]):map;", "", "ColRow");
//				var tmp1 = List.of("Face1|W12|Unit.Kg|100|200|", "Face2|W13|Unit.Kg|300|400|",
//						"Face1|W13|Unit.Gr|500|600|", "Face1|W12|Unit.Kg|700|800|");
//				var tmp2 = new ColRow(tmp1);
//				WB.log(tmp2.row, "ColRow");
//				var tmp3 = new int[] { 1, 2 };
//				var tmp4 = new int[] { 4, 5 };
//				WB.addLog2("ColRow.test.groupingWithSum(2int[]):map, res=" + tmp2.groupingWithSum(tmp3, tmp4)
//						+ ", tmp3=" + Fmtr.listVal(tmp3) + ", tmp4=" + Fmtr.listVal(tmp4), "", "ColRow");
//			}

//			{
//				WB.addLog2("ColRow.test.groupingWithSum(int[],int):map;", "", "ColRow");
//				var tmp1 = List.of("Face1|W12|Unit.Kg|100|200|", "Face2|W13|Unit.Kg|300|400|",
//						"Face1|W13|Unit.Gr|500|600|", "Face1|W12|Unit.Kg|700|800|");
//				var tmp2 = new ColRow(tmp1);
//				WB.log(tmp2.row, "ColRow");
//				var tmp3 = new int[] { 1, 2 };
//				var tmp4 = new int[] { 4, 5 };
//				for (var tmp5 : tmp4) {
//					WB.addLog2("ColRow.test.groupingWithSum(int[],int):map, res=" + tmp2.groupingWithSum(tmp3, tmp5)
//							+ ", tmp3=" + Fmtr.listVal(tmp3) + ", tmp5=" + tmp5, "", "ColRow");
//				}
//			}

//			{
//				WB.addLog2("ColRow.test.grouping(int[]):map", "", "ColRow");
//				var tmp1 = List.of("Face1|W12|Unit.Kg|100|200|", "Face2|W13|Unit.Kg|300|400|",
//						"Face1|W13|Unit.Gr|500|600|", "Face1|W12|Unit.Kg|700|800|");
//				var tmp2 = new ColRow(tmp1);
//				var tmp3 = new int[] { 1, 2 };
//				WB.addLog2("ColRow.test.grouping(int[]):map, res=" + tmp2.grouping(tmp3) + ", tmp3="
//						+ Fmtr.listVal(tmp3), "", "ColRow");
//
//			}

//			{
//				WB.addLog2("ColRow.test.grouping(int):map", "", "ColRow");
//				var tmp1 = List.of("Face1|W12|Unit.Kg|P1|S2 |", "Face2|W13|Unit.Kg|P3|S4|",
//						"Face1|W13|Unit.Gr|P300|S400|");
//				var tmp2 = new ColRow(tmp1);
//				for (var tmp3 : new int[] { 3, 2, 1 }) {
//					WB.addLog2("ColRow.test.grouping(int):map, res=" + tmp2.grouping(tmp3) + ", tmp3=" + tmp3, "",
//							"ColRow");
//				}
//			}

//			{
//				WB.addLog2("ColRow.test.sort(int[]):void", "", "ColRowVal");
//				var tmp1 = List.of("Face1|W12|Unit.Kg|P1|S2 |", "Face2|W13|Unit.Kg|P3|S4|",
//						"Face1|W13|Unit.Gr|P300|S400|");
//				var tmp2 = List.of("Иванов|Сергей|Сергеевич|", "Петров|Анатолий|Анатольевич|",
//						"Johnson|John|Johniest|");
//				List<List<String>> tmp3 = new ArrayList<>();
//				tmp3.add(tmp1);
//				tmp3.add(tmp2);
//				for (var tmp4 : tmp3) {
//					for (var tmp0 : new int[][] { { 3 }, { 2 }, { 1 }, { 3, 2 }, { 2, 3 }, { 3, 1 } }) {
//						var tmp5 = new ColRow(tmp4);
//						WB.addLog2(
//								"ColRow.test.sort(int[]):void, before this.sort()" + ", tmp0=" + Fmtr.listVal(tmp0),
//								"", "ColRow");
//						WB.log(tmp5.row, "ColRow");
//						tmp5.sort(tmp0);
//						WB.addLog2("ColRow.test.sort(int[]):void, after this.sort()" + " tmp0=" + Fmtr.listVal(tmp0),
//								"", "ColRow");
//						WB.log(tmp5.row, "ColRow");
//					}
//				}
//			}

//			{
//				WB.addLog2("ColRow.test.getRowByIndex(int):String", "", "ColRow");
//				var tmp1 = List.of(""Face1|W12|Unit.Kg|1|2 |", "Face2|W13|Unit.Kg|3|4",
//						"Face1|W13|Unit.Gr|300|400");
//				var tmp2 = new ColRow(tmp1);
//				WB.log(tmp2.row, "ColRow");
//				for (var tmp3 : new int[] { 1, 2, 3, 4 }) {
//					WB.addLog2("ColRow.test.getRowByIndex(int):String, res=" + tmp2.getRowByIndex(tmp3) + " userIndex="
//							+ tmp3, "", "ColRow");
//				}
//			}

//			{
//				WB.addLog2("ColRow.test.getColNameByIndex(int):String", "", "ColRow");
//				var tmp1 = List.of("Face1|W12|Unit.Kg|1|2 |", "Face2|W13|Unit.Kg|3|4",
//						"Face1;W13;Unit.Gr;300;400");
//				var tmp2 = new ColRow(tmp1);
//				for (var tmp3 : new int[] { 1, 2, 3, 4, 5 }) {
//					WB.addLog2("ColRow.test.getColNameByIndex(int):String, res=" + tmp2.getColNameByIndex(tmp3)
//							+ " userIndex=" + tmp3, "", "ColRow");
//				}
//			}

//			{
//				WB.addLog2("ColRow.test.getIndexByColName(String):int", "", "ColRow");
//				var tmp1 = List.of("Face1|W12|Unit.Kg|1|2 |", "Face2;W13;Unit.Kg;3;4",
//						"Face1;W13;Unit.Gr;300;400");
//				var tmp2 = new ColRow(tmp1);
//				for (var tmp3 : new String[] { "Face", "Weight", "Unit", "Price", "Sum" }) {
//					WB.addLog2("ColRow.test.getIndexByColName(String):int, res=" + tmp2.getIndexByColName(tmp3)
//							+ " colName=" + tmp3, "", "ColRow");
//				}
//			}

//			{
//			WB.addLog2("ColRow.test.countCol():int,countRow():int;", "", "ColRowVal");
//			var tmp1 = List.of("Face1|W12|Unit.Kg|100|200|", "Face2|W13|Unit.Kg|300|400|",
//					"Face1|W13|Unit.Gr|500|600|", "Face1|W12|Unit.Kg|700|800|");
//			var tmp2 = new ColRow(tmp1);
//			WB.log(tmp2.row, "ColRow");
//			WB.addLog2("ColRow.test.countCol():int, res=" + tmp2.countCol(), "", "ColRow");
//			WB.addLog2("ColRow.test.countRow():int, res=" + tmp2.countRow(), "", "ColRow");
//		}

//			{
//				WB.addLog2("ColRow.test.ctor(List<String>)", "", "ColRow");
//				var tmp1 = List.of("Face1|W12|Unit.Kg|1|2 |", "Face2|W13|Unit.Kg|3|4", "Face1|W13|Unit.Gr|300|400");
//				var tmp2 = new ColRow(tmp1);
//				WB.addLog2("ColRow.test.ctor(List<String>), res=" + tmp2, "", "ColRow");
//				WB.log(tmp2.row, "ColRow");
//			}

		} catch (Exception ex) {
			WB.addLog("ColRow.test():void, ex=" + ex.getMessage(), "", "ColRow");
		}
	}
}