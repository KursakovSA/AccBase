import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

public final class DAL {
	// origin - 23.10.2023, last edit - 12.10.2025
	static {
		try {
		} catch (Exception ex) {
			WB.addLog("DAL.static ctor, ex=" + ex.getMessage(), "", "DAL");
		}
	}

	public static List<FullDto> removeDuplicate(List<FullDto> dtoCollector, List<FullDto> dtoAdd) throws Exception {
		// origin - 03.06.2024, last edit - 13.06.2025
		LocalDateTime localStart = WB.getLocalStart();
		List<FullDto> res = new ArrayList<FullDto>();
		WB.addLog2("DAL.removeDuplicate, before work, res.size=" + res.size() + ", dtoCollector.size="
				+ dtoCollector.size() + ", dtoAdd.size=" + dtoAdd.size(), "", "DAL");
		String strCurrDtoRes = "";
		String strCurrDtoAdd = "";
		boolean hasEqualsCollectorAdd = false;
		try {
			if (dtoCollector.isEmpty()) {
				res.addAll(dtoAdd);
			} else {
				for (var currDtoAdd : dtoAdd) {
					strCurrDtoAdd = currDtoAdd.toString();// strCurrDtoAdd = currDtoAdd.id;
					for (var currDtoRes : dtoCollector) {
						strCurrDtoRes = currDtoRes.toString();// strCurrDtoRes = currDtoRes.id;
						hasEqualsCollectorAdd = false;
						if (strCurrDtoRes.equals(strCurrDtoAdd)) {
							hasEqualsCollectorAdd = true;
							break;
						}
					}
					if (hasEqualsCollectorAdd == false) {
						res.add(new FullDto(currDtoAdd));
					}
				}
			}
			res.addAll(dtoCollector);
		} catch (Exception ex) {
			WB.addLog("DAL.removeDuplicate(2List<FullDto>):List<FullDto>, ex=" + ex.getMessage(), "", "DAL");
		}
		WB.getLocalEnd("DAL.removeDuplicate for List<FullDto> dtoCollector.size=" + dtoCollector.size()
				+ ", dtoAdd.size=" + dtoAdd.size(), localStart);
		WB.addLog2("DAL.removeDuplicate, after work, res.size=" + res.size() + ", dtoCollector.size="
				+ dtoCollector.size() + ", dtoAdd.size=" + dtoAdd.size(), "", "DAL");
		return res;
	}

	public static void getReplaceInto(TreeSet<String> setConn, List<FullDto> set) throws Exception {
		// origin - 09.02.2024, last edit - 13.06.2025
		try {
			for (var currConn : setConn) {
				DAL.setReplaceInto(currConn, set);
			}
		} catch (Exception ex) {
			WB.addLog("DAL.getReplaceInto(TreeSet<String>, List<FullDto>):void, ex=" + ex.getMessage(), "", "DAL");
		}
	}

	public static void setReplaceInto(String currConn, List<FullDto> set) throws Exception {
		// origin - 02.02.2024, last edit - 25.04.2026
		try {
			currConn = Conn.getText(currConn);
			WB.lastConn = currConn;
			Connection conn = DriverManager.getConnection(currConn);
			conn.setAutoCommit(false);
			PreparedStatement qry = null;
			for (var currDto : set) {
				// PreparedStatement qry = conn.prepareStatement(Qry.getReplaceInto(currDto));
				qry = conn.prepareStatement(Qry.getReplaceInto(currDto));
				qry.executeUpdate();
				qry.close();
			}
			qry = null;
			conn.commit();
			conn.setAutoCommit(true);
			conn.close();
			conn = null;
		} catch (Exception ex) {
			WB.addLog("DAL.setReplaceInto(String, List<FullDto>):void, ex=" + ex.getMessage(), "", "DAL");
		}
	}

	public static void getVacuum(TreeSet<String> setConn) throws Exception {
		// origin - 19.12.2023, last edit - 13.06.2025
		for (var currConn : setConn) {
			currConn = Conn.getText(currConn);
			try {
				Connection conn = DriverManager.getConnection(currConn);
				WB.lastConn = currConn;
				java.sql.Statement qry = conn.createStatement();
				qry.execute(Qry.vacuumCmdSQLite);// getVacuum(currConn));
				conn.close();
			} catch (Exception ex) {
				WB.addLog("DAL.getVacuum(TreeSet<String>):void, ex=" + ex.getMessage(), "", "DAL");
			}
		}
	}

	public static void getReindex(TreeSet<String> setConn) throws Exception {
		// origin - 19.12.2023, last edit - 13.06.2025
		for (var currConn : setConn) {
			currConn = Conn.getText(currConn);
			try {
				Connection conn = DriverManager.getConnection(currConn);
				WB.lastConn = currConn;
				java.sql.Statement qry = conn.createStatement();
				qry.execute(Qry.reindexCmdSQLite);// getReindex(currConn));
				conn.close();
			} catch (Exception ex) {
				WB.addLog("DAL.getReindex(TreeSet<String>):void, ex=" + ex.getMessage(), "", "DAL");
			}
		}
	}

	public static void getIntegrityCheck(TreeSet<String> setConn) throws Exception {
		// origin - 19.12.2023, last edit - 13.06.2025
		for (var currConn : setConn) {
			currConn = Conn.getText(currConn);
			try {
				Connection conn = DriverManager.getConnection(currConn);
				WB.lastConn = currConn;
				java.sql.Statement qry = conn.createStatement();
				qry.execute(Qry.integrityCheckCmdSQLite);// getIntegrityCheck(currConn));

				qry.close();
				qry = null;
				conn.close();
				conn = null;
			} catch (Exception ex) {
				WB.addLog("DAL.getIntegrityCheck(TreeSet<String>):void, ex=" + ex.getMessage(), "", "DAL");
			}
		}
	}

	public static void getOutputBackup(TreeSet<String> setConn) throws Exception {
		// origin - 28.05.2024, last edit - 13.06.2025
		for (var currConn : setConn) {
			currConn = Conn.getText(currConn);
			try {
				Connection conn = DriverManager.getConnection(currConn);
				WB.lastConn = currConn;
				java.sql.Statement qry = conn.createStatement();
				qry.execute(Qry.getOutputBackup(currConn));
				qry.close();
				qry = null;
				conn.close();
				conn = null;
			} catch (Exception ex) {
				WB.addLog("DAL.getOutputBackup(TreeSet<String>):void, ex=" + ex.getMessage(), "", "DAL");
			}
		}
	}

	public static void getBackup(TreeSet<String> setConn) throws Exception {
		// origin - 18.12.2023, last edit - 13.06.2025
		for (var currConn : setConn) {
			currConn = Conn.getText(currConn);
			try {
				Connection conn = DriverManager.getConnection(currConn);
				WB.lastConn = currConn;
				java.sql.Statement qry = conn.createStatement();
				qry.execute(Qry.getBackup(currConn));

				qry.close();
				qry = null;
				conn.close();
				conn = null;
			} catch (Exception ex) {
				WB.addLog("DAL.getBackup(TreeSet<String>):void, ex=" + ex.getMessage(), "", "DAL");
			}
		}
	}

	public static List<FullDto> setByTemplate(TreeSet<String> setConn, String templateMore) throws Exception {
		// TOTHINK - add other template - asset, face, etc.
		// origin - 30.05.2024, last edit - 13.06.2025
		// get common FullDto what consist all tables all conn from multiply conn
		List<FullDto> res = new ArrayList<FullDto>();
		List<FullDto> tmp = new ArrayList<FullDto>();
		try {
			for (var currConn : setConn) {
				if (DAL.existFile(currConn) == false) {
					WB.addLog("DAL.setByTemplate(), not exist=" + currConn, "", "DAL");
					return res;
				}

				tmp.clear();
				tmp = DAL.getByTemplate(currConn, templateMore);
				if (tmp.isEmpty() == false) {
					res.addAll(tmp);
					tmp.clear();
				}
			}
		} catch (Exception ex) {
			WB.addLog("DAL.setByTemplate(TreeSet<String>, String):List<FullDto>, ex=" + ex.getMessage(), "", "DAL");
		}
		return res;
	}

	private static boolean isSkip(String currConn, String templateMore, String currTable) throws Exception {
		// origin - 18.06.2024, last edit - 13.06.2025
		// this method skip very big table Workbook in that bases where its not need for
		// read metadata
		Boolean res = false;
		try {
			if (Etc.strContains(currTable, "Workbook")) {
				if (Etc.strContains(templateMore, "AbcBasic")) {
					res = true;
				}
				if (Etc.strContains(currConn, Conn.globalDbPattern)) {// exception for "DatabaseGlobal"
					res = false;
				}
				if (Etc.strContains(currConn, Conn.templateDbPattern)) {// exception for "DatabaseTemplate"
					res = false;
				}
				if (Etc.strContains(currConn, Conn.localDbPattern)) {// exception for "DatabaseLocal"
					res = false;
				}
			}
		} catch (Exception ex) {
			WB.addLog("DAL.isSkip(3String):boolean, ex=" + ex.getMessage(), "", "DAL");
		}
		return res;
	}

	public static List<FullDto> getByTemplate(String currConn, String templateMore, String table) throws Exception {
		// origin - 12.08.2024, last edit - 13.06.2025
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			if (DAL.existFile(currConn) == false) {
				WB.addLog("DAL.getByTemplate(), not exist=" + currConn, "", "DAL");
				return res;
			}
			res = DAL.getTable(currConn, Qry.getText(currConn, table, templateMore));
		} catch (Exception ex) {
			WB.addLog("DAL.getByTemplate(3String):List<FullDto>, ex=" + ex.getMessage(), "", "DAL");
		}
		return res;
	}

	public static List<FullDto> getByTemplate(String currConn, String templateMore) throws Exception {
		// origin - 13.11.2023, last edit - 13.06.2025
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			if (DAL.existFile(currConn) == false) {
				WB.addLog("DAL.getByTemplate(), not exist=" + currConn, "", "DAL");
				return res;
			}

			List<FullDto> tmp = new ArrayList<FullDto>();
			List<String> tableList = DAL.getTableList(currConn);
			for (var currTable : tableList) {

				// skip table Workbook for abc, in Workbook no basic
				if (DAL.isSkip(currConn, templateMore, currTable)) {
					continue;
				}

				tmp.clear();
				tmp = DAL.getTable(currConn, Qry.getText(currConn, currTable, templateMore));
				if (tmp.isEmpty() != true) {
					res.addAll(tmp);
					tmp.clear();
				}
			}
		} catch (Exception ex) {
			WB.addLog("DAL.getByTemplate(2String):List<FullDto>, ex=" + ex.getMessage(), "", "DAL");
		}
		return res;
	}

	public static List<String> getColumnList(String table) throws Exception {
		// origin - 31.01.2026, last edit - 31.01.2026
		List<String> res = new ArrayList<String>();
		String currConn = WB.lastConnWork;

		if (DAL.existFile(currConn) == false) {
			WB.addLog("DAL.getColumnList, not exist=" + currConn, "", "DAL");
			return res;
		}

		if (table.isEmpty() == false) {
			currConn = Conn.getText(currConn);
			try {
				Connection conn = DriverManager.getConnection(currConn);
				WB.lastConn = currConn;
				DatabaseMetaData metaData = conn.getMetaData();
				ResultSet columns = metaData.getColumns(null, null, table, null);
				while (columns.next()) {
					res.add(columns.getString("COLUMN_NAME"));
				}
				conn.close();
				conn = null;
			} catch (Exception ex) {
				WB.addLog("DAL.getColumnList(String):List<String>, ex=" + ex.getMessage(), "", "DAL");
			}
		}
		return res;
	}

	public static boolean hasTableByTableList(String table) throws Exception {
		// origin - 01.03.2026, last edit - 01.03.2026
		boolean res = false;
		List<String> dbTableFactList = DAL.getTableList(WB.lastConnWork);
		try {
			for (var curr : dbTableFactList) {
				if (Etc.strContains(curr, table)) {
					res = true;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("DAL.hasTableByTableList(String):boolean, ex=" + ex.getMessage(), "", "DAL");
		}
		return res;
	}

	public static List<String> getTableList(String currConn) throws Exception {
		// origin - 13.11.2023, last edit - 13.06.2025
		List<String> res = new ArrayList<String>();

		if (DAL.existFile(currConn) == false) {
			WB.addLog("DAL.getTableList, not exist=" + currConn, "", "DAL");
			return res;
		}

		currConn = Conn.getText(currConn);
		try {
			Connection conn = DriverManager.getConnection(currConn);
			WB.lastConn = currConn;
			java.sql.Statement qry = conn.createStatement();
			ResultSet rs;
			rs = qry.executeQuery(Qry.getTableListSQLite);
			while (rs.next()) {
				res.add(rs.getString("name"));
			}
			rs.close();
			rs = null;
			qry.close();
			qry = null;
			conn.close();
			conn = null;

		} catch (Exception ex) {
			WB.addLog("DAL.getTableList(String):List<String>, ex=" + ex.getMessage(), "", "DAL");
		}
		return res;
	}

	public static List<FullDto> getTable(String dbStr, String preparedQryText) throws Exception {
		// origin - 28.10.2023, last edit - 25.03.2026
		List<FullDto> res = new ArrayList<FullDto>();
		try {
			String currConn = Conn.getText(dbStr);

			if (DAL.existFile(currConn) == false) {
				WB.addLog("DAL.getTable, not exist=" + dbStr, "currConn=" + currConn, "DAL");
				return res;
			}

			res = DAL.getFullDto(currConn, preparedQryText);
//			WB.addLog2("DAL.getTable, db=" + Etc.getFileName(dbStr) + ", qry=" + preparedQryText + ", cardinality="
//					+ res.size(), "", "DAL()");
		} catch (Exception ex) {
			WB.addLog("DAL.getTable(2String):List<FullDto>, ex=" + ex.getMessage(), "", "DAL");
		}
		return res;
	}

	private static List<FullDto> getFullDto(String currConn, String preparedQryText) throws Exception {
		// origin - 31.10.2023, last edit - 13.06.2025
		List<FullDto> res = new ArrayList<FullDto>();

		if (DAL.existFile(currConn) == false) {
			WB.addLog("DAL.getFullDto, not exist=" + currConn, "", "DAL");
			return res;
		}

		currConn = Conn.getText(currConn);
		try {
			Connection conn = DriverManager.getConnection(currConn);
			WB.lastConn = currConn;
			java.sql.Statement qry = conn.createStatement();

			ResultSet rs;
			rs = qry.executeQuery(preparedQryText);

			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			String nameDbColumn = "";
			Class<FullDto> FullDtoClassObject = FullDto.class;
			Field field = null;
			FullDto currDto = new FullDto();

			while (rs.next()) {
				currDto.clear();
				currDto.table = rsmd.getTableName(1);

				for (int i = 1; i <= columnCount; i++) {
					nameDbColumn = rsmd.getColumnName(i);
					// for each nameDbColumn example"Deal" match field FullDto example "deal"
					field = FullDtoClassObject.getField(DAL.getDtoFieldName(nameDbColumn));
					field.set(currDto, Etc.fixString(rs.getString(nameDbColumn)));
				}
				if (currDto.id.isEmpty() != true) {
					res.add(new FullDto(currDto));
				}
			}
			rs.close();
			rs = null;
			qry.close();
			qry = null;
			conn.close();
			conn = null;
		} catch (Exception ex) {
			WB.addLog("DAL.getFullDto(2String):List<FullDto>, ex=" + ex.getMessage(), "", "DAL");
		}
		return res;
	}

	private static String getDtoFieldName(String nameDbColumn) throws Exception {
		// origin - 06.11.2023, last edit - 13.06.2025
		String res = "";
		try {
			res = res + nameDbColumn.charAt(0);
			res = res.toLowerCase();
			// only first letter transform into LowerCase, that was right example
			// "MeterValue to "meterValue"
			res = res + nameDbColumn.substring(1, nameDbColumn.length());
		} catch (Exception ex) {
			WB.addLog("DAL.getDtoFieldName(String):String, ex=" + ex.getMessage(), "", "DAL");
		}
		return res;
	}

	private static boolean existFile(String file) throws Exception {
		// origin - 20.11.2023, last edit - 21.04.2026
		boolean res = true;
		try {
			// file = Etc.delStr(file, Conn.prefixJdbcSqlite);
			file = Etc.delStr(file, Conn.delStrList);
			if (Files.notExists(Paths.get(file))) {
				res = false;
			}
		} catch (Exception ex) {
			WB.addLog("DAL.existFile(String):boolean, ex=" + ex.getMessage(), "", "DAL");
		}
		return res;
	}

	public static List<String> getTest(String preparedQryText) throws Exception {
		// origin - 02.03.2026, last edit - 02.03.2026
		List<String> res = new ArrayList<String>();
		String currConn = Conn.getText(WB.lastConnWork);

		if (DAL.existFile(currConn) == false) {
			WB.addLog("DAL.getTest, currConn not exist=" + currConn, "", "DAL");
			return res;
		}

		currConn = Conn.getText(currConn);
		try {
			Connection conn = DriverManager.getConnection(currConn);
			WB.lastConn = currConn;
			java.sql.Statement qry = conn.createStatement();
			ResultSet rs;
			rs = qry.executeQuery(preparedQryText);

			String line = "";
			ResultSetMetaData md = rs.getMetaData();
			int columnCount = md.getColumnCount();

			while (rs.next()) {
				line = "";
				for (int i = 1; i <= columnCount; i++) {
					String value = rs.getString(i);
					line = line + value + ", ";
				}
				res.add(line);
			}
			rs.close();
			rs = null;
			qry.close();
			qry = null;
			conn.close();
			conn = null;
		} catch (Exception ex) {
			WB.addLog("DAL.getTest(String):List<String>, ex=" + ex.getMessage(), "", "DAL");
		}
		return res;
	}

	private DAL() {
		// origin - 04.11.2024, last edit - 04.11.2024
	}

	public static void test() throws Exception {
		// origin - 21.10.2023, last edit - 02.03.2026
		try {

//			{
//				WB.addLog2("DAL.test.getTest(String):List<String>", "", "DAL");
//				var tmp1 = "WITH RECURSIVE lower AS ( " + "SELECT * FROM Geo " + "WHERE Parent = 'Geo.Qazaqstan' "
//						+ "UNION ALL " + "SELECT t.* FROM Geo t " + "JOIN lower s ON t.Parent = s.Id " + ") "
//						+ "SELECT * FROM lower;"; // test recursive on Geo table
////				var tmp1 = "WITH RECURSIVE cnt(x) AS (" + "  SELECT 1" + "  UNION ALL" // test recursive generally
////						+ "  SELECT x + 1 FROM cnt WHERE x < 5" + ")" + "SELECT x FROM cnt;";
//				var tmp2 = DAL.getTest(tmp1);
//				WB.addLog2("DAL.test.getTest(String):List<String>, res.size=" + tmp2.size(), "", "DAL");
//				WB.log(tmp2, "DAL");
//			}

//			WB.addLog2("DAL.test.getColumnList(String)", "", "DAL");
//			for (var tmp1 : new String[] { "", "Slice", "Geo", "Workbook" }) {
//				var tmp2 = DAL.getColumnList(tmp1);
//				WB.addLog2("DAL.test.getColumnList(String), res=" + tmp2 + ", tmp1=" + tmp1, "", "DAL");
//			}

//			{
//				WB.addLog2("DAL.test.Qry.getRoleMarkFilter(List<String>,List<String>):String", "", "DAL");
//				var tmp1 = List.of("Role.Deal.Pawn".split(","));
//				WB.addLog2("DAL.test.Qry.getRoleMarkFilter(List<String>,List<String>):String, res="
//						+ Qry.getRoleMarkInFilter(tmp1, Mark.qryFilter_MD_TD) + ", tmp1=" + tmp1 + ", Mark.qryFilter="
//						+ Mark.qryFilter_MD_TD, "", "DAL");
//				var listDto = DAL.getByTemplate(WB.lastConnWork, Qry.getRoleMarkInFilter(tmp1, Mark.qryFilter_MD_TD),
//						"Deal");
//				WB.addLog2("DAL.test.getByTemplate(), res.size=" + listDto.size(), "", "DAL");
//				WB.log(listDto, "DAL");
//			}

		} catch (Exception ex) {
			WB.addLog("DAL.test():void, ex=" + ex.getMessage(), "", "DAL");
		}
	}
}