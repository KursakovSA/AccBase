import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.util.LinkedHashMap;
import java.util.TreeSet;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import com.formdev.flatlaf.FlatLightLaf;

public final class GUI {
	// origin - 03.12.2023, last edit - 25.12.2025
	private static JMenuBar basicMenuBar;
	private static JToolBar basicToolBar;
	private static String strMenuMark;
	private static int basicHeightFont;
	private static int basicHeightRowTable;
	private static LinkedHashMap<String, String> basicMenuTitle = new LinkedHashMap<String, String>();
	public static String basicMenuStrLocal;// TOTHINK how get it real value

	static {
		try {
			GUI.strMenuMark = "[Menu]";
			GUI.basicMenuTitle = GUI.getBasicMenuTitle();
			GUI.basicMenuStrLocal = LocInt.emergencyStrLang;
			GUI.basicMenuBar = GUI.getBasicMenuBar();
			GUI.basicToolBar = GUI.getBasicToolBar();
			GUI.basicHeightFont = 15;
			GUI.basicHeightRowTable = 20;
		} catch (Exception ex) {
			WB.addLog("GUI.static ctor, ex=" + ex.getMessage(), "", "GUI");
		}
	}

	private static String getPatternMenuItem(String initStrMenu) throws Exception {
		// origin - 22.07.2024, last edit - 13.06.2025
		String res = Etc.fixTrim(initStrMenu);
		try {
			res = Etc.delStr(res, GUI.strMenuMark);
			res = Etc.delStr(res, ")");// ??magic string ??
			res = res + "."; // ex. res="(Face."
		} catch (Exception ex) {
			WB.addLog("GUI.getPatternMenuItem(String):String, ex=" + ex.getMessage(), "", "GUI");
		}
		return res;
	}

	private static String delMark(String initStrMenu) throws Exception {
		// origin - 22.07.2024, last edit - 13.06.2025
		String res = Etc.fixTrim(initStrMenu);
		try {
			res = Etc.delStr(res, GUI.strMenuMark);
			// res = Etc.delStr(res, GUI.strMenuItemMark);
			// menuId.replaceAll("(", "");
			// menuId.replaceAll(")", "");
		} catch (Exception ex) {
			WB.addLog("GUI.delMark(String):String, ex=" + ex.getMessage(), "", "GUI");
		}
		return res;
	}

	private static void addMenu2(JMenuBar menuBar, String initStrMenu) throws Exception {
		// origin - 20.07.2024, last edit - 13.06.2025
		try {
			JMenu currMenu = GUI.getMenu(GUI.setMenuTitle(initStrMenu));
			GUI.addMenu(currMenu, getPatternMenuItem(initStrMenu));
			menuBar.add(currMenu);
		} catch (Exception ex) {
			WB.addLog("GUI.addMenu(JMenuBar, String):void, ex=" + ex.getMessage(), "", "GUI");
		}
	}

	private static void addMenu(JMenu menu, String menuId) throws Exception {
		// origin - 19.07.2024, last edit - 13.06.2025
		try {
			for (var entry : GUI.basicMenuTitle.entrySet()) {
				String key = entry.getKey();
				if (Etc.strContains(key, menuId)) {
					menu.add(GUI.getMenuItem(GUI.setMenuTitle(key)));
				}
			}

			// add custom menu items
			GUI.addMenuItemCustom(menu);
		} catch (Exception ex) {
			WB.addLog("GUI.addMenu(JMenu, String):void, ex=" + ex.getMessage(), "", "GUI");
		}
	}

	private static String setMenuTitle(String menuId) throws Exception {
		// origin - 18.07.2024, last edit - 13.06.2025
		String res = "";
		menuId = Etc.fixTrim(menuId);
		String resLocInt = "";
		try {
			resLocInt = GUI.basicMenuTitle.get(menuId).toString();
			// resLocInt = LocInt.getLocal(LocInt.getListStrLocal(resLocInt),
			// GUI.basicMenuStrLocal);
			resLocInt = LocInt.getLocal(resLocInt, GUI.basicMenuStrLocal);

			if (Etc.strContains(menuId, ".")) {// if this menuItemId ex. "(Input.20)"
				res = menuId + " " + resLocInt;
			} else {
				res = resLocInt; // if this menuId ex. "(Face)"
			}

		} catch (Exception ex) {
			WB.addLog("GUI.setMenuTitle(String):String, ex=" + ex.getMessage(), "", "GUI");
		}
		return res;
	}

	public static JFrame getFrameBasic() throws Exception {
		// origin - 03.12.2023, last edit - 02.09.2026
		FlatLightLaf.setup(); // Инициализация светлой темы

		JFrame frame = new JFrame();
		EventQueue.invokeLater(() -> {
			try {
				frame.setTitle(WB.frameBasicTitle);
				JPanel panelBasic = new JPanel();
				panelBasic.setBackground(Color.lightGray);

				BorderLayout layout = new BorderLayout();
				panelBasic.setLayout(layout);
				frame.add(panelBasic);

				frame.setJMenuBar(GUI.basicMenuBar);
				panelBasic.add(GUI.basicToolBar, BorderLayout.NORTH);

				JTextField dbConnList = new JTextField(100);
				dbConnList.setFont(new Font("Arial", Font.BOLD, GUI.basicHeightFont));
				dbConnList.setText("Input dbConn");
				frame.add(dbConnList, BorderLayout.NORTH);

				Object[][] array = new String[][] {
						{ "Кольцо с кам.", "гр", "1,5", Fmtr.fixForDoubleByStr("1,5"), Fmtr.strForDoubleByStr("1,5") },
						{ "Блезик", "карат", "6676764,0", Fmtr.fixForDoubleByStr("6676764,0"),
								Fmtr.strForDoubleByStr("6676764,0"), Fmtr.strForDoubleByStr("6676764,0", '.', ',') },
						{ "Лом", "карат", "307876.08545", Fmtr.fixForDoubleByStr("307876.08545"),
								Fmtr.strForDoubleByStr("307876.08545") },
						{ "Браслет", "карат", "245643.22", Fmtr.fixForDoubleByStr("245643.22"),
								Fmtr.strForDoubleByStr("245643.22") } };
				Object[] columnsHeader = new String[] { "Наименование", "Ед.измерения", "Количество", "Etc.fixDouble()",
						"Etc.formatterDouble()" };

				int rows = array.length;
				int cols = array[0].length;
				String[][] scaledArray = new String[rows * 2][cols];
				// Arrays.copyOf(null, cols); //?TODO
				for (int i = 0; i < rows; i++) {
					scaledArray[i * 2] = (String[]) array[i];
					scaledArray[i * 2 + 1] = (String[]) array[i];
				}

				JTable table1 = new JTable(scaledArray, columnsHeader);
				table1.getTableHeader().setVisible(true);
				table1.setTableHeader(null);
				table1.setRowHeight(GUI.basicHeightRowTable);
				// table1.setAutoResizeMode(1);
				table1.setFont(new Font("Arial", Font.PLAIN, GUI.basicHeightFont));
				panelBasic.add(table1, BorderLayout.CENTER);

				panelBasic.add(GUI.getTabbedPane(), BorderLayout.CENTER);

				JSlider slider1 = new JSlider();
				// slider1.setOrientation(SwingConstants.BOTTOM);
				slider1.setLocation(SwingConstants.BOTTOM, SwingConstants.BOTTOM);
				slider1.setMajorTickSpacing(10);
				slider1.setValue(GUI.basicHeightFont);

				slider1.addChangeListener(new ChangeListener() {
					@Override
					public void stateChanged(ChangeEvent e) {
						JSlider source = (JSlider) e.getSource();
						// Check if the user has finished moving the slider knob
						if (!source.getValueIsAdjusting()) {
							int value = source.getValue();
							table1.setRowHeight((int) (value * 1.5));
							table1.setFont(new Font("Arial", Font.PLAIN, (int) value));
						}
					}
				});

				slider1.setPaintLabels(true);
				panelBasic.add(slider1, BorderLayout.SOUTH);

				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				// frame.setPreferredSize(new Dimension(640, 480));
				frame.setExtendedState(java.awt.Frame.MAXIMIZED_BOTH);
				frame.setFont(new Font("Verdana", Font.BOLD, GUI.basicHeightFont));
				frame.setVisible(true);
			} catch (Exception ex) {
				WB.addLog("GUI.getFrameBasic, ex=" + ex.getMessage(), "", "GUI");
			}
		});
		WB.addLog("GUI.getFrameBasic():JFrame, frame.getName=" + frame.getName(), "", "GUI");
		return frame;
	}

	private static void addMenuItemCustom(JMenu menu) throws Exception {
		// origin - 19.12.2023, last edit - 13.06.2025
		try {
			menu.addSeparator();
			menu.add(GUI.getMenuItem("Custom standard - "));
			menu.add(GUI.getMenuItem("Custom pawn shop - "));
			// menu.addSeparator();
		} catch (Exception ex) {
			WB.addLog("GUI.addMenuItemCustom(JMenu):void, ex=" + ex.getMessage(), "", "GUI");
		}
	}

	private static String getMenuItemId(String menuItemTitle) throws Exception {
		// origin - 27.08.2024, last edit - 13.06.2025
		String res = "";
		try {
			for (var entry : GUI.basicMenuTitle.entrySet()) {
				String key = entry.getKey();
				// String value = entry.getValue();
				if (Etc.strContains(menuItemTitle, key)) {
					res = key;
					res.replaceAll("(", "");
					res.replaceAll(")", "");
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("GUI.getMenuItemId(String):String, ex=" + ex.getMessage(), "", "GUI");
		}
		return res;
	}

	private static void getActionListener(String menuItemTitle, JMenuItem menuItem) throws Exception {
		// origin - 10.12.2023, last edit - 02.03.2026
		menuItem.addActionListener(event -> {
			try {
				TreeSet<String> setConn = Conn.work;
				// WB.addLog2("GUI.getActionListener, menuItemTitle=" + menuItemTitle,"",
				// "GUI");

				String menuItemTitleId = GUI.getMenuItemId(menuItemTitle);
				switch (menuItemTitleId) {

				case "(Support.80)" -> Command.clearSpoolerPrinters();
				case "(Support.70)" -> Command.openControlPrinters();
				// case "(Support.40)" -> Command.cleanFolderProgram();

				case "(Input.20)" -> {
					String patternInOut = Conn.outputDbPattern;
					String patternTo = Conn.toAllPattern;
					TreeSet<String> setConnFrom = Conn.getDbList2(WB.inputOutputDir, patternInOut, patternTo);
					TreeSet<String> setConnTo = new TreeSet<String>();
					setConnTo.add(WB.lastConnWork);
					Command.input(setConnFrom, setConnTo, patternInOut, patternTo);
					// Command.cleanInputOutput(patternInOut, patternTo);// after input clean
				}

				case "(Output.50)" -> {
					// String patternInOut = Conn.outputDbPattern;
					// String patternTo = Conn.toAllPattern;
					// Command.cleanInputOutput(patternInOut, patternTo);// before output clean
					Command.outputBackup(setConn);
				}

				case "(Support.60)" -> Command.replaceInto(setConn);
				case "(Support.30)" -> Command.openUserManualLocal();

				case "(Support.20)" -> {
					Command.updateBases(setConn);
					Command.updateExtFiles();
				}

				case "(Support.10)" -> {
					Command.backup(setConn);
					Command.integrityCheck(setConn);
					Command.reindex(setConn);
					Command.vacuum(setConn);
				}
				case "(Support.50)" -> Command.getLastRecord(setConn);
				case " - exit" -> Command.exit();

				default -> Etc.doNothing();
				}
			} catch (Exception ex) {
				WB.addLog("GUI.getActionListener(String, JMenuItem):void, ex=" + ex.getMessage(), "", "GUI");
			}
		});
	}

	private static void getActionListener(String buttonTitle, JButton button) throws Exception {
		// origin - 15.12.2023, last edit - 31.08.2026
		button.addActionListener(event -> {
			try {
				switch (buttonTitle) {
				case "Chat bot" -> ChatBot.init();
				case "Exit" -> Command.exit();
				case "Print template doc" -> Etc.doNothing();
				// case "" -> Etc.doNothing();
				default -> Etc.doNothing();
				}

//				if (Etc.strContains(buttonTitle, "Chat bot")) {
//					ChatBot.init();
//				}
//				
//				if (Etc.strContains(buttonTitle, "Exit")) {
//					Command.exit();
//				}
//
//				if (Etc.strContains(buttonTitle, "Print template doc")) {
//					// System.out.println("Print template doc");
//				}
			} catch (Exception ex) {
				WB.addLog("GUI.getActionListener(String, JButton):void, ex=" + ex.getMessage() + ", buttonTitle="
						+ buttonTitle, "", "GUI");
			}
		});
	}

	private static JTabbedPane getTabbedPane() throws Exception {
		// origin - 02.09.2026, last edit - 02.09.2026
		JTabbedPane tabbedPane = new JTabbedPane();
		EventQueue.invokeLater(() -> {
			try {
				tabbedPane.add("Face", new JPanel());
				tabbedPane.add("Deal", new JPanel());
				tabbedPane.add("Asset", new JPanel());
				tabbedPane.add("Workbook", new JPanel());
			} catch (Exception ex) {
				WB.addLog("GUI.getTabbedPane():JTabbedPane, ex=" + ex.getMessage(), "", "GUI");
			}
		});
		return tabbedPane;
	}

	private static JToolBar getBasicToolBar() throws Exception {
		// origin - 05.12.2023, last edit - 29.08.2026
		JToolBar toolBar = new JToolBar();
		EventQueue.invokeLater(() -> {
			try {
				toolBar.setFloatable(false);
				toolBar.setOrientation(SwingConstants.HORIZONTAL);
				toolBar.add(getButton("Print template doc (not ready)"));
				toolBar.add(getButton("Shift process (not ready)"));
				toolBar.add(getButton("Quick select (not ready)"));
				toolBar.add(getButton("Quick rest (not ready)"));
				toolBar.add(getButton("Chat bot"));
				toolBar.add(getButton("Exit"));
			} catch (Exception ex) {
				WB.addLog("GUI.getBasicToolBar():JToolBar, ex=" + ex.getMessage(), "", "GUI");
			}
		});
		return toolBar;
	}

	private static JButton getButton(String buttonTitle) throws Exception {
		// origin - 15.12.2023, last edit - 13.06.2025
		JButton button = new JButton(buttonTitle);
		try {
			GUI.setFont(button);
			GUI.getActionListener(buttonTitle, button);
		} catch (Exception ex) {
			WB.addLog("GUI.getButton(String):JButton, ex=" + ex.getMessage(), "", "GUI");
		}
		return button;
	}

	private static void setFont(JComponent jcomp) throws Exception {
		// origin - 15.12.2023, last edit - 13.06.2025
		try {
			((JComponent) jcomp).setFont(new Font("Arial", Font.BOLD, 15));
		} catch (Exception ex) {
			WB.addLog("GUI.setFont(JComponent):void, ex=" + ex.getMessage(), "", "GUI");
		}
	}

	private static JMenu getMenu(String menuTitle) throws Exception {
		// origin - 19.07.2024, last edit - 13.06.2025
		menuTitle = GUI.delMark(menuTitle);
		JMenu menu = new JMenu(menuTitle);
		try {
			GUI.setFont(menu);
		} catch (Exception ex) {
			WB.addLog("GUI.getMenu(String):JMenu, ex=" + ex.getMessage(), "", "GUI");
		}
		return menu;
	}

	private static JMenuItem getMenuItem(String menuItemTitle) throws Exception {
		// origin - 09.12.2023, last edit - 13.06.2025
		JMenuItem menuItem = new JMenuItem(menuItemTitle);
		try {
			GUI.setFont(menuItem);
			GUI.getActionListener(menuItemTitle, menuItem);
		} catch (Exception ex) {
			WB.addLog("GUI.getMenuItem(String):JMenuItem, ex=" + ex.getMessage(), "", "GUI");
		}
		return menuItem;
	}

	private static LinkedHashMap<String, String> getBasicMenuTitle() throws Exception {
		// origin - 18.07.2024, last edit - 13.06.2025
		LinkedHashMap<String, String> res = new LinkedHashMap<String, String>();
		try {
			res.put("(File)[Menu]", "(File)[EN](Файл)[RU](Файл)[Қаз]");
			res.put("(File.10)",
					"(File - open (not ready)[EN]Файл - открыть (не готов)[RU]Файл - ашық (дайын емес)[Қаз]");
			res.put("(File.20)",
					"File - save (not ready)[EN]Файл - сохранить (не готов)[RU]Файл - сақтау (дайын емес)[Қаз]");

			res.put("(Face)[Menu]", "(Face)[EN](Лицо)[RU](Тұлға)[Қаз]");
			res.put("(Face.10)",
					"Standard - new face (not ready)[EN]Standard - нов лицо (не готов)[RU]Standard - жаңа тұлға (дайын емес)[Қаз]");
			res.put("(Face.20)",
					"Standard - edit face (not ready)[EN]Standard - изм лицо (не готов)[RU]Standard - тұлға-әлпеті (дайын емес)[Қаз]");
			res.put("(Face.PS.10)",
					"Sectoral pawn shop - new borrower (not ready)[EN]Sectoral pawn shop - новый заемщик (не готов)[RU]Sectoral pawn shop - жаңа қарыз алушы (дайын емес)[Қаз]");
			res.put("(Face.PS.20)",
					"Sectoral pawn shop - edit borrower (not ready)[EN]Sectoral pawn shop - изм заемщик (не готов)[RU]Sectoral pawn shop - өңдеу қарыз алушы (дайын емес)[Қаз]");

			res.put("(Asset)[Menu]", "(Asset)[EN](Актив)[RU](Актив)[Қаз]");
			res.put("(Asset.10)",
					"Standard - new asset (not ready)[EN]Standard - нов актив (не готов)[RU]Standard - жаңа актив (дайын емес)[Қаз]");
			res.put("(Asset.20)",
					"Standard - edit asset (not ready)[EN]Standard - изм актив (не готов)[RU]Standard - активті өңдеу (дайын емес)[Қаз]");
			res.put("(Asset.PS.10)",
					"Sectoral pawn shop - new pawn (not ready)[EN]Sectoral pawn shop - нов залог (не готов)[RU]Sectoral pawn shop - жаңа кепіл (дайын емес)[Қаз]");
			res.put("(Asset.PS.20)",
					"Sectoral pawn shop - edit pawn (not ready)[EN]Sectoral pawn shop - изм залог (не готов)[RU]Sectoral pawn shop - қамтамасыз етуді өзгерту (дайын емес)[Қаз]");

			res.put("(Deal)[Menu]", "(Deal)[EN](Договор)[RU](Келісім)[Қаз]");
			res.put("(Deal.10)",
					"Standard - new deal (not ready)[EN]Standard - нов договор (не готов)[RU]Standard - жаңа келісім (дайын емес)[Қаз]");
			res.put("(Deal.20)",
					"Standard - edit deal (not ready)[EN]Standard - изм договор (не готов)[RU]Standard - келісім-шартты өңдеу (дайын емес)[Қаз]");
			res.put("(Deal.PS.10)",
					"Sectoral pawn shop - new pawn doc (not ready)[EN]Sectoral pawn shop - нов залог билет (не готов)[RU]Sectoral pawn shop - жаңа кепіл билеті (дайын емес)[Қаз]");
			res.put("(Deal.PS.20)",
					"Sectoral pawn shop - edit pawn doc (not ready)[EN]Sectoral pawn shop - изм залог билет (не готов)[RU]Sectoral pawn shop - депозиттік билетті өзгерту (дайын емес)[Қаз]");

			res.put("(Process)[Menu]", "(Process)[EN](Процесс)[RU](Процесс)[Қаз]");
			res.put("(Process.PS.10)",
					"Sectoral pawn shop - Accrual interest 1 (not ready)[EN]Sectoral pawn shop - начисление вознаграждения[RU]Sectoral pawn shop - сыйақыны есептеу[Қаз]");
			res.put("(Process.PS.20)",
					"Sectoral pawn shop - Write off deal 1 (not ready)[EN]Sectoral pawn shop - списание договоров 1[RU]Sectoral pawn shop - шарттарды есептен шығару 1[Қаз]");
			res.put("(Process.PS.30)",
					"Sectoral pawn shop - Write off deal 2 (not ready)[EN]Sectoral pawn shop - списание договоров 2[RU]Sectoral pawn shop - шарттарды есептен шығару 2[Қаз]");
			res.put("(Process.PS.40)",
					"Sectoral pawn shop - Write off deal 3 (not ready)[EN]Sectoral pawn shop - списание договоров 3[RU]Sectoral pawn shop - шарттарды есептен шығару 3[Қаз]");
			res.put("(Process.PS.50)",
					"Sectoral pawn shop - Write off deal 4 (not ready)[EN]Sectoral pawn shop - списание договоров 4[RU]Sectoral pawn shop - шарттарды есептен шығару 4[Қаз]");
			res.put("(Process.PS.60)",
					"Sectoral pawn shop - Write off deal 5 (not ready)[EN]Sectoral pawn shop - списание договоров 5[RU]Sectoral pawn shop - шарттарды есептен шығару 5[Қаз]");
			res.put("(Process.PS.70)",
					"Sectoral pawn shop - Write off deal 6 (not ready)[EN]Sectoral pawn shop - списание договоров 6[RU]Sectoral pawn shop - шарттарды есептен шығару 6[Қаз]");
			res.put("(Process.PS.80)",
					"Sectoral pawn shop - Write off deal 7 (not ready)[EN]Sectoral pawn shop - списание договоров 7[RU]Sectoral pawn shop - шарттарды есептен шығару 7[Қаз]");

			res.put("(Workbook)[Menu]", "(Workbook)[EN](Рабочая книга)[RU](Жұмыс дәптері)[Қаз]");

			res.put("(Input)[Menu]", "(Input)[EN](Ввод)[RU](Енгізіңіз)[Қаз]");
			res.put("(Input.10)",
					"Standard - EsfXML (not ready)[EN]Standard - EsfXML (не готов)[RU]Standard - EsfXML (дайын емес)[Қаз]");
			res.put("(Input.20)",
					"Standard - from all to lastConnWork[EN]Standard - от всех в рабочие базы[RU]Standard - барлығынан жұмыс базаларына дейін[Қаз]");
			res.put("(Input.PS.10)",
					"Sectoral pawn shop - PkbXLSX (not ready)[EN]Sectoral pawn shop - PkbXLSX (не готов)[RU]Sectoral pawn shop - PkbXLSX (дайын емес)[Қаз]");

			res.put("(Output)[Menu]", "(Output)[EN](Вывод)[RU](Вывод)[Қаз]");
			res.put("(Output.10)",
					"Standard - EsfXML (not ready)[EN]Standard - EsfXML (не готов)[RU]Standard - EsfXML (дайын емес)[Қаз]");
			res.put("(Output.20)",
					"Standard - MT100 (not ready)[EN]Standard - MT100 (не готов)[RU]Standard - MT100 (дайын емес)[Қаз]");
			res.put("(Output.30)",
					"Standard - MT102 (not ready)[EN]Standard - MT102 (не готов)[RU]Standard - MT102 (дайын емес)[Қаз]");
			res.put("(Output.40)",
					"Standard - Swift all (not ready)[EN]Standard - Swift все (не готов)[RU]Standard - Swift барлығы (дайын емес)[Қаз]");
			res.put("(Output.50)",
					"Standard - from Conn.work to all[EN]Standard - от рабочих баз для всех (не готов)[RU]Standard - жұмыс орындарынан бастап барлығына дейін (дайын емес)[Қаз]");
			res.put("(Output.PS.10)",
					"Sectoral pawn shop - National bank RQ (not ready)[EN]Sectoral pawn shop - National bank RQ (не готов)[RU]Sectoral pawn shop - National bank RQ (дайын емес)[Қаз]");
			res.put("(Output.PS.20)",
					"Sectoral pawn shop - First credit bureau (not ready)[EN]Sectoral pawn shop - Первое кредитное бюро (не готов)[RU]Sectoral pawn shop - Бірінші несиелік бюро (дайын емес)[Қаз]");

			res.put("(Report)[Menu]", "(Report)[EN](Отчет)[RU](Отчет)[Қаз]");
			res.put("(Report.10)",
					"Standard - cash book (not ready)[EN]Standard - кассовая книга (не готов)[RU]Standard - кассалық кітап (дайын емес)[Қаз]");

			res.put("(Other)[Menu]", "(Other)[EN](Прочее)[RU](Прочее)[Қаз]");
			res.put("(Other.10)",
					"Standard - new debt (not ready)[EN]Standard - нов долг (не готов)[RU]Standard - жаңа міндет (дайын емес)[Қаз]");
			res.put("(Other.20)",
					"Standard - edit debt (not ready)[EN]Standard - изм долг (не готов)[RU]Standard - қарызды өңдеу (дайын емес)[Қаз]");
			res.put("(Other.30)",
					"Standard - new geo (not ready)[EN]Standard - нов гео (не готов)[RU]Standard - жаңа гео (дайын емес)[Қаз]");
			res.put("(Other.40)",
					"Standard - edit geo (not ready)[EN]Standard - изм гео (не готов)[RU]Standard - өңдеу гео (дайын емес)[Қаз]");
			res.put("(Other.50)",
					"Standard - new item (not ready)[EN]Standard - нов статья (не готов)[RU]Standard - жаңа мақала (дайын емес)[Қаз]");
			res.put("(Other.60)",
					"Standard - edit item (not ready)[EN]Standard - изм статья (не готов)[RU]Standard - мақаланы өңдеу (дайын емес)[Қаз]");
			res.put("(Other.70)",
					"Standard - new unit (not ready)[EN]Standard - нов ед изм (не готов)[RU]Standard - жаңа өзгеріс бірлігі (дайын емес)[Қаз]");
			res.put("(Other.80)",
					"Standard - edit unit (not ready)[EN]Standard - изм ед изм (не готов)[RU]Standard - Өлшем бірлігі Өлшеу (дайын емес)[Қаз]");

			res.put("(Support)[Menu]", "(Support)[EN](Техподдержка)[RU](Техподдержка)[Қаз]");
			res.put("(Support.10)",
					"Standard - backup, integrity check, reindex, vacuum[EN]Standard - полный сервис баз данных[RU]Standard - толық дерекқор қызметі[Қаз]");
			res.put("(Support.20)",
					"Standard - update bases, update ext files[EN]Standard - апдейт баз данных, апдейт внеш файлов[RU]Standard - дерекқорды жаңарту, сыртқы файлды жаңарту[Қаз]");
			res.put("(Support.30)",
					"Standard - open user manual local[EN]Standard - открыть локальное рук-во польз-ля[RU]Standard - жергілікті пайдаланушы нұсқаулығын ашыңыз[Қаз]");
			res.put("(Support.40)",
					"Standard - clean folder program[EN]Standard - очистка папки программы[RU]Standard - бағдарлама қалтасын тазалау[Қаз]");
			res.put("(Support.50)",
					"Standard - test get last record[EN]Standard - тест чтения последних записей[RU]Standard - соңғы жазбаларды оқу сынағы[Қаз]");
			res.put("(Support.60)",
					"Standard - test replace into[EN]Standard - тест записи[RU]Standard - жазу сынағы[Қаз]");
			res.put("(Support.70)",
					" Standard - open control printers[EN]Standard - открыть управление принтерами[RU]Standard - принтерді басқаруды ашыңыз[Қаз]");
			res.put("(Support.80)",
					"Standard - clear spooler printers[EN]Standard - очистка спулера принтеров[RU]Standard - принтерлерді спулер тазалау[Қаз]");
		} catch (Exception ex) {
			WB.addLog("GUI.getBasicMenuTitle():LinkedHashMap<String, String>, ex=" + ex.getMessage(), "", "GUI");
		}
		return res;
	}

	private static JMenuBar getBasicMenuBar() throws Exception {
		// origin - 03.12.2023, last edit - 13.06.2025
		JMenuBar menuBar = new JMenuBar();
		EventQueue.invokeLater(() -> {
			try {
				LinkedHashMap<String, String> menuOrder = new LinkedHashMap<String, String>();
				menuOrder = getMenuOrder(GUI.basicMenuTitle);

				for (var entry : menuOrder.entrySet()) {
					String initStrMenu = entry.getKey();
					GUI.addMenu2(menuBar, initStrMenu);
				}
			} catch (Exception ex) {
				WB.addLog("GUI.getBasicMenuBar():JMenuBar, ex=" + ex.getMessage(), "", "GUI");
			}
		});
		return menuBar;
	}

	private static LinkedHashMap<String, String> getMenuOrder(LinkedHashMap<String, String> listMenuTitle)
			throws Exception {
		// origin - 22.07.2024, last edit - 13.06.2025
		LinkedHashMap<String, String> res = new LinkedHashMap<String, String>();
		try {
			for (var entry : listMenuTitle.entrySet()) {
				String key = entry.getKey();
				String value = entry.getValue();
				if (Etc.strContains(key, GUI.strMenuMark)) {
					res.put(key, value);
				}
			}
		} catch (Exception ex) {
			WB.addLog("GUI.getMenuOrder(LinkedHashMap<2String>):LinkedHashMap<String, String>, ex=" + ex.getMessage(),
					"", "GUI");
		}
		return res;
	}

	private GUI() {
		// origin - 04.11.2024, last edit - 04.11.2024
	}

	public static void test() throws Exception {
		// origin - 03.12.2023, last edit - 13.06.2025
		try {

//			// getMenuItemId
//			var arg1 = new String[] { "00006715567453", "(Support.70) allo", "003", "00Fkmaf" };
//			for (var testArg1 : arg1) {
//				WB.addLog2("GUI.test.getMenuItemId, res=" + GUI.getMenuItemId(testArg1) + ", testArg1=" + testArg1,"", "GUI");
//			}

		} catch (Exception ex) {
			WB.addLog("GUI.test():void, ex=" + ex.getMessage(), "", "GUI");
		}
	}
}