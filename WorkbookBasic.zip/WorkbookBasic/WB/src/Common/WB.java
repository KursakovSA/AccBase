import java.io.File;
import java.net.InetAddress;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;

public class WB extends JFrame {
	// origin - 25.09.2023, last edit - 25.08.2025
	private static final long serialVersionUID = 1L;
	public static final String startDir = System.getProperty("user.dir");
	public static final String sysLineSep = System.lineSeparator();

	public static int eventCounter = 0;
	public static StringBuilder eventLog = new StringBuilder("");
	public static StringBuilder eventLog2 = new StringBuilder("");
	public static LocalDateTime eventGlobalStart, eventGlobalEnd;

	public static String eventLogFile = "eventLog.csv"; // basic log default;
	public static String eventLogPath = WB.startDir + File.separator + eventLogFile;

	public static String lastSaveDir, lastSelectFileDir = System.getProperty("user.dir");
	public static String mediaDir = System.getProperty("user.dir") + File.separator + "media";
	public static String commonDocDir = System.getProperty("user.dir") + File.separator + "commonDoc";
	public static String localDir = System.getProperty("user.dir") + File.separator + "local";
	public static String templateDocDir = System.getProperty("user.dir") + File.separator + "templateDoc";
	public static String backupDir = System.getProperty("user.dir") + File.separator + "backup";
	public static String inputOutputDir = System.getProperty("user.dir") + File.separator + "inputOutput";

	public static String lastConn = "";
	public static String lastConnWork = "";

	public static Abc abcGlobal, abcTemplate, abcLocal, abcLast;

	public static final LocalDate minDateSupported = LocalDate.of(1900, Month.JANUARY, 01);
	public static final LocalDate maxDateSupported = LocalDate.of(2080, Month.DECEMBER, 31);

	public static String currUser, version, frameBasicTitle;
	public static JFrame frameBasic;

	static {
		try {
			WB.version = "25.08.2025";
			WB.abcGlobal = new Abc(Conn.globalPath);
			WB.abcTemplate = new Abc(Conn.templatePath);
			WB.abcLocal = new Abc();
			WB.abcLast = new Abc();
			WB.currUser = WB.getAuthData();
			WB.frameBasicTitle = "Workbook Basic (accounting program), based on Java, SQLite, Eclipse. License : GPL 3.0. Made in Qazaqstan."
					+ ", version -" + version + ", support - github.com/KursakovSA/AccBase, currUser - " + currUser;
		} catch (Exception ex) {
			WB.addLog("WB.static ctor, ex=" + ex.getMessage(), "", "WB");
		}
		WB.addLog("WB.static ctor block init, WB.abcGlobal=" + WB.abcGlobal, "", "WB");
		WB.addLog("WB.static ctor block init, WB.abcTemplate=" + WB.abcTemplate, "", "WB");
	}

	public static void main(String[] args) throws Exception {
		// origin - 25.09.2023, last edit - 13.06.2025
		LocalDateTime localStart = WB.getLocalStart();
		try {
			WB.getGlobalStart();
			Conn.init();
			WB.init();
			WB.test();
			WB.frameBasic = GUI.getFrameBasic();
		} catch (Exception ex) {
			WB.addLog("WB.main():void, ex=" + ex.getMessage(), "", "WB");
		} finally {
			Etc.doNothing();
		}
		WB.getLocalEnd("WB.main, end ", localStart);
	}

	private static void init() throws Exception {
		// origin - 21.10.2023, last edit - 13.06.2025
		try {
			if (Conn.systemFact.isEmpty()) {
				return;
			}
			WB.createDir();
			WB.restoreLastState();
			WB.javaInfo();
		} catch (Exception ex) {
			WB.addLog("WB.init():void, ex=" + ex.getMessage(), "", "WB");
		}
		WB.addLog("WB.init, end", "", "WB");
		WB.addLog2("WB.init, end", "", "WB");
	}

	private static void javaInfo() throws Exception {
		// origin - 05.07.2024, last edit - 13.06.2025
		try {
			WB.addLog2("WB.init, java.version=" + System.getProperty("java.version"), "", "WB");
			WB.addLog2("WB.init, java.home=" + System.getProperty("java.home"), "", "WB");
			WB.addLog2("WB.init, java.class.path=" + System.getProperty("java.class.path"), "", "WB");
			// WB.addLog2("WB.init, java.io.dir=" +
			// System.getProperty("java.io.dir"),"","WB");
			WB.addLog2("WB.init, os.name=" + System.getProperty("os.name"), "", "WB");
		} catch (Exception ex) {
			addLog("WB.javaInfo():void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	private static void createDir() throws Exception {
		// origin - 05.07.2024, last edit - 13.06.2025
		try {
			for (String dirPath : new String[] { mediaDir, commonDocDir, templateDocDir, backupDir, localDir,
					inputOutputDir }) {
				if (Files.notExists(Paths.get(dirPath))) {
					Files.createDirectory(Paths.get(dirPath));
					WB.addLog("WB.init, createDir=" + dirPath, "", "WB");
				}
			}
		} catch (Exception ex) {
			WB.addLog("WB.createDir():void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	@SuppressWarnings("unused")
	private static void restoreLastState() throws Exception {// TOTHINK
		// origin - 14.02.2024, last edit - 19.03.2025
		List<ModelDto> lastState = new ArrayList<ModelDto>();
		List<ModelDto> restoreState = new ArrayList<ModelDto>();
		try {
			// TODO
		} catch (Exception ex) {
			WB.addLog("WB.restoreLastState():void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	@SuppressWarnings("unused")
	private static void saveLastState() throws Exception {// TOTHINK
		// origin - 14.02.2024, last edit - 19.03.2025
		List<ModelDto> lastState = new ArrayList<ModelDto>();
		try {

		} catch (Exception ex) {
			WB.addLog("WB.saveLastState():void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	private static void test() throws Exception {
		// origin - 25.09.2023, last edit - 10.08.2025
		try {
			if (isProject()) {
				Abc.test();
				Etc.test();
				Account.test();
				Asset.test();
				Deal.test();
				Debt.test();
				Face.test();
				Geo.test();
				Meter.test();
				Price.test();
				Process.test();
				Unit.test();
				Workbook.test();
				Slice.test();
				Mark.test();
				Role.test();
				Info.test();
				Sign.test();
				Item.test();
				ModelDto.test();
				Report.test();
				InOut.test();
				TemplateDoc.test();
				DAL.test();
				GUI.test();
				TimeJob.test();
				Command.test();
				Conn.test();
				Qry.test();
				DateTool.test();
				WorkDay.test();
				LocInt.test();
				Conv.test();
				// CSV.test();
				IdGen.test();
				DefVal.test();
				Fmtr.test();
				StopList.test();
				ListVal.test();
				CompositeVal.test();
				UnitVal.test();
				TagVal.test();
				ReadSet.test();
				WriteSet.test();
				Pawn.test();
				PawnDoc.test();
				PawnDocTerm.test();
				Move.test();
				MoreVal.test();
				SPL.test();
				Prolongation.test();
				RangeVal.test();
				ViewData.test();
				Access.test();
				AnnoVal.test();
				SimplexVal.test();
				Accrual.test();
				Pool.test();

				AssetPart.test();
				AssetPrice.test();
				SubAsset.test();
				AssetDto.test();
				PriceCurrency.test();
				BasicDto.test();
				DealDto.test();
				FaceDto.test();
				Address.test();
				StaffTable.test();
				Staff.test();
				User.test();
				Dept.test();
				Cash.test();
				SpanDate.test();
				Bank.test();
				FIO.test();
				SerNumDate.test();
				Crew.test();

				SpanTime.test();
				JobDay.test();
				JobCycle.test();
				JobTurn.test();
				Point.test();
				JobMap.test();
				FaceContact.test();
				FaceDaily.test();
				Store.test();
				JobDaily.test();

				FaceReg.test();
				PawnGold.test();
				PawnBalance.test();
				PawnSum.test();
				PawnAuto.test();
				PA.test();
				AssetCat.test();
				AssetDefectCat.test();
				BrutNet.test();
				Qty.test();
				PawnCell.test();
				QPA.test();
				ProcessDto.test();
				FaceCat.test();
				PawnDocCat.test();
			}
		} catch (Exception ex) {
			WB.addLog("WB.test():void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	public static void writeFile(String pathFile, String fileContent) throws Exception {
		// origin - 19.10.2023, last edit - 13.06.2025
		try {
			Path pf = Paths.get(pathFile);
			boolean isReplace = true;
			if (isProject() == false) {
				if (Files.exists(pf)) {
					isReplace = false;
				}
			}
			if (isReplace) {
				Files.write(pf, fileContent.toString().getBytes("utf-8"));
			} else {
				Files.write(pf, fileContent.toString().getBytes("utf-8"), StandardOpenOption.APPEND);
			}
		} catch (Exception ex) {
			WB.addLog("WB.writeFile(String pathFile, String fileContent):void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	@SuppressWarnings({ "deprecation", "unused" })
	public static void openFile(String pathFile) throws Exception {
		// origin - 19.10.2023, last edit - 13.06.2025
		if (WB.isProject()) {
			try {
				java.lang.Process process = Runtime.getRuntime().exec("explorer.exe " + pathFile.toString(), null);
			} catch (Exception ex) {
				System.out
						.println("WB.openFile(String pathFile):void, ex=" + ex.getMessage() + ", pathFile=" + pathFile);
			}
		}
	}

	private static String getAuthData() throws Exception {
		// origin - 05.12.2023, last edit - 13.06.2025
		String res = "";
		try {
			res = res + InetAddress.getLocalHost().getHostName() + "\\";
			res = res + System.getProperty("user.name");
		} catch (Exception ex) {
			WB.addLog("WB.getAuthData():String, ex=" + ex.getMessage(), "", "WB");
		}
		return res;
	}

	private static boolean hasFile(String dir, String file) throws Exception {
		// origin - 07.12.2023, last edit - 13.06.2025
		boolean res = false;
		try {
			Path checkFilePath = Paths.get(dir + File.separator + file);
			if (Files.exists(checkFilePath)) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("WB.hasFile(String dir, String file):boolean, ex=" + ex.getMessage(), "", "WB");
		}
		return res;
	}

	private static boolean isProject() throws Exception {
		// origin - 05.12.2023, last edit - 13.06.2025
		boolean res = false;
		try {
			if (WB.hasFile(WB.startDir, ".project")) { // if in startDir exist project Eclipse then isDev = true
				res = true;
			}
		} catch (Exception ex) {
			System.out.println("WB.isProject():boolean, ex=" + ex.getMessage());
		}
		return res;
	}

	public static void getGlobalStart() throws Exception {
		// origin - 25.10.2023, last edit - 13.06.2025
		try {
			WB.eventGlobalStart = DateTool.getNow2();
			WB.addLog("WB.getGlobalStart, eventGlobalStart=" + DateTool.formatter(eventGlobalStart), "", "WB");
		} catch (Exception ex) {
			WB.addLog("WB.getGlobalStart():void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	public static LocalDateTime getLocalStart() throws Exception {
		// origin - 13.06.2024, last edit - 13.06.2025
		LocalDateTime res = null;
		try {
			res = DateTool.getNow2();
		} catch (Exception ex) {
			WB.addLog("WB.getLocalStart():LocalDateTime, ex=" + ex.getMessage(), "", "WB");
		}
		return res;
	}

	public static LocalDateTime getLocalEnd(String source, LocalDateTime localStart) throws Exception {
		// origin - 13.06.2024, last edit - 13.06.2025
		LocalDateTime res = null;
		try {
			res = DateTool.getNow2();
		} catch (Exception ex) {
			WB.addLog("WB.getLocalEnd(String source, LocalDateTime localStart):LocalDateTime, ex=" + ex.getMessage(),
					"", "WB");
		}
		WB.addLog2("WB.getLocalEnd, durationLocal=" + DateTool.getDuration(localStart, res) + " ms, " + source, "",
				"WB");
		return res;
	}

	public static void getFinish() throws Exception {
		// origin - 26.09.2023, last edit - 13.06.2025
		try {
			WB.saveLastState();
			WB.getEventEnd();
			WB.writeFile(eventLogPath, eventLog.toString());
			WB.openFile(eventLogPath);
		} catch (Exception ex) {
			addLog("WB.getFinish():void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	private static void getEventEnd() throws Exception {
		// origin - 21.10.2023, last edit - 13.06.2025
		try {
			WB.eventGlobalEnd = DateTool.getNow2();// DateTool.getOffsetDateTimeNow();
			WB.addLog("WB.getEventEnd, eventGlobalEnd=" + DateTool.formatter(eventGlobalEnd), "", "WB");
			WB.addLog("WB.getEventEnd, durationGlobal=" + DateTool.getDuration(WB.eventGlobalStart, WB.eventGlobalEnd)
					+ " ms", "", "WB");
			WB.addLog("Log detail");
			WB.addLog(eventLog2.toString());
		} catch (Exception ex) {
			WB.addLog("WB.getEventEnd():void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	public static <T> void log(List<T> listDto, String type) throws Exception {
		// origin - 24.05.2025, last edit - 13.06.2025
		try {
			for (var tmp : listDto) {
				WB.addLog2("WB.log(List<" + type + ">), res=" + tmp, "", "WB");
			}
			if (listDto.size() != 0) {
				WB.addLog2("", "", "WB");
			}
		} catch (Exception ex) {
			WB.addLog("WB.log(List<T> listDto, String type):void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	public static void addLog2(Object EventObj, String EventCont, String EventMeth) throws Exception {
		// origin - 03.11.2023, last edit - 13.06.2025
		try {
			WB.eventCounter = WB.eventCounter + 1;
			WB.eventLog2.append(WB.formatter(EventObj, EventCont, EventMeth));
		} catch (Exception ex) {
			WB.addLog("WB.addLog2(Object EventObj, String EventCont, String EventMeth):void, ex=" + ex.getMessage(), "",
					"WB");
		}
	}

	public static void addLog(Object EventObj, String EventCont, String EventMeth) {
		// origin - 26.09.2023, last edit - 13.06.2025
		WB.eventCounter = WB.eventCounter + 1;
		try {
			WB.eventLog.append(WB.formatter(EventObj, EventCont, EventMeth));
		} catch (Exception ex) {
			WB.addLog("WB.addLog(Object EventObj, String EventCont, String EventMeth):void, ex=" + ex.getMessage(), "",
					"WB");
		}
	}

	private static void addLog(String str) throws Exception {
		// origin - 03.11.2023, last edit - 13.06.2025
		try {
			WB.eventCounter = WB.eventCounter + 1;
			WB.eventLog.append(str + WB.sysLineSep);
		} catch (Exception ex) {
			WB.addLog("WB.addLog(String str):void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	private static String formatter(Object eventObj, String eventCont, String eventMeth) throws Exception {
		// origin - 21.10.2023, last edit - 13.06.2025
		String res = "";
		try {
			res = res + "#" + eventCounter + "| " + DateTool.formatter(DateTool.getNow2()) + "| " + eventObj.toString()
					+ "| ";
			if (eventCont.isEmpty()) {
				res = res + WB.currUser + "| ";
			} else {
				res = res + eventCont + "| " + WB.currUser + "| ";
			}

			res = res + eventMeth + "| " + WB.sysLineSep;
		} catch (Exception ex) {
			WB.addLog("WB.formatter(Object eventObj, String eventCont, String eventMeth):String, ex=" + ex.getMessage(),
					"", "WB");
		}
		return res;
	}
}