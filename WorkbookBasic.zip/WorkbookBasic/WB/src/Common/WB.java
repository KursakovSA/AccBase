import java.io.File;
import java.net.InetAddress;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import javax.swing.JFrame;

public class WB extends JFrame {
	// origin - 25.09.2023, last edit - 26.09.2026
	private static final long serialVersionUID = 1L;
	private static final int planCountLinesProjectCode = 100000;
	public static final String startDir = System.getProperty("user.dir");
	public static final String sysLineSep = System.lineSeparator();

	public static int eventCounter = 0;
	public static StringBuilder eventLog = new StringBuilder("");
	public static StringBuilder eventLog2 = new StringBuilder("");
	public static LocalDateTime eventGlobalStart, eventGlobalEnd;

	public static String eventLogFile = "eventLog.csv";
	public static String eventLogPath = WB.startDir + File.separator + eventLogFile;

	public static String lastSaveDir, lastSelectFileDir = System.getProperty("user.dir");
	public static String mediaDir = System.getProperty("user.dir") + File.separator + "media";
	public static String commonDocDir = System.getProperty("user.dir") + File.separator + "commonDoc";
	public static String localDir = System.getProperty("user.dir") + File.separator + "local";
	public static String templateDocDir = System.getProperty("user.dir") + File.separator + "templateDoc";
	public static String backupDir = System.getProperty("user.dir") + File.separator + "backup";
	public static String inputOutputDir = System.getProperty("user.dir") + File.separator + "inputOutput";
	public static String tempDir = System.getProperty("user.dir") + File.separator + "temp";
	public static String docuDir = System.getProperty("user.dir") + File.separator + "docu";
	public static List<String> appDir = List.of(WB.commonDocDir, WB.templateDocDir, WB.mediaDir, WB.inputOutputDir,
			WB.tempDir, WB.docuDir, WB.localDir, WB.backupDir, Conn.dbDir);

	public static String lastConn = "";
	public static String lastConnWork = "";

	public static Abc abcGlobal, abcTemplate, abcLocal, abcLast;

	public static final LocalDate minDateSupported = LocalDate.of(1900, Month.JANUARY, 01);
	public static final LocalDate maxDateSupported = LocalDate.of(2080, Month.DECEMBER, 31);
	public static final LocalDate startProjectDate = LocalDate.of(2023, Month.SEPTEMBER, 14);

	public static String currUser, version, frameBasicTitle;
	public static JFrame frameBasic;

	static {
		try {
			WB.version = "26.09.2026";
			WB.abcGlobal = new Abc(Conn.globalPath);
			WB.abcTemplate = new Abc(Conn.templatePath);
			WB.abcLocal = new Abc();
			WB.abcLast = new Abc();
			// WB.currUser = WB.getAuthData();
			WB.frameBasicTitle = "Workbook Basic (accounting program), based on Java SE, SQLite, Eclipse. License : GPL 3.0. Made in Qazaqstan."
					+ ", version -" + version + ", support - github.com/KursakovSA/AccBase";
		} catch (Exception ex) {
			WB.addLog("WB.static ctor, ex=" + ex.getMessage(), "", "WB");
		}
		WB.addLog("WB.static ctor block init, WB.abcGlobal=" + WB.abcGlobal, "", "WB");
		WB.addLog("WB.static ctor block init, WB.abcTemplate=" + WB.abcTemplate, "", "WB");
	}

	public static void main(String[] args) throws Exception {
		// origin - 25.09.2023, last edit - 18.08.2026
		LocalDateTime localStart = WB.getLocalStart();
		try {
			WB.getGlobalStart();
			Conn.init();
			WB.init();
			WB.test();
			WB.frameBasic = GUI.getFrameBasic();
		} catch (Exception ex) {
			WB.addLog("WB.main():void, ex=" + ex.getMessage(), "", "WB");
		} finally {
			Etc.doNothing();
		}
		WB.getLocalEnd("WB.main, end ", localStart);
	}

	private static void init() throws Exception {
		// origin - 21.10.2023, last edit - 13.06.2025
		try {
			if (Conn.systemFact.isEmpty()) {
				return;
			}
			WB.createDir();
			WB.restoreLastState();
			WB.javaInfo();
		} catch (Exception ex) {
			WB.addLog("WB.init():void, ex=" + ex.getMessage(), "", "WB");
		}
		WB.addLog("WB.init, end", "", "WB");
		WB.addLog2("WB.init, end", "", "WB");
	}

	private static void javaInfo() throws Exception {
		// origin - 05.07.2024, last edit - 13.06.2025
		try {
			WB.addLog2("WB.init, java.version=" + System.getProperty("java.version"), "", "WB");
			WB.addLog2("WB.init, java.home=" + System.getProperty("java.home"), "", "WB");
			WB.addLog2("WB.init, java.class.path=" + System.getProperty("java.class.path"), "", "WB");
			// WB.addLog2("WB.init, java.io.dir=" +
			// System.getProperty("java.io.dir"),"","WB");
			WB.addLog2("WB.init, os.name=" + System.getProperty("os.name"), "", "WB");
		} catch (Exception ex) {
			addLog("WB.javaInfo():void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	private static void createDir() throws Exception {
		// origin - 05.07.2024, last edit - 14.04.2026
		try {
			for (String dirPath : new String[] { mediaDir, commonDocDir, templateDocDir, backupDir, localDir,
					inputOutputDir, tempDir, docuDir }) {
				if (Files.notExists(Paths.get(dirPath))) {
					Files.createDirectory(Paths.get(dirPath));
					WB.addLog("WB.init, createDir=" + dirPath, "", "WB");
				}
			}
		} catch (Exception ex) {
			WB.addLog("WB.createDir():void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	@SuppressWarnings("unused")
	private static void restoreLastState() throws Exception {// TOTHINK
		// origin - 14.02.2024, last edit - 19.03.2025
		List<FullDto> lastState = new ArrayList<FullDto>();
		List<FullDto> restoreState = new ArrayList<FullDto>();
		try {
			// TODO
		} catch (Exception ex) {
			WB.addLog("WB.restoreLastState():void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	@SuppressWarnings("unused")
	private static void saveLastState() throws Exception {// TOTHINK
		// origin - 14.02.2024, last edit - 19.03.2025
		List<FullDto> lastState = new ArrayList<FullDto>();
		try {

		} catch (Exception ex) {
			WB.addLog("WB.saveLastState():void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	private static void test() throws Exception {
		// origin - 25.09.2023, last edit - 12.10.2026
		try {
			if (WB.isProject()) {

				// folder Common
				Abc.test();
				BasicDto.test();
				FullDto.test();
				DAL.test();
				Conn.test();
				Qry.test();
				ReadSet.test();
				WriteSet.test();
				GUI.test();
				Command.test();
				Rule.test();
				Docu.test();
				CccEngine.test();
				UserAccess.test();
				UserAccount.test();
				// ChatBot.init();

				// folder Deal
				Deal.test();
				DealDto.test();
				Move.test();
				Prolongation.test();
				DealTerm.test();
				ShipmentTerm.test();
				PaymentTerm.test();
				DeliveryTerm.test();
				PriceTerm.test();
				AddTerm.test();
				TemplateDocTerm.test();
				DurationTerm.test();
				AccrualTerm.test();

				// folder Face
				Face.test();
				FaceDto.test();
				Address.test();
				Point.test();
				Dept.test();
				FaceContact.test();
				FaceDaily.test();
				FaceReg.test();
				FaceCat.test();
				Crew.test();
				FaceGovId.test();
				FaceSign.test();
				FIO.test();
				Personal.test();
				Prof.test();
				FaceStructId.test();

				// folder Dto
				Account.test();
				AccountClosing.test();
				AccountClosingEngine.test();
				AccountClosingRule.test();
				Debt.test();
				DebtStmt.test();
				Geo.test();
				Meter.test();
				Slice.test();
				Mark.test();
				Role.test();
				Info.test();
				Sign.test();
				Item.test();

				// folder Process
				Process.test();
				Workbook.test();
				ProcessVar.test();
				ProcessEngine.test();
				ProcessContext.test();
				ProcessDesign.test();
				TemplateDoc.test();
				TemplateDocEngine.test();
				TemplateDocPattern.test();
				TemplateDocVar.test();

				// folder Report
				Report.test();
				ViewData.test();
				MassPrint.test();
				SummaryPrint.test();

				// folder Util
				Etc.test();
				IdGen.test();
				InOut.test();
				LocInt.test();
				CSV.test();
				Fmtr.test();
				ZIP.test();
				MassReg.test();
				JSON.test();
				DataEx.test();
				XlsxReader.test();
				Xls97Reader.test();
				Xlsx2csv.test();
				Try.test();
				SpanDate.test();
				SpanTime.test();
				DateTool.test();
				StrDate.test();
				SerNumDate.test();
				SPL.test();
				Num.test();
				DocxReplacer.test();

				// folder Val
				DefVal.test();
				ListVal.test();
				CompositeVal.test();
				TagVal.test();
				MoreVal.test();
				RangeVal.test();
				AnnoVal.test();
				SimplexVal.test();
				ColRow.test();
				SawListVal.test();
				StepwiseVal.test();
				NVal.test();

				// folder Asset
				Asset.test();
				AssetPart.test();
				AssetPrice.test();
				SubAsset.test();
				AssetDto.test();
				AssetCat.test();
				AssetDefectCat.test();
				AssetDepr.test();
				AssetCodeId.test();
				AssetSpec.test();
				AssetCondition.test();

				// folder Unit
				Unit.test();
				UnitVal.test();
				PA.test();
				BrutNet.test();
				Qty.test();
				QPA.test();
				Dim.test();

				// folder Price
				Price.test();
				PriceCurrency.test();
				PriceEngine.test();
				Product.test();
				ProductList.test();
				ProductListItem.test();
				ProductGroup.test();
				ProductListPartMap.test();
				ProductListDescr.test();
				ProductVar.test();
				ProductListPart.test();
				CodeList.test();
				CodeListMap.test();
				CodeListItem.test();

				// folder Money
				Cash.test();
				Bank.test();
				BankEx.test();
				BankExMap.test();
				BankId.test();
				BankAccount.test();

				// folder Store
				Store.test();

				// folder Staff
				Staff.test();
				StaffTable.test();
				WorkDay.test();
				JobDay.test();
				JobCycle.test();
				JobTurn.test();
				JobMap.test();
				JobDaily.test();
				JobTerm.test();

				// folder Salary
				SalaryPayment.test();
				SalaryFund.test();
				SalaryStmt.test();
				SalaryAverage.test();
				SalaryEngine.test();

				// folder AccDoc
				AccDocJournal.test();
				AccDocEngine.test();
				FixedAssetDepreciation.test();
				FixedAssetStmt.test();
				AccDocMap.test();
				BalanceMap.test();

				// folder VAT
				VatStmt.test();
				VatId.test();

				// folder Stmt
				AccBalance.test();
				AccJournal.test();
				AccAnalyst.test();
				BalanceSheet.test();
				CashFlowStmt.test();
				EquityStmt.test();
				IncomeEntTaxStmt.test();
				IncomePersonTaxStmt.test();
				IncomeStmt.test();
				StmtEngine.test();
			}
		} catch (Exception ex) {
			WB.addLog("WB.test():void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	public static void writeFile(String pathFile, String fileContent) throws Exception {
		// origin - 19.10.2023, last edit - 13.06.2025
		try {
			Path pf = Paths.get(pathFile);
			boolean isReplace = true;
			if (isProject() == false) {
				if (Files.exists(pf)) {
					isReplace = false;
				}
			}
			if (isReplace) {
				Files.write(pf, fileContent.toString().getBytes("utf-8"));
			} else {
				Files.write(pf, fileContent.toString().getBytes("utf-8"), StandardOpenOption.APPEND);
			}
		} catch (Exception ex) {
			WB.addLog("WB.writeFile(2String):void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	@SuppressWarnings({ "deprecation", "unused" })
	public static void openFile(String pathFile) throws Exception {
		// origin - 19.10.2023, last edit - 13.06.2025
		if (WB.isProject()) {
			try {
				java.lang.Process process = Runtime.getRuntime().exec("explorer.exe " + pathFile.toString(), null);
			} catch (Exception ex) {
				System.out.println("WB.openFile(String):void, ex=" + ex.getMessage() + ", pathFile=" + pathFile);
			}
		}
	}

	@SuppressWarnings("unused")
	private static String getAuthData() throws Exception {
		// origin - 05.12.2023, last edit - 28.10.2025
		String res = "";
		try {
			res = res + InetAddress.getLocalHost().getHostName() + "\\";
			res = res + System.getProperty("user.name");
		} catch (Exception ex) {
			WB.addLog("WB.getAuthData():String, ex=" + ex.getMessage(), "", "WB");
		}
		return res;
	}

	private static boolean isProject() throws Exception {
		// origin - 05.12.2023, last edit - 24.02.2026
		boolean res = false;
		try {
			if (InOut.hasFile(WB.startDir, ".project")) { // if in startDir exist project Eclipse then isDev = true
				res = true;
			}
		} catch (Exception ex) {
			System.out.println("WB.isProject():boolean, ex=" + ex.getMessage());
		}
		return res;
	}

	public static void getGlobalStart() throws Exception {
		// origin - 25.10.2023, last edit - 21.09.2026
		try {
			WB.codeCounter();
			WB.eventGlobalStart = DateTool.getNow2();
			WB.addLog("WB.getGlobalStart, eventGlobalStart=" + DateTool.formatter(eventGlobalStart), "", "WB");
		} catch (Exception ex) {
			WB.addLog("WB.getGlobalStart():void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	public static LocalDateTime getLocalStart() throws Exception {
		// origin - 13.06.2024, last edit - 13.06.2025
		LocalDateTime res = null;
		try {
			res = DateTool.getNow2();
		} catch (Exception ex) {
			WB.addLog("WB.getLocalStart():LocalDateTime, ex=" + ex.getMessage(), "", "WB");
		}
		return res;
	}

	public static LocalDateTime getLocalEnd(String source, LocalDateTime localStart) throws Exception {
		// origin - 13.06.2024, last edit - 25.09.2025
		LocalDateTime res = null;
		try {
			res = DateTool.getNow2();
		} catch (Exception ex) {
			WB.addLog("WB.getLocalEnd(String, LocalDateTime):LocalDateTime, ex=" + ex.getMessage(), "", "WB");
		}
		WB.addLog2("WB.getLocalEnd, durationLocal=" + DateTool.getDurationInMillis(localStart, res) + " ms, " + source,
				"", "WB");
		return res;
	}

	public static void getFinish() throws Exception {
		// origin - 26.09.2023, last edit - 13.06.2025
		try {
			WB.saveLastState();
			WB.getEventEnd();
			WB.writeFile(eventLogPath, eventLog.toString());
			WB.openFile(eventLogPath);
		} catch (Exception ex) {
			WB.addLog("WB.getFinish():void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	private static void getEventEnd() throws Exception {
		// origin - 21.10.2023, last edit - 25.09.2026
		try {
			WB.eventGlobalEnd = DateTool.getNow2();
			WB.addLog("WB.getEventEnd, eventGlobalEnd=" + DateTool.formatter(eventGlobalEnd), "", "WB");
			WB.addLog("WB.getEventEnd, durationGlobal="
					+ DateTool.getDurationInMillis(WB.eventGlobalStart, WB.eventGlobalEnd) + " ms", "", "WB");
			WB.addLog("Log detail");
			WB.addLog(eventLog2.toString());
		} catch (Exception ex) {
			WB.addLog("WB.getEventEnd():void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	public static <T> void log3Str(List<T> listDto, String type) throws Exception {
		// origin - 08.08.2026, last edit - 08.08.2026
		try {
			for (int i = 0; i < Math.min(listDto.size(), 3); i++) {
				WB.addLog2("WB.log3Str(List<" + type + ">), res=" + listDto.get(i), "", "WB");
			}
		} catch (Exception ex) {
			WB.addLog("WB.log3Str(List<T>, String):void, ex=" + ex.getMessage(), "", "WB");
		}
	}

//	public static void log(List<List<String>> listDto) throws Exception {
//		// origin - 27.09.2026, last edit - 27.09.2026
//		try {
//			for (var tmp : listDto) {
//				WB.addLog2("WB.log(List<List<String>>), res=" + tmp, "", "WB");
//			}
//		} catch (Exception ex) {
//			WB.addLog("WB.log(List<T>, String):void, ex=" + ex.getMessage(), "", "WB");
//		}
//	}

	public static <T> void log(List<T> listDto, String type) throws Exception {
		// origin - 24.05.2025, last edit - 27.09.2026
		try {
			for (var tmp : listDto) {
				WB.addLog2("WB.log(List<" + type + ">), res=" + tmp, "", "WB");
			}
		} catch (Exception ex) {
			WB.addLog("WB.log(List<T>, String):void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	public static void addLog2(Object EventObj, String EventCont, String EventMeth) throws Exception {
		// origin - 03.11.2023, last edit - 08.10.2025
		try {
			WB.eventCounter = WB.eventCounter + 1;
			if (Etc.strMatch(EventObj.toString(), ",") == 0) { // on start block test do space line
				WB.eventLog2.append(WB.formatter("", "", ""));
			}
			WB.eventLog2.append(WB.formatter(EventObj, EventCont, EventMeth));
		} catch (Exception ex) {
			WB.addLog("WB.addLog2(Object, 2String):void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	public static void addLog(Object EventObj, String EventCont, String EventMeth) {
		// origin - 26.09.2023, last edit - 13.06.2025
		WB.eventCounter = WB.eventCounter + 1;
		try {
			WB.eventLog.append(WB.formatter(EventObj, EventCont, EventMeth));
		} catch (Exception ex) {
			WB.addLog("WB.addLog(Object, 2String):void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	private static void addLog(String str) throws Exception {
		// origin - 03.11.2023, last edit - 13.06.2025
		try {
			WB.eventCounter = WB.eventCounter + 1;
			WB.eventLog.append(str + WB.sysLineSep);
		} catch (Exception ex) {
			WB.addLog("WB.addLog(String):void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	private static String formatter(Object eventObj, String eventCont, String eventMeth) throws Exception {
		// origin - 21.10.2023, last edit - 03.10.2026
		String res = "";
		try {
			var delimiter = "! ";
			res = res + "#" + eventCounter + delimiter + DateTool.formatter(DateTool.getNow2()) + delimiter
					+ eventObj.toString() + delimiter;
			if (eventCont.isEmpty()) {
				res = res + WB.currUser + delimiter;
			} else {
				res = res + eventCont + delimiter + WB.currUser + delimiter;
			}
			res = res + eventMeth + delimiter + WB.sysLineSep;
		} catch (Exception ex) {
			WB.addLog("WB.formatter(Object, 2String):String, ex=" + ex.getMessage(), "", "WB");
		}
		return res;
	}

	private static void codeCounter() throws Exception {
		// origin - 21.09.2026, last edit - 11.10.2026
		try {
			if (WB.isProject() == false) {
				return;
			}

			Path srcPath = Paths.get("src");

			long countLinesProjectCode = Files.walk(srcPath).filter(Files::isRegularFile)
					.filter(p -> p.toString().endsWith(".java")).flatMap(p -> {
						try {
							return Files.lines(p);
						} catch (Exception e) {
							return java.util.stream.Stream.empty();
						}
					}).map(String::trim).filter(line -> !line.isEmpty()).count();

			long countMethodsProjectCode = 0;
			try (Stream<Path> walk = Files.walk(srcPath)) {
				Iterable<Path> javaFiles = walk.filter(Files::isRegularFile)
						.filter(path -> path.toString().endsWith(".java"))::iterator;
				for (Path file : javaFiles) {
					try (Stream<String> lines = Files.lines(file)) {
						long matchesInFile = lines.map(String::trim)
								.filter(line -> line.endsWith("throws Exception {") || line.contains(" toString() "))
								.count();
						countMethodsProjectCode += matchesInFile;
					}
				}
			}

			var linesCodeInDay = (int) (countLinesProjectCode
					/ DateTool.getDurationInDays(WB.startProjectDate, DateTool.getNow()));
			var restDays = (int) ((WB.planCountLinesProjectCode - countLinesProjectCode) / linesCodeInDay);
			var restYears = Num.roundCustom((restDays / 365), 2);
			var restMonths = Num.roundCustom((restYears * 12), 2);
			WB.addLog("WB.codeCounter(), Всего строк кода (без пустых)=" + countLinesProjectCode + ", число методов="
					+ countMethodsProjectCode + ", в среднем строк в методе="
					+ (int) (countLinesProjectCode / countMethodsProjectCode) + ", готовность проекта="
					+ Num.roundCustom(((countLinesProjectCode * 100) / WB.planCountLinesProjectCode), 2) + "%"
					+ ", строк кода в день=" + linesCodeInDay + ", осталось дней=" + restDays + ", осталось мес.="
					+ restMonths + ", осталось лет=" + restYears, "", "WB");
		} catch (Exception ex) {
			WB.addLog("WB.codeCounter():void, ex=" + ex.getMessage(), "", "WB");
		}
	}
}