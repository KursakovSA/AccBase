import java.io.File;
import java.net.InetAddress;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;

public class WB extends JFrame {
	// origin - 25.09.2023, last edit - 28.10.2025
	private static final long serialVersionUID = 1L;
	public static final String startDir = System.getProperty("user.dir");
	public static final String sysLineSep = System.lineSeparator();

	public static int eventCounter = 0;
	public static StringBuilder eventLog = new StringBuilder("");
	public static StringBuilder eventLog2 = new StringBuilder("");
	public static LocalDateTime eventGlobalStart, eventGlobalEnd;

	public static String eventLogFile = "eventLog.csv"; // basic log default;
	public static String eventLogPath = WB.startDir + File.separator + eventLogFile;

	public static String lastSaveDir, lastSelectFileDir = System.getProperty("user.dir");
	public static String mediaDir = System.getProperty("user.dir") + File.separator + "media";
	public static String commonDocDir = System.getProperty("user.dir") + File.separator + "commonDoc";
	public static String localDir = System.getProperty("user.dir") + File.separator + "local";
	public static String templateDocDir = System.getProperty("user.dir") + File.separator + "templateDoc";
	public static String backupDir = System.getProperty("user.dir") + File.separator + "backup";
	public static String inputOutputDir = System.getProperty("user.dir") + File.separator + "inputOutput";

	public static String lastConn = "";
	public static String lastConnWork = "";

	public static Abc abcGlobal, abcTemplate, abcLocal, abcLast;

	public static final LocalDate minDateSupported = LocalDate.of(1900, Month.JANUARY, 01);
	public static final LocalDate maxDateSupported = LocalDate.of(2080, Month.DECEMBER, 31);

	public static String currUser, version, frameBasicTitle;
	public static JFrame frameBasic;

	static {
		try {
			WB.version = "26.10.2025";
			WB.abcGlobal = new Abc(Conn.globalPath);
			WB.abcTemplate = new Abc(Conn.templatePath);
			WB.abcLocal = new Abc();
			WB.abcLast = new Abc();
			// WB.currUser = WB.getAuthData();
			WB.frameBasicTitle = "Workbook Basic (accounting program), based on Java, SQLite, Eclipse. License : GPL 3.0. Made in Qazaqstan."
					+ ", version -" + version + ", support - github.com/KursakovSA/AccBase";
		} catch (Exception ex) {
			WB.addLog("WB.static ctor, ex=" + ex.getMessage(), "", "WB");
		}
		WB.addLog("WB.static ctor block init, WB.abcGlobal=" + WB.abcGlobal, "", "WB");
		WB.addLog("WB.static ctor block init, WB.abcTemplate=" + WB.abcTemplate, "", "WB");
	}

	public static void main(String[] args) throws Exception {
		// origin - 25.09.2023, last edit - 13.06.2025
		LocalDateTime localStart = WB.getLocalStart();
		try {
			WB.getGlobalStart();
			Conn.init();
			WB.init();
			WB.test();
			WB.frameBasic = GUI.getFrameBasic();
		} catch (Exception ex) {
			WB.addLog("WB.main():void, ex=" + ex.getMessage(), "", "WB");
		} finally {
			Etc.doNothing();
		}
		WB.getLocalEnd("WB.main, end ", localStart);
	}

	private static void init() throws Exception {
		// origin - 21.10.2023, last edit - 13.06.2025
		try {
			if (Conn.systemFact.isEmpty()) {
				return;
			}
			WB.createDir();
			WB.restoreLastState();
			WB.javaInfo();
		} catch (Exception ex) {
			WB.addLog("WB.init():void, ex=" + ex.getMessage(), "", "WB");
		}
		WB.addLog("WB.init, end", "", "WB");
		WB.addLog2("WB.init, end", "", "WB");
	}

	private static void javaInfo() throws Exception {
		// origin - 05.07.2024, last edit - 13.06.2025
		try {
			WB.addLog2("WB.init, java.version=" + System.getProperty("java.version"), "", "WB");
			WB.addLog2("WB.init, java.home=" + System.getProperty("java.home"), "", "WB");
			WB.addLog2("WB.init, java.class.path=" + System.getProperty("java.class.path"), "", "WB");
			// WB.addLog2("WB.init, java.io.dir=" +
			// System.getProperty("java.io.dir"),"","WB");
			WB.addLog2("WB.init, os.name=" + System.getProperty("os.name"), "", "WB");
		} catch (Exception ex) {
			addLog("WB.javaInfo():void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	private static void createDir() throws Exception {
		// origin - 05.07.2024, last edit - 13.06.2025
		try {
			for (String dirPath : new String[] { mediaDir, commonDocDir, templateDocDir, backupDir, localDir,
					inputOutputDir }) {
				if (Files.notExists(Paths.get(dirPath))) {
					Files.createDirectory(Paths.get(dirPath));
					WB.addLog("WB.init, createDir=" + dirPath, "", "WB");
				}
			}
		} catch (Exception ex) {
			WB.addLog("WB.createDir():void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	@SuppressWarnings("unused")
	private static void restoreLastState() throws Exception {// TOTHINK
		// origin - 14.02.2024, last edit - 19.03.2025
		List<ModelDto> lastState = new ArrayList<ModelDto>();
		List<ModelDto> restoreState = new ArrayList<ModelDto>();
		try {
			// TODO
		} catch (Exception ex) {
			WB.addLog("WB.restoreLastState():void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	@SuppressWarnings("unused")
	private static void saveLastState() throws Exception {// TOTHINK
		// origin - 14.02.2024, last edit - 19.03.2025
		List<ModelDto> lastState = new ArrayList<ModelDto>();
		try {

		} catch (Exception ex) {
			WB.addLog("WB.saveLastState():void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	private static void test() throws Exception {
		// origin - 25.09.2023, last edit - 12.11.2025
		try {
			if (isProject()) {

				// folder Common
				Abc.test();
				BasicDto.test();
				ModelDto.test();

				Etc.test();
				Deal.test();
				Face.test();

				// folder Process
				Account.test();
				Geo.test();
				IdGen.test();
				Meter.test();
				Process.test();
				Workbook.test();
				Slice.test();
				Mark.test();
				Role.test();
				Info.test();
				Sign.test();
				Item.test();
				TimeJob.test();
				StopList.test();

				Report.test();
				InOut.test();
				TemplateDoc.test();

				// folder ORM
				DAL.test();
				Conn.test();
				Qry.test();
				ReadSet.test();
				WriteSet.test();

				// folder GUI
				GUI.test();
				Command.test();

				DateTool.test();
				WorkDay.test();
				LocInt.test();
				Conv.test();
				CSV.test();
				DefVal.test();
				Fmtr.test();
				ListVal.test();
				CompositeVal.test();
				UnitVal.test();
				TagVal.test();
				Pawn.test();
				PawnDoc.test();
				PawnDocTerm.test();
				Move.test();
				MoreVal.test();
				SPL.test();
				Prolongation.test();
				RangeVal.test();
				ViewData.test();
				AnnoVal.test();
				SimplexVal.test();
				AccrualTerm.test();

				DealDto.test();
				FaceDto.test();
				Address.test();
				Dept.test();
				SpanDate.test();
				FIO.test();
				SerNumDate.test();
				Crew.test();

				SpanTime.test();
				JobDay.test();
				JobCycle.test();
				JobTurn.test();
				Point.test();
				JobMap.test();
				FaceContact.test();
				FaceDaily.test();
				JobDaily.test();

				FaceReg.test();
				PawnGold.test();
				PawnBalance.test();
				PawnSum.test();
				PawnAuto.test();
				PA.test();

				BrutNet.test();
				Qty.test();
				PawnCell.test();
				QPA.test();
				ProcessDto.test();
				FaceCat.test();
				PawnDocCat.test();

				ShipmentTerm.test();
				PaymentTerm.test();
				DeliveryTerm.test();
				ProlongationTerm.test();
				PoolTerm.test();
				PawnTerm.test();
				PriceTerm.test();
				AddTerm.test();

				Accrual.test();
				PawnShopEngine.test();

				TemplateDocTerm.test();
				TemplateDocEngine.test();

				ZIP.test();
				ProcessVar.test();
				MassReg.test();
				TwoVal.test();
				ThreeVal.test();
				JobTerm.test();

				// folder Asset
				Asset.test();
				AssetPart.test();
				AssetPrice.test();
				SubAsset.test();
				AssetDto.test();
				AssetCat.test();
				AssetDefectCat.test();
				AssetReg.test();
				AssetBalance.test();
				Unit.test();

				// folder Price
				Price.test();
				PriceCurrency.test();

				FaceBalance.test();
				DealBalance.test();

				Cash.test();
				CashBalance.test();
				CashJournal.test();
				CashOrder.test();
				CashInventory.test();

				// folder Bank
				Bank.test();
				BankJournal.test();
				BankOrder.test();
				PaymentOrder.test();
				BankBalance.test();

				// folder Store
				Store.test();
				StoreOrder.test();
				StoreInventory.test();
				StoreBalance.test();
				StoreJournal.test();

				// folder Staff
				Staff.test();
				StaffTable.test();
				StaffBalance.test();
				StaffOrder.test();

				// folder Salary
				SalaryOrder.test();
				SalaryBalance.test();
				SalaryJournal.test();
				SalaryPayment.test();
				SalaryFund.test();

				User.test();
				Access.test();

				// folder Sale
				SaleOrder.test();
				SaleJournal.test();
				SaleReturn.test();
				SaleBalance.test();

				// folder Purchase
				PurchaseOrder.test();
				PurchaseJournal.test();
				PurchaseReturn.test();
				PurchaseBalance.test();

				// folder Service
				Service.test();
				ServiceOrder.test();
				ServiceBalance.test();

				// folder VAT
				VatIn.test();
				VatOut.test();
				VatBalance.test();
				VatStmt.test();

				// folder FinStmt
				FinStmtCtrl.test();
				BalanceSheet.test();
				CashFlowStmt.test();
				IncomeStmt.test();
				EquityStmt.test();

				// folder StatStmt
				StatStmtCtrl.test();

				// folder Entry
				Entry.test();
				EntryJournal.test();
				FullJournal.test();

				// folder AccStmt
				AccStmtCtrl.test();
				AccBalance.test();
				AccJournal.test();
				AccAnalyst.test();

				// folder Bill
				Bill.test();
				BillJournal.test();

				// folder Warrant
				Warrant.test();
				WarrantJournal.test();

				// folder Imprest
				Imprest.test();
				ImprestBalance.test();
				ImprestJournal.test();
				
				// folder WriteOff
				WriteOff.test();
				WriteOffBalance.test();
				WriteOffJournal.test();
				
				//folder Debt
				Debt.test();
				DebtBalance.test();
			}
		} catch (Exception ex) {
			WB.addLog("WB.test():void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	public static void writeFile(String pathFile, String fileContent) throws Exception {
		// origin - 19.10.2023, last edit - 13.06.2025
		try {
			Path pf = Paths.get(pathFile);
			boolean isReplace = true;
			if (isProject() == false) {
				if (Files.exists(pf)) {
					isReplace = false;
				}
			}
			if (isReplace) {
				Files.write(pf, fileContent.toString().getBytes("utf-8"));
			} else {
				Files.write(pf, fileContent.toString().getBytes("utf-8"), StandardOpenOption.APPEND);
			}
		} catch (Exception ex) {
			WB.addLog("WB.writeFile(String pathFile, String fileContent):void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	@SuppressWarnings({ "deprecation", "unused" })
	public static void openFile(String pathFile) throws Exception {
		// origin - 19.10.2023, last edit - 13.06.2025
		if (WB.isProject()) {
			try {
				java.lang.Process process = Runtime.getRuntime().exec("explorer.exe " + pathFile.toString(), null);
			} catch (Exception ex) {
				System.out
						.println("WB.openFile(String pathFile):void, ex=" + ex.getMessage() + ", pathFile=" + pathFile);
			}
		}
	}

	@SuppressWarnings("unused")
	private static String getAuthData() throws Exception {
		// origin - 05.12.2023, last edit - 28.10.2025
		String res = "";
		try {
			res = res + InetAddress.getLocalHost().getHostName() + "\\";
			res = res + System.getProperty("user.name");
		} catch (Exception ex) {
			WB.addLog("WB.getAuthData():String, ex=" + ex.getMessage(), "", "WB");
		}
		return res;
	}

	private static boolean hasFile(String dir, String file) throws Exception {
		// origin - 07.12.2023, last edit - 13.06.2025
		boolean res = false;
		try {
			Path checkFilePath = Paths.get(dir + File.separator + file);
			if (Files.exists(checkFilePath)) {
				res = true;
			}
		} catch (Exception ex) {
			WB.addLog("WB.hasFile(String dir, String file):boolean, ex=" + ex.getMessage(), "", "WB");
		}
		return res;
	}

	private static boolean isProject() throws Exception {
		// origin - 05.12.2023, last edit - 13.06.2025
		boolean res = false;
		try {
			if (WB.hasFile(WB.startDir, ".project")) { // if in startDir exist project Eclipse then isDev = true
				res = true;
			}
		} catch (Exception ex) {
			System.out.println("WB.isProject():boolean, ex=" + ex.getMessage());
		}
		return res;
	}

	public static void getGlobalStart() throws Exception {
		// origin - 25.10.2023, last edit - 13.06.2025
		try {
			WB.eventGlobalStart = DateTool.getNow2();
			WB.addLog("WB.getGlobalStart, eventGlobalStart=" + DateTool.formatter(eventGlobalStart), "", "WB");
		} catch (Exception ex) {
			WB.addLog("WB.getGlobalStart():void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	public static LocalDateTime getLocalStart() throws Exception {
		// origin - 13.06.2024, last edit - 13.06.2025
		LocalDateTime res = null;
		try {
			res = DateTool.getNow2();
		} catch (Exception ex) {
			WB.addLog("WB.getLocalStart():LocalDateTime, ex=" + ex.getMessage(), "", "WB");
		}
		return res;
	}

	public static LocalDateTime getLocalEnd(String source, LocalDateTime localStart) throws Exception {
		// origin - 13.06.2024, last edit - 13.06.2025
		LocalDateTime res = null;
		try {
			res = DateTool.getNow2();
		} catch (Exception ex) {
			WB.addLog("WB.getLocalEnd(String source, LocalDateTime localStart):LocalDateTime, ex=" + ex.getMessage(),
					"", "WB");
		}
		WB.addLog2("WB.getLocalEnd, durationLocal=" + DateTool.getDuration(localStart, res) + " ms, " + source, "",
				"WB");
		return res;
	}

	public static void getFinish() throws Exception {
		// origin - 26.09.2023, last edit - 13.06.2025
		try {
			WB.saveLastState();
			WB.getEventEnd();
			WB.writeFile(eventLogPath, eventLog.toString());
			WB.openFile(eventLogPath);
		} catch (Exception ex) {
			addLog("WB.getFinish():void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	private static void getEventEnd() throws Exception {
		// origin - 21.10.2023, last edit - 13.06.2025
		try {
			WB.eventGlobalEnd = DateTool.getNow2();// DateTool.getOffsetDateTimeNow();
			WB.addLog("WB.getEventEnd, eventGlobalEnd=" + DateTool.formatter(eventGlobalEnd), "", "WB");
			WB.addLog("WB.getEventEnd, durationGlobal=" + DateTool.getDuration(WB.eventGlobalStart, WB.eventGlobalEnd)
					+ " ms", "", "WB");
			WB.addLog("Log detail");
			WB.addLog(eventLog2.toString());
		} catch (Exception ex) {
			WB.addLog("WB.getEventEnd():void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	public static <T> void log(List<T> listDto, String type) throws Exception {
		// origin - 24.05.2025, last edit - 08.10.2025
		try {
			for (var tmp : listDto) {
				WB.addLog2("WB.log(List<" + type + ">), res=" + tmp, "", "WB");
			}
//			if (listDto.size() != 0) {
//				WB.addLog2("", "", "WB");
//			}
		} catch (Exception ex) {
			WB.addLog("WB.log(List<T> listDto, String type):void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	public static void addLog2(Object EventObj, String EventCont, String EventMeth) throws Exception {
		// origin - 03.11.2023, last edit - 08.10.2025
		try {
			WB.eventCounter = WB.eventCounter + 1;
			if (Etc.strMatch(EventObj.toString(), ",") == 0) { // on start block test do space line
				WB.eventLog2.append(WB.formatter("", "", ""));
			}
			WB.eventLog2.append(WB.formatter(EventObj, EventCont, EventMeth));
		} catch (Exception ex) {
			WB.addLog("WB.addLog2(Object, 2String):void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	public static void addLog(Object EventObj, String EventCont, String EventMeth) {
		// origin - 26.09.2023, last edit - 13.06.2025
		WB.eventCounter = WB.eventCounter + 1;
		try {
			WB.eventLog.append(WB.formatter(EventObj, EventCont, EventMeth));
		} catch (Exception ex) {
			WB.addLog("WB.addLog(Object EventObj, String EventCont, String EventMeth):void, ex=" + ex.getMessage(), "",
					"WB");
		}
	}

	private static void addLog(String str) throws Exception {
		// origin - 03.11.2023, last edit - 13.06.2025
		try {
			WB.eventCounter = WB.eventCounter + 1;
			WB.eventLog.append(str + WB.sysLineSep);
		} catch (Exception ex) {
			WB.addLog("WB.addLog(String str):void, ex=" + ex.getMessage(), "", "WB");
		}
	}

	private static String formatter(Object eventObj, String eventCont, String eventMeth) throws Exception {
		// origin - 21.10.2023, last edit - 13.06.2025
		String res = "";
		try {
			res = res + "#" + eventCounter + "| " + DateTool.formatter(DateTool.getNow2()) + "| " + eventObj.toString()
					+ "| ";
			if (eventCont.isEmpty()) {
				res = res + WB.currUser + "| ";
			} else {
				res = res + eventCont + "| " + WB.currUser + "| ";
			}

			res = res + eventMeth + "| " + WB.sysLineSep;
		} catch (Exception ex) {
			WB.addLog("WB.formatter(Object eventObj, String eventCont, String eventMeth):String, ex=" + ex.getMessage(),
					"", "WB");
		}
		return res;
	}
}