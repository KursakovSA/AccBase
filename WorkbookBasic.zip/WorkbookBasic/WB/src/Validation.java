import java.util.Arrays;
import java.util.TreeSet;

public class Validation extends Model {
	// origin - 22.12.2023, last edit - 06.07.2024

	static {
		try {
			standard = new TreeSet<String>(Arrays.asList(WB.strEmpty, WB.strEmpty, WB.strEmpty, WB.strEmpty,
					WB.strEmpty, WB.strEmpty, WB.strEmpty));// TODO
			sectoral = new TreeSet<String>(Arrays.asList(WB.strEmpty, WB.strEmpty, WB.strEmpty));// TODO
			custom = new TreeSet<String>(Arrays.asList(WB.strEmpty, WB.strEmpty, WB.strEmpty));// TODO
		} catch (Exception ex) {
			WB.addLog("Validation.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Validation");
		} finally {
			Etc.doNothing();
		}
	}

	public Validation(String Id, String Code, String Description) throws Exception {
		// origin - 22.12.2023, last edit - 07.07.2024
		try {
			this.id = Id;
			this.code = Code;
			this.description = Description;
		} catch (Exception ex) {
			WB.addLog("Validation.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Validation");
		} finally {
			Etc.doNothing();
		}
	}

	public Validation() throws Exception {
		// origin - 22.12.2023, last edit - 07.07.2024
		try {
		} catch (Exception ex) {
			WB.addLog("Validation.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Validation");
		} finally {
			Etc.doNothing();
		}
	}

	public static void test() throws Exception {
		// origin - 22.12.2023, last edit - 06.07.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Validation.test, ex=" + ex.getMessage(), WB.strEmpty, "Validation");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Validation.test end ", WB.strEmpty, "Validation");
	}
}