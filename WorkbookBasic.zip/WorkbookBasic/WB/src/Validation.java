import java.util.Arrays;
import java.util.TreeSet;

public class Validation extends Model {
	// origin - 22.12.2023, last edit - 22.12.2023
	
	static {
		standard = new TreeSet<String>(Arrays.asList("", "", "", "", ""));//TODO
		sectoral = new TreeSet<String>(Arrays.asList("", "", "", "", ""));//TODO
		custom = new TreeSet<String>(Arrays.asList("", "", ""));//TODO
	}
    
    public Validation(String Id, String Code, String Description) {
		// origin - 22.12.2023, last edit - 22.12.2023
		this.id = Id;
		this.code = Code;
		this.description = Description;
	}
    
    public Validation() {
		// origin - 22.12.2023, last edit - 22.12.2023
	}
    
    public static void test() throws Exception {
		// origin - 22.12.2023, last edit - 27.06.2024
	}
}