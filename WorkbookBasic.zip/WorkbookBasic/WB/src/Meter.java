public class Meter extends ModelDto {
	// origin - 28.09.2023, last edit - 04.08.2024

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Meter.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Meter");
		} finally {
			Etc.doNothing();
		}
	}

	public Meter(String Id, String Code, String Description) throws Exception {
		// origin - 05.12.2023, last edit - 11.08.2024
		super(Id, Code, Description);
		this.table = this.getClass().getName();
	}

	public Meter() throws Exception {
		// origin - 05.12.2023, last edit - 11.08.2024
		super();
		this.table = this.getClass().getName();
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 06.07.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Meter.test, ex=" + ex.getMessage(), WB.strEmpty, "Meter");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Meter.test end ", WB.strEmpty, "Meter");
	}
}
