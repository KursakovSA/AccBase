public class Meter extends ModelDto {
	// origin - 28.09.2023, last edit - 21.11.2024

	public String expectedValue;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Meter.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "Meter");
		} finally {
			Etc.doNothing();
		}
	}

	public boolean isValid() throws Exception {
		// origin - 08.10.2024, last edit - 09.10.2024
		boolean res = true;
		try {
			if (this.parent.isEmpty()) { // ?? not need ??
				res = false;
			}
		} catch (Exception ex) {
			WB.addLog("Meter.isValid, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Meter");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Meter.isValid, res=" + res + ", this=" + this, WB.strEmpty,
		// "Meter");
		return res;
	}

	public boolean isExist() throws Exception {
		// origin - 08.10.2024, last edit - 13.11.2024
		boolean res = false;
		try {
			for (var currMeter : WB.abcLast.meter) {
				if ((Etc.strEquals(currMeter.id, this.id)) & (Etc.strEquals(currMeter.code, this.code))) {
					this.parent = currMeter.parent;
					this.unit = currMeter.unit;
					this.more = currMeter.more;
					this.expectedValue = MoreVal.getFieldByKey(this.more, "AbcExpectedValue");
					res = true;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Meter.isExist, ex=" + ex.getMessage() + ", res=" + res, WB.strEmpty, "Meter");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Meter.isExist, res=" + res + ", this=" + this, WB.strEmpty,
		// "Meter");
		return res;
	}

	public Meter(String Id) throws Exception {
		// origin - 05.12.2023, last edit - 21.11.2024
		super();
		this.table = this.getClass().getName();
		this.id = Id;
		this.code = Id;
		this.isExist();
		// this.isValid();
	}

	public Meter() throws Exception {
		// origin - 05.12.2023, last edit - 21.11.2024
		super();
		this.table = this.getClass().getName();
		var root = Abc.getRoot(this.table); // get unit root from WB.abcLast
		this.id = root.id;
		this.code = root.code;
		this.description = root.description;
		this.isExist();
		// this.isValid();
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 21.11.2024
		try {

//			// ctor()
//			Meter m0 = new Meter();
//			WB.addLog2("Meter.test.ctor()=" + m0 + ", isExist=" + m0.isExist() + ", isValid=" + m0.isValid(),
//					WB.strEmpty, "Meter");

//			// ctor (String Id)
//			Meter m1 = new Meter("Meter.Amount");
//			WB.addLog2(
//					"Meter.test.ctor('Meter.Amount')=" + m1 + ", isExist=" + m1.isExist() + ", isValid=" + m1.isValid(),
//					WB.strEmpty, "Meter");
//			Meter m2 = new Meter("Meter.tralala");
//			WB.addLog2("Meter.test.ctor('Meter.tralala')=" + m2 + ", isExist=" + m2.isExist() + ", isValid="
//					+ m2.isValid(), WB.strEmpty, "Meter");

		} catch (Exception ex) {
			WB.addLog("Meter.test, ex=" + ex.getMessage(), WB.strEmpty, "Meter");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Meter.test end ", WB.strEmpty, "Meter");
	}
}
