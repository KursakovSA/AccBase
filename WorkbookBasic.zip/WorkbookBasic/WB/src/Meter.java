public class Meter extends ModelDto {
	// origin - 28.09.2023, last edit - 19.03.2025
	public String expectedValue;

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Meter.static ctor, ex=" + ex.getMessage(), "", "Meter");
		}
	}

	public void isValid() throws Exception {
		// origin - 08.10.2024, last edit - 19.03.2025
		super.isValid();
		try {
			if (this.parent.isEmpty()) {
				this.isValid = false;
			}
		} catch (Exception ex) {
			WB.addLog("Meter.isValid, ex=" + ex.getMessage(), "", "Meter");
		}
	}

	public void isExist() throws Exception {
		// origin - 08.10.2024, last edit - 20.03.2025
		super.isExist();
		try {
			for (var currMeter : WB.abcLast.meter) {
				if (Etc.strEquals(currMeter.id, this.id)) {
					this.code = currMeter.code;
					this.description = currMeter.description;
					this.parent = currMeter.parent;
					this.more = currMeter.more;
					this.expectedValue = MoreVal.getFieldByKey(this.more, "AbcExpectedValue");
					this.isExist = true;
					break;
				}
			}
		} catch (Exception ex) {
			WB.addLog("Meter.isExist, ex=" + ex.getMessage(), "", "Meter");
		}
	}

	public Meter(String Id) throws Exception {
		// origin - 05.12.2023, last edit - 27.12.2024
		this();
		this.src = Id;
		if (Id.isEmpty() == false) {
			this.id = this.code = Id;
		}
		this.isExist();
		this.isValid();
	}

	public Meter() throws Exception {
		// origin - 05.12.2023, last edit - 18.02.2025
		this.clear();
		this.isExist();
		var root = Abc.getRoot(this.table); // get root from WB.abcLast
		this.id = root.id;
		this.code = root.code;
		this.description = root.description;
		this.more = root.more;
	}

	public void clear() throws Exception {
		// origin - 21.12.2024, last edit - 20.03.2025
		try {
			super.clear();
			this.table = this.getClass().getName();
		} catch (Exception ex) {
			WB.addLog("Meter.clear, ex=" + ex.getMessage(), "", "Meter");
		}
	}

	public String toString() {
		// origin - 21.12.2024, last edit - 20.03.2025
		String res = "";
		try {
			res = res + Fmtr.addAnyway("src ", this.src);
			res = res + Fmtr.addIfNotEmpty(", table ", this.table);
			res = res + Fmtr.addIfNotEmpty(", id ", this.id);
			res = res + Fmtr.addIfNotEmpty(", parent ", this.parent);
			res = res + Fmtr.addIfNotEmpty(", ", this.slice);
			res = res + Fmtr.addIfNotEmpty(", date1 ", this.date1);
			res = res + Fmtr.addIfNotEmpty(", date2 ", this.date2);
			res = res + Fmtr.addIfNotEmpty(", code ", this.code);
			res = res + Fmtr.addIfNotEmpty(", description ", this.description);
			res = res + Fmtr.addIfNotEmpty(", ", this.unit);
			res = res + Fmtr.addIfNotEmpty(", more ", this.more);

			res = res + Fmtr.addIfNotEmpty(", isExist ", this.isExist);
			res = res + Fmtr.addIfNotEmpty(", isValid ", this.isValid);

			res = res + Fmtr.addIfNotEmpty(", expectedValue ", this.expectedValue);

			res = "{" + res + "}";
		} catch (Exception ex) {
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 20.03.2025
		try {

//			// ctor (String Id)
//			for (var tmp : new String[] {"", "Meter.Amount", "Meter.tralala", "Meter.GrossWeight/NetWeight"}) {
//				WB.addLog2("Meter.test.ctor(String)=" + new Meter(tmp.id), "", "Meter");
//			}

		} catch (Exception ex) {
			WB.addLog("Meter.test, ex=" + ex.getMessage(), "", "Meter");
		}
	}
}