public class Meter extends Model {
	// origin - 28.09.2023, last edit - 06.07.2024
	public Meter parent;
	public Unit unit;

	public Meter(String Id, String Code, String Description) throws Exception {
		// origin - 05.12.2023, last edit - 07.07.2024
		try {
			this.id = Id;
			this.code = Code;
			this.description = Description;
		} catch (Exception ex) {
			WB.addLog("Meter.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Meter");
		} finally {
			Etc.doNothing();
		}
	}

	public Meter() throws Exception {
		// origin - 05.12.2023, last edit - 07.07.2024
		try {
		} catch (Exception ex) {
			WB.addLog("Meter.ctor, ex=" + ex.getMessage(), WB.strEmpty, "Meter");
		} finally {
			Etc.doNothing();
		}
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 06.07.2024
		try {

		} catch (Exception ex) {
			WB.addLog("Meter.test, ex=" + ex.getMessage(), WB.strEmpty, "Meter");
		} finally {
			Etc.doNothing();
		}
		WB.addLog2("Meter.test end ", WB.strEmpty, "Meter");
	}
}
