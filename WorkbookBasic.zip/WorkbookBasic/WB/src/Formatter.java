import java.lang.reflect.Field;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Formatter {
	// origin - 24.08.2024, last edit - 10.09.2024

	static {
		try {
		} catch (Exception ex) {
			WB.addLog("Formatter.static ctor, ex=" + ex.getMessage(), WB.strEmpty, "StopList");
		} finally {
			Etc.doNothing();
		}
	}

	public static List<LocalDate> listStr(List<String> inLst) throws Exception {
		// origin - 10.09.2024, last edit - 11.09.2024
		List<LocalDate> res = new ArrayList<LocalDate>();
		try {
			for (var curr : inLst) {
				if (curr.isEmpty() == false) {
					res.add(DateTool.getLocalDate(curr));
				}
			}
		} catch (Exception ex) {
			WB.addLog("Formatter.listStr, ex=" + ex.getMessage(), WB.strEmpty, "Formatter");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Formatter.listStr, resList<LocalDate>=" + Formatter.listVal2(res,
		// ""), WB.strEmpty, "Formatter");
		return res;
	}

	public static List<String> listVal(String initStr, String strSplit) throws Exception {
		// origin - 16.07.2024, last edit - 11.09.2024
		List<String> res = new ArrayList<String>();
		try {
			initStr = Etc.fixTrim(initStr);
			String[] tmp = initStr.split(strSplit);
			String currTmp = WB.strEmpty;
			for (var currArr : tmp) {
				currTmp = WB.strEmpty;
				// currTmp = currArr.toString();
				currTmp = Etc.fixTrim(currArr.toString());
				// currTmp = currTmp.replace(ListVal.strSplit, WB.strEmpty);
				if (currTmp.isEmpty() == false) {
					res.add(currTmp);
				}
			}

		} catch (Exception ex) {
			WB.addLog("Formatter.listVal, ex=" + ex.getMessage(), WB.strEmpty, "Formatter");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Formatter.listVal, resList<String>=" + Formatter.listVal(res,
		// ""), WB.strEmpty, "Formatter");
		return res;
	}

	public static String reflect(Object obRef) throws Exception {
		// origin - 26.08.2024, last edit - 25.11.2024
		String res = WB.strEmpty;
		try {
			Field[] fields = obRef.getClass().getFields();
			for (var currField : fields) {
				currField.setAccessible(true);

				if (currField.get(obRef) == null) { // skip null
					continue;
				}

				String strFieldValue = currField.get(obRef).toString();

				switch (strFieldValue) { // skip empty vals
				case "0", "0.0", "[]", "{}", "" -> {
					continue;
				}
				default -> Etc.doNothing();
				}
				res = res + Formatter.equal(currField.getName(), strFieldValue);
			}
		} catch (Exception ex) {
			WB.addLog("Formatter.reflect, ex=" + ex.getMessage(), WB.strEmpty, "Formatter");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Formatter.reflect, res=" + res, WB.strEmpty, "Formatter");
		return res;
	}

	public static <T> String listIter(List<T> initIter, String context) throws Exception {
		// origin - 25.08.2024, last edit - 09.09.2024
		String res = WB.strEmpty;
		String currRes = WB.strEmpty;
		try {
			for (var currIter : initIter) {
				currRes = currIter.toString(); // + System.lineSeparator();
				currRes = currRes.replaceAll(WB.strSemiColon, WB.strCommaSpace); // for log file it commaspace that it
																					// break log file
				// separated ;
				WB.addLog2("Formatter.listIter, res=" + currRes + ", context=" + context, WB.strEmpty, "Formatter");
				res = res + currRes;
			}
		} catch (Exception ex) {
			WB.addLog("Formatter.listIter, ex=" + ex.getMessage(), WB.strEmpty, "Formatter");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Formatter.listIter, res=" + res, WB.strEmpty, "Formatter");
		return res;
	}

	public static String listVal2(List<LocalDate> initList, String context) throws Exception {
		// origin - 10.09.2024, last edit - 10.09.2024
		String res = WB.strEmpty;
		try {
			for (var currList : initList) {
				res = res + currList.toString() + WB.strCommaSpace;
			}
		} catch (Exception ex) {
			WB.addLog("Formatter.listVal2, ex=" + ex.getMessage(), WB.strEmpty, "Formatter");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Formatter.listVal2, res(LocalDate)=" + res + ", context=" +
		// context,
		// WB.strEmpty, "Formatter");
		return res;
	}

	public static String listVal(List<String> initList, String context) throws Exception {
		// origin - 24.08.2024, last edit - 04.09.2024
		String res = WB.strEmpty;
		try {
			for (var currList : initList) {
				res = res + currList.toString() + WB.strCommaSpace;
			}
		} catch (Exception ex) {
			WB.addLog("Formatter.listVal, ex=" + ex.getMessage(), WB.strEmpty, "Formatter");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Formatter.listVal, res(String)=" + res + ", context=" + context,
		// WB.strEmpty, "Formatter");
		return res;
	}

	public static String id(String currRes, String objAdd) throws Exception {// for toString
		// origin - 21.08.2024, last edit - 24.08.2024
		String res = Etc.fixTrim(currRes);
		String fixStrAdd = Etc.fixTrim(objAdd.toString());
		try {
			if (fixStrAdd.isEmpty() == false) {
				res = res + WB.strSquareBracketLeft + fixStrAdd + WB.strSquareBracketRight;
			}
		} catch (Exception ex) {
			WB.addLog2("Formatter.Id, ex=" + ex.getMessage(), WB.strEmpty, "Formatter");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	public static String equal(String name, Object objAdd) throws Exception {// for toString
		// origin - 21.08.2024, last edit - 25.11.2024
		String res = WB.strEmpty;
		String fixStrAdd = Etc.fixTrim(objAdd.toString());
		try {
			if (fixStrAdd.isEmpty() == false) {
				// res = res + Etc.fixTrim(name) + WB.strEquals + fixStrAdd + WB.strCommaSpace;
				res = res + Etc.fixTrim(name) + WB.strSpace + fixStrAdd + WB.strCommaSpace;
			}
		} catch (Exception ex) {
			WB.addLog2("Formatter.equal, ex=" + ex.getMessage(), WB.strEmpty, "Formatter");
		} finally {
			Etc.doNothing();
		}
		return res;
	}

	private Formatter() throws Exception {
		// origin - 24.08.2024, last edit - 04.11.2024
	}

	public static void test() throws Exception {
		// origin - 24.08.2024, last edit - 16.09.2024
		try {

//			// listIter
//			List<ModelDto> newListIter = ModelDto.getSubsetByMore(WB.abcLast.basic, "AbcCodePay");
//			Formatter.listIter(newListIter, "AbcCodePay");

		} catch (Exception ex) {
			WB.addLog("Formatter.test, ex=" + ex.getMessage(), WB.strEmpty, "StopList");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Formatter.test end ", WB.strEmpty, "StopList");
	}
}