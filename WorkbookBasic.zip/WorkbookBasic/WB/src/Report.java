import java.util.*;

public class Report extends Model {
	// origin - 16.10.2023, last edit - 17.12.2023
	public TreeSet<Asset> asset;// TODO
	public TreeSet<Deal> deal;// TODO
	public TreeSet<Model> item;// TODO
	public TreeSet<Debt> debt;// TODO

	static {
		standard = new TreeSet<String>(Arrays.asList("Analysis", "Rest", "RestTurnover", "Depreciation", "Detail",
				"Balance", "Capital", "Income", "Money", "List", "PaySheet", "Price", "Revise", 
				"SalaryInquery", "SalarySheet", "SalarySummary", "Sheet","", "StaffDoc", "TaxForm","TaxRegistry"));
		sectoral = new TreeSet<String>(Arrays.asList("", "", ""));
		custom = new TreeSet<String>(Arrays.asList("", "", ""));
	}

	public static void test() {
		// origin - 06.12.2023, last edit - 06.12.2023
	}
}
