import java.util.*;

public class Report extends Model {
	// origin - 16.10.2023, last edit - 27.06.2024
	public TreeSet<Asset> asset;// TOTHINK
	public TreeSet<Deal> deal;// TOTHINK
	public TreeSet<Model> item;// TOTHINK
	public TreeSet<Debt> debt;// TOTHINK
	public static String defaultCellPhonePrefix = WB.strEmpty;

	static {
		standard = new TreeSet<String>(Arrays.asList("Analysis", "Rest", "RestTurnover", "Depreciation", "Detail",
				"Balance", "Capital", "Income", "Money", "List", "PaySheet", "Price", "Revise", "SalaryInquery",
				"SalarySheet", "SalarySummary", "Sheet", "", "StaffDoc", "TaxForm", "TaxRegistry"));
		sectoral = new TreeSet<String>(Arrays.asList("", "", ""));
		custom = new TreeSet<String>(Arrays.asList("", "", ""));
		defaultCellPhonePrefix = "+7-747";
	}

	public static String getKZIINPlaceholder() throws Exception {// sectoral pawnshop
		// origin - 26.06.2024, last edit - 27.06.2024
		String res = WB.strEmpty;
		res = res + Etc.getStrIntRnd(Info.argLenghtIIN); // TODO - how do first 6 numbers in view date - 671125 ???
		// WB.addLog2("Report.getKZIINPlaceholder, res=" + res, WB.strEmpty, "Report");
		return res;
	}

	public static String getCellPhonePlaceholder(String initCellPhonePrefix) throws Exception {// sectoral pawnshop
		// origin - 19.06.2024, last edit - 27.06.2024
		// this method need that fill field "cell phone" in report for gov organs, when
		// cell phone not know, but gov organs require you to indicate it
		String res = WB.strEmpty;
		if (initCellPhonePrefix.isEmpty()) {
			initCellPhonePrefix = Report.defaultCellPhonePrefix;
		}
		res = res + Etc.fixTrim(initCellPhonePrefix);
		res = res + "-" + Etc.getStrIntRnd(3);
		res = res + "-" + Etc.getStrIntRnd(2);
		res = res + "-" + Etc.getStrIntRnd(2); // res = ex. +7-747-567-32-71 random cell phone number
		// WB.addLog2("Report.getCellPhonePlaceholder, res=" + res + ",
		// initCellPhonePrefix=" + initCellPhonePrefix, WB.strEmpty, "Report");
		return res;
	}

	public static void test() throws Exception {
		// origin - 06.12.2023, last edit - 27.06.2024

		// getKZIINPlaceholder
		WB.addLog2("Report.getKZIINPlaceholder, res=" + getKZIINPlaceholder(), WB.strEmpty, "Report");

		// getCellPhonePlaceholder
		for (String testArg1 : new String[] { "+7-701", "+7-707", Report.defaultCellPhonePrefix, "+7-777", "+7-775",
				WB.strEmpty }) {
			WB.addLog2("Report.test.getCellPhonePlaceholder, res=" + getCellPhonePlaceholder(testArg1) + ", testArg1="
					+ testArg1, WB.strEmpty, "Report");
		}
	}
}
