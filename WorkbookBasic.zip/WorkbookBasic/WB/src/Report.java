import java.util.List;
import java.util.TreeSet;

public class Report extends ModelDto {
	// origin - 16.10.2023, last edit - 09.09.2024
	public static TreeSet<String> standard = new TreeSet<String>();
	public static TreeSet<String> sectoral = new TreeSet<String>();
	public static TreeSet<String> custom = new TreeSet<String>();
	public static String defaultCellPhonePrefix = WB.strEmpty;

	static {
		Report.standard = new TreeSet<String>(List.of("Analysis", "Rest", "RestTurnover", "Depreciation", "Detail",
				"Balance", "Capital", "Income", "Money", "List", "PaySheet", "Price", "Revise", "SalaryInquery",
				"SalarySheet", "SalarySummary", "Sheet", "", "StaffDoc", "TaxForm", "TaxRegistry"));
		Report.sectoral = new TreeSet<String>(List.of("", "", ""));
		Report.custom = new TreeSet<String>(List.of("", "", ""));
		Report.defaultCellPhonePrefix = "+7-747";
	}

	public static String getKZIINPlaceholder() throws Exception {// sectoral pawnshop
		// origin - 26.06.2024, last edit - 05.07.2024
		String res = WB.strEmpty;
		try {
			res = res + Etc.getStrIntRnd(Info.argLenghtIIN); // TODO - how do first 6 numbers in view date - 671125 ???
		} catch (Exception ex) {
			WB.addLog("Report.getKZIINPlaceholder, ex=" + ex.getMessage(), WB.strEmpty, "Report");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Report.getKZIINPlaceholder, res=" + res, WB.strEmpty, "Report");
		return res;
	}

	public static String getCellPhonePlaceholder(String initCellPhonePrefix) throws Exception {// sectoral pawnshop
		// origin - 19.06.2024, last edit - 05.07.2024
		// this method need that fill field "cell phone" in report for gov organs, when
		// cell phone not know, but gov organs require you to indicate it
		String res = WB.strEmpty;
		try {
			if (initCellPhonePrefix.isEmpty()) {
				initCellPhonePrefix = Report.defaultCellPhonePrefix;
			}
			res = res + Etc.fixTrim(initCellPhonePrefix);
			res = res + "-" + Etc.getStrIntRnd(3);
			res = res + "-" + Etc.getStrIntRnd(2);
			res = res + "-" + Etc.getStrIntRnd(2); // res = ex. +7-747-567-32-71 random cell phone number
		} catch (Exception ex) {
			WB.addLog("Report.getCellPhonePlaceholder, ex=" + ex.getMessage(), WB.strEmpty, "Report");
		} finally {
			Etc.doNothing();
		}
		// WB.addLog2("Report.getCellPhonePlaceholder, res=" + res + ",
		// initCellPhonePrefix=" + initCellPhonePrefix, WB.strEmpty, "Report");
		return res;
	}

	public Report() throws Exception {
		// origin - 06.07.2024, last edit - 04.08.2024
		super();
	}

	public static void test() throws Exception {
		// origin - 06.12.2023, last edit - 16.09.2024
		try {

//			// getKZIINPlaceholder
//			WB.addLog2("Report.getKZIINPlaceholder, res=" + getKZIINPlaceholder(), WB.strEmpty, "Report");

//			// getCellPhonePlaceholder
//			for (String testArg1 : new String[] { "+7-701", "+7-707", Report.defaultCellPhonePrefix, "+7-777", "+7-775",
//					WB.strEmpty }) {
//				WB.addLog2("Report.test.getCellPhonePlaceholder, res=" + getCellPhonePlaceholder(testArg1)
//						+ ", testArg1=" + testArg1, WB.strEmpty, "Report");
//			}

		} catch (Exception ex) {
			WB.addLog("Report.test, ex=" + ex.getMessage(), WB.strEmpty, "Report");
		} finally {
			Etc.doNothing();
		}
		//WB.addLog2("Report.test end ", WB.strEmpty, "Report");
	}
}
