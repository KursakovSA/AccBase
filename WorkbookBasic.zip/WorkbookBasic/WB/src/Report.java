import java.util.*;

public class Report extends Model {
	// origin - 16.10.2023, last edit - 07.12.2023
	public TreeSet<Asset> asset;// TODO
	public TreeSet<Deal> deal;// TODO
	public TreeSet<Model> item;// TODO
	public TreeSet<Debt> debt;// TODO

	static {
		standard = new TreeSet<String>(Arrays.asList("Analysis", "Balance", "BalanceTurnover", "Depreciation", "Detail",
				"", "", "", "", "", "", "", "", "", "", "", ""));
		sectoral = new TreeSet<String>(Arrays.asList("", "", ""));
		custom = new TreeSet<String>(Arrays.asList("", "", ""));
	}

	public static void test() {
		// origin - 06.12.2023, last edit - 06.12.2023
	}
}
