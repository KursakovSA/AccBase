﻿
//public static string TraceListToString()
//{//созд - 22.12.2022, изм - 22.12.2022
//    string outTraceListString = "";
//    if (TraceList != null)
//    {
//        foreach (var trLst in TraceList)
//        {
//            outTraceListString = outTraceListString + trLst.ToString() + Environment.NewLine;
//        }
//    }
//    return outTraceListString;
//}
//public static string TraceListToString(List<string>? inTraceList)
//{//созд - 22.12.2022, изм - 22.12.2022
//    string outTraceListString = "";
//    if (inTraceList != null)
//    {
//        foreach (var trLst in inTraceList)
//        {
//            outTraceListString = outTraceListString + trLst.ToString() + Environment.NewLine;
//        }
//    }
//    return outTraceListString;
//}

//public static void GetDirectory()
//{//созд - 2022, изм - 29.06.2023
//    StartDirectory = Environment.CurrentDirectory;
//    LastSaveDirectory = StartDirectory;
//    LastSelectFileDirectory = StartDirectory;

//    TraceState(StartDirectory, "GetDirectory(...), StartDirectory ");
//    TraceState(LastSaveDirectory, "GetDirectory(...), LastSaveDirectory ");
//    TraceState(LastSelectFileDirectory, "GetDirectory(...), LastSelectFileDirectory ");
//}

//public static string GetTableNameQuery(string tableView)
//{//созд - 2022, изм - 2022
//    //получаем из имени таблицы или view в запросе типа "AccountList" "чистое" имя таблицы типа "Account"
//    string TableNameQuery = tableView.Trim();
//    if (tableView != null)
//    {
//        TableNameQuery = TableNameQuery.Replace("List", "");
//    }

//    //TraceState(tableView, "GetTableNameQuery(...), tableView ");
//    //TraceState(TableNameQuery, "GetTableNameQuery(...), TableNameQuery ");
//    return TableNameQuery;
//}

//public static string? GetNameCode(string? NameId = default)
//{//созд - 2022, изм - 2022
//    //получаем из имени Id в запросе типа "Account" имя поля кода типа "AccountCode"
//    string? NameCode = default;
//    if (NameId != null)
//    {
//        NameCode = NameId + "Code";
//    }

//    //TraceState(NameId, "GetNameCode(...), NameId ");
//    //TraceState(NameCode, "GetNameCode(...), NameCode");
//    return NameCode;
//}

//public static Unit? GetUnit(SQLiteDataReader dr, string? NameId = default)
//{//созд - 2022, изм - 13.02.2023
//    Unit? outObj = default;
//    string? NameCode = GetNameCode(NameId);
//    if (dr[NameId].GetType().ToString() != "System.DBNull")
//    {
//        if (dr[NameCode].GetType().ToString() != "System.DBNull")
//        {
//            outObj = new Unit { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
//        }
//    }

//    //TraceState(outObj, "GetUnit(...), outObj ");
//    return outObj;
//}

//public static Account? GetAccount(SQLiteDataReader dr, string? NameId = default)
//{//созд - 2022, изм - 13.02.2023
//    Account? outObj = default;
//    string? NameCode = GetNameCode(NameId);
//    if (dr[NameId].GetType().ToString() != "System.DBNull")
//    {
//        if (dr[NameCode].GetType().ToString() != "System.DBNull")
//        {
//            outObj = new Account { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
//        }
//    }

//    //TraceState(outObj, "GetAccount(...), outObj ");
//    return outObj;
//}

//public static Mark? GetMark(SQLiteDataReader dr, string? NameId = default)
//{//созд - 2022, изм - 13.02.2023
//    Mark? outObj = default;
//    string? NameCode = GetNameCode(NameId);
//    if (dr[NameId].GetType().ToString() != "System.DBNull")
//    {
//        if (dr[NameCode].GetType().ToString() != "System.DBNull")
//        {
//            outObj = new Mark { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
//        }
//    }

//    //TraceState(outObj, "GetMark(...), outObj ");
//    return outObj;
//}

//public static Sign? GetSign(SQLiteDataReader dr, string? NameId = default)
//{//созд - 2022, изм - 13.02.2023
//    Sign? outObj = default;
//    string? NameCode = GetNameCode(NameId);
//    if (dr[NameId].GetType().ToString() != "System.DBNull")
//    {
//        if (dr[NameCode].GetType().ToString() != "System.DBNull")
//        {
//            outObj = new Sign { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
//        }
//    }

//    //TraceState(outObj, "GetSign(...), outObj ");
//    return outObj;
//}

//public static Slice? GetSlice(SQLiteDataReader dr, string? NameId = default)
//{//созд - 2022, изм - 13.02.2023
//    Slice? outObj = default;
//    string? NameCode = GetNameCode(NameId);
//    if (dr[NameId].GetType().ToString() != "System.DBNull")
//    {
//        if (dr[NameCode].GetType().ToString() != "System.DBNull")
//        {
//            outObj = new Slice { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
//        }
//    }

//    //TraceState(outObj, "GetSlice(...), outObj ");
//    return outObj;
//}

//public static Info? GetInfo(SQLiteDataReader dr, string? NameId = default)
//{//созд - 2022, изм - 13.02.2023
//    Info? outObj = default;
//    string? NameCode = GetNameCode(NameId);
//    if (dr[NameId].GetType().ToString() != "System.DBNull")
//    {
//        if (dr[NameCode].GetType().ToString() != "System.DBNull")
//        {
//            outObj = new Info { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
//        }
//    }

//    //TraceState(outObj, "GetInfo(...), outObj ");
//    return outObj;
//}

//public static Role? GetRole(SQLiteDataReader dr, string? NameId = default)
//{//созд - 2022, изм - 13.02.2023
//    Role? outObj = default;
//    string? NameCode = GetNameCode(NameId);
//    if (dr[NameId].GetType().ToString() != "System.DBNull")
//    {
//        if (dr[NameCode].GetType().ToString() != "System.DBNull")
//        {
//            outObj = new Role { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
//        }
//    }

//    //TraceState(outObj, "GetRole(...), outObj ");
//    return outObj;
//}

//public static Debt? GetDebt(SQLiteDataReader dr, string? NameId = default)
//{//созд - 2022, изм - 13.02.2023
//    Debt? outObj = default;
//    string? NameCode = GetNameCode(NameId);
//    if (dr[NameId].GetType().ToString() != "System.DBNull")
//    {
//        if (dr[NameCode].GetType().ToString() != "System.DBNull")
//        {
//            outObj = new Debt { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
//        }
//    }

//    //TraceState(outObj, "GetDebt(...), outObj ");
//    return outObj;
//}

//public static Geo? GetGeo(SQLiteDataReader dr, string? NameId = default)
//{//созд - 2022, изм - 13.02.2023
//    Geo? outObj = default;
//    string? NameCode = GetNameCode(NameId);
//    if (dr[NameId].GetType().ToString() != "System.DBNull")
//    {
//        if (dr[NameCode].GetType().ToString() != "System.DBNull")
//        {
//            outObj = new Geo { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
//        }
//    }

//    //TraceState(outObj, "GetGeo(...), outObj ");
//    return outObj;
//}

//public static Deal? GetDeal(SQLiteDataReader dr, string? NameId = default)
//{//созд - 2022, изм - 13.02.2023
//    Deal? outObj = default;
//    string? NameCode = GetNameCode(NameId);
//    if (dr[NameId].GetType().ToString() != "System.DBNull")
//    {
//        if (dr[NameCode].GetType().ToString() != "System.DBNull")
//        {
//            outObj = new Deal { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
//        }
//    }

//    //TraceState(outObj, "GetDeal(...), outObj ");
//    return outObj;
//}

//public static Face? GetFace(SQLiteDataReader dr, string? NameId = default)
//{//созд - 2022, изм - 13.02.2023
//    Face? outObj = default;
//    string? NameCode = GetNameCode(NameId);
//    if (dr[NameId].GetType().ToString() != "System.DBNull")
//    {
//        if (dr[NameCode].GetType().ToString() != "System.DBNull")
//        {
//            outObj = new Face { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
//        }
//    }

//    //TraceState(outObj, "GetFace(...), outObj ");
//    return outObj;
//}

//public static Asset? GetAsset(SQLiteDataReader dr, string? NameId = default)
//{//созд - 2022, изм - 13.02.2023
//    Asset? outObj = default;
//    string? NameCode = GetNameCode(NameId);
//    if (dr[NameId].GetType().ToString() != "System.DBNull")
//    {
//        if (dr[NameCode].GetType().ToString() != "System.DBNull")
//        {
//            outObj = new Asset { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
//        }
//    }

//    //TraceState(outObj, "GetAsset(...), outObj ");
//    return outObj;
//}

//public static Process? GetProcess(SQLiteDataReader dr, string? NameId = default)
//{//созд - 2022, изм - 13.02.2023
//    Process? outObj = default;
//    string? NameCode = GetNameCode(NameId);
//    if (dr[NameId].GetType().ToString() != "System.DBNull")
//    {
//        if (dr[NameCode].GetType().ToString() != "System.DBNull")
//        {
//            outObj = new Process { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
//        }
//    }

//    //TraceState(outObj, "GetProcess(...), outObj ");
//    return outObj;
//}

//public static Workbook? GetWorkbook(SQLiteDataReader dr, string? NameId = default)
//{//созд - 2022, изм - 13.02.2023
//    Workbook? outObj = default;
//    string? NameCode = GetNameCode(NameId);
//    if (dr[NameId].GetType().ToString() != "System.DBNull")
//    {
//        if (dr[NameCode].GetType().ToString() != "System.DBNull")
//        {
//            outObj = new Workbook { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
//        }
//    }

//    //TraceState(outObj, "GetWorkbook(...), outObj ");
//    return outObj;
//}

//public static Item? GetItem(SQLiteDataReader dr, string? NameId = default)
//{//созд - 2022, изм - 13.02.2023
//    Item? outObj = default;
//    string? NameCode = GetNameCode(NameId);
//    if (dr[NameId].GetType().ToString() != "System.DBNull")
//    {
//        if (dr[NameCode].GetType().ToString() != "System.DBNull")
//        {
//            outObj = new Item { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
//        }
//    }

//    //TraceState(outObj, "GetItem(...), outObj ");
//    return outObj;
//}

//public static Meter? GetMeter(SQLiteDataReader dr, string? NameId = default)
//{//созд - 2022, изм - 13.02.2023
//    Meter? outObj = default;
//    string? NameCode = GetNameCode(NameId);
//    if (dr[NameId].GetType().ToString() != "System.DBNull")
//    {
//        if (dr[NameCode].GetType().ToString() != "System.DBNull")
//        {
//            outObj = new Meter { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
//        }
//    }

//    //TraceState(outObj, "GetMeter(...), outObj ");
//    return outObj;
//}

//public static Price? GetPrice(SQLiteDataReader dr, string? NameId = default)
//{//созд - 2022, изм - 13.02.2023
//    Price? outObj = default;
//    string? NameCode = GetNameCode(NameId);
//    if (dr[NameId].GetType().ToString() != "System.DBNull")
//    {
//        if (dr[NameCode].GetType().ToString() != "System.DBNull")
//        {
//            outObj = new Price { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
//        }
//    }

//    //TraceState(outObj, "GetPrice(...), outObj ");
//    return outObj;
//}

//public static DateTime? GetDate1(SQLiteDataReader dr)
//{//созд - 2022, изм - 13.02.2023
//    DateTime? outObj = default;
//    if (dr["Date1"].GetType().ToString() != "System.DBNull")
//    {
//        outObj = (DateTime)dr["Date1"];
//    }

//    //TraceState(outObj, "GetData1(...), outObj ");
//    return outObj;
//}

//public static List<string>? ListBaseEmergency = new() //список баз на экземпляре МС СКЛ,  если из внешнего файла Connection ничего не поступило
//{//созд - 2022, изм - 2022
//    @"BaseN1",
//    @"BaseN2",
//    @"BaseN3",
//};
//public static List<string>? ListDataSourceEmergency = new() //DataSource для учетных баз, если из внешнего файла Connection ничего не поступило 
//{//созд - 2022, изм - 07.08.2022
//    @".\SQLEXPRESS",
//    @"(local)",
//};

//public static string FormatTraceItem(Shell? TraceItem)
//{//созд - 2022, изм - 27.07.2022
//    string outStrTraceItem = "";
//    //outStrTraceItem += TraceItem?.Code + ", " + TraceItem?.Description;
//    outStrTraceItem += TraceItem?.Description + ", " + TraceItem?.Code;
//    outStrTraceItem += Environment.NewLine;
//    return outStrTraceItem;
//}

//public static void AddTraceTime()
//{//созд - 2022, изм - 2022
//    if (StartTestTime != DateTimeOffset.MinValue)
//    {
//        if (FinishTestTime != DateTimeOffset.MinValue)
//        {
//            TraceState(StartTestTime, "Main, Program, StartTestTime ");
//            TraceState(FinishTestTime, "Main, Program, FinishTestTime ");
//            //SpanTestTime = (TimeSpan)(FinishTestTime - StartTestTime);
//            SpanTestTime = (TimeSpan)GetSpanTime(FinishTestTime, StartTestTime);
//            //TraceState((uint)SpanTestTime.Seconds, "Main, Program, SpanTestTime, sec. ");
//            TraceState(SpanTestTime, "Main, Program, SpanTestTime, sec. ");
//        }
//    }
//}

//{//созд - 2022, изм - 26.07.2022

//public static Abc? GetAbc(List<Abc>? inAbc, string? templateCode = null, string? templateDescription = null, string? templateMore = null)  //TODO - получение единичного Abc  ???   
//{//созд - 2022, изм - 24.07.2022
//    Abc outAbc = new();
//    if ((templateCode is not null) || (templateDescription is not null) || (templateMore is not null))
//    {
//        if (templateCode is not null)//если ищем в списке Авс элемент по совпадению Code 
//        {
//            templateCode = templateCode.Trim();
//            IEnumerable<Abc> subset = from g in inAbc let code = g.Code where code.Contains(templateCode) select g;
//            foreach (var s in subset)
//            {
//                outAbc = s;
//            }
//        }
//        if (templateDescription is not null)//если ищем в списке Авс элемент по совпадению Description 
//        {
//            templateDescription = templateDescription.Trim();
//            IEnumerable<Abc> subset = from g in inAbc let code = g.Code where code.Contains(templateDescription) select g;
//            foreach (var s in subset)
//            {
//                outAbc = s;
//            }
//        }
//        if (templateMore is not null)//если ищем в списке Авс элемент по совпадению More 
//        {
//            templateMore = templateMore.Trim();
//            IEnumerable<Abc> subset = from g in inAbc let code = g.Code where code.Contains(templateMore) select g;
//            foreach (var s in subset)
//            {
//                outAbc = s;
//            }
//        }
//    }

//    //TraceState(outAbc, "GetABC(...), outAbc");
//    return outAbc;
//}

//string? strTable = "Account";
//string? templMore;
//templMore = "'%" + strTable + ".Basic%'";//компонуем строку фильтра More для запроса типа "'%Account.Basic%'"
//List<Shell> AccountBasic = GetTable(conn: MainConnCurr, strTable, templateMore:templMore);
//TraceState(AccountBasic.Count, "Program.Test(...), AccountBasic");

//templMore = "'%" + strTable + ".Catalog%'";
//List<Shell> AccountCatalog = GetTable(conn: MainConnCurr, strTable, templateMore: templMore);
//TraceState(AccountCatalog.Count, "Program.Test(...), AccountCatalog");

//public static List<Abc>? GetAbcTable(SqlConnection conn, string strTable)//отбор Abc по принципу - это все строки таблицы с More = basic, в 1-м экземпляре, хотя та же строка может быть и други типом Abc, например, switch
//{//созд - 2022, изм - 18.07.2022
//    string? templMore = "'%" + strTable + ".Basic%'";//компонуем строку фильтра More для запроса типа "'%Account.Basic%'"
//    //templMore = "'%" + strTable + ".table%'";//например, для проверки, для Account/Table = 2
//    List<Shell>?  ListShell = GetTable(conn, strTable, templateMore: templMore);
//    List<Abc>? outAbc = new();
//    foreach (Shell? shl in ListShell)
//    {
//        outAbc.Add(new Abc { Id = shl.Id, Parent = shl.Parent, Date1 = shl.Date1, Date2 = shl.Date2, Code = shl.Code, Description = shl.Description, More = shl.More });
//    }
//    //TraceState(ListShell.Count + "/" + strTable.ToString() + "/" +templMore, "GetAbcTable(...), ListShell.Count / strTable / templateMore");
//    //TraceState(outAbc.Count, "GetAbcTable(...), outAbc");
//    return outAbc;
//}

//public Abc(int? id = default, Abc? parent = default, DateTimeOffset? date1 = default, string? date2 = default, string? code = default, string? description = default, string? more = default)
//{
//    Id = id;
//    Parent = parent;
//    Code = code;
//    Date1 = date1;
//    Date2 = date2;
//    Description = description;
//    More = more;
//}

//public static void GetAbcDb()
//{//созд - 2022, изм - 24.07.2022
//    //TODO --- потом как-нибудь может быть сделать что-то типа делегата, энуменатора, указание на метод в зависимости от наим-я таблицы
//    Account.Abc = GetAbcTable(conn: MainConnCurr, "Account");
//    TraceState(Account.Abc?.Count(), "Abc.GetAbcDb(...), Account.Abc?.Count() ");
//    //Account.Root = (Account?)GetRoot(GetAbc(Account.Abc, templateCode: "Account"));
//    //TraceState(Account.Root, "Abc.GetAbcDb(...), Account.Root ");

//    Asset.Abc = GetAbcTable(conn: MainConnCurr, "Asset");
//    TraceState(Asset.Abc?.Count(), "Abc.GetAbcDb(...), Asset.Abc?.Count() ");
//}

//public static void GetRootDb()
//{
//    Account.Root = (Account?)GetRoot(GetAbc(Account.Abc, templateCode: "Account"));
//    TraceState(Account.Root?.ToString(), "Abc.GetRootDb(...), Account.Root ");

//    Asset.Root = (Asset?)GetRoot(GetAbc(Asset.Abc, templateCode: "Asset"));
//    TraceState(Asset.Root?.ToString(), "Abc.GetRootDb(...), Asset.Root ");
//}

//public static Shell? GetRoot(Abc? inAbc)
//{//созд - 2022, изм - 24.07.2022
//    Shell? outRoot = new()
//    {
//        Id = inAbc?.Id,
//        Parent = null,  //родителя у элемента Root нет
//        Date1 = inAbc?.Date1,
//        Date2 = inAbc?.Date2,
//        Code = inAbc?.Code,
//        Description = inAbc?.Description,
//        More = inAbc?.More,
//    };
//    return outRoot;
//}

//сериализация JSON
//..https://metanit.com/sharp/tutorial/6.5.php

//public int? Id { get; set; }
//public Shell? Parent { get; set; }
//private DateTimeOffset? date1;
//public DateTimeOffset? Date1
//{
//    get => date1;
//    set => date1 = FixDate(value);
//}
//private string? date2;
//public string? Date2
//{
//    get => date2;
//    set => date2 = FixTrim(value);
//}
//private string? code;
//public string? Code
//{
//    get => code;
//    set => code = FixTrim(value);
//}
//private string? description;
//public string? Description
//{
//    get => description;
//    set => description = FixTrim(value);
//}
//private string? more;
//public string? More
//{
//    get => more;
//    set => more = FixTrim(value);
//}

//static Account()
//{
//    //CurrentTable = Basic[key: "AccTable2019"];  ////TODO - надо как-то 
//}

//public static Account? FixParent(Account? inParent = default) //комм - 07.07.2022
//{
//    //Account? outParent = inParent ?? new Account { };
//    Account? outParent = inParent ?? Account.Root;

//    //TraceState(outParent, "Account.FixParent(...), FixParent.outParent ");
//    return outParent;
//}

//public StringBuilder SwiftOPV(Workbook? WorkbookSalary = default)
//{//созд - 2021
//    StringBuilder TextSwift = new();
//    Exchange SwiftOPV = Basic[key: "Role.Exchange.SwiftOPV"];
//    SwiftOPV.TargetFile = @"Swift_OPV.txt";
//    SwiftOPV.TargetExchange = GetTargetExchangeValue(TargetPath, TargetFile);
//    TODO - выгрузка свифт файла для ОПВ

//    TraceState(TextSwift, "SwiftOPV(...), TextSwift ");
//    return TextSwift;
//}

////IEnumerable<Account> subset = from g in ListTable where g.More.Contains("basic") orderby g select g;
//IEnumerable<Account> subset = from g in ListTable select g;
//var subset = from g in ListTable select g;
//foreach (var s in ListTable)
//{
//    Console.WriteLine($"ListTable.Key:{s.Key}, ListTable.Value:{s.Value}");
//    Console.ReadLine();
//}

//static Price()
//{
//    Markup.Add("Price.MarkupBasic", Price.Basic[key: "Price.MarkupBasic"]);
//    Sale.Add("Price.SaleBasic", Price.Basic[key: "Price.SaleBasic"]);
//}

//public string? FixDescription(string? inDescr = "")
//{
//    string? FixDescr = inDescr?.Trim() ?? "";

//    //TraceState(FixDescr, "Shell.FixDescription(...), FixDescr ");
//    return FixDescr;
//}
//public string? FixCode(string? inCode = "")
//{
//    string? FixCode = inCode?.Trim() ?? "";

//    //TraceState(FixCode, "Shell.FixCode(...), FixCode ");
//    return FixCode;
//}

//public static void FromClipboardToStringForBasic()
//{
//    //запрашиваем блок строк с переносами, вводимый из буфера обмена
//    //делаем из этой строки массив с кавычками по 5 элементов  
//    //это нужно для быстрого импорта строк в ctor static basic-поля из XLS-файлов
//    var DataObject = Clipboard.GetDataObject();
//    if (DataObject.ToString().Length == 0) return;
//    string text = DataObject.GetData("UnicodeText", true).ToString();
//    string[] Arr = text.Split(new[] { '\n' }, System.StringSplitOptions.RemoveEmptyEntries);
//    string StrToClipboard = "";
//    int Count = 0;
//    foreach (string tmpArr in Arr)
//    {
//        Count++;
//        StrToClipboard += "\"" + tmpArr.Trim() + "\"" + ",";
//        if (Count % 5 == 0)
//        {
//            StrToClipboard += Environment.NewLine;
//        }
//    }
//    if (Count != 0)
//    {
//        Clipboard.SetText(StrToClipboard);
//    }
//}

//public static void Test()
//{//созд - 13.07.2022, изм - 17.07.2022
//    StartTestTime = DateTimeOffset.Now;
//    GetTable(MainConnCurr, "Account");
//    GetTable(MainConnCurr, "Account", templateDescription: "'%налог%'", templateMore: "'%Account.Catalog%'");
//    GetTable(MainConnCurr, "Account", templateMore: "'%Account.Basic%'");

//    GetTableDb(conn: MainConnCurr);
//    GetAbcTable(conn: MainConnCurr, "Account");
//    TestAccount();

//    FinishTestTime = DateTimeOffset.Now;
//    ListDataSource = GetListDataSource();
//    ListConnCurr = GetListConnCurr();
//    TraceState(MainConnCurr.DataSource.ToString(), "Program(...), MainConnCurr.ToString()");

//    TraceState(Exchange.Basic["Role.Exchange.SwiftOPV"], "Exchange.Basic[Role.Exchange.SwiftOPV]");
//    Exchange? exc = new();
//    TraceState(exc, "Exchange.exc");
//    StringBuilder sb = new();
//    sb = exc.SwiftOPV(null);
//}