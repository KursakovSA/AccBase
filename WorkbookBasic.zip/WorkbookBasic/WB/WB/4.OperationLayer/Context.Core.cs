﻿namespace WB;
[Serializable]
public partial class Context
{//созд - 17.07.2022, изм - 19.06.2023
    public static bool IsDev;
    public static string? StartDirectory;
    public static string? LastSaveDirectory;
    public static string? LastSelectFileDirectory;
    public static void GetDirectory()
    {//созд - 2022, изм - 19.06.2023
        StartDirectory = Environment.CurrentDirectory;
        LastSaveDirectory = StartDirectory;
        LastSelectFileDirectory = StartDirectory;

        //TraceState(StartDirectory, "GetDirectory(...), StartDirectory ");
        //TraceState(LastSaveDirectory, "GetDirectory(...), LastSaveDirectory ");
        //TraceState(LastSelectFileDirectory, "GetDirectory(...), LastSelectFileDirectory ");
    }
    public Context() { }
    static Context() { }
}