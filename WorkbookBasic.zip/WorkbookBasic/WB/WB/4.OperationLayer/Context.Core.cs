﻿namespace WB;
[Serializable]
public partial class Context
{//созд - 17.07.2022, изм - 01.07.2023
    public static bool IsTrace { get; set; }
    public static string? StartDirectory { get; set; }
    public static string? LastSaveDirectory { get; set; }
    public static string? LastSelectFileDirectory { get; set; }
    public Context() { }
    static Context()
    {//созд - 2022, изм - 29.06.2023
        StartDirectory = Environment.CurrentDirectory;
        LastSaveDirectory = StartDirectory;
        LastSelectFileDirectory = StartDirectory;
    }
}