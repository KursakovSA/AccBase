﻿namespace WB;
[Serializable]
public partial class Trace
{//созд - 2022, изм - 05.01.2023
    public static int EventCounter = 0;
    public static List<string>? TraceList = new();
    public static string? TraceState(object? Obj, string? ContextObj)
    {//созд - 2021, изм - 05.01.2023
        string? outTraceStateAdd = "";  //добавка к полному листингу Trace
        if (IsDev)
        {
            EventCounter++;
            outTraceStateAdd = "#" + EventCounter.ToString() + ", " + DateTimeOffset.Now.ToString() + ", " + Obj?.ToString() + ", " + ContextObj?.ToString();
            TraceList?.Add(outTraceStateAdd);  //полный листинг Trace
        }
        return outTraceStateAdd;
    }
    static Trace()
    {//созд - 2022, изм - 05.01.2023
        //static ctor не может содержать ничего, кроме присваивания простых значений
    }
    public Trace() { }
    public static string TraceListToString(List<string>? inTraceList)
    {//созд - 22.12.2022, изм - 22.12.2022
        string outTraceListString = "";
        if (inTraceList != null)
        {
            foreach (var trLst in inTraceList)
            {
                outTraceListString = outTraceListString + trLst.ToString() + Environment.NewLine;
            }
        }
        return outTraceListString;
    }
    public override string ToString()
    {
        return TraceListToString(TraceList);
    }
}