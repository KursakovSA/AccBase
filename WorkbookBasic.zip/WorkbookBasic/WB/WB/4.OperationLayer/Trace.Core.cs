﻿namespace WB;
[Serializable]
public static partial class Trace
{//созд - 2022, изм - 03.07.2023
    public static int EventCounter { get; set; }
    public static List<(int EventCounterTrace, DateTime DateTrace, object ObjTrace, string ContextTrace)> TraceList { get; set; }
    public static string TraceListLog { get; set; }
    public static string TraceState(object Obj, string ContextObj)
    {//созд - 2021, изм - 01.07.2023
        string outTraceState = "";
        if (IsTrace)
        {
            EventCounter++;
            outTraceState = "[#" + EventCounter.ToString() + "] (" + DateTime.Now.ToString() + "), " + Obj.ToString() + ", " + ContextObj.ToString();
            TraceList.Add((EventCounter, DateTime.Now, Obj, ContextObj));  //полный листинг Trace
            TraceListLog = TraceListLog + outTraceState + Environment.NewLine;
        }
        return outTraceState;
    }
    static Trace()
    {//созд - 2022, изм - 29.06.2023
        //static ctor не может содержать ничего, кроме присваивания простых значений
        EventCounter = 0;
        TraceList = new();
        TraceListLog = "";
    }
}