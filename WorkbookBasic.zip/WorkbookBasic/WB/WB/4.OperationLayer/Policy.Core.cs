﻿namespace WB;
[Serializable]
public partial class Policy
{//созд - 2021, изм - 2022
    public static bool HasPolicyRole()  //есть ли вообще такая политика в Role     
    {//созд - 2021
        bool outHasPolicyRole = false;  //изначально считаем, что политики нет  
        return outHasPolicyRole;
    }
    public static bool HasPolicyWorkbook()  //есть ли вообще такая политика в Workbook  
    {
        bool outHasPolicyWorkbook = false;  //изначально считаем, что политики нет 
        return outHasPolicyWorkbook;
    }
    public static bool CheckPolicy()  //проконтролировать соблюдение политики  
    {//созд - 2021
        bool outCheckPolicy = true;    //изначально считаем, что политика соблюдается   
        return outCheckPolicy;
    }
    static Policy() { }
    public Policy() { }
}