﻿namespace WB;
[Serializable]
public class NotValidPriceException : ApplicationException
{//созд - 2021, изм - 2022
    public decimal? GetPriceException(string? inPrice)
    {
        decimal? Price = default;
        try { }
        catch (NotValidPriceException e) { Console.WriteLine(e); }
        catch (Exception e) { Console.WriteLine(e); }
        finally { };
        return Price;
    }
}
