﻿namespace WB;
[Serializable]
public partial class DealDTO : ShellDTO //data transfer object
{//созд - 11.06.2023, изм - 11.06.2023
    public string? Face1 { get; set; }
    public string? Face2 { get; set; }
    public string? Face { get; set; }
    public string? Geo { get; set; }
    public string? Role { get; set; }
    public string? Info { get; set; }
    public DealDTO(string? id = default, string? parent = default, string? face1 = default, string? face2 = default, string? face = default, string? date1 = default, string? date2 = default, string? code = default, string? description = default, string? more = default, string? role = default, string? geo = default, string? info = default)
    {//созд - 11.06.2023, изм - 11.06.2023
        //public ctor не может содержать ничего, кроме присваивания простых значений
        Id = id;
        Parent = parent;
        Face1 = face1;
        Face2 = face2;
        Face = face;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        Geo = geo;
        Role = role;
        Info = info;
        More = more;
    }
    static DealDTO() { }
    public override string ToString()
    {//созд - 11.06.2023, изм - 11.06.2023
        return $"{GetType()}, {Id?.ToString() ?? "No Id"}, {Parent?.ToString() ?? "No Parent"}, {Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"}";
    }
}