﻿namespace WB;
[Serializable]
public class ShellDTO //data transfer object
{//созд - 11.06.2023, изм - 11.06.2023
    public string? Id { get; set; }
    public string? Parent { get; set; }
    public string? Date1 { get; set; }
    public string? Date2 { get; set; }
    public string? Code { get; set; }
    public string? Description { get; set; }
    public string? More { get; set; }
    public ShellDTO(string? id = default, string? parent = default, string? date1 = default, string? date2 = default, string? code = default, string? description = default, string? more = default)
    {//созд - 11.06.2023, изм - 11.06.2023
        //public ctor не может содержать ничего, кроме присваивания простых значений
        Id = id;
        Parent = parent;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        More = more;
    }
    static ShellDTO() { }
    public override string ToString()
    {//созд - 11.06.2023, изм - 11.06.2023
        return $"{GetType()}, {Id?.ToString() ?? "No Id"}, {Parent?.ToString() ?? "No Parent"}, {Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"}";
    }
}