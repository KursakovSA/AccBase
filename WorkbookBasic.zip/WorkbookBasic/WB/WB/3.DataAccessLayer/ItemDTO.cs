﻿namespace WB;
[Serializable]
public partial class ItemDTO : ShellDTO //data transfer object
{//созд - 11.06.2023, изм - 11.06.2023
    public ItemDTO(string? id = default, string? parent = default, string? date1 = default, string? date2 = default, string? code = default, string? description = default, string? more = default)
    {//созд - 11.06.2023, изм - 11.06.2023
        //public ctor не может содержать ничего, кроме присваивания простых значений
        Id = id;
        Parent = parent;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        More = more;
    }
    static ItemDTO() { }
    public override string ToString()
    {//созд - 11.06.2023, изм - 11.06.2023
        return $"{GetType()}, {Id?.ToString() ?? "No Id"}, {Parent?.ToString() ?? "No Parent"}, {Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"}";
    }
}