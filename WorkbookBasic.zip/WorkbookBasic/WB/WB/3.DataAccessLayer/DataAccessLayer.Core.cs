﻿namespace WB;
[Serializable]
public partial class DataAccessLayer
{//созд - 2022, изм - 13.02.2023
    public static bool GetTableDb(SQLiteConnection conn)
    {//созд - 07.07.2022, изм - 13.02.2023
        //получаем все таблицы БД поочередно
        List<Shell> ListRecord = new();
        bool TestGetListTableIsPassed = false;
        int countFillTable = 0;
        foreach (var strTable in ListBaseTableExpected)
        {
            ListRecord = GetTable(conn, strTable);
            if (ListRecord.Count > 0)
            {
                countFillTable++;
                ListRecord.Clear();
            }
        }
        if (countFillTable == ListBaseTableExpected.Count)//заполненных таблиц должно быть столько же, сколько и всего таблиц
        {
            TestGetListTableIsPassed = true;
        }

        TraceState(countFillTable.ToString()+"/"+ TestGetListTableIsPassed.ToString(), "GetTableDb(...), countFillTable / TestGetListTableIsPassed");
        return TestGetListTableIsPassed;
    }
    public static List<Shell> GetTable(SQLiteConnection conn, string table, string? templateCode = null, string? templateDescription = null, string? templateMore = null)
    {//созд - 2022, изм - 13.02.2023
        List<Shell> outListTable = new();
        table = GetTableViewNameQuery(table);    //на всякий случай преобразуем что-либо типа "Account" в "AccountList"
        string? qrySql = BuildQrySqlSelectTable(table, templateCode: templateCode, templateDescription: templateDescription, templateMore: templateMore);
        try
        {
            SQLiteCommand sqlComm = new SQLiteCommand(qrySql, conn);
            conn.Open();
            using (SQLiteDataReader DataReader = sqlComm.ExecuteReader())
            {
                if (DataReader.HasRows)
                {
                    while (DataReader.Read())
                    {
                        AddListTable(table, outListTable, DataReader);
                    }
                }
                DataReader.Close();
            }
            conn.Close();
        }
        catch (Exception ex)
        {
            _ = ex.Message;
            TraceState(table.ToString() + " / " + ex.Message, "GetTable(...), ex.Message ");
        }
        finally { }

        //TraceState(outListTable.Count, "GetTable(...), outListTable.Count " + table.ToString());
        return outListTable;
    }
    public static void AddListTable(string tbl, List<Shell> lstTbl, SQLiteDataReader dr)
    {//созд - 2022, изм - 13.02.2023
        //TODO --- потом как-нибудь может быть сделать что-то типа делегата, энуменатора, указание на метод в зависимости от наим-я таблицы
        switch (tbl)
        {
            case ("AccountList"):
                lstTbl.Add(NewAccount(dr));
                break;
            case ("AssetList"):
                lstTbl.Add(NewAsset(dr));
                break;
            case ("DealList"):
                lstTbl.Add(NewDeal(dr));
                break;
            case ("GeoList"):
                lstTbl.Add(NewGeo(dr));
                break;
            case ("InfoList"):
                lstTbl.Add(NewInfo(dr));
                break;
            case ("ItemList"):
                lstTbl.Add(NewItem(dr));
                break;
            case ("FaceList"):
                lstTbl.Add(NewFace(dr));
                break;
            case ("MarkList"):
                lstTbl.Add(NewMark(dr));
                break;
            case ("SliceList"):
                lstTbl.Add(NewSlice(dr));
                break;
            case ("SignList"):
                lstTbl.Add(NewSign(dr));
                break;
            case ("MeterList"):
                lstTbl.Add(NewMeter(dr));
                break;
            case ("RoleList"):
                lstTbl.Add(NewRole(dr));
                break;
            case ("PriceList"):
                lstTbl.Add(NewPrice(dr));
                break;
            case ("UnitList"):
                lstTbl.Add(NewUnit(dr));
                break;
            case ("DebtList"):
                lstTbl.Add(NewDebt(dr));
                break;
            case ("ProcessList"):
                lstTbl.Add(NewProcess(dr));
                break;
            case ("WorkbookList"):
                lstTbl.Add(NewWorkbook(dr));
                break;
            default:
                break;
        }
    }
    public static WorkbookDTO NewWorkbookDTO(SQLiteDataReader dr)
    {//созд - 11.06.2023, изм - 12.06.2023
        return new WorkbookDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Face1 = GetSimpleString(dr, "Face1"),
            Face2 = GetSimpleString(dr, "Face2"),
            Face = GetSimpleString(dr, "Face"),
            Slice = GetSimpleString(dr, "Slice"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Geo = GetSimpleString(dr, "Geo"),
            Sign = GetSimpleString(dr, "Sign"),
            Account = GetSimpleString(dr, "Account"),
            Process = GetSimpleString(dr, "Process"),
            Asset = GetSimpleString(dr, "Asset"),
            Deal = GetSimpleString(dr, "Deal"),
            Item = GetSimpleString(dr, "Item"),
            Debt = GetSimpleString(dr, "Debt"),
            Price = GetSimpleString(dr, "Price"),
            Role = GetSimpleString(dr, "Role"),
            Info = GetSimpleString(dr, "Info"),
            Meter = GetSimpleString(dr, "Meter"),
            MeterValue = GetSimpleString(dr, "MeterValue"),
            Unit = GetSimpleString(dr, "Unit"),
            More = GetSimpleString(dr, "More"),
            Mark = GetSimpleString(dr, "Mark"),
        };
    }
    public static Workbook NewWorkbook(SQLiteDataReader dr)
    {//созд - 2022, изм - 13.02.2023
        return new Workbook
        {
            Id = GetId(dr),
            Parent = GetWorkbook(dr, "Parent"),
            Face1 = GetFace(dr, "Face1"),
            Face2 = GetFace(dr, "Face2"),
            Face = GetFace(dr, "Face"),
            Slice = GetSlice(dr, "Slice"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Geo = GetGeo(dr, "Geo"),
            Sign = GetSign(dr, "Sign"),
            Account = GetAccount(dr, "Account"),
            Process = GetProcess(dr, "Process"),
            Asset = GetAsset(dr, "Asset"),
            Deal = GetDeal(dr, "Deal"),
            Item = GetItem(dr, "Item"),
            Debt = GetDebt(dr, "Debt"),
            Price = GetPrice(dr, "Price"),
            Role = GetRole(dr, "Role"),
            Info = GetInfo(dr, "Info"),
            Meter = GetMeter(dr, "Meter"),
            MeterValue = GetSimpleString(dr, "MeterValue"),
            Unit = GetUnit(dr, "Unit"),
            More = GetSimpleString(dr, "More"),
            Mark = GetMark(dr, "Mark"),
        };
    }
    public static ProcessDTO NewProcessDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 12.06.2023
        return new ProcessDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Face1 = GetSimpleString(dr, "Face1"),
            Face2 = GetSimpleString(dr, "Face2"),
            Face = GetSimpleString(dr, "Face"),
            Slice = GetSimpleString(dr, "Slice"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Geo = GetSimpleString(dr, "Geo"),
            Sign = GetSimpleString(dr, "Sign"),
            Account = GetSimpleString(dr, "Account"),
            Asset = GetSimpleString(dr, "Asset"),
            Deal = GetSimpleString(dr, "Deal"),
            Item = GetSimpleString(dr, "Item"),
            Debt = GetSimpleString(dr, "Debt"),
            Price = GetSimpleString(dr, "Price"),
            Role = GetSimpleString(dr, "Role"),
            Info = GetSimpleString(dr, "Info"),
            Meter = GetSimpleString(dr, "Meter"),
            MeterValue = GetSimpleString(dr, "MeterValue"),
            Unit = GetSimpleString(dr, "Unit"),
            More = GetSimpleString(dr, "More"),
            Mark = GetSimpleString(dr, "Mark"),
        };
    }
    public static Process NewProcess(SQLiteDataReader dr)
    {//созд - 2022, изм - 3.06.2023
        return new Process
        {
            Id = GetId(dr),
            Parent = GetProcess(dr, "Parent"),
            Face1 = GetFace(dr, "Face1"),
            Face2 = GetFace(dr, "Face2"),
            Face = GetFace(dr, "Face"),
            Slice = GetSlice(dr, "Slice"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Geo = GetGeo(dr, "Geo"),
            Sign = GetSign(dr, "Sign"),
            Account = GetAccount(dr, "Account"),
            Asset = GetAsset(dr, "Asset"),
            Deal = GetDeal(dr, "Deal"),
            Item = GetItem(dr, "Item"),
            Debt = GetDebt(dr, "Debt"),
            Price = GetPrice(dr, "Price"),
            Role = GetRole(dr, "Role"),
            Info = GetInfo(dr, "Info"),
            Meter = GetMeter(dr, "Meter"),
            MeterValue = GetSimpleString(dr, "MeterValue"),
            Unit = GetUnit(dr, "Unit"),
            More = GetSimpleString(dr, "More"),
            Mark = GetMark(dr, "Mark"),
        };
    }
    public static DebtDTO NewDebtDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 12.06.2023
        return new DebtDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Geo = GetSimpleString(dr, "Geo"),
            Role = GetSimpleString(dr, "Role"),
            Info = GetSimpleString(dr, "Info"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Debt NewDebt(SQLiteDataReader dr)
    {//созд - 2022, изм - 13.02.2023
        return new Debt
        {
            Id = GetId(dr),
            Parent = GetDebt(dr, "Parent"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Geo = GetGeo(dr, "Geo"),
            Role = GetRole(dr, "Role"),
            Info = GetInfo(dr, "Info"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static UnitDTO NewUnitDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 12.06.2023
        return new UnitDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Role = GetSimpleString(dr, "Role"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Unit NewUnit(SQLiteDataReader dr)
    {//созд - 2022, изм - 13.02.2023
        return new Unit
        {
            Id = GetId(dr),
            Parent = GetUnit(dr, "Parent"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Role = GetRole(dr, "Role"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static PriceDTO NewPriceDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 12.06.2023
        return new PriceDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Role = GetSimpleString(dr, "Role"),
            Info = GetSimpleString(dr, "Info"),
            Unit = GetSimpleString(dr, "Unit"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Price NewPrice(SQLiteDataReader dr)
    {//созд - 2022, изм - 13.02.2023
        return new Price
        {
            Id = GetId(dr),
            Parent = GetPrice(dr, "Parent"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Role = GetRole(dr, "Role"),
            Info = GetInfo(dr, "Info"),
            Unit = GetUnit(dr, "Unit"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static RoleDTO NewRoleDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 12.06.2023
        return new RoleDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Role NewRole(SQLiteDataReader dr)
    {//созд - 2022, изм - 13.02.2023
        return new Role
        {
            Id = GetId(dr),
            Parent = GetRole(dr, "Parent"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static MeterDTO NewMeterDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 12.06.2023
        return new MeterDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Unit = GetSimpleString(dr, "Unit"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Meter NewMeter(SQLiteDataReader dr)
    {//созд - 2022, изм - 13.02.2023
        return new Meter
        {
            Id = GetId(dr),
            Parent = GetMeter(dr, "Parent"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Unit = GetUnit(dr, "Unit"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static SignDTO NewSignDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 12.06.2023
        return new SignDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Sign NewSign(SQLiteDataReader dr)
    {//созд - 2022, изм - 13.02.2023
        return new Sign
        {
            Id = GetId(dr),
            Parent = GetSign(dr, "Parent"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static SliceDTO NewSliceDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 12.06.2023
        return new SliceDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Slice NewSlice(SQLiteDataReader dr)
    {//созд - 2022, изм - 13.02.2023
        return new Slice
        {
            Id = GetId(dr),
            Parent = GetSlice(dr, "Parent"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static MarkDTO NewMarkDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 12.06.2023
        return new MarkDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Mark NewMark(SQLiteDataReader dr)
    {//созд - 2022, изм - 13.02.2023
        return new Mark
        {
            Id = GetId(dr),
            Parent = GetMark(dr, "Parent"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static FaceDTO NewFaceDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 12.06.2023
        return new FaceDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Geo = GetSimpleString(dr, "Geo"),
            Role = GetSimpleString(dr, "Role"),
            Info = GetSimpleString(dr, "Info"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Face NewFace(SQLiteDataReader dr)
    {//созд - 2022, изм - 13.02.2023
        return new Face
        {
            Id = GetId(dr),
            Parent = GetFace(dr, "Parent"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Geo = GetGeo(dr, "Geo"),
            Role = GetRole(dr, "Role"),
            Info = GetInfo(dr, "Info"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static ItemDTO NewItemDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 12.06.2023
        return new ItemDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Item NewItem(SQLiteDataReader dr)
    {//созд - 2022, изм - 13.02.2023
        return new Item
        {
            Id = GetId(dr),
            Parent = GetItem(dr, "Parent"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static InfoDTO NewInfoDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 12.06.2023
        return new InfoDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Info NewInfo(SQLiteDataReader dr)
    {//созд - 2022, изм - 13.02.2023
        return new Info
        {
            Id = GetId(dr),
            Parent = GetInfo(dr, "Parent"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static GeoDTO NewGeoDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 12.06.2023
        return new GeoDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Role = GetSimpleString(dr, "Role"),
            Unit = GetSimpleString(dr, "Unit"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Geo NewGeo(SQLiteDataReader dr)
    {//созд - 2022, изм - 13.02.2023
        return new Geo
        {
            Id = GetId(dr),
            Parent = GetGeo(dr, "Parent"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Role = GetRole(dr, "Role"),
            Unit = GetUnit(dr, "Unit"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static DealDTO NewDealDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 12.06.2023
        return new DealDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Face1 = GetSimpleString(dr, "Face1"),
            Face2 = GetSimpleString(dr, "Face2"),
            Face = GetSimpleString(dr, "Face"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Geo = GetSimpleString(dr, "Geo"),
            Role = GetSimpleString(dr, "Role"),
            Info = GetSimpleString(dr, "Info"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Deal NewDeal(SQLiteDataReader dr)
    {//созд - 2022, изм - 13.02.2023
        return new Deal
        {
            Id = GetId(dr),
            Parent = GetDeal(dr, "Parent"),
            Face1 = GetFace(dr, "Face1"),
            Face2 = GetFace(dr, "Face2"),
            Face = GetFace(dr, "Face"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Geo = GetGeo(dr, "Geo"),
            Role = GetRole(dr, "Role"),
            Info = GetInfo(dr, "Info"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static AssetDTO NewAssetDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 12.06.2023
        return new AssetDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Geo = GetSimpleString(dr, "Geo"),
            Role = GetSimpleString(dr, "Role"),
            Info = GetSimpleString(dr, "Info"),
            Unit = GetSimpleString(dr, "Unit"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Asset NewAsset(SQLiteDataReader dr)
    {//созд - 2022, изм - 13.02.2023
        return new Asset
        {
            Id = GetId(dr),
            Parent = GetAsset(dr, "Parent"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Geo = GetGeo(dr, "Geo"),
            Role = GetRole(dr, "Role"),
            Info = GetInfo(dr, "Info"),
            Unit = GetUnit(dr, "Unit"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static AccountDTO NewAccountDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 12.06.2023
        return new AccountDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Slice = GetSimpleString(dr, "Slice"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Role = GetSimpleString(dr, "Role"),
            Sign = GetSimpleString(dr, "Sign"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Account NewAccount(SQLiteDataReader dr)
    {//созд - 2022, изм - 13.02.2023
        return new Account
        {
            Id = GetId(dr),
            Parent = GetAccount(dr, "Parent"),
            Slice = GetSlice(dr, "Slice"),
            Date1 = GetDate1(dr),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Role = GetRole(dr, "Role"),
            Sign = GetSign(dr, "Sign"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static string? GetId(SQLiteDataReader dr)
    {//созд - 2022, изм - 13.02.2023
        string? outObj = default;
        if (dr["Id"].GetType().ToString() != "System.DBNull")
        {
            outObj = (string)dr["Id"];
        }

        //TraceState(outObj, "GetId(...), outObj ");
        return outObj;
    }
    public static Asset? GetAsset(SQLiteDataReader dr, string? NameId = default)
    {//созд - 2022, изм - 13.02.2023
        Asset? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Asset { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetAsset(...), outObj ");
        return outObj;
    }
    public static Face? GetFace(SQLiteDataReader dr, string? NameId = default)
    {//созд - 2022, изм - 13.02.2023
        Face? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Face { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetFace(...), outObj ");
        return outObj;
    }
    public static Deal? GetDeal(SQLiteDataReader dr, string? NameId = default)
    {//созд - 2022, изм - 13.02.2023
        Deal? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Deal { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetDeal(...), outObj ");
        return outObj;
    }
    public static Geo? GetGeo(SQLiteDataReader dr, string? NameId = default)
    {//созд - 2022, изм - 13.02.2023
        Geo? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Geo { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetGeo(...), outObj ");
        return outObj;
    }
    public static Debt? GetDebt(SQLiteDataReader dr, string? NameId = default)
    {//созд - 2022, изм - 13.02.2023
        Debt? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Debt { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetDebt(...), outObj ");
        return outObj;
    }
    public static Price? GetPrice(SQLiteDataReader dr, string? NameId = default)
    {//созд - 2022, изм - 13.02.2023
        Price? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Price { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetPrice(...), outObj ");
        return outObj;
    }
    public static Meter? GetMeter(SQLiteDataReader dr, string? NameId = default)
    {//созд - 2022, изм - 13.02.2023
        Meter? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Meter { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetMeter(...), outObj ");
        return outObj;
    }
    public static Role? GetRole(SQLiteDataReader dr, string? NameId = default)
    {//созд - 2022, изм - 13.02.2023
        Role? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Role { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetRole(...), outObj ");
        return outObj;
    }
    public static Info? GetInfo(SQLiteDataReader dr, string? NameId = default)
    {//созд - 2022, изм - 13.02.2023
        Info? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Info { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetInfo(...), outObj ");
        return outObj;
    }
    public static Item? GetItem(SQLiteDataReader dr, string? NameId = default)
    {//созд - 2022, изм - 13.02.2023
        Item? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Item { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetItem(...), outObj ");
        return outObj;
    }
    public static Slice? GetSlice(SQLiteDataReader dr, string? NameId = default)
    {//созд - 2022, изм - 13.02.2023
        Slice? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Slice { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetSlice(...), outObj ");
        return outObj;
    }
    public static Sign? GetSign(SQLiteDataReader dr, string? NameId = default)
    {//созд - 2022, изм - 13.02.2023
        Sign? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Sign { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetSign(...), outObj ");
        return outObj;
    }
    public static Mark? GetMark(SQLiteDataReader dr, string? NameId = default)
    {//созд - 2022, изм - 13.02.2023
        Mark? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Mark { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetMark(...), outObj ");
        return outObj;
    }
    public static Account? GetAccount(SQLiteDataReader dr, string? NameId = default)
    {//созд - 2022, изм - 13.02.2023
        Account? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Account { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetAccount(...), outObj ");
        return outObj;
    }
    public static Unit? GetUnit(SQLiteDataReader dr, string? NameId = default)
    {//созд - 2022, изм - 13.02.2023
        Unit? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Unit { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetUnit(...), outObj ");
        return outObj;
    }
    public static Workbook? GetWorkbook(SQLiteDataReader dr, string? NameId = default)
    {//созд - 2022, изм - 13.02.2023
        Workbook? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Workbook { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetWorkbook(...), outObj ");
        return outObj;
    }
    public static Process? GetProcess(SQLiteDataReader dr, string? NameId = default)
    {//созд - 2022, изм - 13.02.2023
        Process? outObj = default;
        string? NameCode = GetNameCode(NameId);
        if (dr[NameId].GetType().ToString() != "System.DBNull")
        {
            if (dr[NameCode].GetType().ToString() != "System.DBNull")
            {
                outObj = new Process { Id = (string)dr[NameId], Code = (string)dr[NameCode] };
            }
        }

        //TraceState(outObj, "GetProcess(...), outObj ");
        return outObj;
    }
    public static DateTime? GetDate1(SQLiteDataReader dr)
    {//созд - 2022, изм - 13.02.2023
        DateTime? outObj = default;
        if (dr["Date1"].GetType().ToString() != "System.DBNull")
        {
            outObj = (DateTime)dr["Date1"];
        }

        //TraceState(outObj, "GetData1(...), outObj ");
        return outObj;
    }
    public static string? GetSimpleString(SQLiteDataReader dr, string? NameStr = default)
    {//созд - 2022, 13.02.2023
        string? outObj = default;
        if (dr[NameStr].GetType().ToString() != "System.DBNull")
        {
            outObj = (string)dr[NameStr];
        }

        //TraceState(outObj, "GetSimpleString(...), outObj ");
        return outObj;
    }
    public static string GetTableViewNameQuery(string table)
    {//созд - 2022, изм - 2022
        //получаем из имени таблицы\класса в запросе типа "Account" "чистое" имя представления типа "AccountList"
        string TableViewNameQuery = table.Trim();
        if (table != null)
        {
            TableViewNameQuery = TableViewNameQuery.Replace("List", "");  //сначала удалим суффикс List, вдруг он есть
            TableViewNameQuery += "List";  //добавим суффикс "List" для получения имени представления типа "AccountList"
        }

        //TraceState(table, "GetTableViewNameQuery(...), table ");
        //TraceState(TableViewNameQuery, "GetTableViewNameQuery(...), TableViewNameQuery ");
        return TableViewNameQuery;
    }
    public static string GetTableNameQuery(string tableView)
    {//созд - 2022, изм - 2022
        //получаем из имени таблицы или view в запросе типа "AccountList" "чистое" имя таблицы типа "Account"
        string TableNameQuery = tableView.Trim();
        if (tableView != null)
        {
            TableNameQuery = TableNameQuery.Replace("List", "");
        }

        //TraceState(tableView, "GetTableNameQuery(...), tableView ");
        //TraceState(TableNameQuery, "GetTableNameQuery(...), TableNameQuery ");
        return TableNameQuery;
    }
    public static string? GetNameCode(string? NameId = default)
    {//созд - 2022, изм - 2022
        //получаем из имени Id в запросе типа "Account" имя поля кода типа "AccountCode"
        string? NameCode = default;
        if (NameId != null)
        {
            NameCode = NameId + "Code";
        }

        //TraceState(NameId, "GetNameCode(...), NameId ");
        //TraceState(NameCode, "GetNameCode(...), NameCode");
        return NameCode;
    }
    public DataAccessLayer() { }
    static DataAccessLayer() { }
}
