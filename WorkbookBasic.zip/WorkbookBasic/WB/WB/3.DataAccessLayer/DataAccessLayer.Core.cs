﻿namespace WB;
[Serializable]
public partial class DataAccessLayer
{//созд - 2022, изм - 18.06.2023
    public static bool GetModelDb(SQLiteConnection conn)
    {//созд - 18.06.2023, изм - 18.06.2023
        //получаем все таблицы БД поочередно
        List<Shell> ListRecord = new();
        bool TestGetListTableIsPassed = false;
        int countFillTable = 0;
        foreach (var strTable in ListBaseTableExpected)
        {
            ListRecord = GetModel(conn, strTable);
            if (ListRecord.Count > 0)
            {
                countFillTable++;
                ListRecord.Clear();
            }
        }
        if (countFillTable == ListBaseTableExpected.Count)//заполненных таблиц должно быть столько же, сколько и всего таблиц
        {
            TestGetListTableIsPassed = true;
        }

        TraceState(countFillTable.ToString() + "/" + TestGetListTableIsPassed.ToString(), "GetModelDb(...), countFillTable / TestGetListTableIsPassed");
        return TestGetListTableIsPassed;
    }
    public static bool GetTableDb(SQLiteConnection conn)
    {//созд - 07.07.2022, изм - 18.06.2023
        //получаем все таблицы БД поочередно
        List<ShellDTO> ListRecord = new();
        bool TestGetListTableIsPassed = false;
        int countFillTable = 0;
        foreach (var strTable in ListBaseTableExpected)
        {
            ListRecord = GetTable(conn, strTable);
            if (ListRecord.Count > 0)
            {
                countFillTable++;
                ListRecord.Clear();
            }
        }
        if (countFillTable == ListBaseTableExpected.Count)//заполненных таблиц должно быть столько же, сколько и всего таблиц
        {
            TestGetListTableIsPassed = true;
        }

        TraceState(countFillTable.ToString()+"/"+ TestGetListTableIsPassed.ToString(), "GetTableDb(...), countFillTable / TestGetListTableIsPassed");
        return TestGetListTableIsPassed;
    }
    public static List<Shell> GetModel(SQLiteConnection conn, string table, string? templateCode = null, string? templateDescription = null, string? templateMore = null)
    {//созд - 18.06.2023, изм - 18.06.2023
        List<Shell> outListTable = new();
        table = GetTableViewNameQuery(table);    //на всякий случай преобразуем что-либо типа "Account" в "AccountList"
        string? qrySql = BuildQrySqlSelectTable(table, templateCode: templateCode, templateDescription: templateDescription, templateMore: templateMore);
        try
        {
            SQLiteCommand sqlComm = new SQLiteCommand(qrySql, conn);
            conn.Open();
            using (SQLiteDataReader DataReader = sqlComm.ExecuteReader())
            {
                if (DataReader.HasRows)
                {
                    while (DataReader.Read())
                    {
                        AddListModel(table, outListTable, DataReader);
                    }
                }
                DataReader.Close();
            }
            conn.Close();
        }
        catch (Exception ex)
        {
            _ = ex.Message;
            TraceState(table.ToString() + " / " + ex.Message, "GetModel(...), ex.Message ");
        }
        finally { }

        //TraceState(outListTable.Count, "GetModel(...), outListTable.Count " + table.ToString());
        return outListTable;
    }
    public static List<ShellDTO> GetTable(SQLiteConnection conn, string table, string? templateCode = null, string? templateDescription = null, string? templateMore = null)
    {//созд - 2022, изм - 18.06.2023
        List<ShellDTO> outListTable = new();
        table = GetTableViewNameQuery(table);    //на всякий случай преобразуем что-либо типа "Account" в "AccountList"
        string? qrySql = BuildQrySqlSelectTable(table, templateCode: templateCode, templateDescription: templateDescription, templateMore: templateMore);
        try
        {
            SQLiteCommand sqlComm = new SQLiteCommand(qrySql, conn);
            conn.Open();
            using (SQLiteDataReader DataReader = sqlComm.ExecuteReader())
            {
                if (DataReader.HasRows)
                {
                    while (DataReader.Read())
                    {
                        AddListTable(table, outListTable, DataReader);
                    }
                }
                DataReader.Close();
            }
            conn.Close();
        }
        catch (Exception ex)
        {
            _ = ex.Message;
            TraceState(table.ToString() + " / " + ex.Message, "GetTable(...), ex.Message ");
        }
        finally { }

        //TraceState(outListTable.Count, "GetTable(...), outListTable.Count " + table.ToString());
        return outListTable;
    }
    public static void AddListModel(string tbl, List<Shell> lstTbl, SQLiteDataReader dr)
    {//созд - 18.06.2023, изм - 18.06.2023
        //TODO --- потом как-нибудь может быть сделать что-то типа делегата, энуменатора, указание на метод в зависимости от наим-я таблицы
        switch (tbl)
        {
            case ("AccountList"):
                lstTbl.Add(NewAccount(NewAccountDTO(dr)));
                break;
            case ("AssetList"):
                lstTbl.Add(NewAsset(NewAssetDTO(dr)));
                break;
            case ("DealList"):
                lstTbl.Add(NewDeal(NewDealDTO(dr)));
                break;
            case ("GeoList"):
                lstTbl.Add(NewGeo(NewGeoDTO(dr)));
                break;
            case ("InfoList"):
                lstTbl.Add(NewInfo(NewInfoDTO(dr)));
                break;
            case ("ItemList"):
                lstTbl.Add(NewItem(NewItemDTO(dr)));
                break;
            case ("FaceList"):
                lstTbl.Add(NewFace(NewFaceDTO(dr)));
                break;
            case ("MarkList"):
                lstTbl.Add(NewMark(NewMarkDTO(dr)));
                break;
            case ("SliceList"):
                lstTbl.Add(NewSlice(NewSliceDTO(dr)));
                break;
            case ("SignList"):
                lstTbl.Add(NewSign(NewSignDTO(dr)));
                break;
            case ("MeterList"):
                lstTbl.Add(NewMeter(NewMeterDTO(dr)));
                break;
            case ("RoleList"):
                lstTbl.Add(NewRole(NewRoleDTO(dr)));
                break;
            case ("PriceList"):
                lstTbl.Add(NewPrice(NewPriceDTO(dr)));
                break;
            case ("UnitList"):
                lstTbl.Add(NewUnit(NewUnitDTO(dr)));
                break;
            case ("DebtList"):
                lstTbl.Add(NewDebt(NewDebtDTO(dr)));
                break;
            case ("ProcessList"):
                lstTbl.Add(NewProcess(NewProcessDTO(dr)));
                break;
            case ("WorkbookList"):
                lstTbl.Add(NewWorkbook(NewWorkbookDTO(dr)));
                break;
            default:
                break;
        }
    }
    public static void AddListTable(string tbl, List<ShellDTO> lstTbl, SQLiteDataReader dr)
    {//созд - 2022, изм - 18.06.2023
        //TODO --- потом как-нибудь может быть сделать что-то типа делегата, энуменатора, указание на метод в зависимости от наим-я таблицы
        switch (tbl)
        {
            case ("AccountList"):
                lstTbl.Add(NewAccountDTO(dr));
                break;
            case ("AssetList"):
                lstTbl.Add(NewAssetDTO(dr));
                break;
            case ("DealList"):
                lstTbl.Add(NewDealDTO(dr));
                break;
            case ("GeoList"):
                lstTbl.Add(NewGeoDTO(dr));
                break;
            case ("InfoList"):
                lstTbl.Add(NewInfoDTO(dr));
                break;
            case ("ItemList"):
                lstTbl.Add(NewItemDTO(dr));
                break;
            case ("FaceList"):
                lstTbl.Add(NewFaceDTO(dr));
                break;
            case ("MarkList"):
                lstTbl.Add(NewMarkDTO(dr));
                break;
            case ("SliceList"):
                lstTbl.Add(NewSliceDTO(dr));
                break;
            case ("SignList"):
                lstTbl.Add(NewSignDTO(dr));
                break;
            case ("MeterList"):
                lstTbl.Add(NewMeterDTO(dr));
                break;
            case ("RoleList"):
                lstTbl.Add(NewRoleDTO(dr));
                break;
            case ("PriceList"):
                lstTbl.Add(NewPriceDTO(dr));
                break;
            case ("UnitList"):
                lstTbl.Add(NewUnitDTO(dr));
                break;
            case ("DebtList"):
                lstTbl.Add(NewDebtDTO(dr));
                break;
            case ("ProcessList"):
                lstTbl.Add(NewProcessDTO(dr));
                break;
            case ("WorkbookList"):
                lstTbl.Add(NewWorkbookDTO(dr));
                break;
            default:
                break;
        }
    }
    public static WorkbookDTO NewWorkbookDTO(SQLiteDataReader dr)
    {//созд - 11.06.2023, изм - 18.06.2023
        return new WorkbookDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Face1 = GetSimpleString(dr, "Face1"),
            Face2 = GetSimpleString(dr, "Face2"),
            Face = GetSimpleString(dr, "Face"),
            Slice = GetSimpleString(dr, "Slice"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Geo = GetSimpleString(dr, "Geo"),
            Sign = GetSimpleString(dr, "Sign"),
            Account = GetSimpleString(dr, "Account"),
            Process = GetSimpleString(dr, "Process"),
            Asset = GetSimpleString(dr, "Asset"),
            Deal = GetSimpleString(dr, "Deal"),
            Item = GetSimpleString(dr, "Item"),
            Debt = GetSimpleString(dr, "Debt"),
            Price = GetSimpleString(dr, "Price"),
            Role = GetSimpleString(dr, "Role"),
            Info = GetSimpleString(dr, "Info"),
            Meter = GetSimpleString(dr, "Meter"),
            MeterValue = GetSimpleString(dr, "MeterValue"),
            Unit = GetSimpleString(dr, "Unit"),
            More = GetSimpleString(dr, "More"),
            Mark = GetSimpleString(dr, "Mark"),
        };
    }
    public static Workbook NewWorkbook(WorkbookDTO dtoWorkbook)
    {//созд - 2022, изм - 18.06.2023
        return new Workbook
        {
            Id = dtoWorkbook.Id,
            Parent = new Workbook { Id = dtoWorkbook.Parent },
            Face1 = new Face { Id = dtoWorkbook.Face1 },
            Face2 = new Face { Id = dtoWorkbook.Face2 },
            Face = new Face { Id = dtoWorkbook.Face },
            Slice = new Slice { Id = dtoWorkbook.Slice },
            Date1 = GetDate1(dtoWorkbook.Date1),
            Date2 = GetDate2(dtoWorkbook.Date2),
            Code = dtoWorkbook.Code,
            Description = dtoWorkbook.Description,
            Geo = new Geo { Id = dtoWorkbook.Geo },
            Sign = new Sign { Id = dtoWorkbook.Sign },
            Account = new Account { Id = dtoWorkbook.Account },
            Process = new Process { Id = dtoWorkbook.Process },
            Asset = new Asset { Id = dtoWorkbook.Asset },
            Deal = new Deal { Id = dtoWorkbook.Deal },
            Item = new Item { Id = dtoWorkbook.Item },
            Debt = new Debt { Id = dtoWorkbook.Debt },
            Price = new Price { Id = dtoWorkbook.Price },
            Role = new Role { Id = dtoWorkbook.Role },
            Info = new Info { Id = dtoWorkbook.Info },
            Meter = new Meter { Id = dtoWorkbook.Meter },
            MeterValue = dtoWorkbook.MeterValue,
            Unit = new Unit { Id = dtoWorkbook.Unit },
            More = dtoWorkbook.More,
            Mark = new Mark { Id = dtoWorkbook.Mark },
        };
    }
    public static ProcessDTO NewProcessDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 18.06.2023
        return new ProcessDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Face1 = GetSimpleString(dr, "Face1"),
            Face2 = GetSimpleString(dr, "Face2"),
            Face = GetSimpleString(dr, "Face"),
            Slice = GetSimpleString(dr, "Slice"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Geo = GetSimpleString(dr, "Geo"),
            Sign = GetSimpleString(dr, "Sign"),
            Account = GetSimpleString(dr, "Account"),
            Asset = GetSimpleString(dr, "Asset"),
            Deal = GetSimpleString(dr, "Deal"),
            Item = GetSimpleString(dr, "Item"),
            Debt = GetSimpleString(dr, "Debt"),
            Price = GetSimpleString(dr, "Price"),
            Role = GetSimpleString(dr, "Role"),
            Info = GetSimpleString(dr, "Info"),
            Meter = GetSimpleString(dr, "Meter"),
            MeterValue = GetSimpleString(dr, "MeterValue"),
            Unit = GetSimpleString(dr, "Unit"),
            More = GetSimpleString(dr, "More"),
            Mark = GetSimpleString(dr, "Mark"),
        };
    }
    public static Process NewProcess(ProcessDTO dtoProcess)
    {//созд - 2022, изм - 18.06.2023
        return new Process
        {
            Id = dtoProcess.Id,
            Parent = new Process { Id = dtoProcess.Parent },
            Face1 = new Face { Id = dtoProcess.Face1 },
            Face2 = new Face { Id = dtoProcess.Face2 },
            Face = new Face { Id = dtoProcess.Face },
            Slice = new Slice { Id = dtoProcess.Slice },
            Date1 = GetDate1(dtoProcess.Date1),
            Date2 = GetDate2(dtoProcess.Date2),
            Code = dtoProcess.Code,
            Description = dtoProcess.Description,
            Geo = new Geo { Id = dtoProcess.Geo },
            Sign = new Sign { Id = dtoProcess.Sign },
            Account = new Account { Id = dtoProcess.Account },
            Asset = new Asset { Id = dtoProcess.Asset },
            Deal = new Deal { Id = dtoProcess.Deal },
            Item = new Item { Id = dtoProcess.Item },
            Debt = new Debt { Id = dtoProcess.Debt },
            Price = new Price { Id = dtoProcess.Price },
            Role = new Role { Id = dtoProcess.Role },
            Info = new Info { Id = dtoProcess.Info },
            Meter = new Meter { Id = dtoProcess.Meter },
            MeterValue = dtoProcess.MeterValue,
            Unit = new Unit { Id = dtoProcess.Unit },
            More = dtoProcess.More,
            Mark = new Mark { Id = dtoProcess.Mark },
        };
    }
    public static DebtDTO NewDebtDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 18.06.2023
        return new DebtDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Geo = GetSimpleString(dr, "Geo"),
            Role = GetSimpleString(dr, "Role"),
            Info = GetSimpleString(dr, "Info"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Debt NewDebt(DebtDTO dtoDebt)
    {//созд - 2022, изм - 18.06.2023
        return new Debt
        {
            Id = dtoDebt.Id,
            Parent = new Debt { Id = dtoDebt.Parent },
            Date1 = GetDate1(dtoDebt.Date1),
            Date2 = GetDate2(dtoDebt.Date2),
            Code = dtoDebt.Code,
            Description = dtoDebt.Description,
            Geo = new Geo { Id = dtoDebt.Geo },
            Role = new Role { Id = dtoDebt.Role },
            Info = new Info { Id = dtoDebt.Info },
            More = dtoDebt.More,
        };
    }
    public static UnitDTO NewUnitDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 18.06.2023
        return new UnitDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Role = GetSimpleString(dr, "Role"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Unit NewUnit(UnitDTO dtoUnit)
    {//созд - 2022, изм - 18.06.2023
        return new Unit
        {
            Id = dtoUnit.Id,
            Parent = new Unit { Id = dtoUnit.Parent },
            Date1 = GetDate1(dtoUnit.Date1),
            Date2 = GetDate2(dtoUnit.Date2),
            Code = dtoUnit.Code,
            Description = dtoUnit.Description,
            Role = new Role { Id = dtoUnit.Role },
            More = dtoUnit.More,
        };
    }
    public static PriceDTO NewPriceDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 18.06.2023
        return new PriceDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Role = GetSimpleString(dr, "Role"),
            Info = GetSimpleString(dr, "Info"),
            Unit = GetSimpleString(dr, "Unit"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Price NewPrice(PriceDTO dtoPrice)
    {//созд - 2022, изм - 18.06.2023
        return new Price
        {
            Id = dtoPrice.Id,
            Parent = new Price { Id = dtoPrice.Parent },
            Date1 = GetDate1(dtoPrice.Date1),
            Date2 = GetDate2(dtoPrice.Date2),
            Code = dtoPrice.Code,
            Description = dtoPrice.Description,
            Role = new Role { Id = dtoPrice.Role },
            Info = new Info { Id = dtoPrice.Info },
            Unit = new Unit { Id = dtoPrice.Unit },
            More = dtoPrice.More,
        };
    }
    public static RoleDTO NewRoleDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 18.06.2023
        return new RoleDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Role NewRole(RoleDTO dtoRole)
    {//созд - 2022, изм - 18.06.2023
        return new Role
        {
            Id = dtoRole.Id,
            Parent = new Role { Id = dtoRole.Parent },
            Date1 = GetDate1(dtoRole.Date1),
            Date2 = GetDate2(dtoRole.Date2),
            Code = dtoRole.Code,
            Description = dtoRole.Description,
            More = dtoRole.More,
        };
    }
    public static MeterDTO NewMeterDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 18.06.2023
        return new MeterDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Unit = GetSimpleString(dr, "Unit"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Meter NewMeter(MeterDTO dtoMeter)
    {//созд - 2022, изм - 18.06.2023
        return new Meter
        {
            Id = dtoMeter.Id,
            Parent = new Meter { Id = dtoMeter.Parent },
            Date1 = GetDate1(dtoMeter.Date1),
            Date2 = GetDate2(dtoMeter.Date2),
            Code = dtoMeter.Code,
            Description = dtoMeter.Description,
            Unit = new Unit { Id = dtoMeter.Unit },
            More = dtoMeter.More,
        };
    }
    public static SignDTO NewSignDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 18.06.2023
        return new SignDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Sign NewSign(SignDTO dtoSign)
    {//созд - 2022, изм - 18.06.2023
        return new Sign
        {
            Id = dtoSign.Id,
            Parent = new Sign{ Id = dtoSign.Parent },
            Date1 = GetDate1(dtoSign.Date1),
            Date2 = GetDate2(dtoSign.Date2),
            Code = dtoSign.Code,
            Description = dtoSign.Description,
            More = dtoSign.More,
        };
    }
    public static SliceDTO NewSliceDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 18.06.2023
        return new SliceDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Slice NewSlice(SliceDTO dtoSlice)
    {//созд - 2022, изм - 18.06.2023
        return new Slice
        {
            Id = dtoSlice.Id,
            Parent = new Slice { Id = dtoSlice.Parent },
            Date1 = GetDate1(dtoSlice.Date1),
            Date2 = GetDate2(dtoSlice.Date2),
            Code = dtoSlice.Code,
            Description = dtoSlice.Description,
            More = dtoSlice.More,
        };
    }
    public static MarkDTO NewMarkDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 18.06.2023
        return new MarkDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Mark NewMark(MarkDTO dtoMark)
    {//созд - 2022, изм - 18.06.2023
        return new Mark
        {
            Id = dtoMark.Id,
            Parent = new Mark { Id = dtoMark.Parent },
            Date1 = GetDate1(dtoMark.Date1),
            Date2 = GetDate2(dtoMark.Date2),
            Code = dtoMark.Code,
            Description = dtoMark.Description,
            More = dtoMark.More,
        };
    }
    public static FaceDTO NewFaceDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 18.06.2023
        return new FaceDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Geo = GetSimpleString(dr, "Geo"),
            Role = GetSimpleString(dr, "Role"),
            Info = GetSimpleString(dr, "Info"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Face NewFace(FaceDTO dtoFace)
    {//созд - 2022, изм - 18.06.2023
        return new Face
        {
            Id = dtoFace.Id,
            Parent = new Face { Id = dtoFace.Parent },
            Date1 = GetDate1(dtoFace.Date1),
            Date2 = GetDate2(dtoFace.Date2),
            Code = dtoFace.Code,
            Description = dtoFace.Description,
            Geo = new Geo { Id = dtoFace.Geo },
            Role = new Role { Id = dtoFace.Role },
            Info = new Info { Id = dtoFace.Info },
            More = dtoFace.More,
        };
    }
    public static ItemDTO NewItemDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 18.06.2023
        return new ItemDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Item NewItem(ItemDTO dtoItem)
    {//созд - 2022, изм - 18.06.2023
        return new Item
        {
            Id = dtoItem.Id,
            Parent = new Item { Id = dtoItem.Parent },
            Date1 = GetDate1(dtoItem.Date1),
            Date2 = GetDate2(dtoItem.Date2),
            Code = dtoItem.Code,
            Description = dtoItem.Description,
            More = dtoItem.More,
        };
    }
    public static InfoDTO NewInfoDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 18.06.2023
        return new InfoDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Info NewInfo(InfoDTO dtoInfo)
    {//созд - 2022, изм - 18.06.2023
        return new Info
        {
            Id = dtoInfo.Id,
            Parent = new Info { Id = dtoInfo.Parent },
            Date1 = GetDate1(dtoInfo.Date1),
            Date2 = GetDate2(dtoInfo.Date2),
            Code = dtoInfo.Code,
            Description = dtoInfo.Description,
            More = dtoInfo.More,
        };
    }
    public static GeoDTO NewGeoDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 18.06.2023
        return new GeoDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Role = GetSimpleString(dr, "Role"),
            Unit = GetSimpleString(dr, "Unit"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Geo NewGeo(GeoDTO dtoGeo)
    {//созд - 2022, изм - 18.06.2023
        return new Geo
        {
            Id = dtoGeo.Id,
            Parent = new Geo { Id = dtoGeo.Parent },
            Date1 = GetDate1(dtoGeo.Date1),
            Date2 = GetDate2(dtoGeo.Date2),
            Code = dtoGeo.Code,
            Description = dtoGeo.Description,
            Role = new Role { Id = dtoGeo.Role },
            Unit = new Unit { Id = dtoGeo.Unit },
            More = dtoGeo.More,
        };
    }
    public static DealDTO NewDealDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 18.06.2023
        return new DealDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Face1 = GetSimpleString(dr, "Face1"),
            Face2 = GetSimpleString(dr, "Face2"),
            Face = GetSimpleString(dr, "Face"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Geo = GetSimpleString(dr, "Geo"),
            Role = GetSimpleString(dr, "Role"),
            Info = GetSimpleString(dr, "Info"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Deal NewDeal(DealDTO dtoDeal)
    {//созд - 2022, изм - 18.06.2023
        return new Deal
        {
            Id = dtoDeal.Id,
            Parent = new Deal { Id = dtoDeal.Parent },
            Face1 = new Face { Id = dtoDeal.Face1 },
            Face2 = new Face { Id = dtoDeal.Face2 },
            Face = new Face { Id = dtoDeal.Face },
            Date1 = GetDate1(dtoDeal.Date1),
            Date2 = GetDate2(dtoDeal.Date2),
            Code = dtoDeal.Code,
            Description = dtoDeal.Description,
            Geo = new Geo { Id = dtoDeal.Geo },
            Role = new Role { Id = dtoDeal.Role },
            Info = new Info { Id = dtoDeal.Info },
            More = dtoDeal.More,
        };
    }
    public static AssetDTO NewAssetDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 18.06.2023
        return new AssetDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Geo = GetSimpleString(dr, "Geo"),
            Role = GetSimpleString(dr, "Role"),
            Info = GetSimpleString(dr, "Info"),
            Unit = GetSimpleString(dr, "Unit"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Asset NewAsset(AssetDTO dtoAsset)
    {//созд - 2022, изм - 18.06.2023
        return new Asset
        {
            Id = dtoAsset.Id,
            Parent = new Asset { Id = dtoAsset.Parent },
            Date1 = GetDate1(dtoAsset.Date1),
            Date2 = GetDate2(dtoAsset.Date2),
            Code = dtoAsset.Code,
            Description = dtoAsset.Description,
            Geo = new Geo { Id = dtoAsset.Geo },
            Role = new Role { Id = dtoAsset.Role },
            Info = new Info { Id = dtoAsset.Info },
            Unit = new Unit { Id = dtoAsset.Unit },
            More = dtoAsset.More,
        };
    }
    public static AccountDTO NewAccountDTO(SQLiteDataReader dr)
    {//созд - 12.06.2023, изм - 18.06.2023
        return new AccountDTO
        {
            Id = GetId(dr),
            Parent = GetSimpleString(dr, "Parent"),
            Slice = GetSimpleString(dr, "Slice"),
            Date1 = GetSimpleString(dr, "Date1"),
            Date2 = GetSimpleString(dr, "Date2"),
            Code = GetSimpleString(dr, "Code"),
            Description = GetSimpleString(dr, "Description"),
            Role = GetSimpleString(dr, "Role"),
            Sign = GetSimpleString(dr, "Sign"),
            More = GetSimpleString(dr, "More"),
        };
    }
    public static Account NewAccount(AccountDTO dtoAccount)
    {//созд - 2022, изм - 18.06.2023
        return new Account
        {
            Id = dtoAccount.Id,
            Parent = new Account { Id = dtoAccount.Parent },
            Slice = new Slice { Id = dtoAccount.Slice },
            Date1 = GetDate1(dtoAccount.Date1),
            Date2 = GetDate2(dtoAccount.Date2),
            Code = dtoAccount.Code,
            Description = dtoAccount.Description,
            Role = new Role { Id = dtoAccount.Role },
            Sign = new Sign { Id = dtoAccount.Sign },
            More = dtoAccount.More,
        };
    }
    public static string GetId(SQLiteDataReader dr)
    {//созд - 2022, изм - 18.06.2023
        string outObj = "Id=?";
        if (dr["Id"].GetType().ToString() != "System.DBNull")
        {
            outObj = (string)dr["Id"];
        }

        //TraceState(outObj, "GetId(...), outObj ");
        return outObj;
    }
    public static DateTime GetDate1(string? dtoDate1)
    {//созд - 2022, изм - 18.06.2023
        DateTime outObj;
        if (DateTime.TryParse(dtoDate1, out outObj))
        {
            //TraceState(outObj, "GetData1(...), outObj ");
        }

        //TraceState(outObj, "GetData1(...), outObj ");
        return outObj;
    }
    public static string? GetDate2(string? dtoDate2)
    {//созд - 17.06.2023, изм - 19.06.2023
        string? outObj = dtoDate2;
        if (DateTime.TryParse(dtoDate2, out DateTime outObj2))
        {//19.06.2023 - здесь возможно будет какая-то логика если Date2 поддается преобразованию в обычную стандартную дату
            outObj = outObj2.ToString();
        }

        //TraceState(outObj, "GetData2(...), outObj ");
        return outObj;
    }
    public static string GetSimpleString(SQLiteDataReader dr, string NameStr)
    {//созд - 2022, 18.06.2023
        string outObj = "";
        if (dr[NameStr].GetType().ToString() != "System.DBNull")
        {
            outObj = (string)dr[NameStr];
        }

        //TraceState(outObj, "GetSimpleString(...), outObj ");
        return outObj;
    }
    public static string GetTableViewNameQuery(string table)
    {//созд - 2022, изм - 2022
        //получаем из имени таблицы\класса в запросе типа "Account" "чистое" имя представления типа "AccountList"
        string TableViewNameQuery = table.Trim();
        if (table != null)
        {
            TableViewNameQuery = TableViewNameQuery.Replace("List", "");  //сначала удалим суффикс List, вдруг он есть
            TableViewNameQuery += "List";  //добавим суффикс "List" для получения имени представления типа "AccountList"
        }

        //TraceState(table, "GetTableViewNameQuery(...), table ");
        //TraceState(TableViewNameQuery, "GetTableViewNameQuery(...), TableViewNameQuery ");
        return TableViewNameQuery;
    }
    public DataAccessLayer() { }
    static DataAccessLayer() { }
}