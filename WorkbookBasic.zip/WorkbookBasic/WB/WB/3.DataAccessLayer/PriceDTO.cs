﻿namespace WB;
[Serializable]
public partial class PriceDTO : ShellDTO //data transfer object
{//созд - 11.06.2023, изм - 11.06.2023
    public string? Role { get; set; }
    public string? Info { get; set; }
    public string? Unit { get; set; }
    public PriceDTO(string? id = default, string? parent = default, string? date1 = default, string? date2 = default, string? code = default, string? description = default, string? more = default, string? role = default, string? info = default, string? unit = default)
    {//созд - 11.06.2023, изм - 11.06.2023
        //public ctor не может содержать ничего, кроме присваивания простых значений
        Id = id;
        Parent = parent;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        Role = role;
        Info = info;
        Unit = unit;
        More = more;
    }
    static PriceDTO() { }
    public override string ToString()
    {//созд - 11.06.2023, изм - 11.06.2023
        return $"{GetType()}, {Id?.ToString() ?? "No Id"}, {Parent?.ToString() ?? "No Parent"}, {Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"}";
    }
}