﻿namespace WB;
[Serializable]
public partial class Conn
{//созд - 2022, изм - 12.02.2023
    public static List<string>? ListBaseTableFact = default; //фактический список учетных баз
    public static List<string> ListBaseTableExpected = new()  //список базовых таблиц ожидаемый  
    {//созд - 2022, изм - 23.01.2023
        "Account", "Asset", "Deal", "Face", "Geo", "Info", "Item", "Mark", "Meter", "Price", "Process",
        "Role", "Sign", "Slice", "Debt", "Unit", "Workbook",
    };
    public static List<string>? GetListDataSource()  //TODO - сделать поиск скл северов и выбор из них  
    {//созд - 2022, изм - 01.01.2023
        List<string>? outListDataSource = default;
        //TODO --- сделать выборку DataSource из внешнего файла Connection
        //если рез-та выборки нет, пытаемся присвоить теоретически возможные DataSource
        if (outListDataSource is null)
        {
            //outListDataSource = ListDataSourceEmergency;
        }

        //TraceState(outListDataSource?.Count, "GetListDataSource(...), outListDataSource?.Count ");
        return outListDataSource;
    }
    public static SQLiteConnection MainConnCurr = new();
    public static SQLiteConnection MainConnDefault = new();
    public static string DataSourceDefault = @".\SQLExpress";
    public static string InitialCatalogDefault = @"BaseN1";
    public static List<SQLiteConnection>? ListConnCurr = new();
    public static List<string>? ListDataSource = new();
    public static void GetMainConn()
    {//созд - 2022, изм - 01.01.2023
        //MainConnDefault = GetConn(inDataSource: @".\SQLExpress", inInitialCatalog: "BaseN1");
        MainConnDefault = GetConn(inDataSource: DataSourceDefault, inInitialCatalog: InitialCatalogDefault);
        SQLiteConnection tmpCopyTestedConn = MainConnDefault;
        TestConn(GetConn(inDataSource: DataSourceDefault, inInitialCatalog: InitialCatalogDefault));
        MainConnCurr = MainConnDefault;
        //TestConn(MainConnCurr);
        //MainConnDefault = GetConn();
        //GetMainConnCurr();
        //TraceState(MainConnCurr.ConnectionString, "GetMainConn(...), MainConnCurr.ConnectionString ");
    }
    public static void GetMainConnCurr()  //TODO -- получить основную Connection из внешнего файла, или из иных источников  
    {//созд - 2022, изм - 01.01.2023
        //SqlConnection testedConn = new();
        //if (ListConnCurr is null)  //если из внешнего файла не получено никаких Connection  
        //{
        //bool connIsValid = TestConn(MainConnDefault);
        //if (connIsValid == true)
        //{
            MainConnCurr = MainConnDefault;
            //TODO - для случая false продумать позже  ????
        //}
        //}

        //TraceState(MainConnCurr.ConnectionString, "GetMainConnCurr(...), MainConnCurr.ConnectionString ");
    }
    public static bool TestConn(SQLiteConnection testedConn)  //проверить Connection
    {//созд - 2022, изм - 13.02.2023
        SQLiteConnection tmpCopyTestedConn = testedConn;
        bool outTestedConnIsValid = false;  //изначально считаем, что Connection нерабочая
        short? EtalonConnBaseTableCount = (short)ListBaseTableExpected.Count;
        List<string>? ListBaseTableFact = GetListBaseTableFact(tmpCopyTestedConn);
        short? TestedConnBaseTableCount = new();
        if (ListBaseTableFact is not null)
        {
            TestedConnBaseTableCount = (short)ListBaseTableFact.Count;
            if (TestedConnBaseTableCount >= EtalonConnBaseTableCount)  //в текущей БД может быть больше таблиц, чем в эталонной БД
            {
                if (ListBaseTableExpected.SequenceEqual(ListBaseTableFact))
                {
                    outTestedConnIsValid = true;
                }
            }
        }
       
        TraceState(testedConn.ConnectionString +"/"+ outTestedConnIsValid.ToString(), "TestConn(...), testedConn.ConnectionString ");
        return outTestedConnIsValid;
    }
    public static List<SQLiteConnection>? GetListConnCurr()  //получить список основных Connection из внешнего файла
    {//созд - 2022, изм - 13.02.2023
        List<SQLiteConnection>? outListConnCurr = new();
        //if ((short)ListConnCurr.Count = 0)
        //{
            outListConnCurr.Add(MainConnCurr);
        //}

        //TraceState(outListConnCurr.Count(), "GetListConnCurr(...), outListConnCurr.Count() ");
        return outListConnCurr;
    }
    public static List<string>? GetListBaseTableFact(SQLiteConnection conn)  //получить фактический список базовых таблиц для Connection  
    {//созд - 2022, изм - 13.02.2023
        List<string>? outListBaseTableFact = new();
        try
        {
            conn.Open();
            DataTable tbl = conn.GetSchema("Tables");
            foreach (DataRow row in tbl.Rows)
            {
                if (row["TABLE_TYPE"].ToString() == "BASE TABLE")
                {
                    outListBaseTableFact.Add(row["TABLE_NAME"].ToString() ?? "No base table");
                }
            }
            conn.Close();
            conn.Dispose();
            outListBaseTableFact.Sort();
        }
        catch (Exception ex)
        {
            _ = ex.Message;
            //TraceState(ex.Message, "GetListBaseTableFact(...), ex.Message ");
        }
        finally { }
        
        TraceState(outListBaseTableFact.Count(), "GetListBaseTable(...), outListBaseTableFact.Count() ");
        return outListBaseTableFact;
    }
    public static SQLiteConnection BuildSQLiteConn(SQLiteConnectionStringBuilder SQLiteConnStrBuild)
    {//созд - 2022, изм - 13.02.2023
        return new()
        {
            ConnectionString = SQLiteConnStrBuild.ConnectionString,
        };
    }
    public static SQLiteConnectionStringBuilder BuildSQLiteConnStrBuilder(string dataSource, string initialCatalog)  //по умолчанию, если нет никаких данных Connection
    //public static SqlConnectionStringBuilder BuildSqlConnStrBuilder(string dataSource = @".\SQLEXPRESS", string initialCatalog = "BaseN1")  //по умолчанию, если нет никаких данных Connection
    {//созд - 2022, изм - 13.02.2023
        SQLiteConnectionStringBuilder SQLiteConnStrBuild = new();
        SQLiteConnStrBuild.DataSource = dataSource;
        //SqlConnStrBuild.InitialCatalog = initialCatalog;
        //SqlConnStrBuild.IntegratedSecurity = true;
        //TraceState(SqlConnStrBuild, "BuildSQLiteConnStrBuilder(...), SQLiteConnStrBuild() ");
        return SQLiteConnStrBuild;
    }
    public static SQLiteConnection GetConn(string inDataSource, string inInitialCatalog)
    //public static SqlConnection GetConn(string inDataSource = @".\SQLEXPRESS", string inInitialCatalog = "BaseN1")
    {//созд - 2022, изм - 13.02.2023
        //получить Connection по DataSource и InitialCatalog, без проверки, просто объект  
        SQLiteConnection outSQLiteConn = new();
        SQLiteConnectionStringBuilder? SQLiteConnStrBuild = BuildSQLiteConnStrBuilder(dataSource: inDataSource, initialCatalog: inInitialCatalog);
        outSQLiteConn = BuildSQLiteConn(SQLiteConnStrBuild);

        TraceState(outSQLiteConn.ConnectionString, "GetConn(...), outSQLiteConn.ConnectionString ");
        return outSQLiteConn;
    }
    public Conn() { }
    static Conn() { }
    //public static string? ConnToString(SQLiteConnection conn)
    //{//созд - 2022, изм - 13.02.2023
    //    //return $"{GetType()}, {conn.ConnectionString ?? "No ConnectionString"}";
    //    //return $"{conn.ConnectionString.ToString() ?? "No ConnectionString"}";
    //    return $"{conn.ConnectionString}";
    //}
}