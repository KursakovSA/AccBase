﻿namespace WB;
[Serializable]
public partial class WorkbookDTO : ShellDTO //data transfer object
{//созд - 11.06.2023, изм - 11.06.2023
    public string? Face1 { get; set; }
    public string? Face2 { get; set; }
    public string? Face { get; set; }
    public string? Slice { get; set; }
    public string? Geo { get; set; }
    public string? Sign { get; set; }
    public string? Account { get; set; }
    public string? Process { get; set; }
    public string? Asset { get; set; }
    public string? Deal { get; set; }
    public string? Item { get; set; }
    public string? Debt { get; set; }
    public string? Price { get; set; }
    public string? Role { get; set; }
    public string? Info { get; set; }
    public string? Meter { get; set; }
    public string? MeterValue { get; set; }
    public string? Unit { get; set; }
    public string? Mark { get; set; }
    public WorkbookDTO(string? id = default, string? parent = default, string? face1 = default, string? face2 = default, string? face = default, string? date1 = default, string? date2 = default, string? code = default, string? description = default, string? more = default, string? role = default, string? geo = default, string? info = default, string? slice = default, string? sign = default, string? account = default, string? asset = default, string? deal = default, string? item = default, string? debt = default, string? price = default, string? meter = default, string? metervalue = default, string? unit = default, string? mark = null, string? process = null)
    {//созд - 11.06.2023, изм - 11.06.2023
        //public ctor не может содержать ничего, кроме присваивания простых значений
        Id = id;
        Parent = parent;
        Face1 = face1;
        Face2 = face2;
        Face = face;
        Slice = slice;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        Geo = geo;
        Sign = sign;
        Account = account;
        Process = process;
        Asset = asset;
        Deal = deal;
        Item = item;
        Debt = debt;
        Price = price;
        Role = role;
        Info = info;
        Meter = meter;
        MeterValue = metervalue;
        Unit = unit;
        More = more;
        Mark = mark;
    }
    static WorkbookDTO() { }
    public override string ToString()
    {//созд - 11.06.2023, изм - 11.06.2023
        return $"{GetType()}, {Id?.ToString() ?? "No Id"}, {Parent?.ToString() ?? "No Parent"}, {Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"}";
    }
}