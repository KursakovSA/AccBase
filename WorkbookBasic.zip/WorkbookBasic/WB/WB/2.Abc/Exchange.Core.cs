﻿namespace WB;
[Serializable]
public partial class Exchange : Shell
{//созд - 2021, изм - 30.05.2023
    public Role? Role { get; set; }
    public string? TargetPath;
    public string? TargetFile;
    public string? TargetExchange;
    public Exchange()
    {//созд - 2021, изм - 23.07.2022
        //public ctor не может содержать ничего, кроме присваивания простых значений
    }
    public Exchange(string? id = default, Exchange? parent = default, DateTime? date1 = default, string? date2 = default, string? code = default, string? description = default, Role? role = default, string? more = default)
    {//созд - 2021, изм - 30.05.2023
        Id = id;
        Parent = parent;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        Role = role;
        More = more;
        TargetPath = StartDirectory;
    }
    static Exchange()
    {//созд - 2021, изм - 23.07.2022
        //static ctor не может содержать ничего, кроме присваивания простых значений
    }
    public StringBuilder SwiftOPV(Workbook? WorkbookSalary = default)
    {//созд - 2021, изм - 20.07.2022
        StringBuilder TextSwift = new();
        
        TraceState(TextSwift, "SwiftOPV(...), TextSwift ");
        return TextSwift;
    }
    public static string GetTargetExchangeValue(string? inTargetPath, string? inTargetFile)
    {//созд - 2021
        string? TargetExchangeValue = inTargetPath + "\\" + inTargetFile;
        if (TargetExchangeValue == null)
        {
            TargetExchangeValue = "GetTargetExchangeValue.No TargetExchangeValue";
        }
        
        TraceState(TargetExchangeValue, "GetTargetExchangeValue(...), TargetExchangeValue ");
        return TargetExchangeValue;
    }
    public override string ToString()
    {
        return $"{GetType()}, {Id?.ToString() ?? "No Id"}, {Parent?.ToString() ?? "No Parent"}, {Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"} ";
    }
}
