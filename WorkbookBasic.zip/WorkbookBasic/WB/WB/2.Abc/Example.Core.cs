﻿namespace WB;
[Serializable]
public partial class Example : Shell
{//созд - 06.07.2022, изм - 22.07.2022
    public Example()
    {//созд - 06.07.2022, изм - 22.07.2022
        //public ctor не может содержать ничего, кроме присваивания простых значений
    }
    static Example()
    {//созд - 06.07.2022, изм - 23.07.2022
        //static ctor не может содержать ничего, кроме присваивания простых значений
    }
    public override string ToString()
    {
        return $"{GetType()}, {Id?.ToString() ?? "No Id"}, {Parent?.Code?.ToString() ?? "No Parent"}, {Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"} ";
    }
}
