﻿namespace WB;
[Serializable]
public partial class Shell
{//созд - 2021, изм - 02.02.2023
    public int? Id { get; set; }
    public Shell? Parent { get; set; }
    private DateTime? date1;
    public DateTime? Date1
    {//созд - 2021, изм - 02.02.2023
        get => date1;
        set => date1 = FixDate(value);
    }
    private string? date2;
    public string? Date2
    {
        get => date2;
        set => date2 = FixTrim(value);
    }
    private string? code;
    public string? Code
    {
        get => code;
        set => code = FixTrim(value);
    }
    private string? description;
    public string? Description
    {
        get => description;
        set => description = FixTrim(value);
    }
    private string? more;
    public string? More
    {
        get => more;
        set => more = FixTrim(value);
    }
    public string? FullDescription;
    public string? FullName;
    public string? ShortDescription;
    public string? ShortName;
    public static readonly DateTime StartDate = new DateTime(2000, 01, 01);  //начало возм действий в программе, стартовая дата, не раньше (с учетом возможного импорта данных из Универсала, или из 1С8)  
    public static readonly DateTime EndDate = new DateTime(2060, 12, 31);  //конец возм действий в программе, финишная дата, не позже
    public static string? FixTrim(string? inStr = "")
    {//созд - 04.07.2022, изм - 06.07.2022
        string? outFix = inStr?.Trim() ?? "";

        //TraceState(outFix, "Shell.FixTrim(...), outFix ");
        return outFix;
    }
    public static DateTime? FixDate(DateTime? inDate = default)
    {//созд - 2021, изм - 02.02.2023
        DateTime? outDate = inDate ?? (DateTime)DateTime.Today;
        if (inDate < StartDate)
        {
            outDate = StartDate;
        }
        if (inDate > EndDate)
        {
            outDate = EndDate;
        }

        //TraceState(outDate, "Shell.FixDate(...), outDate ");
        return outDate;
    }
    static Shell()
    {//созд - 2022, изм - 23.07.2022
        //static ctor не может содержать ничего, кроме присваивания простых значений
    }
    public Shell()
    {//созд - 2022, изм - 23.07.2022
        //public ctor не может содержать ничего, кроме присваивания простых значений
    }
    public override string ToString()
    {
        return $"{GetType()}, {Id?.ToString() ?? ""}, {Parent?.Code?.ToString() ?? ""}, {Date1.ToString() ?? ""}, {Date2?.ToString() ?? ""}, {Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"}";
    }
}
