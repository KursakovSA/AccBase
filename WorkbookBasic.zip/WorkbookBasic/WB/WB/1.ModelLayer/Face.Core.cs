﻿namespace WB;
[Serializable]
public partial class Face : Shell
{//созд - 2021, изм - 3.06.2023
    public Geo? Geo { get; set; }
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    public Face()
    {//созд - 2021, изм - 23.07.2022
        //public ctor не может содержать ничего, кроме присваивания простых значений
    }
    public Face(string? id = default, Face? parent = default, Geo? geo = default, DateTime? date1 = default, string? date2 = default, string? code = default, string? description = default, Role? role = default, Info? info = default, string? more = default)
    {//созд - 2021, изм - 30.05.2023
        Id = id;
        Parent = parent;
        Geo = geo;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        Role = role;
        Info = info;
        More = more;
    }
    static Face()
    {//созд - 2021, изм - 23.07.2022
        //static ctor не может содержать ничего, кроме присваивания простых значений
    }
    public static Workbook? GetTaxModeFaceValue(DateTime Date1, string? Date2, Face? Face, Debt? Tax) //TODO
    {//созд - 2021, изм - 29.07.2022
        Workbook? TaxModeFaceValue = default;

        TraceState(TaxModeFaceValue, "GetTaxModeFaceValue(...), TaxModeFaceValue ");
        return TaxModeFaceValue;
    }
    public static Face TestFace()
    {//созд - 2022, изм - 21.07.2022
        Face outFace = new();

        //TraceState(outFace, "TestFace(...), outFace ");
        return outFace;
    }
    public override string ToString()
    {
        return $"{GetType()}, {Id?.ToString() ?? "No Id"}, {Parent?.ToString() ?? "No Parent"}, {Code?.ToString() ?? "No code"}, {Description?.ToString() ?? "No description"} ";
    }
}
