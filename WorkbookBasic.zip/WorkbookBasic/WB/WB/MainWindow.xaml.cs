﻿global using System;
global using System.Collections.Generic;
global using System.Linq;
global using System.Text;
global using System.Threading.Tasks;
global using System.Windows;
global using System.Windows.Controls;
global using System.Windows.Data;
global using System.Windows.Documents;
global using System.Windows.Input;
global using System.Windows.Media;
global using System.Windows.Media.Imaging;
global using System.Windows.Navigation;
global using System.Windows.Shapes;
global using System.Data.SQLite;
global using System.Data.SqlClient;
global using System.Data.Common;
global using static WB.DataAccessLayer;
global using static WB.Conn;
global using static WB.Qry;
global using static WB.Shell;
global using static WB.Trace;
global using static WB.Abc;
global using static WB.Context;
global using static WB.Account;
global using static WB.Asset;
global using static WB.Deal;
global using static WB.Example;
global using static WB.Face;
global using static WB.Geo;
global using static WB.Info;
global using static WB.Item;
global using static WB.Mark;
global using static WB.Meter;
global using static WB.Price;
global using static WB.Process;
global using static WB.Role;
global using static WB.Sign;
global using static WB.Slice;
global using static WB.Debt;
global using static WB.Unit;
global using static WB.Workbook;
global using static WB.MathSp;
namespace WB;
public partial class MainWindow : Window
{//созд - 04.12.2022, изм - 21.12.2022
    public MainWindow()
    {//созд - 04.12.2022, изм - 21.12.2022
        InitializeComponent();
        try
        {
            //Binding binding = new Binding();
            //binding.ElementName = TraceLog.ToString(); // элемент-источник
            //binding.Path = new PropertyPath("Text"); // свойство элемента-источника
            //TextBox1.SetBinding(TextBox.TextProperty, binding); // установка привязки для элемента-приемника
            OnStartApp();
            //Test();
        }
        catch (Exception ex)
        {
            _ = ex.Message;
            TraceState(ex.Message, "MainWindow(...), ex.Message ");
        }
        finally
        {
            OnExitApp();
        }
    }
    public static void Test()
    {//созд - 13.07.2022, изм - 19.12.2022
        TestTable();
        TestModel();
    }
    public static void TestTable()
    {//созд - 2022, изм - 19.12.2022
        GetTableDb(conn: MainConnCurr);
    }
    public static void TestModel()
    {//созд - 2022, изм - 23.01.2023
        TestAccount();
        TestAsset();
        TestDeal();
        TestFace();
        TestGeo();
        TestInfo();
        TestItem();
        TestMark();
        TestMeter();
        TestPrice();
        TestProcess();
        TestRole();
        TestSign();
        TestSlice();
        TestDebt();
        TestUnit();
        TestWorkbook();
    }
    public static void OnStartApp()
    {//созд - 2022, изм - 22.12.2022
        try
        {
            IsDev = true;    //закомментировать, если это не так  
            TraceState(IsDev, "MainWindow(), OnStartApp(), IsDev ");
            GetDirectory();
            GetMainConn();
            GetAbcDb(conn: MainConnCurr);
        }
        catch (Exception ex)
        {
            _ = ex.Message;
            TraceState(ex.Message, "OnStartApp(...), ex.Message ");
        }
        finally { }
    }
    public static void OnExitApp()
    {//созд - 2022, изм - 22.12.2022 
        try
        {
            if (IsDev)
            {
                TraceState(IsDev, "Main, OnExitApp(), IsDev ");
                //WriteTraceList(TraceList);
                MessageBox.Show(TraceListToString(TraceList));
            }
        }
        catch (Exception ex)
        {
            _ = ex.Message;
            //TraceState(ex.Message, "OnExitApp(...), ex.Message ");
        }
        finally { }
    }
    private void OnWorkbookList(object sender, RoutedEventArgs e)
    {//созд - 21.12.2022, изм - 21.12.2022
        //var WorkbookList = new WorkbookList();
        //this.TabControl1.SelectedIndex = this.TabControl1.Items.Add(new TabItem { Header = "Workbook list", Content = WorkbookList });
        this.TabControl1.SelectedIndex = this.TabControl1.Items.Add(new TabItem { Header = "Workbook list"});
    }
}
