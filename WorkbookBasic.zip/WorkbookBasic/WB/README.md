Workbook Basic - an accounting program that does not piss anyone off when using it. And the author of his including. Platform - Java, SQLite, Eclipse. System requirements - openjdk-21 or higher (https://download.java.net/java/GA/jdk21.0.1/415e3f918a1f4062a0074a2794853d0d/12/GPL/openjdk-21.0.1_windows-x64_bin.zip).
support - kursakov.s@gmail.com

Workbook Basic - пайдалану кезінде ешкімді ренжітпейтін бухгалтерлік бағдарлама. Және оның авторы. Платформа – Java, SQLite, Eclipse.
Жүйе талаптары - openjdk-21 немесе одан жоғары (https://download.java.net/java/GA/jdk21.0.1/415e3f918a1f4062a0074a2794853d0d/12/GPL/openjdk-21.0.1_windows-x64_bin.zip).
Қолдау - kursakov.s@gmail.com

Workbook Basic - учетная программа, которая никого не выбешивает при ее использовании. И автора своего в том числе. Платформа – Java, SQLite, Eclipse. Системные требования - openjdk-21 или выше (https://download.java.net/java/GA/jdk21.0.1/415e3f918a1f4062a0074a2794853d0d/12/GPL/openjdk-21.0.1_windows-x64_bin.zip).
Поддержка - kursakov.s@gmail.com

общие метаданные DatabaseGlobal.sqlite3,  шаблон учетной базы данных DatabaseTemplate.sqlite3, готовая скомпилированная программа WB.zip, Универсал для 1С77 (предшественник данной программы) UniBase1.zip, стартовые метаданные учетной базы и общие метаданные DatabaseTemplateGlobal_tables.xlsx, папка проекта Eclipse WorkbookBasic.zip, прочие статьи автора articles.zip
