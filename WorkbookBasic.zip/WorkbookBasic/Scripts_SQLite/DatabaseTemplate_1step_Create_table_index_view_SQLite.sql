﻿--Курсаков С.А. https://github.com/KursakovSA/AccBase 

PRAGMA foreign_keys = off;

CREATE TABLE IF NOT EXISTS [Account](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Account(Id),
	[Slice] TEXT references Slice(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
    [Role] TEXT references Role(Id),
    [Sign] TEXT references Sign(Id),
	[More] TEXT
 );

CREATE TABLE IF NOT EXISTS [Asset](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Asset(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Geo] TEXT references Geo(Id),
	[Role] TEXT references Role(Id),
	[Info] TEXT references Info(Id),
	[Unit] TEXT references Unit(Id),
	[More] TEXT
 );

CREATE TABLE IF NOT EXISTS [Deal](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Deal(Id),
	[Face1] TEXT references Face(Id),
	[Face2] TEXT references Face(Id),
	[Face] TEXT references Face(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Geo] TEXT references Geo(Id),
	[Role] TEXT references Role(Id),
	[Info] TEXT references Info(Id),
	[More] TEXT
 );

CREATE TABLE IF NOT EXISTS [Debt](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Debt(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Geo] TEXT references Geo(Id),
	[Role] TEXT references Role(Id),
	[Info] TEXT references Info(Id),
	[More] TEXT
  ); 
 
CREATE TABLE IF NOT EXISTS [Face](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Face(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Geo] TEXT references Geo(Id),
	[Role] TEXT references Role(Id),
	[Info] TEXT references Info(Id),
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Geo](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Geo(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
    [Role] TEXT references Role(Id),
	[Unit] TEXT references Unit(Id),
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Info](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Info(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Item](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Item(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Mark](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Mark(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Meter](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Meter(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Unit] TEXT references Unit(Id),
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Price](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Price(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Role] TEXT references Role(Id),
	[Info] TEXT references Info(Id),
	[Unit] TEXT references Unit(Id),
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Process](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Process(Id),
	[Face1] TEXT references Face(Id),
	[Face2] TEXT references Face(Id),
	[Face] TEXT references Face(Id),
	[Slice] TEXT references Slice(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Geo] TEXT references Geo(Id),
	[Sign] TEXT references Sign(Id),
	[Account] TEXT references Account(Id),
    [Asset] TEXT references Asset(Id),
    [Deal] TEXT references Deal(Id),
    [Item] TEXT references Item(Id),
	[Debt] TEXT references Debt(Id),
	[Price] TEXT references Price(Id),
	[Role] TEXT references Role(Id),
	[Info] TEXT references Info(Id),
	[Meter] TEXT references Meter(Id),
	[MeterValue] TEXT,
	[Unit] TEXT references Unit(Id),
	[More] TEXT,
	[Mark] TEXT references Mark(Id)
 );
 
CREATE TABLE IF NOT EXISTS [Role](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Role(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Sign](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Sign(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Slice](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Slice(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Unit](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Unit(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Role] TEXT references Role(Id),
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Workbook](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Workbook(Id),
	[Face1] TEXT references Face(Id),
	[Face2] TEXT references Face(Id),
	[Face] TEXT references Face(Id),
	[Slice] TEXT references Slice(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Geo] TEXT references Geo(Id),
	[Sign] TEXT references Sign(Id),
	[Account] TEXT references Account(Id),
	[Process] TEXT references Process(Id),
    [Asset] TEXT references Asset(Id),
    [Deal] TEXT references Deal(Id),
    [Item] TEXT references Item(Id),
	[Debt] TEXT references Debt(Id),
	[Price] TEXT references Price(Id),
	[Role] TEXT references Role(Id),
	[Info] TEXT references Info(Id),
	[Meter] TEXT references Meter(Id),
	[MeterValue] TEXT,
	[Unit] TEXT references Unit(Id),
	[More] TEXT,
	[Mark] TEXT references Mark(Id)
 );
 
CREATE INDEX IF NOT EXISTS AssetDate1 ON Asset (
    Date1
);

CREATE INDEX IF NOT EXISTS AssetCode ON Asset (
    Code
);
 
CREATE INDEX IF NOT EXISTS AssetDescription ON Asset (
    Description
);

CREATE INDEX IF NOT EXISTS AssetRole ON Asset (
    Role
);

CREATE INDEX IF NOT EXISTS AssetInfo ON Asset (
    Info
);

CREATE INDEX IF NOT EXISTS DealParent ON Deal (
    Parent
);

CREATE INDEX IF NOT EXISTS DealFace1 ON Deal (
    Face1
);

CREATE INDEX IF NOT EXISTS DealFace2 ON Deal (
    Face2
);

CREATE INDEX IF NOT EXISTS DealFace ON Deal (
    Face
);

CREATE INDEX IF NOT EXISTS DealCode ON Deal (
    Code
);
 
CREATE INDEX IF NOT EXISTS DealDescription ON Deal (
    Description
);

CREATE INDEX IF NOT EXISTS DealRole ON Deal (
    Role
);

CREATE INDEX IF NOT EXISTS DealInfo ON Deal (
    Info
);

CREATE INDEX IF NOT EXISTS FaceParent ON Face (
    Parent
);

CREATE INDEX IF NOT EXISTS FaceDate1 ON Face (
    Date1
);

CREATE INDEX IF NOT EXISTS FaceCode ON Face (
    Code
);
 
CREATE INDEX IF NOT EXISTS FaceDescription ON Face (
    Description
);

CREATE INDEX IF NOT EXISTS FaceRole ON Face (
    Role
);

CREATE INDEX IF NOT EXISTS FaceInfo ON Face (
    Info
);
 
CREATE INDEX IF NOT EXISTS WorkbookParent ON Workbook (
    Parent
);

CREATE INDEX IF NOT EXISTS WorkbookFace1 ON Workbook (
    Face1
);

CREATE INDEX IF NOT EXISTS WorkbookFace2 ON Workbook (
    Face2
);

CREATE INDEX IF NOT EXISTS WorkbookFace ON Workbook (
    Face
);

CREATE INDEX IF NOT EXISTS WorkbookDate1 ON Workbook (
    Date1
);

CREATE INDEX IF NOT EXISTS WorkbookCode ON Workbook (
    Code
);
 
CREATE INDEX IF NOT EXISTS WorkbookDescription ON Workbook (
    Description
);

CREATE INDEX IF NOT EXISTS WorkbookSign ON Workbook (
    Sign
);

CREATE INDEX IF NOT EXISTS WorkbookAccount ON Workbook (
    Account
);

CREATE INDEX IF NOT EXISTS WorkbookProcess ON Workbook (
    Process
);

CREATE INDEX IF NOT EXISTS WorkbookDebt ON Workbook (
    Debt
);

CREATE INDEX IF NOT EXISTS WorkbookDeal ON Workbook (
    Deal
);

CREATE INDEX IF NOT EXISTS WorkbookAsset ON Workbook (
    Asset
);

CREATE INDEX IF NOT EXISTS WorkbookRole ON Workbook (
    Role
);

CREATE INDEX IF NOT EXISTS WorkbookInfo ON Workbook (
    Info
);

-- View: AccountList
CREATE VIEW IF NOT EXISTS AccountList AS
    SELECT Account.Id,
           Account.Parent,
           Account.Slice,
           Account.Date1 AS Date1,
           Account.Date2 AS Date2,
           Account.Code AS Code,
           Account.Description AS Description,
           Account.Role,
           Account.Sign,
           Account.More AS More
      FROM Account AS Account;

-- View: AssetList
CREATE VIEW IF NOT EXISTS AssetList AS
    SELECT Asset.Id,
           Asset.Parent,
           Asset2.Code AS ParentCode,
           Asset2.Description AS ParentDescription,
           Asset.Date1 AS Date1,
           Asset.Date2 AS Date2,
           Asset.Code,
           Asset.Description,
           Asset.Geo,
           Asset.Role,
           Asset.Info,
           Asset.Unit,
           Asset.More AS More
      FROM Asset AS Asset
           LEFT JOIN
           Asset AS Asset2 ON Asset.Parent = Asset2.Id;

-- View: DealList
CREATE VIEW IF NOT EXISTS DealList AS
    SELECT Deal.Id,
           Deal.Parent,
           Deal2.Code AS ParentCode,
           Deal2.Description AS ParentDescription,
           Deal.Face1,
           Face1.Code AS Face1Code,
           Face1.Description AS Face1Description,
           Deal.Face2,
           Face2.Code AS Face2Code,
           Face2.Description AS Face2Description,
           Deal.Face,
           Face.Code AS FaceCode,
           Face.Description AS FaceDescription,
           Deal.Date1 AS Date1,
           Deal.Date2 AS Date2,
           Deal.Code AS Code,
           Deal.Description AS Description,
           Deal.Geo,
           Deal.Role,
           Deal.Info,
           Deal.More AS More
      FROM Deal AS Deal
           LEFT JOIN
           Deal AS Deal2 ON Deal.Parent = Deal2.Id
           LEFT JOIN
           Face AS Face ON Deal.Face = Face.Id
           LEFT JOIN
           Face AS Face1 ON Deal.Face1 = Face1.Id
           LEFT JOIN
           Face AS Face2 ON Deal.Face2 = Face2.Id;

-- View: DebtList
CREATE VIEW IF NOT EXISTS DebtList AS
    SELECT Debt.Id,
           Debt.Parent,
           Debt.Date1 AS Date1,
           Debt.Date2 AS Date2,
           Debt.Code AS Code,
           Debt.Description AS Description,
           Debt.Geo,
           Debt.Role,
           Debt.Info,
           Debt.More AS More
      FROM Debt AS Debt;

-- View: FaceList
CREATE VIEW IF NOT EXISTS FaceList AS
    SELECT Face.Id,
           Face.Parent,
           Face2.Code AS ParentCode,
           Face2.Description AS ParentDescription,
           Face.Date1 AS Date1,
           Face.Date2 AS Date2,
           Face.Code AS Code,
           Face.Description AS Description,
           Face.Geo,
           Face.Role,
           Face.Info,
           Face.More AS More
      FROM Face AS Face
           LEFT JOIN
           Face AS Face2 ON Face.Parent = Face2.Id;

-- View: GeoList
CREATE VIEW IF NOT EXISTS GeoList AS
    SELECT Geo.Id,
           Geo.Parent,
           Geo.Date1 AS Date1,
           Geo.Date2 AS Date2,
           Geo.Code AS Code,
           Geo.Description AS Description,
           Geo.Role,
           Geo.Unit,
           Geo.More AS More
      FROM Geo AS Geo;

-- View: InfoList
CREATE VIEW IF NOT EXISTS InfoList AS
    SELECT Info.Id,
           Info.Parent,
           Info.Date1 AS Date1,
           Info.Date2 AS Date2,
           Info.Code AS Code,
           Info.Description AS Description,
           Info.More AS More
	FROM Info AS Info;

-- View: ItemList
CREATE VIEW IF NOT EXISTS ItemList AS
    SELECT Item.Id,
           Item.Parent,
           Item.Date1 AS Date1,
           Item.Date2 AS Date2,
           Item.Code AS Code,
           Item.Description AS Description,
           Item.More AS More
	FROM Item AS Item;

-- View: MarkList
CREATE VIEW IF NOT EXISTS MarkList AS
    SELECT Mark.Id,
           Mark.Parent,
           Mark.Date1 AS Date1,
           Mark.Date2 AS Date2,
           Mark.Code AS Code,
           Mark.Description AS Description,
           Mark.More AS More
	FROM Mark AS Mark;

-- View: MeterList
CREATE VIEW IF NOT EXISTS MeterList AS
    SELECT Meter.Id,
           Meter.Parent,
           Meter.Date1 AS Date1,
           Meter.Date2 AS Date2,
           Meter.Code AS Code,
           Meter.Description AS Description,
           Meter.More AS More
      FROM Meter AS Meter;

-- View: PriceList
CREATE VIEW IF NOT EXISTS PriceList AS
    SELECT Price.Id,
           Price.Parent,
           Price.Date1 AS Date1,
           Price.Date2 AS Date2,
           Price.Code AS Code,
           Price.Description AS Description,
           Price.Role,
           Price.Info,
           Price.Unit,
           Price.More AS More
      FROM Price AS Price;

-- View: ProcessList
CREATE VIEW IF NOT EXISTS ProcessList AS
    SELECT Process.Id,
           Process.Parent,
           Process.Face1,
           Face1.Code AS Face1Code,
           Face1.Description AS Face1Description,
           Process.Face2,
           Face2.Code AS Face2Code,
           Face2.Description AS Face2Description,
           Process.Face,
           Face.Code AS FaceCode,
           Face.Description AS FaceDescription,
           Process.Slice,
           Process.Date1 AS Date1,
           Process.Date2 AS Date2,
           Process.Code AS Code,
           Process.Description AS Description,
		   Process.Geo,
           Process.Sign,
           Process.Account,
           Process.Asset,
           Asset.Code AS AssetCode,
           Asset.Description AS AssetDescription,
           Process.Deal,
           Deal.Code AS DealCode,
           Deal.Description AS DealDescription,
           Process.Item,
           Process.Debt,
           Process.Price,
           Process.Role,
           Process.Info,
           Process.Meter,
           Process.MeterValue AS MeterValue,
           Process.Unit,
           Process.More AS More,
		   Process.Mark
      FROM Process AS Process
           LEFT JOIN
           Face AS Face ON Process.Face = Face.Id
           LEFT JOIN
           Face AS Face1 ON Process.Face1 = Face1.Id
           LEFT JOIN
           Face AS Face2 ON Process.Face2 = Face2.Id
           LEFT JOIN
           Deal AS Deal ON Process.Deal = Deal.Id
           LEFT JOIN
           Asset AS Asset ON Process.Asset = Asset.Id;

-- View: RoleList
CREATE VIEW IF NOT EXISTS RoleList AS
    SELECT Role.Id,
           Role.Parent,
           Role.Date1 AS Date1,
           Role.Date2 AS Date2,
           Role.Code AS Code,
           Role.Description AS Description,
           Role.More AS More
      FROM Role AS Role;

-- View: SignList
CREATE VIEW IF NOT EXISTS SignList AS
    SELECT Sign.Id,
           Sign.Parent,
           Sign.Date1 AS Date1,
           Sign.Date2 AS Date2,
           Sign.Code AS Code,
           Sign.Description AS Description,
           Sign.More AS More
      FROM Sign AS Sign;

-- View: SliceList
CREATE VIEW IF NOT EXISTS SliceList AS
    SELECT Slice.Id,
           Slice.Parent,
           Slice.Date1 AS Date1,
           Slice.Date2 AS Date2,
           Slice.Code AS Code,
           Slice.Description AS Description,
           Slice.More AS More
      FROM Slice AS Slice;

-- View: UnitList
CREATE VIEW IF NOT EXISTS UnitList AS
    SELECT Unit.Id,
           Unit.Parent,
           Unit.Date1 AS Date1,
           Unit.Date2 AS Date2,
           Unit.Code AS Code,
           Unit.Description AS Description,
           Unit.Role,
           Unit.More AS More
      FROM Unit AS Unit;

-- View: WorkbookList
CREATE VIEW IF NOT EXISTS WorkbookList AS
    SELECT Workbook.Id,
           Workbook.Parent,
           Workbook2.Code AS ParentCode,
           Workbook2.Description AS ParentDescription,
           Workbook.Face1,
           Face1.Code AS Face1Code,
           Face1.Description AS Face1Description,
           Workbook.Face2,
           Face2.Code AS Face2Code,
           Face2.Description AS Face2Description,
           Workbook.Face,
           Face.Code AS FaceCode,
           Face.Description AS FaceDescription,
           Workbook.Slice,
           Workbook.Date1 AS Date1,
           Workbook.Date2 AS Date2,
           Workbook.Code AS Code,
           Workbook.Description AS Description,
           Workbook.Geo,
           Workbook.Sign,
           Workbook.Account,
           Workbook.Process,
           Workbook.Debt,
           Workbook.Item,
           Workbook.Deal,
           Deal.Code AS DealCode,
           Deal.Description AS DealDescription,
           Workbook.Price,
           Workbook.Asset,
           Asset.Code AS AssetCode,
           Asset.Description AS AssetDescription,
           Workbook.Role,
           Workbook.Info,
           Workbook.Meter,
           Workbook.MeterValue AS MeterValue,
           Workbook.Unit,
		   Workbook.More AS More,
           Workbook.Mark
      FROM Workbook AS Workbook
           LEFT JOIN
           Workbook AS Workbook2 ON Workbook.Parent = Workbook2.Id
           LEFT JOIN
           Face AS Face ON Workbook.Face = Face.Id
           LEFT JOIN
           Face AS Face1 ON Workbook.Face1 = Face1.Id
           LEFT JOIN
           Face AS Face2 ON Workbook.Face2 = Face2.Id
           LEFT JOIN
           Deal AS Deal ON Workbook.Deal = Deal.Id
           LEFT JOIN
           Asset AS Asset ON Workbook.Asset = Asset.Id;