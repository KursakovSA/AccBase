﻿--Курсаков С.А. https://github.com/KursakovSA/AccBase 

CREATE TABLE IF NOT EXISTS [Account](
	[Id],
	[Parent],
	[Slice],
	[Date1],
	[Date2],
	[Code],
	[Description],
    [Role],
    [Sign],
	[More]
 );

CREATE TABLE IF NOT EXISTS [Asset](
	[Id],
	[Parent],
	[Date1],
	[Date2],
	[Code],
	[Description],
	[Geo],
	[Role],
	[Info],
	[Unit],
	[More]
 );

CREATE TABLE IF NOT EXISTS [Deal](
	[Id],
	[Parent],
	[Face1],
	[Face2],
	[Face],
	[Date1],
	[Date2],
	[Code],
	[Description],
	[Geo] INTEGER,
	[Role],
	[Info],
	[More]
 );

CREATE TABLE IF NOT EXISTS [Debt](
	[Id],
	[Parent],
	[Date1],
	[Date2],
	[Code],
	[Description],
	[Geo],
	[Role],
	[Info],
	[More]
  ); 
 
CREATE TABLE IF NOT EXISTS [Face](
	[Id],
	[Parent],
	[Date1],
	[Date2],
	[Code],
	[Description],
	[Geo],
	[Role],
	[Info],
	[More]
 );
 
CREATE TABLE IF NOT EXISTS [Geo](
	[Id],
	[Parent],
	[Date1],
	[Date2],
	[Code],
	[Description],
    [Role],
	[Unit],
	[More]
 );
 
CREATE TABLE IF NOT EXISTS [Info](
	[Id],
	[Parent],
	[Date1],
	[Date2],
	[Code],
	[Description],
	[More]
 );
 
CREATE TABLE IF NOT EXISTS [Item](
	[Id],
	[Parent],
	[Date1],
	[Date2],
	[Code],
	[Description],
	[More]
 );
 
CREATE TABLE IF NOT EXISTS [Mark](
	[Id],
	[Parent],
	[Date1],
	[Date2],
	[Code],
	[Description],
	[More]
 );
 
CREATE TABLE IF NOT EXISTS [Meter](
	[Id],
	[Parent],
	[Date1],
	[Date2],
	[Code],
	[Description],
	[Unit],
	[More]
 );
 
CREATE TABLE IF NOT EXISTS [Price](
	[Id],
	[Parent],
	[Date1],
	[Date2],
	[Code],
	[Description],
	[Role],
	[Info],
	[Unit],
	[More]
 );
 
CREATE TABLE IF NOT EXISTS [Process](
	[Id],
	[Parent],
	[Face1],
	[Face2],
	[Face],
	[Slice],
	[Date1],
	[Date2],
	[Code],
	[Description],
	[Sign],
	[Account],
    [Asset],
    [Deal],
    [Item],
	[Debt],
	[Price],
	[Role],
	[Info],
	[Meter],
	[MeterValue],
	[Unit],
	[More]
 );
 
CREATE TABLE IF NOT EXISTS [Role](
	[Id],
	[Parent],
	[Date1],
	[Date2],
	[Code],
	[Description],
	[More]
 );
 
CREATE TABLE IF NOT EXISTS [Sign](
	[Id],
	[Parent],
	[Date1],
	[Date2],
	[Code],
	[Description],
	[Role],
	[Info],
	[More]
 );
 
CREATE TABLE IF NOT EXISTS [Slice](
	[Id],
	[Parent],
	[Date1],
	[Date2],
	[Code],
	[Description],
	[More]
 );
 
CREATE TABLE IF NOT EXISTS [Unit](
	[Id],
	[Parent],
	[Date1],
	[Date2],
	[Code],
	[Description],
	[Role],
	[More]
 );
 
CREATE TABLE IF NOT EXISTS [Workbook](
	[Id],
	[Parent],
	[Face1],
	[Face2],
	[Face],
	[Slice],
	[Date1],
	[Date2],
	[Code],
	[Description],
	[Geo],
	[Sign],
	[Account],
	[Process],
    [Asset],
    [Deal],
    [Item],
	[Debt],
	[Price],
	[Role],
	[Info],
	[Meter],
	[MeterValue],
	[Unit],
	[More],
	[Mark]
 );

-- View: WorkbookList
CREATE VIEW IF NOT EXISTS WorkbookList AS
    SELECT Workbook.Id,
           Workbook.Parent,
           Workbook.Face1,
           Workbook.Face2,
           Workbook.Face,
           Workbook.Slice,
           Workbook.Date1,
           Workbook.Date2,
           Workbook.Code,
           Workbook.Description,
           Workbook.Geo,
           Workbook.Sign,
           Workbook.Account,
           Workbook.Process,
           Workbook.Debt,
           Workbook.Item,
           Workbook.Deal,
           Workbook.Price,
           Workbook.Asset,
           Workbook.Role,
           Workbook.Info,
           Workbook.Meter,
           Workbook.MeterValue,
           Workbook.Unit,
		   Workbook.More,
           Workbook.Mark
		   FROM Workbook;