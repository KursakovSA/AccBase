﻿--Курсаков С.А. https://github.com/KursakovSA/AccBase 

--PRAGMA foreign_keys = off;
--BEGIN TRANSACTION;

-- View: AccountList
CREATE VIEW IF NOT EXISTS AccountList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Slice,
           T3.Code AS SliceCode,
           T3.Description AS SliceDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.Role,
           T10.Code AS RoleCode,
           T10.Description AS RoleDescription,
           T1.Sign,
           T12.Code AS SignCode,
           T12.Description AS SignDescription,
           T1.More AS More
      FROM Account AS T1
           LEFT JOIN
           Account AS T4 ON T1.Parent = T4.Id
           LEFT JOIN
           Slice AS T3 ON T1.Slice = T3.Id
           LEFT JOIN
           Role AS T10 ON T1.Role = T10.Id
           LEFT JOIN
           Sign AS T12 ON T1.Sign = T12.Id;

-- View: AssetList
CREATE VIEW IF NOT EXISTS AssetList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code,
           T1.Description,
           T1.Geo,
           T8.Code AS GeoCode,
           T8.Description AS GeoDescription,
           T1.Asset1,
           T12.Code AS Asset1Code,
           T12.Description AS Asset1Description,
           T1.Role,
           T10.Code AS RoleCode,
           T10.Description AS RoleDescription,
           T1.Info,
           T11.Code AS InfoCode,
           T11.Description AS InfoDescription,
           T1.Unit,
           T13.Code AS UnitCode,
           T13.Description AS UnitDescription,
           T1.More AS More
      FROM Asset AS T1
           LEFT JOIN
           Asset AS T4 ON T1.Parent = T4.Id
           LEFT JOIN
           Geo AS T8 ON T1.Geo = T8.Id
           LEFT JOIN
           Role AS T10 ON T1.Role = T10.Id
           LEFT JOIN
           Info AS T11 ON T1.Info = T11.Id
           LEFT JOIN
           Asset AS T12 ON T1.Asset1 = T12.Id
           LEFT JOIN
           Unit AS T13 ON T1.Unit = T13.Id;

-- View: DealList
CREATE VIEW IF NOT EXISTS DealList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Face1,
           T6.Code AS Face1Code,
           T6.Description AS Face1Description,
           T1.Face2,
           T7.Code AS Face2Code,
           T7.Description AS Face2Description,
           T1.Face,
           T5.Code AS FaceCode,
           T5.Description AS FaceDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.Geo,
           T8.Code AS GeoCode,
           T8.Description AS GeoDescription,
           T1.Role,
           T10.Code AS RoleCode,
           T10.Description AS RoleDescription,
           T1.Info,
           T11.Code AS InfoCode,
           T11.Description AS InfoDescription,
           T1.More AS More
      FROM Deal AS T1
           LEFT JOIN
           Deal AS T4 ON T1.Parent = T4.Id
           LEFT JOIN
           Face AS T5 ON T1.Face = T5.Id
           LEFT JOIN
           Face AS T6 ON T1.Face1 = T6.Id
           LEFT JOIN
           Face AS T7 ON T1.Face2 = T7.Id
           LEFT JOIN
           Geo AS T8 ON T1.Geo = T8.Id
           LEFT JOIN
           Role AS T10 ON T1.Role = T10.Id
           LEFT JOIN
           Info AS T11 ON T1.Info = T11.Id;

-- View: DebtList
CREATE VIEW IF NOT EXISTS DebtList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.Geo,
           T8.Code AS GeoCode,
           T8.Description AS GeoDescription,
           T1.Role,
           T10.Code AS RoleCode,
           T10.Description AS RoleDescription,
           T1.Info,
           T11.Code AS InfoCode,
           T11.Description AS InfoDescription,
           T1.More AS More
      FROM Debt AS T1
           LEFT JOIN
           Debt AS T4 ON T1.Parent = T4.Id
           LEFT JOIN
           Geo AS T8 ON T1.Geo = T8.Id
           LEFT JOIN
           Role AS T10 ON T1.Role = T10.Id
           LEFT JOIN
           Info AS T11 ON T1.Info = T11.Id;

-- View: FaceList
CREATE VIEW IF NOT EXISTS FaceList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.Geo,
           T8.Code AS GeoCode,
           T8.Description AS GeoDescription,
           T1.Role,
           T10.Code AS RoleCode,
           T10.Description AS RoleDescription,
           T1.Info,
           T11.Code AS InfoCode,
           T11.Description AS InfoDescription,
           T1.More AS More
      FROM Face AS T1
           LEFT JOIN
           Face AS T4 ON T1.Parent = T4.Id
           LEFT JOIN
           Geo AS T8 ON T1.Geo = T8.Id
           LEFT JOIN
           Role AS T10 ON T1.Role = T10.Id
           LEFT JOIN
           Info AS T11 ON T1.Info = T11.Id;

-- View: GeoList
CREATE VIEW IF NOT EXISTS GeoList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.Role,
           T10.Code AS RoleCode,
           T10.Description AS RoleDescription,
           T1.Unit,
           T13.Code AS UnitCode,
           T13.Description AS UnitDescription,
           T1.More AS More
      FROM Geo AS T1
           LEFT JOIN
           Geo AS T4 ON T1.Parent = T4.Id
           LEFT JOIN
           Role AS T10 ON T1.Role = T10.Id
           LEFT JOIN
           Unit AS T13 ON T1.Unit = T13.Id;

-- View: InfoList
CREATE VIEW IF NOT EXISTS InfoList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.More AS More
      FROM Info AS T1
           LEFT JOIN
           Info AS T4 ON T1.Parent = T4.Id;

-- View: ItemList
CREATE VIEW IF NOT EXISTS ItemList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.More AS More
      FROM Item AS T1
           LEFT JOIN
           Item AS T4 ON T1.Parent = T4.Id;

-- View: MarkList
CREATE VIEW IF NOT EXISTS MarkList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.More AS More
      FROM Mark AS T1
           LEFT JOIN
           Mark AS T4 ON T1.Parent = T4.Id;

-- View: MeterList
CREATE VIEW IF NOT EXISTS MeterList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.More AS More
      FROM Meter AS T1
           LEFT JOIN
           Meter AS T4 ON T1.Parent = T4.Id;

-- View: PriceList
CREATE VIEW IF NOT EXISTS PriceList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.Role,
           T10.Code AS RoleCode,
           T10.Description AS RoleDescription,
           T1.Info,
           T11.Code AS InfoCode,
           T11.Description AS InfoDescription,
           T1.Unit,
           T13.Code AS UnitCode,
           T13.Description AS UnitDescription,
           T1.More AS More
      FROM Price AS T1
           LEFT JOIN
           Price AS T4 ON T1.Parent = T4.Id
           LEFT JOIN
           Role AS T10 ON T1.Role = T10.Id
           LEFT JOIN
           Info AS T11 ON T1.Info = T11.Id
           LEFT JOIN
           Unit AS T13 ON T1.Unit = T13.Id;

-- View: ProcessList
CREATE VIEW IF NOT EXISTS ProcessList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Face1,
           T6.Code AS Face1Code,
           T6.Description AS Face1Description,
           T1.Face2,
           T7.Code AS Face2Code,
           T7.Description AS Face2Description,
           T1.Face,
           T5.Code AS FaceCode,
           T5.Description AS FaceDescription,
           T1.Slice,
           T3.Code AS SliceCode,
           T3.Description AS SliceDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.Sign,
           T12.Code AS SignCode,
           T12.Description AS SignDescription,
           T1.Account,
           T9.Code AS AccountCode,
           T9.Description AS AccountDescription,
           T1.Asset,
           T21.Code AS AssetCode,
           T21.Description AS AssetDescription,
           T1.Deal,
           T19.Code AS DealCode,
           T19.Description AS DealDescription,
           T1.Item,
           T18.Code AS ItemCode,
           T18.Description AS ItemDescription,
           T1.Debt,
           T17.Code AS DebtCode,
           T17.Description AS DebtDescription,
           T1.Price,
           T20.Code AS PriceCode,
           T20.Description AS PriceDescription,
           T1.Role,
           T10.Code AS RoleCode,
           T10.Description AS RoleDescription,
           T1.Info,
           T11.Code AS InfoCode,
           T11.Description AS InfoDescription,
           T1.Meter,
           T22.Code AS MeterCode,
           T22.Description AS MeterDescription,
           T1.MeterValue AS MeterValue,
           T1.Unit,
           T13.Code AS UnitCode,
           T13.Description AS UnitDescription,
           T1.More AS More
      FROM Process AS T1
           LEFT JOIN
           Process AS T4 ON T1.Parent = T4.Id
           LEFT JOIN
           Slice AS T3 ON T1.Slice = T3.Id
           LEFT JOIN
           Face AS T5 ON T1.Face = T5.Id
           LEFT JOIN
           Face AS T6 ON T1.Face1 = T6.Id
           LEFT JOIN
           Face AS T7 ON T1.Face2 = T7.Id
           LEFT JOIN
           Account AS T9 ON T1.Account = T9.Id
           LEFT JOIN
           Role AS T10 ON T1.Role = T10.Id
           LEFT JOIN
           Info AS T11 ON T1.Info = T11.Id
           LEFT JOIN
           Sign AS T12 ON T1.Sign = T12.Id
           LEFT JOIN
           Unit AS T13 ON T1.Unit = T13.Id
           LEFT JOIN
           Debt AS T17 ON T1.Debt = T17.Id
           LEFT JOIN
           Item AS T18 ON T1.Item = T18.Id
           LEFT JOIN
           Deal AS T19 ON T1.Deal = T19.Id
           LEFT JOIN
           Price AS T20 ON T1.Price = T20.Id
           LEFT JOIN
           Asset AS T21 ON T1.Asset = T21.Id
           LEFT JOIN
           Meter AS T22 ON T1.Meter = T22.Id;

-- View: RoleList
CREATE VIEW IF NOT EXISTS RoleList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.More AS More
      FROM Role AS T1
           LEFT JOIN
           Role AS T4 ON T1.Parent = T4.Id;

-- View: SignList
CREATE VIEW IF NOT EXISTS SignList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.Role,
           T10.Code AS RoleCode,
           T10.Description AS RoleDescription,
           T1.Info,
           T11.Code AS InfoCode,
           T11.Description AS InfoDescription,
           T1.More AS More
      FROM Sign AS T1
           LEFT JOIN
           Sign AS T4 ON T1.Parent = T4.Id
           LEFT JOIN
           Role AS T10 ON T1.Role = T10.Id
           LEFT JOIN
           Info AS T11 ON T1.Info = T11.Id;

-- View: SliceList
CREATE VIEW IF NOT EXISTS SliceList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.More AS More
      FROM Slice AS T1
           LEFT JOIN
           Slice AS T4 ON T1.Parent = T4.Id;

-- View: UnitList
CREATE VIEW IF NOT EXISTS UnitList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.Role,
           T10.Code AS RoleCode,
           T10.Description AS RoleDescription,
           T1.More AS More
      FROM Unit AS T1
           LEFT JOIN
           Unit AS T4 ON T1.Parent = T4.Id
           LEFT JOIN
           Role AS T10 ON T1.Role = T10.Id;

-- View: WorkbookList
CREATE VIEW IF NOT EXISTS WorkbookList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Face1,
           T6.Code AS Face1Code,
           T6.Description AS Face1Description,
           T1.Face2,
           T7.Code AS Face2Code,
           T7.Description AS Face2Description,
           T1.Face,
           T5.Code AS FaceCode,
           T5.Description AS FaceDescription,
           T1.Slice,
           T3.Code AS SliceCode,
           T3.Description AS SliceDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.Geo,
           T8.Code AS GeoCode,
           T8.Description AS GeoDescription,
           T1.Sign,
           T12.Code AS SignCode,
           T12.Description AS SignDescription,
           T1.Account,
           T9.Code AS AccountCode,
           T9.Description AS AccountDescription,
           T1.Process,
           T16.Code AS ProcessCode,
           T16.Description AS ProcessDescription,
           T1.Debt,
           T17.Code AS DebtCode,
           T17.Description AS DebtDescription,
           T1.Item,
           T18.Code AS ItemCode,
           T18.Description AS ItemDescription,
           T1.Deal,
           T19.Code AS DealCode,
           T19.Description AS DealDescription,
           T1.Price,
           T20.Code AS PriceCode,
           T20.Description AS PriceDescription,
           T1.Asset,
           T21.Code AS AssetCode,
           T21.Description AS AssetDescription,
           T1.Role,
           T10.Code AS RoleCode,
           T10.Description AS RoleDescription,
           T1.Info,
           T11.Code AS InfoCode,
           T11.Description AS InfoDescription,
           T1.Meter,
           T22.Code AS MeterCode,
           T22.Description AS MeterDescription,
           T1.MeterValue AS MeterValue,
           T1.Unit,
           T13.Code AS UnitCode,
           T13.Description AS UnitDescription,
           T1.Mark,
           T2.Code AS MarkCode,
           T2.Description AS MarkDescription
      FROM Workbook AS T1
           LEFT JOIN
           Workbook AS T4 ON T1.Parent = T4.Id
           LEFT JOIN
           Mark AS T2 ON T1.Mark = T2.Id
           LEFT JOIN
           Slice AS T3 ON T1.Slice = T3.Id
           LEFT JOIN
           Face AS T5 ON T1.Face = T5.Id
           LEFT JOIN
           Face AS T6 ON T1.Face1 = T6.Id
           LEFT JOIN
           Face AS T7 ON T1.Face2 = T7.Id
           LEFT JOIN
           Geo AS T8 ON T1.Geo = T8.Id
           LEFT JOIN
           Account AS T9 ON T1.Account = T9.Id
           LEFT JOIN
           Role AS T10 ON T1.Role = T10.Id
           LEFT JOIN
           Info AS T11 ON T1.Info = T11.Id
           LEFT JOIN
           Sign AS T12 ON T1.Sign = T12.Id
           LEFT JOIN
           Unit AS T13 ON T1.Unit = T13.Id
           LEFT JOIN
           Process AS T16 ON T1.Process = T16.Id
           LEFT JOIN
           Debt AS T17 ON T1.Debt = T17.Id
           LEFT JOIN
           Item AS T18 ON T1.Item = T18.Id
           LEFT JOIN
           Deal AS T19 ON T1.Deal = T19.Id
           LEFT JOIN
           Price AS T20 ON T1.Price = T20.Id
           LEFT JOIN
           Asset AS T21 ON T1.Asset = T21.Id
           LEFT JOIN
           Meter AS T22 ON T1.Meter = T22.Id;
 

foreign key(Parent) references Account(Id),
             foreign key(Slice) references Slice(Id),
             foreign key(Role) references Role(Id),
             foreign key(Sign) references Sign(Id)
             
 foreign key(Parent) references Asset(Id),
             foreign key(Geo) references Geo(Id),
             foreign key(Role) references Role(Id),
             foreign key(Info) references Info(Id),
             foreign key(Unit) references Unit(Id)
             
foreign key(Parent) references Deal(Id),
             foreign key(Face1) references Face(Id),
             foreign key(Face2) references Face(Id),
             foreign key(Face) references Face(Id),
             foreign key(Geo) references Geo(Id),
             foreign key(Role) references Role(Id),
             foreign key(Info) references Info(Id)
             
foreign key(Parent) references Debt(Id),
             foreign key(Geo) references Geo(Id),
             foreign key(Role) references Role(Id),
             foreign key(Info) references Info(Id)
             
foreign key(Parent) references Face(Id),
             foreign key(Geo) references Geo(Id),
             foreign key(Role) references Role(Id),
             foreign key(Info) references Info(Id)
             
foreign key(Parent) references Geo(Id),
             foreign key(Unit) references Unit(Id)
             
foreign key(Parent) references Info(Id)

foreign key(Parent) references Item(Id)

foreign key(Parent) references Mark(Id)

foreign key(Parent) references Meter(Id),
             foreign key(Unit) references Unit(Id)
             
foreign key(Parent) references Price(Id),
             foreign key(Role) references Role(Id),
             foreign key(Info) references Info(Id),
             foreign key(Unit) references Unit(Id)
             
foreign key(Parent) references Process(Id),
             foreign key(Face1) references Face(Id),
             foreign key(Face2) references Face(Id),
             foreign key(Face) references Face(Id),
             foreign key(Slice) references Slice(Id),
             foreign key(Sign) references Sign(Id),
             foreign key(Account) references Account(Id),
             foreign key(Asset) references Asset(Id),
             foreign key(Deal) references Deal(Id),
             foreign key(Item) references Item(Id),
             foreign key(Debt) references Debt(Id),
             foreign key(Price) references Price(Id),
             foreign key(Role) references Role(Id),
             foreign key(Info) references Info(Id),
             foreign key(Meter) references Meter(Id),
             foreign key(Unit) references Unit(Id),
             foreign key(Mark) references Mark(Id)
             
foreign key(Parent) references Role(Id)

foreign key(Parent) references Sign(Id),
             foreign key(Role) references Role(Id),
             foreign key(Info) references Info(Id)
             
foreign key(Parent) references Slice(Id)

foreign key(Parent) references Unit(Id),
             foreign key(Role) references Role(Id)
             
foreign key(Parent) references Workbook(Id),
             foreign key(Face1) references Face(Id),
             foreign key(Face2) references Face(Id),
             foreign key(Face) references Face(Id),
             foreign key(Slice) references Slice(Id),
            foreign key(Geo) references Geo(Id),
             foreign key(Sign) references Sign(Id),
             foreign key(Account) references Account(Id),
             foreign key(Process) references Process(Id),
             foreign key(Asset) references Asset(Id),
             foreign key(Deal) references Deal(Id),
             foreign key(Item) references Item(Id),
             foreign key(Debt) references Debt(Id),
             foreign key(Price) references Price(Id),
             foreign key(Role) references Role(Id),
             foreign key(Info) references Info(Id),
             foreign key(Meter) references Meter(Id),
             foreign key(Unit) references Unit(Id),
             foreign key(Mark) references Mark(Id)

--COMMIT TRANSACTION;
--PRAGMA foreign_keys = on;