﻿--Курсаков С.А. https://github.com/KursakovSA/AccBase 

--PRAGMA foreign_keys = off;
--BEGIN TRANSACTION;

foreign key(Parent) references Account(Id),
             foreign key(Slice) references Slice(Id),
             foreign key(Role) references Role(Id),
             foreign key(Sign) references Sign(Id)
             
 foreign key(Parent) references Asset(Id),
             foreign key(Geo) references Geo(Id),
             foreign key(Role) references Role(Id),
             foreign key(Info) references Info(Id),
             foreign key(Unit) references Unit(Id)
             
foreign key(Parent) references Deal(Id),
             foreign key(Face1) references Face(Id),
             foreign key(Face2) references Face(Id),
             foreign key(Face) references Face(Id),
             foreign key(Geo) references Geo(Id),
             foreign key(Role) references Role(Id),
             foreign key(Info) references Info(Id)
             
foreign key(Parent) references Debt(Id),
             foreign key(Geo) references Geo(Id),
             foreign key(Role) references Role(Id),
             foreign key(Info) references Info(Id)
             
foreign key(Parent) references Face(Id),
             foreign key(Geo) references Geo(Id),
             foreign key(Role) references Role(Id),
             foreign key(Info) references Info(Id)
             
foreign key(Parent) references Geo(Id),
             foreign key(Unit) references Unit(Id)
             
foreign key(Parent) references Info(Id)

foreign key(Parent) references Item(Id)

foreign key(Parent) references Mark(Id)

foreign key(Parent) references Meter(Id),
             foreign key(Unit) references Unit(Id)
             
foreign key(Parent) references Price(Id),
             foreign key(Role) references Role(Id),
             foreign key(Info) references Info(Id),
             foreign key(Unit) references Unit(Id)
             
foreign key(Parent) references Process(Id),
             foreign key(Face1) references Face(Id),
             foreign key(Face2) references Face(Id),
             foreign key(Face) references Face(Id),
             foreign key(Slice) references Slice(Id),
             foreign key(Sign) references Sign(Id),
             foreign key(Account) references Account(Id),
             foreign key(Asset) references Asset(Id),
             foreign key(Deal) references Deal(Id),
             foreign key(Item) references Item(Id),
             foreign key(Debt) references Debt(Id),
             foreign key(Price) references Price(Id),
             foreign key(Role) references Role(Id),
             foreign key(Info) references Info(Id),
             foreign key(Meter) references Meter(Id),
             foreign key(Unit) references Unit(Id),
             foreign key(Mark) references Mark(Id)
             
foreign key(Parent) references Role(Id)

foreign key(Parent) references Sign(Id),
             foreign key(Role) references Role(Id),
             foreign key(Info) references Info(Id)
             
foreign key(Parent) references Slice(Id)

foreign key(Parent) references Unit(Id),
             foreign key(Role) references Role(Id)
             
foreign key(Parent) references Workbook(Id),
             foreign key(Face1) references Face(Id),
             foreign key(Face2) references Face(Id),
             foreign key(Face) references Face(Id),
             foreign key(Slice) references Slice(Id),
            foreign key(Geo) references Geo(Id),
             foreign key(Sign) references Sign(Id),
             foreign key(Account) references Account(Id),
             foreign key(Process) references Process(Id),
             foreign key(Asset) references Asset(Id),
             foreign key(Deal) references Deal(Id),
             foreign key(Item) references Item(Id),
             foreign key(Debt) references Debt(Id),
             foreign key(Price) references Price(Id),
             foreign key(Role) references Role(Id),
             foreign key(Info) references Info(Id),
             foreign key(Meter) references Meter(Id),
             foreign key(Unit) references Unit(Id),
             foreign key(Mark) references Mark(Id)

--COMMIT TRANSACTION;
--PRAGMA foreign_keys = on;