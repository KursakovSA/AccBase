--
-- File generated with SQLiteStudio v3.4.3 on Сб фев 25 14:14:12 2023
--
-- Text encoding used: UTF-8
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Table: Info
CREATE TABLE Info (
    Id          INTEGER PRIMARY KEY ASC AUTOINCREMENT,
    Parent      INTEGER
                        REFERENCES Info (Id),
    Date1       TEXT    DEFAULT CURRENT_TIMESTAMP,
    Date2       TEXT,
    Code        TEXT    NOT NULL
                        UNIQUE,
    Description TEXT    NOT NULL,
    More        TEXT
);

INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (1, '', '', '', 'Info.', 'InfoData', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (2, 1, '', '', 'Info.Address', 'Address', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (3, 2, '', '', 'Info.Address.Home', 'домашний', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (4, 2, '', '', 'Info.Address.Law', 'юридический', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (5, 2, '', '', 'Info.Address.Post', 'почтовый', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (6, 2, '', '', 'Info.Address.Reg', 'прописки (регистрации)', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (7, 1, '', '', 'Info.Asset', 'Asset', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (8, 7, '', '', 'Info.Asset.Asset', 'актив', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (9, 7, '', '', 'Info.Asset.Catalog', 'каталог активов', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (10, 7, '', '', 'Info.Asset.SubAsset', 'субактив', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (11, 1, '', '', 'Info.Code', 'Code', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (12, 11, '', '', 'Info.Code.Alfa3', 'альфа3 код', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (13, 11, '', '', 'Info.Code.Art', 'артикул', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (14, 11, '', '', 'Info.Code.BIC', 'БИК (BIC)', '{"FullName": "Банковский идентификационный код","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (15, 11, '', '', 'Info.Code.EAN', 'EAN код', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (16, 11, '', '', 'Info.Code.IBAN', 'IBAN (ИИК)', '{FullName": "IBAN","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (17, 11, '', '', 'Info.Code.KBE', 'КБЕ', '{"FullName": "Код бенефициара","AbcBasic": "Info.Basic","AbcCodePay": "Tax.CodePay"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (18, 11, '', '', 'Info.Code.KBK', 'КБК', '{"FullName": "Код бюджетной классификации","AbcBasic": "Info.Basic","AbcCodePay": "Tax.CodePay"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (19, 11, '', '', 'Info.Code.KNP', 'КНП', '{"FullName": "Код назначения платежа","AbcBasic": "Info.Basic","AbcCodePay": "Tax.CodePay"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (20, 11, '', '', 'Info.Code.KOF', 'код КОФ', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (21, 11, '', '', 'Info.Code.KPVED', 'код КПВЭД', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (22, 11, '', '', 'Info.Code.MKEI', 'код МКЕИ', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (23, 11, '', '', 'Info.Code.OKPO', 'код ОКПО', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (24, 11, '', '', 'Info.Code.Post', 'почтовый код РК', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (25, 11, '', '', 'Info.Code.TNVED', 'код ТНВЭД', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (26, 11, '', '', 'Info.Code.VIN', 'VIN код', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (27, 1, '', '', 'Info.Cost', 'Cost', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (28, 27, '', '', 'Info.Cost.Accounting', 'бухгалтерская себестоимость', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (29, 27, '', '', 'Info.Cost.Standard', 'нормативная (стандартная) себестоимость', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (30, 27, '', '', 'Info.Cost.Store', 'складская себестоимость', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (31, 1, '', '', 'Info.Deal', 'Deal', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (32, 31, '', '', 'Info.Deal.Alimony', 'алименты', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (33, 31, '', '', 'Info.Deal.ContractWork', 'подрядные работы', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (34, 31, '', '', 'Info.Deal.GFSS', 'ГФСС', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (35, 31, '', '', 'Info.Deal.GSVP', 'НАО-ГЦВП', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (36, 31, '', '', 'Info.Deal.Loan', 'займ, кредит', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (37, 31, '', '', 'Info.Deal.Main', 'купля-продажа', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (38, 31, '', '', 'Info.Deal.MinistryLabor', 'МТиСЗН', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (39, 31, '', '', 'Info.Deal.OSMS', 'ОСМС', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (40, 31, '', '', 'Info.Deal.ProductionOrder', 'заказ производства', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (41, 31, '', '', 'Info.Deal.Rent', 'аренда', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (42, 31, '', '', 'Info.Deal.Staff', 'трудовой', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (43, 1, '', '', 'Info.Entity', 'Entity', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (44, 43, '', '', 'Info.Entity.Doc', 'документ-журнал', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (45, 43, '', '', 'Info.Entity.Journal', 'журнал документов', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (46, 43, '', '', 'Info.Entity.MainForm', 'основная входная форма', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (47, 43, '', '', 'Info.Entity.Reference', 'справочник', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (48, 1, '', '', 'Info.ExchangeRate', 'ExchangeRate', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (49, 48, '', '', 'Info.ExchangeRate.Bank', 'курс комм банка', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (50, 48, '', '', 'Info.ExchangeRate.Market', 'рыночный курс', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (51, 48, '', '', 'Info.ExchangeRate.NationalBank', 'курс Нацбанка', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (52, 48, '', '', 'Info.ExchangeRate.Stock', 'курс биржи', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (53, 1, '', '', 'Info.Face', 'Face', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (54, 53, '', '', 'Info.Face.Branch', 'филиал', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (55, 53, '', '', 'Info.Face.Businessman', 'ИП', '{"FullName": "Индивидуальный предприниматель","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (56, 53, '', '', 'Info.Face.Corp', 'ТОО', '{"FullName": "Товарищество с ограниченной ответственностью","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (57, 53, '', '', 'Info.Face.GovAgency', 'ГУ', '{"FullName": "Государственное учреждение","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (58, 53, '', '', 'Info.Face.JointStockCompany', 'АО', '{"FullName": "Акционерное общество","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (59, 53, '', '', 'Info.Face.LegalEntity', 'юридическое лицо', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (60, 53, '', '', 'Info.Face.Person', 'физическое лицо', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (61, 53, '', '', 'Info.Face.QuasiGov1', 'РГКП', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (62, 53, '', '', 'Info.Face.QuasiGov2', 'КГКП', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (63, 53, '', '', 'Info.Face.User', 'пользователь', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (64, 1, '', '', 'Info.Generic', 'Generic', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (65, 64, '', '', 'Info.Generic.Cell', 'телефон сотовый', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (66, 64, '', '', 'Info.Generic.Description', 'расшифровка', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (67, 64, '', '', 'Info.Generic.Email', 'емайл', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (68, 64, '', '', 'Info.Generic.Extra', 'необычный', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (69, 64, '', '', 'Info.Generic.FullDescription', 'полное описание', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (70, 64, '', '', 'Info.Generic.FullName', 'полное наименование', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (71, 64, '', '', 'Info.Generic.Workbooko', 'логотип', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (72, 64, '', '', 'Info.Generic.Main', 'общая инфо', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (73, 64, '', '', 'Info.Generic.Phone', 'телефон', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (74, 64, '', '', 'Info.Generic.Photo', 'фото', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (75, 64, '', '', 'Info.Generic.Sert', 'ключ, сертификат', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (76, 64, '', '', 'Info.Generic.ShortDescription', 'краткое описание', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (77, 64, '', '', 'Info.Generic.ShortName', 'сокращенное наименование', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (78, 64, '', '', 'Info.Generic.Site', 'сайт', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (79, 64, '', '', 'Info.Generic.Street-House', 'улица, дом', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (80, 64, '', '', 'Info.Generic.Time', 'время', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (81, 64, '', '', 'Info.Generic.Variant', 'вариант', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (82, 1, '', '', 'Info.Item', 'Item', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (83, 82, '', '', 'Info.Item.Financial', 'финансовая деятельность', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (84, 82, '', '', 'Info.Item.Invest', 'инвестиционная деятельность', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (85, 82, '', '', 'Info.Item.Main', 'операционная деятельность', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (86, 1, '', '', 'Info.List', 'List', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (87, 86, '', '', 'Info.List.ExemptionList', 'Перечень изъятий', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (88, 86, '', '', 'Info.List.StopList', 'Стоп-лист по отгрузке', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (89, 1, '', '', 'Info.Workbook', 'Workbook', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (90, 89, '', '', 'Info.Workbook.Deal.Devivery', 'поставка договора', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (91, 89, '', '', 'Info.Workbook.Deal.Movement', 'движения договора', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (92, 89, '', '', 'Info.Workbook.Level0.Main', 'Workbook.Level0.общее', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (93, 89, '', '', 'Info.Workbook.Level1.Amount', 'Workbook.Level1.сумма', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (94, 89, '', '', 'Info.Workbook.Level1.Cost', 'Workbook.Level1.себ-ть сумма', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (95, 89, '', '', 'Info.Workbook.Level1.Price', 'Workbook.Level1.цена', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (96, 89, '', '', 'Info.Workbook.Level1.Quantity', 'Workbook.Level1.кол-во', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (97, 89, '', '', 'Info.Workbook.Level2.Depreciation', 'Workbook.Level2.аморт-я', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (98, 89, '', '', 'Info.Workbook.Level2.TaxExcess', 'Workbook.Level2.налоги сверх суммы', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (99, 89, '', '', 'Info.Workbook.Level2.TaxTotal', 'Workbook.Level2.налоги в сумме', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (100, 1, '', '', 'Info.Management', 'Management', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (101, 100, '', '', 'Info.Management.Boss', 'директор', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (102, 100, '', '', 'Info.Management.Chief', 'начальник', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (103, 100, '', '', 'Info.Management.Driver', 'водитель', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (104, 100, '', '', 'Info.Management.LeadingSpecialist', 'ведущий специалист', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (105, 100, '', '', 'Info.Management.Manager', 'управляющий', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (106, 100, '', '', 'Info.Management.Responsible', 'ответственный', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (107, 1, '', '', 'Info.Math', 'Math', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (108, 107, '', '', 'Info.Math.Round1.5To1', 'округлять 1,5 до 1', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (109, 107, '', '', 'Info.Math.Round1.5To2', 'округлять 1,5 до 2', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (110, 107, '', '', 'Info.Math.RoundDownward', 'округлять всегда в меньшую сторону', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (111, 107, '', '', 'Info.Math.RoundUpward', 'округлять всегда в большую сторону', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (112, 1, '', '', 'Info.PersonData', 'PersonData', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (113, 112, '', '', 'Info.PersonData.Autobiography', 'автобиография', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (114, 112, '', '', 'Info.PersonData.DateBirth', 'дата рождения', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (115, 112, '', '', 'Info.PersonData.Name', 'имя', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (116, 112, '', '', 'Info.PersonData.Nationality', 'национальность', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (117, 112, '', '', 'Info.PersonData.Patronymic', 'отчество', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (118, 112, '', '', 'Info.PersonData.Resume', 'резюме', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (119, 112, '', '', 'Info.PersonData.Surname', 'фамилия', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (120, 1, '', '', 'Info.Profile', 'Profile', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (121, 120, '', '', 'Info.Profile.Main', 'общий профиль', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (122, 120, '', '', 'Info.Profile.Store', 'профиль склад', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (123, 120, '', '', 'Info.Profile.PropertyManagement', 'профиль КСК', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (124, 1, '', '', 'Info.Rate', 'Rate', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (125, 124, '', '', 'Info.Rate.MinRate', 'МРП', '{"FullName": "минимальный расчетный показатель","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (126, 124, '', '', 'Info.Rate.MinSalary', 'Мин ЗП', '{"FullName": "минимальная заработная плата","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (127, 1, '', '', 'Info.RegData', 'RegData', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (128, 127, '', '', 'Info.RegData.BIN', 'БИН', '{"FullName": "Бизнес-идентификационный номер","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (129, 127, '', '', 'Info.RegData.IIN', 'ИИН', '{"FullName": "Индивидуально-идентификационный номер","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (130, 127, '', '', 'Info.RegData.Passport', 'паспорт РК', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (131, 127, '', '', 'Info.RegData.RNN', 'РНН', '{"FullName": "Регистрационный номер налогоплательщика","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (132, 1, '', '', 'Info.Relation', 'Relation', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (133, 132, '', '', 'Info.Relation.Alimonier', 'получатель алиментов', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (134, 132, '', '', 'Info.Relation.MainCalc', 'основной пересчет', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (135, 132, '', '', 'Info.Relation.Pensioner', 'пенсионер', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (136, 1, '', '', 'Info.Report', 'Отчет', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (137, 136, '', '', 'Info.Report.Analysis', 'анализ', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (138, 136, '', '', 'Info.Report.Balance', 'остатки', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (139, 136, '', '', 'Info.Report.BalanceTurnover', 'остатки и обороты', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (140, 136, '', '', 'Info.Report.Depreciation', 'расчет амортизации', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (141, 136, '', '', 'Info.Report.Detail', 'карточка', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (142, 136, '', '', 'Info.Report.DocLawForm', 'нормативная форма документа', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (143, 136, '', '', 'Info.Report.FinForm', 'фин отчет', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (144, 143, '', '', 'Info.Report.FinForm.Balance', 'баланс', '{"FullName": "Бухгалтерский баланс","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (145, 143, '', '', 'Info.Report.FinForm.Capital', 'капитал', '{"FullName": "Отчет о движении капитала","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (146, 143, '', '', 'Info.Report.FinForm.Income', 'доход', '{"FullName": "Отчет о доходах и расходах","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (147, 143, '', '', 'Info.Report.FinForm.Money', 'деньги', '{"FullName": "Отчет о движении денег","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (148, 136, '', '', 'Info.Report.List', 'список', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (149, 136, '', '', 'Info.Report.PaySheet', 'реестр платежей', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (150, 136, '', '', 'Info.Report.PriceList', 'прайс-лист', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (151, 136, '', '', 'Info.Report.Revise', 'акт сверки', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (152, 136, '', '', 'Info.Report.SalaryInquery', 'справка по зарплате', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (153, 136, '', '', 'Info.Report.SalarySheet', 'расчетная ведомость начисления ЗП', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (154, 136, '', '', 'Info.Report.SalarySummary', 'свод зарплаты', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (155, 136, '', '', 'Info.Report.Sheet', 'ведомость', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (156, 136, '', '', 'Info.Report.StaffDoc', 'кадровый приказ', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (157, 136, '', '', 'Info.Report.TaxForm', 'налог отчет', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (158, 136, '', '', 'Info.Report.TaxRegistry', 'налог регистр', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (159, 1, '', '', 'Info.Sign', 'Sign', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (160, 159, '', '', 'Info.Sign.UseAccTable', 'использовать в плане счетов', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (161, 159, '', '', 'Info.Sign.UseEntry', 'использовать в проводках', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (162, 1, '', '', 'Info.Staff', 'Staff', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (163, 162, '', '', 'Info.Staff.BaseSalary', 'базовый оклад', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (164, 162, '', '', 'Info.Staff.BossSign', 'подпись руководителя', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (165, 162, '', '', 'Info.Staff.ChiefAccountantSign', 'подпись глав бухгалтера', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (166, 1, '', '', 'Info.StaffTime', 'StaffTime', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (167, 166, '', '', 'Info.StaffTime.DayOff', 'выходной день', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (168, 166, '', '', 'Info.StaffTime.Holiday', 'праздничный день', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (169, 1, '', '', 'Info.Store', 'Store', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (170, 169, '', '', 'Info.Store.CoreFund', 'основное средство', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (171, 169, '', '', 'Info.Store.IsDriveLaw', 'есть право вождения', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (172, 169, '', '', 'Info.Store.IsSubStore', 'является субскладом', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (173, 169, '', '', 'Info.Store.NoStoreNoTraffic', 'не требует транспортировки и складирования', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (174, 1, '', '', 'Info.Tax', 'Tax', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (175, 174, '', '', 'Info.Tax.Amount', 'налоговая сумма', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (176, 174, '', '', 'Info.Tax.Base', 'налоговая база', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (177, 174, '', '', 'Info.Tax.BaseDeduction', 'вычет налоговой базы', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (178, 174, '', '', 'Info.Tax.BaseException', 'исключение базы', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (179, 174, '', '', 'Info.Tax.BaseLimit', 'лимит базы', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (180, 174, '', '', 'Info.Tax.Deduction.MinSalary', 'вычет МинЗП', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (181, 174, '', '', 'Info.Tax.Deduction.OPV', 'вычет ОПВ', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (182, 174, '', '', 'Info.Tax.HalfYearReportingCycle', 'полугодовой отчетный цикл', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (183, 174, '', '', 'Info.Tax.MonthBillingCycle', 'месячный расчетный цикл', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (184, 174, '', '', 'Info.Tax.MonthYearBillingCycle', 'месячно-годовой расчетный цикл', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (185, 174, '', '', 'Info.Tax.QuarterBillingCycle', 'квартальный расчетный цикл', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (186, 174, '', '', 'Info.Tax.QuarterReportingCycle', 'квартальный отчетный цикл', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (187, 174, '', '', 'Info.Tax.RateFree', 'освобожденная ставка', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (188, 174, '', '', 'Info.Tax.RateBasic', 'основная ставка', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (189, 174, '', '', 'Info.Tax.RateReduce', 'сниженная ставка', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (190, 174, '', '', 'Info.Tax.RateZero', 'нулевая ставка', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (191, 174, '', '', 'Info.Tax.SNMinusGFSS', 'корректировка СН на ГФСС', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (192, 174, '', '', 'Info.Tax.TaxAdjustment', 'налоговая корректировка', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (193, 174, '', '', 'Info.Tax.YearBillingCycle', 'годовой расчетный цикл', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (194, 174, '', '', 'Info.Tax.YearReportingCycle', 'годовой отчетный цикл', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (195, 174, '', '', 'Info.Tax.RateLess', 'безналоговая ставка', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (196, 174, '', '', 'Info.Tax.FactBillingCycle', 'фактический расчетный цикл', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (197, 174, '', '', 'Info.Tax.FactReportingCycle', 'фактический отчетный цикл', '{"AbcBasic": "Info.Basic"}');

-- View: AccountList
CREATE VIEW AccountList AS
    SELECT Account.Id,
           Account.Parent,
           Account2.Code AS ParentCode,
           Account2.Description AS ParentDescription,
           Account.Slice,
           Slice.Code AS SliceCode,
           Slice.Description AS SliceDescription,
           Account.Date1 AS Date1,
           Account.Date2 AS Date2,
           Account.Code AS Code,
           Account.Description AS Description,
           Account.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Account.Sign,
           Sign.Code AS SignCode,
           Sign.Description AS SignDescription,
           Account.More AS More
      FROM Account AS Account
           LEFT JOIN
           Account AS Account2 ON Account.Parent = Account2.Id
           LEFT JOIN
           Slice AS Slice ON Account.Slice = Slice.Id
           LEFT JOIN
           Role AS Role ON Account.Role = Role.Id
           LEFT JOIN
           Sign AS Sign ON Account.Sign = Sign.Id;


-- View: AssetList
CREATE VIEW AssetList AS
    SELECT Asset.Id,
           Asset.Parent,
           Asset2.Code AS ParentCode,
           Asset2.Description AS ParentDescription,
           Asset.Date1 AS Date1,
           Asset.Date2 AS Date2,
           Asset.Code,
           Asset.Description,
           Asset.Geo,
           Geo.Code AS GeoCode,
           Geo.Description AS GeoDescription,
           Asset.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Asset.Info,
           Info.Code AS InfoCode,
           Info.Description AS InfoDescription,
           Asset.Unit,
           Unit.Code AS UnitCode,
           Unit.Description AS UnitDescription,
           Asset.More AS More
      FROM Asset AS Asset
           LEFT JOIN
           Asset AS Asset2 ON Asset.Parent = Asset2.Id
           LEFT JOIN
           Geo AS Geo ON Asset.Geo = Geo.Id
           LEFT JOIN
           Role AS Role ON Asset.Role = Role.Id
           LEFT JOIN
           Info AS Info ON Asset.Info = Info.Id
           LEFT JOIN
           Unit AS Unit ON Asset.Unit = Unit.Id;


-- View: DealList
CREATE VIEW DealList AS
    SELECT Deal.Id,
           Deal.Parent,
           Deal2.Code AS ParentCode,
           Deal2.Description AS ParentDescription,
           Deal.Face1,
           Face1.Code AS Face1Code,
           Face1.Description AS Face1Description,
           Deal.Face2,
           Face2.Code AS Face2Code,
           Face2.Description AS Face2Description,
           Deal.Face,
           Face.Code AS FaceCode,
           Face.Description AS FaceDescription,
           Deal.Date1 AS Date1,
           Deal.Date2 AS Date2,
           Deal.Code AS Code,
           Deal.Description AS Description,
           Deal.Geo,
           Geo.Code AS GeoCode,
           Geo.Description AS GeoDescription,
           Deal.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Deal.Info,
           Info.Code AS InfoCode,
           Info.Description AS InfoDescription,
           Deal.More AS More
      FROM Deal AS Deal
           LEFT JOIN
           Deal AS Deal2 ON Deal.Parent = Deal2.Id
           LEFT JOIN
           Face AS Face ON Deal.Face = Face.Id
           LEFT JOIN
           Face AS Face1 ON Deal.Face1 = Face1.Id
           LEFT JOIN
           Face AS Face2 ON Deal.Face2 = Face2.Id
           LEFT JOIN
           Geo AS Geo ON Deal.Geo = Geo.Id
           LEFT JOIN
           Role AS Role ON Deal.Role = Role.Id
           LEFT JOIN
           Info AS Info ON Deal.Info = Info.Id;


-- View: DebtList
CREATE VIEW DebtList AS
    SELECT Debt.Id,
           Debt.Parent,
           Debt2.Code AS ParentCode,
           Debt2.Description AS ParentDescription,
           Debt.Date1 AS Date1,
           Debt.Date2 AS Date2,
           Debt.Code AS Code,
           Debt.Description AS Description,
           Debt.Geo,
           Geo.Code AS GeoCode,
           Geo.Description AS GeoDescription,
           Debt.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Debt.Info,
           Info.Code AS InfoCode,
           Info.Description AS InfoDescription,
           Debt.More AS More
      FROM Debt AS Debt
           LEFT JOIN
           Debt AS Debt2 ON Debt.Parent = Debt2.Id
           LEFT JOIN
           Geo AS Geo ON Debt.Geo = Geo.Id
           LEFT JOIN
           Role AS Role ON Debt.Role = Role.Id
           LEFT JOIN
           Info AS Info ON Debt.Info = Info.Id;


-- View: FaceList
CREATE VIEW FaceList AS
    SELECT Face.Id,
           Face.Parent,
           Face2.Code AS ParentCode,
           Face2.Description AS ParentDescription,
           Face.Date1 AS Date1,
           Face.Date2 AS Date2,
           Face.Code AS Code,
           Face.Description AS Description,
           Face.Geo,
           Geo.Code AS GeoCode,
           Geo.Description AS GeoDescription,
           Face.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Face.Info,
           Info.Code AS InfoCode,
           Info.Description AS InfoDescription,
           Face.More AS More
      FROM Face AS Face
           LEFT JOIN
           Face AS Face2 ON Face.Parent = Face2.Id
           LEFT JOIN
           Geo AS Geo ON Face.Geo = Geo.Id
           LEFT JOIN
           Role AS Role ON Face.Role = Role.Id
           LEFT JOIN
           Info AS Info ON Face.Info = Info.Id;


-- View: GeoList
CREATE VIEW GeoList AS
    SELECT Geo.Id,
           Geo.Parent,
           Geo2.Code AS ParentCode,
           Geo2.Description AS ParentDescription,
           Geo.Date1 AS Date1,
           Geo.Date2 AS Date2,
           Geo.Code AS Code,
           Geo.Description AS Description,
           Geo.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Geo.Unit,
           Unit.Code AS UnitCode,
           Unit.Description AS UnitDescription,
           Geo.More AS More
      FROM Geo AS Geo
           LEFT JOIN
           Geo AS Geo2 ON Geo.Parent = Geo2.Id
           LEFT JOIN
           Role AS Role ON Geo.Role = Role.Id
           LEFT JOIN
           Unit AS Unit ON Geo.Unit = Unit.Id;


-- View: InfoList
CREATE VIEW InfoList AS
    SELECT Info.Id,
           Info.Parent,
           Info2.Code AS ParentCode,
           Info2.Description AS ParentDescription,
           Info.Date1 AS Date1,
           Info.Date2 AS Date2,
           Info.Code AS Code,
           Info.Description AS Description,
           Info.More AS More
      FROM Info AS Info
           LEFT JOIN
           Info AS Info2 ON Info.Parent = Info2.Id;


-- View: ItemList
CREATE VIEW ItemList AS
    SELECT Item.Id,
           Item.Parent,
           Item2.Code AS ParentCode,
           Item2.Description AS ParentDescription,
           Item.Date1 AS Date1,
           Item.Date2 AS Date2,
           Item.Code AS Code,
           Item.Description AS Description,
           Item.More AS More
      FROM Item AS Item
           LEFT JOIN
           Item AS Item2 ON Item.Parent = Item2.Id;


-- View: MarkList
CREATE VIEW MarkList AS
    SELECT Mark.Id,
           Mark.Parent,
           Mark2.Code AS ParentCode,
           Mark2.Description AS ParentDescription,
           Mark.Date1 AS Date1,
           Mark.Date2 AS Date2,
           Mark.Code AS Code,
           Mark.Description AS Description,
           Mark.More AS More
      FROM Mark AS Mark
           LEFT JOIN
           Mark AS Mark2 ON Mark.Parent = Mark2.Id;


-- View: MeterList
CREATE VIEW MeterList AS
    SELECT Meter.Id,
           Meter.Parent,
           Meter2.Code AS ParentCode,
           Meter2.Description AS ParentDescription,
           Meter.Date1 AS Date1,
           Meter.Date2 AS Date2,
           Meter.Code AS Code,
           Meter.Description AS Description,
           Meter.More AS More
      FROM Meter AS Meter
           LEFT JOIN
           Meter AS Meter2 ON Meter.Parent = Meter2.Id;


-- View: PriceList
CREATE VIEW PriceList AS
    SELECT Price.Id,
           Price.Parent,
           Price2.Code AS ParentCode,
           Price2.Description AS ParentDescription,
           Price.Date1 AS Date1,
           Price.Date2 AS Date2,
           Price.Code AS Code,
           Price.Description AS Description,
           Price.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Price.Info,
           Info.Code AS InfoCode,
           Info.Description AS InfoDescription,
           Price.Unit,
           Unit.Code AS UnitCode,
           Unit.Description AS UnitDescription,
           Price.More AS More
      FROM Price AS Price
           LEFT JOIN
           Price AS Price2 ON Price.Parent = Price2.Id
           LEFT JOIN
           Role AS Role ON Price.Role = Role.Id
           LEFT JOIN
           Info AS Info ON Price.Info = Info.Id
           LEFT JOIN
           Unit AS Unit ON Price.Unit = Unit.Id;


-- View: ProcessList
CREATE VIEW ProcessList AS
    SELECT Process.Id,
           Process.Parent,
           Process2.Code AS ParentCode,
           Process2.Description AS ParentDescription,
           Process.Face1,
           Face1.Code AS Face1Code,
           Face1.Description AS Face1Description,
           Process.Face2,
           Face2.Code AS Face2Code,
           Face2.Description AS Face2Description,
           Process.Face,
           Face.Code AS FaceCode,
           Face.Description AS FaceDescription,
           Process.Slice,
           Slice.Code AS SliceCode,
           Slice.Description AS SliceDescription,
           Process.Date1 AS Date1,
           Process.Date2 AS Date2,
           Process.Code AS Code,
           Process.Description AS Description,
           Process.Sign,
           Sign.Code AS SignCode,
           Sign.Description AS SignDescription,
           Process.Account,
           T9.Code AS AccountCode,
           T9.Description AS AccountDescription,
           Process.Asset,
           Asset.Code AS AssetCode,
           Asset.Description AS AssetDescription,
           Process.Deal,
           Deal.Code AS DealCode,
           Deal.Description AS DealDescription,
           Process.Item,
           Item.Code AS ItemCode,
           Item.Description AS ItemDescription,
           Process.Debt,
           Debt.Code AS DebtCode,
           Debt.Description AS DebtDescription,
           Process.Price,
           Price.Code AS PriceCode,
           Price.Description AS PriceDescription,
           Process.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Process.Info,
           Info.Code AS InfoCode,
           Info.Description AS InfoDescription,
           Process.Meter,
           Meter.Code AS MeterCode,
           Meter.Description AS MeterDescription,
           Process.MeterValue AS MeterValue,
           Process.Unit,
           Unit.Code AS UnitCode,
           Unit.Description AS UnitDescription,
           Process.More AS More
      FROM Process AS Process
           LEFT JOIN
           Process AS Process2 ON Process.Parent = Process2.Id
           LEFT JOIN
           Slice AS Slice ON Process.Slice = Slice.Id
           LEFT JOIN
           Face AS Face ON Process.Face = Face.Id
           LEFT JOIN
           Face AS Face1 ON Process.Face1 = Face1.Id
           LEFT JOIN
           Face AS Face2 ON Process.Face2 = Face2.Id
           LEFT JOIN
           Account AS T9 ON Process.Account = T9.Id
           LEFT JOIN
           Role AS Role ON Process.Role = Role.Id
           LEFT JOIN
           Info AS Info ON Process.Info = Info.Id
           LEFT JOIN
           Sign AS Sign ON Process.Sign = Sign.Id
           LEFT JOIN
           Unit AS Unit ON Process.Unit = Unit.Id
           LEFT JOIN
           Debt AS Debt ON Process.Debt = Debt.Id
           LEFT JOIN
           Item AS Item ON Process.Item = Item.Id
           LEFT JOIN
           Deal AS Deal ON Process.Deal = Deal.Id
           LEFT JOIN
           Price AS Price ON Process.Price = Price.Id
           LEFT JOIN
           Asset AS Asset ON Process.Asset = Asset.Id
           LEFT JOIN
           Meter AS Meter ON Process.Meter = Meter.Id;


-- View: RoleList
CREATE VIEW RoleList AS
    SELECT Role.Id,
           Role.Parent,
           Role2.Code AS ParentCode,
           Role2.Description AS ParentDescription,
           Role.Date1 AS Date1,
           Role.Date2 AS Date2,
           Role.Code AS Code,
           Role.Description AS Description,
           Role.More AS More
      FROM Role AS Role
           LEFT JOIN
           Role AS Role2 ON Role.Parent = Role2.Id;


-- View: SignList
CREATE VIEW SignList AS
    SELECT Sign.Id,
           Sign.Parent,
           Sign2.Code AS ParentCode,
           Sign2.Description AS ParentDescription,
           Sign.Date1 AS Date1,
           Sign.Date2 AS Date2,
           Sign.Code AS Code,
           Sign.Description AS Description,
           Sign.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Sign.Info,
           Info.Code AS InfoCode,
           Info.Description AS InfoDescription,
           Sign.More AS More
      FROM Sign AS Sign
           LEFT JOIN
           Sign AS Sign2 ON Sign.Parent = Sign2.Id
           LEFT JOIN
           Role AS Role ON Sign.Role = Role.Id
           LEFT JOIN
           Info AS Info ON Sign.Info = Info.Id;


-- View: SliceList
CREATE VIEW SliceList AS
    SELECT Slice.Id,
           Slice.Parent,
           Slice2.Code AS ParentCode,
           Slice2.Description AS ParentDescription,
           Slice.Date1 AS Date1,
           Slice.Date2 AS Date2,
           Slice.Code AS Code,
           Slice.Description AS Description,
           Slice.More AS More
      FROM Slice AS Slice
           LEFT JOIN
           Slice AS Slice2 ON Slice.Parent = Slice2.Id;


-- View: UnitList
CREATE VIEW UnitList AS
    SELECT Unit.Id,
           Unit.Parent,
           Unit2.Code AS ParentCode,
           Unit2.Description AS ParentDescription,
           Unit.Date1 AS Date1,
           Unit.Date2 AS Date2,
           Unit.Code AS Code,
           Unit.Description AS Description,
           Unit.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Unit.More AS More
      FROM Unit AS Unit
           LEFT JOIN
           Unit AS Unit2 ON Unit.Parent = Unit2.Id
           LEFT JOIN
           Role AS Role ON Unit.Role = Role.Id;


-- View: WorkbookList
CREATE VIEW WorkbookList AS
    SELECT Workbook.Id,
           Workbook.Parent,
           Workbook2.Code AS ParentCode,
           Workbook2.Description AS ParentDescription,
           Workbook.Face1,
           Face1.Code AS Face1Code,
           Face1.Description AS Face1Description,
           Workbook.Face2,
           Face2.Code AS Face2Code,
           Face2.Description AS Face2Description,
           Workbook.Face,
           Face.Code AS FaceCode,
           Face.Description AS FaceDescription,
           Workbook.Slice,
           Slice.Code AS SliceCode,
           Slice.Description AS SliceDescription,
           Workbook.Date1 AS Date1,
           Workbook.Date2 AS Date2,
           Workbook.Code AS Code,
           Workbook.Description AS Description,
           Workbook.Geo,
           Geo.Code AS GeoCode,
           Geo.Description AS GeoDescription,
           Workbook.Sign,
           Sign.Code AS SignCode,
           Sign.Description AS SignDescription,
           Workbook.Account,
           Account.Code AS AccountCode,
           Account.Description AS AccountDescription,
           Workbook.Process,
           Process.Code AS ProcessCode,
           Process.Description AS ProcessDescription,
           Workbook.Debt,
           Debt.Code AS DebtCode,
           Debt.Description AS DebtDescription,
           Workbook.Item,
           Item.Code AS ItemCode,
           Item.Description AS ItemDescription,
           Workbook.Deal,
           Deal.Code AS DealCode,
           Deal.Description AS DealDescription,
           Workbook.Price,
           Price.Code AS PriceCode,
           Price.Description AS PriceDescription,
           Workbook.Asset,
           Asset.Code AS AssetCode,
           Asset.Description AS AssetDescription,
           Workbook.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Workbook.Info,
           Info.Code AS InfoCode,
           Info.Description AS InfoDescription,
           Workbook.Meter,
           Meter.Code AS MeterCode,
           Meter.Description AS MeterDescription,
           Workbook.MeterValue AS MeterValue,
           Workbook.Unit,
           Unit.Code AS UnitCode,
           Unit.Description AS UnitDescription,
           Workbook.Mark,
           Mark.Code AS MarkCode,
           Mark.Description AS MarkDescription
      FROM Workbook AS Workbook
           LEFT JOIN
           Workbook AS Workbook2 ON Workbook.Parent = Workbook2.Id
           LEFT JOIN
           Mark AS Mark ON Workbook.Mark = Mark.Id
           LEFT JOIN
           Slice AS Slice ON Workbook.Slice = Slice.Id
           LEFT JOIN
           Face AS Face ON Workbook.Face = Face.Id
           LEFT JOIN
           Face AS Face1 ON Workbook.Face1 = Face1.Id
           LEFT JOIN
           Face AS Face2 ON Workbook.Face2 = Face2.Id
           LEFT JOIN
           Geo AS Geo ON Workbook.Geo = Geo.Id
           LEFT JOIN
           Account AS Account ON Workbook.Account = Account.Id
           LEFT JOIN
           Role AS Role ON Workbook.Role = Role.Id
           LEFT JOIN
           Info AS Info ON Workbook.Info = Info.Id
           LEFT JOIN
           Sign AS Sign ON Workbook.Sign = Sign.Id
           LEFT JOIN
           Unit AS Unit ON Workbook.Unit = Unit.Id
           LEFT JOIN
           Process AS Process ON Workbook.Process = Process.Id
           LEFT JOIN
           Debt AS Debt ON Workbook.Debt = Debt.Id
           LEFT JOIN
           Item AS Item ON Workbook.Item = Item.Id
           LEFT JOIN
           Deal AS Deal ON Workbook.Deal = Deal.Id
           LEFT JOIN
           Price AS Price ON Workbook.Price = Price.Id
           LEFT JOIN
           Asset AS Asset ON Workbook.Asset = Asset.Id
           LEFT JOIN
           Meter AS Meter ON Workbook.Meter = Meter.Id;


COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
