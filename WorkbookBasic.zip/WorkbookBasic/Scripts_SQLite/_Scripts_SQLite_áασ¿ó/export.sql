--
-- File generated with SQLiteStudio v3.4.3 on Пн фев 6 08:41:15 2023
--
-- Text encoding used: UTF-8
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Table: Account
CREATE TABLE IF NOT EXISTS Account (
    Id          INTEGER PRIMARY KEY ASC AUTOINCREMENT,
    Parent      INTEGER
                        REFERENCES Account (Id),
    Slice       INTEGER
                        REFERENCES Slice (Id),
    Date1       TEXT,
    Date2       TEXT,
    Code        TEXT,
    Description TEXT,
    Sign        INTEGER
                        REFERENCES Sign (Id),
    Role        INTEGER
                        REFERENCES Role (Id),
    More        TEXT
);

INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (1, 286, 7, '', '', 'Account.1', 'Краткосрочные активы', 9, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (2, 1, 7, '', '', 'Account.1000', 'Денежные средства', 11, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (3, 2, 1, '', '', 'Account.1010', 'Денежные средства в кассе', 195, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (4, 2, 1, '', '', 'Account.1020', 'Денежные средства в пути', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (5, 2, 1, '', '', 'Account.1030', 'Денежные средства на текущих банковских счетах', 193, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (6, 2, 7, '', '', 'Account.1040', 'Денежные средства на корреспондентских счетах', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (7, 2, 7, '', '', 'Account.1050', 'Денежные средства на сберегательных счетах', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (8, 2, 7, '', '', 'Account.1060', 'Денежные средства, ограниченные в использовании', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (9, 2, 7, '', '', 'Account.1070', 'Учет электронных денег', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (10, 2, 7, '', '', 'Account.1080', 'Прочие денежные средства', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (11, 2, 7, '', '', 'Account.1090', 'Оценочный резерв под убытки от обесценения денежных средств', 12, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (12, 1, 7, '', '', 'Account.1100', 'Краткосрочные финансовые активы', 3, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (13, 12, 7, '', '', 'Account.1110', 'Краткосрочные финансовые активы, оцениваемые по амортизированной стоимости', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (14, 12, 7, '', '', 'Account.1120', 'Краткосрочные финансовые активы, оцениваемые по справедливой стоимости через прочий совокупный доход', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (15, 12, 7, '', '', 'Account.1130', 'Краткосрочные финансовые активы, оцениваемые по справедливой стоимости через прибыль или убыток', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (16, 12, 7, '', '', 'Account.1140', 'Производные финансовые инструменты', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (17, 12, 7, '', '', 'Account.1150', 'Краткосрочные вознаграждения к получению', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (18, 12, 7, '', '', 'Account.1160', 'Прочие краткосрочные финансовые активы', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (19, 12, 7, '', '', 'Account.1170', 'Оценочный резерв под убытки от обесценения краткосрочных финансовых активов', 12, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (20, 1, 7, '', '', 'Account.1200', 'Краткосрочная дебиторская задолженность', 7, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (21, 20, 1, '', '', 'Account.1210', 'Краткосрочная дебиторская задолженность покупателей и заказчиков', '', 4, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (22, 20, 7, '', '', 'Account.1220', 'Краткосрочная дебиторская задолженность дочерних организаций', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (23, 20, 7, '', '', 'Account.1230', 'Краткосрочная дебиторская задолженность ассоциированных и совместных организаций', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (24, 20, 7, '', '', 'Account.1240', 'Краткосрочная дебиторская задолженность филиалов и структурных подразделений', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (25, 20, 1, '', '', 'Account.1250', 'Краткосрочная дебиторская задолженность работников', '', 4, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (26, 20, 7, '', '', 'Account.1260', 'Краткосрочная дебиторская задолженность по аренде', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (27, 20, 7, '', '', 'Account.1270', 'Прочая краткосрочная дебиторская задолженность', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (28, 20, 7, '', '', 'Account.1280', 'Оценочный резерв под убытки от обесценения краткосрочной дебиторской задолженности', 12, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (29, 1, 7, '', '', 'Account.1300', 'Запасы', 3, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (30, 29, 1, '', '', 'Account.1310', 'Сырье и материалы', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (31, 29, 1, '', '', 'Account.1320', 'Готовая продукция', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (32, 29, 1, '', '', 'Account.1330', 'Товары', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (33, 29, 1, '', '', 'Account.1340', 'Незавершенное производство', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (34, 29, 7, '', '', 'Account.1350', 'Прочие запасы', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (35, 29, 7, '', '', 'Account.1360', 'Оценочный резерв под убытки от обесценения запасов', 12, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (36, 29, 7, '', '', 'Account.1370', 'Актив по праву на возврат запасов', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (37, 1, 7, '', '', 'Account.1400', 'Текущие налоговые активы', 15, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (38, 37, 1, '', '', 'Account.1410', 'Корпоративный подоходный налог', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (39, 37, 1, '', '', 'Account.1420', 'Налог на добавленную стоимость', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (40, 37, 7, '', '', 'Account.1430', 'Прочие налоги и другие обязательные платежи в бюджет', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (41, 1, 7, '', '', 'Account.1500', 'Долгосрочные активы, предназначенные для продажи', 3, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (42, 41, 7, '', '', 'Account.1510', 'Долгосрочные активы, предназначенные для продажи', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (43, 41, 7, '', '', 'Account.1520', 'Группы на выбытие, предназначенные для продажи', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (44, 41, 7, '', '', 'Account.1530', 'Оценочный резерв под убытки от обесценения долгосрочных активов (или выбывающих групп), предназначенных для продажи', 12, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (45, 1, 7, '', '', 'Account.1600', 'Биологические активы', 3, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (46, 45, 7, '', '', 'Account.1610', 'Растения', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (47, 45, 7, '', '', 'Account.1620', 'Животные', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (48, 45, 7, '', '', 'Account.1630', 'Оценочный резерв под убытки от обесценения биологических активов', 12, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (49, 1, 7, '', '', 'Account.1700', 'Прочие краткосрочные активы', 3, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (50, 49, 1, '', '', 'Account.1710', 'Краткосрочные авансы выданные', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (51, 49, 7, '', '', 'Account.1720', 'Расходы будущих периодов', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (52, 49, 7, '', '', 'Account.1730', 'Краткосрочные активы по договорам', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (53, 49, 7, '', '', 'Account.1740', 'Оценочный резерв под убытки от обесценения краткосрочных активов по договорам', 12, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (54, 49, 7, '', '', 'Account.1750', 'Прочие краткосрочные активы.', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (55, 286, 7, '', '', 'Account.2', 'Долгосрочные активы', 9, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (56, 55, 7, '', '', 'Account.2000', 'Долгосрочные финансовые активы', 3, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (57, 56, 7, '', '', 'Account.2010', 'Долгосрочные финансовые активы, оцениваемые по амортизированной стоимости', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (58, 56, 7, '', '', 'Account.2020', 'Долгосрочные финансовые активы, оцениваемые по справедливой стоимости через прочий совокупный доход', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (59, 56, 7, '', '', 'Account.2030', 'Долгосрочные финансовые активы, оцениваемые по справедливой стоимости через прибыль или убыток', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (60, 56, 7, '', '', 'Account.2040', 'Производные финансовые инструменты', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (61, 56, 7, '', '', 'Account.2050', 'Долгосрочные вознаграждения к получению', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (62, 56, 7, '', '', 'Account.2060', 'Долевые инструменты', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (63, 56, 7, '', '', 'Account.2070', 'Прочие долгосрочные финансовые активы', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (64, 56, 7, '', '', 'Account.2080', 'Оценочный резерв под убытки от обесценения долгосрочных финансовых активов', 12, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (65, 55, 7, '', '', 'Account.2100', 'Долгосрочная дебиторская задолженность', 7, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (66, 65, 7, '', '', 'Account.2110', 'Долгосрочная задолженность покупателей и заказчиков', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (67, 65, 7, '', '', 'Account.2120', 'Долгосрочная дебиторская задолженность дочерних организаций', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (68, 65, 7, '', '', 'Account.2130', 'Долгосрочная дебиторская задолженность ассоциированных и совместных организаций', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (69, 65, 7, '', '', 'Account.2140', 'Долгосрочная дебиторская задолженность филиалов и структурных подразделений', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (70, 65, 7, '', '', 'Account.2150', 'Долгосрочная дебиторская задолженность работников', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (71, 65, 7, '', '', 'Account.2160', 'Долгосрочная дебиторская задолженность по аренде', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (72, 65, 7, '', '', 'Account.2170', 'Прочая долгосрочная дебиторская задолженность', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (73, 65, 7, '', '', 'Account.2180', 'Оценочный резерв под убытки от обесценения долгосрочной дебиторской задолженности', 12, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (74, 55, 7, '', '', 'Account.2200', 'Инвестиции', 3, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (75, 74, 7, '', '', 'Account.2210', 'Инвестиции, учитываемые методом долевого участия', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (76, 74, 7, '', '', 'Account.2220', 'Инвестиции, учитываемые по первоначальной стоимости', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (77, 74, 7, '', '', 'Account.2230', 'Оценочный резерв под убытки от обесценения инвестиций', 12, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (78, 55, 7, '', '', 'Account.2300', 'Инвестиционное имущество', 3, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (79, 78, 7, '', '', 'Account.2310', 'Инвестиционное имущество', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (80, 78, 7, '', '', 'Account.2320', 'Амортизация инвестиционного имущества', 6, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (81, 78, 7, '', '', 'Account.2330', 'Оценочный резерв под убытки от обесценения инвестиционного имущества', 12, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (82, 55, 7, '', '', 'Account.2400', 'Основные средства', 3, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (83, 82, 1, '', '', 'Account.2410', 'Основные средства', 8, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (84, 82, 1, '', '', 'Account.2420', 'Амортизация основных средств', 6, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (85, 82, 7, '', '', 'Account.2430', 'Оценочный резерв под убытки от обесценения основных средств', 12, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (86, 82, 7, '', '', 'Account.2440', 'Право пользования активом', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (87, 82, 7, '', '', 'Account.2450', 'Амортизация права пользования активом', 6, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (88, 82, 7, '', '', 'Account.2460', 'Убыток от обесценения права пользования активом', 12, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (89, 55, 7, '', '', 'Account.2500', 'Биологические активы', 3, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (90, 89, 7, '', '', 'Account.2510', 'Растения', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (91, 89, 7, '', '', 'Account.2520', 'Животные', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (92, 89, 7, '', '', 'Account.2530', 'Амортизация биологических активов', 6, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (93, 89, 7, '', '', 'Account.2540', 'Оценочный резерв под убытки от обесценения биологических активов', 12, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (94, 55, 7, '', '', 'Account.2600', 'Разведочные и оценочные активы', 3, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (95, 94, 7, '', '', 'Account.2610', 'Разведочные и оценочные активы', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (96, 94, 7, '', '', 'Account.2620', 'Амортизация разведочных и оценочных активов', 6, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (97, 94, 7, '', '', 'Account.2630', 'Оценочный резерв под убытки от обесценения разведочных и оценочных активов', 12, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (98, 55, 7, '', '', 'Account.2700', 'Нематериальные активы', 3, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (99, 98, 7, '', '', 'Account.2710', 'Гудвилл', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (100, 98, 7, '', '', 'Account.2720', 'Обесценение гудвилла', 12, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (101, 98, 7, '', '', 'Account.2730', 'Прочие нематериальные активы', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (102, 98, 7, '', '', 'Account.2740', 'Амортизация прочих нематериальных активов', 6, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (103, 98, 7, '', '', 'Account.2750', 'Оценочный резерв под убытки от обесценения прочих нематериальных активов', 12, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (104, 98, 7, '', '', 'Account.2760', 'Право пользования активом', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (105, 98, 7, '', '', 'Account.2770', 'Амортизация права пользования активом', 6, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (106, 98, 7, '', '', 'Account.2780', 'Оценочный резерв под убытки от обесценения права пользования активом', 12, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (107, 55, 7, '', '', 'Account.2800', 'Отложенные налоговые активы', 15, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (108, 107, 7, '', '', 'Account.2810', 'Отложенные налоговые активы по корпоративному подоходному налогу', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (109, 55, 7, '', '', 'Account.2900', 'Прочие долгосрочные активы', 7, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (110, 109, 7, '', '', 'Account.2910', 'Долгосрочные авансы выданные', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (111, 109, 7, '', '', 'Account.2920', 'Расходы будущих периодов', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (112, 109, 1, '', '', 'Account.2930', 'Незавершенное строительство', 3, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (113, 109, 7, '', '', 'Account.2940', 'Долгосрочные активы по договорам', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (114, 109, 7, '', '', 'Account.2950', 'Оценочный резерв под убытки от обесценения долгосрочных активов по договорам', 12, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (115, 109, 7, '', '', 'Account.2960', 'Затраты по договорам', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (116, 109, 7, '', '', 'Account.2970', 'Амортизация затрат по договорам', 6, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (117, 109, 7, '', '', 'Account.2980', 'Оценочный резерв под убытки от обесценения затрат по договорам', 12, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (118, 109, 7, '', '', 'Account.2990', 'Прочие долгосрочные активы', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (119, 286, 7, '', '', 'Account.3', 'Краткосрочные обязательства', 9, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (120, 119, 7, '', '', 'Account.3000', 'Краткосрочные финансовые обязательства', 7, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (121, 120, 7, '', '', 'Account.3010', 'Краткосрочные финансовые обязательства, оцениваемые по амортизированной стоимости', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (122, 120, 7, '', '', 'Account.3020', 'Краткосрочные финансовые обязательства, оцениваемые по справедливой стоимости через прибыль или убыток', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (123, 120, 7, '', '', 'Account.3030', 'Производные финансовые инструменты', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (124, 120, 7, '', '', 'Account.3040', 'Краткосрочная кредиторская задолженность по дивидендам и доходам участников', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (125, 120, 7, '', '', 'Account.3050', 'Краткосрочные вознаграждения к выплате', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (126, 120, 7, '', '', 'Account.3060', 'Текущая часть долгосрочных финансовых обязательств, оцениваемых по амортизированной стоимости', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (127, 120, 7, '', '', 'Account.3070', 'Текущая часть долгосрочных финансовых обязательств, оцениваемых по справедливой стоимости через прибыль или убытки', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (128, 120, 7, '', '', 'Account.3080', 'Прочие краткосрочные финансовые обязательства', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (129, 119, 7, '', '', 'Account.3100', 'Обязательства по налогам', 15, 2, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (130, 129, 1, '', '', 'Account.3110', 'Корпоративный подоходный налог, подлежащий уплате', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (131, 129, 1, '', '', 'Account.3120', 'Индивидуальный подоходный налог', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (132, 129, 1, '', '', 'Account.3130', 'Налог на добавленную стоимость', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (133, 129, 1, '', '', 'Account.3140', 'Акцизы', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (134, 129, 1, '', '', 'Account.3150', 'Социальный налог', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (135, 129, 1, '', '', 'Account.3160', 'Земельный налог', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (136, 129, 1, '', '', 'Account.3170', 'Налог на транспортные средства', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (137, 129, 1, '', '', 'Account.3180', 'Налог на имущество', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (138, 129, 1, '', '', 'Account.3190', 'Прочие налоги', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (139, 119, 7, '', '', 'Account.3200', 'Обязательства по другим обязательным и добровольным платежам', 15, 2, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (140, 139, 1, '', '', 'Account.3210', 'Обязательства по социальному страхованию', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (141, 139, 1, '', '', 'Account.3220', 'Обязательства по пенсионным отчислениям', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (142, 139, 1, '', '', 'Account.3230', 'Прочие обязательства по другим обязательным платежам', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (143, 139, 1, '', '', 'Account.3240', 'Прочие обязательства по другим добровольным платежам', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (144, 119, 7, '', '', 'Account.3300', 'Краткосрочная кредиторская задолженность', 7, 2, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (145, 144, 1, '', '', 'Account.3310', 'Краткосрочная кредиторская задолженность поставщикам и подрядчикам', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (146, 144, 7, '', '', 'Account.3320', 'Краткосрочная кредиторская задолженность дочерним организациям', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (147, 144, 7, '', '', 'Account.3330', 'Краткосрочная кредиторская задолженность ассоциированным и совместным организациям', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (148, 144, 7, '', '', 'Account.3340', 'Краткосрочная кредиторская задолженность филиалам и структурным подразделениям', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (149, 144, 1, '', '', 'Account.3350', 'Краткосрочная задолженность по оплате труда', 14, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (150, 144, 1, '', '', 'Account.3360', 'Краткосрочная задолженность по аренде', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (151, 144, 7, '', '', 'Account.3370', 'Текущая часть долгосрочной кредиторской задолженности', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (152, 144, 7, '', '', 'Account.3380', 'Прочая краткосрочная кредиторская задолженность', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (153, 119, 7, '', '', 'Account.3400', 'Краткосрочные оценочные обязательства', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (154, 153, 7, '', '', 'Account.3410', 'Краткосрочные гарантийные обязательства', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (155, 153, 7, '', '', 'Account.3420', 'Краткосрочные обязательства по юридическим претензиям', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (156, 153, 7, '', '', 'Account.3430', 'Краткосрочные оценочные обязательства по вознаграждениям работникам', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (157, 153, 7, '', '', 'Account.3440', 'Прочие краткосрочные оценочные обязательства', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (158, 119, 7, '', '', 'Account.3500', 'Прочие краткосрочные обязательства', 7, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (159, 158, 1, '', '', 'Account.3510', 'Краткосрочные авансы полученные', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (160, 158, 7, '', '', 'Account.3520', 'Доходы будущих периодов', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (161, 158, 7, '', '', 'Account.3530', 'Обязательства группы на выбытие, предназначенной для продажи', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (162, 158, 7, '', '', 'Account.3540', 'Краткосрочные обязательства по договорам', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (163, 158, 7, '', '', 'Account.3550', 'Долговой компонент комбинированного краткосрочного финансового инструмента', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (164, 158, 7, '', '', 'Account.3560', 'Прочие краткосрочные обязательства.', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (165, 286, 7, '', '', 'Account.4', 'Долгосрочные обязательства', 9, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (166, 165, 7, '', '', 'Account.4000', 'Долгосрочные финансовые обязательства', 7, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (167, 166, 7, '', '', 'Account.4010', 'Долгосрочные финансовые обязательства, оцениваемые по амортизированной стоимости', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (168, 166, 7, '', '', 'Account.4020', 'Долгосрочные финансовые обязательства, оцениваемые по справедливой стоимости через прибыль или убыток', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (169, 166, 7, '', '', 'Account.4030', 'Производные финансовые инструменты', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (170, 166, 7, '', '', 'Account.4040', 'Долгосрочная задолженность по дивидендам и доходам участников', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (171, 166, 7, '', '', 'Account.4050', 'Долгосрочные вознаграждения к выплате', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (172, 166, 7, '', '', 'Account.4060', 'Прочие долгосрочные финансовые обязательства', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (173, 165, 7, '', '', 'Account.4100', 'Долгосрочная кредиторская задолженность', 7, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (174, 173, 7, '', '', 'Account.4110', 'Долгосрочная кредиторская задолженность поставщикам и подрядчикам', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (175, 173, 7, '', '', 'Account.4120', 'Долгосрочная кредиторская задолженность дочерним организациям', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (176, 173, 7, '', '', 'Account.4130', 'Долгосрочная кредиторская задолженность ассоциированным и совместным организациям', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (177, 173, 7, '', '', 'Account.4140', 'Долгосрочная кредиторская задолженность филиалам и структурным подразделениям', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (178, 173, 7, '', '', 'Account.4150', 'Долгосрочная задолженность по аренде', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (179, 173, 7, '', '', 'Account.4160', 'Прочая долгосрочная кредиторская задолженность', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (180, 165, 7, '', '', 'Account.4200', 'Долгосрочные оценочные обязательства', 7, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (181, 180, 7, '', '', 'Account.4210', 'Долгосрочные гарантийные обязательства', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (182, 180, 7, '', '', 'Account.4220', 'Долгосрочные оценочные обязательства по юридическим претензиям', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (183, 180, 7, '', '', 'Account.4230', 'Долгосрочные оценочные обязательства по вознаграждениям работникам', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (184, 180, 7, '', '', 'Account.4240', 'Прочие долгосрочные оценочные обязательства', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (185, 165, 7, '', '', 'Account.4300', 'Отложенные налоговые обязательства', 15, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (186, 185, 7, '', '', 'Account.4310', 'Отложенные налоговые обязательства по корпоративному подоходному налогу', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (187, 165, 7, '', '', 'Account.4400', 'Прочие долгосрочные обязательства', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (188, 187, 7, '', '', 'Account.4410', 'Долгосрочные авансы полученные', 7, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (189, 187, 7, '', '', 'Account.4420', 'Доходы будущих периодов', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (190, 187, 7, '', '', 'Account.4430', 'Долгосрочные обязательства по договорам', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (191, 187, 7, '', '', 'Account.4440', 'Долговой компонент комбинированного долгосрочного финансового инструмента', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (192, 187, 7, '', '', 'Account.4450', 'Прочие долгосрочные обязательства', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (193, 286, 7, '', '', 'Account.5', 'Капитал и резервы', 9, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (194, 193, 7, '', '', 'Account.5000', 'Уставный капитал', 5, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (195, 194, 7, '', '', 'Account.5010', 'Привилегированные акции', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (196, 194, 7, '', '', 'Account.5020', 'Простые акции', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (197, 194, 1, '', '', 'Account.5030', 'Вклады и паи', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (198, 193, 7, '', '', 'Account.5100', 'Неоплаченный капитал', 5, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (199, 198, 1, '', '', 'Account.5110', 'Неоплаченный капитал', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (200, 193, 7, '', '', 'Account.5200', 'Выкупленные собственные долевые инструменты', 5, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (201, 200, 7, '', '', 'Account.5210', 'Выкупленные собственные долевые инструменты', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (202, 193, 7, '', '', 'Account.5300', 'Эмиссионный доход', 5, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (203, 202, 7, '', '', 'Account.5310', 'Эмиссионный доход', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (204, 193, 7, '', '', 'Account.5400', 'Дополнительно оплаченный капитал', 5, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (205, 204, 1, '', '', 'Account.5410', 'Дополнительно оплаченный капитал по безвозмездным операциям с основной организацией', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (206, 204, 7, '', '', 'Account.5420', 'Дополнительно оплаченный капитал по прочим операциям', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (207, 193, 7, '', '', 'Account.5500', 'Резервы', 5, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (208, 207, 7, '', '', 'Account.5510', 'Резервный капитал, установленный учредительными документами', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (209, 207, 7, '', '', 'Account.5520', 'Резерв на переоценку основных средств', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (210, 207, 7, '', '', 'Account.5530', 'Резерв на переоценку нематериальных активов', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (211, 207, 7, '', '', 'Account.5540', 'Резерв на переоценку финансовых активов, учитываемых по справедливой стоимости через прочий совокупный доход', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (212, 207, 7, '', '', 'Account.5550', 'Резерв под убытки по финансовым активам', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (213, 207, 7, '', '', 'Account.5560', 'Резерв на пересчет иностранной валюты по зарубежной деятельности', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (214, 207, 7, '', '', 'Account.5570', 'Прочие резервы', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (215, 193, 7, '', '', 'Account.5600', 'Нераспределенная прибыль (непокрытый убыток)', 5, 2, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (216, 215, 1, '', '', 'Account.5610', 'Нераспределенная прибыль (непокрытый убыток) отчетного года', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (217, 215, 1, '', '', 'Account.5620', 'Нераспределенная прибыль (непокрытый убыток) предыдущих лет', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (218, 193, 7, '', '', 'Account.5700', 'Итоговая прибыль (итоговый убыток)', 5, 2, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (219, 218, 1, '', '', 'Account.5710', 'Итоговая прибыль (итоговый убыток)', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (220, 286, 7, '', '', 'Account.6', 'Доходы', 9, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (221, 220, 7, '', '', 'Account.6000', 'Доход от реализации продукции и оказания услуг', 4, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (222, 221, 1, '', '', 'Account.6010', 'Доход от реализации продукции и оказания услуг', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (223, 221, 1, '', '', 'Account.6020', 'Возврат проданной продукции', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (224, 221, 7, '', '', 'Account.6030', 'Скидки с цены и продаж', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (225, 220, 7, '', '', 'Account.6100', 'Доход от финансирования', 4, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (226, 225, 7, '', '', 'Account.6110', 'Доходы по вознаграждениям', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (227, 225, 7, '', '', 'Account.6120', 'Доходы по дивидендам', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (228, 225, 7, '', '', 'Account.6130', 'Доходы от финансовой аренды', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (229, 225, 7, '', '', 'Account.6140', 'Доходы от операций с инвестициями в недвижимость', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (230, 225, 7, '', '', 'Account.6150', 'Доходы от изменения справедливой стоимости финансовых инструментов', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (231, 225, 7, '', '', 'Account.6160', 'Прочие доходы от финансирования', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (232, 220, 7, '', '', 'Account.6200', 'Прочие доходы', 4, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (233, 232, 1, '', '', 'Account.6210', 'Доходы от выбытия активов', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (234, 232, 7, '', '', 'Account.6220', 'Доходы от безвозмездно полученных активов', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (235, 232, 7, '', '', 'Account.6230', 'Доходы от государственных субсидий', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (236, 232, 7, '', '', 'Account.6240', 'Доходы от восстановления убытка от обесценения по нефинансовым активам', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (237, 232, 1, '', '', 'Account.6250', 'Доходы от курсовой разницы', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (238, 232, 1, '', '', 'Account.6260', 'Доходы от операционной аренды', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (239, 232, 7, '', '', 'Account.6270', 'Доходы от изменения справедливой стоимости биологических активов', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (240, 232, 7, '', '', 'Account.6280', 'Доходы от восстановления убытка от обесценения по финансовым активам', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (241, 232, 1, '', '', 'Account.6290', 'Прочие доходы', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (242, 220, 7, '', '', 'Account.6300', 'Доходы, связанные с прекращаемой деятельностью', 4, 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (243, 242, 7, '', '', 'Account.6310', 'Доходы, связанные с прекращаемой деятельностью', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (244, 220, 7, '', '', 'Account.6400', 'Доля прибыли организаций, учитываемых по методу долевого участия', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (245, 244, 7, '', '', 'Account.6410', 'Доля прибыли ассоциированных организаций', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (246, 244, 7, '', '', 'Account.6420', 'Доля прибыли совместных организаций.', '', 1, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (247, 286, 7, '', '', 'Account.7', 'Расходы', 9, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (248, 247, 7, '', '', 'Account.7000', 'Себестоимость реализованной продукции и оказанных услуг', 4, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (249, 248, 1, '', '', 'Account.7010', 'Себестоимость реализованной продукции и оказанных услуг', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (250, 247, 7, '', '', 'Account.7100', 'Расходы по реализации продукции и оказанию услуг', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (251, 250, 1, '', '', 'Account.7110', 'Расходы по реализации продукции и оказанию услуг', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (252, 247, 7, '', '', 'Account.7200', 'Административные расходы', 4, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (253, 252, 1, '', '', 'Account.7210', 'Административные расходы', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (254, 247, 7, '', '', 'Account.7300', 'Расходы на финансирование', 4, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (255, 254, 7, '', '', 'Account.7310', 'Расходы по вознаграждениям', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (256, 254, 7, '', '', 'Account.7320', 'Расходы на выплату процентов по финансовой аренде', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (257, 254, 7, '', '', 'Account.7330', 'Расходы от изменения справедливой стоимости финансовых инструментов стоимости', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (258, 254, 7, '', '', 'Account.7340', 'Прочие расходы на финансирование', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (259, 247, 7, '', '', 'Account.7400', 'Прочие расходы', 4, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (260, 259, 7, '', '', 'Account.7410', 'Расходы по выбытию активов', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (261, 259, 7, '', '', 'Account.7420', 'Расходы от обесценения нефинансовых активов', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (262, 259, 1, '', '', 'Account.7430', 'Расходы по курсовой разнице', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (263, 259, 7, '', '', 'Account.7440', 'Расходы по обесценению дебиторской задолженности', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (264, 259, 7, '', '', 'Account.7450', 'Расходы по операционной аренде', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (265, 259, 7, '', '', 'Account.7460', 'Расходы от изменения справедливой стоимости биологических активов', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (266, 259, 7, '', '', 'Account.7470', 'Расходы от обесценения финансовых инструментов', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (267, 259, 1, '', '', 'Account.7480', 'Прочие расходы', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (268, 247, 7, '', '', 'Account.7500', 'Расходы, связанные с прекращаемой деятельностью', 4, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (269, 268, 7, '', '', 'Account.7510', 'Расходы, связанные с прекращаемой деятельностью', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (270, 247, 7, '', '', 'Account.7600', 'Доля в убытке организаций, учитываемых методом долевого участия', 4, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (271, 270, 7, '', '', 'Account.7610', 'Доля в убытке ассоциированных организациях', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (272, 270, 7, '', '', 'Account.7620', 'Доля в убытке совместных организациях', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (273, 247, 7, '', '', 'Account.7700', 'Расходы по корпоративному подоходному налогу', 4, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (274, 273, 1, '', '', 'Account.7710', 'Расходы по корпоративному подоходному налогу.', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (275, 286, 7, '', '', 'Account.8', 'Счета производственного учета', 9, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (276, 275, 7, '', '', 'Account.8100', 'Основное производство', 13, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (277, 276, 1, '', '', 'Account.8110', 'Основное производство', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (278, 275, 7, '', '', 'Account.8200', 'Полуфабрикаты собственного производства', 13, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (279, 278, 1, '', '', 'Account.8210', 'Полуфабрикаты собственного производства', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (280, 275, 7, '', '', 'Account.8300', 'Вспомогательные производства', 13, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (281, 280, 1, '', '', 'Account.8310', 'Вспомогательные производства', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (282, 275, 7, '', '', 'Account.8400', 'Накладные расходы', 13, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (283, 282, 1, '', '', 'Account.8410', 'Накладные расходы', '', 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (284, 285, 5, '', '', 'Account.9', 'Забалансовые активы', 9, 3, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (285, '', 1, '', '', 'Account.', 'AccountData', 2, 4, '{"Role.Generic.Code": "Account.Basic",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (286, 285, 7, '', '', 'Account.AcctTable2019', 'Account Table 2019', 19, 4, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Table",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (287, 285, 7, '', '', 'Account.Work', 'Work', 21, 4, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog","Role.Generic.Code": "Account.Table",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (288, 287, 7, '', '', 'Account.Asset', 'ТМЦ', 3, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (289, 288, 7, '', '', 'Account.AssetBio', 'Биоактив', 3, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (290, 288, 7, '', '', 'Account.AssetCoverall', 'Спецодежда', 3, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (291, 288, 7, '', '', 'Account.AssetGood', 'Товар', 3, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (292, 288, 7, '', '', 'Account.AssetIntangible', 'НМА', 3, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (293, 288, 7, '', '', 'Account.AssetMaterial', 'Материал', 3, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (294, 288, 7, '', '', 'Account.AssetMortgage', 'Залоговое имущество', 3, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (295, 288, 7, '', '', 'Account.AssetProduction', 'Продукция', 13, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (296, 288, 7, '', '', 'Account.AssetTool', 'Инструмент', 3, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (297, 288, 7, '', '', 'Account.AssetUnfinishedProduction', 'Незавершенная продукция', 13, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (298, 287, 7, '', '', 'Account.Customer', 'Покупатель', 7, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (299, 298, 7, '', '', 'Account.CustomerPrepaid', 'Предоплата покупателя', 7, 1, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (300, 287, 7, '', '', 'Account.Equity', 'Капитал', 5, 1, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (301, 287, 7, '', '', 'Account.Expense', 'Расходы', 4, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (302, 301, 7, '', '', 'Account.ExpenseCost', 'Себестоимость', 4, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (303, 301, 7, '', '', 'Account.ExpenseGeneral', 'Общие адм расходы', 4, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (304, 301, 7, '', '', 'Account.ExpenseOther', 'Прочие расходы', 4, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (305, 301, 7, '', '', 'Account.ExpenseSell', 'Расходы по реализации', 4, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (306, 301, 7, '', '', 'Account.ExpenseSellOut', 'Внереализационные расходы', 4, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (307, 287, 7, '', '', 'Account.FixedAsset', 'Основные средства', 8, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (308, 307, 7, '', '', 'Account.FixedAssetBuilding', 'Здания', 8, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (309, 307, 7, '', '', 'Account.FixedAssetCar', 'Автотранспорт', 8, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (310, 307, 7, '', '', 'Account.FixedAssetDepreciation', 'Амортизация', 6, 1, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (311, 307, 7, '', '', 'Account.FixedAssetFurniture', 'Мебель', 8, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (312, 307, 7, '', '', 'Account.FixedAssetLand', 'Земля', 8, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (313, 307, 7, '', '', 'Account.FixedAssetMachine', 'Машинное оборудование', 8, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (314, 307, 7, '', '', 'Account.FixedAssetOfficeEquipment', 'Офисное оборудование', 8, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (315, 307, 7, '', '', 'Account.FixedAssetOther', 'Прочие ОС', 8, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (316, 287, 7, '', '', 'Account.FixedAssetUnfinishedConstruction', 'Незавершенное строительство', 13, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (317, 287, 7, '', '', 'Account.Imprest', 'Авансы сотрудников', 7, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (318, 287, 7, '', '', 'Account.Income', 'Доходы', 4, 1, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (319, 318, 7, '', '', 'Account.IncomeLossNet', 'Чистая прибыль (убыток)', 4, 1, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (320, 318, 7, '', '', 'Account.IncomeOther', 'Прочие доходы', 4, 1, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (321, 318, 7, '', '', 'Account.IncomeSell', 'Выручка', 4, 1, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (322, 318, 7, '', '', 'Account.IncomeSellOut', 'Внереализационные доходы', 4, 1, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (323, 287, 7, '', '', 'Account.Money', 'Деньги', 11, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (324, 323, 7, '', '', 'Account.MoneyBank', 'Банк', 11, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (325, 323, 7, '', '', 'Account.MoneyCash', 'Касса', 11, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (326, 323, 7, '', '', 'Account.MoneyTransit', 'Деньги в пути', 11, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (327, 287, 7, '', '', 'Account.Salary', 'Зарплата', 14, 1, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (328, 327, 7, '', '', 'Account.SalaryDeduction', 'Удержания из зарплаты', 12, 1, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (329, 287, 7, '', '', 'Account.Seller', 'Продавец', 7, 1, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (330, 329, 7, '', '', 'Account.SellerPrepaid', 'Предоплата продавцу', 7, 1, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (331, 287, 7, '', '', 'Account.Tax', 'Налог', 15, 1, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (332, 331, 7, '', '', 'Account.TaxAlimony', 'Алименты', 15, 1, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (333, 331, 7, '', '', 'Account.TaxCar', 'Налог на транспорт', 15, 1, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (334, 331, 7, '', '', 'Account.TaxExcise', 'Акциз', 15, 1, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (335, 331, 7, '', '', 'Account.TaxGFSS', 'ГФСС', 15, 1, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (336, 331, 7, '', '', 'Account.TaxIncome', 'КПН', 15, 1, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (337, 331, 7, '', '', 'Account.TaxIncomePerson', 'ИПН', 15, 1, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (338, 331, 7, '', '', 'Account.TaxLand', 'Налог на землю', 15, 1, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (339, 331, 7, '', '', 'Account.TaxOSMSEmployeeFee', 'ОСМС отчисления', 15, 1, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (340, 331, 7, '', '', 'Account.TaxOSMSEmployeePay', 'ОСМС взносы', 15, 1, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (341, 331, 7, '', '', 'Account.TaxOther', 'Прочие налоги, сборы, пошлины', 15, 1, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (342, 331, 7, '', '', 'Account.TaxPension', 'ОПВ', 15, 1, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (343, 331, 7, '', '', 'Account.TaxProperty', 'Налог на имущество', 15, 1, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (344, 331, 7, '', '', 'Account.TaxSN', 'СН', 15, 1, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (345, 331, 7, '', '', 'Account.TaxVATIn', 'НДС входящий', 15, 3, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Sign, Role, More) VALUES (346, 331, 7, '', '', 'Account.TaxVATOut', 'НДС исходящий', 15, 1, '{"Role.Generic.Code": "Account.Basic","Role.Generic.Code": "Account.Catalog",}');

-- Table: Asset
CREATE TABLE IF NOT EXISTS Asset (
    Id          INTEGER PRIMARY KEY ASC AUTOINCREMENT,
    Parent      INTEGER
                        REFERENCES Asset (Id),
    Date1       TEXT,
    Date2       TEXT,
    Code        TEXT,
    Description TEXT,
    Geo         INTEGER
                        REFERENCES Geo (Id),
    Role        INTEGER
                        REFERENCES Role (Id),
    Info        INTEGER
                        REFERENCES Info (Id),
    Unit        INTEGER
                        REFERENCES Unit (Id),
    More        TEXT
);

INSERT INTO Asset (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, Unit, More) VALUES (1, '', '', '', 'Asset.', 'AssetData', '', 57, 47, 31, '{"Role.Generic.Code": "Asset.Basic",}');
INSERT INTO Asset (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, Unit, More) VALUES (2, 1, '', '', 'Asset.Money', 'Денежные средства', 11, 34, 8, 6, '{"Role.Generic.FullName": "Денежные средства","Role.Generic.Code": "Asset.Basic",}');

-- Table: Deal
CREATE TABLE IF NOT EXISTS Deal (
    Id          INTEGER PRIMARY KEY ASC AUTOINCREMENT,
    Parent      INTEGER
                        REFERENCES Deal (Id),
    Face1       INTEGER
                        REFERENCES Face (Id),
    Face2       INTEGER
                        REFERENCES Face (Id),
    Face        INTEGER
                        REFERENCES Face (Id),
    Date1       TEXT,
    Date2       TEXT,
    Code        TEXT,
    Description TEXT,
    Geo         INTEGER
                        REFERENCES Geo (Id),
    Role        INTEGER
                        REFERENCES Role (Id),
    Info        INTEGER
                        REFERENCES Info (Id),
    More        TEXT
);

INSERT INTO Deal (Id, Parent, Face1, Face2, Face, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (1, '', '', '', '', '', '', 'Deal.', 'DealData', '', 67, 47, '{"Role.Generic.Code": "Deal.Basic",}');
INSERT INTO Deal (Id, Parent, Face1, Face2, Face, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (2, 1, '', '', 1, '', '', 'Deal.Face.alimony', 'алименты-МТиСЗН', 11, 51, 32, '{"Role.Generic.Code": "Deal.Basic",}');
INSERT INTO Deal (Id, Parent, Face1, Face2, Face, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (3, 1, '', '', 1, '', '', 'Deal.Face.enbek.staff', 'штатное расписание-МТиСЗН', 11, 51, 38, '{"Role.Generic.Code": "Deal.Basic",}');
INSERT INTO Deal (Id, Parent, Face1, Face2, Face, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (4, 3, 2, '', '', '', '', 'Deal.Face.FA1.boss', 'директор', 11, 51, 42, '{"Role.Generic.Code": "Deal.Basic",}');
INSERT INTO Deal (Id, Parent, Face1, Face2, Face, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (5, 1, '', '', 20, '', '', 'Deal.Face.GFSS', 'ГФСС-НАО-ГЦВП', 11, 51, 35, '{"Role.Generic.Code": "Deal.Basic",}');
INSERT INTO Deal (Id, Parent, Face1, Face2, Face, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (6, 1, '', '', 25, '', '', 'Deal.Face.kgd.tax', 'налоги-КГД', 11, 51, 35, '{"Role.Generic.Code": "Deal.Basic",}');
INSERT INTO Deal (Id, Parent, Face1, Face2, Face, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (7, 1, '', '', 20, '', '', 'Deal.Face.OPV', 'ОПВ-НАО-ГЦВП', 11, 51, 35, '{"Role.Generic.Code": "Deal.Basic",}');
INSERT INTO Deal (Id, Parent, Face1, Face2, Face, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (8, 1, '', '', 1, '', '', 'Deal.Face.OSGPOR', 'ОСГПОР', 11, 51, 38, '{"Role.Generic.Code": "Deal.Basic",}');
INSERT INTO Deal (Id, Parent, Face1, Face2, Face, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (9, 1, '', '', 20, '', '', 'Deal.Face.OSMS', 'ОСМС-НАО-ГЦВП', 11, 51, 35, '{"Role.Generic.Code": "Deal.Basic",}');

-- Table: Debt
CREATE TABLE IF NOT EXISTS Debt (
    Id          INTEGER PRIMARY KEY ASC AUTOINCREMENT,
    Parent      INTEGER
                        REFERENCES Debt (Id),
    Date1       TEXT,
    Date2       TEXT,
    Code        TEXT,
    Description TEXT,
    Geo         INTEGER
                        REFERENCES Geo (Id),
    Role        INTEGER
                        REFERENCES Role (Id),
    Info        INTEGER
                        REFERENCES Info (Id),
    More        TEXT
);

INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (1, '', '', '', 'Debt.', 'DebtData', '', 93, 47, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (2, 1, '', '', 'Debt.Custom', 'Таможенные платежи', 11, 224, 197, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (3, 2, '', '', 'Debt.Custom.Base', 'База ТП', 11, 212, 196, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (4, 2, '', '', 'Debt.Custom.Duty', 'Таможенная пошлина', 11, 80, 197, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (5, 2, '', '', 'Debt.Custom.Fee', 'Таможенный сбор', 11, 80, 197, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (6, 1, '', '', 'Debt.DeductionSalary', 'Удержания из зарплаты', 11, 217, 196, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (7, 6, '', '', 'Debt.DeductionSalary.Alimony', 'Алименты', 11, 87, 32, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (8, 7, '', '', 'Debt.DeductionSalary.Alimony.Rate1', 'Ставка алиментов1 (на 1 ребенка)', 11, 122, 188, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (9, 7, '', '', 'Debt.DeductionSalary.Alimony.Rate2', 'Ставка алиментов2 (на 2 детей)', 11, 125, 188, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (10, 7, '', '', 'Debt.DeductionSalary.Alimony.Rate3', 'Ставка алиментов3 (на 3 и более детей)', 11, 125, 188, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (11, 6, '', '', 'Debt.DeductionSalary.Other', 'Прочие удержания', 11, 65, 42, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (12, 1, '', '', 'Debt.Depreciation', 'Амортизация', 11, 65, 170, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (13, 12, '', '', 'Debt.Depreciation.Base', 'База амортизации', 11, 211, 72, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (14, 12, '', '', 'Debt.DepreciationAccounting', 'Ам-я бухгалтерская', 11, 220, 183, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (15, 14, '', '', 'Debt.DepreciationAccounting.Rate', 'Ставка аморт-и бухгалтерской', 11, 122, 188, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (16, 12, '', '', 'Debt.DepreciationTax', 'Ам-я налоговая', 11, 221, 194, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (17, 16, '', '', 'Debt.DepreciationTax.Rate', 'Ставка аморт-и налоговой', 11, 122, 188, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (18, 1, '', '', 'Debt.ExchangeDifference', 'Курсовая разница', 11, 209, 196, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (19, 18, '', '', 'Debt.ExchangeDifference.Advance', 'КР на авансы', 11, 222, 52, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (20, 18, '', '', 'Debt.ExchangeDifference.Purchase', 'КР при покупке валюты', 11, 223, 49, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (21, 1, '', '', 'Debt.GFSS', 'ГФСС', 11, 87, 186, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (22, 21, '', '', 'Debt.GFSS.Base', 'База ГФСС', 11, 217, 184, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (23, 21, '', '', 'Debt.GFSS.KNP.012', '012 - обяз соц отчисления', 11, 76, 19, '{"Role.Generic.FullName": "Обязательные социальные отчисления","Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (24, 21, '', '', 'Debt.GFSS.Rate', 'Ставка ГФСС', 11, 122, 188, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (25, 1, '', '', 'Debt.IncomePerson', 'Индивидуальный подоходный налог', 11, 87, 186, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (26, 25, '', '', 'Debt.IncomePerson.Base', 'База ИПН', 11, '', 183, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (27, 25, '', '', 'Debt.IncomePerson.Base.Deduction.MinSalary', 'Вычет МинЗП из базы ИПН', 11, 122, 180, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (28, 25, '', '', 'Debt.IncomePerson.Base.Deduction.OPV', 'Вычет ОПВ из базы ИПН', 11, 122, 181, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (29, 25, '', '', 'Debt.IncomePerson.KBK.101201', '101201 - ИПН с доходов, облагаемых у ист выпл', 11, 76, 18, '{"Role.Generic.FullName": "Индивидуальный подоходный налог с доходов, облагаемых у источника выплаты","Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (30, 25, '', '', 'Debt.IncomePerson.RateBasic', 'Ставка ИПН', 11, '', 188, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (31, 1, '', '', 'Debt.Income', 'Корпоративный подоходный налог', 11, '', 194, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (32, 31, '', '', 'Debt.Income.Base', 'База КПН', 11, 218, '', '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (33, 31, '', '', 'Debt.Income.KBK.101110', '101110 - КПН с ЮЛ, кроме нефт сект', 11, 76, 18, '{"Role.Generic.FullName": "Корпоративный подоходный налог с юридических лиц, за исключением поступлений от организаций нефтяного сектора","Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (34, 1, '', '', 'Debt.OSMS', 'ОСМС', 11, 77, '', '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (35, 34, '', '', 'Debt.OSMS.Base', 'База ОСМС', 11, 217, '', '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (36, 34, '', '', 'Debt.OSMS.EmployeePay', 'Взносы ОСМС', 11, '', 186, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (37, 36, '', '', 'Debt.OSMS.EmployeePay.RateMain', 'Ставка взносов ОСМС', 11, '', 188, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (38, 34, '', '', 'Debt.OSMS.EmployerFee', 'Отчисления ОСМС', 11, '', 186, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (39, 38, '', '', 'Debt.OSMS.EmployerFee.RateBasic', 'Ставка отчислений ОСМС', 11, '', 188, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (40, 1, '', '', 'Debt.Pension', 'Пенсионные платежи', 11, 77, '', '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (41, 40, '', '', 'Debt.Pension.Base', 'База пенсионных платежей', 11, 217, '', '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (42, 40, '', '', 'Debt.Pension.OPPV', 'Обязательные проф пенс взносы', 11, '', '', '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (43, 40, '', '', 'Debt.Pension.OPV', 'ОПВ', 11, '', 186, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (44, 43, '', '', 'Debt.Pension.OPV.KNP.010', '010 - обяз пенс взносы', 11, 76, 19, '{"Role.Generic.FullName": "Обязательные пенсионные взносы","Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (45, 43, '', '', 'Debt.Pension.OPV.RateBasic', 'Ставка ОПВ', 11, '', '', '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (46, 40, '', '', 'Debt.Pension.OPVR', 'ОПВ работодателя', 11, '', '', '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (47, 1, '', '', 'Debt.Salary', 'Оплата труда', 11, '', '', '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (48, 47, '', '', 'Debt.Salary.Commission', 'Комиссионные', 11, '', '', '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (49, 47, '', '', 'Debt.Salary.Extra', 'Премия', 11, '', '', '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (50, 47, '', '', 'Debt.Salary.Main', 'Оклад', 11, '', '', '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (51, 47, '', '', 'Debt.Salary.Other', 'Прочие начисления', 11, '', '', '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (52, 47, '', '', 'Debt.Salary.VacationCompensation', 'Компенсация отпуск', 11, '', '', '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (53, 47, '', '', 'Debt.Salary.VacationPay', 'Отпускные', 11, '', '', '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (54, 1, '', '', 'Debt.SN', 'Социальный налог', 11, '', 186, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (55, 54, '', '', 'Debt.SN.Base', 'База СН', 11, 217, '', '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (56, 54, '', '', 'Debt.SN.KBK.103101', '103101 - соц налог', 11, 76, 18, '{"Role.Generic.FullName": "Социальный налог","Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (57, 54, '', '', 'Debt.SN.Rate', 'Ставка СН', 11, '', 188, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (58, 54, '', '', 'Debt.SN.SNMinusGFSS', 'Корректировка СН на ГФСС', 11, '', 191, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (59, 1, '', '', 'Debt.VAT', 'НДС', 11, '', 186, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (60, 59, '', '', 'Debt.VAT.Base', 'База НДС', 11, 218, '', '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (61, 59, '', '', 'Debt.VAT.Import', 'НДС импорта', 11, '', 186, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (62, 61, '', '', 'Debt.VAT.Import.Base', 'База НДС импорта', 11, 212, 176, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (63, 61, '', '', 'Debt.VAT.Import.RateBasic', 'Осн ставка НДС импорта', 11, 122, 188, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (64, 59, '', '', 'Debt.VAT.Purchase', 'НДС зачета', 11, 224, '', '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (65, 64, '', '', 'Debt.VAT.Purchase.RateBasic', 'Осн ставка НДС зачета', 11, 122, 188, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (66, 64, '', '', 'Debt.VAT.Purchase.RateReduce', 'Сниженная ставка НДС зачета', 11, 125, 189, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (67, 59, '', '', 'Debt.VAT.Sell', 'НДС реализации', 11, 225, '', '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (68, 67, '', '', 'Debt.VAT.Sell.KBK.105101', '105101 - НДС на ТРУ на терр РК', 11, 76, 18, '{"Role.Generic.FullName": "НДС на произведенные товары, выполненные работы и оказанные услуги на территории РК","Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (69, 67, '', '', 'Debt.VAT.Sell.RateFree', 'Осв ставка НДС реализации', 11, 125, 187, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (70, 67, '', '', 'Debt.VAT.Sell.RateBasic', 'Осн ставка НДС реализации', 11, 224, 188, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (71, 67, '', '', 'Debt.VAT.Sell.RateReduce', 'Сниженная ставка НДС реализации', 11, 125, 189, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (72, 67, '', '', 'Debt.VAT.Sell.RateZero', 'Нулевая ставка НДС реализации', 11, 125, 190, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (73, 1, '', '', 'Debt.Car', 'Налог на транспортные средства', 11, '', '', '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (74, 73, '', '', 'Debt.Car.KBK.104401', '104401 - НТС с ЮЛ', 11, 76, 18, '{"Role.Generic.FullName": "Налог на транспортные средства с юр лиц","Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (75, 73, '', '', 'Debt.Car.KBK.104402', '104402 - НТС с ФЛ', 11, 76, 18, '{"Role.Generic.FullName": "Налог на транспортные средства с физ лиц","Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (76, 1, '', '', 'Debt.Other', 'Плата за загрязнение окружающей среды', 11, '', '', '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (77, 1, '', '', 'Debt.Land', 'Земельный налог', 11, '', '', '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (78, 1, '', '', 'Debt.Property', 'Налог на имущество', 11, '', '', '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (79, 67, '', '', 'Debt.VAT.Sell.RateLess', 'Безналоговая ставка НДС реализации', 11, 125, 195, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (80, 64, '', '', 'Debt.VAT.Purchase.RateLess', 'Безналоговая ставка НДС зачета', 11, 125, 195, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (81, 64, '', '', 'Debt.VAT.Purchase.RateFree', 'Осв ставка НДС зачета', 11, 125, 187, '{"Role.Generic.Code": "Debt.Basic",}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (82, 64, '', '', 'Debt.VAT.Purchase.RateZero', 'Нулевая ставка НДС зачета', 11, 125, 190, '{"Role.Generic.Code": "Debt.Basic",}');

-- Table: Face
CREATE TABLE IF NOT EXISTS Face (
    Id          INTEGER PRIMARY KEY ASC AUTOINCREMENT,
    Parent      INTEGER
                        REFERENCES Face (Id),
    Date1       TEXT,
    Date2       TEXT,
    Code        TEXT,
    Description TEXT,
    Geo         INTEGER
                        REFERENCES Geo (Id),
    Role        INTEGER
                        REFERENCES Role (Id),
    Info        INTEGER
                        REFERENCES Info (Id),
    More        TEXT
);

INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (1, 11, '', '', 'Face.enbek', 'МТиСЗН РК', 11, 115, 57, '{"Role.Generic.Code": "Face.Basic",}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (2, 11, '', '', 'Face.FA1', 'Лицо учета1', 9, 110, 121, '{"Role.Generic.Code": "Face.Basic",}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (3, 2, '', '', 'Face.FA1.AdmStaff', 'Лицо учета1.АУП', '', 197, 72, '{"Role.Generic.Code": "Face.Basic","Face.StoreBasic",}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (4, 2, '', '', 'Face.FA1.Bank1', 'Лицо учета1.Банк1', '', 193, 72, '{"Role.Generic.Code": "Face.Basic","Face.StoreBasic",}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (5, 2, '', '', 'Face.FA1.Cash1', 'Лицо учета1.Касса1', '', 195, 72, '{"Role.Generic.Code": "Face.Basic","Face.StoreBasic",}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (6, 2, '', '', 'Face.FA1.StaffTable', 'Лицо учета1.штатное расписание', '', 189, 72, '{"Role.Generic.Code": "Face.Basic",}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (7, 6, '', '', 'Face.FA1.StaffTable.Boss', 'Лицо учета1.Директор', '', 114, 101, '{"Role.Generic.Code": "Face.Basic",}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (8, 6, '', '', 'Face.FA1.StaffTable.ChiefAccountant', 'Лицо учета1.Главный бухгалтер', '', 114, 101, '{"Role.Generic.Code": "Face.Basic",}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (9, 2, '', '', 'Face.FA1.Store1', 'Лицо учета1.Склад1', 9, 199, 72, '{"Role.Generic.Code": "Face.Basic","Face.StoreBasic",}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (10, 3, '', '', 'Face.FA1.User1', 'Лицо учета1.User1', '', 122, 63, '{"Role.Generic.Code": "Face.Basic","Role.Generic.Code": "Face.UserBasic",}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (11, '', '', '', 'Face.', 'FaceData', '', 67, 47, '{"Role.Generic.Code": "Face.Basic",}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (20, 11, '', '', 'Face.GCVP', 'GCVPKZ2A', 11, 112, 57, '{"Role.Generic.FullName": "НАО Государственная корпорация Правительство для граждан","Info.Code.BIC": "GCVPKZ2A","Role.Generic.Code": "Face.Basic",}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (21, 20, '', '', 'Face.GCVP-GFSS.Bank1', 'GCVPKZ2A.KZ67009SS00368609110', '', 193, 34, '{"Info.Code.IBAN": "KZ67009SS00368609110","Role.Generic.Code": "Face.Basic",}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (22, 20, '', '', 'Face.GCVP-OPV.Bank1', 'GCVPKZ2A.KZ12009NPS0413609816', '', 193, 181, '{"Info.Code.IBAN": "KZ12009NPS0413609816","Role.Generic.Code": "Face.Basic",}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (23, 20, '', '', 'Face.GCVP-OSMS.Bank1', 'GCVPKZ2A.KZ92009MEDS368609103', '', 193, 39, '{"Info.Code.IBAN": "KZ92009MEDS368609103","Role.Generic.Code": "Face.Basic",}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES (25, 11, '', '', 'Face.kgd', 'КГД', 11, 115, 57, '{"Role.Generic.FullName": "Комитет государственных доходов","Role.Generic.Code": "Face.Basic",}');

-- Table: Geo
CREATE TABLE IF NOT EXISTS Geo (
    Id          INTEGER PRIMARY KEY ASC AUTOINCREMENT,
    Parent      INTEGER
                        REFERENCES Geo (Id),
    Date1       TEXT,
    Date2       TEXT,
    Code        TEXT,
    Description TEXT,
    Unit        INTEGER
                        REFERENCES Unit (Id),
    More        TEXT
);

INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (1, '', '16-сен-21', '', 'Geo.', 'GeoData', 62, '');
INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (2, 11, '16-сен-21', '', 'Geo.Almaty', 'Алматы', 127, '');
INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (3, 1, '16-сен-21', '', 'Geo.BE', 'РБ', 128, '');
INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (4, 1, '16-сен-21', '', 'Geo.Ch', 'КНР', 128, '');
INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (5, 1, '16-сен-21', '', 'Geo.DE', 'ФРГ', 128, '');
INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (6, 1, '16-сен-21', '', 'Geo.EAEU', 'ЕАЭС', 135, '');
INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (7, 1, '16-сен-21', '', 'Geo.EU', 'ЕС', 135, '13');
INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (8, 1, '16-сен-21', '', 'Geo.KG', 'Кыргызстан', 128, '');
INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (9, 11, '16-сен-21', '', 'Geo.Nur-Sultan', 'Нур-Cултан', 127, '');
INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (10, 1, '16-сен-21', '', 'Geo.OESD', 'ОЭСР', 137, '');
INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (11, 1, '16-сен-21', '', 'Geo.Qazaqstan', 'РК', 128, '22');
INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (12, 1, '16-сен-21', '', 'Geo.RF', 'РФ', 128, '35');
INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (13, 1, '16-сен-21', '', 'Geo.USA', 'США', 128, '40');
INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (14, 1, '16-сен-21', '', 'Geo.UZ', 'РУ', 128, '');
INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (15, 1, '16-сен-21', '', 'Geo.WTO', 'ВТО', 137, '');

-- Table: Info
CREATE TABLE IF NOT EXISTS Info (
    Id          INTEGER PRIMARY KEY ASC AUTOINCREMENT,
    Parent      INTEGER
                        REFERENCES Info (Id),
    Date1       TEXT,
    Date2       TEXT,
    Code        TEXT,
    Description TEXT,
    More        TEXT
);

INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (1, '', '', '', 'Info.', 'InfoData', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (2, 1, '', '', 'Info.Address', 'Address', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (3, 2, '', '', 'Info.Address.Home', 'домашний', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (4, 2, '', '', 'Info.Address.Law', 'юридический', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (5, 2, '', '', 'Info.Address.Post', 'почтовый', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (6, 2, '', '', 'Info.Address.Reg', 'прописки (регистрации)', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (7, 1, '', '', 'Info.Asset', 'Asset', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (8, 7, '', '', 'Info.Asset.Asset', 'актив', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (9, 7, '', '', 'Info.Asset.Catalog', 'каталог активов', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (10, 7, '', '', 'Info.Asset.SubAsset', 'субактив', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (11, 1, '', '', 'Info.Code', 'Code', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (12, 11, '', '', 'Info.Code.Alfa3', 'альфа3 код', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (13, 11, '', '', 'Info.Code.Art', 'артикул', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (14, 11, '', '', 'Info.Code.BIC', 'БИК (BIC)', '{"Role.Generic.FullName": "Банковский идентификационный код","Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (15, 11, '', '', 'Info.Code.EAN', 'EAN код', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (16, 11, '', '', 'Info.Code.IBAN', 'IBAN (ИИК)', '{"Role.Generic.FullName": "IBAN",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (17, 11, '', '', 'Info.Code.KBE', 'КБЕ', '{"Role.Generic.FullName": "Код бенефициара","Role.Generic.Code": "Info.Basic","Role.Generic.Code": "Tax.CodePay",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (18, 11, '', '', 'Info.Code.KBK', 'КБК', '{"Role.Generic.FullName": "Код бюджетной классификации","Role.Generic.Code": "Info.Basic","Role.Generic.Code": "Tax.CodePay",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (19, 11, '', '', 'Info.Code.KNP', 'КНП', '{"Role.Generic.FullName": "Код назначения платежа","Role.Generic.Code": "Info.Basic","Role.Generic.Code": "Tax.CodePay",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (20, 11, '', '', 'Info.Code.KOF', 'код КОФ', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (21, 11, '', '', 'Info.Code.KPVED', 'код КПВЭД', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (22, 11, '', '', 'Info.Code.MKEI', 'код МКЕИ', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (23, 11, '', '', 'Info.Code.OKPO', 'код ОКПО', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (24, 11, '', '', 'Info.Code.Post', 'почтовый код РК', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (25, 11, '', '', 'Info.Code.TNVED', 'код ТНВЭД', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (26, 11, '', '', 'Info.Code.VIN', 'VIN код', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (27, 1, '', '', 'Info.Cost', 'Cost', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (28, 27, '', '', 'Info.Cost.Accounting', 'бухгалтерская себестоимость', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (29, 27, '', '', 'Info.Cost.Standard', 'нормативная (стандартная) себестоимость', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (30, 27, '', '', 'Info.Cost.Store', 'складская себестоимость', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (31, 1, '', '', 'Info.Deal', 'Deal', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (32, 31, '', '', 'Info.Deal.Alimony', 'алименты', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (33, 31, '', '', 'Info.Deal.ContractWork', 'подрядные работы', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (34, 31, '', '', 'Info.Deal.GFSS', 'ГФСС', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (35, 31, '', '', 'Info.Deal.GSVP', 'НАО-ГЦВП', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (36, 31, '', '', 'Info.Deal.Loan', 'займ, кредит', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (37, 31, '', '', 'Info.Deal.Main', 'купля-продажа', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (38, 31, '', '', 'Info.Deal.MinistryLabor', 'МТиСЗН', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (39, 31, '', '', 'Info.Deal.OSMS', 'ОСМС', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (40, 31, '', '', 'Info.Deal.ProductionOrder', 'заказ производства', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (41, 31, '', '', 'Info.Deal.Rent', 'аренда', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (42, 31, '', '', 'Info.Deal.Staff', 'трудовой', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (43, 1, '', '', 'Info.Entity', 'Entity', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (44, 43, '', '', 'Info.Entity.Doc', 'документ-журнал', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (45, 43, '', '', 'Info.Entity.Journal', 'журнал документов', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (46, 43, '', '', 'Info.Entity.MainForm', 'основная входная форма', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (47, 43, '', '', 'Info.Entity.Reference', 'справочник', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (48, 1, '', '', 'Info.ExchangeRate', 'ExchangeRate', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (49, 48, '', '', 'Info.ExchangeRate.Bank', 'курс комм банка', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (50, 48, '', '', 'Info.ExchangeRate.Market', 'рыночный курс', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (51, 48, '', '', 'Info.ExchangeRate.NationalBank', 'курс Нацбанка', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (52, 48, '', '', 'Info.ExchangeRate.Stock', 'курс биржи', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (53, 1, '', '', 'Info.Face', 'Face', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (54, 53, '', '', 'Info.Face.Branch', 'филиал', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (55, 53, '', '', 'Info.Face.Businessman', 'ИП', '{"Role.Generic.FullName": "Индивидуальный предприниматель","Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (56, 53, '', '', 'Info.Face.Corp', 'ТОО', '{"Role.Generic.FullName": "Товарищество с ограниченной ответственностью","Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (57, 53, '', '', 'Info.Face.GovAgency', 'ГУ', '{"Role.Generic.FullName": "Государственное учреждение","Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (58, 53, '', '', 'Info.Face.JointStockCompany', 'АО', '{"Role.Generic.FullName": "Акционерное общество","Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (59, 53, '', '', 'Info.Face.LegalEntity', 'юридическое лицо', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (60, 53, '', '', 'Info.Face.Person', 'физическое лицо', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (61, 53, '', '', 'Info.Face.QuasiGov1', 'РГКП', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (62, 53, '', '', 'Info.Face.QuasiGov2', 'КГКП', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (63, 53, '', '', 'Info.Face.User', 'пользователь', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (64, 1, '', '', 'Info.Generic', 'Generic', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (65, 64, '', '', 'Info.Generic.Cell', 'телефон сотовый', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (66, 64, '', '', 'Info.Generic.Description', 'расшифровка', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (67, 64, '', '', 'Info.Generic.Email', 'емайл', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (68, 64, '', '', 'Info.Generic.Extra', 'необычный', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (69, 64, '', '', 'Info.Generic.FullDescription', 'полное описание', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (70, 64, '', '', 'Info.Generic.FullName', 'полное наименование', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (71, 64, '', '', 'Info.Generic.Workbooko', 'логотип', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (72, 64, '', '', 'Info.Generic.Main', 'общая инфо', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (73, 64, '', '', 'Info.Generic.Phone', 'телефон', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (74, 64, '', '', 'Info.Generic.Photo', 'фото', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (75, 64, '', '', 'Info.Generic.Sert', 'ключ, сертификат', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (76, 64, '', '', 'Info.Generic.ShortDescription', 'краткое описание', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (77, 64, '', '', 'Info.Generic.ShortName', 'сокращенное наименование', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (78, 64, '', '', 'Info.Generic.Site', 'сайт', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (79, 64, '', '', 'Info.Generic.Street-House', 'улица, дом', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (80, 64, '', '', 'Info.Generic.Time', 'время', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (81, 64, '', '', 'Info.Generic.Variant', 'вариант', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (82, 1, '', '', 'Info.Item', 'Item', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (83, 82, '', '', 'Info.Item.Financial', 'финансовая деятельность', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (84, 82, '', '', 'Info.Item.Invest', 'инвестиционная деятельность', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (85, 82, '', '', 'Info.Item.Main', 'операционная деятельность', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (86, 1, '', '', 'Info.List', 'List', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (87, 86, '', '', 'Info.List.ExemptionList', 'Перечень изъятий', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (88, 86, '', '', 'Info.List.StopList', 'Стоп-лист по отгрузке', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (89, 1, '', '', 'Info.Workbook', 'Workbook', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (90, 89, '', '', 'Info.Workbook.Deal.Devivery', 'поставка договора', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (91, 89, '', '', 'Info.Workbook.Deal.Movement', 'движения договора', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (92, 89, '', '', 'Info.Workbook.Level0.Main', 'Workbook.Level0.общее', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (93, 89, '', '', 'Info.Workbook.Level1.Amount', 'Workbook.Level1.сумма', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (94, 89, '', '', 'Info.Workbook.Level1.Cost', 'Workbook.Level1.себ-ть сумма', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (95, 89, '', '', 'Info.Workbook.Level1.Price', 'Workbook.Level1.цена', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (96, 89, '', '', 'Info.Workbook.Level1.Quantity', 'Workbook.Level1.кол-во', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (97, 89, '', '', 'Info.Workbook.Level2.Depreciation', 'Workbook.Level2.аморт-я', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (98, 89, '', '', 'Info.Workbook.Level2.TaxExcess', 'Workbook.Level2.налоги сверх суммы', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (99, 89, '', '', 'Info.Workbook.Level2.TaxTotal', 'Workbook.Level2.налоги в сумме', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (100, 1, '', '', 'Info.Management', 'Management', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (101, 100, '', '', 'Info.Management.Boss', 'директор', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (102, 100, '', '', 'Info.Management.Chief', 'начальник', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (103, 100, '', '', 'Info.Management.Driver', 'водитель', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (104, 100, '', '', 'Info.Management.LeadingSpecialist', 'ведущий специалист', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (105, 100, '', '', 'Info.Management.Manager', 'управляющий', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (106, 100, '', '', 'Info.Management.Responsible', 'ответственный', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (107, 1, '', '', 'Info.Math', 'Math', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (108, 107, '', '', 'Info.Math.Round1.5To1', 'округлять 1,5 до 1', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (109, 107, '', '', 'Info.Math.Round1.5To2', 'округлять 1,5 до 2', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (110, 107, '', '', 'Info.Math.RoundDownward', 'округлять всегда в меньшую сторону', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (111, 107, '', '', 'Info.Math.RoundUpward', 'округлять всегда в большую сторону', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (112, 1, '', '', 'Info.PersonData', 'PersonData', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (113, 112, '', '', 'Info.PersonData.Autobiography', 'автобиография', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (114, 112, '', '', 'Info.PersonData.DateBirth', 'дата рождения', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (115, 112, '', '', 'Info.PersonData.Name', 'имя', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (116, 112, '', '', 'Info.PersonData.Nationality', 'национальность', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (117, 112, '', '', 'Info.PersonData.Patronymic', 'отчество', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (118, 112, '', '', 'Info.PersonData.Resume', 'резюме', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (119, 112, '', '', 'Info.PersonData.Surname', 'фамилия', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (120, 1, '', '', 'Info.Profile', 'Profile', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (121, 120, '', '', 'Info.Profile.Main', 'общий профиль', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (122, 120, '', '', 'Info.Profile.Store', 'профиль склад', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (123, 120, '', '', 'Info.Profile.PropertyManagement', 'профиль КСК', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (124, 1, '', '', 'Info.Rate', 'Rate', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (125, 124, '', '', 'Info.Rate.MinRate', 'МРП', '{"Role.Generic.FullName": "минимальный расчетный показатель","Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (126, 124, '', '', 'Info.Rate.MinSalary', 'Мин ЗП', '{"Role.Generic.FullName": "минимальная заработная плата","Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (127, 1, '', '', 'Info.RegData', 'RegData', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (128, 127, '', '', 'Info.RegData.BIN', 'БИН', '{"Role.Generic.FullName": "Бизнес-идентификационный номер","Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (129, 127, '', '', 'Info.RegData.IIN', 'ИИН', '{"Role.Generic.FullName": "Индивидуально-идентификационный номер","Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (130, 127, '', '', 'Info.RegData.Passport', 'паспорт РК', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (131, 127, '', '', 'Info.RegData.RNN', 'РНН', '{"Role.Generic.FullName": "Регистрационный номер налогоплательщика","Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (132, 1, '', '', 'Info.Relation', 'Relation', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (133, 132, '', '', 'Info.Relation.Alimonier', 'получатель алиментов', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (134, 132, '', '', 'Info.Relation.MainCalc', 'основной пересчет', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (135, 132, '', '', 'Info.Relation.Pensioner', 'пенсионер', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (136, 1, '', '', 'Info.Report', 'Отчет', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (137, 136, '', '', 'Info.Report.Analysis', 'анализ', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (138, 136, '', '', 'Info.Report.Balance', 'остатки', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (139, 136, '', '', 'Info.Report.BalanceTurnover', 'остатки и обороты', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (140, 136, '', '', 'Info.Report.Depreciation', 'расчет амортизации', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (141, 136, '', '', 'Info.Report.Detail', 'карточка', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (142, 136, '', '', 'Info.Report.DocLawForm', 'нормативная форма документа', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (143, 136, '', '', 'Info.Report.FinForm', 'фин отчет', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (144, 143, '', '', 'Info.Report.FinForm.Balance', 'баланс', '{"Role.Generic.FullName": "Бухгалтерский баланс","Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (145, 143, '', '', 'Info.Report.FinForm.Capital', 'капитал', '{"Role.Generic.FullName": "Отчет о движении капитала","Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (146, 143, '', '', 'Info.Report.FinForm.Income', 'доход', '{"Role.Generic.FullName": "Отчет о доходах и расходах","Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (147, 143, '', '', 'Info.Report.FinForm.Money', 'деньги', '{"Role.Generic.FullName": "Отчет о движении денег","Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (148, 136, '', '', 'Info.Report.List', 'список', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (149, 136, '', '', 'Info.Report.PaySheet', 'реестр платежей', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (150, 136, '', '', 'Info.Report.PriceList', 'прайс-лист', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (151, 136, '', '', 'Info.Report.Revise', 'акт сверки', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (152, 136, '', '', 'Info.Report.SalaryInquery', 'справка по зарплате', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (153, 136, '', '', 'Info.Report.SalarySheet', 'расчетная ведомость начисления ЗП', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (154, 136, '', '', 'Info.Report.SalarySummary', 'свод зарплаты', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (155, 136, '', '', 'Info.Report.Sheet', 'ведомость', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (156, 136, '', '', 'Info.Report.StaffDoc', 'кадровый приказ', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (157, 136, '', '', 'Info.Report.TaxForm', 'налог отчет', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (158, 136, '', '', 'Info.Report.TaxRegistry', 'налог регистр', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (159, 1, '', '', 'Info.Sign', 'Sign', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (160, 159, '', '', 'Info.Sign.UseAccTable', 'использовать в плане счетов', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (161, 159, '', '', 'Info.Sign.UseEntry', 'использовать в проводках', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (162, 1, '', '', 'Info.Staff', 'Staff', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (163, 162, '', '', 'Info.Staff.BaseSalary', 'базовый оклад', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (164, 162, '', '', 'Info.Staff.BossSign', 'подпись руководителя', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (165, 162, '', '', 'Info.Staff.ChiefAccountantSign', 'подпись глав бухгалтера', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (166, 1, '', '', 'Info.StaffTime', 'StaffTime', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (167, 166, '', '', 'Info.StaffTime.DayOff', 'выходной день', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (168, 166, '', '', 'Info.StaffTime.Holiday', 'праздничный день', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (169, 1, '', '', 'Info.Store', 'Store', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (170, 169, '', '', 'Info.Store.CoreFund', 'основное средство', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (171, 169, '', '', 'Info.Store.IsDriveLaw', 'есть право вождения', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (172, 169, '', '', 'Info.Store.IsSubStore', 'является субскладом', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (173, 169, '', '', 'Info.Store.NoStoreNoTraffic', 'не требует транспортировки и складирования', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (174, 1, '', '', 'Info.Tax', 'Tax', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (175, 174, '', '', 'Info.Tax.Amount', 'налоговая сумма', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (176, 174, '', '', 'Info.Tax.Base', 'налоговая база', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (177, 174, '', '', 'Info.Tax.BaseDeduction', 'вычет налоговой базы', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (178, 174, '', '', 'Info.Tax.BaseException', 'исключение базы', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (179, 174, '', '', 'Info.Tax.BaseLimit', 'лимит базы', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (180, 174, '', '', 'Info.Tax.Deduction.MinSalary', 'вычет МинЗП', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (181, 174, '', '', 'Info.Tax.Deduction.OPV', 'вычет ОПВ', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (182, 174, '', '', 'Info.Tax.HalfYearReportingCycle', 'полугодовой отчетный цикл', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (183, 174, '', '', 'Info.Tax.MonthBillingCycle', 'месячный расчетный цикл', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (184, 174, '', '', 'Info.Tax.MonthYearBillingCycle', 'месячно-годовой расчетный цикл', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (185, 174, '', '', 'Info.Tax.QuarterBillingCycle', 'квартальный расчетный цикл', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (186, 174, '', '', 'Info.Tax.QuarterReportingCycle', 'квартальный отчетный цикл', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (187, 174, '', '', 'Info.Tax.RateFree', 'освобожденная ставка', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (188, 174, '', '', 'Info.Tax.RateBasic', 'основная ставка', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (189, 174, '', '', 'Info.Tax.RateReduce', 'сниженная ставка', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (190, 174, '', '', 'Info.Tax.RateZero', 'нулевая ставка', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (191, 174, '', '', 'Info.Tax.SNMinusGFSS', 'корректировка СН на ГФСС', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (192, 174, '', '', 'Info.Tax.TaxAdjustment', 'налоговая корректировка', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (193, 174, '', '', 'Info.Tax.YearBillingCycle', 'годовой расчетный цикл', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (194, 174, '', '', 'Info.Tax.YearReportingCycle', 'годовой отчетный цикл', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (195, 174, '', '', 'Info.Tax.RateLess', 'безналоговая ставка', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (196, 174, '', '', 'Info.Tax.FactBillingCycle', 'фактический расчетный цикл', '{"Role.Generic.Code": "Info.Basic",}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES (197, 174, '', '', 'Info.Tax.FactReportingCycle', 'фактический отчетный цикл', '{"Role.Generic.Code": "Info.Basic",}');

-- Table: Item
CREATE TABLE IF NOT EXISTS Item (
    Id          INTEGER PRIMARY KEY ASC AUTOINCREMENT,
    Parent      INTEGER
                        REFERENCES Item (Id),
    Date1       TEXT,
    Date2       TEXT,
    Code        TEXT,
    Description TEXT,
    More        TEXT
);

INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (1, '', '', '', 'Item.', 'ItemData', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (2, 1, '', '', 'Item.Advance', 'авансы', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (3, 1, '', '', 'Item.Advertising', 'реклама', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (4, 1, '', '', 'Item.Bank', 'РКО, услуги банка', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (5, 1, '', '', 'Item.Car', 'автопарк', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (6, 1, '', '', 'Item.Charity', 'благотворительность', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (7, 1, '', '', 'Item.Cost', 'себестоимость', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (8, 1, '', '', 'Item.Deduction from salary', 'удержания из ЗП', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (9, 1, '', '', 'Item.Depreciation', 'амортизация', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (10, 1, '', '', 'Item.Equipment', 'оборудование', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (11, 1, '', '', 'Item.Exchange difference', 'курсовая разница', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (12, 1, '', '', 'Item.Fine', 'штрафы, пени', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (13, 1, '', '', 'Item.Food', 'питание', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (14, 1, '', '', 'Item.Fuel', 'топливо', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (15, 1, '', '', 'Item.Impress', 'подотчет', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (16, 1, '', '', 'Item.Insurance', 'страхование', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (17, 1, '', '', 'Item.Learning', 'обучение персонала', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (18, 1, '', '', 'Item.Loan', 'кредит, овердрафт', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (19, 1, '', '', 'Item.Material', 'материалы', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (20, 1, '', '', 'Item.Office', 'офис, канцелярия, почта', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (21, 1, '', '', 'Item.Other', 'прочее', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (22, 1, '', '', 'Item.Parts', 'запчасти', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (23, 1, '', '', 'Item.Periodical', 'периодика, книги', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (24, 1, '', '', 'Item.Production', 'производство', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (25, 1, '', '', 'Item.Purchase', 'приобретение', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (26, 1, '', '', 'Item.Rent', 'аренда, хранение', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (27, 1, '', '', 'Item.Repair', 'ремонт', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (28, 1, '', '', 'Item.Salary', 'зарплата и отчисления', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (29, 1, '', '', 'Item.Security', 'охрана', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (30, 1, '', '', 'Item.Sell', 'продажа', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (31, 1, '', '', 'Item.Shipping', 'перевозки', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (32, 1, '', '', 'Item.Store', 'склад', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (33, 1, '', '', 'Item.Tax', 'налоги, сборы, отчисления', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (34, 1, '', '', 'Item.Telecom', 'телефон, интернет', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (35, 1, '', '', 'Item.Trip', 'командировки', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (36, 1, '', '', 'Item.Utilities', 'коммунальные услуги', '{"Role.Generic.Code": "Item.Basic",}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES (37, 1, '', '', 'Item.Writeoff', 'списание', '{"Role.Generic.Code": "Item.Basic",}');

-- Table: Mark
CREATE TABLE IF NOT EXISTS Mark (
    Id          INTEGER PRIMARY KEY ASC AUTOINCREMENT,
    Parent      INTEGER
                        REFERENCES Mark (Id),
    Date1       TEXT,
    Date2       TEXT,
    Code        TEXT,
    Description TEXT,
    More        TEXT
);

INSERT INTO Mark (Id, Parent, Date1, Date2, Code, Description, More) VALUES (1, '', '', '', 'Mark.ArcD', 'ArchivalData', '{"Role.Generic.Code": "Mark.Basic",}');
INSERT INTO Mark (Id, Parent, Date1, Date2, Code, Description, More) VALUES (2, '', '', '', 'Mark.CD', 'CurrentData', '{"Role.Generic.Code": "Mark.Basic",}');
INSERT INTO Mark (Id, Parent, Date1, Date2, Code, Description, More) VALUES (3, '', '', '', 'Mark.DD', 'DraftData', '{"Role.Generic.Code": "Mark.Basic",}');
INSERT INTO Mark (Id, Parent, Date1, Date2, Code, Description, More) VALUES (4, '', '', '', 'Mark.DelD', 'DeleteData', '{"Role.Generic.Code": "Mark.Basic",}');
INSERT INTO Mark (Id, Parent, Date1, Date2, Code, Description, More) VALUES (5, '', '', '', 'Mark.ExD', 'ExampleData', '{"Role.Generic.Code": "Mark.Basic",}');
INSERT INTO Mark (Id, Parent, Date1, Date2, Code, Description, More) VALUES (6, '', '', '', 'Mark.ExtD', 'ExternalData', '{"Role.Generic.Code": "Mark.Basic",}');
INSERT INTO Mark (Id, Parent, Date1, Date2, Code, Description, More) VALUES (11, '', '', '', 'Mark.MD', 'MetaData', '{"Role.Generic.Code": "Mark.Basic",}');
INSERT INTO Mark (Id, Parent, Date1, Date2, Code, Description, More) VALUES (12, '', '', '', 'Mark.RuleD', 'RuleData', '{"Role.Generic.Code": "Mark.Basic",}');
INSERT INTO Mark (Id, Parent, Date1, Date2, Code, Description, More) VALUES (13, '', '', '', 'Mark.TemplD', 'TemplateData', '{"Role.Generic.Code": "Mark.Basic",}');
INSERT INTO Mark (Id, Parent, Date1, Date2, Code, Description, More) VALUES (14, '', '', '', 'Mark.TrnD', 'TransferData', '{"Role.Generic.Code": "Mark.Basic",}');

-- Table: Meter
CREATE TABLE IF NOT EXISTS Meter (
    Id          INTEGER PRIMARY KEY ASC AUTOINCREMENT,
    Parent      INTEGER
                        REFERENCES Meter (Id),
    Date1       TEXT,
    Date2       TEXT,
    Code        TEXT,
    Description TEXT,
    Unit        INTEGER
                        REFERENCES Unit (Id),
    More        TEXT
);

INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (1, 10, '', '', 'Meter.Amount', 'сумма', 6, '{"Role.Generic.Code": "Meter.Basic",}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (2, 10, '', '', 'Meter.Authentication', 'аутентификация', 50, '{"Role.Generic.Code": "Meter.Basic",}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (3, 1, '', '', 'Meter.Cost', 'себестоимость', '', '{"Role.Generic.Code": "Meter.Basic",}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (4, 13, '', '', 'Meter.Counter', 'счетчик', 12, '{"Role.Generic.Code": "Meter.Basic",}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (5, 10, '', '', 'Meter.Depth', 'толщина', 48, '{"Role.Generic.Code": "Meter.Basic",}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (6, 10, '', '', 'Meter.Diameter', 'диаметр', 48, '{"Role.Generic.Code": "Meter.Basic",}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (7, 10, '', '', 'Meter.Height', 'высота', 24, '{"Role.Generic.Code": "Meter.Basic",}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (8, 10, '', '', 'Meter.Length', 'длина', 24, '{"Role.Generic.Code": "Meter.Basic",}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (9, 18, '', '', 'Meter.Linear weight 1m', 'погонный вес 1м', 20, '{"Role.Generic.Code": "Meter.Basic",}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (10, '', '', '', 'Meter.', 'MeterData', '', '{"Role.Generic.Code": "Meter.Basic",}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (11, 13, '', '', 'Meter.Number pieces pack', 'кол-во штук в упаковке', 31, '{"Role.Generic.Code": "Meter.Basic",}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (12, 1, '', '', 'Meter.Price', 'цена', '', '{"Role.Generic.Code": "Meter.Basic",}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (13, 10, '', '', 'Meter.Quantity', 'количество', 1, '{"Role.Generic.Code": "Meter.Basic",}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (14, 10, '', '', 'Meter.Rate', 'ставка', 30, '{"Role.Generic.Code": "Meter.Basic",}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (15, 1, '', '', 'Meter.Rating', 'номинал', '', '{"Role.Generic.Code": "Meter.Basic",}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (16, 10, '', '', 'Meter.Time', 'время', '', '{"Role.Generic.Code": "Meter.Basic",}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (17, 10, '', '', 'Meter.Volume', 'объем', 23, '{"Role.Generic.Code": "Meter.Basic",}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (18, 10, '', '', 'Meter.Weight', 'вес', 20, '{"Role.Generic.Code": "Meter.Basic",}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (19, 10, '', '', 'Meter.Width', 'ширина', 24, '{"Role.Generic.Code": "Meter.Basic",}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (20, 10, '', '', 'Meter.PublicHoliday', 'праздник', 31, '{"Role.Generic.Code": "Meter.Basic",}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (21, 10, '', '', 'Meter.ExtraDayOff', 'дополнительный выходной день', 31, '{"Role.Generic.Code": "Meter.Basic",}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES (22, 10, '', '', 'Meter.Matching', 'сопоставление', 31, '{"Role.Generic.Code": "Meter.Basic",}');

-- Table: Price
CREATE TABLE IF NOT EXISTS Price (
    Id          INTEGER PRIMARY KEY ASC AUTOINCREMENT,
    Parent      INTEGER
                        REFERENCES Price (Id),
    Date1       TEXT,
    Date2       TEXT,
    Code        TEXT,
    Description TEXT,
    Role        INTEGER
                        REFERENCES Role (Id),
    Info        INTEGER
                        REFERENCES Info (Id),
    Unit        INTEGER
                        REFERENCES Unit (Id),
    More        TEXT
);

INSERT INTO Price (Id, Parent, Date1, Date2, Code, Description, Role, Info, Unit, More) VALUES (1, '', '', '', 'Price.', 'PriceData', 78, 47, '', '{"Role.Generic.Code": "Price.Basic",}');
INSERT INTO Price (Id, Parent, Date1, Date2, Code, Description, Role, Info, Unit, More) VALUES (2, 1, '', '', 'Price.Basic', 'Оптовая цена', 154, 72, '', '{"Role.Generic.Code": "Price.Basic",}');
INSERT INTO Price (Id, Parent, Date1, Date2, Code, Description, Role, Info, Unit, More) VALUES (3, 1, '', '', 'Price.MarkupBasic', 'Основная наценка', 160, 72, 30, '{"Role.Generic.Code": "Price.Basic",}');
INSERT INTO Price (Id, Parent, Date1, Date2, Code, Description, Role, Info, Unit, More) VALUES (4, 2, '', '', 'Price.SaleBasic', 'Основная скидка', 161, 72, 30, '{"Role.Generic.Code": "Price.Basic",}');
INSERT INTO Price (Id, Parent, Date1, Date2, Code, Description, Role, Info, Unit, More) VALUES (5, 1, '', '', 'Price.USD-KZT', 'USD-KZT (курс тенге к доллару)', 46, 52, 22, '{"Role.Generic.Code": "Price.Basic",}');
INSERT INTO Price (Id, Parent, Date1, Date2, Code, Description, Role, Info, Unit, More) VALUES (6, 1, '', '', 'Price.Retail', 'Розничная цена', 154, 81, '', '{"Role.Generic.Code": "Price.Basic",}');
INSERT INTO Price (Id, Parent, Date1, Date2, Code, Description, Role, Info, Unit, More) VALUES (7, 1, '', '', 'Price.TariffHour', 'Ставка за 1 раб. Час', 156, 72, 22, '{"Role.Generic.Code": "Price.Basic",}');
INSERT INTO Price (Id, Parent, Date1, Date2, Code, Description, Role, Info, Unit, More) VALUES (8, 1, '', '', 'Price.TariffDay', 'Ставка за 1 раб. День', 156, 72, 22, '{"Role.Generic.Code": "Price.Basic",}');

-- Table: Process
CREATE TABLE IF NOT EXISTS Process (
    Id          INTEGER PRIMARY KEY ASC AUTOINCREMENT,
    Parent      INTEGER
                        REFERENCES Process (Id),
    Face1       INTEGER
                        REFERENCES Face (Id),
    Face2       INTEGER
                        REFERENCES Face (Id),
    Face        INTEGER
                        REFERENCES Face (Id),
    Slice       INTEGER
                        REFERENCES Slice (Id),
    Date1       TEXT,
    Date2       TEXT,
    Code        TEXT,
    Description TEXT,
    Sign        INTEGER
                        REFERENCES Sign (Id),
    Account     INTEGER
                        REFERENCES Account (Id),
    Asset       INTEGER
                        REFERENCES Asset (Id),
    Deal        INTEGER
                        REFERENCES Deal (Id),
    Item        INTEGER
                        REFERENCES Item (Id),
    Debt        INTEGER
                        REFERENCES Debt (Id),
    Price       INTEGER
                        REFERENCES Price (Id),
    Role        INTEGER
                        REFERENCES Role (Id),
    Info        INTEGER
                        REFERENCES Info (Id),
    Meter       INTEGER
                        REFERENCES Meter (Id),
    MeterValue  TEXT,
    Unit        INTEGER
                        REFERENCES Unit (Id),
    More        TEXT,
    Mark        INTEGER
                        REFERENCES Mark (Id) 
);

INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (1, 130, 2, '', '', 1, '', '', 'Process.AddSalary', 'Дополн удержание из ЗП', '', '', '', '', '', '', '', 142, 81, '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (2, 1, 2, 11, '', 1, '', '', 'Process.AddSalary.1', 'Удержание из ЗП', 3, 327, '', 1, '', 11, '', 84, 93, 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (3, 1, 2, '', '', 1, '', '', 'Process.AddSalary.2', 'Коррсчет удержания из ЗП', 1, 285, '', '', 8, '', '', 84, 93, 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (4, 130, 2, '', '', 1, '', '', 'Process.Buy', 'Покупка', '', '', '', '', '', '', '', 142, 72, '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (5, 4, 2, 11, 10, 1, '', '', 'Process.Buy.1', 'Согласование вх договора', '', '', 1, '', 25, '', 2, 63, 96, 13, '', 31, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (6, 5, 2, 11, 10, 1, '', '', 'Process.Buy.2 (Contract)', 'Новый договор', '', '', '', 1, 25, '', '', 63, 95, 12, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (7, 6, 11, 10, 10, 1, '', '', 'Process.Buy.3 (Order)', 'Получение вх счета', '', '', '', 1, '', '', '', 74, 92, 12, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (8, 7, 2, '', 11, 9, '', '', 'Process.Buy.3A', 'Оплата вх счета (план)', 3, 323, '', 1, 25, '', '', 73, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (9, 7, 2, '', 11, 1, '', '', 'Process.Buy.4 (Money)', 'Оплата вх счета', '', '', '', 1, '', '', '', 73, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (10, 9, 4, '', 11, 1, '', '', 'Process.Buy.4A', 'Плат поручение исх', 17, '', 2, 1, 25, '', '', 76, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (11, 9, 4, '', 11, 1, '', '', 'Process.Buy.4B', 'Выбытие ДС', 1, 323, 2, 1, 25, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (12, 9, '', '', 11, 1, '', '', 'Process.Buy.4C', 'Списание кред задолж-ти', 3, 329, '', 1, 25, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (13, 7, '', '', '', 1, '', '', 'Process.Buy.5 (Arrival)', 'Исполнение вх счета', '', '', '', '', '', '', '', 80, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (14, 13, '', '', '', 1, '', '', 'Process.Buy.5A', 'Выдача исх доверенности', '', '', 1, 1, 25, '', '', 95, '', 10, '', 1, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (15, 13, 9, '', '', 1, '', '', 'Process.Buy.5B', 'Приход активов.кол-во', 3, 288, 1, 1, 25, '', '', '', 28, 13, '', 1, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (16, 13, 9, '', '', 1, '', '', 'Process.Buy.5C', 'Приход активов.сумма', 3, 288, 1, 1, 25, '', '', '', 28, 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (17, 13, '', '', '', 1, '', '', 'Process.Buy.5CA', 'Приход услуг, работ.сумма', 3, 302, '', 1, 25, '', '', '', 81, 1, '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (18, 13, '', 11, 11, 1, '', '', 'Process.Buy.5D', 'Начисление кред задолж-ти', 1, 346, '', 1, 25, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (19, 13, '', '', 26, 1, '', '', 'Process.Buy.5E (VATBase)', 'Налоговая база НДС зачета', 1, '', '', 6, 25, 60, '', '', 176, 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (20, 13, '', '', 26, 1, '', '', 'Process.Buy.5F (VAT)', 'Начисление НДС зачета', 3, 345, '', 6, 25, 65, '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (21, 13, '', '', '', 1, '', '', 'Process.Buy.6', 'Распределение услуг, работ на активы', '', '', '', '', '', '', '', 92, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (22, 21, '', '', '', 1, '', '', 'Process.Buy.6A', 'Приход работ, услуг.сторно', 3, 302, '', '', '', '', '', '', '', 1, 'storno', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (23, 21, '', '', '', 1, '', '', 'Process.Buy.6B', 'Отнесение работ, услуг на активы', 3, 288, 1, '', '', '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (24, 13, 11, '', 2, 1, '', '', 'Process.Buy.7 (Invoice)', 'Получение счета-фактуры от поставщика', '', '', '', 1, 25, '', '', 70, 72, '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (25, 7, 11, '', 2, 1, '', '', 'Process.Buy.8 (Null)', 'Аннулирование вх счета', '', '', 1, 1, 25, '', 1, 74, 81, '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (26, 130, '', '', '', 1, '', '', 'Process.ChangeCurrency', 'Конвертация валюты', '', '', '', '', '', '', '', 142, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (27, 26, 5, '', '', 1, '', '', 'Process.ChangeCurrency.1', 'Списание ДС на конвертацию', 1, 323, 2, 1, 25, '', '', 73, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (28, 26, 5, '', '', 1, '', '', 'Process.ChangeCurrency.2', 'Покупка валюты', 3, 323, 2, 1, 25, '', '', 73, '', 1, '', 40, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (29, 26, 5, '', '', 1, '', '', 'Process.ChangeCurrency.3', 'Курсовая разница при конвертации', 1, 323, 2, 1, 11, '', '', 73, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (30, 26, '', '', '', 1, '', '', 'Process.ChangeCurrency.4', 'Расход по КР', 3, 306, '', '', 11, 20, '', 73, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (31, 130, '', '', '', 1, '', '', 'Process.Closing', 'Процесс Закрытие счетов', '', '', '', '', '', '', '', 64, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (32, 31, '', '', '', 1, '', '', 'Process.Closing.1', 'Закрытие доходов', 3, 318, '', '', '', '', '', '', '', 3, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (33, 32, '', '', '', 1, '', '', 'Process.Closing.2', 'Итоговый доход', 1, 319, '', '', '', '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (34, 31, '', '', '', 1, '', '', 'Process.Closing.3', 'Закрытие расходов', 1, 301, '', '', '', '', '', '', '', 3, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (35, 31, '', '', '', 1, '', '', 'Process.Closing.4', 'Итоговый расход', 3, 319, '', '', '', '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (36, 130, 9, '', '', 1, '', '', 'Process.CurrentBalance', 'Снятие остатков', '', '', '', '', '', '', '', '', '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (37, 36, 9, '', '', 11, '', '', 'Process.CurrentBalance.1', 'Текущие остатки (отчет)', '', 288, 1, '', '', '', '', 58, 72, 13, '', 1, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (38, 37, 9, '', '', 11, '', '', 'Process.CurrentBalance.1A', 'Текущие остатки.кол-во', 3, 288, 1, '', '', '', '', '', '', 13, '', 1, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (39, 37, 9, '', '', 11, '', '', 'Process.CurrentBalance.1B', 'Текущие остатки.сумма', 3, 288, 1, '', '', '', '', '', '', 3, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (40, 36, 9, '', '', 11, '', '', 'Process.CurrentBalance.2', 'Инв опись', '', 288, 1, '', '', '', '', 58, 81, 13, '', 1, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (41, 37, 9, '', '', 1, '', '', 'Process.CurrentBalance.3', 'Слич ведомость', '', '', 1, '', '', '', '', 58, 81, 13, '', 1, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (42, 41, 9, 11, '', 1, '', '', 'Process.CurrentBalance.3A', 'Списание недостач.кол-во', 1, 288, 1, '', 32, '', '', 96, 81, 13, '', 1, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (43, 41, 9, 11, '', 1, '', '', 'Process.CurrentBalance.3B', 'Списание недостач.сумма', 1, 288, 1, '', 32, '', '', 96, 81, 3, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (44, 41, 2, '', '', 1, '', '', 'Process.CurrentBalance.3C', 'Списание недостач.расход', 3, 302, 1, '', 32, '', '', 96, 81, 1, '', 1, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (45, 130, '', '', '', 1, '', '', 'Process.DebtOffsetting', 'Взаимозачет и списание задолж-ти и авансов', '', '', '', '', '', '', '', 67, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (46, 45, '', '', 11, 1, '', '', 'Process.DebtOffsetting.1', 'Списание кред задолж-ти по договорам', 3, 329, '', 1, 37, '', '', 65, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (47, 45, '', '', 11, 1, '', '', 'Process.DebtOffsetting.2', 'Списание деб задолж-ти по договорам', 1, 298, '', 1, 37, '', '', 65, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (48, 45, '', '', 11, 1, '', '', 'Process.DebtOffsetting.3', 'Списание авансов поставщику', 1, 330, '', 1, 37, '', '', 65, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (49, 45, '', '', 11, 1, '', '', 'Process.DebtOffsetting.4', 'Списание кред задолж-ти поставщика', 3, 329, '', 1, 37, '', '', 65, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (50, 45, '', '', 11, 1, '', '', 'Process.DebtOffsetting.5', 'Списание авансов покупателя', 3, 299, '', 1, 37, '', '', 65, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (51, 45, '', '', 11, 1, '', '', 'Process.DebtOffsetting.6', 'Списание деб задолж-ти покупателя', 1, 298, '', 1, 37, '', '', 65, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (52, 130, '', '', '', 1, '', '', 'Process.Depreciation', 'Начисление амортизации', '', '', '', '', '', '', '', 65, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (53, 52, '', '', '', 1, '', '', 'Process.Depreciation.1', 'Амортизация активов', 1, 310, 1, '', 9, 14, '', 64, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (54, 52, '', '', '', 1, '', '', 'Process.Depreciation.2', 'Затраты по амортизации', 3, 302, '', '', 9, '', '', 64, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (55, 130, '', '', '', 1, '', '', 'Process.Entry', 'Процесс Бух справка', '', '', '', '', '', '', '', 65, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (56, 55, '', 11, 11, 1, '', '', 'Process.Entry.1', 'Бух справка.кол-во', 4, 285, 1, 1, '', 1, 1, '', '', 13, '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (57, 55, '', 11, 11, 1, '', '', 'Process.Entry.2', 'Бух справка.сумма', 4, 285, 1, 1, '', '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (58, 130, '', '', '', 1, '', '', 'Process.ExchangeDifference', 'Расчет курсовой разницы', '', '', '', '', '', '', '', 142, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (59, 58, '', '', 11, 1, '', '', 'Process.ExchangeDifference.1', 'Текущие остатки валютных задолж-тей', 5, 285, '', 1, '', '', '', 65, '', 1, '', 40, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (60, 58, '', '', 11, 1, '', '', 'Process.ExchangeDifference.2', 'Расчет КР', '', 285, '', 1, '', '', '', 65, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (61, 58, '', '', '', 1, '', '', 'Process.ExchangeDifference.3', 'Расходы по КР', 3, 306, '', '', '', '', '', 65, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (62, 58, '', '', '', 1, '', '', 'Process.ExchangeDifference.4', 'Доходы по КР', 1, 322, '', '', '', '', '', 65, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (63, 58, '', '', 11, 1, '', '', 'Process.ExchangeDifference.5', 'Кредиторская задолж-ть по КР', 1, 329, '', 1, '', '', '', 65, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (64, 58, '', '', 11, 1, '', '', 'Process.ExchangeDifference.6', 'Дебиторская задолж-ть по КР', 3, 298, '', 1, '', '', '', 65, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (65, 130, '', '', '', 1, '', '', 'Process.InputInitialBalance', 'Ввод нач остатков', '', '', '', '', '', '', '', 65, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (66, 65, '', 11, 11, 1, '', '', 'Process.InputInitialBalance.1', 'Ввод остатков.кол-во', 5, 285, 1, 1, 1, 1, '', '', '', 13, '', 1, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (67, 65, '', 11, 11, 1, '', '', 'Process.InputInitialBalance.2', 'Ввод остатков.сумма', 5, 285, 1, 1, 1, 1, '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (68, 130, '', 3, '', 1, '', '', 'Process.MainSalary', 'Начисление ЗП и налогов', '', '', '', '', '', '', '', 142, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (69, 68, '', 11, '', 1, '', '', 'Process.MainSalary.1', 'Табелирование.рабочие дни', 9, '', '', 3, '', '', 8, 84, 72, 13, '', 43, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (70, 68, '', 11, '', 1, '', '', 'Process.MainSalary.1A', 'Табелирование.рабочие часы', 9, '', '', 3, '', '', 8, 84, 81, 13, '', 44, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (71, 68, '', 11, '', 1, '', '', 'Process.MainSalary.2', 'Начисления', '', '', '', '', 28, '', '', 87, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (72, 71, '', 11, '', 1, '', '', 'Process.MainSalary.2A', 'Оклад', 1, 327, '', '', 28, 50, '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (73, 71, '', 11, '', 1, '', '', 'Process.MainSalary.2B', 'Премия', 1, 327, '', '', 28, 49, '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (74, 71, '', 11, '', 1, '', '', 'Process.MainSalary.2C', 'Отпускные', 1, 327, '', '', 28, 53, '', '', 81, 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (75, 71, '', 11, '', 1, '', '', 'Process.MainSalary.2D', 'Компенсация за отпуск', 1, 327, '', '', 28, 52, '', '', 81, 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (76, 71, '', '', '', 1, '', '', 'Process.MainSalary.2E', 'Расход', 3, 302, '', '', 28, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (77, 68, '', '', '', 1, '', '', 'Process.MainSalary.3', 'Удержания, налоги, отчисления', '', '', '', '', '', '', '', 87, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (78, 77, '', '', '', 1, '', '', 'Process.MainSalary.3A', 'Вычеты ИПН', 1, '', '', '', '', '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (79, 77, '', '', '', 1, '', '', 'Process.MainSalary.3B', 'База ОПВ', 1, '', '', '', '', 41, '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (80, 77, '', 11, 11, 1, '', '', 'Process.MainSalary.3C', 'Удержание ОПВ', 1, 342, '', '', '', 43, '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (81, 77, '', '', '', 1, '', '', 'Process.MainSalary.3D', 'База взносов ОСМС', 1, '', '', '', '', 35, '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (82, 77, '', '', '', 1, '', '', 'Process.MainSalary.3E', 'Удержание взносов ОСМС', 1, 340, '', '', '', 36, '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (83, 77, '', '', '', 1, '', '', 'Process.MainSalary.3F', 'База ИПН', 1, '', '', '', '', 26, '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (84, 77, '', '', '', 1, '', '', 'Process.MainSalary.3G', 'Удержание ИПН', 1, 337, '', '', '', 25, '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (85, 77, '', '', '', 1, '', '', 'Process.MainSalary.3H', 'База алиментов', 1, '', '', '', '', 7, '', '', 81, 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (86, 77, '', '', '', 1, '', '', 'Process.MainSalary.3I', 'Алименты.начисление получателям', 1, 332, '', '', '', 7, '', '', 81, 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (87, 77, '', '', '', 1, '', '', 'Process.MainSalary.3J', 'Всего удержания из ЗП', 3, 327, '', '', '', 6, '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (88, 77, '', '', '', 1, '', '', 'Process.MainSalary.3K', 'База отчислений ГФСС', 1, '', '', '', '', 22, '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (89, 77, '', '', '', 1, '', '', 'Process.MainSalary.3L', 'Начисление отчислений ГФСС', 1, 335, '', '', '', 21, '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (90, 77, '', '', '', 1, '', '', 'Process.MainSalary.3LA', 'Расходы по отчислениям ГФСС', 3, 302, '', '', 28, 21, '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (91, 77, '', '', '', 1, '', '', 'Process.MainSalary.3M', 'База СН', 1, '', '', '', '', 55, '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (92, 77, '', '', '', 1, '', '', 'Process.MainSalary.3N', 'Расходы по отчислениям СН', 3, 302, '', '', 28, 54, '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (93, 77, '', '', '', 1, '', '', 'Process.MainSalary.3NA', 'Начисление СН', 1, 344, '', '', '', 54, '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (94, 77, '', '', '', 1, '', '', 'Process.MainSalary.3O', 'База отчислений ОСМС', 1, '', '', '', '', 35, '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (95, 77, '', '', '', 1, '', '', 'Process.MainSalary.3P', 'Расходы по отчислениям ОСМС', 3, 302, '', '', 28, 38, '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (96, 77, '', '', '', 1, '', '', 'Process.MainSalary.3Q', 'Начисление отчислений ОСМС', 1, 339, '', '', '', 38, '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (97, 68, '', '', '', 1, '', '', 'Process.MainSalary.4', 'Реестры платежей', '', '', '', '', '', '', '', '', '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (98, 97, 4, 11, 20, 1, '', '', 'Process.MainSalary.4A', 'Составление реестра платежей', '', '', '', '', '', '', '', 77, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (99, 97, 4, 11, 11, 1, '', '', 'Process.MainSalary.4B', 'Плат поручение исх', 20, '', '', '', '', '', '', 76, 19, 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (100, 97, 4, '', '', 1, '', '', 'Process.MainSalary.4C', 'Списание ДС', 1, 323, 2, '', 28, '', '', 60, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (101, 97, '', 11, 11, 1, '', '', 'Process.MainSalary.4D', 'Списание задолженности', 3, 331, '', '', 28, '', '', 60, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (102, 68, 4, '', '', 1, '', '', 'Process.MainSalary.5', 'Возврат реестра платежей', 15, '', '', '', '', 1, '', 77, 81, 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (103, 102, '', 11, 20, 1, '', '', 'Process.MainSalary.5A', 'Восстановление задолж-ти', 1, 331, '', '', 28, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (104, 102, 4, '', '', 1, '', '', 'Process.MainSalary.5B', 'Поступление ДС', 3, 323, 2, '', 28, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (105, 130, '', '', '', 1, '', '', 'Process.PaySalary', 'Выплата ЗП', '', '', '', '', '', '', '', 86, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (106, 105, '', '', '', 1, '', '', 'Process.PaySalary.1', 'Выплата ЗП через банк', '', '', '', '', 28, '', '', '', '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (107, 106, 4, '', 11, 1, '', '', 'Process.PaySalary.1A', 'Плат поручение исх', 19, '', 2, '', 28, '', '', 76, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (108, 106, '', 11, 11, 1, '', '', 'Process.PaySalary.1B', 'Списание задолж-ти по ЗП', 3, 327, '', 3, 28, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (109, 106, 4, '', '', 1, '', '', 'Process.PaySalary.1C', 'Списание ДС', 1, 323, '', '', 28, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (110, 105, '', '', '', 1, '', '', 'Process.PaySalary.2', 'Возврат выплаты ЗП из банка', 15, '', '', '', '', '', '', '', 81, '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (111, 110, '', 11, 11, 1, '', '', 'Process.PaySalary.2A', 'Восстановление задолж-ти по ЗП', 1, 327, '', 3, 28, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (112, 110, 4, '', '', 1, '', '', 'Process.PaySalary.2B', 'Поступление ДС', 3, 323, '', '', 28, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (113, 105, '', '', '', 1, '', '', 'Process.PaySalary.3', 'Выплата ЗП через кассу', 19, '', '', '', 28, '', '', '', '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (114, 113, '', 11, 11, 1, '', '', 'Process.PaySalary.3A', 'Списание задолж-ти по ЗП', 3, 327, '', 3, 28, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (115, 113, 5, '', '', 1, '', '', 'Process.PaySalary.3B', 'Списание ДС', 1, 323, '', '', 28, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (116, 130, '', '', '', 1, '', '', 'Process.PettyCash', 'Аванс в подотчет', '', '', '', '', '', '', '', 142, 72, '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (117, 116, '', '', '', 1, '', '', 'Process.PettyCash.1', 'Согласование выдачи аванса в подотчет', '', '', '', 1, 15, '', '', 68, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (118, 117, 5, 11, '', 1, '', '', 'Process.PettyCash.2 (Payment)', 'Выдача аванса в подотчет', 18, '', '', '', '', '', '', 75, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (119, 118, 5, 11, '', 1, '', '', 'Process.PettyCash.2A', 'Выплата ДС', 1, 323, 2, '', 15, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (120, 118, '', 11, '', 1, '', '', 'Process.PettyCash.2B', 'Начисление подотчета', 3, 317, '', '', 15, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (121, 116, '', 11, 11, 1, '', '', 'Process.PettyCash.3 (Imprest)', 'Погашение кредиторской задолж-ти', '', '', '', '', '', '', '', 68, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (122, 121, '', 11, 11, 1, '', '', 'Process.PettyCash.3A', 'Списание кредиторской задолж-ти', 3, 329, '', 1, 15, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (123, 121, '', 11, '', 1, '', '', 'Process.PettyCash.3B', 'Списание подотчетной суммы', 1, 317, '', '', 15, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (124, 118, '', '', '', 1, '', '', 'Process.PettyCash.4 (ReturnCash)', 'Возврат аванса из подотчета', 15, '', '', '', '', '', '', 69, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (125, 124, 5, 11, '', 1, '', '', 'Process.PettyCash.4A', 'Поступление ДС', 3, 323, 2, '', 15, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (126, 124, '', 11, '', 1, '', '', 'Process.PettyCash.4B', 'Списание подотчета', 1, 317, '', '', 15, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (127, 130, '', 11, '', 1, '', '', 'Process.Price', 'Прайс-лист', '', '', '', '', '', '', '', 142, 72, '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (128, 127, '', 11, '', 1, '', '', 'Process.Price.1', 'Согласование прайса', '', '', 1, 1, '', '', 1, 78, '', 13, '1', 11, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (129, 127, '', 11, '', 1, '', '', 'Process.Price.2', 'Утверждение прайса', 22, '', 1, 1, '', '', 1, 78, '', 12, '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (130, '', 2, '', '', 1, '', '', 'Process.', 'ProcessData', '', '', '', '', '', '', '', 79, 47, '', '', 22, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (131, 130, '', '', '', 1, '', '', 'Process.ReturnBuy', 'Возврат поставщику', '', '', '', '', '', '', '', 142, 81, '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (132, 131, 9, 11, 11, 1, '', '', 'Process.ReturnBuy.1', 'Согласование возврата поставщику', '', '', 1, 1, '', '', 1, 81, '', 13, '', 1, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (133, 132, '', '', '', 1, '', '', 'Process.ReturnBuy.2 (BuyStorno)', 'Возврат активов поставщику', '', '', '', '', '', '', '', 81, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (134, 133, 9, 11, 11, 1, '', '', 'Process.ReturnBuy.2A', 'Приход активов\кол-во (сторно)', 3, 288, 1, 1, 25, '', 1, '', '', 13, 'storno', 1, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (135, 133, '', '', '', 1, '', '', 'Process.ReturnBuy.2B', 'Приход активов\себ-ть (сторно)', 3, 288, 1, 1, 25, '', 1, '', '', 1, 'storno', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (136, 133, '', '', 11, 1, '', '', 'Process.ReturnBuy.2C', 'Списание кредиторской задолж-сти (сторно)', 1, 329, '', 1, 25, '', '', '', '', 1, 'storno', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (137, 133, '', '', 26, 1, '', '', 'Process.ReturnBuy.2D (VATStorno)', 'Начисление НДС зачета (сторно)', 3, 346, '', 6, 25, 65, '', '', '', 1, 'storno', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (138, 133, '', '', 26, 1, '', '', 'Process.ReturnBuy.2E (VATBaseStorno)', 'Налоговая база НДС зачета (сторно)', 1, '', '', 6, 25, 65, '', '', 176, 1, 'storno', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (139, 132, '', '', '', 1, '', '', 'Process.ReturnBuy.3 (ReturnMoney)', 'Возврат ДС поставщиком', '', '', '', '', '', '', '', 73, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (140, 139, 11, '', 4, 1, '', '', 'Process.ReturnBuy.3A', 'Плат поручение вх', 15, '', 2, 1, 25, '', '', 76, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (141, 139, 4, '', 11, 1, '', '', 'Process.ReturnBuy.3B', 'Поступление ДС', 3, 323, 2, 1, 25, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (142, 139, '', '', 11, 1, '', '', 'Process.ReturnBuy.3C', 'Восстановление кредиторской задолж-ти', 1, 329, '', 1, 25, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (143, 133, 11, '', 2, 1, '', '', 'Process.ReturnBuy.4 (InvoiceStorno)', 'Получение счета-фактуры (сторно)', '', '', '', 1, 25, '', '', 70, 72, '', 'storno', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (144, 130, '', '', '', 1, '', '', 'Process.ReturnSell', 'Процесс Возврат от покупателя', '', '', '', '', '', '', '', 142, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (145, 144, 9, 11, 11, 1, '', '', 'Process.ReturnSell.1', 'Согласование возврата от покупателя', '', '', 1, 1, 30, '', 1, 81, '', 13, '', 1, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (146, 145, '', '', '', 1, '', '', 'Process.ReturnSell.2 (SellStorno)', 'Исполнение возврата от покупателя', '', '', '', '', '', '', '', 81, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (147, 146, 9, '', 11, 1, '', '', 'Process.ReturnSell.2A (Storno)', 'Расход активов\кол-во (сторно)', 1, 288, 1, '', 30, '', '', '', 28, 13, 'storno', 1, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (148, 146, '', '', '', 1, '', '', 'Process.ReturnSell.2B (Storno)', 'Расход активов\сумма (сторно)', 1, 288, 1, '', 30, '', '', '', 28, 1, 'storno', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (149, 146, '', 11, 11, 1, '', '', 'Process.ReturnSell.2C (Storno)', 'Списание дебиторской задолж-ти (сторно)', 3, 298, '', 1, 30, '', '', '', '', 1, 'storno', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (150, 146, '', 11, 11, 1, '', '', 'Process.ReturnSell.2D (Storno)', 'Признание расхода (сторно)', 3, 302, '', '', 30, '', '', '', 28, 3, 'storno', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (151, 146, '', 11, 11, 1, '', '', 'Process.ReturnSell.2E (Storno)', 'Признание дохода (сторно)', 1, 321, '', '', 30, '', '', '', '', 1, 'storno', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (152, 146, '', '', 26, 1, '', '', 'Process.ReturnSell.2F (VATStorno)', 'Начисление НДС реализации (сторно)', 1, 346, '', 6, 30, 70, '', '', '', 1, 'storno', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (153, 146, '', '', 26, 1, '', '', 'Process.ReturnSell.2G (IncomeTaxBaseStorno)', 'Налоговая база КПН (сторно)', 1, '', '', 6, 30, 31, '', '', 176, 1, 'storno', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (154, 146, '', '', 26, 1, '', '', 'Process.ReturnSell.2H (VATBaseStorno)', 'Налоговая база НДС реализации (сторно)', 1, '', '', 6, 30, 70, '', '', 176, 1, 'storno', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (155, 145, '', '', 11, 1, '', '', 'Process.ReturnSell.3 (Money)', 'Оплата возврата от покупателя', '', '', '', 1, '', '', '', 73, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (156, 155, 4, '', 11, 1, '', '', 'Process.ReturnSell.3A', 'Плат поручение исх', 21, '', 2, 1, 30, 1, '', 76, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (157, 155, 4, '', 11, 1, '', '', 'Process.ReturnSell.3B', 'Выбытие ДС', 1, 323, 2, 1, 30, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (158, 155, '', '', 11, 1, '', '', 'Process.ReturnSell.3C', 'Восстановление дебиторской задолж-ти', 3, 298, '', 1, 30, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (159, 146, '', '', 11, 1, '', '', 'Process.ReturnSell.4 (InvoiceStorno)', 'Выставление счета-фактуры покупателю (сторно)', '', '', '', 1, 30, '', '', 70, 72, '', 'storno', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (160, 130, '', '', '', 11, '', '', 'Process.Revise', 'Акт сверки', '', '', '', '', '', '', '', 64, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (161, 160, '', 11, 11, 11, '', '', 'Process.Revise.1', 'Согласование акта сверки', 5, 285, '', 1, '', '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (162, 160, '', 11, 11, 11, '', '', 'Process.Revise.2', 'Подписание акта сверки', 5, 285, '', 1, '', '', '', 82, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (163, 130, '', '', '', 1, '', '', 'Process.Sell', 'Реализация', '', '', '', '', '', '', '', 142, 72, '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (164, 163, '', 11, 11, 1, '', '', 'Process.Sell.1', 'Согласование исх договора', '', '', 1, '', 30, '', 1, 63, '', 10, '', 1, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (165, 164, '', 11, 11, 1, '', '', 'Process.Sell.2 (Contract)', 'Новый договор', '', '', '', 1, 30, '', '', 63, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (166, 165, '', 11, 11, 1, '', '', 'Process.Sell.3 (Order)', 'Выставление исх счета', '', '', '', 1, '', '', '', 74, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (167, 166, '', 11, 11, 9, '', '', 'Process.Sell.3A', 'Реализация менеджеров (план)', 1, 321, '', 1, 30, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (168, 166, '', '', '', 9, '', '', 'Process.Sell.3B', 'Себест-ть (план)', 3, 302, '', '', 30, '', '', '', '', 3, '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (169, 166, '', 11, 11, 9, '', '', 'Process.Sell.3C', 'Оплата исх счета (план)', 3, 323, '', '', 30, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (170, 166, '', '', 11, 1, '', '', 'Process.Sell.4 (Money)', 'Оплата исх счета', '', '', '', 1, 30, '', '', 73, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (171, 170, 11, '', 4, 1, '', '', 'Process.Sell.4A', 'Плат поручение вх', 12, '', 2, 1, 30, '', '', 76, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (172, 170, 4, '', 11, 1, '', '', 'Process.Sell.4B', 'Поступление ДС', 3, 323, 2, 1, 30, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (173, 170, '', '', 11, 1, '', '', 'Process.Sell.4C', 'Списание деб задолж-ти', 1, 298, '', 1, 30, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (174, 166, '', '', '', 1, '', '', 'Process.Sell.5 (Consumption)', 'Исполнение исх счета', '', '', '', '', '', '', '', 89, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (175, 174, '', 11, 11, 1, '', '', 'Process.Sell.5A', 'Получение вх доверенности', '', '', 1, 1, 30, '', '', 95, '', 10, '', 1, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (176, 174, '', 11, 11, 1, '', '', 'Process.Sell.5B', 'Начисление деб задолж-ти', 3, 298, '', 1, 30, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (177, 174, 9, '', '', 1, '', '', 'Process.Sell.5C', 'Списание себест-ти активов\кол-во', 1, 288, 1, '', 7, '', '', '', 28, 13, '', 1, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (178, 174, 9, '', '', 1, '', '', 'Process.Sell.5D', 'Списание себест-ти активов\себ-ть', 1, 288, 1, '', 7, '', '', '', 28, 3, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (179, 174, '', '', '', 1, '', '', 'Process.Sell.5E', 'Списание амортизации активов', 3, 310, 1, '', 7, 14, '', '', 28, 3, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (180, 174, '', '', 26, 1, '', '', 'Process.Sell.5F (VATBase)', 'Налоговая база НДС реализации', 34, '', '', 6, 30, 60, '', '', 176, 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (181, 174, '', '', 26, 1, '', '', 'Process.Sell.5G (IncomeTaxBase)', 'Налоговая база КПН', 34, '', '', 6, 30, 32, '', '', 176, 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (182, 174, '', '', 26, 1, '', '', 'Process.Sell.5H (VAT)', 'Начисление НДС реализации', 1, 346, '', 6, 30, 70, '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (183, 174, '', 11, 11, 1, '', '', 'Process.Sell.5I', 'Признание расхода', 3, 302, '', '', 30, '', '', '', 28, 3, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (184, 174, '', 11, 11, 1, '', '', 'Process.Sell.5J', 'Признание дохода', 1, 321, '', '', 30, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (185, 174, '', '', 11, 1, '', '', 'Process.Sell.6 (Invoice)', 'Выставление счета-фактуры покупателю', '', '', '', 1, 30, '', '', 70, 72, '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (186, 166, '', '', '', 1, '', '', 'Process.Sell.7 (Null)', 'Аннулирование исх счета', '', '', 1, 1, 30, '', 1, 74, 81, '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (187, 130, '', '', '', 1, '', '', 'Process.StaffDoc', 'Кадровый приказ', 9, '', '', '', '', '', '', 91, 72, '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (188, 187, '', 11, '', 1, '', '', 'Process.StaffDoc.1', 'Прием на работу', 9, '', '', 1, '', '', '', '', '', 13, '1', 16, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (189, 187, '', 11, '', 1, '', '', 'Process.StaffDoc.2', 'Командировка', 9, '', '', 1, '', '', '', '', '', 13, '1', 53, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (190, 187, '', 11, '', 1, '', '', 'Process.StaffDoc.3', 'Поощрение', 9, '', '', 1, '', '', '', '', '', 13, '1', 52, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (191, 187, '', 11, '', 1, '', '', 'Process.StaffDoc.4', 'Изменение оклада', 9, '', '', 1, '', '', '', '', '', 13, '1', 53, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (192, 187, '', 11, '', 1, '', '', 'Process.StaffDoc.5', 'Взыскание', 9, '', '', 1, '', '', '', '', '', 13, '1', 51, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (193, 187, '', 11, '', 1, '', '', 'Process.StaffDoc.6', 'Отпуск', 9, '', '', 1, '', '', '', '', '', 13, '1', 53, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (194, 187, '', 11, '', 1, '', '', 'Process.StaffDoc.7', 'Увольнение', 9, '', '', 1, '', '', '', '', '', 13, '1', 10, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (195, 130, '', '', '', 1, '', '', 'Process.Storno', 'Процесс Сторно', 2, 285, '', '', '', '', '', 142, '', 10, 'storno', 1, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (196, 130, '', '', '', 1, '', '', 'Process.TaxPay', 'Начисление и оплата налога', 34, '', '', '', '', '', '', 142, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (197, 196, '', '', 26, 1, '', '', 'Process.TaxPay.1', 'Задолженность по налогу', 1, 331, '', 6, '', 1, '', 65, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (198, 196, '', '', '', 1, '', '', 'Process.TaxPay.2', 'Затраты по налогу', 3, 302, '', '', 33, 1, '', 65, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (199, 196, 4, '', 11, 1, '', '', 'Process.TaxPay.3', 'Плат поручение исх', 35, '', 2, 1, 33, 1, '', 76, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (200, 196, 4, '', 26, 1, '', '', 'Process.TaxPay.4', 'Оплата налога', 1, 323, 2, '', 33, 1, '', 73, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (201, 196, '', '', 26, 1, '', '', 'Process.TaxPay.5', 'Списание задолж-ти по налогу', 3, 331, '', 6, 33, 1, '', 73, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (202, 130, '', '', '', 1, '', '', 'Process.Transfer', 'Перемещение активов', '', '', '', '', '', '', '', 142, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (203, 202, '', '', '', 1, '', '', 'Process.Transfer.1', 'Согласование перемещения активов', '', '', 1, '', '', '', '', 94, '', 13, '', 1, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (204, 203, '', '', '', 1, '', '', 'Process.Transfer.2 (Transfer)', 'Пер-е активов', '', '', 1, '', '', '', '', 94, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (205, 204, 9, '', '', 1, '', '', 'Process.Transfer.2A', 'Отпуск активов.кол-во', 1, 288, 1, '', '', '', '', '', 28, 13, '', 1, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (206, 204, 9, '', '', 1, '', '', 'Process.Transfer.2B', 'Отпуск активов.себ-ть сумма', 1, 288, 1, '', '', '', '', '', 28, 3, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (207, 204, 3, '', '', 1, '', '', 'Process.Transfer.2C', 'Прием активов.кол-во', 3, 288, 1, '', '', '', '', '', 28, 13, '', 1, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (208, 204, 3, '', '', 1, '', '', 'Process.Transfer.2D', 'Прием активов.себ-ть сумма', 3, 288, 1, '', '', '', '', '', 28, 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (209, 130, '', '', '', 1, '', '', 'Process.TransferMoney', 'Перемещение ДС', 15, '', '', '', '', '', '', 73, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (210, 209, 4, '', '', 1, '', '', 'Process.TransferMoney.1', 'Плат поручение исх', 21, '', 2, '', '', '', '', 76, '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (211, 209, 4, '', '', 1, '', '', 'Process.TransferMoney.2', 'Списание ДС при отправке', 1, 323, 2, '', '', '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (212, 209, 5, '', '', 1, '', '', 'Process.TransferMoney.3', 'Оприходование ДС при получении', 3, 323, 2, '', '', '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (213, 130, '', '', '', 1, '', '', 'Process.Writeoff', 'Списание активов', '', '', '', '', '', '', '', 142, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (214, 213, 9, '', '', 1, '', '', 'Process.Writeoff.1', 'Согласование спис-я активов', '', '', 1, '', 37, '', '', 96, '', 13, '', 1, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (215, 214, '', '', '', 1, '', '', 'Process.Writeoff.2  (Consumption)', 'Спис-е активов', '', '', 1, '', '', '', '', 96, '', '', '', '', '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (216, 215, 9, '', '', 1, '', '', 'Process.Writeoff.2A', 'Спис-е активов.кол-во', 1, 288, 1, '', 37, '', '', '', 28, 13, '', 1, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (217, 215, '', '', '', 1, '', '', 'Process.Writeoff.2B', 'Спис-е активов.себ-ть сумма', 1, 288, 1, '', 37, '', '', '', 28, 3, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (218, 215, '', '', '', 1, '', '', 'Process.Writeoff.2C', 'Спис-е склада.расход', 3, 302, '', '', 37, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (219, 215, '', '', '', 1, '', '', 'Process.Writeoff.3 (Arrival)', 'Приход других активов после спис-я', '', '', 1, '', '', '', '', 125, '', 13, '', 1, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (220, 219, 9, '', '', 1, '', '', 'Process.Writeoff.3A', 'Приход активов.кол-во', 3, 288, 1, '', 37, '', '', '', 28, 13, '', 1, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (221, 219, '', '', '', 1, '', '', 'Process.Writeoff.3B', 'Приход активов.себ-ть сумма', 3, 288, 1, '', 37, '', '', '', 28, 3, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (222, 219, '', '', '', 1, '', '', 'Process.Writeoff.3C', 'Приход склада.доход', 1, 321, '', '', 37, '', '', '', '', 1, '', 6, '{"Role.Generic.Code": "Process.Basic",}', NULL);

-- Table: Role
CREATE TABLE IF NOT EXISTS Role (
    Id          INTEGER PRIMARY KEY ASC AUTOINCREMENT,
    Parent      INTEGER
                        REFERENCES Role (Id),
    Date1       TEXT,
    Date2       TEXT,
    Code        TEXT,
    Description TEXT,
    More        TEXT
);

INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (1, '', '', '', 'Role.', 'RoleData', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (2, 1, '', '', 'Role.Account', 'Account', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (3, 2, '', '', 'Role.Account.Asset', 'счет активов', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (4, 2, '', '', 'Role.Account.Budget', 'счет бюджета', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (5, 2, '', '', 'Role.Account.Capital', 'счет капитала', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (6, 2, '', '', 'Role.Account.Depreciation', 'счет амортизации', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (7, 2, '', '', 'Role.Account.Face', 'счет лиц', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (8, 2, '', '', 'Role.Account.FixedAsset', 'счет основных средств', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (9, 2, '', '', 'Role.Account.Group1Level', 'группа счетов 1 уровня', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (10, 2, '', '', 'Role.Account.Group2Level', 'группа счетов 2 уровня', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (11, 2, '', '', 'Role.Account.Money', 'счет денег', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (12, 2, '', '', 'Role.Account.Other', 'счет прочий', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (13, 2, '', '', 'Role.Account.Production', 'счет производства', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (14, 2, '', '', 'Role.Account.Salary', 'счет зарплаты', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (15, 2, '', '', 'Role.Account.Tax', 'счет налогов и платежей', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (16, 1, '', '', 'Role.AccTable', 'AccountTable', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (17, 16, '01-янв-97', '31.12.2004', 'Role.AccTable.1997', 'генеральный план счетов 1997', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (18, 16, '01-янв-05', '31.12.2018', 'Role.AccTable.2005', 'типовой план счетов 2005', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (19, 16, '01-янв-19', '', 'Role.AccTable.2019', 'типовой план счетов 2019', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (20, 16, '', '', 'Role.AccTable.OffBalance', 'забалансовый', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (21, 16, '', '', 'Role.AccTable.Work', 'рабочий план счетов', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (22, 1, '', '', 'Role.Asset', 'Asset', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (23, 22, '', '', 'Role.Asset.BioAsset', 'биологический актив', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (24, 22, '', '', 'Role.Asset.Building', 'здание', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (25, 22, '', '', 'Role.Asset.Car', 'автотранспорт', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (26, 22, '', '', 'Role.Asset.Coverall', 'спецодежда', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (27, 22, '', '', 'Role.Asset.Furniture', 'мебель', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (28, 22, '', '', 'Role.Asset.Good', 'товар', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (29, 22, '', '', 'Role.Asset.IntangibleAsset', 'нематериальные активы', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (30, 22, '', '', 'Role.Asset.Land', 'земля', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (31, 22, '', '', 'Role.Asset.LineBusiness', 'направление деятельности', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (32, 22, '', '', 'Role.Asset.Machine', 'машинное оборудование', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (33, 22, '', '', 'Role.Asset.Material', 'материал', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (34, 22, '', '', 'Role.Asset.Money', 'денежные средства', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (35, 22, '', '', 'Role.Asset.Mortgage', 'залоговое имущество', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (36, 22, '', '', 'Role.Asset.OfficeEquipment', 'офисное оборудование', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (37, 22, '', '', 'Role.Asset.OtherFixedAsset', 'прочие ОС', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (38, 22, '', '', 'Role.Asset.Production', 'готовая продукция', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (39, 22, '', '', 'Role.Asset.Project', 'проект', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (40, 22, '', '', 'Role.Asset.Service', 'услуга', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (41, 22, '', '', 'Role.Asset.Tool', 'инструмент', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (42, 22, '', '', 'Role.Asset.Work', 'работа', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (43, 22, '', '', 'Role.Asset.UnfinishedWork', 'незавершенное производство, стр-во', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (44, 1, '', '', 'Role.Currency', 'Currency', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (45, 44, '', '', 'Role.Currency.AccountingCurrency', 'учетная валюта', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (46, 44, '', '', 'Role.Currency.ExchangeCurrency', 'курс валюты', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (47, 1, '', '', 'Role.Deal', 'Deal', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (48, 47, '', '', 'Role.Deal.AddAgreement', 'дополнительное соглашение', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (49, 47, '', '', 'Role.Deal.Appendix', 'приложение', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (50, 47, '', '', 'Role.Deal.Devivery', 'поставка договора', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (51, 47, '', '', 'Role.Deal.Frame', 'рамочный договор', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (52, 47, '', '', 'Role.Deal.Basic', 'разовая сделка', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (53, 47, '', '', 'Role.Deal.Spec', 'спецификация', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (54, 1, '', '', 'Role.Entity', 'Entity', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (55, 54, '', '', 'Role.Entity.Account', 'бухсчета', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (56, 54, '', '', 'Role.Entity.Asset-Deal', 'активы-договора', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (57, 54, '', '', 'Role.Entity.Asset-Unit', 'активы-ед. изм.', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (58, 54, '', '', 'Role.Entity.Balance', 'остатки', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (59, 54, '', '', 'Role.Entity.Bank', 'банк', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (60, 54, '', '', 'Role.Entity.BankStatement', 'выписка банка', '{"Role.Generic.FullName": "Выписка банка","Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (61, 54, '', '', 'Role.Entity.Budget', 'бюджет', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (62, 54, '', '', 'Role.Entity.Country-Currency', 'страны-валюты', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (63, 54, '', '', 'Role.Entity.Deal', 'сделка', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (64, 54, '', '', 'Role.Entity.Doc-Process', 'документ-процесс', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (65, 54, '', '', 'Role.Entity.Entry', 'бухгалтерская справка', '{"Role.Generic.FullName": "Бухгалтерская справка","Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (66, 54, '', '', 'Role.Entity.ExtraCalc', 'расчет премии', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (67, 54, '', '', 'Role.Entity.Face-Deal', 'лица-сделки', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (68, 54, '', '', 'Role.Entity.Imprest', 'авансовый отчет', '{"Role.Generic.FullName": "Авансовый отчет","Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (69, 54, '', '', 'Role.Entity.InputCash', 'приходный кассовый ордер', '{"Role.Generic.FullName": "Приходный кассовый ордер","Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (70, 54, '', '', 'Role.Entity.Invoice', 'счет-фактура (ЭСФ)', '{"Role.Generic.FullName": "Счет-фактура",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (71, 54, '', '', 'Role.Entity.Workbook', 'журнал', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (72, 54, '', '', 'Role.Entity.MainTable', 'общие таблицы', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (73, 54, '', '', 'Role.Entity.Money', 'денежные средства', '{"Role.Generic.FullName": "Кассовая книга","Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (74, 54, '', '', 'Role.Entity.Order', 'счет', '{"Role.Generic.FullName": "Счет",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (75, 54, '', '', 'Role.Entity.OutputCash', 'расходный кассовый ордер', '{"Role.Generic.FullName": "Расходный кассовый ордер","Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (76, 54, '', '', 'Role.Entity.PayOrder', 'платежное поручение', '{"Role.Generic.FullName": "Платежное поручение","Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (77, 54, '', '', 'Role.Entity.PaySheet', 'реестр платежей по ЗП', '{"Role.Generic.FullName": "Реестр",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (78, 54, '', '', 'Role.Entity.PriceList', 'прайс-лист', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (79, 54, '', '', 'Role.Entity.Process', 'процесс', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (80, 54, '', '', 'Role.Entity.Purchase', 'приходная накладная', '{"Role.Generic.FullName": "Приходная накладная","Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (81, 54, '', '', 'Role.Entity.Return', 'возвратная накладная', '{"Role.Generic.FullName": "Возвратная накладная","Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (82, 54, '', '', 'Role.Entity.Revise', 'акт сверки', '{"Role.Generic.FullName": "Акт сверки","Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (83, 54, '', '', 'Role.Entity.SalaryAverageCalc', 'расчет по средней ЗП', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (84, 54, '', '', 'Role.Entity.Salary', 'зарплата', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (85, 54, '', '', 'Role.Entity.SalaryInquery', 'справка по ЗП', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (86, 54, '', '', 'Role.Entity.SalaryPaySheet', 'ведомость выплаты ЗП', '{"Role.Generic.FullName": "Платежая ведомость по зарплате","Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (87, 54, '', '', 'Role.Entity.SalarySheet', 'начисление зарплаты', '{"Role.Generic.FullName": "Расчетная ведомость начисления зарплаты","Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (88, 54, '', '', 'Role.Entity.SalarySummary', 'свод ЗП', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (89, 54, '', '', 'Role.Entity.Sell', 'реализация', '{"Role.Generic.FullName": "Расходная накладная","Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (90, 54, '', '', 'Role.Entity.Staff', 'сотрудники', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (91, 54, '', '', 'Role.Entity.StaffDoc', 'кадровый приказ', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (92, 54, '', '', 'Role.Entity.Store', 'склад', '{"Role.Generic.FullName": "Товарно-транспортная накладная","Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (93, 54, '', '', 'Role.Entity.Tax-Face', 'налоги-лица', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (94, 54, '', '', 'Role.Entity.Transfer', 'накладная перемещения', '{"Role.Generic.FullName": "Накладная на перемещение активов","Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (95, 54, '', '', 'Role.Entity.Warrant', 'доверенность', '{"Role.Generic.FullName": "Доверенность","Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (96, 54, '', '', 'Role.Entity.WriteOff', 'списание', '{"Role.Generic.FullName": "Акт списания","Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (97, 1, '', '', 'Role.Exchange', 'ExchangeData', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (98, 97, '', '', 'Role.Exchange.EsfXML', 'ESF XML', '{"Role.Generic.Code": "Exchange.Basic","Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (99, 97, '', '', 'Role.Exchange.MT100', 'swift MT-100 (платежки)', '{"Role.Generic.Code": "Exchange.Basic","Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (100, 97, '', '', 'Role.Exchange.MT102', 'swift MT-102 (зарплата)', '{"Role.Generic.Code": "Exchange.Basic","Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (101, 97, '', '', 'Role.Exchange.SwiftGFSS', 'swift ГФСС', '{"Role.Generic.Code": "Exchange.Basic","Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (102, 97, '', '', 'Role.Exchange.SwiftOPV', 'swift ОПВ', '{"Role.Generic.Code": "Exchange.Basic","Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (103, 97, '', '', 'Role.Exchange.SwiftOSMS', 'swift отч ОСМС', '{"Role.Generic.Code": "Exchange.Basic","Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (104, 97, '', '', 'Role.Exchange.Tax100-01', 'ф100.01', '{"Role.Generic.Code": "Exchange.Basic","Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (105, 1, '', '', 'Role.Face', 'Face', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (106, 105, '', '', 'Role.Face.Bank', 'банк', '{"Info.Code.KBE": "15","Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (107, 105, '', '', 'Role.Face.ContractWorker', 'работник по договору', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (108, 105, '', '', 'Role.Face.Customer', 'покупатель', '{"Info.Code.KBE": "17","Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (109, 105, '', '', 'Role.Face.ExternalWorker', 'внешний совместитель', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (110, 105, '', '', 'Role.Face.FA', 'лицо учета', '{"Info.Code.KBE": "17","Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (111, 105, '', '', 'Role.Face.Foreigner', 'иностранный персонал', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (112, 105, '', '', 'Role.Face.GCVP', 'НАО-ГЦВП', '{"Info.Code.KBE": "11","Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (113, 105, '', '', 'Role.Face.Seller', 'поставщик', '{"Info.Code.KBE": "17","Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (114, 105, '', '', 'Role.Face.Staff', 'штатный работник', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (115, 105, '', '', 'Role.Face.State', 'госорган', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (116, 1, '', '', 'Role.Generic', 'Generic', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (117, 116, '', '', 'Role.Generic.Code', 'код', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (118, 116, '', '', 'Role.Generic.Description', 'расшифровка', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (119, 116, '', '', 'Role.Generic.Extra', 'необычный', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (120, 116, '', '', 'Role.Generic.FullName', 'полное наименование', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (121, 116, '', '', 'Role.Generic.List', 'список', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (122, 116, '', '', 'Role.Generic.Main', 'общая инфо', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (123, 116, '', '', 'Role.Generic.ShortName', 'сокращенное наименование', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (124, 116, '', '', 'Role.Generic.Time', 'время', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (125, 116, '', '', 'Role.Generic.Variant', 'вариант', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (126, 1, '', '', 'Role.Geo', 'Geo', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (127, 126, '', '', 'Role.Geo.City', 'город', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (128, 126, '', '', 'Role.Geo.Country', 'страна', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (129, 126, '', '', 'Role.Geo.County', 'область', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (130, 126, '', '', 'Role.Geo.District', 'район', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (131, 126, '', '', 'Role.Geo.House', 'дом', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (132, 126, '', '', 'Role.Geo.Region', 'регион', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (133, 126, '', '', 'Role.Geo.Street', 'улица', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (134, 126, '', '', 'Role.Geo.Township', 'поселок', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (135, 126, '', '', 'Role.Geo.Union', 'союз стран', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (136, 126, '', '', 'Role.Geo.Village', 'село', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (137, 126, '', '', 'Role.Geo.WorldOrg', 'международная организация', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (138, 1, '', '', 'Role.Workbook', 'Workbook', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (139, 138, '', '', 'Role.Workbook.ChangeMark', 'change mark', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (140, 138, '', '', 'Role.Workbook.Line1Manual', 'строка ручного ввода (первичная)', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (141, 138, '', '', 'Role.Workbook.Line2Calc', 'доп строка расчета (вторичная)', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (142, 138, '', '', 'Role.Workbook.StartPoint', 'стартовая точка', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (143, 1, '', '', 'Role.Policy', 'Policy', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (144, 143, '', '', 'Role.Policy.CanChangeDayAgo', 'изменять число дней назад', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (145, 143, '', '', 'Role.Policy.MustAuth', 'обязательная авторизация', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (146, 143, '', '', 'Role.Policy.MustFill', 'обязательно заполнять', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (147, 143, '', '', 'Role.Policy.NoChange', 'не изменять', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (148, 143, '', '', 'Role.Policy.NoDelete', 'не удалять', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (149, 143, '', '', 'Role.Policy.NoRound', 'не округлять до целого', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (150, 143, '', '', 'Role.Policy.NoView', 'не отображать', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (151, 143, '', '', 'Role.Policy.ToZero', 'обнулять', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (152, 1, '', '', 'Role.Price', 'Price', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (153, 152, '', '', 'Role.Price.AddFee', 'доп сбор к тарифу', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (154, 152, '', '', 'Role.Price.Basic', 'цена ТРУ', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (155, 152, '', '', 'Role.Price.Percent', 'процент', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (156, 152, '', '', 'Role.Price.Tariff', 'тариф', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (157, 1, '', '', 'Role.PriceChange', 'PriceChange', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (158, 157, '', '', 'Role.PriceChange.Action', 'акция', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (159, 157, '', '', 'Role.PriceChange.FreePiece', 'бесплатный экземпляр', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (160, 157, '', '', 'Role.PriceChange.Markup', 'надбавка, наценка', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (161, 157, '', '', 'Role.PriceChange.Sale', 'скидка', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (162, 1, '', '', 'Role.Rate', 'Rate', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (163, 162, '', '', 'Role.Rate.MaxRate', 'максимальный показатель', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (164, 162, '', '', 'Role.Rate.MinRate', 'минимальный показатель', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (165, 162, '', '', 'Role.Rate.Ratio', 'коэффициент', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (166, 1, '', '', 'Role.RegData', 'RegData', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (167, 166, '', '', 'Role.RegData.ExternalNumber', 'внешний номер', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (168, 166, '', '', 'Role.RegData.License', 'лицензия', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (169, 166, '', '', 'Role.RegData.Passport', 'паспорт', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (170, 166, '', '', 'Role.RegData.RegDescription', 'официальное наименование', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (171, 166, '', '', 'Role.RegData.Sert', 'сертификат', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (172, 166, '', '', 'Role.RegData.TaxNumber', 'налоговый номер', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (173, 1, '', '', 'Role.ReportFrame', 'структура отчета', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (174, 173, '', '', 'Role.ReportFrame.Body', 'тело', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (175, 173, '', '', 'Role.ReportFrame.Column1', 'колонка1', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (176, 173, '', '', 'Role.ReportFrame.Column2', 'колонка2', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (177, 173, '', '', 'Role.ReportFrame.Column3', 'колонка3', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (178, 173, '', '', 'Role.ReportFrame.Footer', 'подвал', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (179, 173, '', '', 'Role.ReportFrame.Header', 'заголовок', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (180, 1, '', '', 'Role.Sign', 'Sign', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (181, 180, '', '', 'Role.Sign.AccTable', 'план счетов', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (182, 180, '', '', 'Role.Sign.Budget', 'бюджет', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (183, 180, '', '', 'Role.Sign.HRA', 'кадры', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (184, 180, '', '', 'Role.Sign.MoneyFlow', 'ДДС', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (185, 180, '', '', 'Role.Sign.Store-Traffic', 'склад, транспорт', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (186, 180, '', '', 'Role.Sign.Tax', 'налоги', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (187, 1, '', '', 'Role.StaffTable', 'StaffTable', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (188, 187, '', '', 'Role.StaffTable.4day', '4-дневка', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (189, 187, '', '', 'Role.StaffTable.5day', '5-дневка', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (190, 187, '', '', 'Role.StaffTable.6day', '6-дневка', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (191, 187, '', '', 'Role.StaffTable.7day', '7-дневка', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (192, 1, '', '', 'Role.Store', 'Store', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (193, 192, '', '', 'Role.Store.Bank', 'текущий банковский счет', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (194, 192, '', '', 'Role.Store.BankPersonAccount', 'карт-счет физлица', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (195, 192, '', '', 'Role.Store.Cash', 'касса', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (196, 192, '', '', 'Role.Store.Construction', 'объект строительства', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (197, 192, '', '', 'Role.Store.Department', 'отдел', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (198, 192, '', '', 'Role.Store.Depo', 'депозитный счет', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (199, 192, '', '', 'Role.Store.Main', 'оптовый склад', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (200, 192, '', '', 'Role.Store.Pallet', 'паллета', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (201, 192, '', '', 'Role.Store.Rack', 'стеллаж', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (202, 192, '', '', 'Role.Store.Retail', 'розничный склад', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (203, 192, '', '', 'Role.Store.Shelf', 'полка', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (204, 192, '', '', 'Role.Store.Shop', 'цех', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (205, 192, '', '', 'Role.Store.Staff', 'работник', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (206, 1, '', '', 'Role.TaxBase', 'TaxBase', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (207, 206, '', '', 'Role.TaxBase.CostBrutto', 'расход брутто', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (208, 206, '', '', 'Role.TaxBase.CostNetto', 'расход нетто', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (209, 206, '', '', 'Role.TaxBase.ExchangeRateDelta', 'разница валютных курсов', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (210, 206, '', '', 'Role.TaxBase.FixedAssetNetto', 'стоимость ФА нетто', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (211, 206, '', '', 'Role.TaxBase.CoreFundNetto', 'стоимость ОС-НМА нетто', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (212, 206, '', '', 'Role.TaxBase.ImportNetto', 'облагаемый импорт нетто', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (213, 206, '', '', 'Role.TaxBase.IncomeBrutto', 'доход брутто', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (214, 206, '', '', 'Role.TaxBase.IncomeNetto', 'доход нетто', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (215, 206, '', '', 'Role.TaxBase.SalaryBrutto', 'зарплата брутто', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (216, 206, '', '', 'Role.TaxBase.SalaryNetto1', 'зарплата нетто 1 (база ИПН)', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (217, 206, '', '', 'Role.TaxBase.SellBrutto', 'реализация брутто (вх и исх)', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (218, 206, '', '', 'Role.TaxBase.SellNetto', 'реализация нетто (вх и исх)', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (219, 1, '', '', 'Role.TaxDetail', 'TaxDetail', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (220, 219, '', '', 'Role.TaxDetail.DepreciationLineMonth', 'амортизация линейно помесячно', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (221, 219, '', '', 'Role.TaxDetail.DepreciationYearTax', 'амортизация по году налоговая', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (222, 219, '', '', 'Role.TaxDetail.ExcRateDelta1', 'разница одного вида вал курса одной валюты между разными датами', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (223, 219, '', '', 'Role.TaxDetail.ExcRateDelta2', 'разница разных видов вал курсов одной даты', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (224, 219, '', '', 'Role.TaxDetail.InputSell', 'входящая реализация', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (225, 219, '', '', 'Role.TaxDetail.OutputSell', 'исходящая реализация', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (226, 1, '', '', 'Role.TaxMode', 'TaxMode', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (227, 226, '', '', 'Role.TaxMode.Basic', 'общеустановленный', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (228, 226, '', '', 'Role.TaxMode.Patent', 'патент', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (229, 226, '', '', 'Role.TaxMode.Simple', 'упрощенный', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (230, 226, '', '', 'Role.TaxMode.WorkContract', 'договор ГПХ', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (231, 1, '', '', 'Role.Unit', 'Unit', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (232, 231, '', '', 'Role.Unit.Auth', 'ЕИ аутентификации', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (233, 231, '', '', 'Role.Unit.Derivative', 'производная ЕИ', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (234, 231, '', '', 'Role.Unit.Basic', 'базовая ЕИ', '{"Role.Generic.Code": "Role.Basic",}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES (235, 206, '', '', 'Role.TaxBase.SalaryNetto2', 'зарплата нетто 2 (на руки)', '{"Role.Generic.Code": "Role.Basic",}');

-- Table: Sign
CREATE TABLE IF NOT EXISTS Sign (
    Id          INTEGER PRIMARY KEY ASC AUTOINCREMENT,
    Parent      INTEGER
                        REFERENCES Sign (Id),
    Date1       TEXT,
    Date2       TEXT,
    Code        TEXT,
    Description TEXT,
    Role        INTEGER
                        REFERENCES Role (Id),
    Info        INTEGER
                        REFERENCES Info (Id),
    More        TEXT
);

INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (1, 5, '', '', 'Sign.Acct.Ct', 'Счет.Кредит', 181, 161, '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (2, 5, '', '', 'Sign.Acct.Ct-Dt', 'Счет.Кредит или Дебет', 181, 160, '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (3, 5, '', '', 'Sign.Acct.Dt', 'Счет.Дебет', 181, 161, '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (4, 5, '', '', 'Sign.Acct.Dt-Ct', 'Счет.Дебет или Кредит', 181, 160, '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (5, 26, '', '', 'Sign.Acct', 'Счет', 181, '', '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (6, 26, '', '', 'Sign.Budget', 'Бюджет', 182, '', '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (7, 6, '', '', 'Sign.Budget.Input', 'Бюджет.Вход', 182, '', '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (8, 6, '', '', 'Sign.Budget.Output', 'Бюджет.Выход', 182, '', '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (9, 26, '', '', 'Sign.HRA', 'HumanResourceAccounting', 183, '', '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (10, 26, '', '', 'Sign.MoneyFlow', 'ДвижениеДенег', 184, '', '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (11, 10, '', '', 'Sign.MoneyFlow.Input', 'ДвижениеДенег.Вход', '', '', '{"Role.Generic.FullName": "Поступление","Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (12, 11, '', '', 'Sign.MoneyFlow.Input.011', '011 - реализация', 122, 147, '{"Role.Generic.FullName": "реализация товаров и услуг","Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (13, 11, '', '', 'Sign.MoneyFlow.Input.012', '012 - прочая выручка', 125, 147, '{"Role.Generic.FullName": "прочая выручка","Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (14, 11, '', '', 'Sign.MoneyFlow.Input.013', '012 - авансы', 122, 147, '{"Role.Generic.FullName": "авансы, полученные от покупателей и заказчиков","Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (15, 11, '', '', 'Sign.MoneyFlow.Input.016', '016 - прочие поступления', 125, 147, '{"Role.Generic.FullName": "прочие поступления","Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (16, 10, '', '', 'Sign.MoneyFlow.Output', 'ДвижениеДенег.Выход', '', '', '{"Role.Generic.FullName": "Выбытие","Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (17, 16, '', '', 'Sign.MoneyFlow.Output.021', '021 - платежи поставщикам', 122, 147, '{"Role.Generic.FullName": "платежи поставщикам за товары и услуги","Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (18, 16, '', '', 'Sign.MoneyFlow.Output.022', '022 - авансы поставщикам', 125, 147, '{"Role.Generic.FullName": "авансы, выданные поставщикам товаров и услуг","Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (19, 16, '', '', 'Sign.MoneyFlow.Output.023', '023 - выплаты по оплате труда', 125, 147, '{"Role.Generic.FullName": "выплаты по оплате труда","Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (20, 16, '', '', 'Sign.MoneyFlow.Output.026', '026 - платежи в бюджет', 122, 147, '{"Role.Generic.FullName": "подоходный налог и другие платежи в бюджет","Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (21, 16, '', '', 'Sign.MoneyFlow.Output.027', '027 - прочие выплаты', 125, 147, '{"Role.Generic.FullName": "прочие выплаты","Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (22, 26, '', '', 'Sign.Price', 'Цена', 185, '', '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (23, 22, '', '', 'Sign.Price.Fall', 'Цена.снижение', 185, '', '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (24, 22, '', '', 'Sign.Price.Growth', 'Цена.рост', 185, '', '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (25, 22, '', '', 'Sign.Price.NoChange', 'Цена.без изм', 185, '', '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (26, '', '', '', 'Sign.', 'SignData', 72, 47, '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (27, 26, '', '', 'Sign.Store', 'Склад', 185, '', '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (28, 27, '', '', 'Sign.Store.Input', 'Склад.Приход', 185, '', '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (29, 27, '', '', 'Sign.Store.Output', 'Склад.Расход', 185, '', '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (30, 27, '', '', 'Sign.Store.Storage', 'Склад.Хранение', 185, '', '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (31, 30, '', '', 'Sign.Store.Storage.Input', 'Склад.Хранение.вход', 185, '', '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (32, 30, '', '', 'Sign.Store.Storage.Output', 'Склад.Хранение.выход', 185, '', '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (33, 26, '', '', 'Sign.Tax', 'Налог', 186, '', '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (34, 33, '', '', 'Sign.Tax.Ct', 'Налог.Кредит', 186, '', '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (35, 33, '', '', 'Sign.Tax.KNP', 'Налог.КНП', 186, 19, '{"Role.Generic.FullName": "Начисленные (исчисленные) и иные обязательства в бюджет","Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (36, 35, '', '', 'Sign.Tax.KNP.TaxMode.Main.911', '911 - обяз-ва в бюджет', 227, 72, '{"Role.Generic.FullName": "Начисленные (исчисленные) и иные обязательства в бюджет","Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (37, 35, '', '', 'Sign.Tax.KNP.TaxMode.Main.912', '912 - пени', 227, 81, '{"Role.Generic.FullName": "Пени по обязательствам в бюджет","Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (38, 35, '', '', 'Sign.Tax.KNP.TaxMode.Patent.921', '921 - обяз-ва в бюджет', 228, 72, '{"Role.Generic.FullName": "Начисленные (исчисленные) и иные обязательства в бюджет","Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (39, 35, '', '', 'Sign.Tax.KNP.TaxMode.Patent.922', '922 - пени', 228, 81, '{"Role.Generic.FullName": "Пени по обязательствам в бюджет","Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (40, 35, '', '', 'Sign.Tax.KNP.TaxMode.Simple.931', '931 - обяз-ва в бюджет', 229, 72, '{"Role.Generic.FullName": "Начисленные (исчисленные) и иные обязательства в бюджет","Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (41, 35, '', '', 'Sign.Tax.KNP.TaxMode.Simple.932', '932 - пени', 229, 81, '{"Role.Generic.FullName": "Пени по обязательствам в бюджет","Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (42, 26, '', '', 'Sign.Traffic', 'Транспорт', 185, '', '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (43, 42, '', '', 'Sign.Traffic.Input', 'Транспорт.Вход', 185, '', '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (44, 42, '', '', 'Sign.Traffic.Output', 'Транспорт.Выход', 185, '', '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (45, 42, '', '', 'Sign.Traffic.Transit', 'Транспорт.Транзит', 185, '', '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (46, 45, '', '', 'Sign.Traffic.Transit.Input', 'Транспорт.Транзит.вход', 185, '', '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (47, 45, '', '', 'Sign.Traffic.Transit.Output', 'Транспорт.Транзит.выход', 185, '', '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (48, 26, '', '', 'Sign.Work', 'Работа', 185, '', '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (49, 48, '', '', 'Sign.Work.Closing', 'Работа.Закрытие', 185, '', '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (50, 48, '', '', 'Sign.Work.Execution', 'Работа.Выполнение', 185, '', '{"Role.Generic.Code": "Sign.Basic",}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES (51, 48, '', '', 'Sign.Work.Plan', 'Работа.План', 185, '', '{"Role.Generic.Code": "Sign.Basic",}');

-- Table: Slice
CREATE TABLE IF NOT EXISTS Slice (
    Id          INTEGER PRIMARY KEY ASC AUTOINCREMENT,
    Parent      INTEGER
                        REFERENCES Slice (Id),
    Date1       TEXT,
    Date2       TEXT,
    Code        TEXT,
    Description TEXT,
    More        TEXT
);

INSERT INTO Slice (Id, Parent, Date1, Date2, Code, Description, More) VALUES (1, '', '', '', 'Slice.Accounting', 'учет', '{"Role.Generic.Code": "Slice.Basic",}');
INSERT INTO Slice (Id, Parent, Date1, Date2, Code, Description, More) VALUES (2, '', '', '', 'Slice.Correction', 'корректировка', '{"Role.Generic.Code": "Slice.Basic",}');
INSERT INTO Slice (Id, Parent, Date1, Date2, Code, Description, More) VALUES (3, '', '', '', 'Slice.Budget', 'бюджет', '{"Role.Generic.Code": "Slice.Basic",}');
INSERT INTO Slice (Id, Parent, Date1, Date2, Code, Description, More) VALUES (4, '', '', '', 'Slice.Duplicate', 'дубликат', '{"Role.Generic.Code": "Slice.Basic",}');
INSERT INTO Slice (Id, Parent, Date1, Date2, Code, Description, More) VALUES (5, '', '', '', 'Slice.Fact', 'факт', '{"Role.Generic.Code": "Slice.Basic",}');
INSERT INTO Slice (Id, Parent, Date1, Date2, Code, Description, More) VALUES (6, '', '', '', 'Slice.Forecast', 'прогноз', '{"Role.Generic.Code": "Slice.Basic",}');
INSERT INTO Slice (Id, Parent, Date1, Date2, Code, Description, More) VALUES (7, '', '', '', 'Slice.Norm', 'норматив', '{"Role.Generic.Code": "Slice.Basic",}');
INSERT INTO Slice (Id, Parent, Date1, Date2, Code, Description, More) VALUES (8, '', '', '', 'Slice.Offer', 'коммерческое предложение', '{"Role.Generic.Code": "Slice.Basic",}');
INSERT INTO Slice (Id, Parent, Date1, Date2, Code, Description, More) VALUES (9, '', '', '', 'Slice.Plan', 'план', '{"Role.Generic.Code": "Slice.Basic",}');
INSERT INTO Slice (Id, Parent, Date1, Date2, Code, Description, More) VALUES (10, '', '', '', 'Slice.Preorder', 'предварительный заказ', '{"Role.Generic.Code": "Slice.Basic",}');
INSERT INTO Slice (Id, Parent, Date1, Date2, Code, Description, More) VALUES (11, '', '', '', 'Slice.Report', 'отчет', '{"Role.Generic.Code": "Slice.Basic",}');
INSERT INTO Slice (Id, Parent, Date1, Date2, Code, Description, More) VALUES (12, '', '', '', 'Slice.Request', 'заявка', '{"Role.Generic.Code": "Slice.Basic",}');

-- Table: Unit
CREATE TABLE IF NOT EXISTS Unit (
    Id          INTEGER PRIMARY KEY ASC AUTOINCREMENT,
    Parent      INTEGER
                        REFERENCES Unit (Id),
    Date1       TEXT,
    Date2       TEXT,
    Code        TEXT,
    Description TEXT,
    Role        INTEGER
                        REFERENCES Role (Id),
    More        TEXT
);

INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (1, '', '', '', 'Unit.', 'UnitData', 57, '{"Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (2, 31, '', '', 'Unit.Account', 'бухсчет', 233, '{"Role.Generic.FullName": "бухсчет","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (3, 1, '', '', 'Unit.Box', 'ящ', 234, '{"Role.Generic.FullName": "ящик","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (4, 1, '', '', 'Unit.CalendarDay', 'кал дн', 234, '{"Role.Generic.FullName": "календарные дни","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (5, 1, '', '', 'Unit.Case', 'коробка', 234, '{"Role.Generic.FullName": "коробка","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (6, 1, '', '', 'Unit.CurrUnit', 'ден ед', 234, '{"Role.Generic.FullName": "денежных единиц","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (7, 1, '', '', 'Unit.Day', 'дн', 234, '{"Role.Generic.FullName": "день","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (8, 31, '', '', 'Unit.Deal', 'сделка', 233, '{"Role.Generic.FullName": "сделка","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (9, 1, '', '', 'Unit.Delivery', 'поставка', 233, '{"Role.Generic.FullName": "поставка","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (10, 17, '', '', 'Unit.Dismissal', 'увольнение', 233, '{"Role.Generic.FullName": "увольнение","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (11, 31, '', '', 'Unit.Doc', 'док', 233, '{"Role.Generic.FullName": "документ","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (12, 31, '', '', 'Unit.DocID', 'номер документа', 233, '{"Role.Generic.FullName": "номер документа","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (13, 6, '', '', 'Unit.EUR', 'EUR', 45, '{"Role.Generic.FullName": "евро","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (14, 1, '', '', 'Unit.Face', 'лицо', 233, '{"Role.Generic.FullName": "лицо","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (15, 1, '', '', 'Unit.HalfYear', 'полугодие', 234, '{"Role.Generic.FullName": "полугодие","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (16, 17, '', '', 'Unit.Hiring', 'прием на работу', 233, '{"Role.Generic.FullName": "прием на работу","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (17, 1, '', '', 'Unit.HR', 'HR', 233, '{"Role.Generic.FullName": "HR","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (18, 31, '', '', 'Unit.InfoBase', 'инф база', 233, '{"Role.Generic.FullName": "информационная база","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (19, 1, '', '', 'Unit.Jar', 'банка', 234, '{"Role.Generic.FullName": "банка","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (20, 1, '', '', 'Unit.Kg', 'кг', 234, '{"Role.Generic.FullName": "килограмм","Info.Code.MKEI": "166","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (21, 1, '', '', 'Unit.Kilometer', 'км', 234, '{"Role.Generic.FullName": "километр","Info.Code.MKEI": "8","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (22, 6, '', '', 'Unit.KZT', 'KZT', 45, '{"Role.Generic.FullName": "казахстанский тенге","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (23, 1, '', '', 'Unit.Litr', 'л', 234, '{"Role.Generic.FullName": "литр","Info.Code.MKEI": "112","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (24, 1, '', '', 'Unit.Meter', 'м', 234, '{"Role.Generic.FullName": "метр","Info.Code.MKEI": "6","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (25, 1, '', '', 'Unit.MinCalcRate', 'МРП', 164, '{"Role.Generic.FullName": "минимальный расчетный показатель","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (26, 1, '', '', 'Unit.MinSalary', 'МинЗП', 164, '{"Role.Generic.FullName": "минимальная заработная плата","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (27, 1, '', '', 'Unit.Month', 'мес', 234, '{"Role.Generic.FullName": "месяц","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (28, 1, '', '', 'Unit.Pack', 'уп', 234, '{"Role.Generic.FullName": "упаковка","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (29, 1, '', '', 'Unit.Packet', 'пач', 234, '{"Role.Generic.FullName": "пачка","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (30, 1, '', '', 'Unit.Percent', '%', 234, '{"Role.Generic.FullName": "процент","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (31, 1, '', '', 'Unit.Piece', 'шт', 234, '{"Role.Generic.FullName": "штука","Info.Code.MKEI": "796","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (32, 1, '', '', 'Unit.Position', 'должность', 233, '{"Role.Generic.FullName": "должность штатного расписания","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (33, 1, '', '', 'Unit.Product', 'изд', 234, '{"Role.Generic.FullName": "изделие","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (34, 1, '', '', 'Unit.Quarter', 'кв', 234, '{"Role.Generic.FullName": "квартал","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (35, 6, '', '', 'Unit.RUB', 'RUB', 45, '{"Role.Generic.FullName": "российский рубль","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (36, 1, '', '', 'Unit.Service', 'усл', 234, '{"Role.Generic.FullName": "услуга","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (37, 1, '', '', 'Unit.SquareMeter', 'кв м', 234, '{"Role.Generic.FullName": "квадратный метр","Info.Code.MKEI": "55","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (38, 1, '', '', 'Unit.T', 'т', 234, '{"Role.Generic.FullName": "тонна","Info.Code.MKEI": "168","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (39, 31, '', '', 'Unit.Text', 'текст', 233, '{"Role.Generic.FullName": "текст","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (40, 6, '', '', 'Unit.USD', 'USD', 45, '{"Role.Generic.FullName": "доллар США","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (41, 1, '', '', 'Unit.User', 'пользователь', 233, '{"Role.Generic.FullName": "пользователь","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (42, 1, '', '', 'Unit.Week', 'нед', 234, '{"Role.Generic.FullName": "неделя","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (43, 1, '', '', 'Unit.WorkDay', 'раб дн', 234, '{"Role.Generic.FullName": "рабочий день","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (44, 1, '', '', 'Unit.WorkHour', 'раб ч', 234, '{"Role.Generic.FullName": "рабочий час","Info.Code.MKEI": "356","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (45, 1, '', '', 'Unit.Year', 'год', 234, '{"Role.Generic.FullName": "год","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (46, 30, '', '', 'Unit.PercentPerDay', '%/дн', 233, '{"Role.Generic.FullName": "%/день","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (47, 1, '', '', 'Unit.Cbm', 'куб м', 234, '{"Role.Generic.FullName": "кубометр","Info.Code.MKEI": "113","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (48, 1, '', '', 'Unit.Mm', 'мм', 234, '{"Role.Generic.FullName": "миллиметр","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (49, 31, '', '', 'Unit.Flight', 'рейс', 233, '{"Role.Generic.FullName": "рейс","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (50, 1, '', '', 'Unit.ServiceLoginPassword', 'сервис, логин, пароль', 232, '{"Role.Generic.FullName": "сервис, логин, пароль","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (51, 17, '', '', 'Unit.Punishment', 'взыскание', 233, '{"Role.Generic.FullName": "взыскание","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (52, 17, '', '', 'Unit.Promotion', 'поощрение', 233, '{"Role.Generic.FullName": "поощрение","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (53, 17, '', '', 'Unit.OtherPersonnelEvent', 'прочее кадровое событие', 233, '{"Role.Generic.FullName": "прочее кадровое событие","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (54, 1, '', '', 'Unit.Formula', 'формула', 234, '{"Role.Generic.FullName": "формула","Role.Generic.Code": "Unit.Basic",}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES (55, 1, '', '', 'Unit.ExactDate', 'точная дата', 234, '{"Role.Generic.FullName": "точная дата","Role.Generic.Code": "Unit.Basic",}');

-- Table: Workbook
CREATE TABLE IF NOT EXISTS Workbook (
    Id          INTEGER PRIMARY KEY ASC AUTOINCREMENT,
    Parent      INTEGER
                        REFERENCES Workbook (Id),
    Face1       INTEGER
                        REFERENCES Face (Id),
    Face2       INTEGER
                        REFERENCES Face (Id),
    Face        INTEGER
                        REFERENCES Face (Id),
    Slice       INTEGER
                        REFERENCES Slice (Id),
    Date1       TEXT,
    Date2       TEXT,
    Code        TEXT,
    Description TEXT,
    Geo         INTEGER
                        REFERENCES Geo (Id),
    Sign        INTEGER
                        REFERENCES Sign (Id),
    Account     INTEGER
                        REFERENCES Account (Id),
    Process     INTEGER
                        REFERENCES Process (Id),
    Asset       INTEGER
                        REFERENCES Asset (Id),
    Deal        INTEGER
                        REFERENCES Deal (Id),
    Item        INTEGER
                        REFERENCES Item (Id),
    Debt        INTEGER
                        REFERENCES Debt (Id),
    Price       INTEGER
                        REFERENCES Price (Id),
    Role        INTEGER
                        REFERENCES Role (Id),
    Info        INTEGER
                        REFERENCES Info (Id),
    Meter       INTEGER
                        REFERENCES Meter (Id),
    MeterValue  TEXT,
    Unit        INTEGER
                        REFERENCES Unit (Id),
    More        TEXT,
    Mark        INTEGER
                        REFERENCES Mark (Id) 
);

INSERT INTO Workbook (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Geo, Sign, Account, Process, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES (1, '', '', '', '', '', '', '', 'Workbook.', 'WorkbookData', '', '', '', '', '', '', '', '', '', 71, 45, '', '', '', '{"Role.Generic.Code": "Workbook.Basic",}', 11);

-- Index: AssetCode
CREATE INDEX IF NOT EXISTS AssetCode ON Asset (
    Code
);


-- Index: AssetDate1
CREATE INDEX IF NOT EXISTS AssetDate1 ON Asset (
    Date1
);


-- Index: AssetDescription
CREATE INDEX IF NOT EXISTS AssetDescription ON Asset (
    Description
);


-- Index: AssetInfo
CREATE INDEX IF NOT EXISTS AssetInfo ON Asset (
    Info
);


-- Index: AssetParent
CREATE INDEX IF NOT EXISTS AssetParent ON Asset (
    Parent
);


-- Index: AssetRole
CREATE INDEX IF NOT EXISTS AssetRole ON Asset (
    Role
);


-- Index: AssetUnit
CREATE INDEX IF NOT EXISTS AssetUnit ON Asset (
    Unit
);


-- Index: DealCode
CREATE INDEX IF NOT EXISTS DealCode ON Deal (
    Code
);


-- Index: DealDescription
CREATE INDEX IF NOT EXISTS DealDescription ON Deal (
    Description
);


-- Index: DealFace
CREATE INDEX IF NOT EXISTS DealFace ON Deal (
    Face
);


-- Index: DealFace1
CREATE INDEX IF NOT EXISTS DealFace1 ON Deal (
    Face1
);


-- Index: DealFace2
CREATE INDEX IF NOT EXISTS DealFace2 ON Deal (
    Face2
);


-- Index: DealGeo
CREATE INDEX IF NOT EXISTS DealGeo ON Deal (
    Geo
);


-- Index: DealInfo
CREATE INDEX IF NOT EXISTS DealInfo ON Deal (
    Info
);


-- Index: DealParent
CREATE INDEX IF NOT EXISTS DealParent ON Deal (
    Parent
);


-- Index: DealRole
CREATE INDEX IF NOT EXISTS DealRole ON Deal (
    Role
);


-- Index: FaceCode
CREATE INDEX IF NOT EXISTS FaceCode ON Face (
    Code
);


-- Index: FaceDate1
CREATE INDEX IF NOT EXISTS FaceDate1 ON Face (
    Date1
);


-- Index: FaceDescription
CREATE INDEX IF NOT EXISTS FaceDescription ON Face (
    Description
);


-- Index: FaceGeo
CREATE INDEX IF NOT EXISTS FaceGeo ON Face (
    Geo
);


-- Index: FaceInfo
CREATE INDEX IF NOT EXISTS FaceInfo ON Face (
    Info
);


-- Index: FaceParent
CREATE INDEX IF NOT EXISTS FaceParent ON Face (
    Parent
);


-- Index: FaceRole
CREATE INDEX IF NOT EXISTS FaceRole ON Face (
    Role
);


-- Index: WorkbookAccount
CREATE INDEX IF NOT EXISTS WorkbookAccount ON Workbook (
    Account
);


-- Index: WorkbookAsset
CREATE INDEX IF NOT EXISTS WorkbookAsset ON Workbook (
    Asset
);


-- Index: WorkbookCode
CREATE INDEX IF NOT EXISTS WorkbookCode ON Workbook (
    Code
);


-- Index: WorkbookDate1
CREATE INDEX IF NOT EXISTS WorkbookDate1 ON Workbook (
    Date1
);


-- Index: WorkbookDeal
CREATE INDEX IF NOT EXISTS WorkbookDeal ON Workbook (
    Deal
);


-- Index: WorkbookDebt
CREATE INDEX IF NOT EXISTS WorkbookDebt ON Workbook (
    Debt
);


-- Index: WorkbookDescription
CREATE INDEX IF NOT EXISTS WorkbookDescription ON Workbook (
    Description
);


-- Index: WorkbookFace
CREATE INDEX IF NOT EXISTS WorkbookFace ON Workbook (
    Face
);


-- Index: WorkbookFace1
CREATE INDEX IF NOT EXISTS WorkbookFace1 ON Workbook (
    Face1
);


-- Index: WorkbookFace2
CREATE INDEX IF NOT EXISTS WorkbookFace2 ON Workbook (
    Face2
);


-- Index: WorkbookInfo
CREATE INDEX IF NOT EXISTS WorkbookInfo ON Workbook (
    Info
);


-- Index: WorkbookItem
CREATE INDEX IF NOT EXISTS WorkbookItem ON Workbook (
    Item
);


-- Index: WorkbookMark
CREATE INDEX IF NOT EXISTS WorkbookMark ON Workbook (
    Mark
);


-- Index: WorkbookMeter
CREATE INDEX IF NOT EXISTS WorkbookMeter ON Workbook (
    Meter
);


-- Index: WorkbookParent
CREATE INDEX IF NOT EXISTS WorkbookParent ON Workbook (
    Parent
);


-- Index: WorkbookPrice
CREATE INDEX IF NOT EXISTS WorkbookPrice ON Workbook (
    Price
);


-- Index: WorkbookProcess
CREATE INDEX IF NOT EXISTS WorkbookProcess ON Workbook (
    Process
);


-- Index: WorkbookRole
CREATE INDEX IF NOT EXISTS WorkbookRole ON Workbook (
    Role
);


-- Index: WorkbookSign
CREATE INDEX IF NOT EXISTS WorkbookSign ON Workbook (
    Sign
);


-- Index: WorkbookSlice
CREATE INDEX IF NOT EXISTS WorkbookSlice ON Workbook (
    Slice
);


-- Index: WorkbookUnit
CREATE INDEX IF NOT EXISTS WorkbookUnit ON Workbook (
    Unit
);


-- View: AccountList
CREATE VIEW IF NOT EXISTS AccountList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Slice,
           T3.Code AS SliceCode,
           T3.Description AS SliceDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.Role,
           T10.Code AS RoleCode,
           T10.Description AS RoleDescription,
           T1.Sign,
           T12.Code AS SignCode,
           T12.Description AS SignDescription,
           T1.More AS More
      FROM Account AS T1
           LEFT JOIN
           Account AS T4 ON T1.Parent = T4.Id
           LEFT JOIN
           Slice AS T3 ON T1.Slice = T3.Id
           LEFT JOIN
           Role AS T10 ON T1.Role = T10.Id
           LEFT JOIN
           Sign AS T12 ON T1.Sign = T12.Id;


-- View: AssetList
CREATE VIEW IF NOT EXISTS AssetList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code,
           T1.Description,
           T1.Geo,
           T8.Code AS GeoCode,
           T8.Description AS GeoDescription,
           T1.Asset1,
           T12.Code AS Asset1Code,
           T12.Description AS Asset1Description,
           T1.Role,
           T10.Code AS RoleCode,
           T10.Description AS RoleDescription,
           T1.Info,
           T11.Code AS InfoCode,
           T11.Description AS InfoDescription,
           T1.Unit,
           T13.Code AS UnitCode,
           T13.Description AS UnitDescription,
           T1.More AS More
      FROM Asset AS T1
           LEFT JOIN
           Asset AS T4 ON T1.Parent = T4.Id
           LEFT JOIN
           Geo AS T8 ON T1.Geo = T8.Id
           LEFT JOIN
           Role AS T10 ON T1.Role = T10.Id
           LEFT JOIN
           Info AS T11 ON T1.Info = T11.Id
           LEFT JOIN
           Asset AS T12 ON T1.Asset1 = T12.Id
           LEFT JOIN
           Unit AS T13 ON T1.Unit = T13.Id;


-- View: DealList
CREATE VIEW IF NOT EXISTS DealList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Face1,
           T6.Code AS Face1Code,
           T6.Description AS Face1Description,
           T1.Face2,
           T7.Code AS Face2Code,
           T7.Description AS Face2Description,
           T1.Face,
           T5.Code AS FaceCode,
           T5.Description AS FaceDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.Geo,
           T8.Code AS GeoCode,
           T8.Description AS GeoDescription,
           T1.Role,
           T10.Code AS RoleCode,
           T10.Description AS RoleDescription,
           T1.Info,
           T11.Code AS InfoCode,
           T11.Description AS InfoDescription,
           T1.More AS More
      FROM Deal AS T1
           LEFT JOIN
           Deal AS T4 ON T1.Parent = T4.Id
           LEFT JOIN
           Face AS T5 ON T1.Face = T5.Id
           LEFT JOIN
           Face AS T6 ON T1.Face1 = T6.Id
           LEFT JOIN
           Face AS T7 ON T1.Face2 = T7.Id
           LEFT JOIN
           Geo AS T8 ON T1.Geo = T8.Id
           LEFT JOIN
           Role AS T10 ON T1.Role = T10.Id
           LEFT JOIN
           Info AS T11 ON T1.Info = T11.Id;


-- View: DebtList
CREATE VIEW IF NOT EXISTS DebtList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.Geo,
           T8.Code AS GeoCode,
           T8.Description AS GeoDescription,
           T1.Role,
           T10.Code AS RoleCode,
           T10.Description AS RoleDescription,
           T1.Info,
           T11.Code AS InfoCode,
           T11.Description AS InfoDescription,
           T1.More AS More
      FROM Debt AS T1
           LEFT JOIN
           Debt AS T4 ON T1.Parent = T4.Id
           LEFT JOIN
           Geo AS T8 ON T1.Geo = T8.Id
           LEFT JOIN
           Role AS T10 ON T1.Role = T10.Id
           LEFT JOIN
           Info AS T11 ON T1.Info = T11.Id;


-- View: FaceList
CREATE VIEW IF NOT EXISTS FaceList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.Geo,
           T8.Code AS GeoCode,
           T8.Description AS GeoDescription,
           T1.Role,
           T10.Code AS RoleCode,
           T10.Description AS RoleDescription,
           T1.Info,
           T11.Code AS InfoCode,
           T11.Description AS InfoDescription,
           T1.More AS More
      FROM Face AS T1
           LEFT JOIN
           Face AS T4 ON T1.Parent = T4.Id
           LEFT JOIN
           Geo AS T8 ON T1.Geo = T8.Id
           LEFT JOIN
           Role AS T10 ON T1.Role = T10.Id
           LEFT JOIN
           Info AS T11 ON T1.Info = T11.Id;


-- View: GeoList
CREATE VIEW IF NOT EXISTS GeoList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.Role,
           T10.Code AS RoleCode,
           T10.Description AS RoleDescription,
           T1.Unit,
           T13.Code AS UnitCode,
           T13.Description AS UnitDescription,
           T1.More AS More
      FROM Geo AS T1
           LEFT JOIN
           Geo AS T4 ON T1.Parent = T4.Id
           LEFT JOIN
           Role AS T10 ON T1.Role = T10.Id
           LEFT JOIN
           Unit AS T13 ON T1.Unit = T13.Id;


-- View: InfoList
CREATE VIEW IF NOT EXISTS InfoList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.More AS More
      FROM Info AS T1
           LEFT JOIN
           Info AS T4 ON T1.Parent = T4.Id;


-- View: ItemList
CREATE VIEW IF NOT EXISTS ItemList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.More AS More
      FROM Item AS T1
           LEFT JOIN
           Item AS T4 ON T1.Parent = T4.Id;


-- View: MarkList
CREATE VIEW IF NOT EXISTS MarkList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.More AS More
      FROM Mark AS T1
           LEFT JOIN
           Mark AS T4 ON T1.Parent = T4.Id;


-- View: MeterList
CREATE VIEW IF NOT EXISTS MeterList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.More AS More
      FROM Meter AS T1
           LEFT JOIN
           Meter AS T4 ON T1.Parent = T4.Id;


-- View: PriceList
CREATE VIEW IF NOT EXISTS PriceList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.Role,
           T10.Code AS RoleCode,
           T10.Description AS RoleDescription,
           T1.Info,
           T11.Code AS InfoCode,
           T11.Description AS InfoDescription,
           T1.Unit,
           T13.Code AS UnitCode,
           T13.Description AS UnitDescription,
           T1.More AS More
      FROM Price AS T1
           LEFT JOIN
           Price AS T4 ON T1.Parent = T4.Id
           LEFT JOIN
           Role AS T10 ON T1.Role = T10.Id
           LEFT JOIN
           Info AS T11 ON T1.Info = T11.Id
           LEFT JOIN
           Unit AS T13 ON T1.Unit = T13.Id;


-- View: ProcessList
CREATE VIEW IF NOT EXISTS ProcessList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Face1,
           T6.Code AS Face1Code,
           T6.Description AS Face1Description,
           T1.Face2,
           T7.Code AS Face2Code,
           T7.Description AS Face2Description,
           T1.Face,
           T5.Code AS FaceCode,
           T5.Description AS FaceDescription,
           T1.Slice,
           T3.Code AS SliceCode,
           T3.Description AS SliceDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.Sign,
           T12.Code AS SignCode,
           T12.Description AS SignDescription,
           T1.Account,
           T9.Code AS AccountCode,
           T9.Description AS AccountDescription,
           T1.Asset,
           T21.Code AS AssetCode,
           T21.Description AS AssetDescription,
           T1.Deal,
           T19.Code AS DealCode,
           T19.Description AS DealDescription,
           T1.Item,
           T18.Code AS ItemCode,
           T18.Description AS ItemDescription,
           T1.Debt,
           T17.Code AS DebtCode,
           T17.Description AS DebtDescription,
           T1.Price,
           T20.Code AS PriceCode,
           T20.Description AS PriceDescription,
           T1.Role,
           T10.Code AS RoleCode,
           T10.Description AS RoleDescription,
           T1.Info,
           T11.Code AS InfoCode,
           T11.Description AS InfoDescription,
           T1.Meter,
           T22.Code AS MeterCode,
           T22.Description AS MeterDescription,
           T1.MeterValue AS MeterValue,
           T1.Unit,
           T13.Code AS UnitCode,
           T13.Description AS UnitDescription,
           T1.More AS More
      FROM Process AS T1
           LEFT JOIN
           Process AS T4 ON T1.Parent = T4.Id
           LEFT JOIN
           Slice AS T3 ON T1.Slice = T3.Id
           LEFT JOIN
           Face AS T5 ON T1.Face = T5.Id
           LEFT JOIN
           Face AS T6 ON T1.Face1 = T6.Id
           LEFT JOIN
           Face AS T7 ON T1.Face2 = T7.Id
           LEFT JOIN
           Account AS T9 ON T1.Account = T9.Id
           LEFT JOIN
           Role AS T10 ON T1.Role = T10.Id
           LEFT JOIN
           Info AS T11 ON T1.Info = T11.Id
           LEFT JOIN
           Sign AS T12 ON T1.Sign = T12.Id
           LEFT JOIN
           Unit AS T13 ON T1.Unit = T13.Id
           LEFT JOIN
           Debt AS T17 ON T1.Debt = T17.Id
           LEFT JOIN
           Item AS T18 ON T1.Item = T18.Id
           LEFT JOIN
           Deal AS T19 ON T1.Deal = T19.Id
           LEFT JOIN
           Price AS T20 ON T1.Price = T20.Id
           LEFT JOIN
           Asset AS T21 ON T1.Asset = T21.Id
           LEFT JOIN
           Meter AS T22 ON T1.Meter = T22.Id;


-- View: RoleList
CREATE VIEW IF NOT EXISTS RoleList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.More AS More
      FROM Role AS T1
           LEFT JOIN
           Role AS T4 ON T1.Parent = T4.Id;


-- View: SignList
CREATE VIEW IF NOT EXISTS SignList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.Role,
           T10.Code AS RoleCode,
           T10.Description AS RoleDescription,
           T1.Info,
           T11.Code AS InfoCode,
           T11.Description AS InfoDescription,
           T1.More AS More
      FROM Sign AS T1
           LEFT JOIN
           Sign AS T4 ON T1.Parent = T4.Id
           LEFT JOIN
           Role AS T10 ON T1.Role = T10.Id
           LEFT JOIN
           Info AS T11 ON T1.Info = T11.Id;


-- View: SliceList
CREATE VIEW IF NOT EXISTS SliceList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.More AS More
      FROM Slice AS T1
           LEFT JOIN
           Slice AS T4 ON T1.Parent = T4.Id;


-- View: UnitList
CREATE VIEW IF NOT EXISTS UnitList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.Role,
           T10.Code AS RoleCode,
           T10.Description AS RoleDescription,
           T1.More AS More
      FROM Unit AS T1
           LEFT JOIN
           Unit AS T4 ON T1.Parent = T4.Id
           LEFT JOIN
           Role AS T10 ON T1.Role = T10.Id;


-- View: WorkbookList
CREATE VIEW IF NOT EXISTS WorkbookList AS
    SELECT T1.Id,
           T1.Parent,
           T4.Code AS ParentCode,
           T4.Description AS ParentDescription,
           T1.Face1,
           T6.Code AS Face1Code,
           T6.Description AS Face1Description,
           T1.Face2,
           T7.Code AS Face2Code,
           T7.Description AS Face2Description,
           T1.Face,
           T5.Code AS FaceCode,
           T5.Description AS FaceDescription,
           T1.Slice,
           T3.Code AS SliceCode,
           T3.Description AS SliceDescription,
           T1.Date1 AS Date1,
           T1.Date2 AS Date2,
           T1.Code AS Code,
           T1.Description AS Description,
           T1.Geo,
           T8.Code AS GeoCode,
           T8.Description AS GeoDescription,
           T1.Sign,
           T12.Code AS SignCode,
           T12.Description AS SignDescription,
           T1.Account,
           T9.Code AS AccountCode,
           T9.Description AS AccountDescription,
           T1.Process,
           T16.Code AS ProcessCode,
           T16.Description AS ProcessDescription,
           T1.Debt,
           T17.Code AS DebtCode,
           T17.Description AS DebtDescription,
           T1.Item,
           T18.Code AS ItemCode,
           T18.Description AS ItemDescription,
           T1.Deal,
           T19.Code AS DealCode,
           T19.Description AS DealDescription,
           T1.Price,
           T20.Code AS PriceCode,
           T20.Description AS PriceDescription,
           T1.Asset,
           T21.Code AS AssetCode,
           T21.Description AS AssetDescription,
           T1.Role,
           T10.Code AS RoleCode,
           T10.Description AS RoleDescription,
           T1.Info,
           T11.Code AS InfoCode,
           T11.Description AS InfoDescription,
           T1.Meter,
           T22.Code AS MeterCode,
           T22.Description AS MeterDescription,
           T1.MeterValue AS MeterValue,
           T1.Unit,
           T13.Code AS UnitCode,
           T13.Description AS UnitDescription,
           T1.Mark,
           T2.Code AS MarkCode,
           T2.Description AS MarkDescription
      FROM Workbook AS T1
           LEFT JOIN
           Workbook AS T4 ON T1.Parent = T4.Id
           LEFT JOIN
           Mark AS T2 ON T1.Mark = T2.Id
           LEFT JOIN
           Slice AS T3 ON T1.Slice = T3.Id
           LEFT JOIN
           Face AS T5 ON T1.Face = T5.Id
           LEFT JOIN
           Face AS T6 ON T1.Face1 = T6.Id
           LEFT JOIN
           Face AS T7 ON T1.Face2 = T7.Id
           LEFT JOIN
           Geo AS T8 ON T1.Geo = T8.Id
           LEFT JOIN
           Account AS T9 ON T1.Account = T9.Id
           LEFT JOIN
           Role AS T10 ON T1.Role = T10.Id
           LEFT JOIN
           Info AS T11 ON T1.Info = T11.Id
           LEFT JOIN
           Sign AS T12 ON T1.Sign = T12.Id
           LEFT JOIN
           Unit AS T13 ON T1.Unit = T13.Id
           LEFT JOIN
           Process AS T16 ON T1.Process = T16.Id
           LEFT JOIN
           Debt AS T17 ON T1.Debt = T17.Id
           LEFT JOIN
           Item AS T18 ON T1.Item = T18.Id
           LEFT JOIN
           Deal AS T19 ON T1.Deal = T19.Id
           LEFT JOIN
           Price AS T20 ON T1.Price = T20.Id
           LEFT JOIN
           Asset AS T21 ON T1.Asset = T21.Id
           LEFT JOIN
           Meter AS T22 ON T1.Meter = T22.Id;


COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
