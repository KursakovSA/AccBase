﻿--Курсаков С.А. https://github.com/KursakovSA/AccBase 

CREATE INDEX IF NOT EXISTS AssetParent ON Asset (
    Parent
);
 
CREATE INDEX IF NOT EXISTS AssetDate1 ON Asset (
    Date1
);

CREATE INDEX IF NOT EXISTS AssetCode ON Asset (
    Code
);
 
CREATE INDEX IF NOT EXISTS AssetDescription ON Asset (
    Description
);

CREATE INDEX IF NOT EXISTS AssetRole ON Asset (
    Role
);

CREATE INDEX IF NOT EXISTS AssetInfo ON Asset (
    Info
);

CREATE INDEX IF NOT EXISTS AssetUnit ON Asset (
    Unit
);

CREATE INDEX IF NOT EXISTS DealParent ON Deal (
    Parent
);

CREATE INDEX IF NOT EXISTS DealFace1 ON Deal (
    Face1
);

CREATE INDEX IF NOT EXISTS DealFace2 ON Deal (
    Face2
);

CREATE INDEX IF NOT EXISTS DealFace ON Deal (
    Face
);

CREATE INDEX IF NOT EXISTS DealCode ON Deal (
    Code
);
 
CREATE INDEX IF NOT EXISTS DealDescription ON Deal (
    Description
);

CREATE INDEX IF NOT EXISTS DealGeo ON Deal (
    Geo
);

CREATE INDEX IF NOT EXISTS DealRole ON Deal (
    Role
);

CREATE INDEX IF NOT EXISTS DealInfo ON Deal (
    Info
);

CREATE INDEX IF NOT EXISTS FaceParent ON Face (
    Parent
);

CREATE INDEX IF NOT EXISTS FaceDate1 ON Face (
    Date1
);

CREATE INDEX IF NOT EXISTS FaceCode ON Face (
    Code
);
 
CREATE INDEX IF NOT EXISTS FaceDescription ON Face (
    Description
);

CREATE INDEX IF NOT EXISTS FaceGeo ON Face (
    Geo
);

CREATE INDEX IF NOT EXISTS FaceRole ON Face (
    Role
);

CREATE INDEX IF NOT EXISTS FaceInfo ON Face (
    Info
);
 
CREATE INDEX IF NOT EXISTS WorkbookParent ON Workbook (
    Parent
);

CREATE INDEX IF NOT EXISTS WorkbookFace1 ON Workbook (
    Face1
);

CREATE INDEX IF NOT EXISTS WorkbookFace2 ON Workbook (
    Face2
);

CREATE INDEX IF NOT EXISTS WorkbookFace ON Workbook (
    Face
);

CREATE INDEX IF NOT EXISTS WorkbookSlice ON Workbook (
    Slice
);

CREATE INDEX IF NOT EXISTS WorkbookDate1 ON Workbook (
    Date1
);

CREATE INDEX IF NOT EXISTS WorkbookCode ON Workbook (
    Code
);
 
CREATE INDEX IF NOT EXISTS WorkbookDescription ON Workbook (
    Description
);

CREATE INDEX IF NOT EXISTS WorkbookSign ON Workbook (
    Sign
);

CREATE INDEX IF NOT EXISTS WorkbookAccount ON Workbook (
    Account
);

CREATE INDEX IF NOT EXISTS WorkbookProcess ON Workbook (
    Process
);

CREATE INDEX IF NOT EXISTS WorkbookDebt ON Workbook (
    Debt
);

CREATE INDEX IF NOT EXISTS WorkbookItem ON Workbook (
    Item
);

CREATE INDEX IF NOT EXISTS WorkbookDeal ON Workbook (
    Deal
);

CREATE INDEX IF NOT EXISTS WorkbookPrice ON Workbook (
    Price
);

CREATE INDEX IF NOT EXISTS WorkbookAsset ON Workbook (
    Asset
);

CREATE INDEX IF NOT EXISTS WorkbookRole ON Workbook (
    Role
);

CREATE INDEX IF NOT EXISTS WorkbookInfo ON Workbook (
    Info
);

CREATE INDEX IF NOT EXISTS WorkbookMeter ON Workbook (
    Meter
);

CREATE INDEX IF NOT EXISTS WorkbookUnit ON Workbook (
    Unit
);

CREATE INDEX IF NOT EXISTS WorkbookMark ON Workbook (
    Mark
);