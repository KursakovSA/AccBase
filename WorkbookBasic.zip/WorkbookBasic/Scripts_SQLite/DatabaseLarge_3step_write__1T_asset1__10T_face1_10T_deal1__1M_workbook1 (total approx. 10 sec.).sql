
--нагенерим Asset1
create table if not exists Asset1 as
with recursive Asset1(Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, Unit, More) as (
    select 1, NULL, '', '', 'Asset.', 'Asset.Data', 11, 29, 8, 6, '{"Role.Generic.Code": "Asset.Basic",}'
    union all
    select
        Asset1.id + 1 as id,
        Asset1.id as Parent,
        current_timestamp as Date1,
        current_timestamp as Date2,
        'Товар' || cast(Asset1.Id+1 as text) as Code,
        'Товар' || cast(Asset1.Id+1 as text) as Description,
         11 as Geo, 
         29 as Role,
         8 as Info,
         6 as Unit,
         '{"Role.Generic.Code": "Asset.Basic",}' as More
    from Asset1
    limit 1000  --1 тыс активов  
)
select * from Asset1;


--нагенерим Face1
create table if not exists Face1 as
with recursive Face1(Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) as (
    select 1, NULL, '', '', 'Face.', 'Face.Data', 11, 115, 57, '{"Role.Generic.Code": "Face.Basic",}'
    union all
    select
        Face1.id + 1 as id,
        Face1.id as Parent,
        current_timestamp as Date1,
        current_timestamp as Date2,
        'Лицо' || cast(Face1.Id+1 as text) as Code,
        'Лицо' || cast(Face1.Id+1 as text) as Description,
         11 as Geo, 
         29 as Role,
         8 as Info,
         '{"Role.Generic.Code": "Face.Basic",}' as More
    from Face1
    limit 10000  --10 тыс лиц
)
select * from Face1;


--нагенерим Deal1
create table if not exists Deal1 as
with recursive Deal1(Id, Parent, Face1, Face2, Face, Date1, Date2, Code, Description, Geo, Role, Info, More) as (
    select 1, NULL, NULL, NULL, NULL, '', '', 'Deal.', 'Deal.Data', 11, 51, 32, '{"Role.Generic.Code": "Deal.Basic",}'
    union all
    select
        Deal1.id + 1 as id,
        Deal1.id as Parent,
        abs(random() % 10000) as Face1,  --случайное лицо в диапазаоне от 1 до 10 тыс
        abs(random() % 10000) as Face2,  --случайное лицо в диапазаоне от 1 до 10 тыс
        abs(random() % 10000) as Face,   --случайное лицо в диапазаоне от 1 до 10 тыс
        current_timestamp as Date1,
        current_timestamp as Date2,
        'Договор' || cast(Deal1.Id+1 as text) as Code,
        'Договор' || cast(Deal1.Id+1 as text) as Description,
         11 as Geo, 
         29 as Role,
         8 as Info,
         '{"Role.Generic.Code": "Deal.Basic",}' as More
    from Deal1
    limit 10000
)
select * from Deal1;


--нагенерим Workbook1
create table if not exists Workbook1 as
with recursive Workbook1(Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Geo, Sign, Account, Process, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) as (
    select 1, NULL, '', '', '', '', '', '', 'Workbook.', 'Workbook.Data', 11, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 115, 57, NULL, '', NULL, '{"Role.Generic.Code": "Workbook.Basic",}', 11
    union all
    select
        Workbook1.id + 1 as id,
        Workbook1.id as Parent,
        2 as Face1,  --Id=2 FA1
        abs(random() % 10000) as Face2,  --случайное лицо в диапазоне от 1 до 10 тыс
        10 as Face,   --Id=10 FA1.User1
        1 as Slice,  --Slice.Accounting = 1  
        current_timestamp as Date1,
        current_timestamp as Date2,
        'Рабочая книга' || cast(Workbook1.Id+1 as text) as Code,
        'Рабочая книга' || cast(Workbook1.Id+1 as text) as Description,
         11 as Geo,  --Geo.Qazaqstan=11
         3 as Sign,  --Id=3 Sign.Acc.Dt   
         32 as Account,  --Id=32 Acc.1330  
         abs(random() %222) as Process,   --случайное число от 1 до 222  
         abs(random() % 1000) as Asset,  --случайное число от 1 до 1 тыс    
         abs(random() % 10000) as Deal,  --случайное число от 1 до 10 тыс
         abs(random() % 37) as Item,  --случайное число от 1 до 37  
         abs(random() % 83) as Debt,  --случайное число от 1 до 83  
         2 as Price,  --Price.Оптовая цена = 2
         abs(random() % 235) as Role,  --случайное число от 1 до 235  
         8 as Info,
         13 as Meter,  --Meter.Quantity=13
         cast(abs(random() % 100000) as text) as MeterValue,  --случайная сумма в диапазоне от 1 до 1 млн   
         22 as Unit,  --Unit.KZT = 22
         '{"Role.Generic.Code": "Workbook.Basic",}' as More,
         2 as Mark  --Mark.CD (Mark.CurremtData) = 2  
    from Workbook1
    limit 1000000
)
select * from Workbook1;