PRAGMA integrity_check;
reindex;
vacuum;