--
-- Файл сгенерирован с помощью SQLiteStudio v3.4.3 в Вс апр 9 07:17:10 2023
--
-- Использованная кодировка текста: UTF-8
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Таблица: Account
CREATE TABLE IF NOT EXISTS [Account](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Account(Id),
	[Slice] TEXT references Slice(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
    [Role] TEXT references Role(Id),
    [Sign] TEXT references Sign(Id),
	[More] TEXT
 );
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1', 'AcctTable2019', 'Slice.Norm', '', '', 'Account.1', 'Краткосрочные активы', 'Role.Account.Group1Level', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1000', 'Account.1', 'Slice.Norm', '', '', 'Account.1000', 'Денежные средства', 'Role.Account.Money', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1010', 'Account.1000', 'Slice.Accounting', '', '', 'Account.1010', 'Денежные средства в кассе', 'Role.Store.Cash', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1020', 'Account.1000', 'Slice.Accounting', '', '', 'Account.1020', 'Денежные средства в пути', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1030', 'Account.1000', 'Slice.Accounting', '', '', 'Account.1030', 'Денежные средства на текущих банковских счетах', 'Role.Store.Bank', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1040', 'Account.1000', 'Slice.Norm', '', '', 'Account.1040', 'Денежные средства на корреспондентских счетах', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1050', 'Account.1000', 'Slice.Norm', '', '', 'Account.1050', 'Денежные средства на сберегательных счетах', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1060', 'Account.1000', 'Slice.Norm', '', '', 'Account.1060', 'Денежные средства, ограниченные в использовании', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1070', 'Account.1000', 'Slice.Norm', '', '', 'Account.1070', 'Учет электронных денег', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1080', 'Account.1000', 'Slice.Norm', '', '', 'Account.1080', 'Прочие денежные средства', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1090', 'Account.1000', 'Slice.Norm', '', '', 'Account.1090', 'Оценочный резерв под убытки от обесценения денежных средств', 'Role.Account.Other', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1100', 'Account.1', 'Slice.Norm', '', '', 'Account.1100', 'Краткосрочные финансовые активы', 'Role.Account.Asset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1110', 'Account.1100', 'Slice.Norm', '', '', 'Account.1110', 'Краткосрочные финансовые активы, оцениваемые по амортизированной стоимости', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1120', 'Account.1100', 'Slice.Norm', '', '', 'Account.1120', 'Краткосрочные финансовые активы, оцениваемые по справедливой стоимости через прочий совокупный доход', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1130', 'Account.1100', 'Slice.Norm', '', '', 'Account.1130', 'Краткосрочные финансовые активы, оцениваемые по справедливой стоимости через прибыль или убыток', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1140', 'Account.1100', 'Slice.Norm', '', '', 'Account.1140', 'Производные финансовые инструменты', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1150', 'Account.1100', 'Slice.Norm', '', '', 'Account.1150', 'Краткосрочные вознаграждения к получению', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1160', 'Account.1100', 'Slice.Norm', '', '', 'Account.1160', 'Прочие краткосрочные финансовые активы', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1170', 'Account.1100', 'Slice.Norm', '', '', 'Account.1170', 'Оценочный резерв под убытки от обесценения краткосрочных финансовых активов', 'Role.Account.Other', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1200', 'Account.1', 'Slice.Norm', '', '', 'Account.1200', 'Краткосрочная дебиторская задолженность', 'Role.Account.Face', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1210', 'Account.1200', 'Slice.Accounting', '', '', 'Account.1210', 'Краткосрочная дебиторская задолженность покупателей и заказчиков', '', 'Sign.Acc.Dt-Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1220', 'Account.1200', 'Slice.Norm', '', '', 'Account.1220', 'Краткосрочная дебиторская задолженность дочерних организаций', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1230', 'Account.1200', 'Slice.Norm', '', '', 'Account.1230', 'Краткосрочная дебиторская задолженность ассоциированных и совместных организаций', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1240', 'Account.1200', 'Slice.Norm', '', '', 'Account.1240', 'Краткосрочная дебиторская задолженность филиалов и структурных подразделений', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1250', 'Account.1200', 'Slice.Accounting', '', '', 'Account.1250', 'Краткосрочная дебиторская задолженность работников', '', 'Sign.Acc.Dt-Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1260', 'Account.1200', 'Slice.Norm', '', '', 'Account.1260', 'Краткосрочная дебиторская задолженность по аренде', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1270', 'Account.1200', 'Slice.Norm', '', '', 'Account.1270', 'Прочая краткосрочная дебиторская задолженность', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1280', 'Account.1200', 'Slice.Norm', '', '', 'Account.1280', 'Оценочный резерв под убытки от обесценения краткосрочной дебиторской задолженности', 'Role.Account.Other', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1300', 'Account.1', 'Slice.Norm', '', '', 'Account.1300', 'Запасы', 'Role.Account.Asset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1310', 'Account.1300', 'Slice.Accounting', '', '', 'Account.1310', 'Сырье и материалы', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1320', 'Account.1300', 'Slice.Accounting', '', '', 'Account.1320', 'Готовая продукция', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1330', 'Account.1300', 'Slice.Accounting', '', '', 'Account.1330', 'Товары', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1340', 'Account.1300', 'Slice.Accounting', '', '', 'Account.1340', 'Незавершенное производство', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1350', 'Account.1300', 'Slice.Norm', '', '', 'Account.1350', 'Прочие запасы', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1360', 'Account.1300', 'Slice.Norm', '', '', 'Account.1360', 'Оценочный резерв под убытки от обесценения запасов', 'Role.Account.Other', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1370', 'Account.1300', 'Slice.Norm', '', '', 'Account.1370', 'Актив по праву на возврат запасов', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1400', 'Account.1', 'Slice.Norm', '', '', 'Account.1400', 'Текущие налоговые активы', 'Role.Account.Tax', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1410', 'Account.1400', 'Slice.Accounting', '', '', 'Account.1410', 'Корпоративный подоходный налог', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1420', 'Account.1400', 'Slice.Accounting', '', '', 'Account.1420', 'Налог на добавленную стоимость', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1430', 'Account.1400', 'Slice.Norm', '', '', 'Account.1430', 'Прочие налоги и другие обязательные платежи в бюджет', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1500', 'Account.1', 'Slice.Norm', '', '', 'Account.1500', 'Долгосрочные активы, предназначенные для продажи', 'Role.Account.Asset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1510', 'Account.1500', 'Slice.Norm', '', '', 'Account.1510', 'Долгосрочные активы, предназначенные для продажи', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1520', 'Account.1500', 'Slice.Norm', '', '', 'Account.1520', 'Группы на выбытие, предназначенные для продажи', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1530', 'Account.1500', 'Slice.Norm', '', '', 'Account.1530', 'Оценочный резерв под убытки от обесценения долгосрочных активов (или выбывающих групп), предназначенных для продажи', 'Role.Account.Other', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1600', 'Account.1', 'Slice.Norm', '', '', 'Account.1600', 'Биологические активы', 'Role.Account.Asset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1610', 'Account.1600', 'Slice.Norm', '', '', 'Account.1610', 'Растения', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1620', 'Account.1600', 'Slice.Norm', '', '', 'Account.1620', 'Животные', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1630', 'Account.1600', 'Slice.Norm', '', '', 'Account.1630', 'Оценочный резерв под убытки от обесценения биологических активов', 'Role.Account.Other', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1700', 'Account.1', 'Slice.Norm', '', '', 'Account.1700', 'Прочие краткосрочные активы', 'Role.Account.Asset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1710', 'Account.1700', 'Slice.Accounting', '', '', 'Account.1710', 'Краткосрочные авансы выданные', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1720', 'Account.1700', 'Slice.Norm', '', '', 'Account.1720', 'Расходы будущих периодов', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1730', 'Account.1700', 'Slice.Norm', '', '', 'Account.1730', 'Краткосрочные активы по договорам', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1740', 'Account.1700', 'Slice.Norm', '', '', 'Account.1740', 'Оценочный резерв под убытки от обесценения краткосрочных активов по договорам', 'Role.Account.Other', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.1750', 'Account.1700', 'Slice.Norm', '', '', 'Account.1750', 'Прочие краткосрочные активы.', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2', 'AcctTable2019', 'Slice.Norm', '', '', 'Account.2', 'Долгосрочные активы', 'Role.Account.Group1Level', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2000', 'Account.2', 'Slice.Norm', '', '', 'Account.2000', 'Долгосрочные финансовые активы', 'Role.Account.Asset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2010', 'Account.2000', 'Slice.Norm', '', '', 'Account.2010', 'Долгосрочные финансовые активы, оцениваемые по амортизированной стоимости', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2020', 'Account.2000', 'Slice.Norm', '', '', 'Account.2020', 'Долгосрочные финансовые активы, оцениваемые по справедливой стоимости через прочий совокупный доход', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2030', 'Account.2000', 'Slice.Norm', '', '', 'Account.2030', 'Долгосрочные финансовые активы, оцениваемые по справедливой стоимости через прибыль или убыток', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2040', 'Account.2000', 'Slice.Norm', '', '', 'Account.2040', 'Производные финансовые инструменты', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2050', 'Account.2000', 'Slice.Norm', '', '', 'Account.2050', 'Долгосрочные вознаграждения к получению', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2060', 'Account.2000', 'Slice.Norm', '', '', 'Account.2060', 'Долевые инструменты', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2070', 'Account.2000', 'Slice.Norm', '', '', 'Account.2070', 'Прочие долгосрочные финансовые активы', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2080', 'Account.2000', 'Slice.Norm', '', '', 'Account.2080', 'Оценочный резерв под убытки от обесценения долгосрочных финансовых активов', 'Role.Account.Other', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2100', 'Account.2', 'Slice.Norm', '', '', 'Account.2100', 'Долгосрочная дебиторская задолженность', 'Role.Account.Face', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2110', 'Account.2100', 'Slice.Norm', '', '', 'Account.2110', 'Долгосрочная задолженность покупателей и заказчиков', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2120', 'Account.2100', 'Slice.Norm', '', '', 'Account.2120', 'Долгосрочная дебиторская задолженность дочерних организаций', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2130', 'Account.2100', 'Slice.Norm', '', '', 'Account.2130', 'Долгосрочная дебиторская задолженность ассоциированных и совместных организаций', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2140', 'Account.2100', 'Slice.Norm', '', '', 'Account.2140', 'Долгосрочная дебиторская задолженность филиалов и структурных подразделений', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2150', 'Account.2100', 'Slice.Norm', '', '', 'Account.2150', 'Долгосрочная дебиторская задолженность работников', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2160', 'Account.2100', 'Slice.Norm', '', '', 'Account.2160', 'Долгосрочная дебиторская задолженность по аренде', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2170', 'Account.2100', 'Slice.Norm', '', '', 'Account.2170', 'Прочая долгосрочная дебиторская задолженность', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2180', 'Account.2100', 'Slice.Norm', '', '', 'Account.2180', 'Оценочный резерв под убытки от обесценения долгосрочной дебиторской задолженности', 'Role.Account.Other', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2200', 'Account.2', 'Slice.Norm', '', '', 'Account.2200', 'Инвестиции', 'Role.Account.Asset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2210', 'Account.2200', 'Slice.Norm', '', '', 'Account.2210', 'Инвестиции, учитываемые методом долевого участия', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2220', 'Account.2200', 'Slice.Norm', '', '', 'Account.2220', 'Инвестиции, учитываемые по первоначальной стоимости', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2230', 'Account.2200', 'Slice.Norm', '', '', 'Account.2230', 'Оценочный резерв под убытки от обесценения инвестиций', 'Role.Account.Other', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2300', 'Account.2', 'Slice.Norm', '', '', 'Account.2300', 'Инвестиционное имущество', 'Role.Account.Asset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2310', 'Account.2300', 'Slice.Norm', '', '', 'Account.2310', 'Инвестиционное имущество', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2320', 'Account.2300', 'Slice.Norm', '', '', 'Account.2320', 'Амортизация инвестиционного имущества', 'Role.Account.Depreciation', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2330', 'Account.2300', 'Slice.Norm', '', '', 'Account.2330', 'Оценочный резерв под убытки от обесценения инвестиционного имущества', 'Role.Account.Other', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2400', 'Account.2', 'Slice.Norm', '', '', 'Account.2400', 'Основные средства', 'Role.Account.Asset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2410', 'Account.2400', 'Slice.Accounting', '', '', 'Account.2410', 'Основные средства', 'Role.Account.FixedAsset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2420', 'Account.2400', 'Slice.Accounting', '', '', 'Account.2420', 'Амортизация основных средств', 'Role.Account.Depreciation', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2430', 'Account.2400', 'Slice.Norm', '', '', 'Account.2430', 'Оценочный резерв под убытки от обесценения основных средств', 'Role.Account.Other', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2440', 'Account.2400', 'Slice.Norm', '', '', 'Account.2440', 'Право пользования активом', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2450', 'Account.2400', 'Slice.Norm', '', '', 'Account.2450', 'Амортизация права пользования активом', 'Role.Account.Depreciation', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2460', 'Account.2400', 'Slice.Norm', '', '', 'Account.2460', 'Убыток от обесценения права пользования активом', 'Role.Account.Other', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2500', 'Account.2', 'Slice.Norm', '', '', 'Account.2500', 'Биологические активы', 'Role.Account.Asset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2510', 'Account.2500', 'Slice.Norm', '', '', 'Account.2510', 'Растения', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2520', 'Account.2500', 'Slice.Norm', '', '', 'Account.2520', 'Животные', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2530', 'Account.2500', 'Slice.Norm', '', '', 'Account.2530', 'Амортизация биологических активов', 'Role.Account.Depreciation', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2540', 'Account.2500', 'Slice.Norm', '', '', 'Account.2540', 'Оценочный резерв под убытки от обесценения биологических активов', 'Role.Account.Other', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2600', 'Account.2', 'Slice.Norm', '', '', 'Account.2600', 'Разведочные и оценочные активы', 'Role.Account.Asset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2610', 'Account.2600', 'Slice.Norm', '', '', 'Account.2610', 'Разведочные и оценочные активы', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2620', 'Account.2600', 'Slice.Norm', '', '', 'Account.2620', 'Амортизация разведочных и оценочных активов', 'Role.Account.Depreciation', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2630', 'Account.2600', 'Slice.Norm', '', '', 'Account.2630', 'Оценочный резерв под убытки от обесценения разведочных и оценочных активов', 'Role.Account.Other', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2700', 'Account.2', 'Slice.Norm', '', '', 'Account.2700', 'Нематериальные активы', 'Role.Account.Asset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2710', 'Account.2700', 'Slice.Norm', '', '', 'Account.2710', 'Гудвилл', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2720', 'Account.2700', 'Slice.Norm', '', '', 'Account.2720', 'Обесценение гудвилла', 'Role.Account.Other', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2730', 'Account.2700', 'Slice.Norm', '', '', 'Account.2730', 'Прочие нематериальные активы', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2740', 'Account.2700', 'Slice.Norm', '', '', 'Account.2740', 'Амортизация прочих нематериальных активов', 'Role.Account.Depreciation', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2750', 'Account.2700', 'Slice.Norm', '', '', 'Account.2750', 'Оценочный резерв под убытки от обесценения прочих нематериальных активов', 'Role.Account.Other', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2760', 'Account.2700', 'Slice.Norm', '', '', 'Account.2760', 'Право пользования активом', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2770', 'Account.2700', 'Slice.Norm', '', '', 'Account.2770', 'Амортизация права пользования активом', 'Role.Account.Depreciation', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2780', 'Account.2700', 'Slice.Norm', '', '', 'Account.2780', 'Оценочный резерв под убытки от обесценения права пользования активом', 'Role.Account.Other', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2800', 'Account.2', 'Slice.Norm', '', '', 'Account.2800', 'Отложенные налоговые активы', 'Role.Account.Tax', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2810', 'Account.2800', 'Slice.Norm', '', '', 'Account.2810', 'Отложенные налоговые активы по корпоративному подоходному налогу', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2900', 'Account.2', 'Slice.Norm', '', '', 'Account.2900', 'Прочие долгосрочные активы', 'Role.Account.Face', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2910', 'Account.2900', 'Slice.Norm', '', '', 'Account.2910', 'Долгосрочные авансы выданные', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2920', 'Account.2900', 'Slice.Norm', '', '', 'Account.2920', 'Расходы будущих периодов', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2930', 'Account.2900', 'Slice.Accounting', '', '', 'Account.2930', 'Незавершенное строительство', 'Role.Account.Asset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2940', 'Account.2900', 'Slice.Norm', '', '', 'Account.2940', 'Долгосрочные активы по договорам', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2950', 'Account.2900', 'Slice.Norm', '', '', 'Account.2950', 'Оценочный резерв под убытки от обесценения долгосрочных активов по договорам', 'Role.Account.Other', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2960', 'Account.2900', 'Slice.Norm', '', '', 'Account.2960', 'Затраты по договорам', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2970', 'Account.2900', 'Slice.Norm', '', '', 'Account.2970', 'Амортизация затрат по договорам', 'Role.Account.Depreciation', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2980', 'Account.2900', 'Slice.Norm', '', '', 'Account.2980', 'Оценочный резерв под убытки от обесценения затрат по договорам', 'Role.Account.Other', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.2990', 'Account.2900', 'Slice.Norm', '', '', 'Account.2990', 'Прочие долгосрочные активы', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3', 'AcctTable2019', 'Slice.Norm', '', '', 'Account.3', 'Краткосрочные обязательства', 'Role.Account.Group1Level', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3000', 'Account.3', 'Slice.Norm', '', '', 'Account.3000', 'Краткосрочные финансовые обязательства', 'Role.Account.Face', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3010', 'Account.3000', 'Slice.Norm', '', '', 'Account.3010', 'Краткосрочные финансовые обязательства, оцениваемые по амортизированной стоимости', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3020', 'Account.3000', 'Slice.Norm', '', '', 'Account.3020', 'Краткосрочные финансовые обязательства, оцениваемые по справедливой стоимости через прибыль или убыток', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3030', 'Account.3000', 'Slice.Norm', '', '', 'Account.3030', 'Производные финансовые инструменты', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3040', 'Account.3000', 'Slice.Norm', '', '', 'Account.3040', 'Краткосрочная кредиторская задолженность по дивидендам и доходам участников', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3050', 'Account.3000', 'Slice.Norm', '', '', 'Account.3050', 'Краткосрочные вознаграждения к выплате', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3060', 'Account.3000', 'Slice.Norm', '', '', 'Account.3060', 'Текущая часть долгосрочных финансовых обязательств, оцениваемых по амортизированной стоимости', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3070', 'Account.3000', 'Slice.Norm', '', '', 'Account.3070', 'Текущая часть долгосрочных финансовых обязательств, оцениваемых по справедливой стоимости через прибыль или убытки', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3080', 'Account.3000', 'Slice.Norm', '', '', 'Account.3080', 'Прочие краткосрочные финансовые обязательства', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3100', 'Account.3', 'Slice.Norm', '', '', 'Account.3100', 'Обязательства по налогам', 'Role.Account.Tax', 'Sign.Acc.Ct-Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3110', 'Account.3100', 'Slice.Accounting', '', '', 'Account.3110', 'Корпоративный подоходный налог, подлежащий уплате', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3120', 'Account.3100', 'Slice.Accounting', '', '', 'Account.3120', 'Индивидуальный подоходный налог', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3130', 'Account.3100', 'Slice.Accounting', '', '', 'Account.3130', 'Налог на добавленную стоимость', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3140', 'Account.3100', 'Slice.Accounting', '', '', 'Account.3140', 'Акцизы', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3150', 'Account.3100', 'Slice.Accounting', '', '', 'Account.3150', 'Социальный налог', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3160', 'Account.3100', 'Slice.Accounting', '', '', 'Account.3160', 'Земельный налог', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3170', 'Account.3100', 'Slice.Accounting', '', '', 'Account.3170', 'Налог на транспортные средства', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3180', 'Account.3100', 'Slice.Accounting', '', '', 'Account.3180', 'Налог на имущество', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3190', 'Account.3100', 'Slice.Accounting', '', '', 'Account.3190', 'Прочие налоги', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3200', 'Account.3', 'Slice.Norm', '', '', 'Account.3200', 'Обязательства по другим обязательным и добровольным платежам', 'Role.Account.Tax', 'Sign.Acc.Ct-Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3210', 'Account.3200', 'Slice.Accounting', '', '', 'Account.3210', 'Обязательства по социальному страхованию', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3220', 'Account.3200', 'Slice.Accounting', '', '', 'Account.3220', 'Обязательства по пенсионным отчислениям', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3230', 'Account.3200', 'Slice.Accounting', '', '', 'Account.3230', 'Прочие обязательства по другим обязательным платежам', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3240', 'Account.3200', 'Slice.Accounting', '', '', 'Account.3240', 'Прочие обязательства по другим добровольным платежам', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3300', 'Account.3', 'Slice.Norm', '', '', 'Account.3300', 'Краткосрочная кредиторская задолженность', 'Role.Account.Face', 'Sign.Acc.Ct-Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3310', 'Account.3300', 'Slice.Accounting', '', '', 'Account.3310', 'Краткосрочная кредиторская задолженность поставщикам и подрядчикам', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3320', 'Account.3300', 'Slice.Norm', '', '', 'Account.3320', 'Краткосрочная кредиторская задолженность дочерним организациям', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3330', 'Account.3300', 'Slice.Norm', '', '', 'Account.3330', 'Краткосрочная кредиторская задолженность ассоциированным и совместным организациям', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3340', 'Account.3300', 'Slice.Norm', '', '', 'Account.3340', 'Краткосрочная кредиторская задолженность филиалам и структурным подразделениям', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3350', 'Account.3300', 'Slice.Accounting', '', '', 'Account.3350', 'Краткосрочная задолженность по оплате труда', 'Role.Account.Salary', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3360', 'Account.3300', 'Slice.Accounting', '', '', 'Account.3360', 'Краткосрочная задолженность по аренде', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3370', 'Account.3300', 'Slice.Norm', '', '', 'Account.3370', 'Текущая часть долгосрочной кредиторской задолженности', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3380', 'Account.3300', 'Slice.Norm', '', '', 'Account.3380', 'Прочая краткосрочная кредиторская задолженность', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3400', 'Account.3', 'Slice.Norm', '', '', 'Account.3400', 'Краткосрочные оценочные обязательства', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3410', 'Account.3400', 'Slice.Norm', '', '', 'Account.3410', 'Краткосрочные гарантийные обязательства', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3420', 'Account.3400', 'Slice.Norm', '', '', 'Account.3420', 'Краткосрочные обязательства по юридическим претензиям', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3430', 'Account.3400', 'Slice.Norm', '', '', 'Account.3430', 'Краткосрочные оценочные обязательства по вознаграждениям работникам', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3440', 'Account.3400', 'Slice.Norm', '', '', 'Account.3440', 'Прочие краткосрочные оценочные обязательства', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3500', 'Account.3', 'Slice.Norm', '', '', 'Account.3500', 'Прочие краткосрочные обязательства', 'Role.Account.Face', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3510', 'Account.3500', 'Slice.Accounting', '', '', 'Account.3510', 'Краткосрочные авансы полученные', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3520', 'Account.3500', 'Slice.Norm', '', '', 'Account.3520', 'Доходы будущих периодов', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3530', 'Account.3500', 'Slice.Norm', '', '', 'Account.3530', 'Обязательства группы на выбытие, предназначенной для продажи', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3540', 'Account.3500', 'Slice.Norm', '', '', 'Account.3540', 'Краткосрочные обязательства по договорам', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3550', 'Account.3500', 'Slice.Norm', '', '', 'Account.3550', 'Долговой компонент комбинированного краткосрочного финансового инструмента', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.3560', 'Account.3500', 'Slice.Norm', '', '', 'Account.3560', 'Прочие краткосрочные обязательства.', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.4', 'AcctTable2019', 'Slice.Norm', '', '', 'Account.4', 'Долгосрочные обязательства', 'Role.Account.Group1Level', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.4000', 'Account.4', 'Slice.Norm', '', '', 'Account.4000', 'Долгосрочные финансовые обязательства', 'Role.Account.Face', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.4010', 'Account.4000', 'Slice.Norm', '', '', 'Account.4010', 'Долгосрочные финансовые обязательства, оцениваемые по амортизированной стоимости', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.4020', 'Account.4000', 'Slice.Norm', '', '', 'Account.4020', 'Долгосрочные финансовые обязательства, оцениваемые по справедливой стоимости через прибыль или убыток', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.4030', 'Account.4000', 'Slice.Norm', '', '', 'Account.4030', 'Производные финансовые инструменты', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.4040', 'Account.4000', 'Slice.Norm', '', '', 'Account.4040', 'Долгосрочная задолженность по дивидендам и доходам участников', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.4050', 'Account.4000', 'Slice.Norm', '', '', 'Account.4050', 'Долгосрочные вознаграждения к выплате', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.4060', 'Account.4000', 'Slice.Norm', '', '', 'Account.4060', 'Прочие долгосрочные финансовые обязательства', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.4100', 'Account.4', 'Slice.Norm', '', '', 'Account.4100', 'Долгосрочная кредиторская задолженность', 'Role.Account.Face', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.4110', 'Account.4100', 'Slice.Norm', '', '', 'Account.4110', 'Долгосрочная кредиторская задолженность поставщикам и подрядчикам', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.4120', 'Account.4100', 'Slice.Norm', '', '', 'Account.4120', 'Долгосрочная кредиторская задолженность дочерним организациям', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.4130', 'Account.4100', 'Slice.Norm', '', '', 'Account.4130', 'Долгосрочная кредиторская задолженность ассоциированным и совместным организациям', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.4140', 'Account.4100', 'Slice.Norm', '', '', 'Account.4140', 'Долгосрочная кредиторская задолженность филиалам и структурным подразделениям', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.4150', 'Account.4100', 'Slice.Norm', '', '', 'Account.4150', 'Долгосрочная задолженность по аренде', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.4160', 'Account.4100', 'Slice.Norm', '', '', 'Account.4160', 'Прочая долгосрочная кредиторская задолженность', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.4200', 'Account.4', 'Slice.Norm', '', '', 'Account.4200', 'Долгосрочные оценочные обязательства', 'Role.Account.Face', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.4210', 'Account.4200', 'Slice.Norm', '', '', 'Account.4210', 'Долгосрочные гарантийные обязательства', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.4220', 'Account.4200', 'Slice.Norm', '', '', 'Account.4220', 'Долгосрочные оценочные обязательства по юридическим претензиям', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.4230', 'Account.4200', 'Slice.Norm', '', '', 'Account.4230', 'Долгосрочные оценочные обязательства по вознаграждениям работникам', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.4240', 'Account.4200', 'Slice.Norm', '', '', 'Account.4240', 'Прочие долгосрочные оценочные обязательства', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.4300', 'Account.4', 'Slice.Norm', '', '', 'Account.4300', 'Отложенные налоговые обязательства', 'Role.Account.Tax', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.4310', 'Account.4300', 'Slice.Norm', '', '', 'Account.4310', 'Отложенные налоговые обязательства по корпоративному подоходному налогу', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.4400', 'Account.4', 'Slice.Norm', '', '', 'Account.4400', 'Прочие долгосрочные обязательства', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.4410', 'Account.4400', 'Slice.Norm', '', '', 'Account.4410', 'Долгосрочные авансы полученные', 'Role.Account.Face', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.4420', 'Account.4400', 'Slice.Norm', '', '', 'Account.4420', 'Доходы будущих периодов', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.4430', 'Account.4400', 'Slice.Norm', '', '', 'Account.4430', 'Долгосрочные обязательства по договорам', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.4440', 'Account.4400', 'Slice.Norm', '', '', 'Account.4440', 'Долговой компонент комбинированного долгосрочного финансового инструмента', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.4450', 'Account.4400', 'Slice.Norm', '', '', 'Account.4450', 'Прочие долгосрочные обязательства', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.5', 'AcctTable2019', 'Slice.Norm', '', '', 'Account.5', 'Капитал и резервы', 'Role.Account.Group1Level', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.5000', 'Account.5', 'Slice.Norm', '', '', 'Account.5000', 'Уставный капитал', 'Role.Account.Capital', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.5010', 'Account.5000', 'Slice.Norm', '', '', 'Account.5010', 'Привилегированные акции', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.5020', 'Account.5000', 'Slice.Norm', '', '', 'Account.5020', 'Простые акции', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.5030', 'Account.5000', 'Slice.Accounting', '', '', 'Account.5030', 'Вклады и паи', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.5100', 'Account.5', 'Slice.Norm', '', '', 'Account.5100', 'Неоплаченный капитал', 'Role.Account.Capital', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.5110', 'Account.5100', 'Slice.Accounting', '', '', 'Account.5110', 'Неоплаченный капитал', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.5200', 'Account.5', 'Slice.Norm', '', '', 'Account.5200', 'Выкупленные собственные долевые инструменты', 'Role.Account.Capital', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.5210', 'Account.5200', 'Slice.Norm', '', '', 'Account.5210', 'Выкупленные собственные долевые инструменты', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.5300', 'Account.5', 'Slice.Norm', '', '', 'Account.5300', 'Эмиссионный доход', 'Role.Account.Capital', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.5310', 'Account.5300', 'Slice.Norm', '', '', 'Account.5310', 'Эмиссионный доход', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.5400', 'Account.5', 'Slice.Norm', '', '', 'Account.5400', 'Дополнительно оплаченный капитал', 'Role.Account.Capital', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.5410', 'Account.5400', 'Slice.Accounting', '', '', 'Account.5410', 'Дополнительно оплаченный капитал по безвозмездным операциям с основной организацией', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.5420', 'Account.5400', 'Slice.Norm', '', '', 'Account.5420', 'Дополнительно оплаченный капитал по прочим операциям', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.5500', 'Account.5', 'Slice.Norm', '', '', 'Account.5500', 'Резервы', 'Role.Account.Capital', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.5510', 'Account.5500', 'Slice.Norm', '', '', 'Account.5510', 'Резервный капитал, установленный учредительными документами', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.5520', 'Account.5500', 'Slice.Norm', '', '', 'Account.5520', 'Резерв на переоценку основных средств', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.5530', 'Account.5500', 'Slice.Norm', '', '', 'Account.5530', 'Резерв на переоценку нематериальных активов', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.5540', 'Account.5500', 'Slice.Norm', '', '', 'Account.5540', 'Резерв на переоценку финансовых активов, учитываемых по справедливой стоимости через прочий совокупный доход', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.5550', 'Account.5500', 'Slice.Norm', '', '', 'Account.5550', 'Резерв под убытки по финансовым активам', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.5560', 'Account.5500', 'Slice.Norm', '', '', 'Account.5560', 'Резерв на пересчет иностранной валюты по зарубежной деятельности', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.5570', 'Account.5500', 'Slice.Norm', '', '', 'Account.5570', 'Прочие резервы', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.5600', 'Account.5', 'Slice.Norm', '', '', 'Account.5600', 'Нераспределенная прибыль (непокрытый убыток)', 'Role.Account.Capital', 'Sign.Acc.Ct-Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.5610', 'Account.5600', 'Slice.Accounting', '', '', 'Account.5610', 'Нераспределенная прибыль (непокрытый убыток) отчетного года', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.5620', 'Account.5600', 'Slice.Accounting', '', '', 'Account.5620', 'Нераспределенная прибыль (непокрытый убыток) предыдущих лет', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.5700', 'Account.5', 'Slice.Norm', '', '', 'Account.5700', 'Итоговая прибыль (итоговый убыток)', 'Role.Account.Capital', 'Sign.Acc.Ct-Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.5710', 'Account.5700', 'Slice.Accounting', '', '', 'Account.5710', 'Итоговая прибыль (итоговый убыток)', '', 'Sign.Acc.Ct-Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.6', 'AcctTable2019', 'Slice.Norm', '', '', 'Account.6', 'Доходы', 'Role.Account.Group1Level', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.6000', 'Account.6', 'Slice.Norm', '', '', 'Account.6000', 'Доход от реализации продукции и оказания услуг', 'Role.Account.Budget', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.6010', 'Account.6000', 'Slice.Accounting', '', '', 'Account.6010', 'Доход от реализации продукции и оказания услуг', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.6020', 'Account.6000', 'Slice.Accounting', '', '', 'Account.6020', 'Возврат проданной продукции', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.6030', 'Account.6000', 'Slice.Norm', '', '', 'Account.6030', 'Скидки с цены и продаж', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.6100', 'Account.6', 'Slice.Norm', '', '', 'Account.6100', 'Доход от финансирования', 'Role.Account.Budget', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.6110', 'Account.6100', 'Slice.Norm', '', '', 'Account.6110', 'Доходы по вознаграждениям', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.6120', 'Account.6100', 'Slice.Norm', '', '', 'Account.6120', 'Доходы по дивидендам', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.6130', 'Account.6100', 'Slice.Norm', '', '', 'Account.6130', 'Доходы от финансовой аренды', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.6140', 'Account.6100', 'Slice.Norm', '', '', 'Account.6140', 'Доходы от операций с инвестициями в недвижимость', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.6150', 'Account.6100', 'Slice.Norm', '', '', 'Account.6150', 'Доходы от изменения справедливой стоимости финансовых инструментов', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.6160', 'Account.6100', 'Slice.Norm', '', '', 'Account.6160', 'Прочие доходы от финансирования', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.6200', 'Account.6', 'Slice.Norm', '', '', 'Account.6200', 'Прочие доходы', 'Role.Account.Budget', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.6210', 'Account.6200', 'Slice.Accounting', '', '', 'Account.6210', 'Доходы от выбытия активов', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.6220', 'Account.6200', 'Slice.Norm', '', '', 'Account.6220', 'Доходы от безвозмездно полученных активов', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.6230', 'Account.6200', 'Slice.Norm', '', '', 'Account.6230', 'Доходы от государственных субсидий', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.6240', 'Account.6200', 'Slice.Norm', '', '', 'Account.6240', 'Доходы от восстановления убытка от обесценения по нефинансовым активам', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.6250', 'Account.6200', 'Slice.Accounting', '', '', 'Account.6250', 'Доходы от курсовой разницы', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.6260', 'Account.6200', 'Slice.Accounting', '', '', 'Account.6260', 'Доходы от операционной аренды', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.6270', 'Account.6200', 'Slice.Norm', '', '', 'Account.6270', 'Доходы от изменения справедливой стоимости биологических активов', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.6280', 'Account.6200', 'Slice.Norm', '', '', 'Account.6280', 'Доходы от восстановления убытка от обесценения по финансовым активам', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.6290', 'Account.6200', 'Slice.Accounting', '', '', 'Account.6290', 'Прочие доходы', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.6300', 'Account.6', 'Slice.Norm', '', '', 'Account.6300', 'Доходы, связанные с прекращаемой деятельностью', 'Role.Account.Budget', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.6310', 'Account.6300', 'Slice.Norm', '', '', 'Account.6310', 'Доходы, связанные с прекращаемой деятельностью', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.6400', 'Account.6', 'Slice.Norm', '', '', 'Account.6400', 'Доля прибыли организаций, учитываемых по методу долевого участия', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.6410', 'Account.6400', 'Slice.Norm', '', '', 'Account.6410', 'Доля прибыли ассоциированных организаций', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.6420', 'Account.6400', 'Slice.Norm', '', '', 'Account.6420', 'Доля прибыли совместных организаций.', '', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.7', 'AcctTable2019', 'Slice.Norm', '', '', 'Account.7', 'Расходы', 'Role.Account.Group1Level', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.7000', 'Account.7', 'Slice.Norm', '', '', 'Account.7000', 'Себестоимость реализованной продукции и оказанных услуг', 'Role.Account.Budget', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.7010', 'Account.7000', 'Slice.Accounting', '', '', 'Account.7010', 'Себестоимость реализованной продукции и оказанных услуг', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.7100', 'Account.7', 'Slice.Norm', '', '', 'Account.7100', 'Расходы по реализации продукции и оказанию услуг', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.7110', 'Account.7100', 'Slice.Accounting', '', '', 'Account.7110', 'Расходы по реализации продукции и оказанию услуг', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.7200', 'Account.7', 'Slice.Norm', '', '', 'Account.7200', 'Административные расходы', 'Role.Account.Budget', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.7210', 'Account.7200', 'Slice.Accounting', '', '', 'Account.7210', 'Административные расходы', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.7300', 'Account.7', 'Slice.Norm', '', '', 'Account.7300', 'Расходы на финансирование', 'Role.Account.Budget', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.7310', 'Account.7300', 'Slice.Norm', '', '', 'Account.7310', 'Расходы по вознаграждениям', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.7320', 'Account.7300', 'Slice.Norm', '', '', 'Account.7320', 'Расходы на выплату процентов по финансовой аренде', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.7330', 'Account.7300', 'Slice.Norm', '', '', 'Account.7330', 'Расходы от изменения справедливой стоимости финансовых инструментов стоимости', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.7340', 'Account.7300', 'Slice.Norm', '', '', 'Account.7340', 'Прочие расходы на финансирование', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.7400', 'Account.7', 'Slice.Norm', '', '', 'Account.7400', 'Прочие расходы', 'Role.Account.Budget', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.7410', 'Account.7400', 'Slice.Norm', '', '', 'Account.7410', 'Расходы по выбытию активов', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.7420', 'Account.7400', 'Slice.Norm', '', '', 'Account.7420', 'Расходы от обесценения нефинансовых активов', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.7430', 'Account.7400', 'Slice.Accounting', '', '', 'Account.7430', 'Расходы по курсовой разнице', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.7440', 'Account.7400', 'Slice.Norm', '', '', 'Account.7440', 'Расходы по обесценению дебиторской задолженности', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.7450', 'Account.7400', 'Slice.Norm', '', '', 'Account.7450', 'Расходы по операционной аренде', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.7460', 'Account.7400', 'Slice.Norm', '', '', 'Account.7460', 'Расходы от изменения справедливой стоимости биологических активов', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.7470', 'Account.7400', 'Slice.Norm', '', '', 'Account.7470', 'Расходы от обесценения финансовых инструментов', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.7480', 'Account.7400', 'Slice.Accounting', '', '', 'Account.7480', 'Прочие расходы', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.7500', 'Account.7', 'Slice.Norm', '', '', 'Account.7500', 'Расходы, связанные с прекращаемой деятельностью', 'Role.Account.Budget', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.7510', 'Account.7500', 'Slice.Norm', '', '', 'Account.7510', 'Расходы, связанные с прекращаемой деятельностью', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.7600', 'Account.7', 'Slice.Norm', '', '', 'Account.7600', 'Доля в убытке организаций, учитываемых методом долевого участия', 'Role.Account.Budget', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.7610', 'Account.7600', 'Slice.Norm', '', '', 'Account.7610', 'Доля в убытке ассоциированных организациях', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.7620', 'Account.7600', 'Slice.Norm', '', '', 'Account.7620', 'Доля в убытке совместных организациях', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.7700', 'Account.7', 'Slice.Norm', '', '', 'Account.7700', 'Расходы по корпоративному подоходному налогу', 'Role.Account.Budget', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.7710', 'Account.7700', 'Slice.Accounting', '', '', 'Account.7710', 'Расходы по корпоративному подоходному налогу.', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.8', 'AcctTable2019', 'Slice.Norm', '', '', 'Account.8', 'Счета производственного учета', 'Role.Account.Group1Level', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.8100', 'Account.8', 'Slice.Norm', '', '', 'Account.8100', 'Основное производство', 'Role.Account.Production', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.8110', 'Account.8100', 'Slice.Accounting', '', '', 'Account.8110', 'Основное производство', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.8200', 'Account.8', 'Slice.Norm', '', '', 'Account.8200', 'Полуфабрикаты собственного производства', 'Role.Account.Production', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.8210', 'Account.8200', 'Slice.Accounting', '', '', 'Account.8210', 'Полуфабрикаты собственного производства', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.8300', 'Account.8', 'Slice.Norm', '', '', 'Account.8300', 'Вспомогательные производства', 'Role.Account.Production', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.8310', 'Account.8300', 'Slice.Accounting', '', '', 'Account.8310', 'Вспомогательные производства', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.8400', 'Account.8', 'Slice.Norm', '', '', 'Account.8400', 'Накладные расходы', 'Role.Account.Production', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.8410', 'Account.8400', 'Slice.Accounting', '', '', 'Account.8410', 'Накладные расходы', '', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.9', 'Account.', 'Slice.Fact', '', '', 'Account.9', 'Забалансовые активы', 'Role.Account.Group1Level', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.', '', 'Slice.Accounting', '', '', 'Account.', 'AccountData', 'Role.Entity.Account', 'Sign.Acct.Dt-Ct', '{"AbcBasic": "Account.Basic"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.AcctTable2019', 'Account.', 'Slice.Norm', '', '', 'Account.AcctTable2019', 'Account Table 2019', 'Role.AccTable.2019', 'Sign.Acct.Dt-Ct', '{"AbcBasic": "Account.Basic","AbcTable": "Account.Table"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.Work', 'Account.', 'Slice.Norm', '', '', 'Account.Work', 'Work', 'Role.AccTable.Work', 'Sign.Acct.Dt-Ct', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog","AbcTable": "Account.Table"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.Asset', 'Account.Work', 'Slice.Norm', '', '', 'Account.Asset', 'ТМЦ', 'Role.Account.Asset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.AssetBio', 'Account.Asset', 'Slice.Norm', '', '', 'Account.AssetBio', 'Биоактив', 'Role.Account.Asset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.AssetCoverall', 'Account.Asset', 'Slice.Norm', '', '', 'Account.AssetCoverall', 'Спецодежда', 'Role.Account.Asset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.AssetGood', 'Account.Asset', 'Slice.Norm', '', '', 'Account.AssetGood', 'Товар', 'Role.Account.Asset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.AssetIntangible', 'Account.Asset', 'Slice.Norm', '', '', 'Account.AssetIntangible', 'НМА', 'Role.Account.Asset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.AssetMaterial', 'Account.Asset', 'Slice.Norm', '', '', 'Account.AssetMaterial', 'Материал', 'Role.Account.Asset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.AssetMortgage', 'Account.Asset', 'Slice.Norm', '', '', 'Account.AssetMortgage', 'Залоговое имущество', 'Role.Account.Asset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.AssetProduction', 'Account.Asset', 'Slice.Norm', '', '', 'Account.AssetProduction', 'Продукция', 'Role.Account.Production', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.AssetTool', 'Account.Asset', 'Slice.Norm', '', '', 'Account.AssetTool', 'Инструмент', 'Role.Account.Asset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.AssetUnfinishedProduction', 'Account.Asset', 'Slice.Norm', '', '', 'Account.AssetUnfinishedProduction', 'Незавершенная продукция', 'Role.Account.Production', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.Customer', 'Account.Work', 'Slice.Norm', '', '', 'Account.Customer', 'Покупатель', 'Role.Account.Face', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.CustomerPrepaid', 'Account.Customer', 'Slice.Norm', '', '', 'Account.CustomerPrepaid', 'Предоплата покупателя', 'Role.Account.Face', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.Equity', 'Account.Work', 'Slice.Norm', '', '', 'Account.Equity', 'Капитал', 'Role.Account.Capital', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.Expense', 'Account.Work', 'Slice.Norm', '', '', 'Account.Expense', 'Расходы', 'Role.Account.Budget', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.ExpenseCost', 'Account.Expense', 'Slice.Norm', '', '', 'Account.ExpenseCost', 'Себестоимость', 'Role.Account.Budget', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.ExpenseGeneral', 'Account.Expense', 'Slice.Norm', '', '', 'Account.ExpenseGeneral', 'Общие адм расходы', 'Role.Account.Budget', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.ExpenseOther', 'Account.Expense', 'Slice.Norm', '', '', 'Account.ExpenseOther', 'Прочие расходы', 'Role.Account.Budget', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.ExpenseSell', 'Account.Expense', 'Slice.Norm', '', '', 'Account.ExpenseSell', 'Расходы по реализации', 'Role.Account.Budget', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.ExpenseSellOut', 'Account.Expense', 'Slice.Norm', '', '', 'Account.ExpenseSellOut', 'Внереализационные расходы', 'Role.Account.Budget', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.FixedAsset', 'Account.Work', 'Slice.Norm', '', '', 'Account.FixedAsset', 'Основные средства', 'Role.Account.FixedAsset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.FixedAssetBuilding', 'Account.FixedAsset', 'Slice.Norm', '', '', 'Account.FixedAssetBuilding', 'Здания', 'Role.Account.FixedAsset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.FixedAssetCar', 'Account.FixedAsset', 'Slice.Norm', '', '', 'Account.FixedAssetCar', 'Автотранспорт', 'Role.Account.FixedAsset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.FixedAssetDepreciation', 'Account.FixedAsset', 'Slice.Norm', '', '', 'Account.FixedAssetDepreciation', 'Амортизация', 'Role.Account.Depreciation', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.FixedAssetFurniture', 'Account.FixedAsset', 'Slice.Norm', '', '', 'Account.FixedAssetFurniture', 'Мебель', 'Role.Account.FixedAsset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.FixedAssetLand', 'Account.FixedAsset', 'Slice.Norm', '', '', 'Account.FixedAssetLand', 'Земля', 'Role.Account.FixedAsset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.FixedAssetMachine', 'Account.FixedAsset', 'Slice.Norm', '', '', 'Account.FixedAssetMachine', 'Машинное оборудование', 'Role.Account.FixedAsset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.FixedAssetOfficeEquipment', 'Account.FixedAsset', 'Slice.Norm', '', '', 'Account.FixedAssetOfficeEquipment', 'Офисное оборудование', 'Role.Account.FixedAsset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.FixedAssetOther', 'Account.FixedAsset', 'Slice.Norm', '', '', 'Account.FixedAssetOther', 'Прочие ОС', 'Role.Account.FixedAsset', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.FixedAssetUnfinishedConstruction', 'Account.Work', 'Slice.Norm', '', '', 'Account.FixedAssetUnfinishedConstruction', 'Незавершенное строительство', 'Role.Account.Production', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.Imprest', 'Account.Work', 'Slice.Norm', '', '', 'Account.Imprest', 'Авансы сотрудников', 'Role.Account.Face', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.Income', 'Account.Work', 'Slice.Norm', '', '', 'Account.Income', 'Доходы', 'Role.Account.Budget', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.IncomeLossNet', 'Account.Income', 'Slice.Norm', '', '', 'Account.IncomeLossNet', 'Чистая прибыль (убыток)', 'Role.Account.Budget', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.IncomeOther', 'Account.Income', 'Slice.Norm', '', '', 'Account.IncomeOther', 'Прочие доходы', 'Role.Account.Budget', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.IncomeSell', 'Account.Income', 'Slice.Norm', '', '', 'Account.IncomeSell', 'Выручка', 'Role.Account.Budget', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.IncomeSellOut', 'Account.Income', 'Slice.Norm', '', '', 'Account.IncomeSellOut', 'Внереализационные доходы', 'Role.Account.Budget', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.Money', 'Account.Work', 'Slice.Norm', '', '', 'Account.Money', 'Деньги', 'Role.Account.Money', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.MoneyBank', 'Account.Money', 'Slice.Norm', '', '', 'Account.MoneyBank', 'Банк', 'Role.Account.Money', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.MoneyCash', 'Account.Money', 'Slice.Norm', '', '', 'Account.MoneyCash', 'Касса', 'Role.Account.Money', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.MoneyTransit', 'Account.Money', 'Slice.Norm', '', '', 'Account.MoneyTransit', 'Деньги в пути', 'Role.Account.Money', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.Salary', 'Account.Work', 'Slice.Norm', '', '', 'Account.Salary', 'Зарплата', 'Role.Account.Salary', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.SalaryDeduction', 'Account.Salary', 'Slice.Norm', '', '', 'Account.SalaryDeduction', 'Удержания из зарплаты', 'Role.Account.Other', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.Seller', 'Account.Work', 'Slice.Norm', '', '', 'Account.Seller', 'Продавец', 'Role.Account.Face', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.SellerPrepaid', 'Account.Seller', 'Slice.Norm', '', '', 'Account.SellerPrepaid', 'Предоплата продавцу', 'Role.Account.Face', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.Tax', 'Account.Work', 'Slice.Norm', '', '', 'Account.Tax', 'Налог', 'Role.Account.Tax', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.TaxAlimony', 'Account.Tax', 'Slice.Norm', '', '', 'Account.TaxAlimony', 'Алименты', 'Role.Account.Tax', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.TaxCar', 'Account.Tax', 'Slice.Norm', '', '', 'Account.TaxCar', 'Налог на транспорт', 'Role.Account.Tax', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.TaxExcise', 'Account.Tax', 'Slice.Norm', '', '', 'Account.TaxExcise', 'Акциз', 'Role.Account.Tax', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.TaxGFSS', 'Account.Tax', 'Slice.Norm', '', '', 'Account.TaxGFSS', 'ГФСС', 'Role.Account.Tax', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.TaxIncome', 'Account.Tax', 'Slice.Norm', '', '', 'Account.TaxIncome', 'КПН', 'Role.Account.Tax', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.TaxIncomePerson', 'Account.Tax', 'Slice.Norm', '', '', 'Account.TaxIncomePerson', 'ИПН', 'Role.Account.Tax', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.TaxLand', 'Account.Tax', 'Slice.Norm', '', '', 'Account.TaxLand', 'Налог на землю', 'Role.Account.Tax', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.TaxOSMSEmployeeFee', 'Account.Tax', 'Slice.Norm', '', '', 'Account.TaxOSMSEmployeeFee', 'ОСМС отчисления', 'Role.Account.Tax', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.TaxOSMSEmployeePay', 'Account.Tax', 'Slice.Norm', '', '', 'Account.TaxOSMSEmployeePay', 'ОСМС взносы', 'Role.Account.Tax', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.TaxOther', 'Account.Tax', 'Slice.Norm', '', '', 'Account.TaxOther', 'Прочие налоги, сборы, пошлины', 'Role.Account.Tax', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.TaxPension', 'Account.Tax', 'Slice.Norm', '', '', 'Account.TaxPension', 'ОПВ', 'Role.Account.Tax', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.TaxProperty', 'Account.Tax', 'Slice.Norm', '', '', 'Account.TaxProperty', 'Налог на имущество', 'Role.Account.Tax', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.TaxSN', 'Account.Tax', 'Slice.Norm', '', '', 'Account.TaxSN', 'СН', 'Role.Account.Tax', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.TaxVATIn', 'Account.Tax', 'Slice.Norm', '', '', 'Account.TaxVATIn', 'НДС входящий', 'Role.Account.Tax', 'Sign.Acc.Dt', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');
INSERT INTO Account (Id, Parent, Slice, Date1, Date2, Code, Description, Role, Sign, More) VALUES ('Account.TaxVATOut', 'Account.Tax', 'Slice.Norm', '', '', 'Account.TaxVATOut', 'НДС исходящий', 'Role.Account.Tax', 'Sign.Acc.Ct', '{"AbcBasic": "Account.Basic","AbcCatalog": "Account.Catalog"}');

-- Таблица: Asset
CREATE TABLE IF NOT EXISTS [Asset](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Asset(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Geo] TEXT references Geo(Id),
	[Role] TEXT references Role(Id),
	[Info] TEXT references Info(Id),
	[Unit] TEXT references Unit(Id),
	[More] TEXT
 );
INSERT INTO Asset (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, Unit, More) VALUES ('Asset.', '', '', '', 'Asset.', 'AssetData', '', 'Role.Entity.Asset-Unit', 'Info.Entity.Reference', 'Unit.Piece', '{"AbcBasic": "Asset.Basic"}');
INSERT INTO Asset (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, Unit, More) VALUES ('Asset.Money', 'Asset.', '', '', 'Asset.Money', 'Денежные средства', 'Geo.Qazaqstan', 'Role.Asset.Money', 'Info.Asset.Activ', 'Unit.CurrUnit', '{"FullName": "Денежные средства","AbcBasic": "Asset.Basic"}');

-- Таблица: Deal
CREATE TABLE IF NOT EXISTS [Deal](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Deal(Id),
	[Face1] TEXT references Face(Id),
	[Face2] TEXT references Face(Id),
	[Face] TEXT references Face(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Geo] TEXT references Geo(Id),
	[Role] TEXT references Role(Id),
	[Info] TEXT references Info(Id),
	[More] TEXT
 );
INSERT INTO Deal (Id, Parent, Face1, Face2, Face, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Deal.', '', '', '', '', '', '', 'Deal.', 'DealData', '', 'Role.Entity.Face-Deal', 'Info.Entity.Reference', '{"AbcBasic": "Deal.Basic"}');
INSERT INTO Deal (Id, Parent, Face1, Face2, Face, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Deal.Face.alimony', 'Deal.', '', '', 'Face.enbek', '', '', 'Deal.Face.alimony', 'алименты-МТиСЗН', 'Geo.Qazaqstan', 'Role.Deal.Frame', 'Info.Deal.Alimony', '{"AbcBasic": "Deal.Basic"}');
INSERT INTO Deal (Id, Parent, Face1, Face2, Face, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Deal.Face.enbek.staff', 'Deal.', '', '', 'Face.enbek', '', '', 'Deal.Face.enbek.staff', 'штатное расписание-МТиСЗН', 'Geo.Qazaqstan', 'Role.Deal.Frame', 'Info.Deal.MinistryLabor', '{"AbcBasic": "Deal.Basic"}');
INSERT INTO Deal (Id, Parent, Face1, Face2, Face, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Deal.Face.FA1.boss', 'Deal.enbek.staff', 'Face.FA1', '', '', '', '', 'Deal.Face.FA1.boss', 'директор', 'Geo.Qazaqstan', 'Role.Deal.Frame', 'Info.Deal.Staff', '{"AbcBasic": "Deal.Basic"}');
INSERT INTO Deal (Id, Parent, Face1, Face2, Face, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Deal.Face.GFSS', 'Deal.', '', '', 'Face.GCVP', '', '', 'Deal.Face.GFSS', 'ГФСС-НАО-ГЦВП', 'Geo.Qazaqstan', 'Role.Deal.Frame', 'Info.Deal.GSVP', '{"AbcBasic": "Deal.Basic"}');
INSERT INTO Deal (Id, Parent, Face1, Face2, Face, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Deal.Face.kgd.tax', 'Deal.', '', '', 'Face.kgd', '', '', 'Deal.Face.kgd.tax', 'налоги-КГД', 'Geo.Qazaqstan', 'Role.Deal.Frame', 'Info.Deal.GSVP', '{"AbcBasic": "Deal.Basic"}');
INSERT INTO Deal (Id, Parent, Face1, Face2, Face, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Deal.Face.OPV', 'Deal.', '', '', 'Face.GCVP', '', '', 'Deal.Face.OPV', 'ОПВ-НАО-ГЦВП', 'Geo.Qazaqstan', 'Role.Deal.Frame', 'Info.Deal.GSVP', '{"AbcBasic": "Deal.Basic"}');
INSERT INTO Deal (Id, Parent, Face1, Face2, Face, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Deal.Face.OSGPOR', 'Deal.', '', '', 'Face.enbek', '', '', 'Deal.Face.OSGPOR', 'ОСГПОР', 'Geo.Qazaqstan', 'Role.Deal.Frame', 'Info.Deal.MinistryLabor', '{"AbcBasic": "Deal.Basic"}');
INSERT INTO Deal (Id, Parent, Face1, Face2, Face, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Deal.Face.OSMS', 'Deal.', '', '', 'Face.GCVP', '', '', 'Deal.Face.OSMS', 'ОСМС-НАО-ГЦВП', 'Geo.Qazaqstan', 'Role.Deal.Frame', 'Info.Deal.GSVP', '{"AbcBasic": "Deal.Basic"}');

-- Таблица: Debt
CREATE TABLE IF NOT EXISTS [Debt](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Debt(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Geo] TEXT references Geo(Id),
	[Role] TEXT references Role(Id),
	[Info] TEXT references Info(Id),
	[More] TEXT
  );
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.', '', '', '', 'Debt.', 'DebtData', '', 'Role.Entity.Tax-Face', 'Info.Entity.Reference', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Custom', 'Debt.', '', '', 'Debt.Custom', 'Таможенные платежи', 'Geo.Qazaqstan', 'Role.TaxDetail.InputSell', 'Info.Tax.FactReportingCycle', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Custom.Base', 'Debt.Custom', '', '', 'Debt.Custom.Base', 'База ТП', 'Geo.Qazaqstan', 'Role.TaxBase.ImportNetto', 'Info.Tax.FactBillingCycle', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Custom.Duty', 'Debt.Custom', '', '', 'Debt.Custom.Duty', 'Таможенная пошлина', 'Geo.Qazaqstan', 'Role.Entity.Purchase', 'Info.Tax.FactReportingCycle', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Custom.Fee', 'Debt.Custom', '', '', 'Debt.Custom.Fee', 'Таможенный сбор', 'Geo.Qazaqstan', 'Role.Entity.Purchase', 'Info.Tax.FactReportingCycle', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.DeductionSalary', 'Debt.', '', '', 'Debt.DeductionSalary', 'Удержания из зарплаты', 'Geo.Qazaqstan', 'Role.TaxBase.SalaryBrutto', 'Info.Tax.FactBillingCycle', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.DeductionSalary.Alimony', 'Debt.DeductionSalary', '', '', 'Debt.DeductionSalary.Alimony', 'Алименты', 'Geo.Qazaqstan', 'Role.Entity.SalarySheet', 'Info.Deal.Alimony', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.DeductionSalary.Alimony.Rate1', 'Debt.DeductionSalary.Alimony', '', '', 'Debt.DeductionSalary.Alimony.Rate1', 'Ставка алиментов1 (на 1 ребенка)', 'Geo.Qazaqstan', 'Role.Generic.Basic', 'Info.Tax.RateBasic', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.DeductionSalary.Alimony.Rate2', 'Debt.DeductionSalary.Alimony', '', '', 'Debt.DeductionSalary.Alimony.Rate2', 'Ставка алиментов2 (на 2 детей)', 'Geo.Qazaqstan', 'Role.Generic.Variant', 'Info.Tax.RateBasic', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.DeductionSalary.Alimony.Rate3', 'Debt.DeductionSalary.Alimony', '', '', 'Debt.DeductionSalary.Alimony.Rate3', 'Ставка алиментов3 (на 3 и более детей)', 'Geo.Qazaqstan', 'Role.Generic.Variant', 'Info.Tax.RateBasic', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.DeductionSalary.Other', 'Debt.DeductionSalary', '', '', 'Debt.DeductionSalary.Other', 'Прочие удержания', 'Geo.Qazaqstan', 'Role.Entity.Entry', 'Info.Deal.Staff', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Depreciation', 'Debt.', '', '', 'Debt.Depreciation', 'Амортизация', 'Geo.Qazaqstan', 'Role.Entity.Entry', 'Info.Store.CoreFund', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Depreciation.Base', 'Debt.Depreciation', '', '', 'Debt.Depreciation.Base', 'База амортизации', 'Geo.Qazaqstan', 'Role.TaxBase.FixedAssetNetto', 'Info.Generic.Basic', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.DepreciationAccounting', 'Debt.Depreciation', '', '', 'Debt.DepreciationAccounting', 'Ам-я бухгалтерская', 'Geo.Qazaqstan', 'Role.TaxDetail.DepreciationLineMonth', 'Info.Tax.MonthBillingCycle', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.DepreciationAccounting.Rate', 'Debt.DepreciationAccounting', '', '', 'Debt.DepreciationAccounting.Rate', 'Ставка аморт-и бухгалтерской', 'Geo.Qazaqstan', 'Role.Generic.Basic', 'Info.Tax.RateBasic', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.DepreciationTax', 'Debt.Depreciation', '', '', 'Debt.DepreciationTax', 'Ам-я налоговая', 'Geo.Qazaqstan', 'Role.TaxDetail.DepreciationYearTax', 'Info.Tax.YearReportingCycle', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.DepreciationTax.Rate', 'Debt.DepreciationTax', '', '', 'Debt.DepreciationTax.Rate', 'Ставка аморт-и налоговой', 'Geo.Qazaqstan', 'Role.Generic.Basic', 'Info.Tax.RateBasic', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.ExchangeDifference', 'Debt.', '', '', 'Debt.ExchangeDifference', 'Курсовая разница', 'Geo.Qazaqstan', 'Role.TaxBase.ExchangeRateDelta', 'Info.Tax.FactBillingCycle', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.ExchangeDifference.Advance', 'Debt.ExchangeDifference', '', '', 'Debt.ExchangeDifference.Advance', 'КР на авансы', 'Geo.Qazaqstan', 'Role.TaxDetail.ExcRateDeltaOne', 'Info.ExchangeRate.Stock', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.ExchangeDifference.Purchase', 'Debt.ExchangeDifference', '', '', 'Debt.ExchangeDifference.Purchase', 'КР при покупке валюты', 'Geo.Qazaqstan', 'Role.TaxDetail.ExcRateDeltaTwo', 'Info.ExchangeRate.Bank', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.GFSS', 'Debt.', '', '', 'Debt.GFSS', 'ГФСС', 'Geo.Qazaqstan', 'Role.Entity.SalarySheet', 'Info.Tax.QuarterReportingCycle', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.GFSS.Base', 'Debt.GFSS', '', '', 'Debt.GFSS.Base', 'База ГФСС', 'Geo.Qazaqstan', 'Role.TaxBase.SalaryBrutto', 'Info.Tax.MonthBillingCycle', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.GFSS.KNP.012', 'Debt.GFSS', '', '', 'Debt.GFSS.KNP.012', '012 - обяз соц отчисления', 'Geo.Qazaqstan', 'Role.Entity.PayOrder', 'Info.Code.KNP', '{"FullName": "Обязательные социальные отчисления","AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.GFSS.Rate', 'Debt.GFSS', '', '', 'Debt.GFSS.Rate', 'Ставка ГФСС', 'Geo.Qazaqstan', 'Role.Generic.Basic', 'Info.Tax.RateBasic', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.IncomePerson', 'Debt.', '', '', 'Debt.IncomePerson', 'Индивидуальный подоходный налог', 'Geo.Qazaqstan', 'Role.Entity.SalarySheet', 'Info.Tax.QuarterReportingCycle', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.IncomePerson.Base', 'Debt.IncomePerson', '', '', 'Debt.IncomePerson.Base', 'База ИПН', 'Geo.Qazaqstan', '', 'Info.Tax.MonthBillingCycle', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.IncomePerson.Base.Deduction.Standard', 'Debt.IncomePerson.Base', '', '', 'Debt.IncomePerson.Base.Deduction.Standard', 'Стандартный вычет из базы ИПН', 'Geo.Qazaqstan', 'Role.Generic.Basic', 'Info.Tax.Deduction.Standard', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.IncomePerson.Base.Deduction.OPV', 'Debt.IncomePerson.Base', '', '', 'Debt.IncomePerson.Base.Deduction.OPV', 'Вычет ОПВ из базы ИПН', 'Geo.Qazaqstan', 'Role.Generic.Basic', 'Info.Tax.Deduction.OPV', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.IncomePerson.KBK.101201', 'Debt.IncomePerson', '', '', 'Debt.IncomePerson.KBK.101201', '101201 - ИПН с доходов, облагаемых у ист выпл', 'Geo.Qazaqstan', 'Role.Entity.PayOrder', 'Info.Code.KBK', '{"FullName": "Индивидуальный подоходный налог с доходов, облагаемых у источника выплаты","AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.IncomePerson.RateBasic', 'Debt.IncomePerson', '', '', 'Debt.IncomePerson.RateBasic', 'Ставка ИПН', 'Geo.Qazaqstan', '', 'Info.Tax.RateBasic', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Income', 'Debt.', '', '', 'Debt.Income', 'Корпоративный подоходный налог', 'Geo.Qazaqstan', '', 'Info.Tax.YearReportingCycle', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Income.Base', 'Debt.Income', '', '', 'Debt.Income.Base', 'База КПН', 'Geo.Qazaqstan', 'Role.TaxBase.SellNetto', '', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Income.KBK.101110', 'Debt.Income', '', '', 'Debt.Income.KBK.101110', '101110 - КПН с ЮЛ, кроме нефт сект', 'Geo.Qazaqstan', 'Role.Entity.PayOrder', 'Info.Code.KBK', '{"FullName": "Корпоративный подоходный налог с юридических лиц, за исключением поступлений от организаций нефтяного сектора","AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.OSMS', 'Debt.', '', '', 'Debt.OSMS', 'ОСМС', 'Geo.Qazaqstan', 'Role.Entity.PaySheet', '', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.OSMS.Base', 'Debt.OSMS', '', '', 'Debt.OSMS.Base', 'База ОСМС', 'Geo.Qazaqstan', 'Role.TaxBase.SalaryBrutto', '', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.OSMS.EmployeePay', 'Debt.OSMS', '', '', 'Debt.OSMS.EmployeePay', 'Взносы ОСМС', 'Geo.Qazaqstan', '', 'Info.Tax.QuarterReportingCycle', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.OSMS.EmployeePay.RateBasic', 'Debt.OSMS.EmployeePay', '', '', 'Debt.OSMS.EmployeePay.RateBasic', 'Осн ставка взносов ОСМС', 'Geo.Qazaqstan', '', 'Info.Tax.RateBasic', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.OSMS.EmployerFee', 'Debt.OSMS', '', '', 'Debt.OSMS.EmployerFee', 'Отчисления ОСМС', 'Geo.Qazaqstan', '', 'Info.Tax.QuarterReportingCycle', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.OSMS.EmployerFee.RateBasic', 'Debt.OSMS.EmployerFee', '', '', 'Debt.OSMS.EmployerFee.RateBasic', 'Ставка отчислений ОСМС', 'Geo.Qazaqstan', '', 'Info.Tax.RateBasic', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Pension', 'Debt.', '', '', 'Debt.Pension', 'Пенсионные платежи', 'Geo.Qazaqstan', 'Role.Entity.PaySheet', '', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Pension.Base', 'Debt.Pension', '', '', 'Debt.Pension.Base', 'База пенсионных платежей', 'Geo.Qazaqstan', 'Role.TaxBase.SalaryBrutto', '', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Pension.OPPV', 'Debt.Pension', '', '', 'Debt.Pension.OPPV', 'Обязательные проф пенс взносы', 'Geo.Qazaqstan', '', '', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Pension.OPV', 'Debt.Pension', '', '', 'Debt.Pension.OPV', 'ОПВ', 'Geo.Qazaqstan', '', 'Info.Tax.QuarterReportingCycle', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Pension.OPV.KNP.010', 'Debt.Pension.OPV', '', '', 'Debt.Pension.OPV.KNP.010', '010 - обяз пенс взносы', 'Geo.Qazaqstan', 'Role.Entity.PayOrder', 'Info.Code.KNP', '{"FullName": "Обязательные пенсионные взносы","AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Pension.OPV.RateBasic', 'Debt.Pension.OPV', '', '', 'Debt.Pension.OPV.RateBasic', 'Осн ставка ОПВ', 'Geo.Qazaqstan', '', 'Info.Tax.RateBasic', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Pension.OPVR', 'Debt.Pension', '', '', 'Debt.Pension.OPVR', 'ОПВ работодателя', 'Geo.Qazaqstan', '', '', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Salary', 'Debt.', '', '', 'Debt.Salary', 'Оплата труда', 'Geo.Qazaqstan', '', '', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Salary.Commission', 'Debt.Salary', '', '', 'Debt.Salary.Commission', 'Комиссионные', 'Geo.Qazaqstan', '', '', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Salary.Extra', 'Debt.Salary', '', '', 'Debt.Salary.Extra', 'Премия', 'Geo.Qazaqstan', '', '', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Salary.Main', 'Debt.Salary', '', '', 'Debt.Salary.Main', 'Оклад', 'Geo.Qazaqstan', '', '', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Salary.Other', 'Debt.Salary', '', '', 'Debt.Salary.Other', 'Прочие начисления', 'Geo.Qazaqstan', '', '', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Salary.VacationCompensation', 'Debt.Salary', '', '', 'Debt.Salary.VacationCompensation', 'Компенсация отпуск', 'Geo.Qazaqstan', '', '', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Salary.VacationPay', 'Debt.Salary', '', '', 'Debt.Salary.VacationPay', 'Отпускные', 'Geo.Qazaqstan', '', '', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.SN', 'Debt.', '', '', 'Debt.SN', 'Социальный налог', 'Geo.Qazaqstan', '', 'Info.Tax.QuarterReportingCycle', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.SN.Base', 'Debt.SN', '', '', 'Debt.SN.Base', 'База СН', 'Geo.Qazaqstan', 'Role.TaxBase.SalaryBrutto', '', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.SN.KBK.103101', 'Debt.SN', '', '', 'Debt.SN.KBK.103101', '103101 - соц налог', 'Geo.Qazaqstan', 'Role.Entity.PayOrder', 'Info.Code.KBK', '{"FullName": "Социальный налог","AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.SN.Rate', 'Debt.SN', '', '', 'Debt.SN.Rate', 'Ставка СН', 'Geo.Qazaqstan', '', 'Info.Tax.RateBasic', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.SN.SNMinusGFSS', 'Debt.SN', '', '', 'Debt.SN.SNMinusGFSS', 'Корректировка СН на ГФСС', 'Geo.Qazaqstan', '', 'Info.Tax.SNMinusGFSS', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.VAT', 'Debt.', '', '', 'Debt.VAT', 'НДС', 'Geo.Qazaqstan', '', 'Info.Tax.QuarterReportingCycle', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.VAT.Base', 'Debt.VAT', '', '', 'Debt.VAT.Base', 'База НДС', 'Geo.Qazaqstan', 'Role.TaxBase.SellNetto', '', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.VAT.Import', 'Debt.VAT', '', '', 'Debt.VAT.Import', 'НДС импорта', 'Geo.Qazaqstan', '', 'Info.Tax.QuarterReportingCycle', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.VAT.Import.Base', 'Debt.VAT.Import', '', '', 'Debt.VAT.Import.Base', 'База НДС импорта', 'Geo.Qazaqstan', 'Role.TaxBase.ImportNetto', 'Info.Tax.Base', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.VAT.Import.RateBasic', 'Debt.VAT.Import', '', '', 'Debt.VAT.Import.RateBasic', 'Осн ставка НДС импорта', 'Geo.Qazaqstan', 'Role.Generic.Basic', 'Info.Tax.RateBasic', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.VAT.Purchase', 'Debt.VAT', '', '', 'Debt.VAT.Purchase', 'НДС зачета', 'Geo.Qazaqstan', 'Role.TaxDetail.InputSell', '', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.VAT.Purchase.RateBasic', 'Debt.VAT.Purchase', '', '', 'Debt.VAT.Purchase.RateBasic', 'Осн ставка НДС зачета', 'Geo.Qazaqstan', 'Role.Generic.Basic', 'Info.Tax.RateMain', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.VAT.Purchase.RateReduce', 'Debt.VAT.Purchase', '', '', 'Debt.VAT.Purchase.RateReduce', 'Сниженная ставка НДС зачета', 'Geo.Qazaqstan', 'Role.Generic.Variant', 'Info.Tax.RateReduce', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.VAT.Sell', 'Debt.VAT', '', '', 'Debt.VAT.Sell', 'НДС реализации', 'Geo.Qazaqstan', 'Role.TaxDetail.OutputSell', '', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.VAT.Sell.KBK.105101', 'Debt.VAT.Sell', '', '', 'Debt.VAT.Sell.KBK.105101', '105101 - НДС на ТРУ на терр РК', 'Geo.Qazaqstan', 'Role.Entity.PayOrder', 'Info.Code.KBK', '{"FullName": "НДС на произведенные товары, выполненные работы и оказанные услуги на территории РК","AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.VAT.Sell.RateFree', 'Debt.VAT.Sell', '', '', 'Debt.VAT.Sell.RateFree', 'Осв ставка НДС реализации', 'Geo.Qazaqstan', 'Role.Generic.Variant', 'Info.Tax.RateFree', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.VAT.Sell.RateBasic', 'Debt.VAT.Sell', '', '', 'Debt.VAT.Sell.RateBasic', 'Осн ставка НДС реализации', 'Geo.Qazaqstan', 'Role.Generic.Basic', 'Info.Tax.RateBasic', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.VAT.Sell.RateReduce', 'Debt.VAT.Sell', '', '', 'Debt.VAT.Sell.RateReduce', 'Сниженная ставка НДС реализации', 'Geo.Qazaqstan', 'Role.Generic.Variant', 'Info.Tax.RateReduce', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.VAT.Sell.RateZero', 'Debt.VAT.Sell', '', '', 'Debt.VAT.Sell.RateZero', 'Нулевая ставка НДС реализации', 'Geo.Qazaqstan', 'Role.Generic.Variant', 'Info.Tax.RateZero', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Car', 'Debt.', '', '', 'Debt.Car', 'Налог на транспортные средства', 'Geo.Qazaqstan', '', '', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Car.KBK.104401', 'Debt.Car', '', '', 'Debt.Car.KBK.104401', '104401 - НТС с ЮЛ', 'Geo.Qazaqstan', 'Role.Entity.PayOrder', 'Info.Code.KBK', '{"FullName": "Налог на транспортные средства с юр лиц","AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Car.KBK.104402', 'Debt.Car', '', '', 'Debt.Car.KBK.104402', '104402 - НТС с ФЛ', 'Geo.Qazaqstan', 'Role.Entity.PayOrder', 'Info.Code.KBK', '{"FullName": "Налог на транспортные средства с физ лиц","AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Other', 'Debt.', '', '', 'Debt.Other', 'Плата за загрязнение окружающей среды', 'Geo.Qazaqstan', '', '', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Land', 'Debt.', '', '', 'Debt.Land', 'Земельный налог', 'Geo.Qazaqstan', '', '', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Property', 'Debt.', '', '', 'Debt.Property', 'Налог на имущество', 'Geo.Qazaqstan', '', '', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.VAT.Sell.RateLess', 'Debt.VAT.Sell', '', '', 'Debt.VAT.Sell.RateLess', 'Безналоговая ставка НДС реализации', 'Geo.Qazaqstan', 'Role.Generic.Variant', 'Info.Tax.RateLess', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.VAT.Purchase.RateLess', 'Debt.VAT.Purchase', '', '', 'Debt.VAT.Purchase.RateLess', 'Безналоговая ставка НДС зачета', 'Geo.Qazaqstan', 'Role.Generic.Variant', 'Info.Tax.RateLess', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.VAT.Purchase.RateFree', 'Debt.VAT.Purchase', '', '', 'Debt.VAT.Purchase.RateFree', 'Осв ставка НДС зачета', 'Geo.Qazaqstan', 'Role.Generic.Variant', 'Info.Tax.RateFree', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.VAT.Purchase.RateZero', 'Debt.VAT.Purchase', '', '', 'Debt.VAT.Purchase.RateZero', 'Нулевая ставка НДС зачета', 'Geo.Qazaqstan', 'Role.Generic.Variant', 'Info.Tax.RateZero', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.DeductionSalary.Alimony.Base', 'Debt.DeductionSalary.Alimony', '', '', 'Debt.DeductionSalary.Alimony.Base', 'База алиментов', 'Geo.Qazaqstan', 'Role.TaxBase.SalaryBrutto', 'Info.Tax.Base', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.IncomePerson.RateForeigner', 'Debt.IncomePerson', '', '', 'Debt.IncomePerson.RateForeigner', 'Ставка ИПН для нерезидентов', 'Geo.Qazaqstan', 'Role.TaxMode.Foreigner', 'Info.Tax.RateBasic', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Pension.OPV.RateZero', 'Debt.Pension.OPV', '', '', 'Debt.Pension.OPV.RateZero', 'Ставка ОПВ нулевая', 'Geo.Qazaqstan', '', 'Info.Tax.RateZero', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.Pension.Base.MaxLimit', 'Debt.Pension.Base', '', '', 'Debt.Pension.Base.MaxLimit', 'Макс лимит базы ОПВ', 'Geo.Qazaqstan', '', 'Info.Tax.BaseLimit', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.GFSS.Base.MaxLimit', 'Debt.GFSS.Base', '', '', 'Debt.GFSS.Base.MaxLimit', 'Макс лимит базы ГФСС', 'Geo.Qazaqstan', '', 'Info.Tax.BaseLimit', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.OSMS.Base.MaxLimit', 'Debt.OSMS.Base', '', '', 'Debt.OSMS.Base.MaxLimit', 'Макс лимит базы ОСМС', 'Geo.Qazaqstan', '', 'Info.Tax.BaseLimit', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.OSMS.Base.MinLimit', 'Debt.OSMS.Base', '', '', 'Debt.OSMS.Base.MinLimit', 'Мин лимит базы ОСМС', 'Geo.Qazaqstan', '', 'Info.Tax.BaseLimit', '{"AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.DepreciationTax.Rate.Group1', 'Debt.DepreciationTax.Rate', '', '', 'Debt.DepreciationTax.Rate.Group1', 'Ставка аморт-и налоговой группа1', 'Geo.Qazaqstan', '', 'Info.Tax.RateBasic', '{"Role.Generic.FullName": "Здания, строения","AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.DepreciationTax.Rate.Group2', 'Debt.DepreciationTax.Rate', '', '', 'Debt.DepreciationTax.Rate.Group2', 'Ставка аморт-и налоговой группа2', 'Geo.Qazaqstan', '', 'Info.Tax.RateBasic', '{"Role.Generic.FullName": "Машины, оборудование","AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.DepreciationTax.Rate.Group3', 'Debt.DepreciationTax.Rate', '', '', 'Debt.DepreciationTax.Rate.Group3', 'Ставка аморт-и налоговой группа3', 'Geo.Qazaqstan', '', 'Info.Tax.RateBasic', '{"Role.Generic.FullName": "Офисное оборудование","AbcBasic": "Debt.Basic"}');
INSERT INTO Debt (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Debt.DepreciationTax.Rate.Group4', 'Debt.DepreciationTax.Rate', '', '', 'Debt.DepreciationTax.Rate.Group4', 'Ставка аморт-и налоговой группа4', 'Geo.Qazaqstan', '', 'Info.Tax.RateBasic', '{"Role.Generic.FullName": "Прочее","AbcBasic": "Debt.Basic"}');

-- Таблица: Face
CREATE TABLE IF NOT EXISTS [Face](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Face(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Geo] TEXT references Geo(Id),
	[Role] TEXT references Role(Id),
	[Info] TEXT references Info(Id),
	[More] TEXT
 );
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Face.enbek', 'Face.', '', '', 'Face.enbek', 'МТиСЗН РК', 'Geo.Qazaqstan', 'Role.Face.State', 'Info.Face.GovAgency', '{"AbcBasic": "Face.Basic"}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Face.FA1', 'Face.', '', '', 'Face.FA1', 'Лицо учета1', 'Geo.Astana', 'Role.Face.FA', 'Info.Profile.Basic', '{"AbcBasic": "Face.Basic"}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Face.FA1.AdmStaff', 'Face.FA1', '', '', 'Face.FA1.AdmStaff', 'Лицо учета1.АУП', '', 'Role.Store.Department', 'Info.Generic.Basic', '{"AbcBasic": "Face.Basic"}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Face.FA1.Bank1', 'Face.FA1', '', '', 'Face.FA1.Bank1', 'Лицо учета1.Банк1', '', 'Role.Store.Bank', 'Info.Generic.Basic', '{"AbcBasic": "Face.Basic"}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Face.FA1.Cash1', 'Face.FA1', '', '', 'Face.FA1.Cash1', 'Лицо учета1.Касса1', '', 'Role.Store.Cash', 'Info.Generic.Basic', '{"AbcBasic": "Face.Basic"}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Face.FA1.StaffTable', 'Face.FA1', '', '', 'Face.FA1.StaffTable', 'Лицо учета1.штатное расписание', '', 'Role.StaffTable.5day', 'Info.Generic.Basic', '{"AbcBasic": "Face.Basic"}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Face.FA1.StaffTable.Boss', 'Face.FA1.StaffTable', '', '', 'Face.FA1.StaffTable.Boss', 'Лицо учета1.Директор', '', 'Role.Face.Staff', 'Info.Management.Boss', '{"AbcBasic": "Face.Basic"}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Face.FA1.StaffTable.ChiefAccountant', 'Face.FA1.StaffTable', '', '', 'Face.FA1.StaffTable.ChiefAccountant', 'Лицо учета1.Главный бухгалтер', '', 'Role.Face.Staff', 'Info.Management.Boss', '{"AbcBasic": "Face.Basic"}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Face.FA1.Store1', 'Face.FA1', '', '', 'Face.FA1.Store1', 'Лицо учета1.Склад1', 'Geo.Astana', 'Role.Store.Basic', 'Info.Generic.Basic', '{"AbcBasic": "Face.Basic"}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Face.FA1.User1', 'Face.FA1.AdmStaff', '', '', 'Face.FA1.User1', 'Лицо учета1.User1', '', 'Role.Generic.Basic', 'Info.Face.User', '{"AbcBasic": "Face.Basic"}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Face.', '', '', '', 'Face.', 'FaceData', '', 'Role.Entity.Face-Deal', 'Info.Entity.Reference', '{"AbcBasic": "Face.Basic"}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Face.GCVP', 'Face.', '', '', 'Face.GCVP', 'GCVPKZ2A', 'Geo.Qazaqstan', 'Role.Face.GCVP', 'Info.Face.GovAgency', '{"FullName": "НАО Государственная корпорация Правительство для граждан","BIN": "160440007161","BIC": "GCVPKZ2A","AbcBasic": "Face.Basic"}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Face.GCVP-GFSS.Bank1', 'Face.GCVP', '', '', 'Face.GCVP-GFSS.Bank1', 'GCVPKZ2A.KZ67009SS00368609110', '', 'Role.Store.Bank', 'Info.Deal.GFSS', '{"IBAN": "KZ67009SS00368609110","AbcBasic": "Face.Basic"}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Face.GCVP-OPV.Bank1', 'Face.GCVP', '', '', 'Face.GCVP-OPV.Bank1', 'GCVPKZ2A.KZ12009NPS0413609816', '', 'Role.Store.Bank', 'Info.Tax.Deduction.OPV', '{"IBAN": "KZ12009NPS0413609816","AbcBasic": "Face.Basic"}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Face.GCVP-OSMS.Bank1', 'Face.GCVP', '', '', 'Face.GCVP-OSMS.Bank1', 'GCVPKZ2A.KZ92009MEDS368609103', '', 'Role.Store.Bank', 'Info.Deal.OSMS', '{"IBAN": "KZ92009MEDS368609103","AbcBasic": "Face.Basic"}');
INSERT INTO Face (Id, Parent, Date1, Date2, Code, Description, Geo, Role, Info, More) VALUES ('Face.kgd', 'Face.', '', '', 'Face.kgd', 'КГД', 'Geo.Qazaqstan', 'Role.Face.State', 'Info.Face.GovAgency', '{"FullName": "Комитет государственных доходов","AbcBasic": "Face.Basic"}');

-- Таблица: Geo
CREATE TABLE IF NOT EXISTS [Geo](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Geo(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
    [Role] TEXT references Role(Id),
	[Unit] TEXT references Unit(Id),
	[More] TEXT
 );
INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Role, Unit, More) VALUES ('Geo.', '', '', '', 'Geo.', 'GeoData', 'Role.Entity.Country-Currency', '', '{"AbcBasic": "Geo.Basic"}');
INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Role, Unit, More) VALUES ('Geo.Almaty', 'Geo.Qazaqstan', '', '', 'Geo.Almaty', 'Алматы', 'Role.Geo.City', '', '{"FullName": "Алматы","AbcBasic": "Geo.Basic"}');
INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Role, Unit, More) VALUES ('Geo.BE', 'Geo.', '', '', 'Geo.BE', 'РБ', 'Role.Geo.Country', '', '{"FullName": "Республика Беларусь","AbcBasic": "Geo.Basic"}');
INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Role, Unit, More) VALUES ('Geo.Ch', 'Geo.', '', '', 'Geo.Ch', 'КНР', 'Role.Geo.Country', '', '{"FullName": "Китайская Народная Республика","AbcBasic": "Geo.Basic"}');
INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Role, Unit, More) VALUES ('Geo.DE', 'Geo.', '', '', 'Geo.DE', 'ФРГ', 'Role.Geo.Country', '', '{"FullName": "Федеративная Республика Германия","AbcBasic": "Geo.Basic"}');
INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Role, Unit, More) VALUES ('Geo.EAEU', 'Geo.', '', '', 'Geo.EAEU', 'ЕАЭС', 'Role.Geo.Union', '', '{"FullName": "ЕАЭС","AbcBasic": "Geo.Basic"}');
INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Role, Unit, More) VALUES ('Geo.EU', 'Geo.', '', '', 'Geo.EU', 'ЕС', 'Role.Geo.Union', 'Unit.EUR', '{"FullName": "Европейский Союз","AbcBasic": "Geo.Basic"}');
INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Role, Unit, More) VALUES ('Geo.KG', 'Geo.', '', '', 'Geo.KG', 'Кыргызстан', 'Role.Geo.Country', '', '{"FullName": "Республика Кыргызстан","AbcBasic": "Geo.Basic"}');
INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Role, Unit, More) VALUES ('Geo.Astana', 'Geo.Qazaqstan', '', '', 'Geo.Astana', 'Астана', 'Role.Geo.City', '', '{"FullName": "Астана","AbcBasic": "Geo.Basic"}');
INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Role, Unit, More) VALUES ('Geo.OESD', 'Geo.', '', '', 'Geo.OESD', 'ОЭСР', 'Role.Geo.WorldOrg', '', '{"FullName": "ОЭСР","AbcBasic": "Geo.Basic"}');
INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Role, Unit, More) VALUES ('Geo.Qazaqstan', 'Geo.', '', '', 'Geo.Qazaqstan', 'РК', 'Role.Geo.Country', 'Unit.KZT', '{"FullName": "Республика Казахстан","AbcBasic": "Geo.Basic"}');
INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Role, Unit, More) VALUES ('Geo.RF', 'Geo.', '', '', 'Geo.RF', 'РФ', 'Role.Geo.Country', 'Unit.RUB', '{"FullName": "Российская Федерация","AbcBasic": "Geo.Basic"}');
INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Role, Unit, More) VALUES ('Geo.USA', 'Geo.', '', '', 'Geo.USA', 'США', 'Role.Geo.Country', 'Unit.USD', '{"FullName": "Соединенные Штаты Америки","AbcBasic": "Geo.Basic"}');
INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Role, Unit, More) VALUES ('Geo.UZ', 'Geo.', '', '', 'Geo.UZ', 'РУ', 'Role.Geo.Country', '', '{"FullName": "Республика Узбекистан","AbcBasic": "Geo.Basic"}');
INSERT INTO Geo (Id, Parent, Date1, Date2, Code, Description, Role, Unit, More) VALUES ('Geo.WTO', 'Geo.', '', '', 'Geo.WTO', 'ВТО', 'Role.Geo.WorldOrg', '', '{"FullName": "Всемирная торговая организация","AbcBasic": "Geo.Basic"}');

-- Таблица: Info
CREATE TABLE IF NOT EXISTS [Info](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Info(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[More] TEXT
 );
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.', '', '', '', 'Info.', 'InfoData', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Address', 'Info.', '', '', 'Info.Address', 'Address', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Address.Home', 'Info.Address', '', '', 'Info.Address.Home', 'домашний адрес', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Address.Law', 'Info.Address', '', '', 'Info.Address.Law', 'юридический адрес', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Address.Post', 'Info.Address', '', '', 'Info.Address.Post', 'почтовый адрес', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Address.Reg', 'Info.Address', '', '', 'Info.Address.Reg', 'адрес прописки (регистрации)', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Asset', 'Info.', '', '', 'Info.Asset', 'Asset', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Asset.Asset', 'Info.Asset', '', '', 'Info.Asset.Asset', 'актив', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Asset.Catalog', 'Info.Asset', '', '', 'Info.Asset.Catalog', 'каталог активов', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Asset.SubAsset', 'Info.Asset', '', '', 'Info.Asset.SubAsset', 'субактив', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Code', 'Info.', '', '', 'Info.Code', 'Code', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Code.Alfa3', 'Info.Code', '', '', 'Info.Code.Alfa3', 'альфа3 код', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Code.Art', 'Info.Code', '', '', 'Info.Code.Art', 'артикул', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Code.BIC', 'Info.Code', '', '', 'Info.Code.BIC', 'БИК (BIC)', '{"FullName": "Банковский идентификационный код","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Code.EAN', 'Info.Code', '', '', 'Info.Code.EAN', 'EAN код', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Code.IBAN', 'Info.Code', '', '', 'Info.Code.IBAN', 'IBAN (ИИК)', '{FullName": "IBAN","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Code.KBE', 'Info.Code', '', '', 'Info.Code.KBE', 'КБЕ', '{"FullName": "Код бенефициара","AbcBasic": "Info.Basic","AbcCodePay": "Tax.CodePay"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Code.KBK', 'Info.Code', '', '', 'Info.Code.KBK', 'КБК', '{"FullName": "Код бюджетной классификации","AbcBasic": "Info.Basic","AbcCodePay": "Tax.CodePay"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Code.KNP', 'Info.Code', '', '', 'Info.Code.KNP', 'КНП', '{"FullName": "Код назначения платежа","AbcBasic": "Info.Basic","AbcCodePay": "Tax.CodePay"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Code.KOF', 'Info.Code', '', '', 'Info.Code.KOF', 'код КОФ', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Code.KPVED', 'Info.Code', '', '', 'Info.Code.KPVED', 'код КПВЭД', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Code.MKEI', 'Info.Code', '', '', 'Info.Code.MKEI', 'код МКЕИ', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Code.OKPO', 'Info.Code', '', '', 'Info.Code.OKPO', 'код ОКПО', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Code.Post', 'Info.Code', '', '', 'Info.Code.Post', 'почтовый код РК', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Code.TNVED', 'Info.Code', '', '', 'Info.Code.TNVED', 'код ТНВЭД', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Code.VIN', 'Info.Code', '', '', 'Info.Code.VIN', 'VIN код', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Cost', 'Info.', '', '', 'Info.Cost', 'Cost', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Cost.Accounting', 'Info.Cost', '', '', 'Info.Cost.Accounting', 'бухгалтерская себестоимость', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Cost.Standard', 'Info.Cost', '', '', 'Info.Cost.Standard', 'нормативная (стандартная) себестоимость', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Cost.Store', 'Info.Cost', '', '', 'Info.Cost.Store', 'складская себестоимость', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Deal', 'Info.', '', '', 'Info.Deal', 'Deal', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Deal.Alimony', 'Info.Deal', '', '', 'Info.Deal.Alimony', 'алименты', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Deal.ContractWork', 'Info.Deal', '', '', 'Info.Deal.ContractWork', 'подрядные работы', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Deal.GFSS', 'Info.Deal', '', '', 'Info.Deal.GFSS', 'ГФСС', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Deal.GSVP', 'Info.Deal', '', '', 'Info.Deal.GSVP', 'НАО-ГЦВП', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Deal.Loan', 'Info.Deal', '', '', 'Info.Deal.Loan', 'займ, кредит', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Deal.Basic', 'Info.Deal', '', '', 'Info.Deal.Basic', 'купля-продажа', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Deal.MinistryLabor', 'Info.Deal', '', '', 'Info.Deal.MinistryLabor', 'МТиСЗН', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Deal.OSMS', 'Info.Deal', '', '', 'Info.Deal.OSMS', 'ОСМС', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Deal.ProductionOrder', 'Info.Deal', '', '', 'Info.Deal.ProductionOrder', 'заказ производства', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Deal.Rent', 'Info.Deal', '', '', 'Info.Deal.Rent', 'аренда', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Deal.Staff', 'Info.Deal', '', '', 'Info.Deal.Staff', 'трудовой', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Entity', 'Info.', '', '', 'Info.Entity', 'Entity', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Entity.Doc', 'Info.Entity', '', '', 'Info.Entity.Doc', 'документ-журнал', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Entity.Journal', 'Info.Entity', '', '', 'Info.Entity.Journal', 'журнал документов', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Entity.MainForm', 'Info.Entity', '', '', 'Info.Entity.MainForm', 'основная входная форма', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Entity.Reference', 'Info.Entity', '', '', 'Info.Entity.Reference', 'справочник', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.ExchangeRate', 'Info.', '', '', 'Info.ExchangeRate', 'ExchangeRate', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.ExchangeRate.Bank', 'Info.ExchangeRate', '', '', 'Info.ExchangeRate.Bank', 'курс комм банка', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.ExchangeRate.Market', 'Info.ExchangeRate', '', '', 'Info.ExchangeRate.Market', 'рыночный курс', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.ExchangeRate.NationalBank', 'Info.ExchangeRate', '', '', 'Info.ExchangeRate.NationalBank', 'курс Нацбанка', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.ExchangeRate.Stock', 'Info.ExchangeRate', '', '', 'Info.ExchangeRate.Stock', 'курс биржи', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Face', 'Info.', '', '', 'Info.Face', 'Face', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Face.Branch', 'Info.Face', '', '', 'Info.Face.Branch', 'филиал', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Face.Businessman', 'Info.Face', '', '', 'Info.Face.Businessman', 'ИП', '{"FullName": "Индивидуальный предприниматель","KBE": "19","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Face.Corp', 'Info.Face', '', '', 'Info.Face.Corp', 'ТОО', '{"FullName": "Товарищество с ограниченной ответственностью","KBE": "17","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Face.GovAgency', 'Info.Face', '', '', 'Info.Face.GovAgency', 'ГУ', '{"FullName": "Государственное учреждение","KBE": "11","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Face.JointStockCompany', 'Info.Face', '', '', 'Info.Face.JointStockCompany', 'АО', '{"FullName": "Акционерное общество","KBE": "17","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Face.LegalEntity', 'Info.Face', '', '', 'Info.Face.LegalEntity', 'юридическое лицо', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Face.Person', 'Info.Face', '', '', 'Info.Face.Person', 'физическое лицо', '{"KBE": "19","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Face.QuasiGov1', 'Info.Face', '', '', 'Info.Face.QuasiGov1', 'РГКП', '{"KBE": "11","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Face.QuasiGov2', 'Info.Face', '', '', 'Info.Face.QuasiGov2', 'КГКП', '{"KBE": "11","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Face.User', 'Info.Face', '', '', 'Info.Face.User', 'пользователь', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Generic', 'Info.', '', '', 'Info.Generic', 'Generic', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Generic.Cell', 'Info.Generic', '', '', 'Info.Generic.Cell', 'телефон сотовый', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Generic.Description', 'Info.Generic', '', '', 'Info.Generic.Description', 'расшифровка', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Generic.Email', 'Info.Generic', '', '', 'Info.Generic.Email', 'емайл', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Generic.Extra', 'Info.Generic', '', '', 'Info.Generic.Extra', 'необычный', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Generic.FullDescription', 'Info.Generic', '', '', 'Info.Generic.FullDescription', 'полное описание', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Generic.FullName', 'Info.Generic', '', '', 'Info.Generic.FullName', 'полное наименование', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Generic.Logo', 'Info.Generic', '', '', 'Info.Generic.Logo', 'логотип', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Generic.Basic', 'Info.Generic', '', '', 'Info.Generic.Basic', 'общая инфо', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Generic.Phone', 'Info.Generic', '', '', 'Info.Generic.Phone', 'телефон', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Generic.Photo', 'Info.Generic', '', '', 'Info.Generic.Photo', 'фото', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Generic.Sert', 'Info.Generic', '', '', 'Info.Generic.Sert', 'ключ, сертификат', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Generic.ShortDescription', 'Info.Generic', '', '', 'Info.Generic.ShortDescription', 'краткое описание', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Generic.ShortName', 'Info.Generic', '', '', 'Info.Generic.ShortName', 'сокращенное наименование', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Generic.Site', 'Info.Generic', '', '', 'Info.Generic.Site', 'сайт', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Generic.Street-House', 'Info.Generic', '', '', 'Info.Generic.Street-House', 'улица, дом', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Generic.Time', 'Info.Generic', '', '', 'Info.Generic.Time', 'время', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Generic.Variant', 'Info.Generic', '', '', 'Info.Generic.Variant', 'вариант', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Item', 'Info.', '', '', 'Info.Item', 'Item', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Item.Financial', 'Info.Item', '', '', 'Info.Item.Financial', 'финансовая деятельность', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Item.Invest', 'Info.Item', '', '', 'Info.Item.Invest', 'инвестиционная деятельность', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Item.Basic', 'Info.Item', '', '', 'Info.Item.Basic', 'операционная деятельность', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.List', 'Info.', '', '', 'Info.List', 'List', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.List.ExemptionList', 'Info.List', '', '', 'Info.List.ExemptionList', 'Перечень изъятий', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.List.StopList', 'Info.List', '', '', 'Info.List.StopList', 'Стоп-лист по отгрузке', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Workbook', 'Info.', '', '', 'Info.Workbook', 'Workbook', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Workbook.Deal.Devivery', 'Info.Workbook', '', '', 'Info.Workbook.Deal.Devivery', 'поставка договора', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Workbook.Deal.Movement', 'Info.Workbook', '', '', 'Info.Workbook.Deal.Movement', 'движения договора', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Workbook.Level0.Main', 'Info.Workbook', '', '', 'Info.Workbook.Level0.Main', 'Workbook.Level0.общее', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Workbook.Level1.Amount', 'Info.Workbook', '', '', 'Info.Workbook.Level1.Amount', 'Workbook.Level1.сумма', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Workbook.Level1.Cost', 'Info.Workbook', '', '', 'Info.Workbook.Level1.Cost', 'Workbook.Level1.себ-ть сумма', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Workbook.Level1.Price', 'Info.Workbook', '', '', 'Info.Workbook.Level1.Price', 'Workbook.Level1.цена', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Workbook.Level1.Quantity', 'Info.Workbook', '', '', 'Info.Workbook.Level1.Quantity', 'Workbook.Level1.кол-во', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Workbook.Level2.Depreciation', 'Info.Workbook', '', '', 'Info.Workbook.Level2.Depreciation', 'Workbook.Level2.аморт-я', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Workbook.Level2.TaxExcess', 'Info.Workbook', '', '', 'Info.Workbook.Level2.TaxExcess', 'Workbook.Level2.налоги сверх суммы', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Workbook.Level2.TaxTotal', 'Info.Workbook', '', '', 'Info.Workbook.Level2.TaxTotal', 'Workbook.Level2.налоги в сумме', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Management', 'Info.', '', '', 'Info.Management', 'Management', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Management.Boss', 'Info.Management', '', '', 'Info.Management.Boss', 'директор', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Management.Chief', 'Info.Management', '', '', 'Info.Management.Chief', 'начальник', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Management.Driver', 'Info.Management', '', '', 'Info.Management.Driver', 'водитель', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Management.LeadingSpecialist', 'Info.Management', '', '', 'Info.Management.LeadingSpecialist', 'ведущий специалист', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Management.Manager', 'Info.Management', '', '', 'Info.Management.Manager', 'управляющий', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Management.Responsible', 'Info.Management', '', '', 'Info.Management.Responsible', 'ответственный', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Math', 'Info.', '', '', 'Info.Math', 'Math', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Math.Round1.5To1', 'Info.Math', '', '', 'Info.Math.Round1.5To1', 'округлять 1,5 до 1', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Math.Round1.5To2', 'Info.Math', '', '', 'Info.Math.Round1.5To2', 'округлять 1,5 до 2', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Math.RoundDownward', 'Info.Math', '', '', 'Info.Math.RoundDownward', 'округлять всегда в меньшую сторону', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Math.RoundUpward', 'Info.Math', '', '', 'Info.Math.RoundUpward', 'округлять всегда в большую сторону', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.PersonData', 'Info.', '', '', 'Info.PersonData', 'PersonData', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.PersonData.Autobiography', 'Info.PersonData', '', '', 'Info.PersonData.Autobiography', 'автобиография', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.PersonData.DateBirth', 'Info.PersonData', '', '', 'Info.PersonData.DateBirth', 'дата рождения', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.PersonData.Name', 'Info.PersonData', '', '', 'Info.PersonData.Name', 'имя', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.PersonData.Nationality', 'Info.PersonData', '', '', 'Info.PersonData.Nationality', 'национальность', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.PersonData.Patronymic', 'Info.PersonData', '', '', 'Info.PersonData.Patronymic', 'отчество', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.PersonData.Resume', 'Info.PersonData', '', '', 'Info.PersonData.Resume', 'резюме', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.PersonData.Surname', 'Info.PersonData', '', '', 'Info.PersonData.Surname', 'фамилия', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Profile', 'Info.', '', '', 'Info.Profile', 'Profile', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Profile.Basic', 'Info.Profile', '', '', 'Info.Profile.Basic', 'общий профиль', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Profile.Store', 'Info.Profile', '', '', 'Info.Profile.Store', 'профиль склад', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Profile.PropertyManagement', 'Info.Profile', '', '', 'Info.Profile.PropertyManagement', 'профиль КСК', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Rate', 'Info.', '', '', 'Info.Rate', 'Rate', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Rate.MinRate', 'Info.Rate', '', '', 'Info.Rate.MinRate', 'МРП', '{"FullName": "минимальный расчетный показатель","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Rate.MinSalary', 'Info.Rate', '', '', 'Info.Rate.MinSalary', 'Мин ЗП', '{"FullName": "минимальная заработная плата","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.RegData', 'Info.', '', '', 'Info.RegData', 'RegData', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.RegData.BIN', 'Info.RegData', '', '', 'Info.RegData.BIN', 'БИН', '{"FullName": "Бизнес-идентификационный номер","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.RegData.IIN', 'Info.RegData', '', '', 'Info.RegData.IIN', 'ИИН', '{"FullName": "Индивидуально-идентификационный номер","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.RegData.Passport', 'Info.RegData', '', '', 'Info.RegData.Passport', 'паспорт РК', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.RegData.RNN', 'Info.RegData', '', '', 'Info.RegData.RNN', 'РНН', '{"FullName": "Регистрационный номер налогоплательщика","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Relation', 'Info.', '', '', 'Info.Relation', 'Relation', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Relation.Alimonier', 'Info.Relation', '', '', 'Info.Relation.Alimonier', 'получатель алиментов', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Relation.MainCalc', 'Info.Relation', '', '', 'Info.Relation.MainCalc', 'основной пересчет', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Relation.Pensioner', 'Info.Relation', '', '', 'Info.Relation.Pensioner', 'пенсионер', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Report', 'Info.', '', '', 'Info.Report', 'Отчет', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Report.Analysis', 'Info.Report', '', '', 'Info.Report.Analysis', 'анализ', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Report.Balance', 'Info.Report', '', '', 'Info.Report.Balance', 'остатки', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Report.BalanceTurnover', 'Info.Report', '', '', 'Info.Report.BalanceTurnover', 'остатки и обороты', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Report.Depreciation', 'Info.Report', '', '', 'Info.Report.Depreciation', 'расчет амортизации', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Report.Detail', 'Info.Report', '', '', 'Info.Report.Detail', 'карточка', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Report.DocLawForm', 'Info.Report', '', '', 'Info.Report.DocLawForm', 'нормативная форма документа', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Report.FinForm', 'Info.Report', '', '', 'Info.Report.FinForm', 'фин отчет', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Report.FinForm.Balance', 'Info.Report.FinForm', '', '', 'Info.Report.FinForm.Balance', 'баланс', '{"FullName": "Бухгалтерский баланс","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Report.FinForm.Capital', 'Info.Report.FinForm', '', '', 'Info.Report.FinForm.Capital', 'капитал', '{"FullName": "Отчет о движении капитала","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Report.FinForm.Income', 'Info.Report.FinForm', '', '', 'Info.Report.FinForm.Income', 'доход', '{"FullName": "Отчет о доходах и расходах","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Report.FinForm.Money', 'Info.Report.FinForm', '', '', 'Info.Report.FinForm.Money', 'деньги', '{"FullName": "Отчет о движении денег","AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Report.List', 'Info.Report', '', '', 'Info.Report.List', 'список', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Report.PaySheet', 'Info.Report', '', '', 'Info.Report.PaySheet', 'реестр платежей', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Report.PriceList', 'Info.Report', '', '', 'Info.Report.PriceList', 'прайс-лист', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Report.Revise', 'Info.Report', '', '', 'Info.Report.Revise', 'акт сверки', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Report.SalaryInquery', 'Info.Report', '', '', 'Info.Report.SalaryInquery', 'справка по зарплате', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Report.SalarySheet', 'Info.Report', '', '', 'Info.Report.SalarySheet', 'расчетная ведомость начисления ЗП', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Report.SalarySummary', 'Info.Report', '', '', 'Info.Report.SalarySummary', 'свод зарплаты', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Report.Sheet', 'Info.Report', '', '', 'Info.Report.Sheet', 'ведомость', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Report.StaffDoc', 'Info.Report', '', '', 'Info.Report.StaffDoc', 'кадровый приказ', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Report.TaxForm', 'Info.Report', '', '', 'Info.Report.TaxForm', 'налог отчет', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Report.TaxRegistry', 'Info.Report', '', '', 'Info.Report.TaxRegistry', 'налог регистр', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Sign', 'Info.', '', '', 'Info.Sign', 'Sign', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Sign.UseAccTable', 'Info.Sign', '', '', 'Info.Sign.UseAccTable', 'использовать в плане счетов', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Sign.UseEntry', 'Info.Sign', '', '', 'Info.Sign.UseEntry', 'использовать в проводках', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Staff', 'Info.', '', '', 'Info.Staff', 'Staff', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Staff.BaseSalary', 'Info.Staff', '', '', 'Info.Staff.BaseSalary', 'базовый оклад', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Staff.BossSign', 'Info.Staff', '', '', 'Info.Staff.BossSign', 'подпись руководителя', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Staff.ChiefAccountantSign', 'Info.Staff', '', '', 'Info.Staff.ChiefAccountantSign', 'подпись глав бухгалтера', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.StaffTime', 'Info.', '', '', 'Info.StaffTime', 'StaffTime', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.StaffTime.DayOff', 'Info.StaffTime', '', '', 'Info.StaffTime.DayOff', 'выходной день', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.StaffTime.Holiday', 'Info.StaffTime', '', '', 'Info.StaffTime.Holiday', 'праздничный день', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Store', 'Info.', '', '', 'Info.Store', 'Store', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Store.CoreFund', 'Info.Store', '', '', 'Info.Store.CoreFund', 'основное средство', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Store.IsDriveLaw', 'Info.Store', '', '', 'Info.Store.IsDriveLaw', 'есть право вождения', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Store.IsSubStore', 'Info.Store', '', '', 'Info.Store.IsSubStore', 'является субскладом', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Store.NoStoreNoTraffic', 'Info.Store', '', '', 'Info.Store.NoStoreNoTraffic', 'не требует транспортировки и складирования', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Tax', 'Info.', '', '', 'Info.Tax', 'Tax', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Tax.Amount', 'Info.Tax', '', '', 'Info.Tax.Amount', 'налоговая сумма', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Tax.Base', 'Info.Tax', '', '', 'Info.Tax.Base', 'налоговая база', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Tax.BaseDeduction', 'Info.Tax', '', '', 'Info.Tax.BaseDeduction', 'вычет налоговой базы', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Tax.BaseException', 'Info.Tax', '', '', 'Info.Tax.BaseException', 'исключение базы', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Tax.BaseLimit', 'Info.Tax', '', '', 'Info.Tax.BaseLimit', 'лимит базы', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Tax.Deduction.Standard', 'Info.Tax', '', '', 'Info.Tax.Deduction.Standard', 'Стандарный вычет', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Tax.Deduction.OPV', 'Info.Tax', '', '', 'Info.Tax.Deduction.OPV', 'вычет ОПВ', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Tax.HalfYearReportingCycle', 'Info.Tax', '', '', 'Info.Tax.HalfYearReportingCycle', 'полугодовой отчетный цикл', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Tax.MonthBillingCycle', 'Info.Tax', '', '', 'Info.Tax.MonthBillingCycle', 'месячный расчетный цикл', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Tax.MonthYearBillingCycle', 'Info.Tax', '', '', 'Info.Tax.MonthYearBillingCycle', 'месячно-годовой расчетный цикл', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Tax.QuarterBillingCycle', 'Info.Tax', '', '', 'Info.Tax.QuarterBillingCycle', 'квартальный расчетный цикл', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Tax.QuarterReportingCycle', 'Info.Tax', '', '', 'Info.Tax.QuarterReportingCycle', 'квартальный отчетный цикл', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Tax.RateFree', 'Info.Tax', '', '', 'Info.Tax.RateFree', 'освобожденная ставка', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Tax.RateBasic', 'Info.Tax', '', '', 'Info.Tax.RateBasic', 'основная ставка', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Tax.RateReduce', 'Info.Tax', '', '', 'Info.Tax.RateReduce', 'сниженная ставка', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Tax.RateZero', 'Info.Tax', '', '', 'Info.Tax.RateZero', 'нулевая ставка', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Tax.SNMinusGFSS', 'Info.Tax', '', '', 'Info.Tax.SNMinusGFSS', 'корректировка СН на ГФСС', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Tax.TaxAdjustment', 'Info.Tax', '', '', 'Info.Tax.TaxAdjustment', 'налоговая корректировка', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Tax.YearBillingCycle', 'Info.Tax', '', '', 'Info.Tax.YearBillingCycle', 'годовой расчетный цикл', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Tax.YearReportingCycle', 'Info.Tax', '', '', 'Info.Tax.YearReportingCycle', 'годовой отчетный цикл', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Tax.RateLess', 'Info.Tax', '', '', 'Info.Tax.RateLess', 'безналоговая ставка', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Tax.FactBillingCycle', 'Info.Tax', '', '', 'Info.Tax.FactBillingCycle', 'фактический расчетный цикл', '{"AbcBasic": "Info.Basic"}');
INSERT INTO Info (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Info.Tax.FactReportingCycle', 'Info.Tax', '', '', 'Info.Tax.FactReportingCycle', 'фактический отчетный цикл', '{"AbcBasic": "Info.Basic"}');

-- Таблица: Item
CREATE TABLE IF NOT EXISTS [Item](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Item(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[More] TEXT
 );
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.', '', '', '', 'Item.', 'ItemData', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Advance', 'Item', '', '', 'Item.Advance', 'авансы', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Advertising', 'Item', '', '', 'Item.Advertising', 'реклама', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Bank', 'Item', '', '', 'Item.Bank', 'РКО, услуги банка', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Car', 'Item', '', '', 'Item.Car', 'автопарк', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Charity', 'Item', '', '', 'Item.Charity', 'благотворительность', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Cost', 'Item', '', '', 'Item.Cost', 'себестоимость', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Deduction', 'Item', '', '', 'Item.Deduction', 'удержания из ЗП', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Depreciation', 'Item', '', '', 'Item.Depreciation', 'амортизация', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Equipment', 'Item', '', '', 'Item.Equipment', 'оборудование', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Exchange difference', 'Item', '', '', 'Item.Exchange difference', 'курсовая разница', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Fine', 'Item', '', '', 'Item.Fine', 'штрафы, пени', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Food', 'Item', '', '', 'Item.Food', 'питание', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Fuel', 'Item', '', '', 'Item.Fuel', 'топливо', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Impress', 'Item', '', '', 'Item.Impress', 'подотчет', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Insurance', 'Item', '', '', 'Item.Insurance', 'страхование', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Learning', 'Item', '', '', 'Item.Learning', 'обучение персонала', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Loan', 'Item', '', '', 'Item.Loan', 'кредит, овердрафт', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Material', 'Item', '', '', 'Item.Material', 'материалы', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Office', 'Item', '', '', 'Item.Office', 'офис, канцелярия, почта', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Other', 'Item', '', '', 'Item.Other', 'прочее', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Parts', 'Item', '', '', 'Item.Parts', 'запчасти', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Periodical', 'Item', '', '', 'Item.Periodical', 'периодика, книги', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Production', 'Item', '', '', 'Item.Production', 'производство', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Purchase', 'Item', '', '', 'Item.Purchase', 'приобретение', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Rent', 'Item', '', '', 'Item.Rent', 'аренда, хранение', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Repair', 'Item', '', '', 'Item.Repair', 'ремонт', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Salary', 'Item', '', '', 'Item.Salary', 'зарплата и отчисления', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Security', 'Item', '', '', 'Item.Security', 'охрана', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Sell', 'Item', '', '', 'Item.Sell', 'продажа', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Shipping', 'Item', '', '', 'Item.Shipping', 'перевозки', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Store', 'Item', '', '', 'Item.Store', 'склад', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Tax', 'Item', '', '', 'Item.Tax', 'налоги, сборы, отчисления', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Telecom', 'Item', '', '', 'Item.Telecom', 'телефон, интернет', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Trip', 'Item', '', '', 'Item.Trip', 'командировки', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.Utilities', 'Item', '', '', 'Item.Utilities', 'коммунальные услуги', '{"AbcBasic": "Item.Basic"}');
INSERT INTO Item (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Item.WriteOff', 'Item', '', '', 'Item.WriteOff', 'списание', '{"AbcBasic": "Item.Basic"}');

-- Таблица: Mark
CREATE TABLE IF NOT EXISTS [Mark](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Mark(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[More] TEXT
 );
INSERT INTO Mark (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Mark.ArcD', 'Mark.', '', '', 'Mark.ArcD', 'ArchivalData', '{"AbcBasic": "Mark.Basic"}');
INSERT INTO Mark (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Mark.CD', 'Mark.', '', '', 'Mark.CD', 'CurrentData', '{"AbcBasic": "Mark.Basic"}');
INSERT INTO Mark (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Mark.DD', 'Mark.', '', '', 'Mark.DD', 'DraftData', '{"AbcBasic": "Mark.Basic"}');
INSERT INTO Mark (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Mark.DelD', 'Mark.', '', '', 'Mark.DelD', 'DeleteData', '{"AbcBasic": "Mark.Basic"}');
INSERT INTO Mark (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Mark.ExD', 'Mark.', '', '', 'Mark.ExD', 'ExampleData', '{"AbcBasic": "Mark.Basic"}');
INSERT INTO Mark (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Mark.ExtD', 'Mark.', '', '', 'Mark.ExtD', 'ExternalData', '{"AbcBasic": "Mark.Basic"}');
INSERT INTO Mark (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Mark.MD', 'Mark.', '', '', 'Mark.MD', 'MetaData', '{"AbcBasic": "Mark.Basic"}');
INSERT INTO Mark (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Mark.RuleD', 'Mark.', '', '', 'Mark.RuleD', 'RuleData', '{"AbcBasic": "Mark.Basic"}');
INSERT INTO Mark (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Mark.TemplD', 'Mark.', '', '', 'Mark.TemplD', 'TemplateData', '{"AbcBasic": "Mark.Basic"}');
INSERT INTO Mark (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Mark.TrnD', 'Mark.', '', '', 'Mark.TrnD', 'TransferData', '{"AbcBasic": "Mark.Basic"}');
INSERT INTO Mark (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Mark.', '', '', '', 'Mark.', 'MarkData', '{"AbcBasic": "Mark.Basic"}');

-- Таблица: Meter
CREATE TABLE IF NOT EXISTS [Meter](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Meter(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Unit] TEXT references Unit(Id),
	[More] TEXT
 );
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES ('Meter.Amount', 'Meter.', '', '', 'Meter.Amount', 'сумма', 'Unit.CurrUnit', '{"AbcBasic": "Meter.Basic"}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES ('Meter.Authentication', 'Meter.', '', '', 'Meter.Authentication', 'аутентификация', 'Unit.ServiceLoginPassword', '{"AbcBasic": "Meter.Basic"}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES ('Meter.Cost', 'Meter.Amount', '', '', 'Meter.Cost', 'себестоимость', '', '{"AbcBasic": "Meter.Basic"}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES ('Meter.Counter', 'Meter.Quantity', '', '', 'Meter.Counter', 'счетчик', 'Unit.DocID', '{"AbcBasic": "Meter.Basic"}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES ('Meter.Depth', 'Meter.', '', '', 'Meter.Depth', 'толщина', 'Unit.Mm', '{"AbcBasic": "Meter.Basic"}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES ('Meter.Diameter', 'Meter.', '', '', 'Meter.Diameter', 'диаметр', 'Unit.Mm', '{"AbcBasic": "Meter.Basic"}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES ('Meter.Height', 'Meter.', '', '', 'Meter.Height', 'высота', 'Unit.Meter', '{"AbcBasic": "Meter.Basic"}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES ('Meter.Length', 'Meter.', '', '', 'Meter.Length', 'длина', 'Unit.Meter', '{"AbcBasic": "Meter.Basic"}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES ('Meter.Linear weight 1m', 'Meter.Weight', '', '', 'Meter.Linear weight 1m', 'погонный вес 1м', 'Unit.Kg', '{"AbcBasic": "Meter.Basic"}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES ('Meter.', '', '', '', 'Meter.', 'MeterData', '', '{"AbcBasic": "Meter.Basic"}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES ('Meter.Number pieces pack', 'Meter.Quantity', '', '', 'Meter.Number pieces pack', 'кол-во штук в упаковке', 'Unit.Piece', '{"AbcBasic": "Meter.Basic"}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES ('Meter.Price', 'Meter.Amount', '', '', 'Meter.Price', 'цена', '', '{"AbcBasic": "Meter.Basic"}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES ('Meter.Quantity', 'Meter.', '', '', 'Meter.Quantity', 'количество', 'Unit', '{"AbcBasic": "Meter.Basic"}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES ('Meter.Rate', 'Meter.', '', '', 'Meter.Rate', 'ставка', 'Unit.Percent', '{"AbcBasic": "Meter.Basic"}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES ('Meter.Rating', 'Meter.Amount', '', '', 'Meter.Rating', 'номинал', '', '{"AbcBasic": "Meter.Basic"}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES ('Meter.Time', 'Meter.', '', '', 'Meter.Time', 'время', '', '{"AbcBasic": "Meter.Basic"}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES ('Meter.Volume', 'Meter.', '', '', 'Meter.Volume', 'объем', 'Unit.Litr', '{"AbcBasic": "Meter.Basic"}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES ('Meter.Weight', 'Meter.', '', '', 'Meter.Weight', 'вес', 'Unit.Kg', '{"AbcBasic": "Meter.Basic"}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES ('Meter.Width', 'Meter.', '', '', 'Meter.Width', 'ширина', 'Unit.Meter', '{"AbcBasic": "Meter.Basic"}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES ('Meter.PublicHoliday', 'Meter.', '', '', 'Meter.PublicHoliday', 'праздник', 'Unit.Piece', '{"AbcBasic": "Meter.Basic"}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES ('Meter.ExtraDayOff', 'Meter.', '', '', 'Meter.ExtraDayOff', 'дополнительный выходной день', 'Unit.Piece', '{"AbcBasic": "Meter.Basic"}');
INSERT INTO Meter (Id, Parent, Date1, Date2, Code, Description, Unit, More) VALUES ('Meter.Matching', 'Meter.', '', '', 'Meter.Matching', 'сопоставление', 'Unit.Piece', '{"AbcBasic": "Meter.Basic"}');

-- Таблица: Price
CREATE TABLE IF NOT EXISTS [Price](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Price(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Role] TEXT references Role(Id),
	[Info] TEXT references Info(Id),
	[Unit] TEXT references Unit(Id),
	[More] TEXT
 );
INSERT INTO Price (Id, Parent, Date1, Date2, Code, Description, Role, Info, Unit, More) VALUES ('Price.', '', '', '', 'Price.', 'PriceData', 'Role.Entity.PriceList', 'Info.Entity.Reference', '', '{"AbcBasic": "Price.Basic"}');
INSERT INTO Price (Id, Parent, Date1, Date2, Code, Description, Role, Info, Unit, More) VALUES ('Price.Basic', 'Price.', '', '', 'Price.Basic', 'Оптовая цена', 'Role.Price.Basic', 'Info.Generic.Basic', '', '{"AbcBasic": "Price.Basic"}');
INSERT INTO Price (Id, Parent, Date1, Date2, Code, Description, Role, Info, Unit, More) VALUES ('Price.MarkupBasic', 'Price.', '', '', 'Price.MarkupBasic', 'Основная наценка', 'Role.PriceChange.Markup', 'Info.Generic.Basic', 'Unit.Percent', '{"AbcBasic": "Price.Basic"}');
INSERT INTO Price (Id, Parent, Date1, Date2, Code, Description, Role, Info, Unit, More) VALUES ('Price.SaleBasic', 'Price.Main', '', '', 'Price.SaleBasic', 'Основная скидка', 'Role.PriceChange.Sale', 'Info.Generic.Basic', 'Unit.Percent', '{"AbcBasic": "Price.Basic"}');
INSERT INTO Price (Id, Parent, Date1, Date2, Code, Description, Role, Info, Unit, More) VALUES ('Price.USD-KZT', 'Price.', '', '', 'Price.USD-KZT', 'USD-KZT (курс тенге к доллару)', 'Role.Currency.ExchangeCurrency', 'Info.ExchangeRate.Stock', 'Unit.KZT', '{"AbcBasic": "Price.Basic"}');
INSERT INTO Price (Id, Parent, Date1, Date2, Code, Description, Role, Info, Unit, More) VALUES ('Price.Retail', 'Price.', '', '', 'Price.Retail', 'Розничная цена', 'Role.Price.Basic', 'Info.Generic.Variant', '', '{"AbcBasic": "Price.Basic"}');
INSERT INTO Price (Id, Parent, Date1, Date2, Code, Description, Role, Info, Unit, More) VALUES ('Price.TariffHour', 'Price.', '', '', 'Price.TariffHour', 'Ставка за 1 раб. Час', 'Role.Price.Tariff', 'Info.Generic.Basic', 'Unit.KZT', '{"AbcBasic": "Price.Basic"}');
INSERT INTO Price (Id, Parent, Date1, Date2, Code, Description, Role, Info, Unit, More) VALUES ('Price.TariffDay', 'Price.', '', '', 'Price.TariffDay', 'Ставка за 1 раб. День', 'Role.Price.Tariff', 'Info.Generic.Basic', 'Unit.KZT', '{"AbcBasic": "Price.Basic"}');

-- Таблица: Process
CREATE TABLE IF NOT EXISTS [Process](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Process(Id),
	[Face1] TEXT references Face(Id),
	[Face2] TEXT references Face(Id),
	[Face] TEXT references Face(Id),
	[Slice] TEXT references Slice(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Sign] TEXT references Sign(Id),
	[Account] TEXT references Account(Id),
    [Asset] TEXT references Asset(Id),
    [Deal] TEXT references Deal(Id),
    [Item] TEXT references Item(Id),
	[Debt] TEXT references Debt(Id),
	[Price] TEXT references Price(Id),
	[Role] TEXT references Role(Id),
	[Info] TEXT references Info(Id),
	[Meter] TEXT references Meter(Id),
	[MeterValue] TEXT,
	[Unit] TEXT references Unit(Id),
	[More] TEXT
 );
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.AddSalary', 'Process.', 'Face.FA1', '', '', 'Slice.Accounting', '', '', 'Process.AddSalary', 'Дополн удержание из ЗП', '', '', '', '', '', '', '', 'Role.Workbook.StartPoint', 'Info.Generic.Variant', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.AddSalary.1', 'Process.AddSalary', 'Face.FA1', 'Face.', '', 'Slice.Accounting', '', '', 'Process.AddSalary.1', 'Удержание из ЗП', 'Sign.Acct.Dt', 'Account.Salary', '', 'Deal.', '', 'Debt.DeductionSalary.Other', '', 'Role.Entity.Salary', 'Info.Workbook.Level1.Amount', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.AddSalary.2', 'Process.AddSalary', 'Face.FA1', '', '', 'Slice.Accounting', '', '', 'Process.AddSalary.2', 'Коррсчет удержания из ЗП', 'Sign.Acct.Ct', 'Account.', '', '', 'Item.Deduction', '', '', 'Role.Entity.Salary', 'Info.Workbook.Level1.Amount', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Buy', 'Process.', 'Face.FA1', '', '', 'Slice.Accounting', '', '', 'Process.Buy', 'Покупка', '', '', '', '', '', '', '', 'Role.Workbook.StartPoint', 'Info.Generic.Basic', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Buy.1', 'Process.Buy', 'Face.FA1', 'Face.', 'Face.FA1.User1', 'Slice.Accounting', '', '', 'Process.Buy.1', 'Согласование вх договора', '', '', 'Asset.', '', 'Item.Purchase', '', 'Price.Basic', 'Role.Entity.Deal', 'Info.Workbook.Level1.Quantity', 'Meter.Quantity', '', 'Unit.Piece', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Buy.2 (Contract)', 'Process.Buy.1', 'Face.FA1', 'Face.', 'Face.FA1.User1', 'Slice.Accounting', '', '', 'Process.Buy.2 (Contract)', 'Новый договор', '', '', '', 'Deal.', 'Item.Purchase', '', '', 'Role.Entity.Deal', 'Info.Workbook.Level1.Price', 'Meter.Price', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Buy.3 (Order)', 'Process.Buy.2 (Contract)', 'Face.', 'Face.FA1', 'Face.FA1.User1', 'Slice.Accounting', '', '', 'Process.Buy.3 (Order)', 'Получение вх счета', '', '', '', 'Deal.', '', '', '', 'Role.Entity.Order', 'Info.Workbook.Level0.Main', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Buy.3A', 'Process.Buy.3 (Order)', 'Face.FA1', '', 'Face.', 'Slice.Plan', '', '', 'Process.Buy.3A', 'Оплата вх счета (план)', 'Sign.Acct.Dt', 'Account.Money', '', 'Deal.', 'Item.Purchase', '', '', 'Role.Entity.Money', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Buy.4 (Money)', 'Process.Buy.3 (Order)', 'Face.FA1', '', 'Face.', 'Slice.Accounting', '', '', 'Process.Buy.4 (Money)', 'Оплата вх счета', '', '', '', 'Deal.', '', '', '', 'Role.Entity.Money', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Buy.4A', 'Process.Buy.4 (Money)', 'Face.FA1.Bank1', '', 'Face.', 'Slice.Accounting', '', '', 'Process.Buy.4A', 'Плат поручение исх', 'Sign.MoneyFlow.Output.021', '', 'Asset.Money', 'Deal.', 'Item.Purchase', '', '', 'Role.Entity.PayOrder', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Buy.4B', 'Process.Buy.4 (Money)', 'Face.FA1.Bank1', '', 'Face.', 'Slice.Accounting', '', '', 'Process.Buy.4B', 'Выбытие ДС', 'Sign.Acct.Ct', 'Account.Money', 'Asset.Money', 'Deal.', 'Item.Purchase', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Buy.4C', 'Process.Buy.4 (Money)', '', '', 'Face.', 'Slice.Accounting', '', '', 'Process.Buy.4C', 'Списание кред задолж-ти', 'Sign.Acct.Dt', 'Account.Seller', '', 'Deal.', 'Item.Purchase', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Buy.5 (Arrival)', 'Process.Buy.3 (Order)', '', '', '', 'Slice.Accounting', '', '', 'Process.Buy.5 (Arrival)', 'Исполнение вх счета', '', '', '', '', '', '', '', 'Role.Entity.Purchase', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Buy.5A', 'Process.Buy.5 (Arrival)', '', '', '', 'Slice.Accounting', '', '', 'Process.Buy.5A', 'Выдача исх доверенности', '', '', 'Asset.', 'Deal.', 'Item.Purchase', '', '', 'Role.Entity.Warrant', '', 'Meter.', '', 'Unit.', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Buy.5B', 'Process.Buy.5 (Arrival)', 'Face.FA1.Store1', '', '', 'Slice.Accounting', '', '', 'Process.Buy.5B', 'Приход активов.кол-во', 'Sign.Acct.Dt', 'Account.Asset', 'Asset.', 'Deal.', 'Item.Purchase', '', '', '', 'Info.Cost.Accounting', 'Meter.Quantity', '', 'Unit.', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Buy.5C', 'Process.Buy.5 (Arrival)', 'Face.FA1.Store1', '', '', 'Slice.Accounting', '', '', 'Process.Buy.5C', 'Приход активов.сумма', 'Sign.Acct.Dt', 'Account.Asset', 'Asset.', 'Deal.', 'Item.Purchase', '', '', '', 'Info.Cost.Accounting', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Buy.5CA', 'Process.Buy.5 (Arrival)', '', '', '', 'Slice.Accounting', '', '', 'Process.Buy.5CA', 'Приход услуг, работ.сумма', 'Sign.Acct.Dt', 'Account.ExpenseCost', '', 'Deal.', 'Item.Purchase', '', '', '', 'Info.Generic.Variant', 'Meter.Amount', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Buy.5D', 'Process.Buy.5 (Arrival)', '', 'Face.', 'Face.', 'Slice.Accounting', '', '', 'Process.Buy.5D', 'Начисление кред задолж-ти', 'Sign.Acct.Ct', 'Account.TaxVATOut', '', 'Deal.', 'Item.Purchase', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Buy.5E (VATBase)', 'Process.Buy.5 (Arrival)', '', '', '', 'Slice.Accounting', '', '', 'Process.Buy.5E (VATBase)', 'Налоговая база НДС зачета', 'Sign.Tax.Ct', '', '', 'Deal.kgd.tax', 'Item.Purchase', 'Debt.VAT.Base', '', '', 'Info.Tax.Base', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Buy.5F (VAT)', 'Process.Buy.5 (Arrival)', '', '', '', 'Slice.Accounting', '', '', 'Process.Buy.5F (VAT)', 'Начисление НДС зачета', 'Sign.Acct.Dt', 'Account.TaxVATIn', '', 'Deal.kgd.tax', 'Item.Purchase', 'Debt.VAT.Purchase.RateMain', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Buy.6', 'Process.Buy.5 (Arrival)', '', '', '', 'Slice.Accounting', '', '', 'Process.Buy.6', 'Распределение услуг, работ на активы', '', '', '', '', '', '', '', 'Role.Entity.Store', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Buy.6A', 'Process.Buy.6', '', '', '', 'Slice.Accounting', '', '', 'Process.Buy.6A', 'Приход работ, услуг.сторно', 'Sign.Acct.Dt', 'Account.ExpenseCost', '', '', '', '', '', '', '', 'Meter.Amount', 'storno', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Buy.6B', 'Process.Buy.6', '', '', '', 'Slice.Accounting', '', '', 'Process.Buy.6B', 'Отнесение работ, услуг на активы', 'Sign.Acct.Dt', 'Account.Asset', 'Asset.', '', '', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Buy.7 (Invoice)', 'Process.Buy.5 (Arrival)', 'Face.', '', 'Face.FA1', 'Slice.Accounting', '', '', 'Process.Buy.7 (Invoice)', 'Получение счета-фактуры от поставщика', '', '', '', 'Deal.', 'Item.Purchase', '', '', 'Role.Entity.Invoice', 'Info.Generic.Main', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Buy.8 (Null)', 'Process.Buy.3 (Order)', 'Face.', '', 'Face.FA1', 'Slice.Accounting', '', '', 'Process.Buy.8 (Null)', 'Аннулирование вх счета', '', '', 'Asset.', 'Deal.', 'Item.Purchase', '', 'Price.', 'Role.Entity.Order', 'Info.Generic.Variant', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ChangeCurrency', 'Process.', '', '', '', 'Slice.Accounting', '', '', 'Process.ChangeCurrency', 'Конвертация валюты', '', '', '', '', '', '', '', 'Role.Workbook.StartPoint', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ChangeCurrency.1', 'Process.ChangeCurrency', 'Face.FA1.Cash1', '', '', 'Slice.Accounting', '', '', 'Process.ChangeCurrency.1', 'Списание ДС на конвертацию', 'Sign.Acct.Ct', 'Account.Money', 'Asset.Money', 'Deal.', 'Item.Purchase', '', '', 'Role.Entity.Money', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ChangeCurrency.2', 'Process.ChangeCurrency', 'Face.FA1.Cash1', '', '', 'Slice.Accounting', '', '', 'Process.ChangeCurrency.2', 'Покупка валюты', 'Sign.Acct.Dt', 'Account.Money', 'Asset.Money', 'Deal.', 'Item.Purchase', '', '', 'Role.Entity.Money', '', 'Meter.Amount', '', 'Unit.USD', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ChangeCurrency.3', 'Process.ChangeCurrency', 'Face.FA1.Cash1', '', '', 'Slice.Accounting', '', '', 'Process.ChangeCurrency.3', 'Курсовая разница при конвертации', 'Sign.Acct.Ct', 'Account.Money', 'Asset.Money', 'Deal.', 'Item.Exchange difference', '', '', 'Role.Entity.Money', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ChangeCurrency.4', 'Process.ChangeCurrency', '', '', '', 'Slice.Accounting', '', '', 'Process.ChangeCurrency.4', 'Расход по КР', 'Sign.Acct.Dt', 'Account.ExpenseSellOut', '', '', 'Item.Exchange difference', 'Debt.ExchangeDifference.Purchase', '', 'Role.Entity.Money', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.AcctClosing', 'Process.', '', '', '', 'Slice.Accounting', '', '', 'Process.AcctClosing', 'Процесс Закрытие счетов', '', '', '', '', '', '', '', 'Role.Entity.Doc-Process', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.CurrentBalance', 'Process.', 'Face.FA1.Store1', '', '', 'Slice.Accounting', '', '', 'Process.CurrentBalance', 'Снятие остатков', '', '', '', '', '', '', '', '', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.CurrentBalance.1', 'Process.CurrentBalance', 'Face.FA1.Store1', '', '', 'Slice.Report', '', '', 'Process.CurrentBalance.1', 'Текущие остатки (отчет)', '', 'Account.Asset', 'Asset.', '', '', '', '', 'Role.Entity.Balance', 'Info.Generic.Main', 'Meter.Quantity', '', 'Unit.', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.CurrentBalance.1A', 'Process.CurrentBalance.1', 'Face.FA1.Store1', '', '', 'Slice.Report', '', '', 'Process.CurrentBalance.1A', 'Текущие остатки.кол-во', 'Sign.Acct.Dt', 'Account.Asset', 'Asset.', '', '', '', '', '', '', 'Meter.Quantity', '', 'Unit.', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.CurrentBalance.1B', 'Process.CurrentBalance.1', 'Face.FA1.Store1', '', '', 'Slice.Report', '', '', 'Process.CurrentBalance.1B', 'Текущие остатки.сумма', 'Sign.Acct.Dt', 'Account.Asset', 'Asset.', '', '', '', '', '', '', 'Meter.Cost', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.CurrentBalance.2', 'Process.CurrentBalance', 'Face.FA1.Store1', '', '', 'Slice.Report', '', '', 'Process.CurrentBalance.2', 'Инв опись', '', 'Account.Asset', 'Asset.', '', '', '', '', 'Role.Entity.Balance', 'Info.Generic.Variant', 'Meter.Quantity', '', 'Unit.', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.CurrentBalance.3', 'Process.CurrentBalance.1', 'Face.FA1.Store1', '', '', 'Slice.Accounting', '', '', 'Process.CurrentBalance.3', 'Слич ведомость', '', '', 'Asset.', '', '', '', '', 'Role.Entity.Balance', 'Info.Generic.Variant', 'Meter.Quantity', '', 'Unit.', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.CurrentBalance.3A', 'Process.CurrentBalance.3', 'Face.FA1.Store1', 'Face.', '', 'Slice.Accounting', '', '', 'Process.CurrentBalance.3A', 'Списание недостач.кол-во', 'Sign.Acct.Ct', 'Account.Asset', 'Asset.', '', 'Item.Store', '', '', 'Role.Entity.WriteOff', 'Info.Generic.Variant', 'Meter.Quantity', '', 'Unit.', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.CurrentBalance.3B', 'Process.CurrentBalance.3', 'Face.FA1.Store1', 'Face.', '', 'Slice.Accounting', '', '', 'Process.CurrentBalance.3B', 'Списание недостач.сумма', 'Sign.Acct.Ct', 'Account.Asset', 'Asset.', '', 'Item.Store', '', '', 'Role.Entity.WriteOff', 'Info.Generic.Variant', 'Meter.Cost', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.CurrentBalance.3C', 'Process.CurrentBalance.3', 'Face.FA1', '', '', 'Slice.Accounting', '', '', 'Process.CurrentBalance.3C', 'Списание недостач.расход', 'Sign.Acct.Dt', 'Account.ExpenseCost', 'Asset.', '', 'Item.Store', '', '', 'Role.Entity.WriteOff', 'Info.Generic.Variant', 'Meter.Amount', '', 'Unit.', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.DebtOffsetting', 'Process.', '', '', '', 'Slice.Accounting', '', '', 'Process.DebtOffsetting', 'Взаимозачет и списание задолж-ти и авансов', '', '', '', '', '', '', '', 'Role.Entity.Face-Deal', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.DebtOffsetting.1', 'Process.DebtOffsetting', '', '', 'Face.', 'Slice.Accounting', '', '', 'Process.DebtOffsetting.1', 'Списание кред задолж-ти по договорам', 'Sign.Acct.Dt', 'Account.Seller', '', 'Deal.', 'Item.Writeoff', '', '', 'Role.Entity.Entry', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.DebtOffsetting.2', 'Process.DebtOffsetting', '', '', 'Face.', 'Slice.Accounting', '', '', 'Process.DebtOffsetting.2', 'Списание деб задолж-ти по договорам', 'Sign.Acct.Ct', 'Account.Customer', '', 'Deal.', 'Item.Writeoff', '', '', 'Role.Entity.Entry', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.DebtOffsetting.3', 'Process.DebtOffsetting', '', '', 'Face.', 'Slice.Accounting', '', '', 'Process.DebtOffsetting.3', 'Списание авансов поставщику', 'Sign.Acct.Ct', 'Account.SellerPrepaid', '', 'Deal.', 'Item.Writeoff', '', '', 'Role.Entity.Entry', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.DebtOffsetting.4', 'Process.DebtOffsetting', '', '', 'Face.', 'Slice.Accounting', '', '', 'Process.DebtOffsetting.4', 'Списание кред задолж-ти поставщика', 'Sign.Acct.Dt', 'Account.Seller', '', 'Deal.', 'Item.Writeoff', '', '', 'Role.Entity.Entry', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.DebtOffsetting.5', 'Process.DebtOffsetting', '', '', 'Face.', 'Slice.Accounting', '', '', 'Process.DebtOffsetting.5', 'Списание авансов покупателя', 'Sign.Acct.Dt', 'Account.CustomerPrepaid', '', 'Deal.', 'Item.Writeoff', '', '', 'Role.Entity.Entry', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.DebtOffsetting.6', 'Process.DebtOffsetting', '', '', 'Face.', 'Slice.Accounting', '', '', 'Process.DebtOffsetting.6', 'Списание деб задолж-ти покупателя', 'Sign.Acct.Ct', 'Account.Customer', '', 'Deal.', 'Item.Writeoff', '', '', 'Role.Entity.Entry', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Depreciation', 'Process.', '', '', '', 'Slice.Accounting', '', '', 'Process.Depreciation', 'Начисление амортизации', '', '', '', '', '', '', '', 'Role.Entity.Entry', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Depreciation.1', 'Process.Depreciation', '', '', '', 'Slice.Accounting', '', '', 'Process.Depreciation.1', 'Амортизация активов', 'Sign.Acct.Ct', 'Account.FixedAssetDepreciation', 'Asset.', '', 'Item.Depreciation', 'Debt.DepreciationAccounting', '', 'Role.Entity.Doc-Process', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Depreciation.2', 'Process.Depreciation', '', '', '', 'Slice.Accounting', '', '', 'Process.Depreciation.2', 'Затраты по амортизации', 'Sign.Acct.Dt', 'Account.ExpenseCost', '', '', 'Item.Depreciation', '', '', 'Role.Entity.Doc-Process', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Entry', 'Process.', '', '', '', 'Slice.Accounting', '', '', 'Process.Entry', 'Процесс Бух справка', '', '', '', '', '', '', '', 'Role.Entity.Entry', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Entry.1', 'Process.Entry', '', 'Face.', 'Face.', 'Slice.Accounting', '', '', 'Process.Entry.1', 'Бух справка.кол-во', 'Sign.Acct.Dt-Ct', 'Account.', 'Asset.', 'Deal.', '', 'Debt.', 'Price.', '', '', 'Meter.Quantity', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Entry.2', 'Process.Entry', '', 'Face.', 'Face.', 'Slice.Accounting', '', '', 'Process.Entry.2', 'Бух справка.сумма', 'Sign.Acct.Dt-Ct', 'Account.', 'Asset.', 'Deal.', '', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ExchangeDifference', 'Process.', '', '', '', 'Slice.Accounting', '', '', 'Process.ExchangeDifference', 'Расчет курсовой разницы', '', '', '', '', '', '', '', 'Role.Workbook.StartPoint', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ExchangeDifference.1', 'Process.ExchangeDifference', '', '', 'Face.', 'Slice.Accounting', '', '', 'Process.ExchangeDifference.1', 'Текущие остатки валютных задолж-тей', 'Sign.Acct', 'Account.', '', 'Deal.', '', '', '', 'Role.Entity.Entry', '', 'Meter.Amount', '', 'Unit.USD', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ExchangeDifference.2', 'Process.ExchangeDifference', '', '', 'Face.', 'Slice.Accounting', '', '', 'Process.ExchangeDifference.2', 'Расчет КР', '', 'Account.', '', 'Deal.', '', '', '', 'Role.Entity.Entry', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ExchangeDifference.3', 'Process.ExchangeDifference', '', '', '', 'Slice.Accounting', '', '', 'Process.ExchangeDifference.3', 'Расходы по КР', 'Sign.Acct.Dt', 'Account.ExpenseSellOut', '', '', '', '', '', 'Role.Entity.Entry', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ExchangeDifference.4', 'Process.ExchangeDifference', '', '', '', 'Slice.Accounting', '', '', 'Process.ExchangeDifference.4', 'Доходы по КР', 'Sign.Acct.Ct', 'Account.IncomeSellOut', '', '', '', '', '', 'Role.Entity.Entry', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ExchangeDifference.5', 'Process.ExchangeDifference', '', '', 'Face.', 'Slice.Accounting', '', '', 'Process.ExchangeDifference.5', 'Кредиторская задолж-ть по КР', 'Sign.Acct.Ct', 'Account.Seller', '', 'Deal.', '', '', '', 'Role.Entity.Entry', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ExchangeDifference.6', 'Process.ExchangeDifference', '', '', 'Face.', 'Slice.Accounting', '', '', 'Process.ExchangeDifference.6', 'Дебиторская задолж-ть по КР', 'Sign.Acct.Dt', 'Account.Customer', '', 'Deal.', '', '', '', 'Role.Entity.Entry', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.InputInitialBalance', 'Process.', '', '', '', 'Slice.Accounting', '', '', 'Process.InputInitialBalance', 'Ввод нач остатков', '', '', '', '', '', '', '', 'Role.Entity.Entry', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.InputInitialBalance.1', 'Process.InputInitialBalance', '', 'Face.', 'Face.', 'Slice.Accounting', '', '', 'Process.InputInitialBalance.1', 'Ввод остатков.кол-во', 'Sign.Acct', 'Account.', 'Asset.', 'Deal.', 'Item.', 'Debt.', '', '', '', 'Meter.Quantity', '', 'Unit.', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.InputInitialBalance.2', 'Process.InputInitialBalance', '', 'Face.', 'Face.', 'Slice.Accounting', '', '', 'Process.InputInitialBalance.2', 'Ввод остатков.сумма', 'Sign.Acct', 'Account.', 'Asset.', 'Deal.', 'Item.', 'Debt.', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary', 'Process.', '', 'Face.FA1.AdmStaff', '', 'Slice.Accounting', '', '', 'Process.MainSalary', 'Начисление ЗП и налогов', '', '', '', '', '', '', '', 'Role.Workbook.StartPoint', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.1', 'Process.MainSalary', '', 'Face.', '', 'Slice.Accounting', '', '', 'Process.MainSalary.1', 'Табелирование.рабочие дни', 'Sign.HRA', '', '', 'Deal.enbek.staff', '', '', 'Price.TariffHour', 'Role.Entity.Salary', 'Info.Generic.Main', 'Meter.Quantity', '', 'Unit.WorkDay', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.1A', 'Process.MainSalary', '', 'Face.', '', 'Slice.Accounting', '', '', 'Process.MainSalary.1A', 'Табелирование.рабочие часы', 'Sign.HRA', '', '', 'Deal.enbek.staff', '', '', 'Price.TariffHour', 'Role.Entity.Salary', 'Info.Generic.Variant', 'Meter.Quantity', '', 'Unit.WorkHour', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.2', 'Process.MainSalary', '', 'Face.', '', 'Slice.Accounting', '', '', 'Process.MainSalary.2', 'Начисления', '', '', '', '', 'Item.Salary', '', '', 'Role.Entity.SalarySheet', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.2A', 'Process.MainSalary.2', '', 'Face.', '', 'Slice.Accounting', '', '', 'Process.MainSalary.2A', 'Оклад', 'Sign.Acct.Ct', 'Account.Salary', '', '', 'Item.Salary', 'Debt.Salary.Main', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.2B', 'Process.MainSalary.2', '', 'Face.', '', 'Slice.Accounting', '', '', 'Process.MainSalary.2B', 'Премия', 'Sign.Acct.Ct', 'Account.Salary', '', '', 'Item.Salary', 'Debt.Salary.Extra', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.2C', 'Process.MainSalary.2', '', 'Face.', '', 'Slice.Accounting', '', '', 'Process.MainSalary.2C', 'Отпускные', 'Sign.Acct.Ct', 'Account.Salary', '', '', 'Item.Salary', 'Debt.Salary.VacationPay', '', '', 'Info.Generic.Variant', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.2D', 'Process.MainSalary.2', '', 'Face.', '', 'Slice.Accounting', '', '', 'Process.MainSalary.2D', 'Компенсация за отпуск', 'Sign.Acct.Ct', 'Account.Salary', '', '', 'Item.Salary', 'Debt.Salary.VacationCompensation', '', '', 'Info.Generic.Variant', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.2E', 'Process.MainSalary.2', '', '', '', 'Slice.Accounting', '', '', 'Process.MainSalary.2E', 'Расход', 'Sign.Acct.Dt', 'Account.ExpenseCost', '', '', 'Item.Salary', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.3', 'Process.MainSalary', '', '', '', 'Slice.Accounting', '', '', 'Process.MainSalary.3', 'Удержания, налоги, отчисления', '', '', '', '', '', '', '', 'Role.Entity.SalarySheet', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.3A', 'Process.MainSalary.3', '', '', '', 'Slice.Accounting', '', '', 'Process.MainSalary.3A', 'Вычеты ИПН', 'Sign.Tax.Ct', '', '', '', '', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.3B', 'Process.MainSalary.3', '', '', '', 'Slice.Accounting', '', '', 'Process.MainSalary.3B', 'База ОПВ', 'Sign.Tax.Ct', '', '', '', '', 'Debt.Pension.Base', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.3C', 'Process.MainSalary.3', '', 'Face.', 'Face.', 'Slice.Accounting', '', '', 'Process.MainSalary.3C', 'Удержание ОПВ', 'Sign.Acct.Ct', 'Account.TaxPension', '', '', '', 'Debt.Pension.OPV', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.3D', 'Process.MainSalary.3', '', '', '', 'Slice.Accounting', '', '', 'Process.MainSalary.3D', 'База взносов ОСМС', 'Sign.Tax.Ct', '', '', '', '', 'Debt.OSMS.Base', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.3E', 'Process.MainSalary.3', '', '', '', 'Slice.Accounting', '', '', 'Process.MainSalary.3E', 'Удержание взносов ОСМС', 'Sign.Acct.Ct', 'Account.TaxOSMSEmployeePay', '', '', '', 'Debt.OSMS.EmployeePay', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.3F', 'Process.MainSalary.3', '', '', '', 'Slice.Accounting', '', '', 'Process.MainSalary.3F', 'База ИПН', 'Sign.Tax.Ct', '', '', '', '', 'Debt.IncomePerson.Base', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.3G', 'Process.MainSalary.3', '', '', '', 'Slice.Accounting', '', '', 'Process.MainSalary.3G', 'Удержание ИПН', 'Sign.Acct.Ct', 'Account.TaxIncomePerson', '', '', '', 'Debt.IncomePersonTax', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.3H', 'Process.MainSalary.3', '', '', '', 'Slice.Accounting', '', '', 'Process.MainSalary.3H', 'База алиментов', 'Sign.Tax.Ct', '', '', '', '', 'Debt.DeductionSalary.Alimony', '', '', 'Info.Generic.Variant', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.3I', 'Process.MainSalary.3', '', '', '', 'Slice.Accounting', '', '', 'Process.MainSalary.3I', 'Алименты.начисление получателям', 'Sign.Acct.Ct', 'Account.TaxAlimony', '', '', '', 'Debt.DeductionSalary.Alimony', '', '', 'Info.Generic.Variant', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.3J', 'Process.MainSalary.3', '', '', '', 'Slice.Accounting', '', '', 'Process.MainSalary.3J', 'Всего удержания из ЗП', 'Sign.Acct.Dt', 'Account.Salary', '', '', '', 'Debt.DeductionSalary', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.3K', 'Process.MainSalary.3', '', '', '', 'Slice.Accounting', '', '', 'Process.MainSalary.3K', 'База отчислений ГФСС', 'Sign.Tax.Ct', '', '', '', '', 'Debt.GFSS.Base', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.3L', 'Process.MainSalary.3', '', '', '', 'Slice.Accounting', '', '', 'Process.MainSalary.3L', 'Начисление отчислений ГФСС', 'Sign.Acct.Ct', 'Account.TaxGFSS', '', '', '', 'Debt.GFSS', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.3LA', 'Process.MainSalary.3', '', '', '', 'Slice.Accounting', '', '', 'Process.MainSalary.3LA', 'Расходы по отчислениям ГФСС', 'Sign.Acct.Dt', 'Account.ExpenseCost', '', '', 'Item.Salary', 'Debt.GFSS', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.3M', 'Process.MainSalary.3', '', '', '', 'Slice.Accounting', '', '', 'Process.MainSalary.3M', 'База СН', 'Sign.Tax.Ct', '', '', '', '', 'Debt.SN.Base', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.3N', 'Process.MainSalary.3', '', '', '', 'Slice.Accounting', '', '', 'Process.MainSalary.3N', 'Расходы по отчислениям СН', 'Sign.Acct.Dt', 'Account.ExpenseCost', '', '', 'Item.Salary', 'Debt.SN', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.3NA', 'Process.MainSalary.3', '', '', '', 'Slice.Accounting', '', '', 'Process.MainSalary.3NA', 'Начисление СН', 'Sign.Acct.Ct', 'Account.TaxSN', '', '', '', 'Debt.SN', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.3O', 'Process.MainSalary.3', '', '', '', 'Slice.Accounting', '', '', 'Process.MainSalary.3O', 'База отчислений ОСМС', 'Sign.Tax.Ct', '', '', '', '', 'Debt.OSMS.Base', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.3P', 'Process.MainSalary.3', '', '', '', 'Slice.Accounting', '', '', 'Process.MainSalary.3P', 'Расходы по отчислениям ОСМС', 'Sign.Acct.Dt', 'Account.ExpenseCost', '', '', 'Item.Salary', 'Debt.OSMS.EmployerFee', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.3Q', 'Process.MainSalary.3', '', '', '', 'Slice.Accounting', '', '', 'Process.MainSalary.3Q', 'Начисление отчислений ОСМС', 'Sign.Acct.Ct', 'Account.TaxOSMSEmployeeFee', '', '', '', 'Debt.OSMS.EmployerFee', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.4', 'Process.MainSalary', '', '', '', 'Slice.Accounting', '', '', 'Process.MainSalary.4', 'Реестры платежей', '', '', '', '', '', '', '', '', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.4A', 'Process.MainSalary.4', 'Face.FA1.Bank1', 'Face.', 'Face.GCVP', 'Slice.Accounting', '', '', 'Process.MainSalary.4A', 'Составление реестра платежей', '', '', '', '', '', '', '', 'Role.Entity.PaySheet', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.4B', 'Process.MainSalary.4', 'Face.FA1.Bank1', 'Face.', 'Face.', 'Slice.Accounting', '', '', 'Process.MainSalary.4B', 'Плат поручение исх', 'Sign.MoneyFlow.Output.026', '', '', '', '', '', '', 'Role.Entity.PayOrder', 'Info.Code.KNP', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.4C', 'Process.MainSalary.4', 'Face.FA1.Bank1', '', '', 'Slice.Accounting', '', '', 'Process.MainSalary.4C', 'Списание ДС', 'Sign.Acct.Ct', 'Account.Money', 'Asset.Money', '', 'Item.Salary', '', '', 'Role.Entity.BankStatement', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.4D', 'Process.MainSalary.4', '', 'Face.', 'Face.', 'Slice.Accounting', '', '', 'Process.MainSalary.4D', 'Списание задолженности', 'Sign.Acct.Dt', 'Account.Tax', '', '', 'Item.Salary', '', '', 'Role.Entity.BankStatement', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.5', 'Process.MainSalary', 'Face.FA1.Bank1', '', '', 'Slice.Accounting', '', '', 'Process.MainSalary.5', 'Возврат реестра платежей', 'Sign.MoneyFlow.Input.016', '', '', '', '', 'Debt.', '', 'Role.Entity.PaySheet', 'Info.Generic.Variant', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.5A', 'Process.MainSalary.5', '', 'Face.', 'Face.GCVP', 'Slice.Accounting', '', '', 'Process.MainSalary.5A', 'Восстановление задолж-ти', 'Sign.Acct.Ct', 'Account.Tax', '', '', 'Item.Salary', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.MainSalary.5B', 'Process.MainSalary.5', 'Face.FA1.Bank1', '', '', 'Slice.Accounting', '', '', 'Process.MainSalary.5B', 'Поступление ДС', 'Sign.Acct.Dt', 'Account.Money', 'Asset.Money', '', 'Item.Salary', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.PaySalary', 'Process.', '', '', '', 'Slice.Accounting', '', '', 'Process.PaySalary', 'Выплата ЗП', '', '', '', '', '', '', '', 'Role.Entity.SalaryPaySheet', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.PaySalary.1', 'Process.PaySalary', '', '', '', 'Slice.Accounting', '', '', 'Process.PaySalary.1', 'Выплата ЗП через банк', '', '', '', '', 'Item.Salary', '', '', '', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.PaySalary.1A', 'Process.PaySalary.1', 'Face.FA1.Bank1', '', 'Face.', 'Slice.Accounting', '', '', 'Process.PaySalary.1A', 'Плат поручение исх', 'Sign.MoneyFlow.Output.023', '', 'Asset.Money', '', 'Item.Salary', '', '', 'Role.Entity.PayOrder', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.PaySalary.1B', 'Process.PaySalary.1', '', 'Face.', 'Face.', 'Slice.Accounting', '', '', 'Process.PaySalary.1B', 'Списание задолж-ти по ЗП', 'Sign.Acct.Dt', 'Account.Salary', '', 'Deal.enbek.staff', 'Item.Salary', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.PaySalary.1C', 'Process.PaySalary.1', 'Face.FA1.Bank1', '', '', 'Slice.Accounting', '', '', 'Process.PaySalary.1C', 'Списание ДС', 'Sign.Acct.Ct', 'Account.Money', '', '', 'Item.Salary', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.PaySalary.2', 'Process.PaySalary', '', '', '', 'Slice.Accounting', '', '', 'Process.PaySalary.2', 'Возврат выплаты ЗП из банка', 'Sign.MoneyFlow.Input.016', '', '', '', '', '', '', '', 'Info.Generic.Variant', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.PaySalary.2A', 'Process.PaySalary.2', '', 'Face.', 'Face.', 'Slice.Accounting', '', '', 'Process.PaySalary.2A', 'Восстановление задолж-ти по ЗП', 'Sign.Acct.Ct', 'Account.Salary', '', 'Deal.enbek.staff', 'Item.Salary', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.PaySalary.2B', 'Process.PaySalary.2', 'Face.FA1.Bank1', '', '', 'Slice.Accounting', '', '', 'Process.PaySalary.2B', 'Поступление ДС', 'Sign.Acct.Dt', 'Account.Money', '', '', 'Item.Salary', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.PaySalary.3', 'Process.PaySalary', '', '', '', 'Slice.Accounting', '', '', 'Process.PaySalary.3', 'Выплата ЗП через кассу', 'Sign.MoneyFlow.Output.023', '', '', '', 'Item.Salary', '', '', '', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.PaySalary.3A', 'Process.PaySalary.3', '', 'Face.', 'Face.', 'Slice.Accounting', '', '', 'Process.PaySalary.3A', 'Списание задолж-ти по ЗП', 'Sign.Acct.Dt', 'Account.Salary', '', 'Deal.enbek.staff', 'Item.Salary', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.PaySalary.3B', 'Process.PaySalary.3', 'Face.FA1.Cash1', '', '', 'Slice.Accounting', '', '', 'Process.PaySalary.3B', 'Списание ДС', 'Sign.Acct.Ct', 'Account.Money', '', '', 'Item.Salary', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.PettyCash', 'Process.', '', '', '', 'Slice.Accounting', '', '', 'Process.PettyCash', 'Аванс в подотчет', '', '', '', '', '', '', '', 'Role.Workbook.StartPoint', 'Info.Generic.Main', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.PettyCash.1', 'Process.PettyCash', '', '', '', 'Slice.Accounting', '', '', 'Process.PettyCash.1', 'Согласование выдачи аванса в подотчет', '', '', '', 'Deal.', 'Item.Impress', '', '', 'Role.Entity.Imprest', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.PettyCash.2 (Payment)', 'Process.PettyCash.1', 'Face.FA1.Cash1', 'Face.', '', 'Slice.Accounting', '', '', 'Process.PettyCash.2 (Payment)', 'Выдача аванса в подотчет', 'Sign.MoneyFlow.Output.022', '', '', '', '', '', '', 'Role.Entity.OutputCash', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.PettyCash.2A', 'Process.PettyCash.2 (Payment)', 'Face.FA1.Cash1', 'Face.', '', 'Slice.Accounting', '', '', 'Process.PettyCash.2A', 'Выплата ДС', 'Sign.Acct.Ct', 'Account.Money', 'Asset.Money', '', 'Item.Impress', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.PettyCash.2B', 'Process.PettyCash.2 (Payment)', '', 'Face.', '', 'Slice.Accounting', '', '', 'Process.PettyCash.2B', 'Начисление подотчета', 'Sign.Acct.Dt', 'Account.Imprest', '', '', 'Item.Impress', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.PettyCash.3 (Imprest)', 'Process.PettyCash', '', 'Face.', 'Face.', 'Slice.Accounting', '', '', 'Process.PettyCash.3 (Imprest)', 'Погашение кредиторской задолж-ти', '', '', '', '', '', '', '', 'Role.Entity.Imprest', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.PettyCash.3A', 'Process.PettyCash.3 (Imprest)', '', 'Face.', 'Face.', 'Slice.Accounting', '', '', 'Process.PettyCash.3A', 'Списание кредиторской задолж-ти', 'Sign.Acct.Dt', 'Account.Seller', '', 'Deal.', 'Item.Impress', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.PettyCash.3B', 'Process.PettyCash.3 (Imprest)', '', 'Face.', '', 'Slice.Accounting', '', '', 'Process.PettyCash.3B', 'Списание подотчетной суммы', 'Sign.Acct.Ct', 'Account.Imprest', '', '', 'Item.Impress', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.PettyCash.4 (ReturnCash)', 'Process.PettyCash.2 (Payment)', '', '', '', 'Slice.Accounting', '', '', 'Process.PettyCash.4 (ReturnCash)', 'Возврат аванса из подотчета', 'Sign.MoneyFlow.Input.016', '', '', '', '', '', '', 'Role.Entity.InputCash', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.PettyCash.4A', 'Process.PettyCash.4 (ReturnCash)', 'Face.FA1.Cash1', 'Face.', '', 'Slice.Accounting', '', '', 'Process.PettyCash.4A', 'Поступление ДС', 'Sign.Acct.Dt', 'Account.Money', 'Asset.Money', '', 'Item.Impress', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.PettyCash.4B', 'Process.PettyCash.4 (ReturnCash)', '', 'Face.', '', 'Slice.Accounting', '', '', 'Process.PettyCash.4B', 'Списание подотчета', 'Sign.Acct.Ct', 'Account.Imprest', '', '', 'Item.Impress', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Price', 'Process.', '', 'Face.', '', 'Slice.Accounting', '', '', 'Process.Price', 'Прайс-лист', '', '', '', '', '', '', '', 'Role.Workbook.StartPoint', 'Info.Generic.Main', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Price.1', 'Process.Price', '', 'Face.', '', 'Slice.Accounting', '', '', 'Process.Price.1', 'Согласование прайса', '', '', 'Asset.', 'Deal.', '', '', 'Price.', 'Role.Entity.PriceList', '', 'Meter.Quantity', '1', 'Unit.Doc', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Price.2', 'Process.Price', '', 'Face.', '', 'Slice.Accounting', '', '', 'Process.Price.2', 'Утверждение прайса', 'Sign.Price', '', 'Asset.', 'Deal.', '', '', 'Price.', 'Role.Entity.PriceList', '', 'Meter.Price', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.', '', 'Face.FA1', '', '', 'Slice.Accounting', '', '', 'Process.', 'ProcessData', '', '', '', '', '', '', '', 'Role.Entity.Process', 'Info.Entity.Reference', '', '', 'Unit.KZT', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ReturnBuy', 'Process.', '', '', '', 'Slice.Accounting', '', '', 'Process.ReturnBuy', 'Возврат поставщику', '', '', '', '', '', '', '', 'Role.Workbook.StartPoint', 'Info.Generic.Variant', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ReturnBuy.1', 'Process.ReturnBuy', 'Face.FA1.Store1', 'Face.', 'Face.', 'Slice.Accounting', '', '', 'Process.ReturnBuy.1', 'Согласование возврата поставщику', '', '', 'Asset.', 'Deal.', '', '', 'Price.', 'Role.Entity.Return', '', 'Meter.Quantity', '', 'Unit.', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ReturnBuy.2 (BuyStorno)', 'Process.ReturnBuy.1', '', '', '', 'Slice.Accounting', '', '', 'Process.ReturnBuy.2 (BuyStorno)', 'Возврат активов поставщику', '', '', '', '', '', '', '', 'Role.Entity.Return', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ReturnBuy.2A', 'Process.ReturnBuy.2 (BuyStorno)', 'Face.FA1.Store1', 'Face.', 'Face.', 'Slice.Accounting', '', '', 'Process.ReturnBuy.2A', 'Приход активов\кол-во (сторно)', 'Sign.Acct.Dt', 'Account.Asset', 'Asset.', 'Deal.', 'Item.Purchase', '', 'Price.', '', '', 'Meter.Quantity', 'storno', 'Unit.', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ReturnBuy.2B', 'Process.ReturnBuy.2 (BuyStorno)', '', '', '', 'Slice.Accounting', '', '', 'Process.ReturnBuy.2B', 'Приход активов\себ-ть (сторно)', 'Sign.Acct.Dt', 'Account.Asset', 'Asset.', 'Deal.', 'Item.Purchase', '', 'Price.', '', '', 'Meter.Amount', 'storno', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ReturnBuy.2C', 'Process.ReturnBuy.2 (BuyStorno)', '', '', 'Face.', 'Slice.Accounting', '', '', 'Process.ReturnBuy.2C', 'Списание кредиторской задолж-сти (сторно)', 'Sign.Acct.Ct', 'Account.Seller', '', 'Deal.', 'Item.Purchase', '', '', '', '', 'Meter.Amount', 'storno', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ReturnBuy.2D (VATStorno)', 'Process.ReturnBuy.2 (BuyStorno)', '', '', '', 'Slice.Accounting', '', '', 'Process.ReturnBuy.2D (VATStorno)', 'Начисление НДС зачета (сторно)', 'Sign.Acct.Dt', 'Account.TaxVATOut', '', 'Deal.kgd.tax', 'Item.Purchase', 'Debt.VAT.Purchase.RateMain', '', '', '', 'Meter.Amount', 'storno', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ReturnBuy.2E (VATBaseStorno)', 'Process.ReturnBuy.2 (BuyStorno)', '', '', '', 'Slice.Accounting', '', '', 'Process.ReturnBuy.2E (VATBaseStorno)', 'Налоговая база НДС зачета (сторно)', 'Sign.Tax.Ct', '', '', 'Deal.kgd.tax', 'Item.Purchase', 'Debt.VAT.Purchase.RateMain', '', '', 'Info.Tax.Base', 'Meter.Amount', 'storno', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ReturnBuy.3 (ReturnMoney)', 'Process.ReturnBuy.1', '', '', '', 'Slice.Accounting', '', '', 'Process.ReturnBuy.3 (ReturnMoney)', 'Возврат ДС поставщиком', '', '', '', '', '', '', '', 'Role.Entity.Money', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ReturnBuy.3A', 'Process.ReturnBuy.3 (ReturnMoney)', 'Face.', '', 'Face.FA1.Bank1', 'Slice.Accounting', '', '', 'Process.ReturnBuy.3A', 'Плат поручение вх', 'Sign.MoneyFlow.Input.016', '', 'Asset.Money', 'Deal.', 'Item.Purchase', '', '', 'Role.Entity.PayOrder', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ReturnBuy.3B', 'Process.ReturnBuy.3 (ReturnMoney)', 'Face.FA1.Bank1', '', 'Face.', 'Slice.Accounting', '', '', 'Process.ReturnBuy.3B', 'Поступление ДС', 'Sign.Acct.Dt', 'Account.Money', 'Asset.Money', 'Deal.', 'Item.Purchase', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ReturnBuy.3C', 'Process.ReturnBuy.3 (ReturnMoney)', '', '', 'Face.', 'Slice.Accounting', '', '', 'Process.ReturnBuy.3C', 'Восстановление кредиторской задолж-ти', 'Sign.Acct.Ct', 'Account.Seller', '', 'Deal.', 'Item.Purchase', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ReturnBuy.4 (InvoiceStorno)', 'Process.ReturnBuy.2 (BuyStorno)', 'Face.', '', 'Face.FA1', 'Slice.Accounting', '', '', 'Process.ReturnBuy.4 (InvoiceStorno)', 'Получение счета-фактуры (сторно)', '', '', '', 'Deal.', 'Item.Purchase', '', '', 'Role.Entity.Invoice', 'Info.Generic.Main', '', 'storno', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ReturnSell', 'Process.', '', '', '', 'Slice.Accounting', '', '', 'Process.ReturnSell', 'Процесс Возврат от покупателя', '', '', '', '', '', '', '', 'Role.Workbook.StartPoint', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ReturnSell.1', 'Process.ReturnSell', 'Face.FA1.Store1', 'Face.', 'Face.', 'Slice.Accounting', '', '', 'Process.ReturnSell.1', 'Согласование возврата от покупателя', '', '', 'Asset.', 'Deal.', 'Item.Sell', '', 'Price.', 'Role.Entity.Return', '', 'Meter.Quantity', '', 'Unit.', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ReturnSell.2 (SellStorno)', 'Process.ReturnSell.1', '', '', '', 'Slice.Accounting', '', '', 'Process.ReturnSell.2 (SellStorno)', 'Исполнение возврата от покупателя', '', '', '', '', '', '', '', 'Role.Entity.Return', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ReturnSell.2A (Storno)', 'Process.ReturnSell.2 (SellStorno)', 'Face.FA1.Store1', '', 'Face.', 'Slice.Accounting', '', '', 'Process.ReturnSell.2A (Storno)', 'Расход активов\кол-во (сторно)', 'Sign.Acct.Ct', 'Account.Asset', 'Asset.', '', 'Item.Sell', '', '', '', 'Info.Cost.Accounting', 'Meter.Quantity', 'storno', 'Unit.', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ReturnSell.2B (Storno)', 'Process.ReturnSell.2 (SellStorno)', '', '', '', 'Slice.Accounting', '', '', 'Process.ReturnSell.2B (Storno)', 'Расход активов\сумма (сторно)', 'Sign.Acct.Ct', 'Account.Asset', 'Asset.', '', 'Item.Sell', '', '', '', 'Info.Cost.Accounting', 'Meter.Amount', 'storno', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ReturnSell.2C (Storno)', 'Process.ReturnSell.2 (SellStorno)', '', 'Face.', 'Face.', 'Slice.Accounting', '', '', 'Process.ReturnSell.2C (Storno)', 'Списание дебиторской задолж-ти (сторно)', 'Sign.Acct.Dt', 'Account.Customer', '', 'Deal.', 'Item.Sell', '', '', '', '', 'Meter.Amount', 'storno', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ReturnSell.2D (Storno)', 'Process.ReturnSell.2 (SellStorno)', '', 'Face.', 'Face.', 'Slice.Accounting', '', '', 'Process.ReturnSell.2D (Storno)', 'Признание расхода (сторно)', 'Sign.Acct.Dt', 'Account.ExpenseCost', '', '', 'Item.Sell', '', '', '', 'Info.Cost.Accounting', 'Meter.Cost', 'storno', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ReturnSell.2E (Storno)', 'Process.ReturnSell.2 (SellStorno)', '', 'Face.', 'Face.', 'Slice.Accounting', '', '', 'Process.ReturnSell.2E (Storno)', 'Признание дохода (сторно)', 'Sign.Acct.Ct', 'Account.IncomeSell', '', '', 'Item.Sell', '', '', '', '', 'Meter.Amount', 'storno', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ReturnSell.2F (VATStorno)', 'Process.ReturnSell.2 (SellStorno)', '', '', '', 'Slice.Accounting', '', '', 'Process.ReturnSell.2F (VATStorno)', 'Начисление НДС реализации (сторно)', 'Sign.Acct.Ct', 'Account.TaxVATOut', '', 'Deal.kgd.tax', 'Item.Sell', 'Debt.VAT.Sell.RateMain', '', '', '', 'Meter.Amount', 'storno', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ReturnSell.2G (IncomeTaxBaseStorno)', 'Process.ReturnSell.2 (SellStorno)', '', '', '', 'Slice.Accounting', '', '', 'Process.ReturnSell.2G (IncomeTaxBaseStorno)', 'Налоговая база КПН (сторно)', 'Sign.Tax.Ct', '', '', 'Deal.kgd.tax', 'Item.Sell', 'Debt.Income', '', '', 'Info.Tax.Base', 'Meter.Amount', 'storno', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ReturnSell.2H (VATBaseStorno)', 'Process.ReturnSell.2 (SellStorno)', '', '', '', 'Slice.Accounting', '', '', 'Process.ReturnSell.2H (VATBaseStorno)', 'Налоговая база НДС реализации (сторно)', 'Sign.Tax.Ct', '', '', 'Deal.kgd.tax', 'Item.Sell', 'Debt.VAT.Sell.RateMain', '', '', 'Info.Tax.Base', 'Meter.Amount', 'storno', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ReturnSell.3 (Money)', 'Process.ReturnSell.1', '', '', 'Face.', 'Slice.Accounting', '', '', 'Process.ReturnSell.3 (Money)', 'Оплата возврата от покупателя', '', '', '', 'Deal.', '', '', '', 'Role.Entity.Money', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ReturnSell.3A', 'Process.ReturnSell.3 (Money)', 'Face.FA1.Bank1', '', 'Face.', 'Slice.Accounting', '', '', 'Process.ReturnSell.3A', 'Плат поручение исх', 'Sign.MoneyFlow.Output.027', '', 'Asset.Money', 'Deal.', 'Item.Sell', 'Debt.', '', 'Role.Entity.PayOrder', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ReturnSell.3B', 'Process.ReturnSell.3 (Money)', 'Face.FA1.Bank1', '', 'Face.', 'Slice.Accounting', '', '', 'Process.ReturnSell.3B', 'Выбытие ДС', 'Sign.Acct.Ct', 'Account.Money', 'Asset.Money', 'Deal.', 'Item.Sell', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ReturnSell.3C', 'Process.ReturnSell.3 (Money)', '', '', 'Face.', 'Slice.Accounting', '', '', 'Process.ReturnSell.3C', 'Восстановление дебиторской задолж-ти', 'Sign.Acct.Dt', 'Account.Customer', '', 'Deal.', 'Item.Sell', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.ReturnSell.4 (InvoiceStorno)', 'Process.ReturnSell.2 (SellStorno)', '', '', 'Face.', 'Slice.Accounting', '', '', 'Process.ReturnSell.4 (InvoiceStorno)', 'Выставление счета-фактуры покупателю (сторно)', '', '', '', 'Deal.', 'Item.Sell', '', '', 'Role.Entity.Invoice', 'Info.Generic.Main', '', 'storno', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Revise', 'Process.', '', '', '', 'Slice.Report', '', '', 'Process.Revise', 'Акт сверки', '', '', '', '', '', '', '', 'Role.Entity.Doc-Process', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Revise.1', 'Process.Revise', '', 'Face.', 'Face.', 'Slice.Report', '', '', 'Process.Revise.1', 'Согласование акта сверки', 'Sign.Acct', 'Account.', '', 'Deal.', '', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Revise.2', 'Process.Revise', '', 'Face.', 'Face.', 'Slice.Report', '', '', 'Process.Revise.2', 'Подписание акта сверки', 'Sign.Acct', 'Account.', '', 'Deal.', '', '', '', 'Role.Entity.Revise', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Sell', 'Process.', '', '', '', 'Slice.Accounting', '', '', 'Process.Sell', 'Реализация', '', '', '', '', '', '', '', 'Role.Workbook.StartPoint', 'Info.Generic.Main', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Sell.1', 'Process.Sell', '', 'Face.', 'Face.', 'Slice.Accounting', '', '', 'Process.Sell.1', 'Согласование исх договора', '', '', 'Asset.', '', 'Item.Sell', '', 'Price.', 'Role.Entity.Deal', '', 'Meter.', '', 'Unit.', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Sell.2 (Contract)', 'Process.Sell.1', '', 'Face.', 'Face.', 'Slice.Accounting', '', '', 'Process.Sell.2 (Contract)', 'Новый договор', '', '', '', 'Deal.', 'Item.Sell', '', '', 'Role.Entity.Deal', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Sell.3 (Order)', 'Process.Sell.2 (Contract)', '', 'Face.', 'Face.', 'Slice.Accounting', '', '', 'Process.Sell.3 (Order)', 'Выставление исх счета', '', '', '', 'Deal.', '', '', '', 'Role.Entity.Order', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Sell.3A', 'Process.Sell.3 (Order)', '', 'Face.', 'Face.', 'Slice.Plan', '', '', 'Process.Sell.3A', 'Реализация менеджеров (план)', 'Sign.Acct.Ct', 'Account.IncomeSell', '', 'Deal.', 'Item.Sell', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Sell.3B', 'Process.Sell.3 (Order)', '', '', '', 'Slice.Plan', '', '', 'Process.Sell.3B', 'Себест-ть (план)', 'Sign.Acct.Dt', 'Account.ExpenseCost', '', '', 'Item.Sell', '', '', '', '', 'Meter.Cost', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Sell.3C', 'Process.Sell.3 (Order)', '', 'Face.', 'Face.', 'Slice.Plan', '', '', 'Process.Sell.3C', 'Оплата исх счета (план)', 'Sign.Acct.Dt', 'Account.Money', '', '', 'Item.Sell', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Sell.4 (Money)', 'Process.Sell.3 (Order)', '', '', 'Face.', 'Slice.Accounting', '', '', 'Process.Sell.4 (Money)', 'Оплата исх счета', '', '', '', 'Deal.', 'Item.Sell', '', '', 'Role.Entity.Money', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Sell.4A', 'Process.Sell.4 (Money)', 'Face.', '', 'Face.FA1.Bank1', 'Slice.Accounting', '', '', 'Process.Sell.4A', 'Плат поручение вх', 'Sign.MoneyFlow.Input.011', '', 'Asset.Money', 'Deal.', 'Item.Sell', '', '', 'Role.Entity.PayOrder', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Sell.4B', 'Process.Sell.4 (Money)', 'Face.FA1.Bank1', '', 'Face.', 'Slice.Accounting', '', '', 'Process.Sell.4B', 'Поступление ДС', 'Sign.Acct.Dt', 'Account.Money', 'Asset.Money', 'Deal.', 'Item.Sell', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Sell.4C', 'Process.Sell.4 (Money)', '', '', 'Face.', 'Slice.Accounting', '', '', 'Process.Sell.4C', 'Списание деб задолж-ти', 'Sign.Acct.Ct', 'Account.Customer', '', 'Deal.', 'Item.Sell', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Sell.5 (Consumption)', 'Process.Sell.3 (Order)', '', '', '', 'Slice.Accounting', '', '', 'Process.Sell.5 (Consumption)', 'Исполнение исх счета', '', '', '', '', '', '', '', 'Role.Entity.Sell', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Sell.5A', 'Process.Sell.5 (Consumption)', '', 'Face.', 'Face.', 'Slice.Accounting', '', '', 'Process.Sell.5A', 'Получение вх доверенности', '', '', 'Asset.', 'Deal.', 'Item.Sell', '', '', 'Role.Entity.Warrant', '', 'Meter.', '', 'Unit.', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Sell.5B', 'Process.Sell.5 (Consumption)', '', 'Face.', 'Face.', 'Slice.Accounting', '', '', 'Process.Sell.5B', 'Начисление деб задолж-ти', 'Sign.Acct.Dt', 'Account.Customer', '', 'Deal.', 'Item.Sell', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Sell.5C', 'Process.Sell.5 (Consumption)', 'Face.FA1.Store1', '', '', 'Slice.Accounting', '', '', 'Process.Sell.5C', 'Списание себест-ти активов\кол-во', 'Sign.Acct.Ct', 'Account.Asset', 'Asset.', '', 'Item.Cost', '', '', '', 'Info.Cost.Accounting', 'Meter.Quantity', '', 'Unit.', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Sell.5D', 'Process.Sell.5 (Consumption)', 'Face.FA1.Store1', '', '', 'Slice.Accounting', '', '', 'Process.Sell.5D', 'Списание себест-ти активов\себ-ть', 'Sign.Acct.Ct', 'Account.Asset', 'Asset.', '', 'Item.Cost', '', '', '', 'Info.Cost.Accounting', 'Meter.Cost', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Sell.5E', 'Process.Sell.5 (Consumption)', '', '', '', 'Slice.Accounting', '', '', 'Process.Sell.5E', 'Списание амортизации активов', 'Sign.Acct.Dt', 'Account.FixedAssetDepreciation', 'Asset.', '', 'Item.Cost', 'Debt.DepreciationAccounting', '', '', 'Info.Cost.Accounting', 'Meter.Cost', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Sell.5F (VATBase)', 'Process.Sell.5 (Consumption)', '', '', '', 'Slice.Accounting', '', '', 'Process.Sell.5F (VATBase)', 'Налоговая база НДС реализации', 'Sign.Tax.Ct', '', '', 'Deal.kgd.tax', 'Item.Sell', 'Debt.VAT.Base', '', '', 'Info.Tax.Base', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Sell.5G (IncomeTaxBase)', 'Process.Sell.5 (Consumption)', '', '', '', 'Slice.Accounting', '', '', 'Process.Sell.5G (IncomeTaxBase)', 'Налоговая база КПН', 'Sign.Tax.Ct', '', '', 'Deal.kgd.tax', 'Item.Sell', 'Debt.Income.Base', '', '', 'Info.Tax.Base', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Sell.5H (VAT)', 'Process.Sell.5 (Consumption)', '', '', '', 'Slice.Accounting', '', '', 'Process.Sell.5H (VAT)', 'Начисление НДС реализации', 'Sign.Acct.Ct', 'Account.TaxVATOut', '', 'Deal.kgd.tax', 'Item.Sell', 'Debt.VAT.Sell.RateMain', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Sell.5I', 'Process.Sell.5 (Consumption)', '', 'Face.', 'Face.', 'Slice.Accounting', '', '', 'Process.Sell.5I', 'Признание расхода', 'Sign.Acct.Dt', 'Account.ExpenseCost', '', '', 'Item.Sell', '', '', '', 'Info.Cost.Accounting', 'Meter.Cost', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Sell.5J', 'Process.Sell.5 (Consumption)', '', 'Face.', 'Face.', 'Slice.Accounting', '', '', 'Process.Sell.5J', 'Признание дохода', 'Sign.Acct.Ct', 'Account.IncomeSell', '', '', 'Item.Sell', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Sell.6 (Invoice)', 'Process.Sell.5 (Consumption)', '', '', 'Face.', 'Slice.Accounting', '', '', 'Process.Sell.6 (Invoice)', 'Выставление счета-фактуры покупателю', '', '', '', 'Deal.', 'Item.Sell', '', '', 'Role.Entity.Invoice', 'Info.Generic.Main', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Sell.7 (Null)', 'Process.Sell.3 (Order)', '', '', '', 'Slice.Accounting', '', '', 'Process.Sell.7 (Null)', 'Аннулирование исх счета', '', '', 'Asset.', 'Deal', 'Item.Sell', '', 'Price.', 'Role.Entity.Order', 'Info.Generic.Variant', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.StaffDoc', 'Process.', '', '', '', 'Slice.Accounting', '', '', 'Process.StaffDoc', 'Кадровый приказ', 'Sign.HRA', '', '', '', '', '', '', 'Role.Entity.StaffDoc', 'Info.Generic.Main', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.StaffDoc.1', 'Process.StaffDoc', '', 'Face.', '', 'Slice.Accounting', '', '', 'Process.StaffDoc.1', 'Прием на работу', 'Sign.HRA', '', '', 'Deal.', '', '', '', '', '', 'Meter.Quantity', '1', 'Unit.Hiring', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.StaffDoc.2', 'Process.StaffDoc', '', 'Face.', '', 'Slice.Accounting', '', '', 'Process.StaffDoc.2', 'Командировка', 'Sign.HRA', '', '', 'Deal.', '', '', '', '', '', 'Meter.Quantity', '1', 'Unit.OtherPersonnelEvent', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.StaffDoc.3', 'Process.StaffDoc', '', 'Face.', '', 'Slice.Accounting', '', '', 'Process.StaffDoc.3', 'Поощрение', 'Sign.HRA', '', '', 'Deal.', '', '', '', '', '', 'Meter.Quantity', '1', 'Unit.Promotion', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.StaffDoc.4', 'Process.StaffDoc', '', 'Face.', '', 'Slice.Accounting', '', '', 'Process.StaffDoc.4', 'Изменение оклада', 'Sign.HRA', '', '', 'Deal.', '', '', '', '', '', 'Meter.Quantity', '1', 'Unit.OtherPersonnelEvent', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.StaffDoc.5', 'Process.StaffDoc', '', 'Face.', '', 'Slice.Accounting', '', '', 'Process.StaffDoc.5', 'Взыскание', 'Sign.HRA', '', '', 'Deal.', '', '', '', '', '', 'Meter.Quantity', '1', 'Unit.Punishment', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.StaffDoc.6', 'Process.StaffDoc', '', 'Face.', '', 'Slice.Accounting', '', '', 'Process.StaffDoc.6', 'Отпуск', 'Sign.HRA', '', '', 'Deal.', '', '', '', '', '', 'Meter.Quantity', '1', 'Unit.OtherPersonnelEvent', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.StaffDoc.7', 'Process.StaffDoc', '', 'Face.', '', 'Slice.Accounting', '', '', 'Process.StaffDoc.7', 'Увольнение', 'Sign.HRA', '', '', 'Deal.', '', '', '', '', '', 'Meter.Quantity', '1', 'Unit.Dismissal', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Storno', 'Process.', '', '', '', 'Slice.Accounting', '', '', 'Process.Storno', 'Процесс Сторно', 'Sign.Acct.Ct-Dt', 'Account.', '', '', '', '', '', 'Role.Workbook.StartPoint', '', 'Meter.', 'storno', 'Unit.', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.TaxPay', 'Process.', '', '', '', 'Slice.Accounting', '', '', 'Process.TaxPay', 'Начисление и оплата налога', 'Sign.Tax.Ct', '', '', '', '', '', '', 'Role.Workbook.StartPoint', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.TaxPay.1', 'Process.TaxPay', '', '', '', 'Slice.Accounting', '', '', 'Process.TaxPay.1', 'Задолженность по налогу', 'Sign.Acct.Ct', 'Account.Tax', '', 'Deal.kgd.tax', '', 'Debt.', '', 'Role.Entity.Entry', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.TaxPay.2', 'Process.TaxPay', '', '', '', 'Slice.Accounting', '', '', 'Process.TaxPay.2', 'Затраты по налогу', 'Sign.Acct.Dt', 'Account.ExpenseCost', '', '', 'Item.Tax', 'Debt.', '', 'Role.Entity.Entry', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.TaxPay.3', 'Process.TaxPay', 'Face.FA1.Bank1', '', 'Face.', 'Slice.Accounting', '', '', 'Process.TaxPay.3', 'Плат поручение исх', 'Sign.Tax.KNP', '', 'Asset.Money', 'Deal.', 'Item.Tax', 'Debt.', '', 'Role.Entity.PayOrder', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.TaxPay.4', 'Process.TaxPay', 'Face.FA1.Bank1', '', '', 'Slice.Accounting', '', '', 'Process.TaxPay.4', 'Оплата налога', 'Sign.Acct.Ct', 'Account.Money', 'Asset.Money', '', 'Item.Tax', 'Debt.', '', 'Role.Entity.Money', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.TaxPay.5', 'Process.TaxPay', '', '', '', 'Slice.Accounting', '', '', 'Process.TaxPay.5', 'Списание задолж-ти по налогу', 'Sign.Acct.Dt', 'Account.Tax', '', 'Deal.kgd.tax', 'Item.Tax', 'Debt.', '', 'Role.Entity.Money', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Transfer', 'Process.', '', '', '', 'Slice.Accounting', '', '', 'Process.Transfer', 'Перемещение активов', '', '', '', '', '', '', '', 'Role.Workbook.StartPoint', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Transfer.1', 'Process.Transfer', '', '', '', 'Slice.Accounting', '', '', 'Process.Transfer.1', 'Согласование перемещения активов', '', '', 'Asset.', '', '', '', '', 'Role.Entity.Transfer', '', 'Meter.Quantity', '', 'Unit.', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Transfer.2 (Transfer)', 'Process.Transfer.1', '', '', '', 'Slice.Accounting', '', '', 'Process.Transfer.2 (Transfer)', 'Пер-е активов', '', '', 'Asset.', '', '', '', '', 'Role.Entity.Transfer', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Transfer.2A', 'Process.Transfer.2 (Transfer)', 'Face.FA1.Store1', '', '', 'Slice.Accounting', '', '', 'Process.Transfer.2A', 'Отпуск активов.кол-во', 'Sign.Acct.Ct', 'Account.Asset', 'Asset.', '', '', '', '', '', 'Info.Cost.Accounting', 'Meter.Quantity', '', 'Unit.', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Transfer.2B', 'Process.Transfer.2 (Transfer)', 'Face.FA1.Store1', '', '', 'Slice.Accounting', '', '', 'Process.Transfer.2B', 'Отпуск активов.себ-ть сумма', 'Sign.Acct.Ct', 'Account.Asset', 'Asset.', '', '', '', '', '', 'Info.Cost.Accounting', 'Meter.Cost', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Transfer.2C', 'Process.Transfer.2 (Transfer)', 'Face.FA1.AdmStaff', '', '', 'Slice.Accounting', '', '', 'Process.Transfer.2C', 'Прием активов.кол-во', 'Sign.Acct.Dt', 'Account.Asset', 'Asset.', '', '', '', '', '', 'Info.Cost.Accounting', 'Meter.Quantity', '', 'Unit.', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Transfer.2D', 'Process.Transfer.2 (Transfer)', 'Face.FA1.AdmStaff', '', '', 'Slice.Accounting', '', '', 'Process.Transfer.2D', 'Прием активов.себ-ть сумма', 'Sign.Acct.Dt', 'Account.Asset', 'Asset.', '', '', '', '', '', 'Info.Cost.Accounting', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.TransferMoney', 'Process.', '', '', '', 'Slice.Accounting', '', '', 'Process.TransferMoney', 'Перемещение ДС', 'Sign.MoneyFlow.Input.016', '', '', '', '', '', '', 'Role.Entity.Money', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.TransferMoney.1', 'Process.TransferMoney', 'Face.FA1.Bank1', '', '', 'Slice.Accounting', '', '', 'Process.TransferMoney.1', 'Плат поручение исх', 'Sign.MoneyFlow.Output.027', '', 'Asset.Money', '', '', '', '', 'Role.Entity.PayOrder', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.TransferMoney.2', 'Process.TransferMoney', 'Face.FA1.Bank1', '', '', 'Slice.Accounting', '', '', 'Process.TransferMoney.2', 'Списание ДС при отправке', 'Sign.Acct.Ct', 'Account.Money', 'Asset.Money', '', '', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.TransferMoney.3', 'Process.TransferMoney', 'Face.FA1.Cash1', '', '', 'Slice.Accounting', '', '', 'Process.TransferMoney.3', 'Оприходование ДС при получении', 'Sign.Acct.Dt', 'Account.Money', 'Asset.Money', '', '', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Writeoff', 'Process.', '', '', '', 'Slice.Accounting', '', '', 'Process.Writeoff', 'Списание активов', '', '', '', '', '', '', '', 'Role.Workbook.StartPoint', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Writeoff.1', 'Process.Writeoff', 'Face.FA1.Store1', '', '', 'Slice.Accounting', '', '', 'Process.Writeoff.1', 'Согласование спис-я активов', '', '', 'Asset.', '', 'Item.Writeoff', '', '', 'Role.Entity.WriteOff', '', 'Meter.Amount', '', 'Unit.', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Writeoff.2  (Consumption)', 'Process.Writeoff.1', '', '', '', 'Slice.Accounting', '', '', 'Process.Writeoff.2  (Consumption)', 'Спис-е активов', '', '', 'Asset.', '', '', '', '', 'Role.Entity.WriteOff', '', '', '', '', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Writeoff.2A', 'Process.Writeoff.2  (Consumption)', 'Face.FA1.Store1', '', '', 'Slice.Accounting', '', '', 'Process.Writeoff.2A', 'Спис-е активов.кол-во', 'Sign.Acct.Ct', 'Account.Asset', 'Asset.', '', 'Item.Writeoff', '', '', '', 'Info.Cost.Accounting', 'Meter.Amount', '', 'Unit.', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Writeoff.2B', 'Process.Writeoff.2  (Consumption)', '', '', '', 'Slice.Accounting', '', '', 'Process.Writeoff.2B', 'Спис-е активов.себ-ть сумма', 'Sign.Acct.Ct', 'Account.Asset', 'Asset.', '', 'Item.Writeoff', '', '', '', 'Info.Cost.Accounting', 'Meter.Cost', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Writeoff.2C', 'Process.Writeoff.2  (Consumption)', '', '', '', 'Slice.Accounting', '', '', 'Process.Writeoff.2C', 'Спис-е склада.расход', 'Sign.Acct.Dt', 'Account.ExpenseCost', '', '', 'Item.Writeoff', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Writeoff.3 (Arrival)', 'Process.Writeoff.2  (Consumption)', '', '', '', 'Slice.Accounting', '', '', 'Process.Writeoff.3 (Arrival)', 'Приход других активов после спис-я', '', '', 'Asset.', '', '', '', '', 'Role.Generic.Variant', '', 'Meter.Amount', '', 'Unit.', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Writeoff.3A', 'Process.Writeoff.3 (Arrival)', 'Face.FA1.Store1', '', '', 'Slice.Accounting', '', '', 'Process.Writeoff.3A', 'Приход активов.кол-во', 'Sign.Acct.Dt', 'Account.Asset', 'Asset.', '', 'Item.Writeoff', '', '', '', 'Info.Cost.Accounting', 'Meter.Amount', '', 'Unit.', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Writeoff.3B', 'Process.Writeoff.3 (Arrival)', '', '', '', 'Slice.Accounting', '', '', 'Process.Writeoff.3B', 'Приход активов.себ-ть сумма', 'Sign.Acct.Dt', 'Account.Asset', 'Asset.', '', 'Item.Writeoff', '', '', '', 'Info.Cost.Accounting', 'Meter.Cost', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');
INSERT INTO Process (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Sign, Account, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More) VALUES ('Process.Writeoff.3C', 'Process.Writeoff.3 (Arrival)', '', '', '', 'Slice.Accounting', '', '', 'Process.Writeoff.3C', 'Приход склада.доход', 'Sign.Acct.Ct', 'Account.IncomeSell', '', '', 'Item.Writeoff', '', '', '', '', 'Meter.Amount', '', 'Unit.CurrUnit', '{"AbcBasic": "Process.Basic"}');

-- Таблица: Role
CREATE TABLE IF NOT EXISTS [Role](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Role(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[More] TEXT
 );
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.', '', '', '', 'Role.', 'RoleData', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Account', 'Role.', '', '', 'Role.Account', 'Account', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Account.Asset', 'Role.Account', '', '', 'Role.Account.Asset', 'счет активов', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Account.Budget', 'Role.Account', '', '', 'Role.Account.Budget', 'счет бюджета', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Account.Capital', 'Role.Account', '', '', 'Role.Account.Capital', 'счет капитала', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Account.Depreciation', 'Role.Account', '', '', 'Role.Account.Depreciation', 'счет амортизации', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Account.Face', 'Role.Account', '', '', 'Role.Account.Face', 'счет лиц', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Account.FixedAsset', 'Role.Account', '', '', 'Role.Account.FixedAsset', 'счет основных средств', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Account.Group1Level', 'Role.Account', '', '', 'Role.Account.Group1Level', 'группа счетов 1 уровня', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Account.Group2Level', 'Role.Account', '', '', 'Role.Account.Group2Level', 'группа счетов 2 уровня', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Account.Money', 'Role.Account', '', '', 'Role.Account.Money', 'счет денег', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Account.Other', 'Role.Account', '', '', 'Role.Account.Other', 'счет прочий', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Account.Production', 'Role.Account', '', '', 'Role.Account.Production', 'счет производства', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Account.Salary', 'Role.Account', '', '', 'Role.Account.Salary', 'счет зарплаты', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Account.Tax', 'Role.Account', '', '', 'Role.Account.Tax', 'счет налогов и платежей', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.AccTable', 'Role.', '', '', 'Role.AccTable', 'AccountTable', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.AccTable.1997', 'Role.AccTable', '1997-01-01', '2004-12-31', 'Role.AccTable.1997', 'генеральный план счетов 1997', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.AccTable.2005', 'Role.AccTable', '2005-01-01', '2018-12-31', 'Role.AccTable.2005', 'типовой план счетов 2005', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.AccTable.2019', 'Role.AccTable', '2019-01-01', '', 'Role.AccTable.2019', 'типовой план счетов 2019', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.AccTable.OffBalance', 'Role.AccTable', '', '', 'Role.AccTable.OffBalance', 'забалансовый', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.AccTable.Work', 'Role.AccTable', '', '', 'Role.AccTable.Work', 'рабочий план счетов', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Asset', 'Role.', '', '', 'Role.Asset', 'Asset', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Asset.BioAsset', 'Role.Asset', '', '', 'Role.Asset.BioAsset', 'биологический актив', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Asset.Building', 'Role.Asset', '', '', 'Role.Asset.Building', 'здание', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Asset.Car', 'Role.Asset', '', '', 'Role.Asset.Car', 'автотранспорт', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Asset.Coverall', 'Role.Asset', '', '', 'Role.Asset.Coverall', 'спецодежда', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Asset.Furniture', 'Role.Asset', '', '', 'Role.Asset.Furniture', 'мебель', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Asset.Good', 'Role.Asset', '', '', 'Role.Asset.Good', 'товар', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Asset.IntangibleAsset', 'Role.Asset', '', '', 'Role.Asset.IntangibleAsset', 'нематериальные активы', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Asset.Land', 'Role.Asset', '', '', 'Role.Asset.Land', 'земля', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Asset.LineBusiness', 'Role.Asset', '', '', 'Role.Asset.LineBusiness', 'направление деятельности', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Asset.Machine', 'Role.Asset', '', '', 'Role.Asset.Machine', 'машинное оборудование', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Asset.Material', 'Role.Asset', '', '', 'Role.Asset.Material', 'материал', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Asset.Money', 'Role.Asset', '', '', 'Role.Asset.Money', 'денежные средства', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Asset.Mortgage', 'Role.Asset', '', '', 'Role.Asset.Mortgage', 'залоговое имущество', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Asset.OfficeEquipment', 'Role.Asset', '', '', 'Role.Asset.OfficeEquipment', 'офисное оборудование', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Asset.OtherFixedAsset', 'Role.Asset', '', '', 'Role.Asset.OtherFixedAsset', 'прочие ОС', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Asset.Production', 'Role.Asset', '', '', 'Role.Asset.Production', 'готовая продукция', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Asset.Project', 'Role.Asset', '', '', 'Role.Asset.Project', 'проект', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Asset.Service', 'Role.Asset', '', '', 'Role.Asset.Service', 'услуга', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Asset.Tool', 'Role.Asset', '', '', 'Role.Asset.Tool', 'инструмент', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Asset.Work', 'Role.Asset', '', '', 'Role.Asset.Work', 'работа', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Asset.UnfinishedWork', 'Role.Asset', '', '', 'Role.Asset.UnfinishedWork', 'незавершенное производство, стр-во', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Currency', 'Role.', '', '', 'Role.Currency', 'Currency', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Currency.AccountingCurrency', 'Role.Currency', '', '', 'Role.Currency.AccountingCurrency', 'учетная валюта', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Currency.ExchangeCurrency', 'Role.Currency', '', '', 'Role.Currency.ExchangeCurrency', 'курс валюты', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Deal', 'Role.', '', '', 'Role.Deal', 'Deal', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Deal.AddAgreement', 'Role.Deal', '', '', 'Role.Deal.AddAgreement', 'дополнительное соглашение', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Deal.Appendix', 'Role.Deal', '', '', 'Role.Deal.Appendix', 'приложение', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Deal.Devivery', 'Role.Deal', '', '', 'Role.Deal.Devivery', 'поставка договора', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Deal.Frame', 'Role.Deal', '', '', 'Role.Deal.Frame', 'рамочный договор', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Deal.Basic', 'Role.Deal', '', '', 'Role.Deal.Basic', 'разовая сделка', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Deal.Spec', 'Role.Deal', '', '', 'Role.Deal.Spec', 'спецификация', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity', 'Role.', '', '', 'Role.Entity', 'Entity', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.Account', 'Role.Entity', '', '', 'Role.Entity.Account', 'бухсчета', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.Asset-Deal', 'Role.Entity', '', '', 'Role.Entity.Asset-Deal', 'активы-договора', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.Asset-Unit', 'Role.Entity', '', '', 'Role.Entity.Asset-Unit', 'активы-ед. изм.', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.Balance', 'Role.Entity', '', '', 'Role.Entity.Balance', 'остатки', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.Bank', 'Role.Entity', '', '', 'Role.Entity.Bank', 'банк', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.BankStatement', 'Role.Entity', '', '', 'Role.Entity.BankStatement', 'выписка банка', '{"FullName": "Выписка банка","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.Budget', 'Role.Entity', '', '', 'Role.Entity.Budget', 'бюджет', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.Country-Currency', 'Role.Entity', '', '', 'Role.Entity.Country-Currency', 'страны-валюты', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.Deal', 'Role.Entity', '', '', 'Role.Entity.Deal', 'сделка', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.Doc-Process', 'Role.Entity', '', '', 'Role.Entity.Doc-Process', 'документ-процесс', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.Entry', 'Role.Entity', '', '', 'Role.Entity.Entry', 'бухгалтерская справка', '{"FullName": "Бухгалтерская справка","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.ExtraCalc', 'Role.Entity', '', '', 'Role.Entity.ExtraCalc', 'расчет премии', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.Face-Deal', 'Role.Entity', '', '', 'Role.Entity.Face-Deal', 'лица-сделки', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.Imprest', 'Role.Entity', '', '', 'Role.Entity.Imprest', 'авансовый отчет', '{"FullName": "Авансовый отчет","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.InputCash', 'Role.Entity', '', '', 'Role.Entity.InputCash', 'приходный кассовый ордер', '{"FullName": "Приходный кассовый ордер","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.Invoice', 'Role.Entity', '', '', 'Role.Entity.Invoice', 'счет-фактура (ЭСФ)', '{"FullName": "Счет-фактура","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.Workbook', 'Role.Entity', '', '', 'Role.Entity.Workbook', 'журнал', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.MainTable', 'Role.Entity', '', '', 'Role.Entity.MainTable', 'общие таблицы', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.Money', 'Role.Entity', '', '', 'Role.Entity.Money', 'денежные средства', '{"FullName": "Кассовая книга","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.Order', 'Role.Entity', '', '', 'Role.Entity.Order', 'счет', '{"FullName": "Счет","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.OutputCash', 'Role.Entity', '', '', 'Role.Entity.OutputCash', 'расходный кассовый ордер', '{"FullName": "Расходный кассовый ордер","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.PayOrder', 'Role.Entity', '', '', 'Role.Entity.PayOrder', 'платежное поручение', '{"FullName": "Платежное поручение","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.PaySheet', 'Role.Entity', '', '', 'Role.Entity.PaySheet', 'реестр платежей по ЗП', '{"FullName": "Реестр","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.PriceList', 'Role.Entity', '', '', 'Role.Entity.PriceList', 'прайс-лист', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.Process', 'Role.Entity', '', '', 'Role.Entity.Process', 'процесс', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.Purchase', 'Role.Entity', '', '', 'Role.Entity.Purchase', 'приходная накладная', '{"FullName": "Приходная накладная","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.Return', 'Role.Entity', '', '', 'Role.Entity.Return', 'возвратная накладная', '{"FullName": "Возвратная накладная","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.Revise', 'Role.Entity', '', '', 'Role.Entity.Revise', 'акт сверки', '{"FullName": "Акт сверки","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.SalaryAverageCalc', 'Role.Entity', '', '', 'Role.Entity.SalaryAverageCalc', 'расчет по средней ЗП', '{"AbcBasci": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.Salary', 'Role.Entity', '', '', 'Role.Entity.Salary', 'зарплата', '{"AbcBasci": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.SalaryInquery', 'Role.Entity', '', '', 'Role.Entity.SalaryInquery', 'справка по ЗП', '{"AbcBasci": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.SalaryPaySheet', 'Role.Entity', '', '', 'Role.Entity.SalaryPaySheet', 'ведомость выплаты ЗП', '{"FullName": "Платежая ведомость по зарплате","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.SalarySheet', 'Role.Entity', '', '', 'Role.Entity.SalarySheet', 'начисление зарплаты', '{"FullName": "Расчетная ведомость начисления зарплаты","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.SalarySummary', 'Role.Entity', '', '', 'Role.Entity.SalarySummary', 'свод ЗП', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.Sell', 'Role.Entity', '', '', 'Role.Entity.Sell', 'реализация', '{"FullName": "Расходная накладная","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.Staff', 'Role.Entity', '', '', 'Role.Entity.Staff', 'сотрудники', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.StaffDoc', 'Role.Entity', '', '', 'Role.Entity.StaffDoc', 'кадровый приказ', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.Store', 'Role.Entity', '', '', 'Role.Entity.Store', 'склад', '{"FullName": "Товарно-транспортная накладная","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.Tax-Face', 'Role.Entity', '', '', 'Role.Entity.Tax-Face', 'налоги-лица', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.Transfer', 'Role.Entity', '', '', 'Role.Entity.Transfer', 'накладная перемещения', '{"FullName": "Накладная на перемещение активов","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.Warrant', 'Role.Entity', '', '', 'Role.Entity.Warrant', 'доверенность', '{"FullName": "Доверенность","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Entity.WriteOff', 'Role.Entity', '', '', 'Role.Entity.WriteOff', 'списание', '{"FullName": "Акт списания","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Exchange', 'Role.', '', '', 'Role.Exchange', 'ExchangeData', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Exchange.EsfXML', 'Role.ExchangeData', '', '', 'Role.Exchange.EsfXML', 'ESF XML', '{"AbcExchange": "Exchange.Basic","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Exchange.MT100', 'Role.ExchangeData', '', '', 'Role.Exchange.MT100', 'swift MT-100 (платежки)', '{"AbcExchange": "Exchange.Basic","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Exchange.MT102', 'Role.ExchangeData', '', '', 'Role.Exchange.MT102', 'swift MT-102 (зарплата)', '{"AbcExchange": "Exchange.Basic","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Exchange.SwiftGFSS', 'Role.ExchangeData', '', '', 'Role.Exchange.SwiftGFSS', 'swift ГФСС', '{"AbcExchange": "Exchange.Basic","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Exchange.SwiftOPV', 'Role.ExchangeData', '', '', 'Role.Exchange.SwiftOPV', 'swift ОПВ', '{"AbcExchange": "Exchange.Basic","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Exchange.SwiftOSMS', 'Role.ExchangeData', '', '', 'Role.Exchange.SwiftOSMS', 'swift отч ОСМС', '{"AbcExchange": "Exchange.Basic","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Exchange.Tax100-01', 'Role.ExchangeData', '', '', 'Role.Exchange.Tax100-01', 'ф100.01', '{"AbcExchange": "Exchange.Basic","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Face', 'Role.', '', '', 'Role.Face', 'Face', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Face.Bank', 'Role.Face', '', '', 'Role.Face.Bank', 'банк', '{"KBE": "15","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Face.ContractWorker', 'Role.Face', '', '', 'Role.Face.ContractWorker', 'работник по договору', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Face.Customer', 'Role.Face', '', '', 'Role.Face.Customer', 'покупатель', '{"KBE": "17","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Face.ExternalWorker', 'Role.Face', '', '', 'Role.Face.ExternalWorker', 'внешний совместитель', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Face.FA', 'Role.Face', '', '', 'Role.Face.FA', 'лицо учета', '{"KBE": "17","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Face.Foreigner', 'Role.Face', '', '', 'Role.Face.Foreigner', 'иностранный персонал', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Face.GCVP', 'Role.Face', '', '', 'Role.Face.GCVP', 'НАО-ГЦВП', '{"KBE": "11","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Face.Seller', 'Role.Face', '', '', 'Role.Face.Seller', 'поставщик', '{"KBE": "17","AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Face.Staff', 'Role.Face', '', '', 'Role.Face.Staff', 'штатный работник', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Face.State', 'Role.Face', '', '', 'Role.Face.State', 'госорган', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Generic', 'Role.', '', '', 'Role.Generic', 'Generic', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Generic.Code', 'Role.Generic', '', '', 'Role.Generic.Code', 'код', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Generic.Description', 'Role.Generic', '', '', 'Role.Generic.Description', 'расшифровка', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Generic.Extra', 'Role.Generic', '', '', 'Role.Generic.Extra', 'необычный', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Generic.FullName', 'Role.Generic', '', '', 'Role.Generic.FullName', 'полное наименование', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Generic.List', 'Role.Generic', '', '', 'Role.Generic.List', 'список', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Generic.Basic', 'Role.Generic', '', '', 'Role.Generic.Basic', 'общая инфо', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Generic.ShortName', 'Role.Generic', '', '', 'Role.Generic.ShortName', 'сокращенное наименование', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Generic.Time', 'Role.Generic', '', '', 'Role.Generic.Time', 'время', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Generic.Variant', 'Role.Generic', '', '', 'Role.Generic.Variant', 'вариант', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Geo', 'Role.', '', '', 'Role.Geo', 'Geo', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Geo.City', 'Role.Geo', '', '', 'Role.Geo.City', 'город', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Geo.Country', 'Role.Geo', '', '', 'Role.Geo.Country', 'страна', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Geo.County', 'Role.Geo', '', '', 'Role.Geo.County', 'область', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Geo.District', 'Role.Geo', '', '', 'Role.Geo.District', 'район', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Geo.House', 'Role.Geo', '', '', 'Role.Geo.House', 'дом', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Geo.Region', 'Role.Geo', '', '', 'Role.Geo.Region', 'регион', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Geo.Street', 'Role.Geo', '', '', 'Role.Geo.Street', 'улица', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Geo.Township', 'Role.Geo', '', '', 'Role.Geo.Township', 'поселок', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Geo.Union', 'Role.Geo', '', '', 'Role.Geo.Union', 'союз стран', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Geo.Village', 'Role.Geo', '', '', 'Role.Geo.Village', 'село', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Geo.WorldOrg', 'Role.Geo', '', '', 'Role.Geo.WorldOrg', 'международная организация', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Workbook', 'Role.', '', '', 'Role.Workbook', 'Workbook', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Workbook.ChangeMark', 'Role.Workbook', '', '', 'Role.Workbook.ChangeMark', 'change mark', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Workbook.Line1Manual', 'Role.Workbook', '', '', 'Role.Workbook.Line1Manual', 'строка ручного ввода (первичная)', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Workbook.Line2Calc', 'Role.Workbook', '', '', 'Role.Workbook.Line2Calc', 'доп строка расчета (вторичная)', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Workbook.StartPoint', 'Role.Workbook', '', '', 'Role.Workbook.StartPoint', 'стартовая точка', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Policy', 'Role.', '', '', 'Role.Policy', 'Policy', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Policy.CanChangeDayAgo', 'Role.Policy', '', '', 'Role.Policy.CanChangeDayAgo', 'изменять число дней назад', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Policy.MustAuth', 'Role.Policy', '', '', 'Role.Policy.MustAuth', 'обязательная авторизация', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Policy.MustFill', 'Role.Policy', '', '', 'Role.Policy.MustFill', 'обязательно заполнять', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Policy.NoChange', 'Role.Policy', '', '', 'Role.Policy.NoChange', 'не изменять', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Policy.NoDelete', 'Role.Policy', '', '', 'Role.Policy.NoDelete', 'не удалять', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Policy.NoRound', 'Role.Policy', '', '', 'Role.Policy.NoRound', 'не округлять до целого', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Policy.NoView', 'Role.Policy', '', '', 'Role.Policy.NoView', 'не отображать', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Policy.ToZero', 'Role.Policy', '', '', 'Role.Policy.ToZero', 'обнулять', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Price', 'Role.', '', '', 'Role.Price', 'Price', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Price.AddFee', 'Role.Price', '', '', 'Role.Price.AddFee', 'доп сбор к тарифу', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Price.Basic', 'Role.Price', '', '', 'Role.Price.Basic', 'цена ТРУ', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Price.Percent', 'Role.Price', '', '', 'Role.Price.Percent', 'процент', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Price.Tariff', 'Role.Price', '', '', 'Role.Price.Tariff', 'тариф', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.PriceChange', 'Role.', '', '', 'Role.PriceChange', 'PriceChange', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.PriceChange.Action', 'Role.PriceChange', '', '', 'Role.PriceChange.Action', 'акция', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.PriceChange.FreePiece', 'Role.PriceChange', '', '', 'Role.PriceChange.FreePiece', 'бесплатный экземпляр', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.PriceChange.Markup', 'Role.PriceChange', '', '', 'Role.PriceChange.Markup', 'надбавка, наценка', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.PriceChange.Sale', 'Role.PriceChange', '', '', 'Role.PriceChange.Sale', 'скидка', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Rate', 'Role.', '', '', 'Role.Rate', 'Rate', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Rate.MaxRate', 'Role.Rate', '', '', 'Role.Rate.MaxRate', 'максимальный показатель', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Rate.MinRate', 'Role.Rate', '', '', 'Role.Rate.MinRate', 'минимальный показатель', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Rate.Ratio', 'Role.Rate', '', '', 'Role.Rate.Ratio', 'коэффициент', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.RegData', 'Role.', '', '', 'Role.RegData', 'RegData', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.RegData.ExternalNumber', 'Role.RegData', '', '', 'Role.RegData.ExternalNumber', 'внешний номер', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.RegData.License', 'Role.RegData', '', '', 'Role.RegData.License', 'лицензия', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.RegData.Passport', 'Role.RegData', '', '', 'Role.RegData.Passport', 'паспорт', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.RegData.RegDescription', 'Role.RegData', '', '', 'Role.RegData.RegDescription', 'официальное наименование', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.RegData.Sert', 'Role.RegData', '', '', 'Role.RegData.Sert', 'сертификат', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.RegData.TaxNumber', 'Role.RegData', '', '', 'Role.RegData.TaxNumber', 'налоговый номер', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.ReportFrame', 'Role.', '', '', 'Role.ReportFrame', 'структура отчета', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.ReportFrame.Body', 'Role.ReportFrame', '', '', 'Role.ReportFrame.Body', 'тело', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.ReportFrame.Column1', 'Role.ReportFrame', '', '', 'Role.ReportFrame.Column1', 'колонка1', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.ReportFrame.Column2', 'Role.ReportFrame', '', '', 'Role.ReportFrame.Column2', 'колонка2', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.ReportFrame.Column3', 'Role.ReportFrame', '', '', 'Role.ReportFrame.Column3', 'колонка3', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.ReportFrame.Footer', 'Role.ReportFrame', '', '', 'Role.ReportFrame.Footer', 'подвал', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.ReportFrame.Header', 'Role.ReportFrame', '', '', 'Role.ReportFrame.Header', 'заголовок', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Sign', 'Role.', '', '', 'Role.Sign', 'Sign', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Sign.AccTable', 'Role.Sign', '', '', 'Role.Sign.AccTable', 'план счетов', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Sign.Budget', 'Role.Sign', '', '', 'Role.Sign.Budget', 'бюджет', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Sign.HRA', 'Role.Sign', '', '', 'Role.Sign.HRA', 'кадры', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Sign.MoneyFlow', 'Role.Sign', '', '', 'Role.Sign.MoneyFlow', 'ДДС', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Sign.Store-Traffic', 'Role.Sign', '', '', 'Role.Sign.Store-Traffic', 'склад, транспорт', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Sign.Tax', 'Role.Sign', '', '', 'Role.Sign.Tax', 'налоги', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.StaffTable', 'Role.', '', '', 'Role.StaffTable', 'StaffTable', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.StaffTable.4day', 'Role.StaffTable', '', '', 'Role.StaffTable.4day', '4-дневка', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.StaffTable.5day', 'Role.StaffTable', '', '', 'Role.StaffTable.5day', '5-дневка', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.StaffTable.6day', 'Role.StaffTable', '', '', 'Role.StaffTable.6day', '6-дневка', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.StaffTable.7day', 'Role.StaffTable', '', '', 'Role.StaffTable.7day', '7-дневка', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Store', 'Role.', '', '', 'Role.Store', 'Store', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Store.Bank', 'Role.Store', '', '', 'Role.Store.Bank', 'текущий банковский счет', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Store.BankPersonAccount', 'Role.Store', '', '', 'Role.Store.BankPersonAccount', 'карт-счет физлица', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Store.Cash', 'Role.Store', '', '', 'Role.Store.Cash', 'касса', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Store.Construction', 'Role.Store', '', '', 'Role.Store.Construction', 'объект строительства', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Store.Department', 'Role.Store', '', '', 'Role.Store.Department', 'отдел', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Store.Depo', 'Role.Store', '', '', 'Role.Store.Depo', 'депозитный счет', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Store.Main', 'Role.Store', '', '', 'Role.Store.Main', 'оптовый склад', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Store.Pallet', 'Role.Store', '', '', 'Role.Store.Pallet', 'паллета', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Store.Rack', 'Role.Store', '', '', 'Role.Store.Rack', 'стеллаж', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Store.Retail', 'Role.Store', '', '', 'Role.Store.Retail', 'розничный склад', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Store.Shelf', 'Role.Store', '', '', 'Role.Store.Shelf', 'полка', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Store.Shop', 'Role.Store', '', '', 'Role.Store.Shop', 'цех', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Store.Staff', 'Role.Store', '', '', 'Role.Store.Staff', 'работник', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.TaxBase', 'Role.', '', '', 'Role.TaxBase', 'TaxBase', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.TaxBase.CostBrutto', 'Role.TaxBase', '', '', 'Role.TaxBase.CostBrutto', 'расход брутто', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.TaxBase.CostNetto', 'Role.TaxBase', '', '', 'Role.TaxBase.CostNetto', 'расход нетто', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.TaxBase.ExchangeRateDelta', 'Role.TaxBase', '', '', 'Role.TaxBase.ExchangeRateDelta', 'разница валютных курсов', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.TaxBase.FixedAssetNetto', 'Role.TaxBase', '', '', 'Role.TaxBase.FixedAssetNetto', 'стоимость ФА нетто', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.TaxBase.CoreFundNetto', 'Role.TaxBase', '', '', 'Role.TaxBase.CoreFundNetto', 'стоимость ОС-НМА нетто', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.TaxBase.ImportNetto', 'Role.TaxBase', '', '', 'Role.TaxBase.ImportNetto', 'облагаемый импорт нетто', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.TaxBase.IncomeBrutto', 'Role.TaxBase', '', '', 'Role.TaxBase.IncomeBrutto', 'доход брутто', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.TaxBase.IncomeNetto', 'Role.TaxBase', '', '', 'Role.TaxBase.IncomeNetto', 'доход нетто', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.TaxBase.SalaryBrutto', 'Role.TaxBase', '', '', 'Role.TaxBase.SalaryBrutto', 'зарплата брутто', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.TaxBase.SalaryNetto1', 'Role.TaxBase', '', '', 'Role.TaxBase.SalaryNetto1', 'зарплата нетто 1 (база ИПН)', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.TaxBase.SellBrutto', 'Role.TaxBase', '', '', 'Role.TaxBase.SellBrutto', 'реализация брутто (вх и исх)', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.TaxBase.SellNetto', 'Role.TaxBase', '', '', 'Role.TaxBase.SellNetto', 'реализация нетто (вх и исх)', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.TaxDetail', 'Role.', '', '', 'Role.TaxDetail', 'TaxDetail', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.TaxDetail.DepreciationLineMonth', 'Role.TaxDetail', '', '', 'Role.TaxDetail.DepreciationLineMonth', 'амортизация линейно помесячно', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.TaxDetail.DepreciationYearTax', 'Role.TaxDetail', '', '', 'Role.TaxDetail.DepreciationYearTax', 'амортизация по году налоговая', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.TaxDetail.ExcRateDelta1', 'Role.TaxDetail', '', '', 'Role.TaxDetail.ExcRateDelta1', 'разница одного вида вал курса одной валюты между разными датами', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.TaxDetail.ExcRateDelta2', 'Role.TaxDetail', '', '', 'Role.TaxDetail.ExcRateDelta2', 'разница разных видов вал курсов одной даты', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.TaxDetail.InputSell', 'Role.TaxDetail', '', '', 'Role.TaxDetail.InputSell', 'входящая реализация', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.TaxDetail.OutputSell', 'Role.TaxDetail', '', '', 'Role.TaxDetail.OutputSell', 'исходящая реализация', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.TaxMode', 'Role.', '', '', 'Role.TaxMode', 'TaxMode', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.TaxMode.Basic', 'Role.TaxMode', '', '', 'Role.TaxMode.Basic', 'общеустановленный', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.TaxMode.Patent', 'Role.TaxMode', '', '', 'Role.TaxMode.Patent', 'патент', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.TaxMode.Simple', 'Role.TaxMode', '', '', 'Role.TaxMode.Simple', 'упрощенный', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.TaxMode.WorkContract', 'Role.TaxMode', '', '', 'Role.TaxMode.WorkContract', 'договор ГПХ', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Unit', 'Role.', '', '', 'Role.Unit', 'Unit', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Unit.Auth', 'Role.Unit', '', '', 'Role.Unit.Auth', 'ЕИ аутентификации', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Unit.Derivative', 'Role.Unit', '', '', 'Role.Unit.Derivative', 'производная ЕИ', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.Unit.Basic', 'Role.Unit', '', '', 'Role.Unit.Basic', 'базовая ЕИ', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.TaxBase.SalaryNetto2', 'Role.TaxBase', '', '', 'Role.TaxBase.SalaryNetto2', 'зарплата нетто 2 (на руки)', '{"AbcBasic": "Role.Basic"}');
INSERT INTO Role (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Role.TaxMode.Foreigner', 'Role.TaxMode', '', '', 'Role.TaxMode.Foreigner', 'нерезидент', '{"AbcBasic": "Role.Basic"}');

-- Таблица: Sign
CREATE TABLE IF NOT EXISTS [Sign](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Sign(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Role] TEXT references Role(Id),
	[Info] TEXT references Info(Id),
	[More] TEXT
 );
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Acct.Ct', 'Sign.Acct', '', '', 'Sign.Acct.Ct', 'Счет.Кредит', 'Role.Sign.AccTable', 'Info.Sign.UseEntry', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Acct.Ct-Dt', 'Sign.Acct', '', '', 'Sign.Acct.Ct-Dt', 'Счет.Кредит или Дебет', 'Role.Sign.AccTable', 'Info.Sign.UseAccTable', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Acct.Dt', 'Sign.Acct', '', '', 'Sign.Acct.Dt', 'Счет.Дебет', 'Role.Sign.AccTable', 'Info.Sign.UseEntry', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Acct.Dt-Ct', 'Sign.Acct', '', '', 'Sign.Acct.Dt-Ct', 'Счет.Дебет или Кредит', 'Role.Sign.AccTable', 'Info.Sign.UseAccTable', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Acct', 'Sign.', '', '', 'Sign.Acct', 'Счет', 'Role.Sign.AccTable', '', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Budget', 'Sign.', '', '', 'Sign.Budget', 'Бюджет', 'Role.Sign.Budget', '', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Budget.Input', 'Sign.Budget', '', '', 'Sign.Budget.Input', 'Бюджет.Вход', 'Role.Sign.Budget', '', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Budget.Output', 'Sign.Budget', '', '', 'Sign.Budget.Output', 'Бюджет.Выход', 'Role.Sign.Budget', '', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.HRA', 'Sign.', '', '', 'Sign.HRA', 'HumanResourceAccounting', 'Role.Sign.HRA', '', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.MoneyFlow', 'Sign.', '', '', 'Sign.MoneyFlow', 'ДвижениеДенег', 'Role.Sign.MoneyFlow', '', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.MoneyFlow.Input', 'Sign.MoneyFlow', '', '', 'Sign.MoneyFlow.Input', 'ДвижениеДенег.Вход', '', '', '{"FullName": "Поступление","AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.MoneyFlow.Input.011', 'Sign.MoneyFlow.Input', '', '', 'Sign.MoneyFlow.Input.011', '011 - реализация', 'Role.Generic.Basic', 'Info.Report.FinForm.Money', '{"FullName": "реализация товаров и услуг","AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.MoneyFlow.Input.012', 'Sign.MoneyFlow.Input', '', '', 'Sign.MoneyFlow.Input.012', '012 - прочая выручка', 'Role.Generic.Variant', 'Info.Report.FinForm.Money', '{"FullName": "прочая выручка","AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.MoneyFlow.Input.013', 'Sign.MoneyFlow.Input', '', '', 'Sign.MoneyFlow.Input.013', '012 - авансы', 'Role.Generic.Basic', 'Info.Report.FinForm.Money', '{"FullName": "авансы, полученные от покупателей и заказчиков","AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.MoneyFlow.Input.016', 'Sign.MoneyFlow.Input', '', '', 'Sign.MoneyFlow.Input.016', '016 - прочие поступления', 'Role.Generic.Variant', 'Info.Report.FinForm.Money', '{"FullName": "прочие поступления","AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.MoneyFlow.Output', 'Sign.MoneyFlow', '', '', 'Sign.MoneyFlow.Output', 'ДвижениеДенег.Выход', '', '', '{"FullName": "Выбытие","AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.MoneyFlow.Output.021', 'Sign.MoneyFlow.Output', '', '', 'Sign.MoneyFlow.Output.021', '021 - платежи поставщикам', 'Role.Generic.Basic', 'Info.Report.FinForm.Money', '{"FullName": "платежи поставщикам за товары и услуги","AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.MoneyFlow.Output.022', 'Sign.MoneyFlow.Output', '', '', 'Sign.MoneyFlow.Output.022', '022 - авансы поставщикам', 'Role.Generic.Variant', 'Info.Report.FinForm.Money', '{"FullName": "авансы, выданные поставщикам товаров и услуг","AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.MoneyFlow.Output.023', 'Sign.MoneyFlow.Output', '', '', 'Sign.MoneyFlow.Output.023', '023 - выплаты по оплате труда', 'Role.Generic.Variant', 'Info.Report.FinForm.Money', '{"FullName": "выплаты по оплате труда","AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.MoneyFlow.Output.026', 'Sign.MoneyFlow.Output', '', '', 'Sign.MoneyFlow.Output.026', '026 - платежи в бюджет', 'Role.Generic.Basic', 'Info.Report.FinForm.Money', '{"FullName": "подоходный налог и другие платежи в бюджет","AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.MoneyFlow.Output.027', 'Sign.MoneyFlow.Output', '', '', 'Sign.MoneyFlow.Output.027', '027 - прочие выплаты', 'Role.Generic.Variant', 'Info.Report.FinForm.Money', '{"FullName": "прочие выплаты","AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Price', 'Sign.', '', '', 'Sign.Price', 'Цена', 'Role.Sign.Store-Traffic', '', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Price.Fall', 'Sign.Price', '', '', 'Sign.Price.Fall', 'Цена.снижение', 'Role.Sign.Store-Traffic', '', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Price.Growth', 'Sign.Price', '', '', 'Sign.Price.Growth', 'Цена.рост', 'Role.Sign.Store-Traffic', '', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Price.NoChange', 'Sign.Price', '', '', 'Sign.Price.NoChange', 'Цена.без изм', 'Role.Sign.Store-Traffic', '', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.', '', '', '', 'Sign.', 'SignData', 'Role.Entity.MainTable', 'Info.Entity.Reference', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Store', 'Sign.', '', '', 'Sign.Store', 'Склад', 'Role.Sign.Store-Traffic', '', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Store.Input', 'Sign.Store', '', '', 'Sign.Store.Input', 'Склад.Приход', 'Role.Sign.Store-Traffic', '', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Store.Output', 'Sign.Store', '', '', 'Sign.Store.Output', 'Склад.Расход', 'Role.Sign.Store-Traffic', '', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Store.Storage', 'Sign.Store', '', '', 'Sign.Store.Storage', 'Склад.Хранение', 'Role.Sign.Store-Traffic', '', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Store.Storage.Input', 'Sign.Store.Storage', '', '', 'Sign.Store.Storage.Input', 'Склад.Хранение.вход', 'Role.Sign.Store-Traffic', '', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Store.Storage.Output', 'Sign.Store.Storage', '', '', 'Sign.Store.Storage.Output', 'Склад.Хранение.выход', 'Role.Sign.Store-Traffic', '', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Tax', 'Sign.', '', '', 'Sign.Tax', 'Налог', 'Role.Sign.Tax', '', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Tax.Ct', 'Sign.Tax', '', '', 'Sign.Tax.Ct', 'Налог.Кредит', 'Role.Sign.Tax', '', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Tax.KNP', 'Sign.Tax', '', '', 'Sign.Tax.KNP', 'Налог.КНП', 'Role.Sign.Tax', 'Info.Code.KNP', '{"FullName": "Начисленные (исчисленные) и иные обязательства в бюджет","AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Tax.KNP.TaxMode.Main.911', 'Sign.Tax.KNP', '', '', 'Sign.Tax.KNP.TaxMode.Main.911', '911 - обяз-ва в бюджет', 'Role.TaxMode.Basic', 'Info.Generic.Basic', '{"FullName": "Начисленные (исчисленные) и иные обязательства в бюджет","AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Tax.KNP.TaxMode.Main.912', 'Sign.Tax.KNP', '', '', 'Sign.Tax.KNP.TaxMode.Main.912', '912 - пени', 'Role.TaxMode.Basic', 'Info.Generic.Variant', '{"FullName": "Пени по обязательствам в бюджет","AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Tax.KNP.TaxMode.Patent.921', 'Sign.Tax.KNP', '', '', 'Sign.Tax.KNP.TaxMode.Patent.921', '921 - обяз-ва в бюджет', 'Role.TaxMode.Patent', 'Info.Generic.Basic', '{"FullName": "Начисленные (исчисленные) и иные обязательства в бюджет","AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Tax.KNP.TaxMode.Patent.922', 'Sign.Tax.KNP', '', '', 'Sign.Tax.KNP.TaxMode.Patent.922', '922 - пени', 'Role.TaxMode.Patent', 'Info.Generic.Variant', '{"FullName": "Пени по обязательствам в бюджет","AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Tax.KNP.TaxMode.Simple.931', 'Sign.Tax.KNP', '', '', 'Sign.Tax.KNP.TaxMode.Simple.931', '931 - обяз-ва в бюджет', 'Role.TaxMode.Simple', 'Info.Generic.Basic', '{"FullName": "Начисленные (исчисленные) и иные обязательства в бюджет","AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Tax.KNP.TaxMode.Simple.932', 'Sign.Tax.KNP', '', '', 'Sign.Tax.KNP.TaxMode.Simple.932', '932 - пени', 'Role.TaxMode.Simple', 'Info.Generic.Variant', '{"FullName": "Пени по обязательствам в бюджет","AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Traffic', 'Sign.', '', '', 'Sign.Traffic', 'Транспорт', 'Role.Sign.Store-Traffic', '', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Traffic.Input', 'Sign.Traffic', '', '', 'Sign.Traffic.Input', 'Транспорт.Вход', 'Role.Sign.Store-Traffic', '', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Traffic.Output', 'Sign.Traffic', '', '', 'Sign.Traffic.Output', 'Транспорт.Выход', 'Role.Sign.Store-Traffic', '', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Traffic.Transit', 'Sign.Traffic', '', '', 'Sign.Traffic.Transit', 'Транспорт.Транзит', 'Role.Sign.Store-Traffic', '', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Traffic.Transit.Input', 'Sign.Traffic.Transit', '', '', 'Sign.Traffic.Transit.Input', 'Транспорт.Транзит.вход', 'Role.Sign.Store-Traffic', '', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Traffic.Transit.Output', 'Sign.Traffic.Transit', '', '', 'Sign.Traffic.Transit.Output', 'Транспорт.Транзит.выход', 'Role.Sign.Store-Traffic', '', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Work', 'Sign.', '', '', 'Sign.Work', 'Работа', 'Role.Sign.Store-Traffic', '', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Work.Closing', 'Sign.Work', '', '', 'Sign.Work.Closing', 'Работа.Закрытие', 'Role.Sign.Store-Traffic', '', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Work.Execution', 'Sign.Work', '', '', 'Sign.Work.Execution', 'Работа.Выполнение', 'Role.Sign.Store-Traffic', '', '{"AbcBasic": "Sign.Basic"}');
INSERT INTO Sign (Id, Parent, Date1, Date2, Code, Description, Role, Info, More) VALUES ('Sign.Work.Plan', 'Sign.Work', '', '', 'Sign.Work.Plan', 'Работа.План', 'Role.Sign.Store-Traffic', '', '{"AbcBasic": "Sign.Basic"}');

-- Таблица: Slice
CREATE TABLE IF NOT EXISTS [Slice](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Slice(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[More] TEXT
 );
INSERT INTO Slice (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Slice.Accounting', 'Slice.', '', '', 'Slice.Accounting', 'учет', '{"AbcBasic": "Slice.Basic"}');
INSERT INTO Slice (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Slice.Correction', 'Slice.', '', '', 'Slice.Correction', 'корректировка', '{"AbcBasic": "Slice.Basic"}');
INSERT INTO Slice (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Slice.Budget', 'Slice.', '', '', 'Slice.Budget', 'бюджет', '{"AbcBasic": "Slice.Basic"}');
INSERT INTO Slice (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Slice.Duplicate', 'Slice.', '', '', 'Slice.Duplicate', 'дубликат', '{"AbcBasic": "Slice.Basic"}');
INSERT INTO Slice (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Slice.Fact', 'Slice.', '', '', 'Slice.Fact', 'факт', '{"AbcBasic": "Slice.Basic"}');
INSERT INTO Slice (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Slice.Forecast', 'Slice.', '', '', 'Slice.Forecast', 'прогноз', '{"AbcBasic": "Slice.Basic"}');
INSERT INTO Slice (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Slice.Norm', 'Slice.', '', '', 'Slice.Norm', 'норматив', '{"AbcBasic": "Slice.Basic"}');
INSERT INTO Slice (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Slice.Offer', 'Slice.', '', '', 'Slice.Offer', 'коммерческое предложение', '{"AbcBasic": "Slice.Basic"}');
INSERT INTO Slice (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Slice.Plan', 'Slice.', '', '', 'Slice.Plan', 'план', '{"AbcBasic": "Slice.Basic"}');
INSERT INTO Slice (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Slice.Preorder', 'Slice.', '', '', 'Slice.Preorder', 'предварительный заказ', '{"AbcBasic": "Slice.Basic"}');
INSERT INTO Slice (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Slice.Report', 'Slice.', '', '', 'Slice.Report', 'отчет', '{"AbcBasic": "Slice.Basic"}');
INSERT INTO Slice (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Slice.Request', 'Slice.', '', '', 'Slice.Request', 'заявка', '{"AbcBasic": "Slice.Basic"}');
INSERT INTO Slice (Id, Parent, Date1, Date2, Code, Description, More) VALUES ('Slice.', '', '', '', 'Slice.', 'SliceData', '{"AbcBasic": "Slice.Basic"}');

-- Таблица: Unit
CREATE TABLE IF NOT EXISTS [Unit](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Unit(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Role] TEXT references Role(Id),
	[More] TEXT
 );
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.', '', '', '', 'Unit.', 'UnitData', 'Role.Entity.Asset-Unit', '{"AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Account', 'Unit.Piece', '', '', 'Unit.Account', 'бухсчет', 'Role.Unit.Derivative', '{"FullName": "бухсчет","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Box', 'Unit.', '', '', 'Unit.Box', 'ящ', 'Role.Unit.Basic', '{"FullName": "ящик","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.CalendarDay', 'Unit.', '', '', 'Unit.CalendarDay', 'кал дн', 'Role.Unit.Basic', '{"FullName": "календарные дни","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Case', 'Unit.', '', '', 'Unit.Case', 'коробка', 'Role.Unit.Basic', '{"FullName": "коробка","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.CurrUnit', 'Unit.', '', '', 'Unit.CurrUnit', 'ден ед', 'Role.Unit.Basic', '{"FullName": "денежных единиц","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Day', 'Unit.', '', '', 'Unit.Day', 'дн', 'Role.Unit.Basic', '{"FullName": "день","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Deal', 'Unit.Piece', '', '', 'Unit.Deal', 'сделка', 'Role.Unit.Derivative', '{"FullName": "сделка","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Delivery', 'Unit.', '', '', 'Unit.Delivery', 'поставка', 'Role.Unit.Derivative', '{"FullName": "поставка","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Dismissal', 'Unit.HR', '', '', 'Unit.Dismissal', 'увольнение', 'Role.Unit.Derivative', '{"FullName": "увольнение","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Doc', 'Unit.Piece', '', '', 'Unit.Doc', 'док', 'Role.Unit.Derivative', '{"FullName": "документ","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.DocID', 'Unit.', '', '', 'Unit.DocID', 'номер документа', 'Role.Unit.Derivative', '{"FullName": "номер документа","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.EUR', 'Unit.CurrUnit', '', '', 'Unit.EUR', 'EUR', 'Role.Currency.AccountingCurrency', '{"FullName": "евро","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Face', 'Unit.', '', '', 'Unit.Face', 'лицо', 'Role.Unit.Derivative', '{"FullName": "лицо","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.HalfYear', 'Unit.', '', '', 'Unit.HalfYear', 'полугодие', 'Role.Unit.Basic', '{"FullName": "полугодие","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Hiring', 'Unit.HR', '', '', 'Unit.Hiring', 'прием на работу', 'Role.Unit.Derivative', '{"FullName": "прием на работу","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.HR', 'Unit.', '', '', 'Unit.HR', 'HR', 'Role.Unit.Derivative', '{"FullName": "HR","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.InfoBase', 'Unit.Piece', '', '', 'Unit.InfoBase', 'инф база', 'Role.Unit.Derivative', '{"FullName": "информационная база","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Jar', 'Unit.', '', '', 'Unit.Jar', 'банка', 'Role.Unit.Basic', '{"FullName": "банка","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Kg', 'Unit.', '', '', 'Unit.Kg', 'кг', 'Role.Unit.Basic', '{"FullName": "килограмм","MKEI": "166","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Kilometer', 'Unit.', '', '', 'Unit.Kilometer', 'км', 'Role.Unit.Basic', '{"FullName": "километр","MKEI": "8","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.KZT', 'Unit.CurrUnit', '', '', 'Unit.KZT', 'KZT', 'Role.Currency.AccountingCurrency', '{"FullName": "казахстанский тенге","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Litr', 'Unit.', '', '', 'Unit.Litr', 'л', 'Role.Unit.Basic', '{"FullName": "литр","MKEI": "112","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Meter', 'Unit.', '', '', 'Unit.Meter', 'м', 'Role.Unit.Basic', '{"FullName": "метр","MKEI": "6","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.MinCalcRate', 'Unit.', '', '', 'Unit.MinCalcRate', 'МРП', 'Role.Rate.MinRate', '{"FullName": "минимальный расчетный показатель","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.MinSalary', 'Unit.', '', '', 'Unit.MinSalary', 'МинЗП', 'Role.Rate.MinRate', '{"FullName": "минимальная заработная плата","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Month', 'Unit.', '', '', 'Unit.Month', 'мес', 'Role.Unit.Basic', '{"FullName": "месяц","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Pack', 'Unit.', '', '', 'Unit.Pack', 'уп', 'Role.Unit.Basic', '{"FullName": "упаковка","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Packet', 'Unit.', '', '', 'Unit.Packet', 'пач', 'Role.Unit.Basic', '{"FullName": "пачка","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Percent', 'Unit.', '', '', 'Unit.Percent', '%', 'Role.Unit.Basic', '{"FullName": "процент","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Piece', 'Unit.', '', '', 'Unit.Piece', 'шт', 'Role.Unit.Basic', '{"FullName": "штука","MKEI": "796","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Position', 'Unit.', '', '', 'Unit.Position', 'должность', 'Role.Unit.Derivative', '{"FullName": "должность штатного расписания","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Product', 'Unit.', '', '', 'Unit.Product', 'изд', 'Role.Unit.Basic', '{"FullName": "изделие","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Quarter', 'Unit.', '', '', 'Unit.Quarter', 'кв', 'Role.Unit.Basic', '{"FullName": "квартал","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.RUB', 'Unit.CurrUnit', '', '', 'Unit.RUB', 'RUB', 'Role.Currency.AccountingCurrency', '{"FullName": "российский рубль","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Service', 'Unit.', '', '', 'Unit.Service', 'усл', 'Role.Unit.Basic', '{"FullName": "услуга","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.SquareMeter', 'Unit.', '', '', 'Unit.SquareMeter', 'кв м', 'Role.Unit.Basic', '{"FullName": "квадратный метр","MKEI": "55","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.T', 'Unit.', '', '', 'Unit.T', 'т', 'Role.Unit.Basic', '{"FullName": "тонна","MKEI": "168","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Text', 'Unit.Piece', '', '', 'Unit.Text', 'текст', 'Role.Unit.Derivative', '{"FullName": "текст","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.USD', 'Unit.CurrUnit', '', '', 'Unit.USD', 'USD', 'Role.Currency.AccountingCurrency', '{"FullName": "доллар США","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.User', 'Unit.', '', '', 'Unit.User', 'пользователь', 'Role.Unit.Derivative', '{"FullName": "пользователь","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Week', 'Unit.', '', '', 'Unit.Week', 'нед', 'Role.Unit.Basic', '{"FullName": "неделя","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.WorkDay', 'Unit.', '', '', 'Unit.WorkDay', 'раб дн', 'Role.Unit.Basic', '{"FullName": "рабочий день","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.WorkHour', 'Unit.', '', '', 'Unit.WorkHour', 'раб ч', 'Role.Unit.Basic', '{"FullName": "рабочий час","MKEI": "356","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Year', 'Unit.', '', '', 'Unit.Year', 'год', 'Role.Unit.Basic', '{"FullName": "год","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.PercentPerDay', 'Unit.Percent', '', '', 'Unit.PercentPerDay', '%/дн', 'Role.Unit.Derivative', '{"FullName": "%/день","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Cbm', 'Unit.', '', '', 'Unit.Cbm', 'куб м', 'Role.Unit.Basic', '{"FullName": "кубометр","MKEI": "113","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Mm', 'Unit.', '', '', 'Unit.Mm', 'мм', 'Role.Unit.Basic', '{"FullName": "миллиметр","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Flight', 'Unit.Piece', '', '', 'Unit.Flight', 'рейс', 'Role.Unit.Derivative', '{"FullName": "рейс","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.ServiceLoginPassword', 'Unit.', '', '', 'Unit.ServiceLoginPassword', 'сервис, логин, пароль', 'Role.Unit.Auth', '{"FullName": "сервис, логин, пароль","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Punishment', 'Unit.HR', '', '', 'Unit.Punishment', 'взыскание', 'Role.Unit.Derivative', '{"FullName": "взыскание","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Promotion', 'Unit.HR', '', '', 'Unit.Promotion', 'поощрение', 'Role.Unit.Derivative', '{"FullName": "поощрение","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.OtherPersonnelEvent', 'Unit.HR', '', '', 'Unit.OtherPersonnelEvent', 'прочее кадровое событие', 'Role.Unit.Derivative', '{"FullName": "прочее кадровое событие","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.Formula', 'Unit.', '', '', 'Unit.Formula', 'формула', 'Role.Unit.Basic', '{"FullName": "формула","AbcBasic": "Unit.Basic"}');
INSERT INTO Unit (Id, Parent, Date1, Date2, Code, Description, Role, More) VALUES ('Unit.ExactDate', 'Unit.', '', '', 'Unit.ExactDate', 'точная дата', 'Role.Unit.Basic', '{"FullName": "точная дата","AbcBasic": "Unit.Basic"}');

-- Таблица: Workbook
CREATE TABLE IF NOT EXISTS [Workbook](
	[Id] TEXT PRIMARY KEY,
	[Parent] TEXT references Workbook(Id),
	[Face1] TEXT references Face(Id),
	[Face2] TEXT references Face(Id),
	[Face] TEXT references Face(Id),
	[Slice] TEXT references Slice(Id),
	[Date1] TEXT DEFAULT CURRENT_TIMESTAMP,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Geo] TEXT references Geo(Id),
	[Sign] TEXT references Sign(Id),
	[Account] TEXT references Account(Id),
	[Process] TEXT references Process(Id),
    [Asset] TEXT references Asset(Id),
    [Deal] TEXT references Deal(Id),
    [Item] TEXT references Item(Id),
	[Debt] TEXT references Debt(Id),
	[Price] TEXT references Price(Id),
	[Role] TEXT references Role(Id),
	[Info] TEXT references Info(Id),
	[Meter] TEXT references Meter(Id),
	[MeterValue] TEXT,
	[Unit] TEXT references Unit(Id),
	[More] TEXT,
	[Mark] TEXT references Mark(Id)
 );
INSERT INTO Workbook (Id, Parent, Face1, Face2, Face, Slice, Date1, Date2, Code, Description, Geo, Sign, Account, Process, Asset, Deal, Item, Debt, Price, Role, Info, Meter, MeterValue, Unit, More, Mark) VALUES ('Workbook.', '', '', '', '', '', '', '', 'Workbook.', 'WorkbookData', '', '', '', '', '', '', '', '', '', 'Role.Entity.Workbook', 'Info.Entity.Journal', '', '', '', '{"AbcBasic": "Workbook.Basic"}', 'Mark.MD');

-- Индекс: AssetCode
CREATE INDEX IF NOT EXISTS AssetCode ON Asset (
    Code
);

-- Индекс: AssetDate1
CREATE INDEX IF NOT EXISTS AssetDate1 ON Asset (
    Date1
);

-- Индекс: AssetDescription
CREATE INDEX IF NOT EXISTS AssetDescription ON Asset (
    Description
);

-- Индекс: AssetInfo
CREATE INDEX IF NOT EXISTS AssetInfo ON Asset (
    Info
);

-- Индекс: AssetRole
CREATE INDEX IF NOT EXISTS AssetRole ON Asset (
    Role
);

-- Индекс: DealCode
CREATE INDEX IF NOT EXISTS DealCode ON Deal (
    Code
);

-- Индекс: DealDescription
CREATE INDEX IF NOT EXISTS DealDescription ON Deal (
    Description
);

-- Индекс: DealFace
CREATE INDEX IF NOT EXISTS DealFace ON Deal (
    Face
);

-- Индекс: DealFace1
CREATE INDEX IF NOT EXISTS DealFace1 ON Deal (
    Face1
);

-- Индекс: DealFace2
CREATE INDEX IF NOT EXISTS DealFace2 ON Deal (
    Face2
);

-- Индекс: DealInfo
CREATE INDEX IF NOT EXISTS DealInfo ON Deal (
    Info
);

-- Индекс: DealParent
CREATE INDEX IF NOT EXISTS DealParent ON Deal (
    Parent
);

-- Индекс: DealRole
CREATE INDEX IF NOT EXISTS DealRole ON Deal (
    Role
);

-- Индекс: FaceCode
CREATE INDEX IF NOT EXISTS FaceCode ON Face (
    Code
);

-- Индекс: FaceDate1
CREATE INDEX IF NOT EXISTS FaceDate1 ON Face (
    Date1
);

-- Индекс: FaceDescription
CREATE INDEX IF NOT EXISTS FaceDescription ON Face (
    Description
);

-- Индекс: FaceInfo
CREATE INDEX IF NOT EXISTS FaceInfo ON Face (
    Info
);

-- Индекс: FaceParent
CREATE INDEX IF NOT EXISTS FaceParent ON Face (
    Parent
);

-- Индекс: FaceRole
CREATE INDEX IF NOT EXISTS FaceRole ON Face (
    Role
);

-- Индекс: WorkbookAccount
CREATE INDEX IF NOT EXISTS WorkbookAccount ON Workbook (
    Account
);

-- Индекс: WorkbookAsset
CREATE INDEX IF NOT EXISTS WorkbookAsset ON Workbook (
    Asset
);

-- Индекс: WorkbookCode
CREATE INDEX IF NOT EXISTS WorkbookCode ON Workbook (
    Code
);

-- Индекс: WorkbookDate1
CREATE INDEX IF NOT EXISTS WorkbookDate1 ON Workbook (
    Date1
);

-- Индекс: WorkbookDeal
CREATE INDEX IF NOT EXISTS WorkbookDeal ON Workbook (
    Deal
);

-- Индекс: WorkbookDebt
CREATE INDEX IF NOT EXISTS WorkbookDebt ON Workbook (
    Debt
);

-- Индекс: WorkbookDescription
CREATE INDEX IF NOT EXISTS WorkbookDescription ON Workbook (
    Description
);

-- Индекс: WorkbookFace
CREATE INDEX IF NOT EXISTS WorkbookFace ON Workbook (
    Face
);

-- Индекс: WorkbookFace1
CREATE INDEX IF NOT EXISTS WorkbookFace1 ON Workbook (
    Face1
);

-- Индекс: WorkbookFace2
CREATE INDEX IF NOT EXISTS WorkbookFace2 ON Workbook (
    Face2
);

-- Индекс: WorkbookInfo
CREATE INDEX IF NOT EXISTS WorkbookInfo ON Workbook (
    Info
);

-- Индекс: WorkbookParent
CREATE INDEX IF NOT EXISTS WorkbookParent ON Workbook (
    Parent
);

-- Индекс: WorkbookProcess
CREATE INDEX IF NOT EXISTS WorkbookProcess ON Workbook (
    Process
);

-- Индекс: WorkbookRole
CREATE INDEX IF NOT EXISTS WorkbookRole ON Workbook (
    Role
);

-- Индекс: WorkbookSign
CREATE INDEX IF NOT EXISTS WorkbookSign ON Workbook (
    Sign
);

-- Представление: AccountList
CREATE VIEW IF NOT EXISTS AccountList AS
    SELECT Account.Id,
           Account.Parent,
           Account2.Code AS ParentCode,
           Account2.Description AS ParentDescription,
           Account.Slice,
           Slice.Code AS SliceCode,
           Slice.Description AS SliceDescription,
           Account.Date1 AS Date1,
           Account.Date2 AS Date2,
           Account.Code AS Code,
           Account.Description AS Description,
           Account.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Account.Sign,
           Sign.Code AS SignCode,
           Sign.Description AS SignDescription,
           Account.More AS More
      FROM Account AS Account
           LEFT JOIN
           Account AS Account2 ON Account.Parent = Account2.Id
           LEFT JOIN
           Slice AS Slice ON Account.Slice = Slice.Id
           LEFT JOIN
           Role AS Role ON Account.Role = Role.Id
           LEFT JOIN
           Sign AS Sign ON Account.Sign = Sign.Id;

-- Представление: AssetList
CREATE VIEW IF NOT EXISTS AssetList AS
    SELECT Asset.Id,
           Asset.Parent,
           Asset2.Code AS ParentCode,
           Asset2.Description AS ParentDescription,
           Asset.Date1 AS Date1,
           Asset.Date2 AS Date2,
           Asset.Code,
           Asset.Description,
           Asset.Geo,
           Geo.Code AS GeoCode,
           Geo.Description AS GeoDescription,
           Asset.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Asset.Info,
           Info.Code AS InfoCode,
           Info.Description AS InfoDescription,
           Asset.Unit,
           Unit.Code AS UnitCode,
           Unit.Description AS UnitDescription,
           Asset.More AS More
      FROM Asset AS Asset
           LEFT JOIN
           Asset AS Asset2 ON Asset.Parent = Asset2.Id
           LEFT JOIN
           Geo AS Geo ON Asset.Geo = Geo.Id
           LEFT JOIN
           Role AS Role ON Asset.Role = Role.Id
           LEFT JOIN
           Info AS Info ON Asset.Info = Info.Id
           LEFT JOIN
           Unit AS Unit ON Asset.Unit = Unit.Id;

-- Представление: DealList
CREATE VIEW IF NOT EXISTS DealList AS
    SELECT Deal.Id,
           Deal.Parent,
           Deal2.Code AS ParentCode,
           Deal2.Description AS ParentDescription,
           Deal.Face1,
           Face1.Code AS Face1Code,
           Face1.Description AS Face1Description,
           Deal.Face2,
           Face2.Code AS Face2Code,
           Face2.Description AS Face2Description,
           Deal.Face,
           Face.Code AS FaceCode,
           Face.Description AS FaceDescription,
           Deal.Date1 AS Date1,
           Deal.Date2 AS Date2,
           Deal.Code AS Code,
           Deal.Description AS Description,
           Deal.Geo,
           Geo.Code AS GeoCode,
           Geo.Description AS GeoDescription,
           Deal.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Deal.Info,
           Info.Code AS InfoCode,
           Info.Description AS InfoDescription,
           Deal.More AS More
      FROM Deal AS Deal
           LEFT JOIN
           Deal AS Deal2 ON Deal.Parent = Deal2.Id
           LEFT JOIN
           Face AS Face ON Deal.Face = Face.Id
           LEFT JOIN
           Face AS Face1 ON Deal.Face1 = Face1.Id
           LEFT JOIN
           Face AS Face2 ON Deal.Face2 = Face2.Id
           LEFT JOIN
           Geo AS Geo ON Deal.Geo = Geo.Id
           LEFT JOIN
           Role AS Role ON Deal.Role = Role.Id
           LEFT JOIN
           Info AS Info ON Deal.Info = Info.Id;

-- Представление: DebtList
CREATE VIEW IF NOT EXISTS DebtList AS
    SELECT Debt.Id,
           Debt.Parent,
           Debt2.Code AS ParentCode,
           Debt2.Description AS ParentDescription,
           Debt.Date1 AS Date1,
           Debt.Date2 AS Date2,
           Debt.Code AS Code,
           Debt.Description AS Description,
           Debt.Geo,
           Geo.Code AS GeoCode,
           Geo.Description AS GeoDescription,
           Debt.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Debt.Info,
           Info.Code AS InfoCode,
           Info.Description AS InfoDescription,
           Debt.More AS More
      FROM Debt AS Debt
           LEFT JOIN
           Debt AS Debt2 ON Debt.Parent = Debt2.Id
           LEFT JOIN
           Geo AS Geo ON Debt.Geo = Geo.Id
           LEFT JOIN
           Role AS Role ON Debt.Role = Role.Id
           LEFT JOIN
           Info AS Info ON Debt.Info = Info.Id;

-- Представление: FaceList
CREATE VIEW IF NOT EXISTS FaceList AS
    SELECT Face.Id,
           Face.Parent,
           Face2.Code AS ParentCode,
           Face2.Description AS ParentDescription,
           Face.Date1 AS Date1,
           Face.Date2 AS Date2,
           Face.Code AS Code,
           Face.Description AS Description,
           Face.Geo,
           Geo.Code AS GeoCode,
           Geo.Description AS GeoDescription,
           Face.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Face.Info,
           Info.Code AS InfoCode,
           Info.Description AS InfoDescription,
           Face.More AS More
      FROM Face AS Face
           LEFT JOIN
           Face AS Face2 ON Face.Parent = Face2.Id
           LEFT JOIN
           Geo AS Geo ON Face.Geo = Geo.Id
           LEFT JOIN
           Role AS Role ON Face.Role = Role.Id
           LEFT JOIN
           Info AS Info ON Face.Info = Info.Id;

-- Представление: GeoList
CREATE VIEW IF NOT EXISTS GeoList AS
    SELECT Geo.Id,
           Geo.Parent,
           Geo2.Code AS ParentCode,
           Geo2.Description AS ParentDescription,
           Geo.Date1 AS Date1,
           Geo.Date2 AS Date2,
           Geo.Code AS Code,
           Geo.Description AS Description,
           Geo.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Geo.Unit,
           Unit.Code AS UnitCode,
           Unit.Description AS UnitDescription,
           Geo.More AS More
      FROM Geo AS Geo
           LEFT JOIN
           Geo AS Geo2 ON Geo.Parent = Geo2.Id
           LEFT JOIN
           Role AS Role ON Geo.Role = Role.Id
           LEFT JOIN
           Unit AS Unit ON Geo.Unit = Unit.Id;

-- Представление: InfoList
CREATE VIEW IF NOT EXISTS InfoList AS
    SELECT Info.Id,
           Info.Parent,
           Info2.Code AS ParentCode,
           Info2.Description AS ParentDescription,
           Info.Date1 AS Date1,
           Info.Date2 AS Date2,
           Info.Code AS Code,
           Info.Description AS Description,
           Info.More AS More
      FROM Info AS Info
           LEFT JOIN
           Info AS Info2 ON Info.Parent = Info2.Id;

-- Представление: ItemList
CREATE VIEW IF NOT EXISTS ItemList AS
    SELECT Item.Id,
           Item.Parent,
           Item2.Code AS ParentCode,
           Item2.Description AS ParentDescription,
           Item.Date1 AS Date1,
           Item.Date2 AS Date2,
           Item.Code AS Code,
           Item.Description AS Description,
           Item.More AS More
      FROM Item AS Item
           LEFT JOIN
           Item AS Item2 ON Item.Parent = Item2.Id;

-- Представление: MarkList
CREATE VIEW IF NOT EXISTS MarkList AS
    SELECT Mark.Id,
           Mark.Parent,
           Mark2.Code AS ParentCode,
           Mark2.Description AS ParentDescription,
           Mark.Date1 AS Date1,
           Mark.Date2 AS Date2,
           Mark.Code AS Code,
           Mark.Description AS Description,
           Mark.More AS More
      FROM Mark AS Mark
           LEFT JOIN
           Mark AS Mark2 ON Mark.Parent = Mark2.Id;

-- Представление: MeterList
CREATE VIEW IF NOT EXISTS MeterList AS
    SELECT Meter.Id,
           Meter.Parent,
           Meter2.Code AS ParentCode,
           Meter2.Description AS ParentDescription,
           Meter.Date1 AS Date1,
           Meter.Date2 AS Date2,
           Meter.Code AS Code,
           Meter.Description AS Description,
           Meter.More AS More
      FROM Meter AS Meter
           LEFT JOIN
           Meter AS Meter2 ON Meter.Parent = Meter2.Id;

-- Представление: PriceList
CREATE VIEW IF NOT EXISTS PriceList AS
    SELECT Price.Id,
           Price.Parent,
           Price2.Code AS ParentCode,
           Price2.Description AS ParentDescription,
           Price.Date1 AS Date1,
           Price.Date2 AS Date2,
           Price.Code AS Code,
           Price.Description AS Description,
           Price.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Price.Info,
           Info.Code AS InfoCode,
           Info.Description AS InfoDescription,
           Price.Unit,
           Unit.Code AS UnitCode,
           Unit.Description AS UnitDescription,
           Price.More AS More
      FROM Price AS Price
           LEFT JOIN
           Price AS Price2 ON Price.Parent = Price2.Id
           LEFT JOIN
           Role AS Role ON Price.Role = Role.Id
           LEFT JOIN
           Info AS Info ON Price.Info = Info.Id
           LEFT JOIN
           Unit AS Unit ON Price.Unit = Unit.Id;

-- Представление: ProcessList
CREATE VIEW IF NOT EXISTS ProcessList AS
    SELECT Process.Id,
           Process.Parent,
           Process2.Code AS ParentCode,
           Process2.Description AS ParentDescription,
           Process.Face1,
           Face1.Code AS Face1Code,
           Face1.Description AS Face1Description,
           Process.Face2,
           Face2.Code AS Face2Code,
           Face2.Description AS Face2Description,
           Process.Face,
           Face.Code AS FaceCode,
           Face.Description AS FaceDescription,
           Process.Slice,
           Slice.Code AS SliceCode,
           Slice.Description AS SliceDescription,
           Process.Date1 AS Date1,
           Process.Date2 AS Date2,
           Process.Code AS Code,
           Process.Description AS Description,
           Process.Sign,
           Sign.Code AS SignCode,
           Sign.Description AS SignDescription,
           Process.Account,
           T9.Code AS AccountCode,
           T9.Description AS AccountDescription,
           Process.Asset,
           Asset.Code AS AssetCode,
           Asset.Description AS AssetDescription,
           Process.Deal,
           Deal.Code AS DealCode,
           Deal.Description AS DealDescription,
           Process.Item,
           Item.Code AS ItemCode,
           Item.Description AS ItemDescription,
           Process.Debt,
           Debt.Code AS DebtCode,
           Debt.Description AS DebtDescription,
           Process.Price,
           Price.Code AS PriceCode,
           Price.Description AS PriceDescription,
           Process.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Process.Info,
           Info.Code AS InfoCode,
           Info.Description AS InfoDescription,
           Process.Meter,
           Meter.Code AS MeterCode,
           Meter.Description AS MeterDescription,
           Process.MeterValue AS MeterValue,
           Process.Unit,
           Unit.Code AS UnitCode,
           Unit.Description AS UnitDescription,
           Process.More AS More
      FROM Process AS Process
           LEFT JOIN
           Process AS Process2 ON Process.Parent = Process2.Id
           LEFT JOIN
           Slice AS Slice ON Process.Slice = Slice.Id
           LEFT JOIN
           Face AS Face ON Process.Face = Face.Id
           LEFT JOIN
           Face AS Face1 ON Process.Face1 = Face1.Id
           LEFT JOIN
           Face AS Face2 ON Process.Face2 = Face2.Id
           LEFT JOIN
           Account AS T9 ON Process.Account = T9.Id
           LEFT JOIN
           Role AS Role ON Process.Role = Role.Id
           LEFT JOIN
           Info AS Info ON Process.Info = Info.Id
           LEFT JOIN
           Sign AS Sign ON Process.Sign = Sign.Id
           LEFT JOIN
           Unit AS Unit ON Process.Unit = Unit.Id
           LEFT JOIN
           Debt AS Debt ON Process.Debt = Debt.Id
           LEFT JOIN
           Item AS Item ON Process.Item = Item.Id
           LEFT JOIN
           Deal AS Deal ON Process.Deal = Deal.Id
           LEFT JOIN
           Price AS Price ON Process.Price = Price.Id
           LEFT JOIN
           Asset AS Asset ON Process.Asset = Asset.Id
           LEFT JOIN
           Meter AS Meter ON Process.Meter = Meter.Id;

-- Представление: RoleList
CREATE VIEW IF NOT EXISTS RoleList AS
    SELECT Role.Id,
           Role.Parent,
           Role2.Code AS ParentCode,
           Role2.Description AS ParentDescription,
           Role.Date1 AS Date1,
           Role.Date2 AS Date2,
           Role.Code AS Code,
           Role.Description AS Description,
           Role.More AS More
      FROM Role AS Role
           LEFT JOIN
           Role AS Role2 ON Role.Parent = Role2.Id;

-- Представление: SignList
CREATE VIEW IF NOT EXISTS SignList AS
    SELECT Sign.Id,
           Sign.Parent,
           Sign2.Code AS ParentCode,
           Sign2.Description AS ParentDescription,
           Sign.Date1 AS Date1,
           Sign.Date2 AS Date2,
           Sign.Code AS Code,
           Sign.Description AS Description,
           Sign.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Sign.Info,
           Info.Code AS InfoCode,
           Info.Description AS InfoDescription,
           Sign.More AS More
      FROM Sign AS Sign
           LEFT JOIN
           Sign AS Sign2 ON Sign.Parent = Sign2.Id
           LEFT JOIN
           Role AS Role ON Sign.Role = Role.Id
           LEFT JOIN
           Info AS Info ON Sign.Info = Info.Id;

-- Представление: SliceList
CREATE VIEW IF NOT EXISTS SliceList AS
    SELECT Slice.Id,
           Slice.Parent,
           Slice2.Code AS ParentCode,
           Slice2.Description AS ParentDescription,
           Slice.Date1 AS Date1,
           Slice.Date2 AS Date2,
           Slice.Code AS Code,
           Slice.Description AS Description,
           Slice.More AS More
      FROM Slice AS Slice
           LEFT JOIN
           Slice AS Slice2 ON Slice.Parent = Slice2.Id;

-- Представление: UnitList
CREATE VIEW IF NOT EXISTS UnitList AS
    SELECT Unit.Id,
           Unit.Parent,
           Unit2.Code AS ParentCode,
           Unit2.Description AS ParentDescription,
           Unit.Date1 AS Date1,
           Unit.Date2 AS Date2,
           Unit.Code AS Code,
           Unit.Description AS Description,
           Unit.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Unit.More AS More
      FROM Unit AS Unit
           LEFT JOIN
           Unit AS Unit2 ON Unit.Parent = Unit2.Id
           LEFT JOIN
           Role AS Role ON Unit.Role = Role.Id;

-- Представление: WorkbookList
CREATE VIEW IF NOT EXISTS WorkbookList AS
    SELECT Workbook.Id,
           Workbook.Parent,
           Workbook2.Code AS ParentCode,
           Workbook2.Description AS ParentDescription,
           Workbook.Face1,
           Face1.Code AS Face1Code,
           Face1.Description AS Face1Description,
           Workbook.Face2,
           Face2.Code AS Face2Code,
           Face2.Description AS Face2Description,
           Workbook.Face,
           Face.Code AS FaceCode,
           Face.Description AS FaceDescription,
           Workbook.Slice,
           Slice.Code AS SliceCode,
           Slice.Description AS SliceDescription,
           Workbook.Date1 AS Date1,
           Workbook.Date2 AS Date2,
           Workbook.Code AS Code,
           Workbook.Description AS Description,
           Workbook.Geo,
           Geo.Code AS GeoCode,
           Geo.Description AS GeoDescription,
           Workbook.Sign,
           Sign.Code AS SignCode,
           Sign.Description AS SignDescription,
           Workbook.Account,
           Account.Code AS AccountCode,
           Account.Description AS AccountDescription,
           Workbook.Process,
           Process.Code AS ProcessCode,
           Process.Description AS ProcessDescription,
           Workbook.Debt,
           Debt.Code AS DebtCode,
           Debt.Description AS DebtDescription,
           Workbook.Item,
           Item.Code AS ItemCode,
           Item.Description AS ItemDescription,
           Workbook.Deal,
           Deal.Code AS DealCode,
           Deal.Description AS DealDescription,
           Workbook.Price,
           Price.Code AS PriceCode,
           Price.Description AS PriceDescription,
           Workbook.Asset,
           Asset.Code AS AssetCode,
           Asset.Description AS AssetDescription,
           Workbook.Role,
           Role.Code AS RoleCode,
           Role.Description AS RoleDescription,
           Workbook.Info,
           Info.Code AS InfoCode,
           Info.Description AS InfoDescription,
           Workbook.Meter,
           Meter.Code AS MeterCode,
           Meter.Description AS MeterDescription,
           Workbook.MeterValue AS MeterValue,
           Workbook.Unit,
           Unit.Code AS UnitCode,
           Unit.Description AS UnitDescription,
		   Workbook.More AS More,
           Workbook.Mark,
           Mark.Code AS MarkCode,
           Mark.Description AS MarkDescription
      FROM Workbook AS Workbook
           LEFT JOIN
           Workbook AS Workbook2 ON Workbook.Parent = Workbook2.Id
           LEFT JOIN
           Mark AS Mark ON Workbook.Mark = Mark.Id
           LEFT JOIN
           Slice AS Slice ON Workbook.Slice = Slice.Id
           LEFT JOIN
           Face AS Face ON Workbook.Face = Face.Id
           LEFT JOIN
           Face AS Face1 ON Workbook.Face1 = Face1.Id
           LEFT JOIN
           Face AS Face2 ON Workbook.Face2 = Face2.Id
           LEFT JOIN
           Geo AS Geo ON Workbook.Geo = Geo.Id
           LEFT JOIN
           Account AS Account ON Workbook.Account = Account.Id
           LEFT JOIN
           Role AS Role ON Workbook.Role = Role.Id
           LEFT JOIN
           Info AS Info ON Workbook.Info = Info.Id
           LEFT JOIN
           Sign AS Sign ON Workbook.Sign = Sign.Id
           LEFT JOIN
           Unit AS Unit ON Workbook.Unit = Unit.Id
           LEFT JOIN
           Process AS Process ON Workbook.Process = Process.Id
           LEFT JOIN
           Debt AS Debt ON Workbook.Debt = Debt.Id
           LEFT JOIN
           Item AS Item ON Workbook.Item = Item.Id
           LEFT JOIN
           Deal AS Deal ON Workbook.Deal = Deal.Id
           LEFT JOIN
           Price AS Price ON Workbook.Price = Price.Id
           LEFT JOIN
           Asset AS Asset ON Workbook.Asset = Asset.Id
           LEFT JOIN
           Meter AS Meter ON Workbook.Meter = Meter.Id;

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
