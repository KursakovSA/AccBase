﻿/****** Скрипт для команды SelectTopNRows из среды SSMS  ******/
SELECT top (7) *
  FROM [DatabaseLarge].[dbo].[WorkbookList] order by Id Desc