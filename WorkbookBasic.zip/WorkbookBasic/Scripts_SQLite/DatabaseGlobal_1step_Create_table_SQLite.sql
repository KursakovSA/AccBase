﻿--Курсаков С.А. https://github.com/KursakovSA/AccBase 

PRAGMA foreign_keys = off;

CREATE TABLE IF NOT EXISTS [Account](
	[Id] TEXT,
	[Parent] TEXT,
	[Slice] TEXT,
	[Date1] TEXT,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
    [Role] TEXT,
    [Sign] TEXT,
	[More] TEXT
 );

CREATE TABLE IF NOT EXISTS [Asset](
	[Id] TEXT,
	[Parent] TEXT,
	[Date1] TEXT,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Geo] TEXT,
	[Role] TEXT,
	[Info] TEXT,
	[Unit] TEXT,
	[More] TEXT
 );

CREATE TABLE IF NOT EXISTS [Deal](
	[Id] TEXT,
	[Parent] TEXT,
	[Face1] TEXT,
	[Face2] TEXT,
	[Face] TEXT,
	[Date1] TEXT,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Geo] TEXT,
	[Role] TEXT,
	[Info] TEXT,
	[More] TEXT
 );

CREATE TABLE IF NOT EXISTS [Debt](
	[Id] TEXT,
	[Parent] TEXT,
	[Date1] TEXT,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Geo] TEXT,
	[Role] TEXT,
	[Info] TEXT,
	[More] TEXT
  ); 
 
CREATE TABLE IF NOT EXISTS [Face](
	[Id] TEXT,
	[Parent] TEXT,
	[Date1] TEXT,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Geo] TEXT,
	[Role] TEXT,
	[Info] TEXT,
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Geo](
	[Id] TEXT,
	[Parent] TEXT,
	[Date1] TEXT,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
    [Role] TEXT,
	[Unit] TEXT,
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Info](
	[Id] TEXT,
	[Parent] TEXT,
	[Date1] TEXT,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Item](
	[Id] TEXT,
	[Parent] TEXT,
	[Date1] TEXT,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Mark](
	[Id] TEXT,
	[Parent] TEXT,
	[Date1] TEXT,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Meter](
	[Id] TEXT,
	[Parent] TEXT,
	[Date1] TEXT,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Unit] TEXT,
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Price](
	[Id] TEXT,
	[Parent] TEXT,
	[Date1] TEXT,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Role] TEXT,
	[Info] TEXT,
	[Unit] TEXT,
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Process](
	[Id] TEXT,
	[Parent] TEXT,
	[Face1] TEXT,
	[Face2] TEXT,
	[Face] TEXT,
	[Slice] TEXT,
	[Date1] TEXT,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Sign] TEXT,
	[Account] TEXT,
    [Asset] TEXT,
    [Deal] TEXT,
    [Item] TEXT,
	[Debt] TEXT,
	[Price] TEXT,
	[Role] TEXT,
	[Info] TEXT,
	[Meter] TEXT,
	[MeterValue] TEXT,
	[Unit] TEXT,
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Role](
	[Id] TEXT,
	[Parent] TEXT,
	[Date1] TEXT,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Sign](
	[Id] TEXT,
	[Parent] TEXT,
	[Date1] TEXT,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Role] TEXT,
	[Info] TEXT,
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Slice](
	[Id] TEXT,
	[Parent] TEXT,
	[Date1] TEXT,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Unit](
	[Id] TEXT,
	[Parent] TEXT,
	[Date1] TEXT,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Role] TEXT,
	[More] TEXT
 );
 
CREATE TABLE IF NOT EXISTS [Workbook](
	[Id] TEXT,
	[Parent] TEXT,
	[Face1] TEXT,
	[Face2] TEXT,
	[Face] TEXT,
	[Slice] TEXT,
	[Date1] TEXT,
	[Date2] TEXT,
	[Code] TEXT,
	[Description] TEXT,
	[Geo] TEXT,
	[Sign] TEXT,
	[Account] TEXT,
	[Process] TEXT,
    [Asset] TEXT,
    [Deal] TEXT,
    [Item] TEXT,
	[Debt] TEXT,
	[Price] TEXT,
	[Role] TEXT,
	[Info] TEXT,
	[Meter] TEXT,
	[MeterValue] TEXT,
	[Unit] TEXT,
	[More] TEXT,
	[Mark] TEXT
 );