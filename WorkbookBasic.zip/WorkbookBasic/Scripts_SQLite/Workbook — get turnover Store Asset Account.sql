SELECT 

[T1].[Face1], 
--[T6].[Code] AS [Face1Code],

[T1].[Slice], 
--[T3].[Code] AS [SliceCode],

--[T1].[Date1] AS [Date1], 

[T1].[Sign], 
--[T12].[Code] AS [SignCode],

[T1].[Account], 
--[T9].[Code] AS [AccountCode],

[T1].[Asset], 
--[T21].[Code] AS [AssetCode],

[T1].[Meter], 
--[T22].[Code] AS [MeterCode],

[T1].[Unit], 
--[T13].[Code] AS [UnitCode],

[T1].[Mark],
--[T2].[Code] AS [MarkCode],

SUM(CAST([T1].[MeterValue] AS REAL)) AS MeterValue

FROM [Workbook1] AS [T1]                            

--LEFT JOIN [Mark] AS [T2] ON [T1].[Mark]=[T2].[Id] 
--LEFT JOIN [Slice] AS [T3] ON [T1].[Slice]=[T3].[Id]      
--LEFT JOIN [Face] AS [T6] ON [T1].[Face1]=[T6].[Id]  
--LEFT JOIN [Account] AS [T9] ON [T1].[Account]=[T9].[Id] 
--LEFT JOIN [Sign] AS T12 ON [T1].[Sign]=[T12].[Id] 
--LEFT JOIN [Unit] AS [T13] ON [T1].[Unit]=[T13].[Id] 
--LEFT JOIN [Asset] AS [T21] ON [T1].[Asset]=[T21].[Id] 
--LEFT JOIN [Meter] AS [T22] ON [T1].[Meter]=[T22].[Id]

WHERE 
[T1].[Slice] = 1 AND     ---Accounting
[T1].[Mark] = 2 AND     --- CD
[T1].[Meter] = 13 AND   ---Quantity  
[T1].[Unit] = 22 AND   ---Unit.KZT
[T1].[Account] IS NOT NUll AND
[T1].[Sign] IS NOT NULL AND

[T1].[Asset] = 532 

GROUP BY 
[T1].[Face1],
--[T6].[Code],

[T1].[Slice], 
--[T3].[Code],

[T1].[Asset], 
--[T21].[Code],

[T1].[Sign], 
--[T12].[Code],

[T1].[Account], 
--[T9].[Code],

[T1].[Meter], 
--[T22].[Code],

[T1].[Unit],
--[T13].[Code],

[T1].[Mark]
--[T2].[Code]