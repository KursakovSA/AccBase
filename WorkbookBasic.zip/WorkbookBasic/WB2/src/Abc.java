import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

public class Abc {
	// origin - 28.09.2023, last edit - 29.11.2023
	public List<ModelDto> basic = new ArrayList<ModelDto>();
	public TreeSet<String> catalogAsset = new TreeSet<String>(); // TODO
	public TreeSet<String> codePayInfo = new TreeSet<String>(); // TODO
	public TreeSet<String> markupPrice = new TreeSet<String>(); // TODO
	public TreeSet<String> salePrice = new TreeSet<String>(); // TODO
	public TreeSet<String> accountTable = new TreeSet<String>(); // TODO
	public TreeSet<String> accountMatching = new TreeSet<String>(); // TODO
	public TreeSet<String> accountClose = new TreeSet<String>(); // TODO
	public TreeSet<String> storeFace = new TreeSet<String>(); // TODO
	public TreeSet<String> userFace = new TreeSet<String>(); // TODO
	public TreeSet<String> departmentFace = new TreeSet<String>(); // TODO
	public TreeSet<String> cashFace = new TreeSet<String>(); // TODO
	public TreeSet<String> bankFace = new TreeSet<String>(); // TODO
	public TreeSet<String> staffTableFace = new TreeSet<String>(); // TODO
	public TreeSet<String> example = new TreeSet<String>(); // TODO
	public TreeSet<String> templateDoc = new TreeSet<String>(); // TODO
	public TreeSet<String> report = new TreeSet<String>(); // TODO
	public TreeSet<String> segmentTax = new TreeSet<String>(); // TODO

	public static Abc getAbc(String conn) {
		// origin - 28.11.2023, last edit - 29.11.2023
		Abc res = new Abc();
		try {
			res = new Abc(conn, Qry.templateMoreAbcBasic);
			Logger.add2("Abc.static ctor, abc=" + res + ", conn=" + conn, "", "Abc");
		} catch (Exception ex) {
			Logger.add2("Abc.static ctor, ex=" + ex.getMessage(), "StackTrace=" + ex.getStackTrace(), "Abc");
		}
		return res;
	}

	public Abc(String DbConn, String qry) throws Exception {
		// origin - 26.11.2023, last edit - 29.11.2023
		try {
			this.basic = DAL.getBasic(DbConn, qry);
		} catch (Exception ex) {
			Logger.add2("Abc.ctor.basic, ex=" + ex.getMessage(), "StackTrace=" + ex.getStackTrace(), "Abc");
		} finally {
		}
	}

	public Abc() {
		// origin - 13.11.2023, last edit - 27.11.2023
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 28.11.2023
		Abc testAbc = new Abc();
		Logger.add("Abc.test, testAbc=" + testAbc, "", "Abc");
	}

	public String toString() {
		// origin - 21.11.2023, last edit - 27.11.2023
		String res = "{";
		if (this.basic.isEmpty() != true) {
			res = res + "basic.size=" + this.basic.size();
		}
		if (this.catalogAsset.isEmpty() != true) {
			res = res + "catalogAsset.size=" + this.catalogAsset.size();
		}
		if (this.markupPrice.isEmpty() != true) {
			res = res + "markupPrice.size=" + this.markupPrice.size();
		}
		if (this.salePrice.isEmpty() != true) {
			res = res + "salePrice.size=" + this.salePrice.size();
		}
		if (this.accountTable.isEmpty() != true) {
			res = res + "accountTable.size=" + this.accountTable.size();
		}
		if (this.accountMatching.isEmpty() != true) {
			res = res + "accountMatching.size=" + this.accountMatching.size();
		}
		if (this.accountClose.isEmpty() != true) {
			res = res + "accountClose.size=" + this.accountClose.size();
		}
		if (this.storeFace.isEmpty() != true) {
			res = res + "storeFace.size=" + this.storeFace.size();
		}
		if (this.userFace.isEmpty() != true) {
			res = res + "userFace.size=" + this.userFace.size();
		}
		if (this.departmentFace.isEmpty() != true) {
			res = res + "departmentFace.size=" + this.departmentFace.size();
		}
		if (this.cashFace.isEmpty() != true) {
			res = res + "cashFace.size=" + this.cashFace.size();
		}
		if (this.bankFace.isEmpty() != true) {
			res = res + "bankFace.size=" + this.bankFace.size();
		}
		if (this.staffTableFace.isEmpty() != true) {
			res = res + "staffTableFace.size=" + this.staffTableFace.size();
		}
		if (this.example.isEmpty() != true) {
			res = res + "example.size=" + this.example.size();
		}
		if (this.templateDoc.isEmpty() != true) {
			res = res + "templateDoc.size=" + this.templateDoc.size();
		}
		if (this.report.isEmpty() != true) {
			res = res + "report.size=" + this.report.size();
		}
		if (this.segmentTax.isEmpty() != true) {
			res = res + "segmentTax.size=" + this.segmentTax.size();
		}
		res = res + "}";
		return res;
	}
}
