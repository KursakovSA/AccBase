import java.util.List;
import java.util.TreeSet;

public class Abc {
	// origin - 28.09.2023, last edit - 26.11.2023
	public List<ModelDto> basic;
	public TreeSet<String> catalogAsset = new TreeSet<String>(); // TODO
	public TreeSet<String> codePayInfo = new TreeSet<String>(); // TODO
	public TreeSet<String> markupPrice = new TreeSet<String>(); // TODO
	public TreeSet<String> salePrice = new TreeSet<String>(); // TODO
	public TreeSet<String> accountTable = new TreeSet<String>(); // TODO
	public TreeSet<String> accountMatching = new TreeSet<String>(); // TODO
	public TreeSet<String> accountClose = new TreeSet<String>(); // TODO
	public TreeSet<String> storeFace = new TreeSet<String>(); // TODO
	public TreeSet<String> userFace = new TreeSet<String>(); // TODO
	public TreeSet<String> departmentFace = new TreeSet<String>(); // TODO
	public TreeSet<String> cashFace = new TreeSet<String>(); // TODO
	public TreeSet<String> bankFace = new TreeSet<String>(); // TODO
	public TreeSet<String> staffTableFace = new TreeSet<String>(); // TODO
	public TreeSet<String> example = new TreeSet<String>(); // TODO
	public TreeSet<String> templateDoc = new TreeSet<String>(); // TODO
	public TreeSet<String> report = new TreeSet<String>(); // TODO
	public TreeSet<String> segmentTax = new TreeSet<String>(); // TODO

	public Abc(String DbConn, String qry) throws Exception {
		// origin - 26.11.2023, last edit - 26.11.2023
		try {
			this.basic = DAL.getBasic(DbConn, qry);
			Logger.add("Abc.ctor, DbConn=" + DbConn, "qry=" + qry, "Abc");
		} catch (Exception ex) {
			Logger.add("Abc, ex=" + ex.getMessage(), "StackTrace=" + ex.getStackTrace(), "Abc");
		} finally {
		}
	}

//	public Abc(String DbConn) throws Exception {
//		// origin - 21.11.2023, last edit - 26.11.2023
//		try {
//			this.basic = DAL.getBasic(this.dbConn, Qry.templateMoreAbcBasic);
//		} catch (Exception ex) {
//			Logger.add2("Abc, ex=" + ex.getMessage(), "StackTrace=" + ex.getStackTrace(), "Abc");
//		} finally {
//		}
//	}

//	public Abc() throws Exception {
//		// origin - 13.11.2023, last edit - 26.11.2023
//		try {
//			this.basic = DAL.getBasic(this.dbConn, Qry.templateMoreAbcBasic);
//		} catch (Exception ex) {
//			Logger.add2("Abc, ex=" + ex.getMessage(), "StackTrace=" + ex.getStackTrace(), "Abc_ctor()");
//		} finally {
//		}
//	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 13.10.2023
	}

	public String toString() {
		// origin - 21.11.2023, last edit - 26.11.2023
		String res = "{";
		if (this.basic.isEmpty() != true) {
			res = res + "basic.size=" + this.basic.size();
		}
		if (this.catalogAsset.isEmpty() != true) {
			res = res + "catalogAsset.size=" + this.catalogAsset.size();
		}
		res = res + "}";
		return res;// this.getClass().getName() + "{" + "basic.size=" + this.basic.size() + '}';
	}
}
