import java.io.File;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.TreeSet;

public class Abc {
	// origin - 28.09.2023, last edit - 30.10.2023
	public TreeSet<String> basic; // TODO
	public TreeSet<String> catalogAsset; // TODO
	public TreeSet<String> codePayInfo; // TODO
	public TreeSet<String> transfer = new TreeSet<String>(
			Arrays.asList("EsfXML", "MT100", "MT102", "SwiftOPV", "SwiftGFSS", "SwiftOSMS"));
	public TreeSet<String> markupPrice; // TODO
	public TreeSet<String> salePrice; // TODO
	public TreeSet<String> relaySlice = new TreeSet<String>(Arrays.asList("ToAccounting", "ToFact", "ToPlan"));
	public TreeSet<String> relayMark = new TreeSet<String>(Arrays.asList("ToArc", "ToCD", "ToDD", "ToDelD"));
	public TreeSet<String> accountTable; // TODO
	public TreeSet<String> accountMatching; // TODO
	public TreeSet<String> accountClose; // TODO
	public TreeSet<String> storeFace; // TODO
	public TreeSet<String> userFace; // TODO
	public TreeSet<String> departmentFace; // TODO
	public TreeSet<String> cashFace; // TODO
	public TreeSet<String> bankFace; // TODO
	public TreeSet<String> staffTableFace; // TODO
	public TreeSet<String> example; // TODO
	public TreeSet<String> templateDoc; // TODO
	public TreeSet<String> report; // TODO
	public TreeSet<String> segmentTax; // TODO

	// dbs
	public static TreeSet<String> dbTable = new TreeSet<String>(
			Arrays.asList("Account", "Asset", "Deal", "Debt", "Face", "Geo", "Info", "Item", "Mark", "Meter", "Price",
					"Process", "Role", "Sign", "Slice", "Unit", "Workbook"));
	public static String dbDir = System.getProperty("user.dir"); // + File.separator + "Db";
	public static String dbGlobalFile = "DatabaseGlobal.sqlite3";
	public static String dbGlobalPath = dbDir + File.separator + dbGlobalFile;
	public static String dbTemplateFile = "DatabaseTemplate.sqlite3";
	public static String dbTemplatePath = dbDir + File.separator + dbTemplateFile;
	public static String dbLargeFile = "DatabaseLarge.sqlite3";
	public static String dbLargePath = dbDir + File.separator + dbLargeFile;
	public static String dbWorkAutoCreateFile = "MyBase1.sqlite3";
	public static String dbWorkAutoCreatePath = dbDir + File.separator + dbWorkAutoCreateFile;
	public static TreeSet<String> dbSystemNorm = new TreeSet<String>(
			Arrays.asList(dbGlobalPath, dbTemplatePath, dbLargePath));
//	public static TreeSet<String> dbColumnName = new TreeSet<String>(Arrays.asList("Id", "Parent", "Face1", "Face2",
//			"Face", "Slice", "Date1", "Date2", "Code", "Description", "Sign", "Account", "Geo", "Role", "Info", "Meter",
//			"MeterValue", "Unit", "More", "Mark", "Process", "Asset", "Deal", "Item", "Debt", "Price"));

	// dirs
	public static String startDir = System.getProperty("user.dir");
	public static String lastSaveDir = System.getProperty("user.dir");
	public static String lastSelectFileDir = System.getProperty("user.dir");
	public static String mediaDir = System.getProperty("user.dir") + File.separator + "media";
	public static String swiftDir = System.getProperty("user.dir") + File.separator + "swift";
	public static String docDir = System.getProperty("user.dir") + File.separator + "doc";
	public static String esfDir = System.getProperty("user.dir") + File.separator + "esf";
	public static String templateDocDir = System.getProperty("user.dir") + File.separator + "templateDoc";
	public static LocalDate startDate = LocalDate.of(2000, 01, 01);
	public static LocalDate endDate = LocalDate.of(2060, 12, 31);

	// logs
	public static String eventLogFile = "eventLog.txt"; // basic log default
	public static String eventLogPath = Abc.startDir + File.separator + eventLogFile;
	public static TreeSet<String> logAll = new TreeSet<String>(); // TODO

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 28.10.2023
	}
}
