import java.io.*;
import java.time.*;
import java.util.*;

public class Abc {
	// origin - 28.09.2023, last edit - 16.11.2023
	public String dbConn = new String();
	public List<ModelDto> basic; // TODO
	public TreeSet<String> catalogAsset; // TODO
	public TreeSet<String> codePayInfo; // TODO
	public TreeSet<String> markupPrice; // TODO
	public TreeSet<String> salePrice; // TODO
	public TreeSet<String> accountTable; // TODO
	public TreeSet<String> accountMatching; // TODO
	public TreeSet<String> accountClose; // TODO
	public TreeSet<String> storeFace; // TODO
	public TreeSet<String> userFace; // TODO
	public TreeSet<String> departmentFace; // TODO
	public TreeSet<String> cashFace; // TODO
	public TreeSet<String> bankFace; // TODO
	public TreeSet<String> staffTableFace; // TODO
	public TreeSet<String> example; // TODO
	public TreeSet<String> templateDoc; // TODO
	public TreeSet<String> report; // TODO
	public TreeSet<String> segmentTax; // TODO
	//static
	public static TreeSet<String> transferList;
	public static TreeSet<String> relaySliceList;
	public static TreeSet<String> relayMarkList;
	public static TreeSet<String> dbTableNormList;
	public static String dbDir;
	public static String dbGlobalFile;
	public static String dbGlobalPath;
	public static String dbTemplateFile;
	public static String dbTemplatePath;
	public static String dbWorkAutoCreateFile;
	public static String dbWorkAutoCreatePath;
	public static TreeSet<String> dbSystemNormList;
	public static String startDir;
	public static String lastSaveDir;
	public static String lastSelectFileDir;
	public static String mediaDir;
	public static String docDir;
	public static String templateDocDir;
	public static LocalDate minDateSupported;
	public static LocalDate maxDateSupported;
	public static String eventLogFile;
	public static String eventLogPath;
	public static TreeSet<String> logAll = new TreeSet<String>(); // TODO ??

	static {
		// origin - 09.11.2023, last edit - 17.11.2023
		transferList = new TreeSet<String>(Arrays.asList("EsfXML", "MT100", "MT102", "SwiftOPV", "SwiftGFSS", "SwiftOSMS"));
		relaySliceList = new TreeSet<String>(Arrays.asList("ToAccounting", "ToFact", "ToPlan"));
		relayMarkList = new TreeSet<String>(Arrays.asList("ToArc", "ToCD", "ToDD", "ToDelD"));
		dbTableNormList = new TreeSet<String>(Arrays.asList("Account", "Asset", "Deal", "Debt", "Face", "Geo", "Info", "Item",
				"Mark", "Meter", "Price", "Process", "Role", "Sign", "Slice", "Unit", "Workbook"));
		dbDir = System.getProperty("user.dir");
		dbGlobalFile = "DatabaseGlobal.sqlite3"; //TODO --- sqlite 4 ???
		dbGlobalPath = dbDir + File.separator + dbGlobalFile;
		dbTemplateFile = "DatabaseTemplate.sqlite3"; //TODO --- sqlite 4 ???
		dbTemplatePath = dbDir + File.separator + dbTemplateFile;
		dbWorkAutoCreateFile = "MyBase1.sqlite3"; //TODO --- sqlite 4 ???
		dbWorkAutoCreatePath = dbDir + File.separator + dbWorkAutoCreateFile;
		dbSystemNormList = new TreeSet<String>(Arrays.asList(dbGlobalPath, dbTemplatePath));
		startDir = dbDir;
		lastSaveDir = dbDir;
		lastSelectFileDir = dbDir;
		mediaDir = dbDir + File.separator + "media";
		docDir = dbDir + File.separator + "doc";
		templateDocDir = dbDir + File.separator + "templateDoc";
		minDateSupported = LocalDate.of(2020, 01, 01);
		maxDateSupported = LocalDate.of(2060, 12, 31);
		eventLogFile = "eventLog.csv"; // basic log default
		eventLogPath = startDir + File.separator + eventLogFile;
	}
	
	public Abc() throws Exception {
		// origin - 13.11.2023, last edit - 17.11.2023
		this.dbConn = DAL.currConnWork;
		this.basic = DAL.getBasic(this.dbConn, Qry.templateMoreAbcBasic);
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 13.10.2023
	}
}
