public class Asset extends Model {
	// origin - 28.09.2023, last edit - 06.12.2023
	public static Asset root;
	public Asset parent;
	public Geo geo;
	public Role role;
	public Info info;
	public Unit unit;
	
	static {
		root = new Asset("Asset", "Asset", "AssetData");
	}
	
	public Asset(String Id, String Code, String Description) {
		// origin - 05.12.2023, last edit - 05.12.2023
		this.id = Id;
		this.code = Code;
		this.description = Description;
	}
	
	public Asset() {
		// origin - 05.12.2023, last edit - 05.12.2023
	}

	public static void test()  {
		// origin - 28.10.2023, last edit - 05.12.2023
    	Logger.add("Asset.test, Asset.root=" + Asset.root, "", "Asset");
	}
}