public class Asset extends Model {
	// origin - 28.09.2023, last edit - 28.11.2023
	public Geo geo = new Geo();
	public Model role = new Model();
	public Model info = new Model();
	public Unit unit = new Unit();

	public static void test()  {
		// origin - 28.10.2023, last edit - 28.11.2023
		Asset testAsset = new Asset();
    	Logger.add("Asset.test, testAsset=" + testAsset, "", "Asset");
	}
}