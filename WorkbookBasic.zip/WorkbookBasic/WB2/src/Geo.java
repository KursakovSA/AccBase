public class Geo extends Model {
	// origin - 28.09.2023, last edit - 28.11.2023
	public Model role = new Model();
    public Unit unit = new Unit();
    
    public static void test() {
		// origin - 28.10.2023, last edit - 28.11.2023
    	Geo testGeo = new Geo();
    	Logger.add("Geo.test, testGeo=" + testGeo, "", "Geo");
	}
}
