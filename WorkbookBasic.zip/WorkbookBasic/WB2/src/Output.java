import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.TreeSet;

public class Output extends Model {
	// origin - 30.09.2023, last edit - 06.12.2023
	private static String dir = new String();
	private String file = new String();
	private String path = new String();
	
	static {
		dir = WB.docDir;
		standard = new TreeSet<String>(Arrays.asList("EsfXML", "MT100", "MT102", "SwiftOPV", "SwiftGFSS", "SwiftOSMS"));
	}
	
	public static String formatter(String name, String strAdd) {//TODO
		// origin - 05.12.2023, last edit - 05.12.2023
		String res = "";
		strAdd = Etc.fixTrim(strAdd);
		res = res + Etc.fixTrim(name) + "=" + strAdd + ", ";
		return res;
	}

	public static String appender(String strRes, String strAdd) {//TODO
		// origin - 05.12.2023, last edit - 05.12.2023
		String res = strRes;
		res = res + strAdd;
		return res;
	}


	public static StringBuilder addHeader(StringBuilder txtSwift) {
		// origin - 19.10.2023, last edit - 19.10.2023
		StringBuilder addTxtSwift = new StringBuilder(txtSwift);
		// TODO
		return addTxtSwift;
	}

	public static StringBuilder addDetail(StringBuilder txtSwift) {
		// origin - 19.10.2023, last edit - 19.10.2023
		StringBuilder addTxtSwift = new StringBuilder(txtSwift);
		// TODO
		return addTxtSwift;
	}

	public static StringBuilder addFooter(StringBuilder txtSwift) {
		// origin - 19.10.2023, last edit - 19.10.2023
		StringBuilder addTxtSwift = new StringBuilder(txtSwift);
		// TODO
		return addTxtSwift;
	}

	public static StringBuilder getSwiftOPV(Workbook WorkbookSalary) {
		// origin - 30.09.2023, last edit - 26.11.2023
		Output currOut = new Output();
		currOut.file = "swift_OPV.txt";
		currOut.path = dir + File.separator + currOut.file;
		Logger.add("getSwiftOPV, currOut.outputPath=" + currOut.path, "", "Output");
		StringBuilder txtSwift = new StringBuilder("");
		addHeader(txtSwift);
		addDetail(txtSwift);
		addFooter(txtSwift);

		Logger.add(txtSwift.length(), "txtSwift.length()", "Out.SwiftOPV()");
		return txtSwift;
	}

	public static void getOut() throws Exception {
		// origin - 19.10.2023, last edit - 06.12.2023
		StringBuilder textSwift = getSwiftOPV(null); // TODO
		Output currOut = new Output();
		currOut.file = "swift_OPV.txt";
		currOut.path = dir + File.separator + currOut.file;
		Path pf = Paths.get(currOut.path);
		Logger.add("getOut, currOut.outputPath=" + currOut.path, "", "Output");
		WB.writeReplace(pf, textSwift.toString());
		WB.openFile(currOut.file);
	}
	
	public Output() {
		// origin - 04.12.2023, last edit - 04.12.2023
		path = dir + File.separator + file;
	}

	public static void test() {
		// origin - 28.10.2023, last edit - 06.12.2023
	}
}
