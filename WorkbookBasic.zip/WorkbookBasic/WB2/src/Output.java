import java.io.*;
import java.util.Arrays;
import java.util.TreeSet;

public class Output {
	// origin - 30.09.2023, last edit - 26.11.2023
	private static String dir;
	private String file;
	private String path;
	public static TreeSet<String> allow;
	
	static {
		dir = WB.docDir;
		allow = new TreeSet<String>(Arrays.asList("EsfXML", "MT100", "MT102", "SwiftOPV", "SwiftGFSS", "SwiftOSMS"));
	}

	public static StringBuilder addHeader(StringBuilder txtSwift) {
		// origin - 19.10.2023, last edit - 19.10.2023
		StringBuilder addTxtSwift = new StringBuilder(txtSwift);
		// TODO
		return addTxtSwift;
	}

	public static StringBuilder addDetail(StringBuilder txtSwift) {
		// origin - 19.10.2023, last edit - 19.10.2023
		StringBuilder addTxtSwift = new StringBuilder(txtSwift);
		// TODO
		return addTxtSwift;
	}

	public static StringBuilder addFooter(StringBuilder txtSwift) {
		// origin - 19.10.2023, last edit - 19.10.2023
		StringBuilder addTxtSwift = new StringBuilder(txtSwift);
		// TODO
		return addTxtSwift;
	}

	public static StringBuilder getSwiftOPV(Workbook WorkbookSalary) {
		// origin - 30.09.2023, last edit - 26.11.2023
		Output currOut = new Output();
		currOut.file = "swift_OPV.txt";
		currOut.path = dir + File.separator + currOut.file;
		Logger.add("getSwiftOPV, currOut.outputPath=" + currOut.path, "", "Output");
		StringBuilder txtSwift = new StringBuilder("");
		addHeader(txtSwift);
		addDetail(txtSwift);
		addFooter(txtSwift);

		Logger.add(txtSwift.length(), "txtSwift.length()", "Out.SwiftOPV()");
		return txtSwift;
	}

	public static void getOut() throws Exception {
		// origin - 19.10.2023, last edit - 26.11.2023
		StringBuilder textSwift = getSwiftOPV(null); // TODO
		Output currOut = new Output();
		currOut.file = "swift_OPV.txt";
		currOut.path = dir + File.separator + currOut.file;
		Logger.add("getOut, currOut.outputPath=" + currOut.path, "", "Output");
		WB.writeFile(currOut.file, textSwift.toString()); // TODO
		WB.openFile(currOut.file);
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 28.10.2023
	}
}
