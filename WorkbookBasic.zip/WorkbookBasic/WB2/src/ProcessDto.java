public class ProcessDto extends ModelDto {
	// origin - 01.10.2023, last edit - 28.10.2023
    public String asset;
    public String deal;
    public String item;
    public String debt;
    public String price;
    
    public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 28.10.2023
	}
}
