public class Face extends Model {
	// origin - 28.09.2023, last edit - 28.11.2023
	public Geo geo = new Geo();
	public Model role = new Model();
	public Model info = new Model();

	public static void test() {
		// origin - 28.10.2023, last edit - 28.11.2023
		Face testFace = new Face();
    	Logger.add("Face.test, testFace=" + testFace, "", "Face");
	}
}
