public class Face extends Model {
	// origin - 28.09.2023, last edit - 28.10.2023
	public Geo geo;
	public Model role;
	public Model info;

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 28.10.2023
	}
}
