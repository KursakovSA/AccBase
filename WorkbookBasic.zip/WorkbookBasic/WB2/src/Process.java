public class Process extends Model {
	// origin - 28.09.2023, last edit - 28.10.2023
	public Face face1;
    public Face face2;
    public Face face;
    public Model slice;
    public Geo geo;
    public Model sign;
    public Account account;
    public Asset asset;
    public Deal deal;
    public Model item;
    public Debt debt;
    public Price price;
    public Model role;
    public Model info;
    public Meter meter;
    public String meterValue;
    public Unit unit;
    public Model mark;
    
    public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 28.10.2023
	}
}
