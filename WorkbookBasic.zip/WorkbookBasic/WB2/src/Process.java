public class Process extends Model {
	// origin - 28.09.2023, last edit - 27.11.2023
	public Face face1 = new Face();
    public Face face2 = new Face();
    public Face face = new Face();
    public Model slice = new Model();
    public Geo geo = new Geo();
    public Model sign = new Model();
    public Account account = new Account();
    public Asset asset = new Asset();
    public Deal deal = new Deal();
    public Model item = new Model();
    public Debt debt = new Debt();
    public Price price = new Price();
    public Model role = new Model();
    public Model info = new Model();
    public Meter meter = new Meter();
    public String meterValue = new String();
    public Unit unit = new Unit();
    public Model mark = new Model();
    
    public static void test() {
		// origin - 28.10.2023, last edit - 27.11.2023
    	Process testProcess = new Process();
    	Logger.add("Process.test, testProcess=" + testProcess, "", "Process");
	}
}
