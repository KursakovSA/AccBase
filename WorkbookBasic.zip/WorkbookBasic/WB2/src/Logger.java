import java.io.File;
import java.time.*;

public class Logger {
	// origin - 23.10.2023, last edit - 25.11.2023
	//private static StringBuilder eventLogSpecial;
	private static int eventCounter;
	private static StringBuilder eventLog;
	private static StringBuilder eventLog2;
	private static OffsetDateTime eventGlobalStart;
	private static OffsetDateTime eventGlobalEnd;
	private static OffsetDateTime eventLocalStart;
	private static OffsetDateTime eventLocalEnd;
	private static final String eventLogFile;
	private static final String eventLogPath;

	static {
		eventCounter = 0;
		eventLog = new StringBuilder("");
		eventLog2 = new StringBuilder("");
		eventLogFile = "eventLog.csv"; // basic log default
		eventLogPath = WB.startDir + File.separator + eventLogFile;
	}

	public static void getGlobalStart() {
		// origin - 25.10.2023, last edit - 25.11.2023
		Logger.eventGlobalStart = Etc.getOffsetDateTimeNow();
		add("Logger.getGlobalStart, eventGlobalStart=" + eventGlobalStart, "", "Logger");
	}

	public static void getLocalStart() {
		// origin - 21.10.2023, last edit - 02.11.2023
		// getLocalStart(); //--- for copy/paste
		eventLocalStart = Etc.getOffsetDateTimeNow();
	}

	public static void getLocalEnd() {
		// origin - 21.10.2023, last edit - 25.11.2023
		// getLocalEnd(); //--- for copy/paste
		eventLocalEnd = Etc.getOffsetDateTimeNow();
		add2("Logger.getLocalEnd, durationLocal=" + Etc.getDuration(eventLocalStart, eventLocalEnd) + " ms", "","Logger");
	}

	public static void eventTrace() throws Exception {
		// origin - 26.09.2023, last edit - 25.10.2023
		getEventEnd();
		WB.writeFile(eventLogPath, eventLog.toString());
		WB.openFile(eventLogPath);
	}

	public static void getEventEnd() throws Exception {
		// origin - 21.10.2023, last edit - 24.11.2023
		eventGlobalEnd = Etc.getOffsetDateTimeNow();
		add("Logger.getEventEnd, eventGlobalEnd=" + eventGlobalEnd, "", "Logger");
		add("Logger.getEventEnd, durationGlobal=" + Etc.getDuration(eventGlobalStart, eventGlobalEnd) + " ms", "",
				"Logger");
		getEventEnd2();
	}

	public static void getEventEnd2() {
		// origin - 03.11.2023, last edit - 15.11.2023
		// TODO add event2 = detail
		if (eventLog2.length() != 0) {
			add(" ");
			add("Log detail");
			add(" ");
			add(eventLog2.toString());
		}
	}

	public static void add2(Object EventObj, String EventCont, String EventMeth) {
		// origin - 03.11.2023, last edit - 04.11.2023
		eventCounter = eventCounter + 1;
		eventAppender2(eventFormatter(EventObj, EventCont, EventMeth));
	}

	public static void add(Object EventObj, String EventCont, String EventMeth) {
		// origin - 26.09.2023, last edit - 24.11.2023
		eventCounter = eventCounter + 1;
		eventAppender(eventFormatter(EventObj, EventCont, EventMeth));
		try {
			WB.writeFile(eventLogPath, eventLog.toString());
		} catch (Exception ex) {
		} finally {
		}
	}

	public static void add(String str) {
		// origin - 03.11.2023, last edit - 24.11.2023
		eventCounter = eventCounter + 1;
		eventAppender(str + System.lineSeparator());
		try {
			WB.writeFile(eventLogPath, eventLog.toString());
		} catch (Exception ex) {
		} finally {
		}
	}

	public static String eventFormatter(Object EventObj, String EventCont, String EventMeth) {
		// origin - 21.10.2023, last edit - 15.11.2023
		return "#" + eventCounter + "; " + Etc.getOffsetDateTimeNow() + "; " + EventObj + "; " + EventCont + "; "
				+ EventMeth + ";" + System.lineSeparator();
	}

	public static void eventAppender2(String currEventAdd) {
		// origin - 03.11.2023, last edit - 03.11.2023
		eventLog2.append(currEventAdd.toString());
	}

	public static void eventAppender(String currEventAdd) {
		// origin - 21.10.2023, last edit - 21.10.2023
		eventLog.append(currEventAdd.toString());
	}

	public static void eventAppender(String currEventAdd, StringBuilder eventLogSpecial) {// TODO
		// origin - 23.10.2023, last edit - 23.10.2023
		eventLogSpecial.append(currEventAdd.toString());
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 28.10.2023
	}
}
