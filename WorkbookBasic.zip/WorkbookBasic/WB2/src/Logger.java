import java.time.OffsetDateTime;

public class Logger {
	// origin - 23.10.2023, last edit - 28.10.2023
	public static StringBuilder eventLogSpecial;
	public static int eventCounter = 0;
	public static StringBuilder eventLog = new StringBuilder("");
	public static OffsetDateTime eventGlobalStart;
	public static OffsetDateTime eventGlobalEnd;
	public static OffsetDateTime eventLocalStart;
	public static OffsetDateTime eventLocalEnd;
	
	public static void getGlobalStart() {
		// origin - 25.10.2023, last edit - 25.10.2023
		Logger.eventGlobalStart = Calc.getOffsetDateTimeNow();
		Logger.add("eventGlobalStart=" + Logger.eventGlobalStart, "Logger.getGlobalStart()", "getGlobalStart()()");
	}

	public static void getLocalStart() {// less test
		// origin - 21.10.2023, last edit - 25.10.2023
		// getLocalStart(); //--- for copy/paste
		eventLocalStart = Calc.getOffsetDateTimeNow();
		// add("eventLocalStart=" + eventLocalStart, "Logger.getLocalStart()",
		// "getLocalStart()");
	}

	public static void getLocalEnd() {// less test
		// origin - 21.10.2023, last edit - 25.10.2023
		// getLocalEnd(); //--- for copy/paste
		eventLocalEnd = Calc.getOffsetDateTimeNow();
		// add("eventLocalEnd=" + eventLocalEnd, "Calc.getOffsetDateTimeNow()",
		// "getOutVAT()");
		add("durationLocal=" + Calc.getDurationInMillis(eventLocalStart, eventLocalEnd) + " ms",
				"Calc.getDurationInMillis()", "getOutVAT()");
	}

	public static void eventTrace() throws Exception {
		// origin - 26.09.2023, last edit - 25.10.2023
		getEventEnd();
		WB.writeFile(Abc.eventLogPath, eventLog.toString());
		WB.openFile(Abc.eventLogPath);
	}

	public static void getEventEnd() throws Exception {
		// origin - 21.10.2023, last edit - 25.10.2023
		eventGlobalEnd = Calc.getOffsetDateTimeNow();
		add("eventGlobalEnd=" + eventGlobalEnd, "Calc.getOffsetDateTimeNow()", "eventTrace()");
		add("durationGlobal=" + Calc.getDurationInMillis(eventGlobalStart, eventGlobalEnd) + " ms",
				"Calc.getDurationInMillis()", "eventTrace()");
	}

	public static void add(Object EventObj, String EventCont, String EventMeth) {
		// origin - 26.09.2023, last edit - 27.10.2023
		eventCounter = eventCounter + 1;
		eventAppender(eventFormatter(EventObj, EventCont, EventMeth));
		try {
			WB.writeFile(Abc.eventLogPath, eventLog.toString());	
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		} finally {
		}
	}

//	public static void add(Object EventObj, String EventCont, String EventMeth, StringBuilder eventLogSpecial) {// TODO
//		// origin - 23.09.2023, last edit - 25.10.2023
//		eventCounter = eventCounter + 1;
//		eventAppender(eventFormatter(EventObj, EventCont, EventMeth), eventLogSpecial);
//	}

	public static String eventFormatter(Object EventObj, String EventCont, String EventMeth) {
		// origin - 21.10.2023, last edit - 21.10.2023
		return "[#" + eventCounter + "] (" + Calc.getOffsetDateTimeNow() + "), " + EventObj + "), (" + EventCont
				+ "), (" + EventMeth + ")" + System.lineSeparator();
	}

	public static void eventAppender(String currEventAdd) {
		// origin - 21.10.2023, last edit - 21.10.2023
		eventLog.append(currEventAdd.toString());
	}

	public static void eventAppender(String currEventAdd, StringBuilder eventLogSpecial) {// TODO
		// origin - 23.10.2023, last edit - 23.10.2023
		eventLogSpecial.append(currEventAdd.toString());
	}
	
	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 28.10.2023
	}
}
