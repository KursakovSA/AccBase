import java.time.*;

public class Logger {
	// origin - 23.10.2023, last edit - 16.11.2023
	public static StringBuilder eventLogSpecial;
	public static int eventCounter;
	public static StringBuilder eventLog;
	public static StringBuilder eventLog2;
	public static OffsetDateTime eventGlobalStart;
	public static OffsetDateTime eventGlobalEnd;
	public static OffsetDateTime eventLocalStart;
	public static OffsetDateTime eventLocalEnd;

	static {
		eventCounter = 0;
		eventLog = new StringBuilder("");
		eventLog2 = new StringBuilder("");
	}

	public static void getGlobalStart() {
		// origin - 25.10.2023, last edit - 04.11.2023
		Logger.eventGlobalStart = Etc.getOffsetDateTimeNow();
		Logger.add("eventGlobalStart=" + Logger.eventGlobalStart, "Logger.getGlobalStart()", "getGlobalStart()()");
	}

	public static void getLocalStart() {// less test
		// origin - 21.10.2023, last edit - 02.11.2023
		// getLocalStart(); //--- for copy/paste
		eventLocalStart = Etc.getOffsetDateTimeNow();
	}

	public static void getLocalEnd() {// less test
		// origin - 21.10.2023, last edit - 04.11.2023
		// getLocalEnd(); //--- for copy/paste
		eventLocalEnd = Etc.getOffsetDateTimeNow();
		add2("durationLocal=" + Etc.getDuration(eventLocalStart, eventLocalEnd) + " ms", "Etc.getDuration()",
				"getOutVAT()");
	}

	public static void eventTrace() throws Exception {
		// origin - 26.09.2023, last edit - 25.10.2023
		getEventEnd();
		WB.writeFile(Abc.eventLogPath, eventLog.toString());
		WB.openFile(Abc.eventLogPath);
	}

	public static void getEventEnd() throws Exception {
		// origin - 21.10.2023, last edit - 04.11.2023
		eventGlobalEnd = Etc.getOffsetDateTimeNow();
		add("eventGlobalEnd=" + eventGlobalEnd, "Calc.getOffsetDateTimeNow()", "eventTrace()");
		add("durationGlobal=" + Etc.getDuration(eventGlobalStart, eventGlobalEnd) + " ms", "Etc.getDuration()",
				"eventTrace()");
		getEventEnd2();
	}

	public static void getEventEnd2() {
		// origin - 03.11.2023, last edit - 15.11.2023
		// TODO add event2 = detail
		if (eventLog2.length() != 0) {
			add(" ");
			add("Log detail");
			add(" ");
			add(eventLog2.toString());
		}
	}

	public static void add2(Object EventObj, String EventCont, String EventMeth) {
		// origin - 03.11.2023, last edit - 04.11.2023
		eventCounter = eventCounter + 1;
		eventAppender2(eventFormatter(EventObj, EventCont, EventMeth));
	}

	public static void add(Object EventObj, String EventCont, String EventMeth) {
		// origin - 26.09.2023, last edit - 27.10.2023
		eventCounter = eventCounter + 1;
		eventAppender(eventFormatter(EventObj, EventCont, EventMeth));
		try {
			WB.writeFile(Abc.eventLogPath, eventLog.toString());
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		} finally {
		}
	}

	public static void add(String str) {
		// origin - 03.11.2023, last edit - 03.11.2023
		eventCounter = eventCounter + 1;
		eventAppender(str + System.lineSeparator());
		try {
			WB.writeFile(Abc.eventLogPath, eventLog.toString());
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		} finally {
		}
	}

	public static String eventFormatter(Object EventObj, String EventCont, String EventMeth) {
		// origin - 21.10.2023, last edit - 15.11.2023
		return "#" + eventCounter + "; " + Etc.getOffsetDateTimeNow() + "; " + EventObj + "; " + EventCont + "; "
				+ EventMeth + ";" + System.lineSeparator();
	}

	public static void eventAppender2(String currEventAdd) {
		// origin - 03.11.2023, last edit - 03.11.2023
		eventLog2.append(currEventAdd.toString());
	}

	public static void eventAppender(String currEventAdd) {
		// origin - 21.10.2023, last edit - 21.10.2023
		eventLog.append(currEventAdd.toString());
	}

	public static void eventAppender(String currEventAdd, StringBuilder eventLogSpecial) {// TODO
		// origin - 23.10.2023, last edit - 23.10.2023
		eventLogSpecial.append(currEventAdd.toString());
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 28.10.2023
	}
}
