public class Unit extends Model {
	// origin - 28.09.2023, last edit - 28.10.2023
	public Model role;
	
	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 28.10.2023
	}
}
