public class Price extends Model {
	// origin - 28.09.2023, last edit - 27.11.2023
	public Model role = new Model();
    public Model info = new Model();
    public Unit unit = new Unit();
    
    public static void test() {
		// origin - 28.10.2023, last edit - 27.11.2023
    	Price testPrice = new Price();
    	Logger.add("Price.test, testPrice=" + testPrice, "", "Price");
	}
}
