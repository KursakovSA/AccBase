import java.time.LocalDate;

public class Debt extends Model {
	// origin - 28.09.2023, last edit - 29.10.2023
	public Geo geo;
	public Model role;
	public Model info;
	public static double rateVAT = getRateVAT(LocalDate.now(), WB.currContext);

	public static double getTurn(LocalDate date1, LocalDate date2, String currContext) {
		// origin - 18.10.2023, last edit - 28.10.2023
		// find turn Debt at period from date1 to date2
		// currContext may be equals -- "VAT.Sum", "VAT.Base.Sum", "VAT.Base.MaxLimit",
		// "IncomePersonTax.Dediction".... etc.
		double res = 0.0;
		// TODO - here need do get processRateVAT from WorkDatabase.sqlite3
		res = Calc.roundCustom(res);
		return res;
	}

	public static double getRest(LocalDate date2, String currContext) {
		// origin - 18.10.2023, last edit - 28.10.2023
		// find rest Debt on currDate
		// currContext may be equals -- "VAT.Sum", "VAT.Base.Sum", "VAT.Base.MaxLimit",
		// "IncomePersonTax.Dediction".... etc.
		double res = 0.0;
		// TODO - here need do get processRateVAT from WorkDatabase.sqlite3
		res = Calc.roundCustom(res);
		return res;
	}

	public static double getSegment(LocalDate currDate, String currContext) {
		// origin - 18.10.2023, last edit - 28.10.2023
		// currContext may be equals -- "VAT.Rate", "VAT.Base.MinLimit",
		// "VAT.Base.MaxLimit", "IncomePersonTax.Dediction".... etc.
		double res = 0.0;
		// TODO - here need do get processRateVAT from DatabaseGlobal.sqlite3
		res = Calc.setZeroOnNeg(Calc.roundCustom(res));
		return res;
	}

	public static double getSumTax(double sumBaseTax, double rateTax, int numberFractionalDigit) {
		// origin - 10.10.2023, last edit - 28.10.2023
		double res = 0.0;
		// sumBaseTax = roundCustom(sumBaseTax,numberFractionalDigit);
		res = sumBaseTax * (Calc.ratio100(rateTax)); // only net sum Tax, less baseTax
		res = Calc.setZeroOnNeg(Calc.roundCustom(res, numberFractionalDigit));
		return res;
	}

	public static double getRateVAT(LocalDate currDate, Workbook currContext) {
		// origin - 09.10.2023, last edit - 28.10.2023
		double res = 0.0;
		getSegment(currDate, "Debt.VAT.Sell.RateBasic");
		res = res == 0.0 ? 12.0 : res; // default stub = 12.0 when no rate vat from DatabaseGlobal.sqlite3
		res = Calc.setZeroOnNeg(Calc.roundCustom(res));
		return res;
	}

	public static double subtractInVAT(double sumWithVAT, double rateVAT) {
		// origin - 08.10.2023, last edit - 29.10.2023
		double res = 0.0;
		sumWithVAT = Calc.roundCustom(sumWithVAT);
		res = sumWithVAT - getInVAT(sumWithVAT, rateVAT);
		res = Calc.roundCustom(res);
		return res;
	}

	public static double addOutVAT(double sumLessVAT, double rateVAT) {
		// origin - 02.10.2023, last edit - 28.10.2023
		double res = 0.0;
		sumLessVAT = Calc.roundCustom(sumLessVAT); // with cents
		res = sumLessVAT + getOutVAT(sumLessVAT, rateVAT);
		res = Calc.roundCustom(res);
		return res;
	}

	public static double getOutVAT(double sumLessVAT, double rateVAT) {
		// origin - 08.10.2023, last edit - 28.10.2023
		double res = 0.0;
		sumLessVAT = Calc.roundCustom(sumLessVAT); // with cents
		res = getSumTax(sumLessVAT, rateVAT, Calc.round2); // with cents
		res = Calc.roundCustom(res); // with cents
		return res;
	}

	public static double getInVAT(double sumWithVAT, double rateVAT) {
		// origin - 02.10.2023, last edit - 28.10.2023
		double res = 0.0;
		sumWithVAT = Calc.roundCustom(sumWithVAT); // with cents
		res = (sumWithVAT * rateVAT) / (100.0 + rateVAT);
		res = Calc.roundCustom(res); // with cents
		return res;
	}

	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 28.10.2023

		// getSumTax
		for (double testArg11 : new double[] { 100.0, 567.43, 0.00, 323.56452 }) {
			Logger.add(
					"res=" + getSumTax(testArg11, rateVAT, Calc.round2) + ", baseTax=" + testArg11 + ", RateTax=" + rateVAT,
					"getSumTax()", "Debt.test()");
			// check
			Logger.add(
					"check, res=" + getOutVAT(testArg11, rateVAT) + ", baseTax=" + testArg11 + ", RateTax=" + rateVAT,
					"getOutVAT()", "Debt.test()");
		}

		// getRateVAT
		Logger.add("res=" + getRateVAT(LocalDate.now(), WB.currContext), "getRateVAT()", "Debt.test()");

		// subtractInVAT
		for (double testArg11 : new double[] { 112.0, 567.68, 0.00, 342.8456 }) {
			Logger.add(
					"res=" + subtractInVAT(testArg11, rateVAT) + ", sumWithVAT=" + testArg11 + ", rateVAT=" + rateVAT,
					"subtractInVAT()", "Debt.test()");
			// reverse check
			Logger.add("reverse check, res=" + addOutVAT(subtractInVAT(testArg11, rateVAT), rateVAT) + ", sumLessVAT="
					+ subtractInVAT(testArg11, rateVAT) + ", rateVAT=" + rateVAT, "addOutVAT()", "Debt.test()");
		}

		// addOutVAT
		for (double testArg1 : new double[] { 100.0, 567.43, 0.00, 323.56452 }) {
			Logger.add("res=" + addOutVAT(testArg1, rateVAT) + ", sumLessVAT=" + testArg1 + ", rateVAT=" + rateVAT,
					"addOutVAT()", "Debt.test()");
		}

		// getOutVAT
		for (double testArg1 : new double[] { 100.0, 567.43, 0.00, 323.56452 }) {
			Logger.add("res=" + getOutVAT(testArg1, rateVAT) + ", sumLessVAT=" + testArg1 + ", rateVAT=" + rateVAT,
					"getOutVAT()", "Debt.test()");
		}

		// getInVAT
		for (double testArg1 : new double[] { 112.0, 567.68, 0.00, 342.8456 }) {
			Logger.add("res=" + getInVAT(testArg1, rateVAT) + ", sumWithVAT=" + testArg1 + ", rateVAT=" + rateVAT,
					"getInVAT()", "Debt.test()");
		}
	}
}
