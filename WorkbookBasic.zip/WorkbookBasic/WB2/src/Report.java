public class Report extends ModelDto {
	// origin - 16.10.2023, last edit - 28.10.2023
	//public static TreeSet<String> dbReport = new TreeSet<String>(
		//		Arrays.asList("Analysis", "Balance", "BalanceTurnover", "Depreciation", "Detail", "", "", "", "", "", "", "", "", "", "", "", ""));
	public Asset asset;
	public Deal deal;
	public Model item;
	public Debt debt;
	
	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 28.10.2023
	}
}
