import java.util.*;

public class Report {
	// origin - 16.10.2023, last edit - 28.11.2023
	//public static TreeSet<String> dbReport = new TreeSet<String>(
		//		Arrays.asList("Analysis", "Balance", "BalanceTurnover", "Depreciation", "Detail", "", "", "", "", "", "", "", "", "", "", "", ""));
	public TreeSet<Asset> asset = new TreeSet<Asset>();
	public TreeSet<Deal> deal = new TreeSet<Deal>();
	public TreeSet<Model> item = new TreeSet<Model>();
	public TreeSet<Debt> debt = new TreeSet<Debt>();
	
	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 28.11.2023
		Report testReport = new Report();
    	Logger.add("Report.test, testReport=" + testReport, "", "Report");
	}
}
