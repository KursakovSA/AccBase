import java.util.*;

public class Report {
	// origin - 16.10.2023, last edit - 02.11.2023
	//public static TreeSet<String> dbReport = new TreeSet<String>(
		//		Arrays.asList("Analysis", "Balance", "BalanceTurnover", "Depreciation", "Detail", "", "", "", "", "", "", "", "", "", "", "", ""));
	public TreeSet<Asset> asset;
	public TreeSet<Deal> deal;
	public TreeSet<Model> item;
	public TreeSet<Debt> debt;
	
	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 28.10.2023
	}
}
