import java.io.File;

public class Transfer {
	// origin - 30.09.2023, last edit - 29.10.2023
	public static String transferPath;
	public static String transferFile;
	
	public static StringBuilder addHeader(StringBuilder txtSwift) {
		// origin - 19.10.2023, last edit - 19.10.2023
		StringBuilder addTxtSwift = new StringBuilder(txtSwift); 
		//TODO
		return addTxtSwift;
	}
	
	public static StringBuilder addDetail(StringBuilder txtSwift) {
		// origin - 19.10.2023, last edit - 19.10.2023
		StringBuilder addTxtSwift = new StringBuilder(txtSwift); 
		//TODO
		return addTxtSwift;
	}
	
	public static StringBuilder addFooter(StringBuilder txtSwift) {
		// origin - 19.10.2023, last edit - 19.10.2023
		StringBuilder addTxtSwift = new StringBuilder(txtSwift); 
		//TODO
		return addTxtSwift;
	}

	public static StringBuilder getSwiftOPV(Workbook WorkbookSalary) {
		// origin - 30.09.2023, last edit - 29.10.2023
		transferFile = "swift_OPV.txt";
		transferPath = Abc.swiftDir+File.separator+transferFile;
		StringBuilder txtSwift = new StringBuilder("");
		addHeader(txtSwift);
		addDetail(txtSwift);
		addFooter(txtSwift);

		Logger.add(txtSwift.length(), "txtSwift.length()", "TransferData.SwiftOPV()");
		return txtSwift;
	}
	
	public static void getTransfer() throws Exception {
		// origin - 19.10.2023, last edit - 29.10.2023
		StringBuilder textSwift = getSwiftOPV(null); //TODO
		WB.writeFile(transferFile, textSwift.toString()); //TODO
		WB.openFile(transferFile);
	}
	
	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 28.10.2023
	}
}
