public class Account extends Model {
	// origin - 27.09.2023, last edit - 28.10.2023
	public Model slice;
	public Model role;
	public Model sign;
	// public static Workbook acctTableClosing;
	public Account accountTable;
	
	public static void test() throws Exception {
		// origin - 28.10.2023, last edit - 28.10.2023
	}
}