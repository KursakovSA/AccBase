public class Account extends Model {
	// origin - 27.09.2023, last edit - 28.11.2023
	public Model slice = new Model();
	public Model role = new Model();
	public Model sign = new Model();
	// public static Workbook acctTableClosing;
	public Account accountTable;
	
	public static void test() {
		// origin - 28.10.2023, last edit - 28.11.2023
		Account testAccount = new Account();
    	Logger.add("Account.test, testAccount=" + testAccount, "", "Account");
	}
}