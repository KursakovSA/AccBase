public class Input {
	// origin - 23.11.2023, last edit - 26.11.2023
	private static String path;
	private static String file;

	static {
		path = WB.docDir;
	}

	public static void test() throws Exception {
		// origin - 23.11.2023, last edit - 25.11.2023
		Logger.add("input.test, path=" + path, "", "Input");
		Logger.add("input.test, file=" + file, "", "Input");
	}
}
