public class Input {
	// origin - 23.11.2023, last edit - 28.11.2023
	private static String path = new String();
	private static String file = new String();

	static {
		path = WB.docDir;
		file="";
	}

	public static void test() throws Exception {
		// origin - 23.11.2023, last edit - 28.11.2023
		Logger.add("input.test, path=" + path + ", file=" + file, "", "Input");
	}
}
