public class Qry {
	// origin - 09.11.2023, last edit - 26.11.2023
	public static final String getTableListSQLite;
	public static int maxNumberItemParameter; // ???
	public static final String templateMoreAbcBasic;
	public String table;
	public String templateMore;
	public String[] field; // TODO ??? need
	public String[] where; // TODO ??? need
	public String[] having; // TODO ??? need 
	public String[] groupBy; // TODO ??? need 
	public static final String workbookTableName;

	static {
		// origin - 09.11.2023, last edit - 23.11.2023
		getTableListSQLite = "SELECT name FROM sqlite_master WHERE type = 'table'";
		maxNumberItemParameter = 26; // this is counter field in ModelDto - id, parent ... debt, price
		templateMoreAbcBasic = "More LIKE '%AbcBasic%'";
		workbookTableName = "Workbook";
	}

	{
		// origin - 14.11.2023, last edit - 16.11.2023
		this.table = workbookTableName; //usually this table need
		this.templateMore = "";
		this.field = new String[maxNumberItemParameter]; // ??? need
		this.where = new String[maxNumberItemParameter]; // ??? need
		this.having = new String[maxNumberItemParameter]; // ??? need
		this.groupBy = new String[maxNumberItemParameter]; // ??? need
	}

	public String getText(String currConn) {
		// origin - 25.10.2023, last edit - 23.11.2023
		String res = "";

		res = appender(res, "SELECT * FROM");
		res = appender(res, this.table);
		if (this.templateMore.isEmpty() != true) {
			res = appender(res, "WHERE");
			res = appender(res, this.templateMore);
		}
		return res;
	}

	public Qry(String Table, String TemplateMore) {
		// origin - 14.11.2023, last edit - 14.11.2023
		this.table = Table;
		this.templateMore = TemplateMore;
	}

	public Qry(String Table) {
		// origin - 14.11.2023, last edit - 14.11.2023
		this.table = Table;
	}
	
	public Qry() {
		// origin - 14.11.2023, last edit - 16.11.2023
		this.table = workbookTableName; //usually this table need
	}
	
	private static String appender(String qry, String add) {
		// origin - 15.11.2023, last edit - 25.11.2023
		String res = qry;  //less fixTrim !!!
		res = res + Etc.fixString(add) + " ";  //with right space !!!
		return res;
	}

	public static void test() throws Exception {
		// origin - 12.10.2023, last edit - 22.11.2023
	}
}
