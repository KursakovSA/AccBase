public class Qry {
	// origin - 09.11.2023, last edit - 28.11.2023
	public static String getTableListSQLite = new String();
	public static String templateMoreAbcBasic = new String();
	public String table = new String();
	public String templateMore = new String();
	public static String workbookTableName = new String();

	static {
		// origin - 09.11.2023, last edit - 23.11.2023
		getTableListSQLite = "SELECT name FROM sqlite_master WHERE type = 'table'";
		templateMoreAbcBasic = "More LIKE '%AbcBasic%'";
		workbookTableName = "Workbook";
	}

	{
		// origin - 14.11.2023, last edit - 27.11.2023
		this.table = workbookTableName; //usually this table need
		this.templateMore = "";
	}

	public String getText(String currConn) {
		// origin - 25.10.2023, last edit - 23.11.2023
		String res = "";

		res = appender(res, "SELECT * FROM");
		res = appender(res, this.table);
		if (this.templateMore.isEmpty() != true) {
			res = appender(res, "WHERE");
			res = appender(res, this.templateMore);
		}
		return res;
	}

	public Qry(String Table, String TemplateMore) {
		// origin - 14.11.2023, last edit - 14.11.2023
		this.table = Table;
		this.templateMore = TemplateMore;
	}

	public Qry(String Table) {
		// origin - 14.11.2023, last edit - 14.11.2023
		this.table = Table;
	}
	
	public Qry() {
		// origin - 14.11.2023, last edit - 16.11.2023
		this.table = workbookTableName; //usually this table need
	}
	
	private static String appender(String qry, String add) {
		// origin - 15.11.2023, last edit - 25.11.2023
		String res = qry;  //less fixTrim !!!
		res = res + Etc.fixString(add) + " ";  //with right space !!!
		return res;
	}

	public static void test() throws Exception {
		// origin - 12.10.2023, last edit - 28.11.2023
	}
}
