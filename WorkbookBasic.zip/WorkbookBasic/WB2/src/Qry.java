public class Qry {
	// origin - 09.11.2023, last edit - 16.11.2023
	public static String getTableListSQLite;
	public static int maxNumberItemParameter; // ???
	public static String templateMoreAbcBasic;
	public String table;
	public String templateMore;
	public String[] field; // TO DO ??? need
	public String[] where; // TO DO ??? need
	public String[] having; // TO DO ??? need 
	public String[] groupBy; // TO DO ??? need 
	public static String postfixView;
	public static String WorkbookTableName;

	static {
		// origin - 09.11.2023, last edit - 16.11.2023
		getTableListSQLite = "SELECT name FROM sqlite_master WHERE type = 'table'";
		maxNumberItemParameter = 26; // this is counter field in ModelDto - id, parent ... debt, price
		templateMoreAbcBasic = "More LIKE '%AbcBasic%'";
		postfixView = "List";
		WorkbookTableName = "Workbook";
	}

	{
		// origin - 14.11.2023, last edit - 16.11.2023
		this.table = WorkbookTableName; //usually this table need
		this.templateMore = "";
		this.field = new String[maxNumberItemParameter]; // ??? need
		this.where = new String[maxNumberItemParameter]; // ??? need
		this.having = new String[maxNumberItemParameter]; // ??? need
		this.groupBy = new String[maxNumberItemParameter]; // ??? need
	}

	public String getText() {
		// origin - 25.10.2023, last edit - 15.11.2023
		String res = "";
		this.table = getViewName(this.table, postfixView);
		res = appender(res, "SELECT * FROM");
		res = appender(res, this.table);
		if (this.templateMore.isEmpty() != true) {
			res = appender(res, "WHERE");
			res = appender(res, this.templateMore);
		}
		return res;
	}

	public Qry(String Table, String TemplateMore) {
		// origin - 14.11.2023, last edit - 14.11.2023
		this.table = Table;
		this.templateMore = TemplateMore;
	}

	public Qry(String Table) {
		// origin - 14.11.2023, last edit - 14.11.2023
		this.table = Table;
	}
	
	public Qry() {
		// origin - 14.11.2023, last edit - 16.11.2023
		this.table = WorkbookTableName; //usually this table need
	}
	
	public static String appender(String qry, String add) {
		// origin - 15.11.2023, last edit - 15.11.2023
		String res = qry;  //less fixTrim !!!
		res = res + Etc.fixString(add) + " ";  //with right space !!!
		return res;
	}
	
	public static String getViewName(String tableName, String addWord) {
		// origin - 29.10.2023, last edit - 15.11.2023
		// if tableName = "Account", then viewName = "AccountList", etc.
		String res = "";
		res = Etc.delWord(tableName, addWord); // delete word "list" if it exist then 2 time word "list" not add
		res = res + addWord;
		return res;
	}

	public static String getTableName(String tableName) {
		// origin - 31.10.2023, last edit - 16.11.2023
		String res = "";
		res = Etc.delWord(tableName, postfixView); // delete word "list" if it exist then 2 time word "list" not add
		return res;
	}

	public static void test() throws Exception {
		// origin - 12.10.2023, last edit - 16.11.2023

		// getTableName
		for (var testArg1 : new String[] { "Account", "AssetList  ", " Deal", "Debt", "ListPriListceList" }) {
			Logger.add2("res=" + getTableName(testArg1) + ", str1=" + testArg1, "getTableName()", "Qry.test()");
		}

		// getViewName
		for (var testArg1 : new String[] { "Account", "AssetList  ", " Deal", "Debt", "ListPriListceList" }) {
			Logger.add2("res=" + getViewName(testArg1, postfixView) + ", str1=" + testArg1, "getViewName()", "Qry.test()");
		}
	}
}
