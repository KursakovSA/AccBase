public class ModelDto {
	// origin - 30.09.2023, last edit - 28.11.2023
	// common field
	public String table = new String();
	public String id = new String();
	public String parent = new String();
	public String face1 = new String();
	public String face2 = new String();
	public String face = new String();
	public String slice = new String();
	public String date1 = new String();
	public String date2 = new String();
	public String code = new String();
	public String description = new String();
	public String sign = new String();
	public String account = new String();
	public String geo = new String();
	public String role = new String();
	public String info = new String();
	public String meter = new String();
	public String meterValue = new String();
	public String unit = new String();
	public String more = new String();
	public String mark = new String();

	// special field
	public String process;
	public String asset;
	public String deal;
	public String item;
	public String debt;
	public String price;

	{
		// origin - 08.11.2023, last edit - 25.11.2023
		this.table = "";
		this.id = "";
		this.parent = "";
		this.code = "";
		this.description = "";
		this.more = "";
	}

	public ModelDto(String Table, String Id, String Parent, String Face1, String Face2, String Face,
			String Slice, String Date1, String Date2, String Code, String Description, String Sign, String Account,
			String Geo, String Role, String Info, String Meter, String MeterValue, String Unit, String More,
			String Mark, String Process, String Asset, String Deal, String Item, String Debt, String Price) {
		// origin - 02.11.2023, last edit - 25.11.2023
		this.table = Table;
		this.id = Id;
		this.parent = Parent;
		this.face1 = Face1;
		this.face2 = Face2;
		this.face = Face;
		this.slice = Slice;
		this.date1 = Date1;
		this.date2 = Date2;
		this.code = Code;
		this.description = Description;
		this.sign = Sign;
		this.account = Account;
		this.geo = Geo;
		this.role = Role;
		this.info = Info;
		this.meter = Meter;
		this.meterValue = MeterValue;
		this.unit = Unit;
		this.more = More;
		this.mark = Mark;
		this.process = Process;
		this.asset = Asset;
		this.deal = Deal;
		this.item = Item;
		this.debt = Debt;
		this.price = Price;
	}

	public ModelDto() {
		// origin - 02.11.2023, last edit - 22.11.2023
		this.id = "";
	}

	public static void test() throws Exception {
		// origin - 12.10.2023, last edit - 28.11.2023
		ModelDto testModelDto = new ModelDto();
    	Logger.add("ModelDto.test, testModelDto=" + testModelDto, "", "modelDto");
	}

	public String toString() {
		// origin - 30.09.2023, last edit - 22.11.2023
		return this.getClass().getName() + "{" + "table='" + table + "', id='" + id + '\'' + ", code=" + code + '}';
	}
}
