public class ModelDto {
	// origin - 30.09.2023, last edit - 25.11.2023
	// common field
	public String table;
	public String id;
	public String parent;
	public String face1;
	public String face2;
	public String face;
	public String slice;
	public String date1;
	public String date2;
	public String code;
	public String description;
	public String sign;
	public String account;
	public String geo;
	public String role;
	public String info;
	public String meter;
	public String meterValue;
	public String unit;
	public String more;
	public String mark;

	// special field
	public String process;
	public String asset;
	public String deal;
	public String item;
	public String debt;
	public String price;

	{
		// origin - 08.11.2023, last edit - 25.11.2023
		this.table = "";
		this.id = "";
		this.parent = "";
		this.code = "";
		this.description = "";
		this.more = "";
	}

	public ModelDto(String Table, String Id, String Parent, String Face1, String Face2, String Face,
			String Slice, String Date1, String Date2, String Code, String Description, String Sign, String Account,
			String Geo, String Role, String Info, String Meter, String MeterValue, String Unit, String More,
			String Mark, String Process, String Asset, String Deal, String Item, String Debt, String Price) {
		// origin - 02.11.2023, last edit - 25.11.2023
		this.table = Table;
		this.id = Id;
		this.parent = Parent;
		this.face1 = Face1;
		this.face2 = Face2;
		this.face = Face;
		this.slice = Slice;
		this.date1 = Date1;
		this.date2 = Date2;
		this.code = Code;
		this.description = Description;
		this.sign = Sign;
		this.account = Account;
		this.geo = Geo;
		this.role = Role;
		this.info = Info;
		this.meter = Meter;
		this.meterValue = MeterValue;
		this.unit = Unit;
		this.more = More;
		this.mark = Mark;
		this.process = Process;
		this.asset = Asset;
		this.deal = Deal;
		this.item = Item;
		this.debt = Debt;
		this.price = Price;
	}

	public ModelDto() {
		// origin - 02.11.2023, last edit - 22.11.2023
		this.id = "";
	}

	public static void test() throws Exception {
		// origin - 12.10.2023, last edit - 12.11.2023
	}

	public String toString() {
		// origin - 30.09.2023, last edit - 22.11.2023
		return this.getClass().getName() + "{" + "table='" + table + "', id='" + id + '\'' + ", code=" + code + '}';
	}
}
