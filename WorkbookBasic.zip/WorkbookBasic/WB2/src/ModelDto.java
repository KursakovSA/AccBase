public class ModelDto {
	// origin - 30.09.2023, last edit - 28.10.2023
	public String id;
	public String parent;
	public String face1;
    public String face2;
    public String face;
    public String slice;
	public String date1;
	public String date2;
	public String code;
	public String description;
	public String sign;
	public String account;
	public String geo;
	public String role;
    public String info;
    public String meter;
    public String meterValue;
    public String unit;
	public String more;
	public String mark;

	public String toString() {
		// origin - 30.09.2023, last edit - 14.09.2023
		return this.getClass().getName() + "{" + "id='" + id + '\'' + ", code=" + code + ", description=" + description
				+ '}';
	}
}
