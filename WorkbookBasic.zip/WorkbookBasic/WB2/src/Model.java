import java.time.OffsetDateTime;

public class Model {
	// origin - 26.09.2023, last edit - 27.11.2023
	public String id = new String();
	public Model parent;// = new Model();
	public OffsetDateTime date1;
	public String date2 = new String();
	public String code = new String();
	public String description = new String();
	public String more = new String();
	public String fullDescription =  new String();
	public String fullName =  new String();
	public String shortDescription =  new String();
	public String shortName = new String();
	
	{
		// origin - 09.11.2023, last edit - 24.11.2023
		this.id = "";
		this.code = "";
		this.description = "";
		this.more = "";
	}
	
	public Model(String Id, OffsetDateTime Date1, String Date2, String Code, String Description, 
			String More) {
		// origin - 08.11.2023, last edit - 24.11.2023
		this.id = Id;
		this.date1 = Date1;
		this.date2 = Date2;
		this.code = Code;
		this.description = Description;
	}
	
	public Model() {
		// origin - 08.11.2023, last edit - 09.11.2023
	}

	public String toString() {
		// origin - 27.09.2023, last edit - 02.11.2023
		return this.getClass().getName() + "{" + "id='" + id + '\'' + ", code=" + code + ", description=" + description
				+ ", more=" + more + '}';
	}
	
	public static void test() {
		// origin - 27.11.2023, last edit - 27.11.2023
    	Model testModel = new Model();
    	Logger.add("Model.test, testModel=" + testModel, "", "Model");
	}
}
