import java.time.OffsetDateTime;
import java.util.TreeSet;

public class Model {
	// origin - 26.09.2023, last edit - 06.12.2023
	public static TreeSet<String> standard;
	public static TreeSet<String> custom;
	public String id;
	public OffsetDateTime date1;
	public String date2;
	public String code;
	public String description;
	public String more;
	public String fullDescription;
	public String fullName;
	public String shortDescription;
	public String shortName;
	
	public Model() {
		// origin - 08.11.2023, last edit - 05.12.2023
	}

	public String toString() {
		// origin - 27.09.2023, last edit - 02.12.2023
		String res = "";
		res = ModelDto.appender(res, ModelDto.formatter("id", this.id));
		res = ModelDto.appender(res, ModelDto.formatter("code", this.code));
		res = ModelDto.appender(res, ModelDto.formatter("date2", this.date2));
		res = ModelDto.appender(res, ModelDto.formatter("description", this.description));
		res = ModelDto.appender(res, ModelDto.formatter("more", this.more));
		res = "{" + res + "}";
		return res;
	}
	
	public static void test() {
		// origin - 27.11.2023, last edit - 05.12.2023
	}
}
