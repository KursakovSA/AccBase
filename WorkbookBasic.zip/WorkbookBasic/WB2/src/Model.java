import java.time.LocalDateTime;

public class Model {
	// origin - 26.09.2023, last edit - 28.10.2023
	public String id;
	public Model parent;
	public LocalDateTime date1;
	public String date2;
	public String code;
	public String description;
	public String more;
	public String fullDescription;
	public String fullName;
	public String shortDescription;
	public String shortName;
	public String basic;
	public ModelDto dto;
	public static Model root;

	public String toString() {
		// origin - 27.09.2023, last edit - 14.10.2023
		return this.getClass().getName() + "{" + "id='" + id + '\'' + ", code=" + code + ", description=" + description
				+ '}';
	}
}
