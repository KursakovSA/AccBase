import java.awt.Desktop;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class WB extends JFrame {
	// origin - 25.09.2023, last edit - 12.11.2023
	private static final long serialVersionUID = 1L;
	public static Workbook currContext = new Workbook();

	public static void main(String[] args) throws Exception {
		// origin - 25.09.2023, last edit - 06.11.2023
		try {
			Logger.getGlobalStart();
			onStartApp();	
		} catch (Exception ex) {
			Logger.add("ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "main()");
		} finally {
			Logger.eventTrace();
		}
	}

	public static void onStartApp() throws Exception {
		// origin - 25.09.2023, last edit - 23.10.2023
		test();
		//getGui();
	}

	public static void getGui() throws Exception {
		// origin - 06.10.2023, last edit - 15.10.2023
		JFrame window = new JFrame("Workbook Basic, ");
		JPanel panel = new JPanel();
		// JButton button = new JButton("Click me!");
		// panel.add(button);
		window.add(panel);
		window.setSize(800, 400);
		// button.addActionListener(e -> System.out.println("Ouch! You clicked me!"));
		window.setVisible(true);
	}

	public static void testExistDir(String dirPath) throws Exception {
		// origin - 21.10.2023, last edit - 03.11.2023
		if (DAL.dbSystemFactList.size() != 0) {// only if exist fact system db
			if (Files.exists(Paths.get(dirPath)) == false) {
				Files.createDirectory(Paths.get(dirPath));
				Logger.add("createDir=" + dirPath, "WB.checkExistDir()", "main()");
			} else {
			    Logger.add2("existDir=" + dirPath, "WB.checkExistDir()", "main()");
			}
		}
	}

	public static void test() throws Exception {
		// origin - 25.09.2023, last edit - 12.11.2023
		DAL.test();
		Qry.test();
		Conn.test();
		
		Etc.test();
//		Account.test();
//		Asset.test();
//		Calc.test();
//		Deal.test();
//		Debt.test();
//		Face.test();
//		Geo.test();
//		Meter.test();
//		Price.test();
//		Process.test();
//		Report.test();
//		TransferData.test();
//		Unit.test();
//		Workbook.test();
		
		ModelDto.test();
		Report.test();
		Transfer.test();

		// testExistDir
		for (String testDir : new String[] { Abc.mediaDir, Abc.docDir, Abc.templateDocDir }) {
			testExistDir(testDir);
		}
	}
	
	public static void writeFile(String pathFile, String file) throws Exception {
		// origin - 19.10.2023, last edit - 01.11.2023
		Files.write(Paths.get(pathFile), file.toString().getBytes("utf-8"));
	}

	public static void openFile(String pathFile) throws Exception {
		// origin - 19.10.2023, last edit - 23.10.2023
		Desktop.getDesktop().open(new File(pathFile));
	}
}
