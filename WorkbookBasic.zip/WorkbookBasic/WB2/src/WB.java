import java.awt.Color;
import java.awt.Desktop;
import java.awt.GridLayout;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

public class WB extends JFrame {
	// origin - 25.09.2023, last edit - 28.11.2023
	private static final long serialVersionUID = 1L;
	public static String startDir = new String();
	public static String lastSaveDir = new String();
	public static String lastSelectFileDir = new String();
	public static String mediaDir = new String();
	public static String docDir = new String();
	public static String templateDocDir = new String();
	public static String lastConn = new String();
	public static Abc abcGlobal = new Abc();
	public static Abc abcLast = new Abc();
	public static final LocalDate minDateSupported;
	public static final LocalDate maxDateSupported;

	static {
		startDir = System.getProperty("user.dir");
		lastSaveDir = startDir;
		lastSelectFileDir = startDir;
		mediaDir = startDir + File.separator + "media";
		docDir = startDir + File.separator + "doc";
		templateDocDir = startDir + File.separator + "templateDoc";
		minDateSupported = LocalDate.of(2020, 01, 01);
		maxDateSupported = LocalDate.of(2060, 12, 31);
		Abc abcGlobal = Abc.getAbc(Conn.globalPath);
		Logger.add("WB.static init, abcGlobal=" + abcGlobal, "", "WB");
	}

	public static void main(String[] args) throws Exception {
		// origin - 25.09.2023, last edit - 28.11.2023
		try {
			Logger.getGlobalStart();
			onStartApp();
		} catch (Exception ex) {
			Logger.add("WB.main, ex=" + ex.getMessage(), ", StackTrace=" + ex.getStackTrace(), "WB.main");
		} finally {
			Logger.eventTrace();
		}
	}

	private static void onStartApp() throws Exception {
		// origin - 25.09.2023, last edit - 28.11.2023
		try {
			Conn.init();
			init();
			test();	
			getGui();
		} catch (Exception ex) {
			Logger.add("WB.onStartApp, ex=" + ex.getMessage(), ", StackTrace=" + ex.getStackTrace(), "WB.main");
		} finally {
		}
	}

	private static void getGui() {
		// origin - 06.10.2023, last edit - 29.11.2023
//		JFrame window = new JFrame("Workbook Basic, ");
//		JPanel panel = new JPanel();
//		
//		GridLayout layout = new GridLayout(1,4);
//	      layout.setHgap(40);
//	      panel.setLayout(layout);
//	      panel.add(new JButton("Overview"));
//	      panel.add(new JButton("Samples"));
//	      panel.add(new JButton("Tutorials"));
//	      panel.add(new JButton("Support"));
//		
//		// JButton button = new JButton("Click me!");
//		// panel.add(button);
//		window.add(panel);
//		window.setSize(800, 400);
//		// button.addActionListener(e -> System.out.println("Ouch! You clicked me!"));
//		window.setVisible(true);
		
		JFrame frame = new JFrame("Sections");
	      JPanel panel = new JPanel();
	      panel.setBackground(Color.orange);
	      GridLayout layout = new GridLayout(1,4);
	      layout.setHgap(40);
	      panel.setLayout(layout);
	      panel.add(new JButton("Overview"));
	      panel.add(new JButton("Samples"));
	      panel.add(new JButton("Tutorials"));
	      panel.add(new JButton("Support"));
	      frame.add(panel);
	      frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	      frame.setSize(800, 400);
	      frame.setVisible(true);
		
	}

	private static void init() {
		// origin - 21.10.2023, last edit - 28.11.2023
		if (Conn.systemFact.size() != 0) {
			for (String dirPath : new String[] { mediaDir, docDir, templateDocDir }) {
				if (Files.notExists(Paths.get(dirPath))) {
					try {
						Files.createDirectory(Paths.get(dirPath));
					} catch (IOException ex) {
						Logger.add("WB.init, ex=" + ex.getMessage(), ", StackTrace=" + ex.getStackTrace(), "WB");
					}
					Logger.add("WB.init, createDir=" + dirPath, "main", "WB.init");
				}
			}
		}
	}

	public static void test() throws Exception {
		// origin - 25.09.2023, last edit - 27.11.2023
		Abc.test();
		Etc.test();
		Account.test();
		Asset.test();
		Deal.test();
		Debt.test();
		Face.test();
		Geo.test();
		Meter.test();
		Price.test();
		Process.test();
		Report.test();
		Unit.test();
		Workbook.test();
		Model.test();
		ModelDto.test();
		Report.test();
		Output.test();
		Input.test();
		Custom.test();
	}

	public static void writeFile(String pathFile, String file) throws Exception {
		// origin - 19.10.2023, last edit - 27.11.2023
		try {
			Files.write(Paths.get(pathFile), file.toString().getBytes("utf-8"));
		} catch (Exception ex) {
			Logger.add("WB.writeFile, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "WB.main");
		} finally {
		}
	}

	public static void openFile(String pathFile) throws Exception {
		// origin - 19.10.2023, last edit - 27.11.2023
		try {
			Desktop.getDesktop().open(new File(pathFile));
		} catch (Exception ex) {
			Logger.add("WB.openFile, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "WB.main");
		} finally {
		}
	}
}
