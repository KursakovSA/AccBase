import java.awt.Desktop;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class WB extends JFrame {
	// origin - 25.09.2023, last edit - 26.11.2023
	private static final long serialVersionUID = 1L;
	public static final String startDir;
	public static String lastSaveDir;
	public static String lastSelectFileDir;
	public static String mediaDir;
	public static String docDir;
	public static String templateDocDir;
	public static String lastConn;
	public static final Abc abcGlobal = null;
	public static Abc abcLastConn = null;
	public static final LocalDate minDateSupported;
	public static final LocalDate maxDateSupported;

	static {
		startDir = System.getProperty("user.dir");
		lastSaveDir = startDir;
		lastSelectFileDir = startDir;
		mediaDir = startDir + File.separator + "media";
		docDir = startDir + File.separator + "doc";
		templateDocDir = startDir + File.separator + "templateDoc";
		minDateSupported = LocalDate.of(2020, 01, 01);
		maxDateSupported = LocalDate.of(2060, 12, 31);
		try {
			Abc abcGlobal = new Abc(Conn.globalPath, Qry.templateMoreAbcBasic);
			Logger.add("WB.static init, abcGlobal=" + abcGlobal, "", "WB");
		} catch (Exception ex) {
			Logger.add("WB.static init, abcGlobal, ex=" + ex.getMessage(), "StackTrace=" + ex.getStackTrace(), "WB");
		}
	}

	public static void main(String[] args) throws Exception {
		// origin - 25.09.2023, last edit - 23.11.2023
		try {
			Logger.getGlobalStart();
			onStartApp();
		} catch (Exception ex) {
			Logger.add("main, ex=" + ex.getMessage(), ", StackTrace=" + ex.getStackTrace(), "main()");
		} finally {
			Logger.eventTrace();
		}
	}

	public static void onStartApp() throws Exception {
		// origin - 25.09.2023, last edit - 25.11.2023
		try {
			Conn.init();
			test();
			// abcCurrDb = new Abc(Conn.dbWorkList.first());
			// Logger.add("onStartApp, WB.abcCurrDb=" + abcCurrDb, "main", "WB");
			// Conn.currWork = Conn.dbWorkList.first();
			// Logger.add("onStartApp, Conn.currWork=" + Conn.currWork, "main", "WB");	

			// getGui();
		} catch (Exception ex) {
			Logger.add("onStartApp, ex=" + ex.getMessage(), ", StackTrace=" + ex.getStackTrace(), "main()");
		} finally {
		}
	}

	public static void getGui() throws Exception {
		// origin - 06.10.2023, last edit - 15.10.2023
		JFrame window = new JFrame("Workbook Basic, ");
		JPanel panel = new JPanel();
		// JButton button = new JButton("Click me!");
		// panel.add(button);
		window.add(panel);
		window.setSize(800, 400);
		// button.addActionListener(e -> System.out.println("Ouch! You clicked me!"));
		window.setVisible(true);
	}

	public static void testExistDir(String dirPath) throws Exception {
		// origin - 21.10.2023, last edit - 23.11.2023
		if (Conn.systemFact.size() != 0) {
			if (Files.notExists(Paths.get(dirPath))) {
				Files.createDirectory(Paths.get(dirPath));
				Logger.add("testExistDir, createDir=" + dirPath, "main", "WB");
			}
		}
	}

	public static void test() throws Exception {
		// origin - 25.09.2023, last edit - 25.11.2023
		Conn.test();
		Qry.test();
		DAL.test();
		Etc.test();
//		Account.test();
//		Asset.test();
//		Calc.test();
//		Deal.test();
//		Debt.test();
//		Face.test();
//		Geo.test();
//		Meter.test();
//		Price.test();
//		Process.test();
//		Report.test();
//		Unit.test();
//		Workbook.test();
		// ModelDto.test();
		// Report.test();
		// Output.test();
		// Input.test();

		// testExistDir
		for (String testDir : new String[] { mediaDir, docDir, templateDocDir }) {
			testExistDir(testDir);
		}
	}

	public static boolean existFile(String file) {
		// origin - 20.11.2023, last edit - 25.11.2023
		boolean res = true;
		try {
			file = Etc.delStr(file, Conn.prefixJdbcSqlite);
			if (Files.notExists(Paths.get(file))) {
				res = false;
				// Logger.add("not exist=" + file, "existFile()", "WB");
			}
		} catch (Exception ex) {
			Logger.add("existFile, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "main", "WB");
		} finally {
		}
		return res;
	}

	public static void writeFile(String pathFile, String file) throws Exception {
		// origin - 19.10.2023, last edit - 21.11.2023
		try {
			Files.write(Paths.get(pathFile), file.toString().getBytes("utf-8"));
		} catch (Exception ex) {
			Logger.add("writeFile, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "main", "WB");
		} finally {
		}
	}

	public static void openFile(String pathFile) throws Exception {
		// origin - 19.10.2023, last edit - 20.11.2023
		try {
			Desktop.getDesktop().open(new File(pathFile));
		} catch (Exception ex) {
			Logger.add("openFile, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "main", "WB");
		} finally {
		}
	}
}
