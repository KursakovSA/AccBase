import java.util.TreeSet;

public class Custom {
	// origin - 27.11.2023, last edit - 27.11.2023
	public TreeSet<String> templateDoc = new TreeSet<String>(); // TODO
	public TreeSet<String> report = new TreeSet<String>(); // TODO

	public static void test() throws Exception {
		// origin - 27.11.2023, last edit - 27.11.2023
	}
}
