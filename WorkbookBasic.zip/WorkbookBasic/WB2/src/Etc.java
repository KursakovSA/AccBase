import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;

public class Etc {
	// origin - 01.10.2023, last edit - 16.11.2023
	public static int round0;
	public static int round2;
	public static int roundDefault;
	public static int round4;
	
	static
	{
		// origin - 09.11.2023, last edit - 09.11.2023
		round0 = 0;
		round2 = 2;
		roundDefault = round2;
		round4 = 4;
	}
	
	public static String delWord(String viewName, String delWord) {
		// if viewName = "AccountList", then tableName = "Account", etc.
		// origin - 30.10.2023, last edit - 15.11.2023
		String res = "";
		res = Etc.fixTrim(viewName); // delete all space
		res = res.replace(delWord, ""); // delete word if it exist
		return res;
	}
	
	public static int getDuration(OffsetDateTime date1, OffsetDateTime date2) {//less test
		// origin - 21.10.2023, last edit - 09.11.2023
		return Math.abs((int)Etc.roundCustom(Duration.between(date2, date1).toMillis(),round0));
	}
	
	public static OffsetDateTime getOffsetDateTimeNow() {//less test 
		// origin - 21.10.2023, last edit - 09.11.2023
		return OffsetDateTime.now(ZoneOffset.systemDefault().getRules().getOffset(Instant.now()));
	}
	
	public static double ratio100(double ratePercent) {
		// origin - 17.10.2023, last edit - 17.10.2023
		double res = 0.0;
		res = ratePercent / 100.0;
		res = roundCustom(res, round4);
		return res;
	}
	
	public static boolean strEqual(String str1, String str2) {
		// origin - 18.10.2023, last edit - 18.10.2023
		boolean res = false;
		str1 = fixTrim(str1);
		str2 = fixTrim(str2);
		res = str1.equalsIgnoreCase(str2) == true ? true : res;
		return res;
	}

	public static double roundCustom(double sum) {
		// origin - 17.10.2023, last edit - 17.10.2023
		//variant round less number fractional digit as argument, take him = 2 
		double res = sum;
		res = roundCustom(sum, roundDefault); // default round
		return res;
	}

	public static double roundCustom(double sum, int numberFractionalDigit) {
		// origin - 16.10.2023, last edit - 17.10.2023
		double res = sum;
		int power10 = (int) Math.pow(10, numberFractionalDigit);
		res = sum * power10;
		res = Math.round(res);
		res = res / power10;
		return res;
	}

	public static LocalDate fixLocalDate(LocalDate fixDate) {
		// origin - 02.10.2023, last edit - 27.10.2023
		// LocalDate not must be big endDate and least startDate
		LocalDate res = fixDate;
		if (fixDate.isBefore(Abc.minDateSupported)) {
			res = Abc.minDateSupported;
		}
		if (fixDate.isAfter(Abc.maxDateSupported)) {
			res = Abc.maxDateSupported;
		}
		return res;
	}
	
	public static String fixString (Object fixObj) {
		// origin - 12.11.2023, last edit - 12.11.2023
		String res = "";
		try {
			res = fixObj.toString();
		} catch (Exception ex) {
			res = "";
		} finally {
			res=fixTrim(res);
		}
		return res;
	}

	public static String fixTrim(String fixStr) {
		// origin - 02.10.2023, last edit - 12.11.2023
		String res = "";
		try {
			res = fixStr.strip();
		} catch (Exception ex) {
			res = "";
		} finally {
		}
		return res;
	}

	public static double setZeroOnNeg(Number fixNumb) {
		// origin - 01.10.2023, last edit - 21.10.2023
		// for tax calculate and etc where not need be negative number
		double res = (double) fixNumb;
		res = res < 0 ? 0 : res;
		return (double) res;	
	}

	public static void test() {
		// origin - 01.10.2023, last edit - 16.11.2023

		// delWord
		for (var testArg1 : new String[] { "ListAccount", "AssetList  ", " Deal", "Debt", "ListPriListceList" }) {
			Logger.add2("res=" + delWord(testArg1, Qry.postfixView) + ", str1=" + testArg1, "delWord()", "DAL.test()");
		}

		// fixString
		for (var testArg1 : new Object[] { "test1", 12.45, new Asset(), null }) {
			Logger.add2("res=" + fixString(testArg1) + ", fixObj=" + testArg1, "fixString()", "Etc.test()");
		}
		
		// strEqual
		String str2 = "test1";
		for (String testArg1 : new String[] { "test1", "test1 ", " tEst1", "TEST1", "test22" }) {
			Logger.add2("res=" + strEqual(testArg1, str2) + ", str1=" + testArg1 + ", str2=" + str2, "strEqual()",
					"Etc.test()");
		}

		// ratio
		for (double testArg1 : new double[] { 100.0, 67.43, 0.00, 23.56452, 12.0, 234.65432 }) {
			Logger.add2("res=" + ratio100(testArg1) + ", rateTax=" + testArg1, "ratio100()", "Etc.test()");
		}

		// roundCustom - round2
		for (double testArg1 : new double[] { 100.0, 57.4363, 43.0078, 21.212, 34.7845 }) {
			Logger.add2("res=" + roundCustom(testArg1, round2) + ", sumLessRound=" + testArg1
					+ ", numberFractionalDigit=" + round2, "roundCustom()", "Etc.test()");
		}
		// roundCustom - round0
		for (double testArg1 : new double[] { 100.0, 57.4363, 43.0078, 21.212, 34.7845 }) {
			Logger.add2("res=" + roundCustom(testArg1, round0) + ", sumLessRound=" + testArg1
					+ ", numberFractionalDigit=" + round0, "roundCustom()", "Etc.test()");
		}

		// fixLocalDate
		for (LocalDate testArg1 : new LocalDate[] { LocalDate.of(2026, 4, 28), LocalDate.of(1967, 11, 25),
				LocalDate.of(2100, 5, 26) }) {
			Logger.add2("res=" + fixLocalDate(testArg1) + ", fixDate=" + testArg1, "fixLocalDate()", "Etc.test()");
		}

		// fixTrim
		for (String testArg1 : new String[] { "test1", "test2 ", " test3", " test4 " }) {
			Logger.add2("res=" + fixTrim(testArg1) + ", fixStr=" + testArg1, "fixTrim()", "Etc.test()");
		}

		// setZeroOnNeg
		for (double testArg1 : new double[] { 1.25, -41.2556, 0.0, 0.0002, -0.0002, 64.1278 }) {
			Logger.add2("res=" + setZeroOnNeg(testArg1) + ", fixNumb=" + testArg1, "setZeroOnNeg()", "Etc.test()");
		}
	}
}
