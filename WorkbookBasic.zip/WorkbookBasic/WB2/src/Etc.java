import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;

public class Etc {
	// origin - 01.10.2023, last edit - 25.11.2023
	public static final int round0;
	public static final int round2;
	public static final int roundDefault;
	public static final int round4;
	
	static
	{
		// origin - 09.11.2023, last edit - 09.11.2023
		round0 = 0;
		round2 = 2;
		roundDefault = round2;
		round4 = 4;
	}
	
	public static OffsetDateTime getOffsetDateTime(String expectedDate) {
		// origin - 24.11.2023, last edit - 24.11.2023
		OffsetDateTime res;
		expectedDate = fixTrim(expectedDate);
		try {
			res = OffsetDateTime.parse(expectedDate);
		} catch (Exception ex) {
			//res = OffsetDateTime.of(expectedDate, null, null);
			res = null;
			//Logger.add("getOffsetDateTime, ex=" + ex.getMessage(), ", StackTrace=" + ex.getStackTrace(), "Etc");
		} finally {
		}
		return res;
	}
	
	public static LocalDate getLocalDate(String expectedDate) {
		// origin - 24.11.2023, last edit - 24.11.2023
		LocalDate res = null;
		expectedDate = fixTrim(expectedDate);
		try {
			res = LocalDate.parse(expectedDate);
			res = fixLocalDate(res);
		} catch (Exception ex) {
			res = null;
			//Logger.add("getOffsetDateTime, ex=" + ex.getMessage(), ", StackTrace=" + ex.getStackTrace(), "Etc");
		} finally {
			if (res == null) {
				res = LocalDate.now();
			}
		}
		return res;
	}
	
	public static LocalTime getLocalTime(String expectedDate) {
		// origin - 24.11.2023, last edit - 24.11.2023
		LocalTime res;
		expectedDate = fixTrim(expectedDate);
		try {
			res = LocalTime.parse(expectedDate);
		} catch (Exception ex) {
			res = null;
			//Logger.add("getOffsetDateTime, ex=" + ex.getMessage(), ", StackTrace=" + ex.getStackTrace(), "Etc");
		} finally {
		}
		return res;
	}
	
	public static String delStr(String viewName, String delWord) {
		// origin - 30.10.2023, last edit - 24.11.2023
		String res = "";
		res = fixTrim(viewName); // delete all space
		res = res.replace(delWord, ""); // delete word if it exist
		res = fixTrim(res); // delete all space
		return res;
	}
	
	public static int getDuration(OffsetDateTime date1, OffsetDateTime date2) {//less test
		// origin - 21.10.2023, last edit - 09.11.2023
		return Math.abs((int)Etc.roundCustom(Duration.between(date2, date1).toMillis(),round0));
	}
	
	public static OffsetDateTime getOffsetDateTimeNow() { 
		// origin - 21.10.2023, last edit - 24.11.2023
		return OffsetDateTime.now(ZoneOffset.systemDefault().getRules().getOffset(Instant.now()));
	}
	
	public static double ratio100(double ratePercent) {
		// origin - 17.10.2023, last edit - 17.10.2023
		double res = 0.0;
		res = ratePercent / 100.0;
		res = roundCustom(res, round4);
		return res;
	}
	
	public static boolean strEqual(String str1, String str2) {
		// origin - 18.10.2023, last edit - 18.10.2023
		boolean res = false;
		str1 = fixTrim(str1);
		str2 = fixTrim(str2);
		res = str1.equalsIgnoreCase(str2) == true ? true : res;
		return res;
	}

	public static double roundCustom(double sum) {
		// origin - 17.10.2023, last edit - 17.10.2023
		//variant round less number fractional digit as argument, take him = 2 
		double res = sum;
		res = roundCustom(sum, roundDefault); // default round
		return res;
	}

	public static double roundCustom(double sum, int numberFractionalDigit) {
		// origin - 16.10.2023, last edit - 17.10.2023
		double res = sum;
		int power10 = (int) Math.pow(10, numberFractionalDigit);
		res = sum * power10;
		res = Math.round(res);
		res = res / power10;
		return res;
	}

	public static LocalDate fixLocalDate(LocalDate fixDate) {
		// origin - 02.10.2023, last edit - 20.11.2023
		// LocalDate not must be big maxDateSupported and least minDateSupported
		LocalDate res = fixDate;
		if (fixDate.isBefore(WB.minDateSupported)) {
			res = WB.minDateSupported;
		}
		if (fixDate.isAfter(WB.maxDateSupported)) {
			res = WB.maxDateSupported;
		}
		return res;
	}
	
	public static String fixString (Object fixObj) {
		// origin - 12.11.2023, last edit - 12.11.2023
		String res = "";
		try {
			res = fixObj.toString();
		} catch (Exception ex) {
			res = "";
		} finally {
			res=fixTrim(res);
		}
		return res;
	}

	public static String fixTrim(String fixStr) {
		// origin - 02.10.2023, last edit - 12.11.2023
		String res = "";
		try {
			res = fixStr.strip();
		} catch (Exception ex) {
			res = "";
		} finally {
		}
		return res;
	}

	public static double setZeroOnNeg(Number fixNumb) {
		// origin - 01.10.2023, last edit - 21.10.2023
		// for tax calculate and etc where not need be negative number
		double res = (double) fixNumb;
		res = res < 0 ? 0 : res;
		return (double) res;	
	}

	public static void test() {
		// origin - 01.10.2023, last edit - 26.11.2023
		
		// getOffsetDateTime
		for (var testArg1 : new String[] { "2023-11-24T06:46:16.907+06:00", "2023-11-08 02:15:09", "06:46:16.907+06:00", "2019-01-01",
				"test1", "12.45", null }) {
			Logger.add2("Etc.getOffsetDateTime, res=" + getOffsetDateTime(testArg1) + ", testArg1=" + testArg1, "test",
					"Etc");
		}

		// getLocalDate
		for (var testArg1 : new String[] { "2023-11-24T06:46:16.907+06:00", "2023-11-08 02:15:09", "06:46:16.907+06:00", "2019-01-01", "1991-01-01",
				"test1", "12.45", null }) {
			Logger.add2("Etc.getLocalDate, res=" + getLocalDate(testArg1) + ", testArg1=" + testArg1, "test",
					"Etc");
		}
		
		// getLocalTime
		for (var testArg1 : new String[] { "2023-11-24T06:46:16.907+06:00", "2023-11-08 02:15:09", "06:46:16.907+06:00", "06:46:16.907",
				"2019-01-01", "test1", "12.45", null }) {
			Logger.add2("Etc.getLocalTime, res=" + getLocalTime(testArg1) + ", testArg1=" + testArg1, "test", "Etc");
		}

		// fixString
		for (var testArg1 : new Object[] { "test1", 12.45, new Asset(), null }) {
			Logger.add2("Etc.fixString, res=" + fixString(testArg1) + ", testArg1=" + testArg1, "test", "Etc");
		}
		
		// strEqual
		String str2 = "test1";
		for (String testArg1 : new String[] { "test1", "test1 ", " tEst1", "TEST1", "test22" }) {
			Logger.add2("Etc.strEqual, res=" + strEqual(testArg1, str2) + ", testArg1=" + testArg1 + ", str2=" + str2, "test",
					"Etc");
		}

		// ratio100
		for (double testArg1 : new double[] { 100.0, 67.43, 0.00, 23.56452, 12.0, 234.65432 }) {
			Logger.add2("Etc.ratio100, res=" + ratio100(testArg1) + ", testArg1=" + testArg1, "test", "Etc");
		}

		// roundCustom - round2
		for (double testArg1 : new double[] { 100.0, 57.4363, 43.0078, 21.212, 34.7845 }) {
			Logger.add2("Etc.roundCustom, res=" + roundCustom(testArg1, round2) + ", testArg1=" + testArg1
					+ ", numberFractionalDigit=" + round2, "test", "Etc");
		}
		// roundCustom - round0
		for (double testArg1 : new double[] { 100.0, 57.4363, 43.0078, 21.212, 34.7845 }) {
			Logger.add2("Etc.roundCustom, res=" + roundCustom(testArg1, round0) + ", testArg1=" + testArg1
					+ ", numberFractionalDigit=" + round0, "test", "Etc");
		}

		// fixLocalDate
		for (LocalDate testArg1 : new LocalDate[] { LocalDate.of(2026, 4, 28), LocalDate.of(1967, 11, 25),
				LocalDate.of(2100, 5, 26) }) {
			Logger.add2("Etc.fixLocalDate, res=" + fixLocalDate(testArg1) + ", testArg1=" + testArg1, "test", "Etc");
		}

		// fixTrim
		for (String testArg1 : new String[] { "test1", "test2 ", " test3", " test4 " }) {
			Logger.add2("Etc.fixTrim, res=" + fixTrim(testArg1) + ", testArg1=" + testArg1, "test", "Etc");
		}

		// setZeroOnNeg
		for (double testArg1 : new double[] { 1.25, -41.2556, 0.0, 0.0002, -0.0002, 64.1278 }) {
			Logger.add2("Etc.setZeroOnNeg, res=" + setZeroOnNeg(testArg1) + ", testArg1=" + testArg1, "test", "Etc");
		}
	}
}
