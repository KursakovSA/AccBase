import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;

public class Calc {
	// origin - 01.10.2023, last edit - 28.10.2023
	public static int round0 = 0;
	public static int round2 = 2;
	public static int roundDefault = round2;
	public static int round4 = 4;
	
	public static int getDurationInMillis(OffsetDateTime date1, OffsetDateTime date2) {//less test
		// origin - 21.10.2023, last edit - 21.10.2023
		return Math.abs((int)Calc.roundCustom(Duration.between(date2, date1).toMillis(),Calc.round0));
	}
	
	public static OffsetDateTime getOffsetDateTimeNow() {//less test 
		// origin - 21.10.2023, last edit - 21.10.2023
		return OffsetDateTime.now(ZoneOffset.systemDefault().getRules().getOffset(Instant.now()));
	}
	
	public static double ratio100(double ratePercent) {
		// origin - 17.10.2023, last edit - 17.10.2023
		double res = 0.0;
		res = ratePercent / 100.0;
		res = roundCustom(res, round4);
		return res;
	}
	
	public static boolean strEqual(String str1, String str2) {
		// origin - 18.10.2023, last edit - 18.10.2023
		boolean res = false;
		str1 = fixTrim(str1);
		str2 = fixTrim(str2);
		res = str1.equalsIgnoreCase(str2) == true ? true : res;
		return res;
	}

	public static double roundCustom(double sum) {
		// origin - 17.10.2023, last edit - 17.10.2023
		//variant round less number fractional digit as argument, take him = 2 
		double res = sum;
		res = roundCustom(sum, roundDefault); // default round
		return res;
	}

	public static double roundCustom(double sum, int numberFractionalDigit) {
		// origin - 16.10.2023, last edit - 17.10.2023
		double res = sum;
		int power10 = (int) Math.pow(10, numberFractionalDigit);
		res = sum * power10;
		res = Math.round(res);
		res = res / power10;
		return res;
	}

	public static LocalDate fixLocalDate(LocalDate fixDate) {
		// origin - 02.10.2023, last edit - 27.10.2023
		// LocalDate not must be big endDate and least startDate
		LocalDate res = fixDate;
		if (fixDate.isBefore(Abc.startDate)) {
			res = Abc.startDate;
		}
		if (fixDate.isAfter(Abc.endDate)) {
			res = Abc.endDate;
		}
		return res;
	}

	public static String fixTrim(String fixStr) {
		// origin - 02.10.2023, last edit - 25.10.2023
		return fixStr.trim();
	}

	public static double setZeroOnNeg(Number fixNumb) {
		// origin - 01.10.2023, last edit - 21.10.2023
		// for tax calculate and etc where not need be negative number
		double res = (double) fixNumb;
		res = res < 0 ? 0 : res;
		return (double) res;	
	}

	public static void test() {
		// origin - 01.10.2023, last edit - 28.10.2023
		
		// strEqual
		String str2 = "test1";
		for (String testArg1 : new String[] { "test1", "test1 ", " tEst1", "TEST1", "test22" }) {
			Logger.add("res=" + strEqual(testArg1, str2) + ", str1=" + testArg1 + ", str2=" + str2, "strEqual()",
					"Calc.test()");
		}

		// ratio
		for (double testArg1 : new double[] { 100.0, 67.43, 0.00, 23.56452, 12.0, 234.65432 }) {
			Logger.add("res=" + ratio100(testArg1) + ", rateTax=" + testArg1, "ratio100()", "Calc.test()");
		}

		// roundCustom - round2
		for (double testArg1 : new double[] { 100.0, 57.4363, 43.0078, 21.212, 34.7845 }) {
			Logger.add("res=" + roundCustom(testArg1, round2) + "), (sumLessRound=" + testArg1
					+ ", numberFractionalDigit=" + round2, "roundCustom()", "Calc.test()");
		}
		// roundCustom - round0
		for (double testArg1 : new double[] { 100.0, 57.4363, 43.0078, 21.212, 34.7845 }) {
			Logger.add("res=" + roundCustom(testArg1, round0) + "), (sumLessRound=" + testArg1
					+ ", numberFractionalDigit=" + round0, "roundCustom()", "Calc.test()");
		}

		// fixLocalDate
		for (LocalDate testArg1 : new LocalDate[] { LocalDate.of(2026, 4, 28), LocalDate.of(1967, 11, 25),
				LocalDate.of(2100, 5, 26) }) {
			Logger.add("res=" + fixLocalDate(testArg1) + ", fixDate=" + testArg1, "fixLocalDate()", "Calc.test()");
		}

		// fixTrim
		for (String testArg1 : new String[] { "test1", "test2 ", " test3", " test4 " }) {
			Logger.add("res=" + fixTrim(testArg1) + ", fixStr=" + testArg1, "fixTrim()", "Calc.test()");
		}

		// setZeroOnNeg
		for (double testArg1 : new double[] { 1.25, -41.2556, 0.0, 0.0002, -0.0002, 64.1278 }) {
			Logger.add("res=" + setZeroOnNeg(testArg1) + ", fixNumb=" + testArg1, "setZeroOnNeg()", "Calc.test()");
		}
	}
}
