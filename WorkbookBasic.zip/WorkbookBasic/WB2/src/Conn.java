import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.sqlite.JDBC;

public class Conn {
	// origin - 17.11.2023, last edit - 17.11.2023
	public static String prefixJdbcSqlite = new String();

	static {
		// origin - 17.11.2023, last edit - 17.11.2023
		prefixJdbcSqlite = "jdbc:sqlite:";
	}

	public static void getDbSystemList(String dirPath) throws Exception {
		// origin - 22.10.2023, last edit - 17.11.2023
		if (Files.exists(Paths.get(dirPath)) == true) {

			File file = Paths.get(dirPath).toFile();

			for (File currFile : file.listFiles()) {

				if (currFile.isFile()) {

					// in future will be new versions sqlite, ex. "sqlite4" etc.
					if (currFile.getName().contains(".sqlite")) {

						// if in current database no tables then skip this database file
						if (DAL.existTableList(currFile.toString()) != true) {
							// Logger.add2("no add currFile in dbWork=" + currFile, "getDbSystemList()",
							// "Conn()");
							continue;
						}

						if (Abc.dbSystemNormList.contains(currFile.getPath().toString()) == false) {
							DAL.dbWorkList.add(currFile.getName().toString());
							Logger.add2("add currFile in dbWork=" + currFile, "getDbFile()", "Conn()");
						}

						if (Abc.dbSystemNormList.contains(currFile.getPath().toString()) == true) {
							DAL.dbSystemFactList.add(currFile.getName().toString());
							Logger.add2("add currFile in dbSystemFact=" + currFile, "getDbFile()", "Conn()");
						}
					}
				}
			}
		}
		Logger.add("dbWork.size=" + DAL.dbWorkList.size(), "getDbFile()", "Conn()");
		Logger.add("dbSystemFact.size=" + DAL.dbSystemFactList.size(), "getDbFile()", "Conn()");
	}

	public static String getText(String dbStr) {
		// origin - 02.11.2023, last edit - 17.11.2023
		String connTxt = Etc.fixTrim(dbStr);
		connTxt = Etc.delWord(dbStr, prefixJdbcSqlite);
		connTxt = prefixJdbcSqlite + connTxt;
		return connTxt;
	}

	public static void getDbConnList() throws Exception {
		// origin - 22.10.2023, last edit - 17.11.2023
		Connection conn = null;
		String url = "";
		DriverManager.registerDriver(new JDBC());
		Class.forName("org.sqlite.JDBC");

		for (String currDbWork : DAL.dbWorkList) {
			// Logger.add("(currDbWork=" + currDbWork, "getConn()", "DAL()");
			try {
				url = getText(currDbWork.toString());
				// if in current database no tables then skip this url
				if (DAL.existTableList(url) != true) {
					continue;
				}
				conn = DriverManager.getConnection(url);
				if (conn.isValid(1)) {
					DAL.dbConnList.add(url.toString());
					Logger.add2("url good conn=" + url, "getConn()", "DAL()");
				}

			} catch (SQLException e) {
				Logger.add2("url bad conn=" + currDbWork, "getConn()", "DAL()");
			} finally {
				try {
					if (conn != null) {
						conn.close();
					}
				} catch (SQLException ex) {
				}
			}
		}
	}

	public static void cloneDbTemplate(String dirPath) throws Exception {
		// origin - 22.10.2023, last edit - 17.11.2023
		if (DAL.dbWorkList.isEmpty()) {

			Path fileTo = Paths.get(Abc.dbWorkAutoCreatePath);

			if (Files.notExists(fileTo)) {

				Path fileFrom = Paths.get(Abc.dbTemplatePath);

				if (Files.exists(fileFrom)) {
					Logger.add("Files.exists(fileFrom)=" + Files.exists(fileFrom), "cloneDbTemplate()", "Conn()");

					if (DAL.existTableList(fileFrom.toString())) {

						try {
							Files.copy(fileFrom, fileTo);
						} catch (Exception ex) {
						} finally {
						}
						DAL.dbWorkList.add(fileTo.toString());
						Logger.add("dbWorkAutoCreatePath=" + Abc.dbWorkAutoCreatePath, "cloneDbTemplate()", "Conn()");
						Logger.add2("dbWork.size=" + DAL.dbWorkList.size(), "cloneDbTemplate()", "Conn()");
					}
				}
			}
		}
	}

	public static void test() throws Exception {
		// origin - 17.11.2023, last edit - 17.10.2023
	}
}
