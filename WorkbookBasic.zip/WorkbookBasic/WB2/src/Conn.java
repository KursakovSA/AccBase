import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.TreeSet;

public class Conn {
	// origin - 17.11.2023, last edit - 26.11.2023
	private static String dbDir;
	public static final String global;
	public static final String globalPath;
	public static final String template;
	public static final String templatePath;
	public static final String workAutoCreate;
	public static final String workAutoCreatePath;
	public static TreeSet<String> systemFact = new TreeSet<String>();
	public static TreeSet<String> work = new TreeSet<String>();
	public static TreeSet<String> workOut = new TreeSet<String>(); // TODO ????
	public static final TreeSet<String> systemNorm;
	public static final List<String> tableNorm;
	public static final String prefixJdbcSqlite;

	static {
		dbDir = System.getProperty("user.dir");
		global = "DatabaseGlobal.sqlite3"; // TODO --- sqlite4 ???
		globalPath = dbDir + File.separator + global;
		template = "DatabaseTemplate.sqlite3"; // TODO --- sqlite4 ???
		templatePath = dbDir + File.separator + template;
		workAutoCreate = "MyBase1.sqlite3"; // TODO --- sqlite4 ???
		workAutoCreatePath = dbDir + File.separator + workAutoCreate;
		systemNorm = new TreeSet<String>(Arrays.asList(globalPath, templatePath));
		tableNorm = new ArrayList<String>(Arrays.asList("Account", "Asset", "Deal", "Debt", "Face", "Geo", "Info",
				"Item", "Mark", "Meter", "Price", "Process", "Role", "Sign", "Slice", "Unit", "Workbook"));
		prefixJdbcSqlite = "jdbc:sqlite:";	
	}
	
	public static void init() throws Exception{
		// origin - 25.11.2023, last edit - 25.11.2023
		if (systemFact.isEmpty()) {
			getDbList(dbDir);
			cloneDbTemplate(dbDir);
		}
		setLast();
	}

	private static void setLast() throws Exception {
		// origin - 25.11.2023, last edit - 26.11.2023
		if (work.isEmpty() == false) {
			WB.lastConn = work.first();
			Logger.add("Conn.setLast, WB.lastConn=" + WB.lastConn, "", "Conn");
			try {
				WB.abcLastConn = new Abc(WB.lastConn, Qry.templateMoreAbcBasic);
				Logger.add("Conn.setLast, WB.abcLastConn=" + WB.abcLastConn, "", "Conn");
			} catch (Exception ex) {
				Logger.add("WB.static init, abcGlobal, ex=" + ex.getMessage(), "StackTrace=" + ex.getStackTrace(), "WB");
			}
		}
	}

	private static void getDbList(String dirPath) throws Exception {
		// origin - 22.10.2023, last edit - 25.11.2023
		if (Files.exists(Paths.get(dirPath)) == true) {

			File file = Paths.get(dirPath).toFile();

			for (File currFile : file.listFiles()) {

				if (currFile.isFile()) {

					// in future will be new versions SQLite, example "sqlite4" etc.
					if (currFile.getName().contains(".sqlite")) {

						// skip DatabaseLarge
						if (currFile.getName().contains("DatabaseLarge")) {
							continue;
						}

						// if in current database no tables norm then skip this database file
						if (hasTableNormList(currFile.toString()) != true) {
							// Logger.add("getDbList.dbHasTableNormList=" +
							// DAL.dbHasTableNormList(currFile.toString()), "currFile=" + currFile,
							// "Conn()");
							continue;
						}

						// if in current database no tables then skip this database file
						if (DAL.existTableList(currFile.toString()) != true) {
							// Logger.add("getDbList.existTableList=" +
							// DAL.existTableList(currFile.toString()), "currFile=" + currFile, "Conn()");
							continue;
						}

						if (systemNorm.contains(currFile.getPath().toString()) == false) {
							work.add(currFile.getName().toString());
						}

						if (systemNorm.contains(currFile.getPath().toString()) == true) {
							systemFact.add(currFile.getName().toString());
						}
					}
				}
			}
		}
		Logger.add("Conn.getDbList, Conn.work=" + work, "", "Conn");
		Logger.add("Conn.getDbList, Conn.systemFact=" + systemFact, "", "Conn");
	}

	public static String getText(String dbStr) {
		// origin - 02.11.2023, last edit - 25.11.2023
		String res = Etc.fixTrim(dbStr);
		res = Etc.delStr(dbStr, prefixJdbcSqlite);
		res = prefixJdbcSqlite + res;
		return res;
	}

	private static void cloneDbTemplate(String dirPath) throws Exception {
		// origin - 22.10.2023, last edit - 25.11.2023
		if (work.isEmpty()) {

			Path fileTo = Paths.get(workAutoCreatePath);

			if (Files.notExists(fileTo)) {

				Path fileFrom = Paths.get(templatePath);

				if (Files.exists(fileFrom)) {

					if (DAL.existTableList(fileFrom.toString())) {

						if (hasTableNormList(fileFrom.toString())) {

							try {
								Files.copy(fileFrom, fileTo);
							} catch (Exception ex) {
								Logger.add("cloneDbTemplate, ex=" + ex.getMessage(),
										", StackTrace=" + ex.getStackTrace(), "Conn");
							} finally {
							}
							work.add(fileTo.toString());
							Logger.add("cloneDbTemplate, dbWorkAutoCreatePath=" + workAutoCreatePath, "",
									"Conn()");
							Logger.add("cloneDbTemplate, dbWork=" + work, "", "Conn()");
						}
					}
				}
			}
		}
	}
	
	private static boolean hasTableNormList(String currConn) {
		// origin - 22.11.2023, last edit - 25.11.2023
		boolean res = false;
		List<String> dbHasTableFactList = DAL.getTableList(currConn);
		if (dbHasTableFactList.containsAll(Conn.tableNorm)) {
			res = true;
		}
		return res;
	}

	public static void test() throws Exception {
		// origin - 17.11.2023, last edit - 17.10.2023
	}
}
