import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.TreeSet;

import org.sqlite.JDBC;

public class DAL {
	// origin - 23.10.2023, last edit - 29.10.2023
	public static TreeSet<String> dbSystemFact = new TreeSet<String>();
	public static TreeSet<String> dbWork = new TreeSet<String>();
	public static TreeSet<String> dbAll = new TreeSet<String>();
	public static TreeSet<String> dbConn = new TreeSet<String>();
	public static TreeSet<String> dbOut = new TreeSet<String>(); // TODO
	public static TreeSet<String> dbBasic = new TreeSet<String>(); // TODO
	public static TreeSet<String> dbNotVisible = new TreeSet<String>(); // TODO

	public static TreeSet<ModelDto> getTable(String dbStr, String tableStr) throws Exception {
		// origin - 28.10.2023, last edit - 29.10.2023
		TreeSet<ModelDto> res = new TreeSet<ModelDto>();
		Connection conn = null;
		for (String currConn : dbConn) {
			Logger.add("(currConn=" + currConn.toString(), "getTable()", "DAL()");
			if (dbStr.isEmpty() != true) {
				if (currConn.contains(dbStr)) {
					Logger.add("(currConn contains dbStr=" + dbStr, "getTable()", "DAL()");
				}

				if (tableStr.isEmpty() != true) {
					Logger.add("(tableStr=" + tableStr, "getTable()", "DAL()");
					conn = DriverManager.getConnection(currConn);
					java.sql.Statement qry = conn.createStatement();
					
					ResultSet rs = qry.executeQuery("SELECT * FROM " + tableStr);
					ResultSetMetaData rsmd = rs.getMetaData();
					int columnCount = rsmd.getColumnCount();
					
					while (rs.next()) {
						for (int i = 1; i <= columnCount; i++) {
							String name = rsmd.getColumnName(i);
							//Logger.add("(column name=" + name, "getTable()", "DAL()");
							Logger.add("(column name=" + name +", column value="+rs.getString(name), "getTable()", "DAL()");
						}
					}
					
			
				}

			}
		}
		return res;
	}
	
//	public static int getColumnIndex(ResultSet rs, String columnName) throws Exception {
//		// origin - 29.10.2023, last edit - 30.10.2023
//		int res=0;
//		try {
//			res = rs.findColumn(columnName);
//			//Logger.add("(column name good =" + columnName, "getColumnIndex()", "DAL()");
//		} catch (Exception e) {
//			//Logger.add("(column name bad =" + columnName, "getColumnIndex()", "DAL()");
//		} finally {
//		}
//		
//		return res;
//	}

	public static String getNameView(String tableName) {// if tableName = "Account", then viewName = "AccountList", etc.
		// origin - 29.10.2023, last edit - 29.10.2023
		String res = "";
		String addWord = "List";
		res = Calc.fixTrim(tableName); // delete space
		res = res.replace(addWord, ""); // delete word "list" if it exist then 2 time word "list" not add
		res = res + addWord;
		return res;
	}

	public static String getQry(String table) {
		// origin - 25.10.2023, last edit - 25.10.2023
		String res = "";
		// TODO
		return res;
	}

	public static void getConn() throws Exception {
		// origin - 22.10.2023, last edit - 28.10.2023
		Connection conn = null;
		String url = null;
		DriverManager.registerDriver(new JDBC());
		Class.forName("org.sqlite.JDBC");

		for (String currDbWork : dbWork) {
			try {
				// DriverManager.registerDriver(new JDBC());
				// Class.forName("org.sqlite.JDBC");
				url = "jdbc:sqlite:" + currDbWork.toString();
				conn = DriverManager.getConnection(url);
				dbConn.add(url.toString());
				// System.out.println("Connection to SQLite has been established.");
				Logger.add("(url good conn=" + url, "getConn()", "DAL()");

			} catch (SQLException e) {
				// System.out.println("1 try.checkTest(), " + e.getMessage());
				Logger.add("(url bad conn=" + currDbWork, "getConn()", "DAL()");
			} finally {
				try {
					if (conn != null) {
						conn.close();
					}
				} catch (SQLException ex) {
					// System.out.println("2 try.checkTest(), " + ex.getMessage());
				}
			}
		}
	}

	public static void test() throws Exception {
		// origin - 21.10.2023, last edit - 29.10.2023
		getDbFile(Abc.dbDir);
		cloneDbTemplate(Abc.dbDir);
		getConn();
		getTable("MyBase1.sqlite3", getNameView("Account")); // TODO

//		// getNameView
//		for (String testArg1 : new String[] { "Account", "AssetList  ", " Deal", "Debt", "ListPriListceList" }) {
//			Logger.add("res=" + getNameView(testArg1) + ", str1=" + testArg1, "getNameView()", "DAL.test()");
//		}
	}

	public static void getDbFile(String dirPath) throws Exception {
		// origin - 22.10.2023, last edit - 27.10.2023
		if (Files.exists(Paths.get(dirPath)) == true) {
			File file = Paths.get(dirPath).toFile();
			for (File currFile : file.listFiles()) {
				if (currFile.isFile()) {
					if (currFile.getName().endsWith(".sqlite3")) {
						if (Abc.dbSystemNorm.contains(currFile.getPath().toString()) == false) {
							dbWork.add(currFile.getName().toString());
						}

						if (Abc.dbSystemNorm.contains(currFile.getPath().toString()) == true) {
							dbSystemFact.add(currFile.getName().toString());
						}
					}
				}
			}
		}
		Logger.add("(dbWork.size()=" + dbWork.size(), "getDbFile()", "DAL()");
		Logger.add("(dbSystemFact.size()=" + dbSystemFact.size(), "getDbFile()", "DAL()");
	}

	public static void cloneDbTemplate(String dirPath) throws Exception {
		// origin - 22.10.2023, last edit - 29.10.2023
		if (dbWork.isEmpty()) {
			Path fileTo = Paths.get(Abc.dbWorkAutoCreatePath);
			if (Files.notExists(fileTo)) {
				Path fileFrom = Paths.get(Abc.dbTemplatePath);
				if (Files.exists(fileFrom)) {
					Files.copy(fileFrom, fileTo);
					dbWork.add(fileTo.toString());
					dbBasic.add(fileTo.toString());
					Logger.add("dbWorkAutoCreatePath=" + Abc.dbWorkAutoCreatePath, "cloneDbTemplate()", "DAL()");
					Logger.add("dbWork.size()=" + dbWork.size(), "cloneDbTemplate()", "DAL()");
				}
			}
		}
	}
}
