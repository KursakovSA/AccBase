import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

public class DAL {
	// origin - 23.10.2023, last edit - 17.11.2023
	public static TreeSet<String> dbSystemFactList = new TreeSet<String>();
	public static TreeSet<String> dbWorkList = new TreeSet<String>();
	public static TreeSet<String> dbConnList = new TreeSet<String>();
	public static TreeSet<String> dbOutList = new TreeSet<String>(); // TODO ????
	public static String currConnWork = new String();

	static {
		// origin - 09.11.2023, last edit - 17.11.2023
	}

	public static List<ModelDto> getBasic(String currConn, String templateMore) throws Exception {
		// origin - 13.11.2023, last edit - 17.11.2023
		List<ModelDto> res = new ArrayList<ModelDto>();
		List<ModelDto> tmp = new ArrayList<ModelDto>();
		tmp.clear();
		Qry qryAbc = new Qry();
		qryAbc.templateMore = Etc.fixString(templateMore);
		List<String> tableList = getTableList(currConn);
		for (var currTable : tableList) {
			if (tmp.isEmpty() != true) {
				res.addAll(tmp);
			}
			tmp.clear();
			
			//skip table "Workbook", there never no basic data
			if (Etc.strEqual(currTable, Qry.WorkbookTableName)) {
				Logger.add2("skip table=" + currTable,"", "DAL.getBasic()");
				continue;
			}
			
			qryAbc.table = Etc.fixString(currTable);
			tmp = getTable(currConn, qryAbc.getText());
			// Logger.add("tmp.size=" + tmp.size(), ", currTable=" + currTable,
			// "getBasic()");
		}
		Logger.add("res.size=" + res.size(),"templateMore=" +templateMore, "getBasic");
		return res;
	}
	
	public static boolean existTableList(String currConn) {
		// origin - 16.11.2023, last edit - 17.11.2023
		boolean res = false;
		try {
			if (getTableList(currConn).isEmpty() != true) {
				res = true;
			}
		} catch (Exception ex) {
		} finally {
		}
		// Logger.add2("res=" + res,"currConn="+currConn, "DAL.existTableList()");
		return res;
	}

	public static List<String> getTableList(String currConn) {
		// origin - 13.11.2023, last edit - 15.11.2023
		List<String> res = new ArrayList<String>();
		currConn = Conn.getText(currConn);
		
		try {
			Connection conn = DriverManager.getConnection(currConn);
			currConnWork = currConn;
			java.sql.Statement qry = conn.createStatement();
			ResultSet rs;
			rs = qry.executeQuery(Qry.getTableListSQLite);
			while (rs.next()) {
				res.add(rs.getString("name"));
			}
			rs.close();
		
		} catch (Exception ex) {
			Logger.add2("ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "getTableList()");
		} finally {
		}
		Logger.add2("res=" + res + ", currConn=" + currConn, "getTableList()", "DAL()");
		return res;
	}

	public static List<ModelDto> getTable(String dbStr, String preparedQryText) throws Exception {
		// origin - 28.10.2023, last edit - 15.11.2023
		List<ModelDto> res = new ArrayList<ModelDto>();
		String currConn = Conn.getText(dbStr);
		res = getModelDto(currConn, preparedQryText);
		Logger.add2("Db=" + dbStr + ", qry=" + preparedQryText + ", cardinality=" + res.size(), "getTable()", "DAL()");
		return res;
	}

//	public static List<ModelDto> getModelDto(String table) throws Exception {
//		// origin - 03.11.2023, last edit - 15.11.2023
//		List<ModelDto> res = new ArrayList<ModelDto>();
//		table = getViewName(table, postfixView);
//		Qry qry = new Qry(table);
//		res = getModelDto(currConnWork, qry.getText());
//		Logger.add2("(get ModelDto() on currConnWork=" + currConnWork, "getModelDto()", "DAL()");
//		return res;
//	}

	public static List<ModelDto> getModelDto(String currConn, String preparedQryText) {
		// origin - 31.10.2023, last edit - 15.11.2023
		List<ModelDto> res = new ArrayList<ModelDto>();
		currConn = Conn.getText(currConn);

		try {
			Connection conn = DriverManager.getConnection(currConn);
			currConnWork = currConn;
			java.sql.Statement qry = conn.createStatement();

			ResultSet rs;
			rs = qry.executeQuery(preparedQryText);

			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			String nameDbColumn = "";
			Class<ModelDto> ModelDtoClassObject = ModelDto.class;
			Field field = null;
			ModelDto currDto = new ModelDto();

			while (rs.next()) {
				currDto.dbConn = Etc.fixTrim(currConn);
				currDto.table = rsmd.getTableName(1); //System.out.println(rsmd.getTableName(1).toString());

				for (int i = 1; i <= columnCount; i++) {
					nameDbColumn = rsmd.getColumnName(i);
					// for each nameDbColumn example"Deal" match field ModelDto example "deal"
					field = ModelDtoClassObject.getField(getDtoFieldName(nameDbColumn));
					field.set(currDto, rs.getString(nameDbColumn));
				}
				res.add(currDto);
			}
			rs.close();
			// Logger.add("last currDto=" + currDto, ", tableStr=" + tableStr, "getModelDto()");
		
		} catch (Exception ex) {
			Logger.add2("ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "getModelDto()");
		} finally {
		}
		return res;
	}

	public static String getDtoFieldName(String nameDbColumn) {
		// origin - 06.11.2023, last edit - 14.11.2023
		String res = "";
		res = res + nameDbColumn.charAt(0);
		res = res.toLowerCase(); // only first letter transform into LowerCase, that was right example
									// "MeterValue to
									// "meterValue"
		res = res + nameDbColumn.substring(1, nameDbColumn.length());
		return res;
	}

	public static void test() throws Exception {
		// origin - 21.10.2023, last edit - 17.11.2023
		Conn.getDbSystemList(Abc.dbDir);
		Conn.cloneDbTemplate(Abc.dbDir);
		Conn.getDbConnList();
		//getTable("DatabaseLarge.sqlite3", "SELECT * FROM Face WHERE More LIKE '%AbcBasic%'");

		// getTableList("DatabaseTemplate.sqlite3");
		getBasic("DatabaseLarge.sqlite3", Qry.templateMoreAbcBasic);

//		getTable("DatabaseLarge.sqlite3", Qry.WorkbookTableName,"SELECT [T1].[Face1], [T1].[Slice], [T1].[Sign], [T1].[Account], [T1].[Asset], [T1].[Meter], [T1].[Unit], [T1].[Mark],\r\n"
//				+ "SUM(CAST([T1].[MeterValue] AS REAL)) AS MeterValue\r\n"
//				+ "\r\n"
//				+ "FROM [Workbook] AS [T1]                            \r\n"
//				+ "\r\n"
//				+ "WHERE \r\n"
//				+ "[T1].[Slice] = 'Slice.Accounting' AND\r\n"
//				+ "[T1].[Mark] = 'Mark.CD' AND\r\n"
//				+ "[T1].[Meter] = 'Meter.Quantity' AND\r\n"
//				+ "[T1].[Unit] = 'Unit.KZT' AND\r\n"
//				+ "[T1].[Account] IS NOT NUll AND\r\n"
//				+ "[T1].[Sign] IS NOT NULL AND\r\n"
//				+ "\r\n"
//				+ "[T1].[Asset] = 532 \r\n"
//				+ "\r\n"
//				+ "GROUP BY [T1].[Face1], [T1].[Slice], [T1].[Asset], [T1].[Sign], [T1].[Account], [T1].[Meter], [T1].[Unit], [T1].[Mark]");

		// getDtoFieldName
		for (var testArg1 : new String[] { "Id", "Parent", "Deal", "Debt", "MeterValue" }) {
			Logger.add2("res=" + getDtoFieldName(testArg1) + ", str1=" + testArg1, "getDtoFieldName()", "DAL.test()");
		}
	}
}
