import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.List;

public class DAL {
	// origin - 23.10.2023, last edit - 25.11.2023

	public static List<ModelDto> getBasic(String currConn, String templateMore) throws Exception {
		// origin - 13.11.2023, last edit - 23.11.2023
		List<ModelDto> res = new ArrayList<ModelDto>();

		if (WB.existFile(currConn) == false) {
			Logger.add("getBasic(), not exist=" + currConn, "", "DAL");
			return res;
		}

		List<ModelDto> tmp = new ArrayList<ModelDto>();

		Qry qryAbc = new Qry();
		qryAbc.templateMore = Etc.fixString(templateMore);

		List<String> tableList = getTableList(currConn);
		for (var currTable : tableList) {
			tmp.clear();

			qryAbc.table = Etc.fixString(currTable);
			tmp = getTable(currConn, qryAbc.getText(currConn));

			if (tmp.isEmpty() != true) {
				res.addAll(tmp);
				tmp.clear();
			}
		}
		// Logger.add("getBasic.res.size=" + res.size(), "currConn="+currConn, "DAL");
		return res;
	}

	public static boolean existTableList(String currConn) {
		// origin - 16.11.2023, last edit - 23.11.2023
		boolean res = false;
		try {
			if (getTableList(currConn).isEmpty() != true) {
				res = true;
			}
		} catch (Exception ex) {
			Logger.add("existTableList, ex=" + ex.getMessage(), "StackTrace=" + ex.getStackTrace(), "DAL");
		} finally {
		}
		return res;
	}

	public static List<String> getTableList(String currConn) {
		// origin - 13.11.2023, last edit - 23.11.2023
		List<String> res = new ArrayList<String>();

		if (WB.existFile(currConn) == false) {
			Logger.add("not exist=" + currConn, "getTableList()", "DAL");
			return res;
		}

		currConn = Conn.getText(currConn);

		try {
			Connection conn = DriverManager.getConnection(currConn);
			WB.lastConn = currConn;
			java.sql.Statement qry = conn.createStatement();
			ResultSet rs;
			rs = qry.executeQuery(Qry.getTableListSQLite);
			while (rs.next()) {
				res.add(rs.getString("name"));
			}
			rs.close();

		} catch (Exception ex) {
			Logger.add("getTableList, ex=" + ex.getMessage(), "StackTrace=" + ex.getStackTrace(), "DAL");
		} finally {
		}
		return res;
	}

	public static List<ModelDto> getTable(String dbStr, String preparedQryText) throws Exception {
		// origin - 28.10.2023, last edit - 23.11.2023
		List<ModelDto> res = new ArrayList<ModelDto>();
		String currConn = Conn.getText(dbStr);

		if (WB.existFile(currConn) == false) {
			Logger.add("getTable, not exist=" + dbStr, "currConn=" + currConn, "DAL");
			return res;
		}

		res = getModelDto(currConn, preparedQryText);
		// Logger.add("Db=" + dbStr + ", qry=" + preparedQryText + ", cardinality=" +
		// res.size(), "getTable()", "DAL()");
		return res;
	}

	public static List<ModelDto> getModelDto(String currConn, String preparedQryText) {
		// origin - 31.10.2023, last edit - 25.11.2023
		List<ModelDto> res = new ArrayList<ModelDto>();

		if (WB.existFile(currConn) == false) {
			Logger.add("getModelDto, not exist=" + currConn, "", "DAL");
			return res;
		}

		currConn = Conn.getText(currConn);

		try {
			Connection conn = DriverManager.getConnection(currConn);
			WB.lastConn = currConn;
			java.sql.Statement qry = conn.createStatement();

			ResultSet rs;
			// Logger.add("getModelDto, preparedQryText=" + preparedQryText, "currConn=" +
			// currConn, "DAL()");
			rs = qry.executeQuery(preparedQryText);

			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			String nameDbColumn = "";
			Class<ModelDto> ModelDtoClassObject = ModelDto.class;
			Field field = null;
			ModelDto currDto = new ModelDto();

			while (rs.next()) {
				currDto.table = rsmd.getTableName(1);

				for (int i = 1; i <= columnCount; i++) {
					nameDbColumn = rsmd.getColumnName(i);
					// for each nameDbColumn example"Deal" match field ModelDto example "deal"
					field = ModelDtoClassObject.getField(getDtoFieldName(nameDbColumn));

					field.set(currDto, Etc.fixString(rs.getString(nameDbColumn)));
				}
				if (currDto.id.isEmpty() != true) {
					res.add(currDto);
				}
			}
			rs.close();
			// Logger.add("getModelDto, preparedQryText=" + preparedQryText, "res.size=" +
			// res.size(), "DAL()");

		} catch (Exception ex) {
			Logger.add("getModelDto, ex=" + ex.getMessage(), ", StackTrace=" + ex.getStackTrace(), "DAL");
		} finally {
		}
		return res;
	}

	private static String getDtoFieldName(String nameDbColumn) {
		// origin - 06.11.2023, last edit - 25.11.2023
		String res = "";
		res = res + nameDbColumn.charAt(0);
		res = res.toLowerCase(); // only first letter transform into LowerCase, that was right example
									// "MeterValue to
									// "meterValue"
		res = res + nameDbColumn.substring(1, nameDbColumn.length());
		return res;
	}

	public static void test() throws Exception {
		// origin - 21.10.2023, last edit - 24.11.2023
		// getTable("DatabaseLarge.sqlite3", "SELECT * FROM Face WHERE More LIKE
		// '%AbcBasic%'");
		// getTable("DatabaseTemplate.sqlite3", "SELECT * FROM Face WHERE More LIKE
		// '%AbcBasic%'");

		// getBasic("DatabaseLarge.sqlite3", Qry.templateMoreAbcBasic);

//		getTable("DatabaseLarge.sqlite3", "SELECT [T1].[Face1], [T1].[Slice], [T1].[Sign], [T1].[Account], [T1].[Asset], [T1].[Meter], [T1].[Unit], [T1].[Mark],\r\n"
//				+ "SUM(CAST([T1].[MeterValue] AS REAL)) AS MeterValue\r\n"
//				+ "\r\n"
//				+ "FROM [Workbook] AS [T1]                            \r\n"
//				+ "\r\n"
//				+ "WHERE \r\n"
//				+ "[T1].[Slice] = 'Slice.Accounting' AND\r\n"
//				+ "[T1].[Mark] = 'Mark.CD' AND\r\n"
//				+ "[T1].[Meter] = 'Meter.Quantity' AND\r\n"
//				+ "[T1].[Unit] = 'Unit.KZT' AND\r\n"
//				+ "[T1].[Account] IS NOT NUll AND\r\n"
//				+ "[T1].[Sign] IS NOT NULL AND\r\n"
//				+ "\r\n"
//				+ "[T1].[Asset] = 532 \r\n"
//				+ "\r\n"
//				+ "GROUP BY [T1].[Face1], [T1].[Slice], [T1].[Asset], [T1].[Sign], [T1].[Account], [T1].[Meter], [T1].[Unit], [T1].[Mark]");

//		// getDtoFieldName
//		for (var testArg1 : new String[] { "Id", "Parent", "Deal", "Debt", "MeterValue" }) {
//			Logger.add2("res=" + getDtoFieldName(testArg1) + ", str1=" + testArg1, "getDtoFieldName()", "DAL.test()");
//		}
	}
}
