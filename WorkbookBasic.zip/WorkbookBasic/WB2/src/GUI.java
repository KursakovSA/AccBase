import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JToolBar;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;

public class GUI {
	// origin - 03.12.2023, last edit - 05.12.2023
	private static JMenuBar basicMenuBar;
	private static JToolBar basicToolBar;
	
	static {
		try {
			basicMenuBar = getBasicMenuBar();
			basicToolBar = getBasicToolBar();
		} catch (Exception ex) {
			Logger.add("GUI.static ctor, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "", "GUI");
		} finally {
		}
	}

	public static JFrame getFrameBasic() throws Exception {
		// origin - 03.12.2023, last edit - 05.12.2023
		JFrame frame = new JFrame();
		EventQueue.invokeLater(() -> {
			try {
				frame.setTitle(WB.frameBasicTitle);
				JPanel panelBasic = new JPanel();
				panelBasic.setBackground(Color.lightGray);

				GridLayout layout = new GridLayout(15, 4);
				panelBasic.setLayout(layout);

				JButton overviewButton = new JButton();
				overviewButton.setText("Overview");
//				overviewButton.getHeight();
//				// panelBasic.add(overviewButton);
//				panelBasic.add(overviewButton);

				frame.add(panelBasic);

				frame.setJMenuBar(basicMenuBar);
				frame.add(basicToolBar, BorderLayout.NORTH);

				frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
				frame.setPreferredSize(new Dimension(640, 480));
				frame.setExtendedState(java.awt.Frame.MAXIMIZED_BOTH);
				frame.setVisible(true);
			} catch (Exception ex) {
				Logger.add("GUI.getFrameBasic, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "",
						"GUI");
			} finally {
			}
		});
		return frame;
	}

	private static JMenuBar getBasicMenuBar() throws Exception {
		// origin - 03.12.2023, last edit - 03.12.2023
		JMenuBar menuBar = new JMenuBar();
		EventQueue.invokeLater(() -> {
			try {
				JMenu fileMenu = new JMenu("File");
				var openItem = new JMenuItem("Open");
				var saveItem = new JMenuItem("Save");
				var exitItem = new JMenuItem("Exit");
				fileMenu.add(openItem);
				fileMenu.add(saveItem);
				fileMenu.addSeparator();
				fileMenu.add(exitItem);
				fileMenu.setSize(100, 200);
				menuBar.add(fileMenu);

				JMenu editMenu = new JMenu("Edit");
				var newItem = new JMenuItem("New");
				fileMenu.addSeparator();
				var existItem = new JMenuItem("Exist");
				editMenu.add(newItem);
				editMenu.add(existItem);
				menuBar.add(editMenu);
			} catch (Exception ex) {
				Logger.add("GUI.getBasicMenuBar, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "",
						"GUI");
			} finally {
			}
		});

		return menuBar;
	}

	private static JToolBar getBasicToolBar() throws Exception {
		// origin - 05.12.2023, last edit - 05.12.2023
		JToolBar toolBar = new JToolBar();
		EventQueue.invokeLater(() -> {
			try {
				toolBar.setFloatable(false);
				toolBar.setOrientation(SwingConstants.HORIZONTAL);
				JButton bt = null;
				bt = new JButton("toolbar button 1");
				// bt.addActionListener(this);
				toolBar.add(bt);
				bt = new JButton("toolbar button 1");
				// bt.addActionListener(this);
				toolBar.add(bt);
				// toolBar.addSeparator(); // добавить разделитель
				bt = new JButton("toolbar button 1");
				// bt.addActionListener(this);
				toolBar.add(bt);

			} catch (Exception ex) {
				Logger.add("GUI.getBasicToolBar, ex=" + ex.getMessage() + ", StackTrace=" + ex.getStackTrace(), "",
						"GUI");
			} finally {
			}
		});

		return toolBar;
	}

	public static void test() throws Exception {
		// origin - 03.12.2023, last edit - 03.12.2023
	}
}