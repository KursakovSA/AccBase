public class Meter extends Model {
	// origin - 28.09.2023, last edit - 28.11.2023
	public Unit unit = new Unit();
	
	public static void test() {
		// origin - 28.10.2023, last edit - 28.11.2023
		Meter testMeter = new Meter();
    	Logger.add("Meter.test, testMeter=" + testMeter, "", "Meter");
	}
}
