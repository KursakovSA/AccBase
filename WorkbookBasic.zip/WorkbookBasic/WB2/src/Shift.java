import java.util.Arrays;
import java.util.TreeSet;

public class Shift {
	// origin - 26.10.2023, last edit - 26.11.2023
	public static TreeSet<String> sliceAllow;
	public static TreeSet<String> markAllow;
	static {
		// origin - 26.11.2023, last edit - 26.11.2023
		sliceAllow = new TreeSet<String>(Arrays.asList("Accounting", "Fact", "Plan"));
		markAllow = new TreeSet<String>(Arrays.asList("Arc", "ToCD", "DD", "DelD"));
	}
	
	public static void test() throws Exception {
		// origin - 26.11.2023, last edit - 26.11.2023
	}

	public String toString() {
		// origin - 26.11.2023, last edit - 26.11.2023
		return this.getClass().getName() + "{" + "sliceAllow.size=" + sliceAllow.size() + '}';
	}
}
