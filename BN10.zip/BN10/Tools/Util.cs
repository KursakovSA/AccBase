﻿#nullable disable
namespace Tools;
[Serializable]
public partial class Util
{
    //public static void FromClipboardToStringForBasic()
    //{
    //    //запрашиваем блок строк с переносами, вводимый из буфера обмена
    //    //делаем из этой строки массив с кавычками по 5 элементов  
    //    //это нужно для быстрого импорта строк в ctor static basic-поля из XLS-файлов
    //    var DataObject = Clipboard.GetDataObject();
    //    if (DataObject.ToString().Length == 0) return;
    //    string text = DataObject.GetData("UnicodeText", true).ToString();
    //    string[] Arr = text.Split(new[] { '\n' }, System.StringSplitOptions.RemoveEmptyEntries);
    //    string StrToClipboard = "";
    //    int Count = 0;
    //    foreach (string tmpArr in Arr)
    //    {
    //        Count++;
    //        StrToClipboard += "\"" + tmpArr.Trim() + "\"" + ",";
    //        if (Count % 5 == 0)
    //        {
    //            StrToClipboard += Environment.NewLine;
    //        }
    //    }
    //    if (Count != 0)
    //    {
    //        Clipboard.SetText(StrToClipboard);
    //    }
    //}
    public static void FromClipboardToJSONForMore()
    {
        //запрашиваем блок строк, разделенный точками с запятой, вводимый из буфера обмена 
        //это нужно для быстрого импорта строк в JSON More-поля из XLS-файлов
        var DataObject = Clipboard.GetDataObject();
        if (DataObject.ToString().Length == 0) return;
        string text = DataObject.GetData("UnicodeText", true).ToString();
        string[] Arr = text.Split(new[] { '\n' }, System.StringSplitOptions.RemoveEmptyEntries);
        string[] Arr2;
        string StrToClipboard = "";
        int PosLastDot;  //потому что раньше в полях More были строки "Role.Account.Debitor;", и теперь надо найти последнюю точку, это будет разделитель объекта и значения
        string CurrStr, CurrStr2, Obj_JSON, Value_JSON;
        foreach (string tmpArr in Arr)
        {
            CurrStr = tmpArr.Trim();
            if (CurrStr.Length == 0)
            {
                StrToClipboard += Environment.NewLine;
            }
            else
            {
                StrToClipboard += "{";
                Arr2 = tmpArr.Split(new[] { ';' }, System.StringSplitOptions.RemoveEmptyEntries);
                foreach (string tmpArr2 in Arr2)
                {
                    CurrStr2 = tmpArr2.Trim();
                    if (CurrStr2.Length != 0)
                    {
                        PosLastDot = CurrStr2.LastIndexOf(".");
                        Obj_JSON = CurrStr2.Substring(0, PosLastDot);
                        Value_JSON = CurrStr2.Substring(PosLastDot + 1);
                        StrToClipboard += "\"" + Obj_JSON + "\": " + "\"" + Value_JSON + "\",";
                    }
                }
                StrToClipboard += "}";
                StrToClipboard += Environment.NewLine;
            }
        }
        Clipboard.SetText(StrToClipboard);
    }
    public Util() { }
    static Util() { }
}

