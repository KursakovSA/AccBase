﻿namespace BN;
[Serializable]
[Table("Unit")]
public partial class Unit : HeadClass
{
    public Unit? Parent { get; set; }
    public Role? Role { get; set; }
    public Unit? Unit1 { get; set; }
    [NotMapped]
    public static string[]? BasicCode = {
            "Unit","Unit.Account","Unit.Box","Unit.CalendarDay","Unit.Case",
"Unit.CurrUnit","Unit.Day","Unit.Deal","Unit.Delivery","Unit.Dismissal",
"Unit.Doc","Unit.DocID","Unit.EUR","Unit.Face","Unit.HalfYear",
"Unit.Hiring","Unit.HR","Unit.InfoBase","Unit.Jar","Unit.Kg",
"Unit.Kilometer","Unit.KZT","Unit.Litr","Unit.Meter","Unit.MinCalcRate",
"Unit.MinSalary","Unit.Month","Unit.Pack","Unit.Packet","Unit.Percent",
"Unit.Piece","Unit.Position","Unit.Product","Unit.Quarter","Unit.RUB",
"Unit.Service","Unit.SquareMeter","Unit.T","Unit.Text","Unit.USD",
"Unit.User","Unit.Week","Unit.WorkDay","Unit.WorkHour","Unit.Year",
"Unit1","Unit2","Unit3","Unit4","Unit5",
"Unit6","Unit7","Unit8",
        };
    [NotMapped]
    public static string[]? CatalogCode = Array.Empty<string>();
    [NotMapped]
    public static SortedDictionary<string, Unit> Basic = new();
    [NotMapped]
    public static SortedDictionary<string, Unit> Switch = new();  //TODO
    [NotMapped]
    public static SortedDictionary<string, Unit> Template = new(); //TODO
    [NotMapped]
    public static SortedDictionary<string, Unit> Catalog = new();  //TODO
    public Unit() { }
    static Unit() 
    {
        foreach (string bc in BasicCode)
        {
            Basic.Add(bc, new Unit { Code = bc });
        }
        foreach (string bc in CatalogCode)
        {
            Catalog.Add(bc, new Unit { Code = bc });
        }
    }
}
