﻿namespace BN;
[Serializable]
[Table("Face")]
public partial class Store : Face
{
    public Store() { }
    static Store()
    {
        Basic.Add("FA1.AdmStaff", Face.Basic[key: "FA1.AdmStaff"]);
        Basic.Add("FA1.Bank1", Face.Basic[key: "FA1.Bank1"]);
        Basic.Add("FA1.Cash1", Face.Basic[key: "FA1.Cash1"]);
        Basic.Add("FA1.Store1", Face.Basic[key: "FA1.Store1"]);
        Basic.Add("Face1.Bank1", Face.Basic[key: "Face1.Bank1"]);
        Basic.Add("Face1.Cash1", Face.Basic[key: "Face1.Cash1"]);
        Basic.Add("Face1.Store1", Face.Basic[key: "Face1.Store1"]);
        Basic.Add("GCVP-GFSS.Bank1", Face.Basic[key: "GCVP-GFSS.Bank1"]);
        Basic.Add("GCVP-OPV.Bank1", Face.Basic[key: "GCVP-OPV.Bank1"]);
        Basic.Add("GCVP-OSMS.Bank1", Face.Basic[key: "GCVP-OSMS.Bank1"]);
        Basic.Add("Sadvakasov.Bank1", Face.Basic[key: "Sadvakasov.Bank1"]);
        Basic.Add("UGD6202.Bank1", Face.Basic[key: "UGD6202.Bank1"]);
    }
}
