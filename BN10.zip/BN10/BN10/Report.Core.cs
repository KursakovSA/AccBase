﻿namespace BN;
[Serializable]
[Table("Report")]
public partial class Report : HeadClass
{
    public Report? Parent { get; set; }
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    [NotMapped]
    public static string[]? BasicCode = {
            "Report","Report.AccForm.Balance","Report.AccForm.BalanceTurnover","Report.AccForm.Detail","Report.AccForm.Sheet",
"Report.DepreciationForm","Report.DepreciationForm.Account","Report.DepreciationForm.Asset","Report.DocForm","Report.DocForm.BankStatement",
"Report.DocForm.CashBook","Report.DocForm.Entry","Report.DocForm.Imprest","Report.DocForm.InputCash","Report.DocForm.Invoice",
"Report.DocForm.Order","Report.DocForm.OutputCash","Report.DocForm.PayOrder","Report.DocForm.PaySheet","Report.DocForm.Purchase",
"Report.DocForm.Return","Report.DocForm.Revise","Report.DocForm.SalaryPaySheet","Report.DocForm.SalarySheet","Report.DocForm.Sell",
"Report.DocForm.TrafficOrder","Report.DocForm.Transfer","Report.DocForm.Warrant","Report.DocForm.WriteOff","Report.FinForm",
"Report.FinForm.Balance2019","Report.FinForm.Capital2019","Report.FinForm.Income2019","Report.FinForm.Money2019","Report.HRForm",
"Report.HRForm.Salary","Report.HRForm.Staff","Report.List","Report.Price","Report.Price.Asset.Deal",
"Report.Price.Asset.Unit","Report.Price.Face.Deal","Report.Price.Store","Report.SalaryInquery","Report.SalaryInquery.Staff",
"Report.SalaryInquery.Total","Report.SalarySummary","Report.SalarySummary.Staff","Report.SalarySummary.Total","Report.TaxForm",
"Report.TaxForm.100","Report.TaxForm.200","Report.TaxForm.300","Report.TaxForm.328","Report.TaxForm.910",
"Report.TaxForm.Registry",
        };
    [NotMapped]
    public static string[]? CatalogCode = Array.Empty<string>();
    [NotMapped]
    public static SortedDictionary<string, Report> Basic = new();
    [NotMapped]
    public static SortedDictionary<string, Report> Switch = new();  //TODO
    [NotMapped]
    public static SortedDictionary<string, Report> Template = new(); //TODO
    [NotMapped]
    public static SortedDictionary<string, Report> Catalog = new();  //TODO
    public Report() { }
    static Report() 
    {
        foreach (string bc in BasicCode)
        {
            Basic.Add(bc, new Report { Code = bc });
        }
        foreach (string bc in CatalogCode)
        {
            Catalog.Add(bc, new Report { Code = bc });
        }
    }
}
