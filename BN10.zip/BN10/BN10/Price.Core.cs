﻿namespace BN;
[Serializable]
public partial class Price : HeadClass
{
    private short id;
    public short Id
    {
        get => id;
        set => id = FixId(value);  //TEST
    }
    public Price? Parent { get; set; }
    private DateTime date1;
    public DateTime Date1
    {
        get => date1;
        set => date1 = FixDate1(value);  //TEST
    }
    public string? Date2 { get; set; }
    public string? Code { get; set; }
    public string? Description { get; set; }
    public string? More { get; set; }
    public Face? Face1 { get; set; }
    public Face? Face2 { get; set; }
    public Face? Face { get; set; }
    public Geo? Geo { get; set; }
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    public Unit? Unit { get; set; }
    public static SortedDictionary<string, Price>? Markup = new(); //TODO
    public static SortedDictionary<string, Price>? Sale = new(); //TODO
    public Price() { }
    public Price(short id = default,
                    DateTime? date1 = default,
                    string? date2 = default,
                    string? code = default,
                    string? description = default,
                    Role? role = default,
                    Info? info = default,
                    string? more = default)
    {
        Id = id;
        Date1 = DateTime.Today;//date1;
        Date2 = date2;
        Code = code;
        Description = description;
        More = more;
        Role = role;
        Info = info;
    }
    static Price()
    {
        //Markup.Add("Price.MarkupBasic", Price.Basic[key: "Price.MarkupBasic"]);
        //Sale.Add("Price.SaleBasic", Price.Basic[key: "Price.SaleBasic"]);
    }
    public short FixId(short inId = default)
    {
        short FixId = inId;
        if (FixId < 0)
        {
            FixId = 0;
        }

        TraceState(FixId, "Price.FixId(...), return ");
        return FixId;
    }
}
