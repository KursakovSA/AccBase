﻿namespace BN;
[Serializable]
[Table("Price")]
public partial class Price : HeadClass
{
    public Price? Parent { get; set; }
    public Face? Face1 { get; set; }
    public Face? Face2 { get; set; }
    public Face? Face { get; set; }
    public Geo? Geo { get; set; }
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    public Unit? Unit { get; set; }
    [NotMapped]
    public static SortedDictionary<string, Price> Basic = new();
    [NotMapped]
    public static SortedDictionary<string, Price> Switch = new();  //TODO
    [NotMapped]
    public static SortedDictionary<string, Price> Template = new(); //TODO
    [NotMapped]
    public static SortedDictionary<string, Markup>? Markup = new(); //TODO
    [NotMapped]
    public static SortedDictionary<string, Sale>? Sale = new(); //TODO
    public Price() { }
    public Price(int id = default,
                    DateTime? date1 = default,
                    string? date2 = default,
                    string? code = default,
                    string? description = default,
                    Role? role = default,
                    Info? info = default,
                    string? more = default)
    {
        Id = id;
        Date1 = DateTime.Today;//date1;
        Date2 = date2;
        Code = code;
        Description = description;
        More = more;
        Role = role;
        Info = info;
    }
    static Price()
    {
        string[] BasicCode =
        {
            "Price","Price.Basic","Price.MarkupBasic","Price.SaleBasic","Price.USD-KZT",
"Price6","Price.TariffPerOneHour","Price.TariffPerOneDay",
        };
        foreach (string bc in BasicCode)
        {
            Basic.Add(bc, new Price { Code = bc });
        }
    }
}
