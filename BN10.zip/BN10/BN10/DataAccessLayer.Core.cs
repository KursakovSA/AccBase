﻿namespace BN;
[Serializable]
public partial class DataAccessLayer
{
    public static SqlConnectionStringBuilder SqlConnStrBuild = new()
    {
        //DataSource = @".\SQLExpress",
        DataSource = @".\SQL2017", 
        InitialCatalog = "BaseN1",
        IntegratedSecurity = true,
        ConnectTimeout = 30,
    };
    public static SqlConnection SqlConn = new()
    {
        ConnectionString = SqlConnStrBuild.ConnectionString,
    };
    public static void OpenConn(SqlConnection conn)
    {
        try
        {
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }
        }
        catch (SqlException ex)
        {
            TraceState(ex.Message, "OpenConn(conn), catch exception : ");
        }

        TraceState(conn.State, "OpenConn(...), return ");
        return;
    }
    public static void CloseConn(SqlConnection conn)
    {
        try
        {
            if (conn.State != ConnectionState.Closed)
            {
                conn.Close();
            }
        }
        catch (SqlException ex)
        {
            CloseConn(SqlConn);
            TraceState(ex.Message, "CloseConn(conn), catch exception : ");
        }

        TraceState(conn.State, "CloseConn(...), return ");
        return;
    }
    public static string? BuildQuerySql(string? tableView, string? templateMore)
    {
        string? qrySql = "";
        if (tableView != null)
        {
            qrySql += "SELECT * FROM ";
            qrySql += "dbo.";
            qrySql += tableView.ToString();
            if (templateMore != null)
            {
                qrySql += " WHERE ";    ////TODO - сделать чтобы WHERE был только если есть хоть один отбор
                qrySql += "More LIKE ";
                qrySql += templateMore.ToString();
            }
        }

        TraceState(qrySql, "BuildQuerySql(...), return ");
        return qrySql;
    }
    public static SqlDataReader GetDataReader(string? tableView, string? templateMore)
    {
        SqlCommand sqlComm = new SqlCommand(BuildQuerySql(tableView, templateMore), SqlConn);
        OpenConn(SqlConn);
        SqlDataReader DataReader = sqlComm.ExecuteReader();

        TraceState(DataReader.FieldCount, "GetDataReader(...), return ");
        return DataReader;
    }
    public static List<Abc> GetAbc(string? tableView)
    {
        List<Abc> res = new();
        foreach (var mast in AbcKind)
        {
            string? templateMore = "'%" + mast.Value.ToString() + "%'";
            //выборка из БД элементов типа Basic, Catalog, Template и т.д. --- подключенный способ   
            using (SqlDataReader DataReader = GetDataReader(tableView, templateMore))
            {
                if (DataReader.HasRows)
                {
                    while (DataReader.Read())
                    {
                        //Console.WriteLine($"Id: {DataReader["Id"]}, Code: {DataReader["Code"]}, More: {DataReader["More"]}");
                        res.Add(new Abc { Id = (short)DataReader["Id"], Code = (string)DataReader["Code"], More = (string)DataReader["More"] });
                    }
                }
                DataReader.Close();
                CloseConn(SqlConn);
            }
        }
        #region отключенный способ не работает проба  
        ////выборка из БД элементов типа Basic, Catalog, Template и т.д. --- отключенный способ  
        //using (SqlConnection SqlConn = new SqlConnection(SqlConnStrBuild.ConnectionString))
        //{
        //    DataTable AccountTable = new();
        //    SqlCommand sqlComm = new SqlCommand(BuildQuerySql(tableView, templateMore));
        //    SqlDataAdapter dataAdapter = new(sqlComm);
        //    //DataSet ds = new DataSet();
        //    dataAdapter.Fill(AccountTable);
        //    //dataAdapter.Fill(ds);
        //    // перебор всех таблиц
        //    //foreach (DataTable dt in ds.Tables)
        //        //{
        //        //Console.WriteLine(dt.TableName); // название таблицы
        //                                         // перебор всех столбцов
        //        foreach (DataColumn column in AccountTable.Columns)
        //            Console.Write("\t{0}", column.ColumnName);
        //        Console.WriteLine();
        //        // перебор всех строк таблицы
        //        foreach (DataRow row in AccountTable.Rows)
        //        {
        //            // получаем все ячейки строки
        //            var cells = row.ItemArray;
        //            foreach (object? cell in cells)
        //                Console.Write("\t{0}", cell);
        //            Console.WriteLine();
        //        }
        //} 
        #endregion
        TraceState(res.Count, "GetABC(...), return ");
        return res;
    }
}
