﻿namespace BN;
[Serializable]
    public partial class Abc
    {
        public string? TableName { get; set; }
        public string? AbcKind { get; set; }
        public string? AbcName { get; set; }
        public short Id { get; set; }
        public string? Parent { get; set; }
        public string? Date1 { get; set; }
        public string? Date2 { get; set; }
        public string? Code { get; set; }
        public string? Description { get; set; }
        public string? More { get; set; }
        public Abc() { }
    public Abc(string? tableName = default,
               string? abcKind = default,
               string? abcName = default,
               short id = default,
               string? date1 = default,
               string? date2 = default,
               string? code = default,
               string? description = default,
               string? more = default)
    {
        TableName = tableName;
        AbcKind = abcKind;
        AbcName = abcName;
        Id = id;
        Code = code;
        Date1 = date1;
        Date2 = date2;
        Description = description;
        More = more;
    }
    static Abc() { }
        public HeadClass GetItem(Abc AbcItem)  //TODO - сделать получение элемента например Account по его данным в элементе ABC  
        {
            HeadClass HeadClassItem = new();
            return HeadClassItem;
        }
    public override string ToString()
    => $"{GetType()}, {Id.ToString() ?? "No Id"}, {Code ?? "No code"}, {Description ?? "No description"}, {More ?? "No More"}";
}
