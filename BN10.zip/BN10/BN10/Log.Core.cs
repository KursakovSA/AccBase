﻿namespace BN;
[Serializable]
[Table("Log")]
public partial class Log : HeadClass
{
    public Log? Parent { get; set; }
    public Face? Face1 { get; set; }
    public Face? Face2 { get; set; }
    public Face? Face { get; set; }
    public Slice? Slice { get; set; }
    public Geo? Geo { get; set; }
    public Sign? Sign { get; set; }
    public Account? Account { get; set; }
    public Log? Log1 { get; set; }
    public Process? Process1 { get; set; }
    public Tax? Tax { get; set; }
    public Item? Item { get; set; }
    public Deal? Deal { get; set; }
    public Price? Price { get; set; }
    public Asset? Asset { get; set; }
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    public Meter? Meter { get; set; }
    public string? MeterValue { get; set; }
    public Unit? Unit { get; set; }
    public Mark? Mark { get; set; }
    [NotMapped]
    public static string[]? BasicCode =  {
            "Log","Log.AT","Log.AT0.1","Log.AT1.1","Log.AT1.2",
"Log.AT1.3","Log.AT1.4","Log.AT2.1","Log.DailySalary","Log.DepreciationTax",
"Log.DepreciationTax.Group1.Rate","Log.DepreciationTax.Group2.Rate","Log.DepreciationTax.Group3.Rate","Log.DepreciationTax.Group4.Rate","Log.DT",
"Log.DT0","Log.DT0.KNP","Log.DT0.KNP","Log.DT0.KNP","Log.DT0.KNP",
"Log.DT1","Log.DT1.1","Log.ET","Log.ET0.1","Log.ET1.1",
"Log.ET1.2","Log.Face.KBE","Log.FT","Log.FT0.1","Log.FT1.1",
"Log.FT1.2","Log.FT1.3","Log.FT2.1","Log.FT2.2","Log.GFSS.MainRate",
"Log.IMT","Log.IMT0.1","Log.IMT1.1","Log.IncomePersonTax.RateMain","Log.IT",
"Log.IT0.1","Log.IT1.1","Log.IT1.2","Log.IT1.3","Log.IT2.1",
"Log.MainMarkup","Log.MainSale","Log.MT","Log.MT0.1","Log.MT1.1",
"Log.MT1.2","Log.OPV.RateMain","Log.OSMS.EmployePay.RateMain","Log.OSMS.EmployerFee.RateMain","Log.OT",
"Log.OT0.1","Log.OT1.1","Log.OT1.2","Log.OT1.3","Log.OT1.4",
"Log.OT2.1","Log.PT","Log.PT0.1","Log.PT1.1","Log.PT1.2",
"Log.PT1.3","Log.PT1.4","Log.PT2.1","Log.SN.MainRate","Log.ST",
"Log.ST0.1","Log.ST1.1","Log.ST1.2","Log.ST1.3","Log.ST1.4",
"Log.ST2.1","Log.ST2.4","Log.TaxBase.MaxLimit","Log.TaxBase.MaxLimit.GFSS","Log.TaxBase.MaxLimit.OPV",
"Log.TaxBase.MaxLimit.OSMS","Log.USD-KZT","Log.USD-KZT.halykbank","Log.VAT.Import.RateMain","Log.VAT.Purchase.RateMain",
"Log.VAT.Purchase.RateReduce","Log.VAT.Sell.MainRate","Log.VAT.Sell.RateReduce","Log.WorkDay-WorkHour","Log3",
"Log3.1","Log4","Log4.1","Log4.1.1","Log4.2",
"Log4.2.1","Log6",
        };
    [NotMapped]
    public static string[]? CatalogCode = Array.Empty<string>();
    [NotMapped]
    public static SortedDictionary<string, Log> Basic = new();
    [NotMapped]
    public static SortedDictionary<string, Log> Switch = new();  //TODO
    [NotMapped]
    public static SortedDictionary<string, Log> Template = new(); //TODO
    [NotMapped]
    public static SortedDictionary<string, Log> Catalog = new();  //TODO
    public Log() { }
    static Log()
    {
        foreach (string bc in BasicCode)
        {
            Basic.Add(bc, new Log { Code = bc });
        }
        foreach (string bc in CatalogCode)
        {
            Catalog.Add(bc, new Log { Code = bc });
        }
    }
    public static double? Turnover<Log>(List<Log> inLog)
    {
        double? outTurnover = default;
        return outTurnover;
    }
}
