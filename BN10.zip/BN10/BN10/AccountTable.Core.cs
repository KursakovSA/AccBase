﻿namespace BN;
[Serializable]
[Table("Account")]
public partial class AccountTable : Account
{
    [NotMapped]
    public SortedDictionary<Account, Account>? ClosingPlan { get; set; } //TODO - сделать заполнение
    [NotMapped]
    public SortedDictionary<Account, Account>? ConversionPlan { get; set; } //TODO - сделать заполнение
    [NotMapped]
    public static Account? PreviousAccTable;
    [NotMapped]
    public static Account? CurrentAccTable;
    [NotMapped]
    public static Account? FutureAccTable;
    public AccountTable(int id = default,
                    DateTime date1 = default,
                    string? date2 = default,
                    string? code = default,
                    string? description = default,
                    Slice? slice = default,
                    Role? role = default,
                    string? more = default)
    {
        Id = id;
        Date1 = DateTime.Today;//date1;
        Date2 = date2;
        Code = code;
        Description = description;
        More = more;
        Role = role;
        Slice = slice;
    }
    public AccountTable() { }
    static AccountTable()
    {
        Basic.Add("AccTable2019", Basic[key: "AccTable2019"]);
        Basic.Add("Work", Basic[key: "Work"]);
        CurrentAccTable = Basic[key: "AccTable2019"];
    }
    public void CloseAccTable(AccountTable ClosingAccTable) { }
    public void ConverseAccTable(AccountTable ConversionAccTable) { }
    public override string ToString()
    => $"{GetType()}, {Code}, {Description}, Slice={Slice?.Code}";
}
