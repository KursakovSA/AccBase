﻿namespace BN;
[Serializable]
[Table("Deal")]
public partial class Movement : Deal
{
    public Movement() { }
    public Movement(int id = default,
                    DateTime date1 = default,
                    string? date2 = default,
                    string? code = default,
                    string? description = default,
                    Role? role = default,
                    Info? info = default,
                    string? more = default)
    {
        Id = id;
        Date1 = DateTime.Today;//date1;
        Date2 = date2;
        Code = code;
        Description = description;
        More = more;
        Role = role;
        Info = info;
    }
    static Movement() { }
}

