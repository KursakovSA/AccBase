﻿namespace BN;
[Serializable]
public partial class Face : HeadClass
{
    private int id;
    public int Id
    {
        get => id;
        set => id = FixId(value);  //TEST
    }
    private DateTime date1;
    public DateTime Date1
    {
        get => date1;
        set => date1 = FixDate1(value);  //TEST
    }
    public string? Date2 { get; set; }
    public string? Code { get; set; }
    public string? Description { get; set; }
    public string? More { get; set; }
    public Face? Parent { get; set; }
    public Face? Face1 { get; set; }
    public Face? Face2 { get; set; }
    public Geo? Geo { get; set; }
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    public static SortedDictionary<string, Face> StoreBasic = new(); //TODO
    public SortedDictionary<string, Face> Store = new(); //TODO
    public static SortedDictionary<string, Face> UserBasic = new(); //TODO
    public static SortedDictionary<string, Face> DepartmentBasic = new(); //TODO
    public static SortedDictionary<string, Face> CashBasic = new(); //TODO
    public static SortedDictionary<string, Face> BankBasic = new(); //TODO
    public static SortedDictionary<string, Face> StaffTable = new();  //TODO
    public SortedDictionary<string, Face>? Staff = new();  //TODO
    public SortedDictionary<string, Workbook>? Address = new(); //TODO
    public static SortedDictionary<string, Info>? CodeEnterprise = new();  //TODO
    public static SortedDictionary<string, Info>? CodePerson = new();  //TODO
    public Workbook? TaxModeFace; //TODO
    public Face() { }
    static Face() { }
    public int FixId(int inId = default)  
    {
        int FixId = inId;
        if (FixId < 0)
        {
            FixId = 0;
        }

        TraceState(FixId, "Face.FixId(...), return ");
        return FixId;
    }
    public static Workbook? GetTaxModeFaceValue(DateTime Date1,
                                string? Date2,
                                Face? Face,
                                Tax? Tax) //TODO
    {
        Workbook? TaxModeFaceValue = default;

        TraceState(TaxModeFaceValue, "GetTaxModeFaceValue(...), return ");
        return TaxModeFaceValue;
    }
}
