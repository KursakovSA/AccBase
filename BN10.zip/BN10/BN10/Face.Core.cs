﻿namespace BN;
[Serializable]
[Table("Face")]
public partial class Face : HeadClass
{
    public Face? Parent { get; set; }
    public Face? Face1 { get; set; }
    public Face? Face2 { get; set; }
    public Geo? Geo { get; set; }
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    [NotMapped]
    public static SortedDictionary<string, Face> StoreBasic = new(); //TODO
    [NotMapped]
    public SortedDictionary<string, Face> Store = new(); //TODO
    [NotMapped]
    public static SortedDictionary<string, Face> UserBasic = new(); //TODO
    [NotMapped]
    public static SortedDictionary<string, Face> DepartmentBasic = new(); //TODO
    [NotMapped]
    public static SortedDictionary<string, Face> CashBasic = new(); //TODO
    [NotMapped]
    public static SortedDictionary<string, Face> BankBasic = new(); //TODO
    [NotMapped]
    public static SortedDictionary<string, Face> StaffTable = new();  //TODO
    [NotMapped]
    public SortedDictionary<string, Face>? Staff = new();  //TODO
    [NotMapped]
    public SortedDictionary<string, Log>? Address = new(); //TODO
    [NotMapped]
    public static SortedDictionary<string, Info>? CodeEnterprise = new();  //TODO
    [NotMapped]
    public static SortedDictionary<string, Info>? CodePerson = new();  //TODO
    [NotMapped]
    public static string[]? BasicCode = {
            "enbek","FA1","FA1.AdmStaff","FA1.Bank1","FA1.Cash1",
"FA1.StaffTable","FA1.StaffTable.Boss","FA1.StaffTable.ChiefAccountant","FA1.Store1","FA1.User1",
"Face","Face.Template1","Face.Template2","Face.Template3","Face1",
"Face1.Abishev","Face1.Bank1","Face1.Cash1","Face1.Store1","GCVP",
"GCVP-GFSS.Bank1","GCVP-OPV.Bank1","GCVP-OSMS.Bank1","halykbank","kgd",
"kgd.ugd6202","Sadvakasov","Sadvakasov.Bank1","UGD6202.Bank1",
        };
    [NotMapped]
    public static string[]? CatalogCode = Array.Empty<string>();
    [NotMapped]
    public static SortedDictionary<string, Face> Basic = new();
    [NotMapped]
    public static SortedDictionary<string, Face> Switch = new();  //TODO
    [NotMapped]
    public static SortedDictionary<string, Face> Template = new(); //TODO
    [NotMapped]
    public static SortedDictionary<string, Face> Catalog = new();  //TODO
    [NotMapped]
    public Log? TaxModeFace; //TODO
    public Face() { }
    static Face()
    {
        //basic face
        foreach (string bc in BasicCode)
        {
            Basic.Add(bc, new Face { Code = bc });
        }
        foreach (string bc in CatalogCode)
        {
            Catalog.Add(bc, new Face { Code = bc });
        }
        //template
        Template.Add("Face.Template1", Face.Basic[key: "Face.Template1"]);
        Template.Add("Face.Template2", Face.Basic[key: "Face.Template2"]);
        Template.Add("Face.Template3", Face.Basic[key: "Face.Template3"]);
        //store
        StoreBasic.Add("FA1.AdmStaff", Face.Basic[key: "FA1.AdmStaff"]);
        StoreBasic.Add("FA1.Bank1", Face.Basic[key: "FA1.Bank1"]);
        StoreBasic.Add("FA1.Cash1", Face.Basic[key: "FA1.Cash1"]);
        StoreBasic.Add("FA1.Store1", Face.Basic[key: "FA1.Store1"]);
        StoreBasic.Add("Face1.Bank1", Face.Basic[key: "Face1.Bank1"]);
        StoreBasic.Add("Face1.Cash1", Face.Basic[key: "Face1.Cash1"]);
        StoreBasic.Add("Face1.Store1", Face.Basic[key: "Face1.Store1"]);
        StoreBasic.Add("GCVP-GFSS.Bank1", Face.Basic[key: "GCVP-GFSS.Bank1"]);
        StoreBasic.Add("GCVP-OPV.Bank1", Face.Basic[key: "GCVP-OPV.Bank1"]);
        StoreBasic.Add("GCVP-OSMS.Bank1", Face.Basic[key: "GCVP-OSMS.Bank1"]);
        StoreBasic.Add("Sadvakasov.Bank1", Face.Basic[key: "Sadvakasov.Bank1"]);
        StoreBasic.Add("UGD6202.Bank1", Face.Basic[key: "UGD6202.Bank1"]);
        //user
        UserBasic.Add("FA1.User1", Face.Basic[key: "FA1.User1"]);
    }
    public static Log? GetTaxModeFaceValue(DateTime Date1,
                                string? Date2,
                                Face? Face,
                                Tax? Tax) //TODO
    {
        Log? TaxModeFaceValue = default;
        return TaxModeFaceValue;
    }
}
