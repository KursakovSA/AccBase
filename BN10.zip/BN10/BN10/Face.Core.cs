﻿namespace BN;
[Serializable]
[Table("Face")]
public partial class Face : HeadClass
{
    public Face? Parent { get; set; }
    public Face? Face1 { get; set; }
    public Face? Face2 { get; set; }
    public Geo? Geo { get; set; }
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    [NotMapped]
    public SortedDictionary<string, Store>? Store = new(); //TODO
    [NotMapped]
    public SortedDictionary<string, User>? User = new(); //TODO
    [NotMapped]
    public SortedDictionary<string, Store>? Department = new(); //TODO
    [NotMapped]
    public SortedDictionary<string, Store>? Cash = new(); //TODO
    [NotMapped]
    public SortedDictionary<string, Store>? Bank = new(); //TODO
    [NotMapped]
    public SortedDictionary<string, StaffTable>? StaffTable = new();  //TODO
    [NotMapped]
    public SortedDictionary<string, Log>? Address = new(); //TODO
    [NotMapped]
    public static SortedDictionary<string, Info>? CodeEnterprise = new();  //TODO
    [NotMapped]
    public static SortedDictionary<string, Info>? CodePerson = new();  //TODO
    [NotMapped]
    public static SortedDictionary<string, Face> Basic = new();
    [NotMapped]
    public static SortedDictionary<string, Face> Switch = new();  //TODO
    [NotMapped]
    public static SortedDictionary<string, Face> Template = new(); //TODO
    [NotMapped]
    public Log? TaxModeFace; //TODO
    public Face() { }
    static Face()
    {
        //basic face
        string[] BasicCode =
        #region basic
		{
            "enbek","FA1","FA1.AdmStaff","FA1.Bank1","FA1.Cash1",
"FA1.StaffTable","FA1.StaffTable.Boss","FA1.StaffTable.ChiefAccountant","FA1.Store1","FA1.User1",
"Face","Face.Template1","Face.Template2","Face.Template3","Face1",
"Face1.Abishev","Face1.Bank1","Face1.Cash1","Face1.Store1","GCVP",
"GCVP-GFSS.Bank1","GCVP-OPV.Bank1","GCVP-OSMS.Bank1","halykbank","kgd",
"kgd.ugd6202","Sadvakasov","Sadvakasov.Bank1","UGD6202.Bank1",
        }; 
        #endregion
        foreach (string bc in BasicCode)
        {
            Basic.Add(bc, new Face { Code = bc });
        }
        //template
        Template.Add("Face.Template1", Face.Basic[key: "Face.Template1"]);
        Template.Add("Face.Template2", Face.Basic[key: "Face.Template2"]);
        Template.Add("Face.Template3", Face.Basic[key: "Face.Template3"]);
    }
    public Log? GetTaxModeFaceValue(DateTime Date1,
                                string? Date2,
                                Face? Face,
                                Tax? Tax) //TODO
    {
        Log? TaxModeFaceValue = default;
        return TaxModeFaceValue;
    }
}
