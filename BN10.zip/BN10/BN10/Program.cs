﻿global using BN;
//global using BN10;
global using System;
global using System.Collections.Generic;
global using System.Text;
global using static BN.Util;
global using static BN.DataAccessLayer;
global using System.Data;
global using System.Data.SqlClient;
global using System.Linq;
namespace BN;
class Program
{
    static void Main(string[] args)
    {
        OnStartApp();
        try
        {
            //Trace.WriteLine(Process.Basic["PettyCash.4 (ReturnCash)"], "Main, Process.Basic[PettyCash.4 (ReturnCash)] : ");
            //TraceState(Process.Basic["PettyCash.4 (ReturnCash)"], "Main, Process.Basic[PettyCash.4 (ReturnCash)] : ");
            //TraceState(Asset.Basic["FNO100.FixedAsset.Group1"], "Main, Catalog.Basic[FNO100.FixedAsset.Group1] : ");
            //TraceState(Item.Basic["Item.Advance"], "Main, Item.Basic[Item.Advance] : ");
            //TraceState(Price.Basic["Price.TariffPerOneHour"], "Main, Price.Basic[Price.TariffPerOneHour] : ");
            //TraceState(Slice.Basic["Norm"], "Main, Slice.Basic[Norm] : ");
            //TraceState(Mark.Basic["DD"], "Main, Mark.Basic[DD] : ");
            //TraceState(Deal.Basic["Deal.enbek.staff"], "Main, Deal.Basic[Deal.enbek.staff] : ");

            List<Abc> AbcModel = GetAbc("AccountList");
            TraceState(AbcModel.Count, "Program(...), AbcModel ");

            //HeadClass.GetPrice();

            //TraceState(Exchange.Basic["Role.Exchange.SwiftOPV"], "Exchange.Basic[Role.Exchange.SwiftOPV]");
            //Exchange? exc = new();
            //TraceState(exc, "Exchange.exc");
            //StringBuilder sb = new();
            //sb = exc.SwiftOPV(null);
        }
        catch (Exception ex)
        {
            TraceState(ex.Message, "Program(...), catch ");
        }
        finally { }

        OnExitApp();
    }
    public static void OnStartApp()
    {
        IsDev = true;    ////закомментировать, если это не так  
        TraceState(IsDev, "Main, OnStartApp(), IsDev = ");
    }
    public static void OnExitApp()
    {
        if (IsDev == true)
        {
            Console.WriteLine(TraceLog);
            Console.ReadLine();
        }
        TraceState(IsDev, "Main, OnExitApp(), IsDev = ");
    }
}

