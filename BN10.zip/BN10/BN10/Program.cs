﻿global using System;
global using System.Collections.Generic;
global using System.Text;
global using System.ComponentModel.DataAnnotations.Schema;
global using static BN.Util;
namespace BN;
class Program
{
    [STAThread]
    static void Main(string[] args)
    {
        OnStartApp();
        //Trace.WriteLine(Process.Basic["PettyCash.4 (ReturnCash)"], "Main, Process.Basic[PettyCash.4 (ReturnCash)] : ");
        //TraceState(Process.Basic["PettyCash.4 (ReturnCash)"], "Main, Process.Basic[PettyCash.4 (ReturnCash)] : ");
        //TraceState(AssetCatalog.Basic["FNO100.FixedAsset.Group1"], "Main, Catalog.Basic[FNO100.FixedAsset.Group1] : ");
        //TraceState(Item.Basic["Item.Advance"], "Main, Item.Basic[Item.Advance] : ");
        //TraceState(Price.Basic["Price.TariffPerOneHour"], "Main, Price.Basic[Price.TariffPerOneHour] : ");
        //TraceState(Slice.Basic["Norm"], "Main, Slice.Basic[Norm] : ");
        //TraceState(Mark.Basic["DD"], "Main, Mark.Basic[DD] : ");

        TraceState(Exchange.Basic[key: "Role.ExchangeData.SwiftOPV"], "Exchange.Basic[Role.ExchangeData.SwiftOPV]");
        //ExchangeData.SwiftOPV(null);

        OnExitApp();
    }
    public static void OnStartApp()
    {
        IsDev = true;    ////закомментировать, если это не так  
        TraceState(IsDev, "Main, UtilClass.IsDev");
    }
    public static void OnExitApp()
    {
        if (IsDev == true)
        {
            Console.WriteLine(LogConsole);
            Console.ReadLine();
        }
    }
}

