﻿global using System;
global using System.Collections.Generic;
global using System.Text;
global using System.ComponentModel.DataAnnotations.Schema;
global using static BN.Util;
namespace BN;
class Program
{
    static void Main(string[] args)
    {
        OnStartApp();
        try
        {
            //Trace.WriteLine(Process.Basic["PettyCash.4 (ReturnCash)"], "Main, Process.Basic[PettyCash.4 (ReturnCash)] : ");
            //TraceState(Process.Basic["PettyCash.4 (ReturnCash)"], "Main, Process.Basic[PettyCash.4 (ReturnCash)] : ");
            TraceState(Asset.Basic["FNO100.FixedAsset.Group1"], "Main, Catalog.Basic[FNO100.FixedAsset.Group1] : ");
            //TraceState(Item.Basic["Item.Advance"], "Main, Item.Basic[Item.Advance] : ");
            //TraceState(Price.Basic["Price.TariffPerOneHour"], "Main, Price.Basic[Price.TariffPerOneHour] : ");
            //TraceState(Slice.Basic["Norm"], "Main, Slice.Basic[Norm] : ");
            //TraceState(Mark.Basic["DD"], "Main, Mark.Basic[DD] : ");
            TraceState(Deal.Basic["Deal.enbek.staff"], "Main, Deal.Basic[Deal.enbek.staff] : ");

            //Account acc = new();
            //TraceState(acc, "Program(), Account acc : ");

            //HeadClass.GetPrice();

            //TraceState(Exchange.Basic["Role.Exchange.SwiftOPV"], "Exchange.Basic[Role.Exchange.SwiftOPV]");
            //Exchange? exc = new();
            //TraceState(exc, "Exchange.exc");
            //StringBuilder sb = new();
            //sb = exc.SwiftOPV(null);
        }
        catch (Exception ex)
        {
            Console.WriteLine("catch exception message = " + ex.Message);
        }
        finally { }

        OnExitApp();
    }
    public static void OnStartApp()
    {
        IsDev = true;    ////закомментировать, если это не так  
        TraceState(IsDev, "Main, UtilClass.IsDev");
    }
    public static void OnExitApp()
    {
        if (IsDev == true)
        {
            Console.WriteLine(TraceLog);
            Console.ReadLine();
        }
    }
}

