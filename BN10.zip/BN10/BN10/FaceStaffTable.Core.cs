﻿namespace BN;
[Serializable]
[Table("Face")]
public partial class StaffTable : Face
{
    public SortedDictionary<string, Face>? Staff = new();  //TODO
    public StaffTable() { }
    static StaffTable()
    {
        Basic.Add("FA1.AdmStaff", Face.Basic[key: "FA1.AdmStaff"]);
        Basic.Add("FA1.StaffTable", Face.Basic[key: "FA1.StaffTable"]);
        Basic.Add("FA1.StaffTable.Boss", Face.Basic[key: "FA1.StaffTable.Boss"]);
        Basic.Add("FA1.StaffTable.ChiefAccountant", Face.Basic[key: "FA1.StaffTable.ChiefAccountant"]);
        Basic.Add("Face1.Abishev", Face.Basic[key: "Face1.Abishev"]);
    }
}
