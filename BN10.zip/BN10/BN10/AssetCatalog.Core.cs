﻿namespace BN;
[Serializable]
[Table("Asset")]
public partial class AssetCatalog : Asset
{
    public AssetCatalog() { }
    static AssetCatalog()
    {
        string[] BasicCode =
        {
            "FNO100.FixedAsset", "FNO100.FixedAsset.Group1", "FNO100.FixedAsset.Group2",
            "FNO100.FixedAsset.Group3", "FNO100.FixedAsset.Group4",
        };
        foreach (string bc in BasicCode)
        {
            Basic.Add(bc, new AssetCatalog { Code = bc });
        }
    }
}
