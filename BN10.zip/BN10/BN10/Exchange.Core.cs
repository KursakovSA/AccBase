﻿namespace BN;
[Serializable]
[NotMapped]
public partial class Exchange : Role
{
    [NotMapped]
    public static string? TargetPath;
    [NotMapped]
    public string? TargetFile;
    public Exchange() { }
    static Exchange()
    {
        //TargetPath = @"C:\";
        TargetPath = AppDirectory;
        Geo? Geo = new Geo { Id = 0, Code = "Geo.Qazaqstan", Description = "РК" };
        //Basic.Add("Role.ExchangeData.EsfXML", Basic[key: "Role.ExchangeData.EsfXML"]);
        //Basic.Add("Role.ExchangeData.MT100", Basic[key: "Role.ExchangeData.MT100"]);
        //Basic.Add("Role.ExchangeData.MT102", Basic[key: "Role.ExchangeData.MT102"]);
        //Basic.Add("Role.ExchangeData.SwiftGFSS", Basic[key: "Role.ExchangeData.SwiftGFSS"]);
        //Basic.Add("Role.ExchangeData.SwiftOPV", Basic[key: "Role.ExchangeData.SwiftOPV"]);
        //Basic.Add("Role.ExchangeData.SwiftOSMS", Basic[key: "Role.ExchangeData.SwiftOSMS"]);
        //Basic.Add("Role.ExchangeData.Tax100 - 01", Basic[key: "Role.ExchangeData.Tax100 - 01"]);
    }
    public static StringBuilder SwiftOPV(Log? LogSalary)
    {
        Exchange SwiftOPV = (Exchange)Basic[key: "Role.ExchangeData.SwiftOPV"];
        SwiftOPV.TargetFile = @"Swift_OPV.txt";
        //ObjToConsole(SwiftOPV, "SwiftOPV, SwiftOPV : ");
        StringBuilder TextSwiftOPV = new();
        //TODO - выгрузка свифт файла для ОПВ
        return TextSwiftOPV;
    }
}
