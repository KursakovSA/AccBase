﻿namespace BN;
[Serializable]
public partial class Exchange : HeadClass
{
    private byte id;
    public byte Id
    {
        get => id;
        set => id = FixId(value);  //TEST
    }
    private DateTime date1;
    public DateTime Date1
    {
        get => date1;
        set => date1 = FixDate1(value);  //TEST
    }
    public string? Date2 { get; set; }
    public string? Code { get; set; }
    public string? Description { get; set; }
    public string? More { get; set; }
    public Role? Role { get; set; }
    public string? TargetPath;
    public string? TargetFile;
    public string? TargetExchange;
    public Exchange() { }
    public Exchange(byte id = default,
                   DateTime date1 = default,
                   string? date2 = default,
                   string? code = default,
                   string? description = default,
                   string? more = default)
    {
        Id = id;
        Code = code;
        Date1 = DateTime.Today;//date1;
        Date2 = date2;
        Description = description;
        More = more;
        TargetPath = StartDirectory;
    }
    static Exchange() { }
    public StringBuilder SwiftOPV(Workbook? WorkbookSalary = default)
    {
        StringBuilder TextSwift = new();
        //Exchange SwiftOPV = Basic[key: "Role.Exchange.SwiftOPV"];
        //SwiftOPV.TargetFile = @"Swift_OPV.txt";
        //SwiftOPV.TargetExchange = GetTargetExchangeValue(TargetPath, TargetFile);
        //TODO - выгрузка свифт файла для ОПВ
        
        TraceState(TextSwift, "SwiftOPV(...), return ");
        return TextSwift;
    }
    public static string GetTargetExchangeValue(string? inTargetPath, string? inTargetFile)
    {
        string? TargetExchangeValue = inTargetPath + "\\" + inTargetFile;
        if (TargetExchangeValue == null)
        {
            TargetExchangeValue = "GetTargetExchangeValue.No TargetExchangeValue";
        }
        
        TraceState(TargetExchangeValue, "GetTargetExchangeValue(...), return ");
        return TargetExchangeValue;
    }
    public byte FixId(byte inId = default)
    {
        byte FixId = inId;
        if (FixId < 0)
        {
            FixId = 0;
        }

        TraceState(FixId, "Exchange.FixId(...), return ");
        return FixId;
    }
}
