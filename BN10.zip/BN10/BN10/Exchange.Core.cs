﻿namespace BN;
[Serializable]
[NotMapped]
public partial class Exchange : HeadClass
{
    public Role? Role { get; set; }
    public string? TargetPath;
    public string? TargetFile;
    public string? TargetExchange;
    public static string[]? BasicCode = {
            "Role.Exchange.EsfXML","Role.Exchange.MT100","Role.Exchange.MT102",
"Role.Exchange.SwiftGFSS","Role.Exchange.SwiftOPV","Role.Exchange.SwiftOSMS","Role.Exchange.Tax100-01",
        };
    public static string[]? CatalogCode = Array.Empty<string>();
    public static SortedDictionary<string, Exchange> Basic = new();
    public static SortedDictionary<string, Exchange> Switch = new();  //TODO
    public static SortedDictionary<string, Exchange> Template = new(); //TODO
    public static SortedDictionary<string, Exchange> Catalog = new();  //TODO
    public Exchange() { }
    public Exchange(int id = default,
                   DateTime date1 = default,
                   string? date2 = default,
                   string? code = default,
                   string? description = default,
                   string? more = default)
    {
        Id = id;
        Code = code;
        Date1 = DateTime.Today;//date1;
        Date2 = date2;
        Description = description;
        More = more;
        TargetPath = AppDirectory;
    }
    static Exchange()
    {
        //Geo? Geo = new Geo { Id = 0, Code = "Geo.Qazaqstan", Description = "РК" };
        foreach (string bc in BasicCode)
        {
            Basic.Add(bc, new Exchange { Code = bc });
        }
        foreach (string bc in CatalogCode)
        {
            Catalog.Add(bc, new Exchange { Code = bc });
        }
    }
    public StringBuilder SwiftOPV(Log? LogSalary = default)
    {
        StringBuilder TextSwift = new();
        Exchange SwiftOPV = Basic[key: "Role.Exchange.SwiftOPV"];
        SwiftOPV.TargetFile = @"Swift_OPV.txt";
        SwiftOPV.TargetExchange = GetTargetExchangeValue(TargetPath, TargetFile);
        //TODO - выгрузка свифт файла для ОПВ
        TraceState(TextSwift, "SwiftOPV(LogSalary), return : ");
        return TextSwift;
    }
    public static string GetTargetExchangeValue(string? inTargetPath, string? inTargetFile)
    {
        string? TargetExchangeValue = inTargetPath + "\\" + inTargetFile;
        if (TargetExchangeValue == null)
        {
            TargetExchangeValue = "GetTargetExchangeValue.No TargetExchangeValue";
        }
        TraceState(TargetExchangeValue, "GetTargetExchangeValue(inTargetPath, inTargetFile), return : ");
        return TargetExchangeValue;
    }
}
