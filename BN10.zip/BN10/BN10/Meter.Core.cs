﻿namespace BN;
[Serializable]
[Table("Meter")]
public partial class Meter : HeadClass
{
    public Meter? Parent { get; set; }
    public Unit? Unit { get; set; }
    [NotMapped]
    public static SortedDictionary<string, Meter> Basic = new();
    [NotMapped]
    public static SortedDictionary<string, Meter> Switch = new();  //TODO
    [NotMapped]
    public static SortedDictionary<string, Meter> Template = new(); //TODO
    public Meter() { }
    static Meter()
    {
        string[] BasicCode =
        {
            "Amount","Authentication","Cost","Counter","Depth",
"Diameter","Height","Length","Linear weight 1m","Meter",
"Number pieces pack","Price","Quantity","Rate","Rating",
"Time","Volume","Weight","Width",
        };
        foreach (string bc in BasicCode)
        {
            Basic.Add(bc, new Meter { Code = bc });
        }
    }
}
