﻿namespace BN;
[Serializable]
[Table("Meter")]
public partial class Meter : HeadClass
{
    public Meter? Parent { get; set; }
    public Unit? Unit { get; set; }
    [NotMapped]
    public static string[]? BasicCode = {
            "Amount","Authentication","Cost","Counter","Depth",
"Diameter","Height","Length","Linear weight 1m","Meter",
"Number pieces pack","Price","Quantity","Rate","Rating",
"Time","Volume","Weight","Width",
        };
    [NotMapped]
    public static string[]? CatalogCode = Array.Empty<string>();
    [NotMapped]
    public static SortedDictionary<string, Meter> Basic = new();
    [NotMapped]
    public static SortedDictionary<string, Meter> Switch = new();  //TODO
    [NotMapped]
    public static SortedDictionary<string, Meter> Template = new(); //TODO
    [NotMapped]
    public static SortedDictionary<string, Meter> Catalog = new();  //TODO
    public Meter() { }
    static Meter()
    {
        foreach (string bc in BasicCode)
        {
            Basic.Add(bc, new Meter { Code = bc });
        }
        foreach (string bc in CatalogCode)
        {
            Catalog.Add(bc, new Meter { Code = bc });
        }
    }
}
