﻿namespace BN;
[Serializable]
public partial class Meter : HeadClass
{
    private short id;
    public short Id
    {
        get => id;
        set => id = FixId(value);  //TEST
    }
    public Meter? Parent { get; set; }
    private DateTime date1;
    public DateTime Date1
    {
        get => date1;
        set => date1 = FixDate1(value);  //TEST
    }
    public string? Date2 { get; set; }
    public string? Code { get; set; }
    public string? Description { get; set; }
    public string? More { get; set; }
    public Unit? Unit { get; set; }
    public Meter() { }
    static Meter() { }
    public short FixId(short inId = default)
    {
        short FixId = inId;
        if (FixId < 0)
        {
            FixId = 0;
        }

        TraceState(FixId, "Meter.FixId(...), return ");
        return FixId;
    }
}
