﻿namespace BN;
[Serializable]
[Table("Price")]
public partial class Sale : Price
{
    public Sale() { }
    static Sale()
    {
        Basic.Add("Price.SaleBasic", Price.Basic[key: "Price.SaleBasic"]);
    }
}
