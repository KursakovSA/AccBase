﻿namespace BN
{
    [Serializable]
    [Table("Account")]
    public partial class AccountCatalog : Account
    {
        public AccountCatalog() { }
        static AccountCatalog()
        {
            string[] BasicCode =
        {
            "Asset","AssetBio","AssetCoverall","AssetGood","AssetIntangible",
"AssetMaterial","AssetMortgage","AssetProduction","AssetTool","AssetUnfinishedProduction",
"Customer","CustomerPrepaid","Equity","Expense","ExpenseCost",
"ExpenseGeneral","ExpenseOther","ExpenseSell","ExpenseSellOut","FixedAsset",
"FixedAssetBuilding","FixedAssetCar","FixedAssetDepreciation","FixedAssetFurniture","FixedAssetLand",
"FixedAssetMachine","FixedAssetOfficeEquipment","FixedAssetOther","FixedAssetUnfinishedConstruction","Imprest",
"Income","IncomeLossNet","IncomeOther","IncomeSell","IncomeSellOut",
"Money","MoneyBank","MoneyCash","MoneyTransit","Salary",
"SalaryDeduction","Seller","SellerPrepaid","Tax","TaxAlimony",
"TaxCar","TaxExcise","TaxGFSS","TaxIncome","TaxIncomePerson",
"TaxLand","TaxOSMSEmployeeFee","TaxOSMSEmployeePay","TaxOther","TaxPension",
"TaxProperty","TaxSN","TaxVATIn","TaxVATOut",
        };
            foreach (string bc in BasicCode)
            {
                Basic.Add(bc, new Account { Code = bc });
            }
        }
        public override string ToString()
        => $"{GetType()}, {Code}, {Description ?? ""}, {AccountTable?.Description}";
    }
}
