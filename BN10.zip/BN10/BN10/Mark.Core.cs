﻿namespace BN;
[Serializable]
[Table("Mark")]
public partial class Mark : HeadClass
{
    public Mark? Parent { get; set; }
    public Role? Role { get; set; }
    [NotMapped]
    public static SortedDictionary<string, Mark> Basic = new();
    [NotMapped]
    public static SortedDictionary<string, Mark> Switch = new();  //TODO
    [NotMapped]
    public static SortedDictionary<string, Mark> Template = new(); //TODO
    public Mark() { }
    static Mark()
    {
        //basic
        string[] BasicCode1 =
        {
            "ArcD","CD","DD","DelD","ExD",
"ExtD","ToArcD","ToCD","ToDD","ToDelD",
"MD","RuleD","TemplD","TrnD",

        };
        foreach (string bc in BasicCode1)
        {
            Basic.Add(bc, new Mark { Code = bc });
        }
        //switch 
        Switch.Add("ToArcD", Mark.Basic[key: "ToArcD"]);
        Switch.Add("ToCD", Mark.Basic[key: "ToCD"]);
        Switch.Add("ToDD", Mark.Basic[key: "ToDD"]);
        Switch.Add("ToDelD", Mark.Basic[key: "ToDelD"]);
    }
}
