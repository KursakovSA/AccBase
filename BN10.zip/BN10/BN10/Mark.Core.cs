﻿namespace BN;
[Serializable]
public partial class Mark : HeadClass
{
    private byte id;
    public byte Id
    {
        get => id;
        set => id = FixId(value);  //TEST
    }
    public Mark? Parent { get; set; }
    private DateTime date1;
    public DateTime Date1
    {
        get => date1;
        set => date1 = FixDate1(value);  //TEST
    }
    public string? Date2 { get; set; }
    public string? Code { get; set; }
    public string? Description { get; set; }
    public string? More { get; set; }
    public Role? Role { get; set; }
//    public static string[]? BasicCode = {
//            "ArcD","CD","DD","DelD","ExD",
//"ExtD","ToArcD","ToCD","ToDD","ToDelD",
//"MD","RuleD","TemplD","TrnD",
//        };
    public static SortedDictionary<string, Mark> Basic = new();
    public static SortedDictionary<string, Mark> Switch = new();  //TODO
    public static SortedDictionary<string, Mark> Template = new(); //TODO
    public static SortedDictionary<string, Mark> Catalog = new();  //TODO
    public Mark() { }
    static Mark()
    {
        //foreach (string bc in BasicCode)
        //{
        //    Basic.Add(bc, new Mark { Code = bc });
        //}
        //foreach (string bc in CatalogCode)
        //{
        //    Catalog.Add(bc, new Mark { Code = bc });
        //}
        ////switch 
        //Switch.Add("ToArcD", Mark.Basic[key: "ToArcD"]);
        //Switch.Add("ToCD", Mark.Basic[key: "ToCD"]);
        //Switch.Add("ToDD", Mark.Basic[key: "ToDD"]);
        //Switch.Add("ToDelD", Mark.Basic[key: "ToDelD"]);
    }
    public byte FixId(byte inId = default)
    {
        byte FixId = inId;
        if (FixId < 0)
        {
            FixId = 0;
        }

        TraceState(FixId, "Mark.FixId(...), return ");
        return FixId;
    }
}
