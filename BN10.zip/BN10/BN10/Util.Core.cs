﻿namespace BN;
[Serializable]
public partial class Util
{
    //public static void FixObj(HeadClass checkObj, out HeadClass fixObj)   //исправляем строки объектов, самые распространенные ошибки
    //{                                                  //чтобы не звонили по каждой мелочи 300 раз !!!!
    //    HeadClass fixObj.Code = checkObj.Code.Trim();   //самое первое - удаляем пробелы начальные и конечные   
    //}
    public static bool? IsDev = false;
    public static string? LogConsole;
    public static SortedDictionary<string, string>? ListBase = new()
    {
        ["BaseN1"] = @"SQLEXPRESS\BaseN1",
        ["BaseN2"] = @"SQLEXPRESS\BaseN2",
        ["BaseN3"] = @"SQLEXPRESS\BaseN3",
    };
    public static Dictionary<string, string>? PartTab = new()
    {
        ["SelectBase"] = "",
        ["Dialog"] = "",
        ["Tree"] = "",
        ["Main"] = "",
        ["SelectChangeMark"] = "",
        ["SelectChangeSlice"] = "",
        ["Validation"] = "",
        ["Filter"] = "",
    };
    public static Dictionary<string, string>? Tab = new()
    {
        ["List"] = "List",
        ["Detail"] = "Detail",
        ["Edit"] = "Edit",
        ["New"] = "New",
        ["Console"] = "Console",
    };
    public static Dictionary<string, string>? EditableTable = new()
    {
        ["Geo"] = "Geo",
        ["Log"] = "Log",
        ["Face"] = "Face",
        ["Deal"] = "Deal",
        ["Asset"] = "Asset",
        ["Price"] = "Price",
    };
    public static string? AppDirectory;
    public static string? AppStartDirectory;
    public static string? AppLastSaveDirectory;
    public static string? AppLastSelectFileDirectory;
    public static void TraceState(object Obj, string? ContextObj)
    {
        //if ((IsDev) && (Obj != null))
        //{
            //string? tempstr = ContextObj + " == " + Obj.ToString() + Environment.NewLine;
            //LogConsole += tempstr;
        LogConsole += ContextObj + " == " + Obj.ToString() + Environment.NewLine;
        //}
    }
    //public static string StrListObj<T>(List<T> ListObj)
    //{
    //    string? outListObj = default;
    //    foreach (T obj in ListObj)
    //    {
    //        //TODO - сделать сериализацию реквизитов obj
    //        if (obj != null)
    //        {
    //            outListObj += obj.ToString();  //TODO - сделать добавление разделителя строк
    //        }
    //    }
    //    return outListObj;
    //}
    public Util() { }
    static Util() { }
}

