﻿namespace BN;
[Serializable]
public partial class Util
{
    public static bool IsDev = false;
    public static StringBuilder TraceLog = new StringBuilder("TraceLog" + Environment.NewLine);
    public static SortedDictionary<string, string> AbcKind = new()
    {
        ["Basic"] = "Basic",
        ["Catalog"] = "Catalog",
        ["CodePay"] = "CodePay",
        ["Switch"] = "Switch",
        ["Table"] = "Table",
        ["Template"] = "Template",
    };
    public static SortedDictionary<string, string>? DataSource = new()
    {
        ["SQL2017"] = @"SQL2017",
        ["SQLExpress"] = @"SQLExpress",
        ["(local)"] = @"(local)",
    };
    public static SortedDictionary<string, string>? AppBase = new()
    {
        ["BaseN1"] = @"BaseN1",
        ["BaseN2"] = @"BaseN2",
        ["BaseN3"] = @"BaseN3",
    };
    public static Dictionary<string, string>? PartTab = new()
    {
        ["SelectBase"] = "",
        ["Dialog"] = "",
        ["Tree"] = "",
        ["Main"] = "",
        ["SelectSwitchMark"] = "",
        ["SelectSwitchSlice"] = "",
        ["Validation"] = "",
        ["Filter"] = "",
    };
    public static Dictionary<string, string>? AppTab = new()
    {
        ["List"] = "List",
        //["One"] = "One",  //думаю, нет нужды делать отдельный смысл One - List тоже может отображать одну строку, это и будет One   
        ["Detail"] = "Detail",
        ["Console"] = "Console",
    };
    public static Dictionary<string, string>? WorkTable = new()
    {
        ["Asset"] = "Asset",
        ["Deal"] = "Deal",
        ["Face"] = "Face",
        ["Geo"] = "Geo",
        ["Log"] = "Log",
        ["Price"] = "Price",
    };
    public static string? StartDirectory;
    public static string? LastSaveDirectory;
    public static string? LastSelectFileDirectory;
    public static void TraceState(object? Obj, string? ContextObj, object? objFilter = default)
    {
        if (IsDev == true)
        {
            if ((objFilter != null) && (objFilter == Obj))
            {
                AddTraceLog(Obj, ContextObj);
            }
            if (objFilter == null)
            {
                AddTraceLog(Obj, ContextObj);
            }
        }
    }
    public static void AddTraceLog(object? Obj, string? ContextObj)
    {
        string? AddToTraceLog = "";
        if ((ContextObj != null) && (Obj != null))
        {
            AddToTraceLog = $"{ContextObj} = {Obj.ToString()}";   //{Environment.NewLine}";
        }
        if ((ContextObj == null) && (Obj != null))
        {
            AddToTraceLog = $"{Obj.ToString()}";   // {Environment.NewLine}";
        }
        if ((ContextObj != null) && (Obj == null))
        {
            AddToTraceLog = $"{ContextObj}";    // == {Environment.NewLine}";
        }
        if ((AddToTraceLog != null) && (AddToTraceLog !=String.Empty))
        {
            TraceLog.AppendLine(AddToTraceLog);
        }
    }
    public Util() { }
    static Util() { }
}

