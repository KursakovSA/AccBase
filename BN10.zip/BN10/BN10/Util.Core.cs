﻿namespace BN;
[Serializable]
public partial class Util
{
    public static bool IsDev = false;
    public static StringBuilder TraceLog = new StringBuilder("TraceLog" + Environment.NewLine);
    public static object? TraceFilter;
    public static SortedDictionary<string, string>? ListBase = new()
    {
        ["BaseN1"] = @"SQLEXPRESS\BaseN1",
        ["BaseN2"] = @"SQLEXPRESS\BaseN2",
        ["BaseN3"] = @"SQLEXPRESS\BaseN3",
    };
    public static Dictionary<string, string>? PartTab = new()
    {
        ["SelectBase"] = "",
        ["Dialog"] = "",
        ["Tree"] = "",
        ["Main"] = "",
        ["SelectChangeMark"] = "",
        ["SelectChangeSlice"] = "",
        ["Validation"] = "",
        ["Filter"] = "",
    };
    public static Dictionary<string, string>? Tab = new()
    {
        ["List"] = "List",
        ["Detail"] = "Detail",
        ["Edit"] = "Edit",
        ["New"] = "New",
        ["Console"] = "Console",
    };
    public static Dictionary<string, string>? EditableTable = new()
    {
        ["Geo"] = "Geo",
        ["Log"] = "Log",
        ["Face"] = "Face",
        ["Deal"] = "Deal",
        ["Asset"] = "Asset",
        ["Price"] = "Price",
    };
    public static string? AppDirectory;
    public static string? AppStartDirectory;
    public static string? AppLastSaveDirectory;
    public static string? AppLastSelectFileDirectory;
    public static void TraceState(object? Obj, string? ContextObj, object? objFilter = default)
    {
        if (IsDev == true)
        {
            if ((objFilter != null) && (objFilter == Obj))
            {
                AddTraceLog(Obj, ContextObj);
            }
            if (objFilter == null)
            {
                AddTraceLog(Obj, ContextObj);
            }
        }
    }
    public static void AddTraceLog(object? Obj, string? ContextObj)
    {
        string? AddToTraceLog = "";
        if ((ContextObj != null) && (Obj != null))
        {
            AddToTraceLog = $"{ContextObj} = {Obj.ToString()}";   //{Environment.NewLine}";
        }
        if ((ContextObj == null) && (Obj != null))
        {
            AddToTraceLog = $"{Obj.ToString()}";   // {Environment.NewLine}";
        }
        if ((ContextObj != null) && (Obj == null))
        {
            AddToTraceLog = $"{ContextObj}";    // == {Environment.NewLine}";
        }
        if ((AddToTraceLog != null) && (AddToTraceLog !=String.Empty))
        {
            TraceLog.AppendLine(AddToTraceLog);
        }
    }
    public Util() { }
    static Util() { }
}

