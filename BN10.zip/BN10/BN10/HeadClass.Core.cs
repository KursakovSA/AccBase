﻿namespace BN;
[Serializable]
[NotMapped]
public partial class HeadClass
{
    private int id;
    public int Id
    {
        get => id;
        set => id = FixId(value);  //TEST
    }
    private DateTime date1;
    public DateTime Date1
    {
        get => date1;
        set => date1 = FixDate1(value);  //TEST
    }
    public string? Date2 { get; set; }
    public string? Code { get; set; }
    public string? Description { get; set; }
    public string? More { get; set; }
    [NotMapped]
    public string? FullDescription;
    [NotMapped]
    public string? FullName;
    [NotMapped]
    public string? ShortDescription;
    [NotMapped]
    public string? ShortName;
    [NotMapped]
    public static readonly DateTime StartDate = new DateTime(2000, 01, 01);  //1 янв 2000 - начало возм действий в программе, стартовая дата, не раньше   
    [NotMapped]
    public static readonly DateTime EndDate = new DateTime(2060, 12, 31);  //31 дек 2060 - конец возм действий в программе, финишная дата, не позже
    [NotMapped]
    public static SortedDictionary<string, string>? State = new(); //TODO
    public decimal? GetPrice(Asset? inAsset, Deal? inDeal, DateTime? Date1, string? Date2)  //TODO
    {
        decimal? Price = default;
        //TraceState(ChangeMark.Basic["ToCD"], "Main, ChangeMark.Basic[ToCD] : ");
        return Price;
    }
    public decimal? GetPercent(decimal? inAmount,
                               decimal? inPercent1,
                               decimal? inPercent2)  //TODO
    {
        //найти процент inPercent1 (например, НДС 12%) от суммы inAmount, которая составляет inPercent2 (например, 112%, или 100%)
        decimal? Amount = default;
        if (inPercent1!=0)
        {
            Amount = (inAmount / inPercent2) * inPercent1;
        }
        return Amount;
    }
    public decimal? GetTurnover(DateTime Date1,
                                string? Date2) //TODO
    {
        decimal? turnover = default;
        Date1 = FixDate1(Date1);
        return turnover;
    }
    public decimal? GetSaldo(DateTime Date1, string? Date2)  //TODO
    {
        decimal? saldo = default;
        Date1 = FixDate1(Date1);
        return saldo;
    }
    public int FixId(int inId = default)  //TEST
    {
        int fixId = inId;
        if (fixId < 0)
        {
            fixId = 0;
        }
        return fixId;
    }
    public DateTime FixDate1(DateTime inDate1 = default)  //TEST
    {
        DateTime fixDate1 = inDate1;
        if (inDate1 < StartDate)
        {
            //fixDate1 = StartDate;
            return StartDate;
        }
        if (inDate1 > EndDate)
        {
            //fixDate1 = EndDate;
            return EndDate;
        }
        return inDate1;
    }
    public override string ToString()
    => $"Type={GetType()}, Id={Id}, Code={Code}, Description={Description}";
    public HeadClass() { }
    static HeadClass()  //????  не уверен что это нужно
    {
        State.Add("New", "New");
        State.Add("Saved", "Saved");
        State.Add("Saving", "Saving");
        State.Add("Edit", "Edit");
        State.Add("Editing", "Editing");

    }
    public HeadClass(int id = default,
                     DateTime date1 = default,
                     string? date2 = default,
                     string? code = default,
                     string? description = default,
                     string? more = default)
    {
        Id = id;
        Date1 = DateTime.Today;//date1;
        Date2 = date2;
        Code = code;
        Description = description;
        More = more;
    }
    //public void MoveState() { }  //TODO - перемещение элемента - заготовка
    //public void CopyState() { }  //TODO - копирование элемента - заготовка
    //public void DeleteState() { }  //TODO - удаление элемента - заготовка
    //public void ClearState() { }  //TODO - очистка элемента - заготовка
}
