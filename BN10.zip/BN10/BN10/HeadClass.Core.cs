﻿namespace BN;
[Serializable]
public partial class HeadClass
{
    public string? FullDescription;
    public string? FullName;
    public string? ShortDescription;
    public string? ShortName;
    public static readonly DateTime StartDate = new DateTime(2000, 01, 01);  //1 янв 2000 - начало возм действий в программе, стартовая дата, не раньше   
    public static readonly DateTime EndDate = new DateTime(2060, 12, 31);  //31 дек 2060 - конец возм действий в программе, финишная дата, не позже
    public static SortedDictionary<string, string>? State = new(); //TODO
    public static decimal? GetPrice(Asset? inAsset = default,
                                    Deal? inDeal = default,
                                    DateTime? inDate1 = default,
                                    string? inDate2 = default)  //TODO
    {
        decimal? Price = default;
        
        TraceState(Price, "HeadClass.GetPrice(...), return ");
        return Price;
    }
    public static decimal? GetPercent(decimal? inAmount,
                               decimal? inPercent1,
                               decimal? inPercent2)  //TODO
    {
        //найти процент inPercent1 (например, НДС 12%) от суммы inAmount, которая составляет inPercent2 (например, 112%, или 100%)
        decimal? Amount = default;
        if (inPercent1 != 0)
        {
            Amount = (inAmount / inPercent2) * inPercent1;
        }
        
        TraceState(Amount, "HeadClass.GetPercent(...), return ");
        return Amount;
    }
    //public decimal? GetTurnover(DateTime inDate1,
    //                            string? inDate2) //TODO
    //{
    //    decimal? Turnover = default;
    //    Date1 = FixDate1(Date1);
        
    //    TraceState(Turnover, "HeadClass.GetTurnover(...), return ");
    //    return Turnover;
    //}
    //public decimal? GetSaldo(DateTime inDate1,
    //                         string? inDate2)  //TODO
    //{
    //    decimal? Saldo = default;
    //    Date1 = FixDate1(Date1);
        
    //    TraceState(Saldo, "HeadClass.GetSaldo(...), return ");
    //    return Saldo;
    //}
    public static DateTime FixDate1(DateTime inDate1 = default)
    {
        DateTime FixDate1 = inDate1;
        if (inDate1 < StartDate)
        {
            FixDate1 = StartDate;
        }
        if (inDate1 > EndDate)
        {
            FixDate1 = EndDate;
        }
        
        TraceState(FixDate1, "HeadClass.FixDate1(...), return ");
        return FixDate1;
    }
    public string FixDescription(string inDescr = "")
    {
        string FixDescr = inDescr.Trim();
        
        TraceState(FixDescr, "HeadClass.FixDescription(...), return ");
        return FixDescr;
    }
    static HeadClass() {}
    public HeadClass(){}
}
