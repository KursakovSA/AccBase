﻿namespace BN;
[Serializable]
[NotMapped]
public partial class HeadClass
{
    private int id;
    public int Id
    {
        get => id;
        set => id = FixId(value);  //TEST
    }
    private DateTime date1;
    public DateTime Date1
    {
        get => date1;
        set => date1 = FixDate1(value);  //TEST
    }
    public string? Date2 { get; set; }
    public string? Code { get; set; }
    public string? Description { get; set; }
    public string? More { get; set; }
    public string? FullDescription;
    public string? FullName;
    public string? ShortDescription;
    public string? ShortName;
    public static readonly DateTime StartDate = new DateTime(2000, 01, 01);  //1 янв 2000 - начало возм действий в программе, стартовая дата, не раньше   
    public static readonly DateTime EndDate = new DateTime(2060, 12, 31);  //31 дек 2060 - конец возм действий в программе, финишная дата, не позже
    public static SortedDictionary<string, string>? State = new(); //TODO
    public static decimal? GetPrice(Asset? inAsset = default,
                                    Deal? inDeal = default,
                                    DateTime? inDate1 = default,
                                    string? inDate2 = default)  //TODO
    {
        decimal? Price = default;
        TraceState(Price, "HeadClass.GetPrice(inAsset, inDeal, inDate1, inDate2), return : ");
        return Price;
    }
    public static decimal? GetPercent(decimal? inAmount,
                               decimal? inPercent1,
                               decimal? inPercent2)  //TODO
    {
        //найти процент inPercent1 (например, НДС 12%) от суммы inAmount, которая составляет inPercent2 (например, 112%, или 100%)
        decimal? Amount = default;
        if (inPercent1 != 0)
        {
            Amount = (inAmount / inPercent2) * inPercent1;
        }
        TraceState(Amount, "HeadClass.GetPercent(inAmount, inPercent1, inPercent2), return : ");
        return Amount;
    }
    public decimal? GetTurnover(DateTime inDate1,
                                string? inDate2) //TODO
    {
        decimal? Turnover = default;
        Date1 = FixDate1(Date1);
        TraceState(Turnover, "HeadClass.GetTurnover(inDate1, inDate2), return : ");
        return Turnover;
    }
    public decimal? GetSaldo(DateTime inDate1,
                             string? inDate2)  //TODO
    {
        decimal? Saldo = default;
        Date1 = FixDate1(Date1);
        TraceState(Saldo, "HeadClass.GetSaldo(inDate1, inDate2), return : ");
        return Saldo;
    }
    public int FixId(int inId = default)  //TEST
    {
        int FixId = inId;
        if (FixId < 0)
        {
            FixId = 0;
        }
        TraceState(FixId, "HeadClass.FixId(inId), return : ");
        return FixId;
    }
    public static DateTime FixDate1(DateTime inDate1 = default)
    {
        DateTime FixDate1 = inDate1;
        if (inDate1 < StartDate)
        {
            FixDate1 = StartDate;
        }
        if (inDate1 > EndDate)
        {
            FixDate1 = EndDate;
        }
        TraceState(FixDate1, "HeadClass.FixDate1(inDate1), return : ");
        return FixDate1;
    }
    public string FixDescription(string inDescr = "")
    {
        string FixDescr = inDescr.Trim();
        TraceState(FixDescr, "HeadClass.FixDescription(inDescr), return : ");
        return FixDescr;
    }
    public override string ToString()
    => $"{GetType()}, {Code ?? "No code"}, {Description ?? "No description"}";
    public HeadClass() { }
    static HeadClass()  //????  не уверен что это нужно
    {
        State.Add("New", "New");
        State.Add("Saved", "Saved");
        State.Add("Saving", "Saving");
        State.Add("Edit", "Edit");
        State.Add("Editing", "Editing");

    }
    public HeadClass(int id = default,
                     DateTime date1 = default,
                     string? date2 = default,
                     string? code = default,
                     string? description = default,
                     string? more = default)
    {
        Id = id;
        Date1 = DateTime.Today;//date1;
        Date2 = date2;
        Code = code;
        Description = description;
        More = more;
    }
    //public void MoveState() { }  //TODO - перемещение элемента - заготовка
    //public void CopyState() { }  //TODO - копирование элемента - заготовка
    //public void DeleteState() { }  //TODO - удаление элемента - заготовка
    //public void ClearState() { }  //TODO - очистка элемента - заготовка
}
