﻿namespace BN;
[Serializable]
[Table("Face")]
public partial class User : Face
{
    public User() { }
    static User()
    {
        Basic.Add("FA1.User1", Face.Basic[key: "FA1.User1"]);
    }
}
