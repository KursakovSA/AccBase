﻿namespace BN;
[Serializable]
public partial class Asset : HeadClass
{
    private int id;
    public int Id
    {
        get => id;
        set => id = FixId(value);  //TEST
    }
    private DateTime date1;
    public DateTime Date1
    {
        get => date1;
        set => date1 = FixDate1(value);  //TEST
    }
    public string? Date2 { get; set; }
    public string? Code { get; set; }
    public string? Description { get; set; }
    public string? More { get; set; }
    public Asset? Parent { get; set; }
    public Face? Face1 { get; set; }
    public Face? Face2 { get; set; }
    public Face? Face { get; set; }
    public Geo? Geo { get; set; }
    public Asset? Asset1 { get; set; }  //catalog
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    public Unit? Unit { get; set; }
    public SortedDictionary<string, Asset>? SubAsset = new(); //TODO
    public Asset() { }
    static Asset() { }
    public int FixId(int inId = default)
    {
        int FixId = inId;
        if (FixId < 0)
        {
            FixId = 0;
        }

        TraceState(FixId, "Asset.FixId(...), return ");
        return FixId;
    }
}
