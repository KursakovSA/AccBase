﻿namespace BN;
[Serializable]
[Table("Asset")]
public partial class Asset : HeadClass
{
    public Asset? Parent { get; set; }
    public Face? Face1 { get; set; }
    public Face? Face2 { get; set; }
    public Face? Face { get; set; }
    public Geo? Geo { get; set; }
    public Asset? Asset1 { get; set; }  //catalog
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    public Unit? Unit { get; set; }
    [NotMapped]
    public static string[]? BasicCode = {
            "Asset","Asset.Money","Asset.Template1.Good","Asset.Template2.Material","Asset.Template3.Service",
"Asset.Template4.Work","Asset7","Asset8","Asset9","Asset10",
"Asset11","Asset12","Asset13","Asset14","Asset15",
"FNO100.FixedAsset","FNO100.FixedAsset.Group1","FNO100.FixedAsset.Group2","FNO100.FixedAsset.Group3","FNO100.FixedAsset.Group4",
        };
    [NotMapped]
    public static string[]? CatalogCode = {
           "FNO100.FixedAsset", "FNO100.FixedAsset.Group1", "FNO100.FixedAsset.Group2",
            "FNO100.FixedAsset.Group3", "FNO100.FixedAsset.Group4",
        };
    [NotMapped]
    public static SortedDictionary<string, Asset> Basic = new();
    [NotMapped]
    public static SortedDictionary<string, Asset> Switch = new();  //TODO
    [NotMapped]
    public static SortedDictionary<string, Asset> Template = new(); //TODO
    [NotMapped]
    public static SortedDictionary<string, Asset> Catalog = new(); //TODO
    [NotMapped]
    public SortedDictionary<string, Asset>? SubAsset = new(); //TODO
    public Asset() { }
    static Asset()
    {
        foreach (string bc in BasicCode)
        {
            Basic.Add(bc, new Asset { Code = bc });
        }
        foreach (string bc in CatalogCode)
        {
            Catalog.Add(bc, new Asset { Code = bc });
        }
    }
}
