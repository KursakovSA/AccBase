﻿namespace BN;
[Serializable]
[Table("Item")]
public partial class Item : HeadClass
{
    public Item? Parent { get; set; }
    [NotMapped]
    public static SortedDictionary<string, Item> Basic = new();
    [NotMapped]
    public static SortedDictionary<string, Item> Switch = new();  //TODO
    [NotMapped]
    public static SortedDictionary<string, Item> Template = new(); //TODO
    public Item() { }
    static Item()
    {
        string[] BasicCode =
        {
            "Item","Item.Advance","Item.Advertising","Item.Bank","Item.Car",
"Item.Charity","Item.Cost","Item.Deduction","Item.Depreciation","Item.Equipment",
"Item.Exchange difference","Item.Fine","Item.Food","Item.Fuel","Item.Impress",
"Item.Insurance","Item.Learning","Item.Loan","Item.Material","Item.Office",
"Item.Other","Item.Parts","Item.Periodical","Item.Production","Item.Purchase",
"Item.Rent","Item.Repair","Item.Salary","Item.Security","Item.Sell",
"Item.Shipping","Item.Store","Item.Tax","Item.Telecom","Item.Trip",
"Item.Utilities","Item.WriteOff",
        };
        foreach (string bc in BasicCode)
        {
            Basic.Add(bc, new Item { Code = bc });
        }
    }
}
