﻿namespace BN;
[Serializable]
public partial class Workbook : HeadClass
{
    private int id;
    public int Id
    {
        get => id;
        set => id = FixId(value);  //TEST
    }
    public Workbook? Parent { get; set; }
    private DateTime date1;
    public DateTime Date1
    {
        get => date1;
        set => date1 = FixDate1(value);  //TEST
    }
    public string? Date2 { get; set; }
    public string? Code { get; set; }
    public string? Description { get; set; }
    public string? More { get; set; }
    public Face? Face1 { get; set; }
    public Face? Face2 { get; set; }
    public Face? Face { get; set; }
    public Slice? Slice { get; set; }
    public Geo? Geo { get; set; }
    public Sign? Sign { get; set; }
    public Account? Account { get; set; }
    public Workbook? Workbook1 { get; set; }
    public Process? Process1 { get; set; }
    public Tax? Tax { get; set; }
    public Item? Item { get; set; }
    public Deal? Deal { get; set; }
    public Price? Price { get; set; }
    public Asset? Asset { get; set; }
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    public Meter? Meter { get; set; }
    public string? MeterValue { get; set; }
    public Unit? Unit { get; set; }
    public Mark? Mark { get; set; }
    public Workbook() { }
    static Workbook() { }
    public static double? Turnover<Workbook>(List<Workbook> inLog)
    {
        double? outTurnover = default;

        TraceState(outTurnover, "Workbook.Turnover(...), return ");
        return outTurnover;
    }
    public int FixId(int inId = default)
    {
        int FixId = inId;
        if (FixId < 0)
        {
            FixId = 0;
        }

        TraceState(FixId, "Workbook.FixId(...), return ");
        return FixId;
    }
}
