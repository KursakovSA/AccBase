﻿namespace BN;
[Serializable]
[Table("Info")]
public partial class Info : HeadClass
{
    public Info? Parent { get; set; }
    [NotMapped]
    public static string[]? BasicCode = {
            "Info",
            "Info.Address", "Info.Address.Home","Info.Address.Law","Info.Address.Post","Info.Address.Reg", "Info.Asset",
            "Info.Asset.Asset", "Info.Asset.Catalog","Info.Asset.SubAsset","Info.Code","Info.Code.Alfa3", "Info.Code.Art",
            "Info.Code.BIC", "Info.Code.EAN","Info.Code.IBAN","Info.Code.KBE","Info.Code.KBK", "Info.Code.KNP",
            "Info.Code.KOF", "Info.Code.KPVED","Info.Code.MKEI","Info.Code.OKPO","Info.Code.Post", "Info.Code.TNVED",
            "Info.Code.VIN", "Info.Cost","Info.Cost.Accounting","Info.Cost.Standard","Info.Cost.Store", "Info.Deal",
            "Info.Deal.Alimony", "Info.Deal.ContractWork","Info.Deal.GFSS","Info.Deal.GSVP","Info.Deal.Loan", "Info.Deal.Basic",
            "Info.Deal.MinistryLabor", "Info.Deal.OSMS","Info.Deal.ProductionOrder","Info.Deal.Rent","Info.Deal.Staff", "Info.Entity",
            "Info.Entity.Doc", "Info.Entity.Journal","Info.Entity.MainForm","Info.Entity.Reference","Info.ExchangeRate", "Info.ExchangeRate.Bank",
            "Info.ExchangeRate.Market", "Info.ExchangeRate.NationalBank","Info.ExchangeRate.Stock","Info.Face","Info.Face.Branch", "Info.Face.Businessman",
            "Info.Face.Corp", "Info.Face.GovAgency","Info.Face.JointStockCompany","Info.Face.LegalEntity","Info.Face.Person", "Info.Face.QuasiGov1",
            "Info.Face.QuasiGov2", "Info.Face.User","Info.Generic","Info.Generic.Cell","Info.Generic.Description", "Info.Generic.Email",
            "Info.Generic.Extra", "Info.Generic.FullDescription","Info.Generic.FullName","Info.Generic.Logo","Info.Generic.Basic", "Info.Generic.Phone",
            "Info.Generic.Photo", "Info.Generic.Sert","Info.Generic.ShortDescription","Info.Generic.ShortName","Info.Generic.Site", "Info.Generic.Street-House",
            "Info.Generic.Time", "Info.Generic.Variant","Info.Item","Info.Item.Financial","Info.Item.Invest", "Info.Item.Basic",
            "Info.List", "Info.List.ExemptionList","Info.List.StopList","Info.Log","Info.Log.Deal.Devivery", "Info.Log.Deal.Movement",
            "Info.Log.Level0.Main", "Info.Log.Level1.Amount","Info.Log.Level1.Cost","Info.Log.Level1.Price","Info.Log.Level1.Quantity", "Info.Log.Level2.Depreciation",
            "Info.Log.Level2.TaxExcess", "Info.Log.Level2.TaxTotal","Info.Management","Info.Management.Boss","Info.Management.Chief", "Info.Management.Driver",
            "Info.Management.LeadingSpecialist", "Info.Management.Manager","Info.Management.Responsible","Info.Math","Info.Math.Round1.5To1", "Info.Math.Round1.5To2",
            "Info.Math.RoundDownward", "Info.Math.RoundUpward","Info.PersonData","Info.PersonData.Autobiography","Info.PersonData.DateBirth", "Info.PersonData.Name",
            "Info.PersonData.Nationality", "Info.PersonData.Patronymic","Info.PersonData.Resume","Info.PersonData.Surname","Info.Profile", "Info.Profile.Basic",
            "Info.Profile.Pawnshop", "Info.Profile.PropertyManagement","Info.Rate","Info.Rate.MinRate","Info.Rate.MinSalary", "Info.RegData",
            "Info.RegData.BIN", "Info.RegData.IIN","Info.RegData.Passport","Info.RegData.RNN","Info.Relation", "Info.Relation.Alimonier",
            "Info.Relation.MainCalc", "Info.Relation.Pensioner","Info.Report","Info.Report.Analysis","Info.Report.Balance", "Info.Report.BalanceTurnover",
            "Info.Report.Depreciation", "Info.Report.Detail","Info.Report.DocLawForm","Info.Report.FinForm","Info.Report.FinForm.Balance", "Info.Report.FinForm.Capital",
            "Info.Report.FinForm.Income", "Info.Report.FinForm.Money","Info.Report.List","Info.Report.PaySheet","Info.Report.PriceList", "Info.Report.Revise",
            "Info.Report.SalaryInquery", "Info.Report.SalarySheet","Info.Report.SalarySummary","Info.Report.Sheet","Info.Report.StaffDoc", "Info.Report.TaxForm",
            "Info.Report.TaxRegistry", "Info.Sign","Info.Sign.UseAccTable","Info.Sign.UseEntry","Info.Staff", "Info.Staff.BaseSalary",
            "Info.Staff.BossSign", "Info.Staff.ChiefAccountantSign","Info.StaffTime","Info.StaffTime.DayOff","Info.StaffTime.Holiday", "Info.Store",
            "Info.Store.CoreFund", "Info.Store.IsDriveLaw","Info.Store.IsSubStore","Info.Store.NoStoreNoTraffic","Info.Tax", "Info.Tax.Amount",
            "Info.Tax.Base", "Info.Tax.BaseDeduction","Info.Tax.BaseException","Info.Tax.BaseLimit","Info.Tax.Deduction.MinSalary", "Info.Tax.Deduction.OPV",
            "Info.Tax.HalfYearReportingCycle", "Info.Tax.MonthBillingCycle","Info.Tax.MonthYearBillingCycle","Info.Tax.QuarterBillingCycle","Info.Tax.QuarterReportingCycle", "Info.Tax.RateFree",
            "Info.Tax.RateBasic", "Info.Tax.RateReduce","Info.Tax.RateZero","Info.Tax.SNMinusGFSS","Info.Tax.TaxAdjustment", "Info.Tax.YearBillingCycle",
            "Info.Tax.YearReportingCycle",
        };
    [NotMapped]
    public static string[]? CatalogCode = Array.Empty<string>();
    [NotMapped]
    public static SortedDictionary<string, Info> Basic = new();
    [NotMapped]
    public static SortedDictionary<string, Info> Switch = new();  //TODO
    [NotMapped]
    public static SortedDictionary<string, Info> Template = new(); //TODO
    [NotMapped]
    public static SortedDictionary<string, Info> Catalog = new();  //TODO
    public Info() { }
    static Info()
    {
        foreach (string bc in BasicCode)
        {
            Basic.Add(bc, new Info { Code = bc });
        }
        foreach (string bc in CatalogCode)
        {
            Catalog.Add(bc, new Info { Code = bc });
        }
    }
}
