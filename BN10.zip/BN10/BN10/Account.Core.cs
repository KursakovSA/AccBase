﻿namespace BN;
[Serializable]
public partial class Account : HeadClass
{
    private short id;
    public short Id
    {
        get => id;
        set => id = FixId(value);
    }
    public DateTime Date1 { get; set; }
    public string? Date2 { get; set; }
    public string? Code { get; set; }
    public string? Description { get; set; }
    public Account? Parent { get; set; }
    public Slice? Slice { get; set; }
    public Account? Account1 { get; set; }
    public Role? Role { get; set; }
    public Sign? Sign { get; set; }
    public string? More { get; set; }
    public Account? AccountTable;
    public static Account? PreviousTable;   //TODO, пока пустое поле, до очередной смены плана счетов
    public static Account? CurrentTable;
    public static Account? FutureTable;   //TODO, пока пустое поле, до очередной смены плана счетов
    public static SortedDictionary<string, string>? ClosePlan { get; set; } //TODO 
    public static SortedDictionary<string, string>? ConversePlan { get; set; } //TODO, пока пустое поле, до очередной смены плана счетов    
    public Account() { }
    public Account(short id = default,
                   DateTime? date1 = default,
                   string? date2 = default,
                   string? code = default,
                   string? description = default,
                   Account? account1 = default,
                   string? more = default,
                   Account? accountTable = default)
    {
        Id = id;
        Code = code;
        Date1 = DateTime.Today;//date1;
        Date2 = date2;
        Description = description;
        Account1 = account1;
        More = more;
        AccountTable = accountTable;
    }
    static Account()
    {
        //CurrentTable = Basic[key: "AccTable2019"];  ////TODO - надо как-то 
    }
    public static short FixId(short inId = default)
    {
        short FixId = inId;
        if (FixId < 0)
        {
            FixId = 0;
        }

        TraceState(FixId, "Account.FixId(...), return ");
        return FixId;
    }
    public override string ToString()
    => $"{GetType()}, {Code ?? "No code"}, {Description ?? "No description"}, {AccountTable?.Description}";
}
