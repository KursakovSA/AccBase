﻿namespace BN;
[Serializable]
[Table("Account")]
public partial class Account : HeadClass
{
    public Account? Parent { get; set; }
    public Slice? Slice { get; set; }
    public Role? Role { get; set; }
    public Sign? Sign { get; set; }
    [NotMapped]
    public Account? AccountTable;

    [NotMapped]
    public static Account? PreviousTable;   //TODO, пока пустое поле, до очередной смены плана счетов
    [NotMapped]
    public static Account? CurrentTable;
    [NotMapped]
    public static Account? FutureTable;   //TODO, пока пустое поле, до очередной смены плана счетов


    [NotMapped]
    public static SortedDictionary<string, string>? ClosePlan { get; set; } //TODO 
    [NotMapped]
    public static SortedDictionary<string, string>? ConversePlan { get; set; } //TODO, пока пустое поле, до очередной смены плана счетов    


    [NotMapped]
    public static string[]? BasicCode = {
            "Ac.1","Ac.1000","Ac.1010","Ac.1020","Ac.1030",
"Ac.1040","Ac.1050","Ac.1060","Ac.1070","Ac.1080",
"Ac.1090","Ac.1100","Ac.1110","Ac.1120","Ac.1130",
"Ac.1140","Ac.1150","Ac.1160","Ac.1170","Ac.1200",
"Ac.1210","Ac.1220","Ac.1230","Ac.1240","Ac.1250",
"Ac.1260","Ac.1270","Ac.1280","Ac.1300","Ac.1310",
"Ac.1320","Ac.1330","Ac.1340","Ac.1350","Ac.1360",
"Ac.1370","Ac.1400","Ac.1410","Ac.1420","Ac.1430",
"Ac.1500","Ac.1510","Ac.1520","Ac.1530","Ac.1600",
"Ac.1610","Ac.1620","Ac.1630","Ac.1700","Ac.1710",
"Ac.1720","Ac.1730","Ac.1740","Ac.1750","Ac.2",
"Ac.2000","Ac.2010","Ac.2020","Ac.2030","Ac.2040",
"Ac.2050","Ac.2060","Ac.2070","Ac.2080","Ac.2100",
"Ac.2110","Ac.2120","Ac.2130","Ac.2140","Ac.2150",
"Ac.2160","Ac.2170","Ac.2180","Ac.2200","Ac.2210",
"Ac.2220","Ac.2230","Ac.2300","Ac.2310","Ac.2320",
"Ac.2330","Ac.2400","Ac.2410","Ac.2420","Ac.2430",
"Ac.2440","Ac.2450","Ac.2460","Ac.2500","Ac.2510",
"Ac.2520","Ac.2530","Ac.2540","Ac.2600","Ac.2610",
"Ac.2620","Ac.2630","Ac.2700","Ac.2710","Ac.2720",
"Ac.2730","Ac.2740","Ac.2750","Ac.2760","Ac.2770",
"Ac.2780","Ac.2800","Ac.2810","Ac.2900","Ac.2910",
"Ac.2920","Ac.2930","Ac.2940","Ac.2950","Ac.2960",
"Ac.2970","Ac.2980","Ac.2990","Ac.3","Ac.3000",
"Ac.3010","Ac.3020","Ac.3030","Ac.3040","Ac.3050",
"Ac.3060","Ac.3070","Ac.3080","Ac.3100","Ac.3110",
"Ac.3120","Ac.3130","Ac.3140","Ac.3150","Ac.3160",
"Ac.3170","Ac.3180","Ac.3190","Ac.3200","Ac.3210",
"Ac.3220","Ac.3230","Ac.3240","Ac.3300","Ac.3310",
"Ac.3320","Ac.3330","Ac.3340","Ac.3350","Ac.3360",
"Ac.3370","Ac.3380","Ac.3400","Ac.3410","Ac.3420",
"Ac.3430","Ac.3440","Ac.3500","Ac.3510","Ac.3520",
"Ac.3530","Ac.3540","Ac.3550","Ac.3560","Ac.4",
"Ac.4000","Ac.4010","Ac.4020","Ac.4030","Ac.4040",
"Ac.4050","Ac.4060","Ac.4100","Ac.4110","Ac.4120",
"Ac.4130","Ac.4140","Ac.4150","Ac.4160","Ac.4200",
"Ac.4210","Ac.4220","Ac.4230","Ac.4240","Ac.4300",
"Ac.4310","Ac.4400","Ac.4410","Ac.4420","Ac.4430",
"Ac.4440","Ac.4450","Ac.5","Ac.5000","Ac.5010",
"Ac.5020","Ac.5030","Ac.5100","Ac.5110","Ac.5200",
"Ac.5210","Ac.5300","Ac.5310","Ac.5400","Ac.5410",
"Ac.5420","Ac.5500","Ac.5510","Ac.5520","Ac.5530",
"Ac.5540","Ac.5550","Ac.5560","Ac.5570","Ac.5600",
"Ac.5610","Ac.5620","Ac.5700","Ac.5710","Ac.6",
"Ac.6000","Ac.6010","Ac.6020","Ac.6030","Ac.6100",
"Ac.6110","Ac.6120","Ac.6130","Ac.6140","Ac.6150",
"Ac.6160","Ac.6200","Ac.6210","Ac.6220","Ac.6230",
"Ac.6240","Ac.6250","Ac.6260","Ac.6270","Ac.6280",
"Ac.6290","Ac.6300","Ac.6310","Ac.6400","Ac.6410",
"Ac.6420","Ac.7","Ac.7000","Ac.7010","Ac.7100",
"Ac.7110","Ac.7200","Ac.7210","Ac.7300","Ac.7310",
"Ac.7320","Ac.7330","Ac.7340","Ac.7400","Ac.7410",
"Ac.7420","Ac.7430","Ac.7440","Ac.7450","Ac.7460",
"Ac.7470","Ac.7480","Ac.7500","Ac.7510","Ac.7600",
"Ac.7610","Ac.7620","Ac.7700","Ac.7710","Ac.8",
"Ac.8100","Ac.8110","Ac.8200","Ac.8210","Ac.8300",
"Ac.8310","Ac.8400","Ac.8410","Ac.9","Account",
"AccTable2019","Work","Asset","AssetBio","AssetCoverall",
"AssetGood","AssetIntangible","AssetMaterial","AssetMortgage","AssetProduction",
"AssetTool","AssetUnfinishedProduction","Customer","CustomerPrepaid","Equity",
"Expense","ExpenseCost","ExpenseGeneral","ExpenseOther","ExpenseSell",
"ExpenseSellOut","FixedAsset","FixedAssetBuilding","FixedAssetCar","FixedAssetDepreciation",
"FixedAssetFurniture","FixedAssetLand","FixedAssetMachine","FixedAssetOfficeEquipment","FixedAssetOther",
"FixedAssetUnfinishedConstruction","Imprest","Income","IncomeLossNet","IncomeOther",
"IncomeSell","IncomeSellOut","Money","MoneyBank","MoneyCash",
"MoneyTransit","Salary","SalaryDeduction","Seller","SellerPrepaid",
"Tax","TaxAlimony","TaxCar","TaxExcise","TaxGFSS",
"TaxIncome","TaxIncomePerson","TaxLand","TaxOSMSEmployeeFee","TaxOSMSEmployeePay",
"TaxOther","TaxPension","TaxProperty","TaxSN","TaxVATIn",
"TaxVATOut",
        };
    [NotMapped]
    public static string[]? CatalogCode =  {
            "Asset","AssetBio","AssetCoverall","AssetGood","AssetIntangible",
"AssetMaterial","AssetMortgage","AssetProduction","AssetTool","AssetUnfinishedProduction",
"Customer","CustomerPrepaid","Equity","Expense","ExpenseCost",
"ExpenseGeneral","ExpenseOther","ExpenseSell","ExpenseSellOut","FixedAsset",
"FixedAssetBuilding","FixedAssetCar","FixedAssetDepreciation","FixedAssetFurniture","FixedAssetLand",
"FixedAssetMachine","FixedAssetOfficeEquipment","FixedAssetOther","FixedAssetUnfinishedConstruction","Imprest",
"Income","IncomeLossNet","IncomeOther","IncomeSell","IncomeSellOut",
"Money","MoneyBank","MoneyCash","MoneyTransit","Salary",
"SalaryDeduction","Seller","SellerPrepaid","Tax","TaxAlimony",
"TaxCar","TaxExcise","TaxGFSS","TaxIncome","TaxIncomePerson",
"TaxLand","TaxOSMSEmployeeFee","TaxOSMSEmployeePay","TaxOther","TaxPension",
"TaxProperty","TaxSN","TaxVATIn","TaxVATOut",
        };
    [NotMapped]
    public static SortedDictionary<string, Account> Basic = new();
    [NotMapped]
    public static SortedDictionary<string, Account> Switch = new();  //TODO
    [NotMapped]
    public static SortedDictionary<string, Account> Template = new(); //TODO
    [NotMapped]
    public static SortedDictionary<string, Account> Catalog = new();  //TODO
    [NotMapped]
    public static SortedDictionary<string, Account> Table = new();  //TODO, планы счетов  
    public Account() 
    {
        //TraceState(this.Code, "Account.Ctor(), return : ");
    }
    public Account(int id = default,
                   DateTime date1 = default,
                   string? date2 = default,
                   string? code = default,
                   string? description = default,
                   string? more = default,
                   Account? accountTable = default)
    {
        Id = id;
        Code = code;
        Date1 = DateTime.Today;//date1;
        Date2 = date2;
        Description = description;
        More = more;
        AccountTable = accountTable;
        //TraceState(this.Code, "Account.Ctor(id, date1, date2, code, descr, more, accountTable), return : ");
    }
    static Account() 
    {
        foreach (string bc in BasicCode)
        {
            Basic.Add(bc, new Account { Code = bc });
        }
        foreach (string bc in CatalogCode)
        {
            Catalog.Add(bc, new Account { Code = bc });
        }
        foreach (string bc in CatalogCode)
        {
            Catalog.Add(bc, new Account { Code = bc });
        }
        //table
        Table.Add("AccTable2019", Basic[key: "AccTable2019"]);
        Table.Add("Work", Basic[key: "Work"]);
        CurrentTable = Basic[key: "AccTable2019"];
    }
    public override string ToString()
    => $"{GetType()}, {Code ?? "No code"}, {Description ?? "No description"}, {AccountTable?.Description}";
}
