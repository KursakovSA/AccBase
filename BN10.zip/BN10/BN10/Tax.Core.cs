﻿namespace BN;
[Serializable]
public partial class Tax : HeadClass
{
    private short id;
    public short Id
    {
        get => id;
        set => id = FixId(value);  //TEST
    }
    public Tax? Parent { get; set; }
    private DateTime date1;
    public DateTime Date1
    {
        get => date1;
        set => date1 = FixDate1(value);  //TEST
    }
    public string? Date2 { get; set; }
    public string? Code { get; set; }
    public string? Description { get; set; }
    public string? More { get; set; }
    public Face? Face1 { get; set; }
    public Face? Face2 { get; set; }
    public Geo? Geo { get; set; }
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    public Tax? Base = default; //TODO
    public Tax? Rate = default; //TODO
    public Tax? Mode = default; //TODO
    public Tax? Deduction = default; //TODO
    public Tax() { }
    static Tax() { }
    public Role? GetTaxModeValue(DateTime Date1,
                                string? Date2,
                                Tax? Tax) //TODO
    {
        Role? TaxModeValue = default;

        TraceState(TaxModeValue, "Tax.GetTaxModeValue(...), return ");
        return TaxModeValue;
    }
    public Role? GetTaxBaseValue(DateTime Date1,
                                string? Date2,
                                Tax? Tax) //TODO
    {
        Role? TaxBaseValue = default;

        TraceState(TaxBaseValue, "Tax.GetTaxBaseValue(...), return ");
        return TaxBaseValue;
    }
    public decimal? GetTaxRateValue(DateTime Date1,
                                string? Date2,
                                Tax? Tax) //TODO
    {
        decimal? TaxRateValue = default;

        TraceState(TaxRateValue, "Tax.GetTaxRateValue(...), return ");
        return TaxRateValue;
    }
    public decimal? GetTaxDeductionValue(DateTime Date1,
                                string? Date2,
                                Tax? Tax) //TODO
    {
        decimal? TaxDeductionValue = default;

        TraceState(TaxDeductionValue, "Tax.GetTaxDeductionValue(...), return ");
        return TaxDeductionValue;
    }
    public short FixId(short inId = default)
    {
        short FixId = inId;
        if (FixId < 0)
        {
            FixId = 0;
        }

        TraceState(FixId, "Tax.FixId(...), return ");
        return FixId;
    }
}
