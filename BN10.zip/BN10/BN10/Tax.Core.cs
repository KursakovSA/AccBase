﻿namespace BN;
[Serializable]
[Table("Tax")]
public partial class Tax : HeadClass
{
    public Tax? Parent { get; set; }
    public Face? Face1 { get; set; }
    public Face? Face2 { get; set; }
    public Geo? Geo { get; set; }
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    [NotMapped]
    public static SortedDictionary<string, Tax> Basic = new();
    [NotMapped]
    public static SortedDictionary<string, Tax> Switch = new();  //TODO
    [NotMapped]
    public static SortedDictionary<string, Tax> Template = new(); //TODO
    [NotMapped]
    public static SortedDictionary<string, Info>? CodePay = new();  //TODO
    [NotMapped]
    public Tax? Base = default; //TODO
    [NotMapped]
    public Tax? Rate = default; //TODO
    [NotMapped]
    public Tax? Mode = default; //TODO
    [NotMapped]
    public Tax? Deduction = default; //TODO
    public Tax() { }
    static Tax()
    {
        #region basic
        //basic
        string[] BasicCode =
        {
           "Tax","Tax.Custom","Tax.Custom.Base","Tax.Custom.Duty","Tax.Custom.Fee",
"Tax.DeductionSalary","Tax.DeductionSalary.Alimony","Tax.DeductionSalary.Alimony.Rate1","Tax.DeductionSalary.Alimony.Rate2","Tax.DeductionSalary.Alimony.Rate3",
"Tax.DeductionSalary.Other","Tax.Depreciation","Tax.Depreciation.Base","Tax.DepreciationAccounting","Tax.DepreciationAccounting.Rate",
"Tax.DepreciationTax","Tax.DepreciationTax.Rate","Tax.ExchangeDifference","Tax.ExchangeDifference.Advance","Tax.ExchangeDifference.Purchase",
"Tax.GFSS","Tax.GFSS.Base","Tax.GFSS.KNP.012","Tax.GFSS.Rate","Tax.IncomePersonTax",
"Tax.IncomePersonTax.Base","Tax.IncomePersonTax.Base.Deduction.MinSalary","Tax.IncomePersonTax.Base.Deduction.OPV","Tax.IncomePersonTax.KBK.101201","Tax.IncomePersonTax.RateBasic",
"Tax.IncomeTax","Tax.IncomeTax.Base","Tax.IncomeTax.KBK.101110","Tax.OSMS","Tax.OSMS.Base",
"Tax.OSMS.EmployeePay","Tax.OSMS.EmployeePay.RateMain","Tax.OSMS.EmployerFee","Tax.OSMS.EmployerFee.RateBasic","Tax.Pension",
"Tax.Pension.Base","Tax.Pension.OPPV","Tax.Pension.OPV","Tax.Pension.OPV.KNP.010","Tax.Pension.OPV.RateBasic",
"Tax.Pension.OPVR","Tax.Salary","Tax.Salary.Commission","Tax.Salary.Extra","Tax.Salary.Main",
"Tax.Salary.Other","Tax.Salary.VacationCompensation","Tax.Salary.VacationPay","Tax.SN","Tax.SN.Base",
"Tax.SN.KBK.103101","Tax.SN.Rate","Tax.SN.SNMinusGFSS","Tax.VAT","Tax.VAT.Base",
"Tax.VAT.Import","Tax.VAT.Import.Base","Tax.VAT.Import.RateBasic","Tax.VAT.Purchase","Tax.VAT.Purchase.RateBasic",
"Tax.VAT.Purchase.RateReduce","Tax.VAT.Sell","Tax.VAT.Sell.KBK.105101","Tax.VAT.Sell.RateFree","Tax.VAT.Sell.RateBasic",
"Tax.VAT.Sell.RateReduce","Tax.VAT.Sell.RateZero","TaxCar","TaxCar.KBK.104401","TaxCar.KBK.104402",
"TaxOther","TaxLand","TaxProperty", 
	#endregion
        };
        foreach (string bc in BasicCode)
        {
            Basic.Add(bc, new Tax { Code = bc });
        }
        //CodePay
        CodePay.Add("Info.Code.KBE", Info.Basic[key: "Info.Code.KBE"]);
        CodePay.Add("Info.Code.KBK", Info.Basic[key: "Info.Code.KBK"]);
        CodePay.Add("Info.Code.KNP", Info.Basic[key: "Info.Code.KNP"]);
    }
    public Role? GetTaxModeValue(DateTime Date1,
                                string? Date2,
                                Tax? Tax) //TODO
    {
        Role? TaxModeValue = default;
        return TaxModeValue;
    }
    public Role? GetTaxBaseValue(DateTime Date1,
                                string? Date2,
                                Tax? Tax) //TODO
    {
        Role? TaxBaseValue = default;
        return TaxBaseValue;
    }
    public decimal? GetTaxRateValue(DateTime Date1,
                                string? Date2,
                                Tax? Tax) //TODO
    {
        decimal? TaxRateValue = default;
        return TaxRateValue;
    }
    public decimal? GetTaxDeductionValue(DateTime Date1,
                                string? Date2,
                                Tax? Tax) //TODO
    {
        decimal? TaxDeductionValue = default;
        return TaxDeductionValue;
    }
}
