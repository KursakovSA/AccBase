﻿namespace BN;
[Serializable]
[Table("Slice")]
public partial class Slice : HeadClass
{
    public Slice? Parent { get; set; }
    [NotMapped]
    public static SortedDictionary<string, Slice> Basic = new();
    [NotMapped]
    public static SortedDictionary<string, Slice> Switch = new();  //TODO
    [NotMapped]
    public static SortedDictionary<string, Slice> Template = new(); //TODO
    static Slice()
    {
        //basic
        string[] BasicCode =
        {
            "Accounting","Adjustment","Budget","Duplicate","Fact",
"Forecast","Norm","Offer","Plan","Preorder",
"Report","Request","ToAccounting","ToFact","ToPlan",
        };
        foreach (string bc in BasicCode)
        {
            Basic.Add(bc, new Slice { Code = bc });
        }
        //switch
        Switch.Add("ToAccounting", Slice.Basic[key: "ToAccounting"]);
        Switch.Add("ToFact", Slice.Basic[key: "ToFact"]);
        Switch.Add("ToPlan", Slice.Basic[key: "ToPlan"]);
    }
    public Slice() { }
}
