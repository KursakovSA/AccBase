﻿namespace BN;
[Serializable]
public partial class Process : HeadClass
{
    private short id;
    public short Id
    {
        get => id;
        set => id = FixId(value);  //TEST
    }
    public Process? Parent { get; set; }
    private DateTime date1;
    public DateTime Date1
    {
        get => date1;
        set => date1 = FixDate1(value);  //TEST
    }
    public string? Date2 { get; set; }
    public string? Code { get; set; }
    public string? Description { get; set; }
    public string? More { get; set; }
    public Face? Face1 { get; set; }
    public Face? Face2 { get; set; }
    public Slice? Slice { get; set; }
    public Sign? Sign { get; set; }
    public Account? Account { get; set; }
    public Workbook? Workbook1 { get; set; }
    public Workbook? Workbook2 { get; set; }
    public Process? Process1 { get; set; }
    public Asset? Asset { get; set; }
    public Deal? Deal { get; set; }
    public Item? Item { get; set; }
    public Tax? Tax { get; set; }
    public Price? Price { get; set; }
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    public Meter? Meter { get; set; }
    public string? MeterValue { get; set; }
    public Unit? Unit { get; set; }
    public Process() { }
    static Process() { }
    public short FixId(short inId = default)
    {
        short FixId = inId;
        if (FixId < 0)
        {
            FixId = 0;
        }

        TraceState(FixId, "Process.FixId(...), return ");
        return FixId;
    }
}
