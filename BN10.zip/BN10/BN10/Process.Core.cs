﻿namespace BN;
[Serializable]
[Table("Process")]
public partial class Process : HeadClass
{
    public Process? Parent { get; set; }
    public Face? Face1 { get; set; }
    public Face? Face2 { get; set; }
    public Slice? Slice { get; set; }
    public Sign? Sign { get; set; }
    public Account? Account { get; set; }
    public Log? Log1 { get; set; }
    public Log? Log2 { get; set; }
    public Process? Process1 { get; set; }
    public Asset? Asset { get; set; }
    public Deal? Deal { get; set; }
    public Item? Item { get; set; }
    public Tax? Tax { get; set; }
    public Price? Price { get; set; }
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    public Meter? Meter { get; set; }
    public string? MeterValue { get; set; }
    public Unit? Unit { get; set; }
    [NotMapped]
    public static SortedDictionary<string, Process> Basic = new();
    [NotMapped]
    public static SortedDictionary<string, Process> Switch = new();  //TODO
    [NotMapped]
    public static SortedDictionary<string, Process> Template = new(); //TODO
    public Process() { }
    static Process()
    {
        string[] BasicCode =
        {
            "AddSalary","AddSalary.1","AddSalary.2","Buy","Buy.1",
"Buy.2 (Contract)","Buy.3 (Order)","Buy.3A","Buy.4 (Money)","Buy.4A",
"Buy.4B","Buy.4C","Buy.5 (Arrival)","Buy.5A","Buy.5B",
"Buy.5C","Buy.5CA","Buy.5D","Buy.5E (VATBase)","Buy.5F (VAT)",
"Buy.6","Buy.6A","Buy.6B","Buy.7 (Invoice)","Buy.8 (Null)",
"ChangeCurrency","ChangeCurrency.1","ChangeCurrency.2","ChangeCurrency.3","ChangeCurrency.4",
"Closing","Closing.1","Closing.2","Closing.3","Closing.4",
"CurrentBalance","CurrentBalance.1","CurrentBalance.1A","CurrentBalance.1B","CurrentBalance.2",
"CurrentBalance.3","CurrentBalance.3A","CurrentBalance.3B","CurrentBalance.3C","DebtOffsetting",
"DebtOffsetting.1","DebtOffsetting.2","DebtOffsetting.3","DebtOffsetting.4","DebtOffsetting.5",
"DebtOffsetting.6","Depreciation","Depreciation.1","Depreciation.2","Entry",
"Entry.1","Entry.2","ExchangeDifference","ExchangeDifference.1","ExchangeDifference.2",
"ExchangeDifference.3","ExchangeDifference.4","ExchangeDifference.5","ExchangeDifference.6","InputInitialBalance",
"InputInitialBalance.1","InputInitialBalance.2","MainSalary","MainSalary.1","MainSalary.1A",
"MainSalary.2","MainSalary.2A","MainSalary.2B","MainSalary.2C","MainSalary.2D",
"MainSalary.2E","MainSalary.3","MainSalary.3A","MainSalary.3B","MainSalary.3C",
"MainSalary.3D","MainSalary.3E","MainSalary.3F","MainSalary.3G","MainSalary.3H",
"MainSalary.3I","MainSalary.3J","MainSalary.3K","MainSalary.3L","MainSalary.3LA",
"MainSalary.3M","MainSalary.3N","MainSalary.3NA","MainSalary.3O","MainSalary.3P",
"MainSalary.3Q","MainSalary.4","MainSalary.4A","MainSalary.4B","MainSalary.4C",
"MainSalary.4D","MainSalary.5","MainSalary.5A","MainSalary.5B","PaySalary",
"PaySalary.1","PaySalary.1A","PaySalary.1B","PaySalary.1C","PaySalary.2",
"PaySalary.2A","PaySalary.2B","PaySalary.3","PaySalary.3A","PaySalary.3B",
"PettyCash","PettyCash.1","PettyCash.2 (Payment)","PettyCash.2A","PettyCash.2B",
"PettyCash.3 (Imprest)","PettyCash.3A","PettyCash.3B","PettyCash.4 (ReturnCash)","PettyCash.4A",
"PettyCash.4B","Price","Price.1","Price.2","Process",
"ReturnBuy","ReturnBuy.1","ReturnBuy.2 (BuyStorno)","ReturnBuy.2A","ReturnBuy.2B",
"ReturnBuy.2C","ReturnBuy.2D (VATStorno)","ReturnBuy.2E (VATBaseStorno)","ReturnBuy.3 (ReturnMoney)","ReturnBuy.3A",
"ReturnBuy.3B","ReturnBuy.3C","ReturnBuy.4 (InvoiceStorno)","ReturnSell","ReturnSell.1",
"ReturnSell.2 (SellStorno)","ReturnSell.2A (Storno)","ReturnSell.2B (Storno)","ReturnSell.2C (Storno)","ReturnSell.2D (Storno)",
"ReturnSell.2E (Storno)","ReturnSell.2F (VATStorno)","ReturnSell.2G (IncomeTaxBaseStorno)","ReturnSell.2H (VATBaseStorno)","ReturnSell.3 (Money)",
"ReturnSell.3A","ReturnSell.3B","ReturnSell.3C","ReturnSell.4 (InvoiceStorno)","Revise",
"Revise.1","Revise.2","Sell","Sell.1","Sell.2 (Contract)",
"Sell.3 (Order)","Sell.3A","Sell.3B","Sell.3C","Sell.4 (Money)",
"Sell.4A","Sell.4B","Sell.4C","Sell.5 (Consumption)","Sell.5A",
"Sell.5B","Sell.5C","Sell.5D","Sell.5E","Sell.5F (VATBase)",
"Sell.5G (IncomeTaxBase)","Sell.5H (VAT)","Sell.5I","Sell.5J","Sell.6 (Invoice)",
"Sell.7 (Null)","StaffDoc","StaffDoc.1","StaffDoc.2","StaffDoc.3",
"StaffDoc.4","StaffDoc.5","StaffDoc.6","StaffDoc.7","Storno",
"TaxPay","TaxPay.1","TaxPay.2","TaxPay.3","TaxPay.4",
"TaxPay.5","Transfer","Transfer.1","Transfer.2 (Transfer)","Transfer.2A",
"Transfer.2B","Transfer.2C","Transfer.2D","TransferMoney","TransferMoney.1",
"TransferMoney.2","TransferMoney.3","Writeoff","Writeoff.1","Writeoff.2  (Consumption)",
"Writeoff.2A","Writeoff.2B","Writeoff.2C","Writeoff.3 (Arrival)","Writeoff.3A",
"Writeoff.3B","Writeoff.3C",
        };
        foreach (string bc in BasicCode)
        {
            Basic.Add(bc, new Process { Code = bc });
        }
    }
}
