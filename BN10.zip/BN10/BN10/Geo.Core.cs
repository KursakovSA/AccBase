﻿namespace BN;
[Serializable]
[Table("Geo")]
public partial class Geo : HeadClass
{
    public Geo? Parent { get; set; }
    public Role? Role { get; set; }
    public Unit? Unit { get; set; }
    [NotMapped]
    public string? AddressPost;
    [NotMapped]
    public static string[]? BasicCode = {
            "Geo","Geo.Almaty","Geo.BE","Geo.Ch","Geo.DE",
"Geo.EAEU","Geo.EU","Geo.KG","Geo.Nur-Sultan","Geo.OESD",
"Geo.Qazaqstan","Geo.RF","Geo.USA","Geo.UZ","Geo.WTO",
        };
    [NotMapped]
    public static string[]? CatalogCode = Array.Empty<string>();
    [NotMapped]
    public static SortedDictionary<string, Geo> Basic = new();
    [NotMapped]
    public static SortedDictionary<string, Geo> Switch = new();  //TODO
    [NotMapped]
    public static SortedDictionary<string, Geo> Template = new(); //TODO
    [NotMapped]
    public static SortedDictionary<string, Geo> Catalog = new();  //TODO
    public Geo() { }
    static Geo()
    {
        foreach (string bc in BasicCode)
        {
            Basic.Add(bc, new Geo { Code = bc });
        }
        foreach (string bc in CatalogCode)
        {
            Catalog.Add(bc, new Geo { Code = bc });
        }
    }
}
