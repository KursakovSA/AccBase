﻿namespace BN;
[Serializable]
[Table("Role")]
public partial class Role : HeadClass
{
    public Role? Parent { get; set; }
    [NotMapped]
    public static string[]? BasicCode = {
            "Role","Role.Account","Role.Account.Asset","Role.Account.Budget","Role.Account.Capital",
"Role.Account.Depreciation","Role.Account.Face","Role.Account.FixedAsset","Role.Account.Group1Level","Role.Account.Group2Level",
"Role.Account.Money","Role.Account.Other","Role.Account.Production","Role.Account.Salary","Role.Account.Tax",
"Role.AccTable","Role.AccTable.1997","Role.AccTable.2005","Role.AccTable.2019","Role.AccTable.OffBalance",
"Role.AccTable.Work","Role.Asset","Role.Asset.BioAsset","Role.Asset.Building","Role.Asset.Car",
"Role.Asset.Coverall","Role.Asset.Furniture","Role.Asset.Good","Role.Asset.IntangibleAsset","Role.Asset.Land",
"Role.Asset.LineBusiness","Role.Asset.Machine","Role.Asset.Material","Role.Asset.Money","Role.Asset.Mortgage",
"Role.Asset.OfficeEquipment","Role.Asset.OtherFixedAsset","Role.Asset.Production","Role.Asset.Project","Role.Asset.Service",
"Role.Asset.Tool","Role.Asset.Work","Role.Asset.UnfinishedWork","Role.Currency","Role.Currency.AccountingCurrency",
"Role.Currency.ExchangeCurrency","Role.Deal","Role.Deal.AddAgreement","Role.Deal.Appendix","Role.Deal.Devivery",
"Role.Deal.Frame","Role.Deal.Basic","Role.Deal.Spec","Role.Entity","Role.Entity.Account",
"Role.Entity.Asset-Deal","Role.Entity.Asset-Unit","Role.Entity.Balance","Role.Entity.Bank","Role.Entity.BankStatement",
"Role.Entity.Budget","Role.Entity.Country-Currency","Role.Entity.Deal","Role.Entity.Doc-Process","Role.Entity.Entry",
"Role.Entity.ExtraCalc","Role.Entity.Face-Deal","Role.Entity.Imprest","Role.Entity.InputCash","Role.Entity.Invoice",
"Role.Entity.Log","Role.Entity.MainTable","Role.Entity.Money","Role.Entity.Order","Role.Entity.OutputCash",
"Role.Entity.PayOrder","Role.Entity.PaySheet","Role.Entity.PriceList","Role.Entity.Process","Role.Entity.Purchase",
"Role.Entity.Return","Role.Entity.Revise","Role.Entity.SalaryAverageCalc","Role.Entity.Salary","Role.Entity.SalaryInquery",
"Role.Entity.SalaryPaySheet","Role.Entity.SalarySheet","Role.Entity.SalarySummary","Role.Entity.Sell","Role.Entity.Staff",
"Role.Entity.StaffDoc","Role.Entity.Store","Role.Entity.Tax-Face","Role.Entity.Transfer","Role.Entity.Warrant",
"Role.Entity.WriteOff","Role.Exchange","Role.Exchange.EsfXML","Role.Exchange.MT100","Role.Exchange.MT102",
"Role.Exchange.SwiftGFSS","Role.Exchange.SwiftOPV","Role.Exchange.SwiftOSMS","Role.Exchange.Tax100-01","Role.Face",
"Role.Face.Bank","Role.Face.ContractWorker","Role.Face.Customer","Role.Face.ExternalWorker","Role.Face.FA",
"Role.Face.Foreigner","Role.Face.GCVP","Role.Face.Seller","Role.Face.Staff","Role.Face.State",
"Role.Generic","Role.Generic.Code","Role.Generic.Description","Role.Generic.Extra","Role.Generic.FullName",
"Role.Generic.List","Role.Generic.Basic","Role.Generic.ShortName","Role.Generic.Time","Role.Generic.Variant",
"Role.Geo","Role.Geo.City","Role.Geo.Country","Role.Geo.County","Role.Geo.District",
"Role.Geo.House","Role.Geo.Region","Role.Geo.Street","Role.Geo.Township","Role.Geo.Union",
"Role.Geo.Village","Role.Geo.WorldOrg","Role.Log","Role.Log.ChangeMark","Role.Log.Line1Manual",
"Role.Log.Line2Calc","Role.Log.StartPoint","Role.Policy","Role.Policy.CanChangeDayAgo","Role.Policy.MustAuth",
"Role.Policy.MustFill","Role.Policy.NoChange","Role.Policy.NoDelete","Role.Policy.NoRound","Role.Policy.NoView",
"Role.Policy.ToZero","Role.Price","Role.Price.AddFee","Role.Price.Basic","Role.Price.Percent",
"Role.Price.Tariff","Role.PriceChange","Role.PriceChange.Action","Role.PriceChange.FreePiece","Role.PriceChange.Markup",
"Role.PriceChange.Sale","Role.Rate","Role.Rate.MaxRate","Role.Rate.MinRate","Role.Rate.Ratio",
"Role.RegData","Role.RegData.ExternalNumber","Role.RegData.License","Role.RegData.Passport","Role.RegData.RegDescription",
"Role.RegData.Sert","Role.RegData.TaxNumber","Role.ReportFrame","Role.ReportFrame.Body","Role.ReportFrame.Column1",
"Role.ReportFrame.Column2","Role.ReportFrame.Column3","Role.ReportFrame.Footer","Role.ReportFrame.Header","Role.Sign",
"Role.Sign.AccTable","Role.Sign.Budget","Role.Sign.HRA","Role.Sign.MoneyFlow","Role.Sign.Store-Traffic",
"Role.Sign.Tax","Role.StaffTable","Role.StaffTable.4day","Role.StaffTable.5day","Role.StaffTable.6day",
"Role.StaffTable.7day","Role.Store","Role.Store.Bank","Role.Store.BankPersonAccount","Role.Store.Cash",
"Role.Store.Construction","Role.Store.Department","Role.Store.Depo","Role.Store.Main","Role.Store.Pallet",
"Role.Store.Rack","Role.Store.Retail","Role.Store.Shelf","Role.Store.Shop","Role.Store.Staff",
"Role.TaxBase","Role.TaxBase.CostBrutto","Role.TaxBase.CostNetto","Role.TaxBase.ExchangeRateDelta","Role.TaxBase.FixedAssetNetto",
"Role.TaxBase.CoreFundNetto","Role.TaxBase.ImportNetto","Role.TaxBase.IncomeBrutto","Role.TaxBase.IncomeNetto","Role.TaxBase.SalaryBrutto",
"Role.TaxBase.SalaryNetto","Role.TaxBase.SellBrutto","Role.TaxBase.SellNetto","Role.TaxDetail","Role.TaxDetail.DepreciationLineMonth",
"Role.TaxDetail.DepreciationYearTax","Role.TaxDetail.ExcRateDelta1","Role.TaxDetail.ExcRateDelta2","Role.TaxDetail.InputSell","Role.TaxDetail.OutputSell",
"Role.TaxMode","Role.TaxMode.Basic","Role.TaxMode.Patent","Role.TaxMode.Simple","Role.TaxMode.WorkContract",
"Role.Unit","Role.Unit.Auth","Role.Unit.Derivative","Role.Unit.Basic",
        };
    [NotMapped]
    public static string[]? CatalogCode = Array.Empty<string>();
    [NotMapped]
    public static SortedDictionary<string, Role> Basic = new();
    [NotMapped]
    public static SortedDictionary<string, Role> Switch = new();  //TODO
    [NotMapped]
    public static SortedDictionary<string, Role> Template = new(); //TODO
    [NotMapped]
    public static SortedDictionary<string, Role> Catalog = new();  //TODO
    public Role() { }
    static Role()
    {
        foreach (string bc in BasicCode)
        {
            Basic.Add(bc, new Role { Code = bc });
        }
        foreach (string bc in CatalogCode)
        {
            Catalog.Add(bc, new Role { Code = bc });
        }
    }
}
[Serializable]
public partial class ExchangeData : HeadClass
{
    public Role? Parent { get; set; }
    [NotMapped]
    public static string? TargetPath = @"C:\";
    [NotMapped]
    public string? TargetFile;
    [NotMapped]
    public static SortedDictionary<string, Role>? Basic = new();
    public ExchangeData() { }
    static ExchangeData()
    {
        TargetPath = @"C:\";
        Geo? Geo = new Geo { Id = 0, Code = "Geo.Qazaqstan", Description = "РК" };
    }
    public static StringBuilder SwiftOPV(Log? LogSalary)
    {
        ExchangeData? SwiftOPV = new ExchangeData { Id = 0, Code = "Role.ExchangeData.SwiftOPV", Description = "swift ОПВ" };
        SwiftOPV.TargetFile = @"Swift_OPV.txt";
        //ObjToConsole(SwiftOPV, "SwiftOPV, SwiftOPV : ");
        StringBuilder TextSwiftOPV = new();
        //TODO - выгрузка свифт файла для ОПВ
        return TextSwiftOPV;
    }
}
