﻿namespace BN;
[Serializable]
public partial class Deal : HeadClass
{
    private int id;
    public int Id
    {
        get => id;
        set => id = FixId(value);  //TEST
    }
    private DateTime date1;
    public DateTime Date1
    {
        get => date1;
        set => date1 = FixDate1(value);  //TEST
    }
    public string? Date2 { get; set; }
    public string? Code { get; set; }
    public string? Description { get; set; }
    public string? More { get; set; }
    public Deal? Parent { get; set; }
    public Face? Face1 { get; set; }
    public Face? Face2 { get; set; }
    public Face? Face { get; set; }
    public Geo? Geo { get; set; }
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    public SortedDictionary<string, Deal>? Delivery = new(); //TODO
    public SortedDictionary<string, Deal>? Movement = new(); //TODO
    public Deal() { }
    public Deal(int id = default,
                    DateTime date1 = default,
                    string? date2 = default,
                    string? code = default,
                    string? description = default,
                    Role? role = default,
                    Info? info = default,
                    string? more = default)
    {
        Id = id;
        Date1 = DateTime.Today;//date1;
        Date2 = date2;
        Code = code;
        Description = description;
        More = more;
        Role = role;
        Info = info;
    }
    static Deal() { }
   public int FixId(int inId = default)
    {
        int FixId = inId;
        if (FixId < 0)
        {
            FixId = 0;
        }

        TraceState(FixId, "Deal.FixId(...), return ");
        return FixId;
    }
}
