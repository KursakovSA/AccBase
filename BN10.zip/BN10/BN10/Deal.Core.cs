﻿namespace BN;
[Serializable]
[Table("Deal")]
public partial class Deal : HeadClass
{
    public Deal? Parent { get; set; }
    public Face? Face1 { get; set; }
    public Face? Face2 { get; set; }
    public Face? Face { get; set; }
    public Geo? Geo { get; set; }
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    [NotMapped]
    public static string[]? BasicCode = {
                    "Deal","Deal.alimony","Deal.enbek.staff","Deal.FA1.boss","Deal.GFSS",
        "Deal.kgd.tax","Deal.OPV","Deal.OSGPOR","Deal.OSMS","Deal.Template1.Good",
        "Deal.Template2.ContractWork","Deal.Template3.Staff",
                };
    [NotMapped]
    public static string[]? CatalogCode = Array.Empty<string>();
    [NotMapped]
    public static SortedDictionary<string, Deal> Basic = new();
    [NotMapped]
    public static SortedDictionary<string, Deal> Switch = new();  //TODO
    [NotMapped]
    public static SortedDictionary<string, Deal> Template = new(); //TODO
    [NotMapped]
    public static SortedDictionary<string, Deal> Catalog = new();  //TODO
    [NotMapped]
    public SortedDictionary<string, Deal>? Delivery = new(); //TODO
    [NotMapped]
    public SortedDictionary<string, Deal>? Movement = new(); //TODO
    public Deal() { }
    public Deal(int id = default,
                    DateTime date1 = default,
                    string? date2 = default,
                    string? code = default,
                    string? description = default,
                    Role? role = default,
                    Info? info = default,
                    string? more = default)
    {
        Id = id;
        Date1 = DateTime.Today;//date1;
        Date2 = date2;
        Code = code;
        Description = description;
        More = more;
        Role = role;
        Info = info;
    }
    static Deal()
    {
        foreach (string bc in BasicCode)
        {
            Basic.Add(bc, new Deal { Code = bc });
        }
        foreach (string bc in CatalogCode)
        {
            Catalog.Add(bc, new Deal { Code = bc });
        }
        //template
        Template.Add("Deal.Template1.Good", Deal.Basic[key: "Deal.Template1.Good"]);
        Template.Add("Deal.Template2.ContractWork", Deal.Basic[key: "Deal.Template2.ContractWork"]);
        Template.Add("Deal.Template3.Staff", Deal.Basic[key: "Deal.Template3.Staff"]);
    }
}
