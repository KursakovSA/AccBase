﻿namespace BN;
[Serializable]
[Table("Sign")]
public partial class Sign : HeadClass
{
    public Sign? Parent { get; set; }
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    [NotMapped]
    public static string[]? BasicCode = {
            "Acc.Ct","Acc.Ct-Dt","Acc.Dt","Acc.Dt-Ct","Account",
"Budget","Budget.Input","Budget.Output","HRA","MoneyFlow",
"MoneyFlow.Input","MoneyFlow.Input.011","MoneyFlow.Input.012","MoneyFlow.Input.013","MoneyFlow.Input.016",
"MoneyFlow.Output","MoneyFlow.Output.021","MoneyFlow.Output.022","MoneyFlow.Output.023","MoneyFlow.Output.026",
"MoneyFlow.Output.027","Price","Price.Fall","Price.Growth","Price.NoChange",
"Sign","Store","Store.Input","Store.Output","Store.Storage",
"Store.Storage.Input","Store.Storage.Output","Tax","Tax.Ct","Tax.KNP",
"Tax.KNP.TaxMode.Main.911","Tax.KNP.TaxMode.Main.912","Tax.KNP.TaxMode.Patent.921","Tax.KNP.TaxMode.Patent.922","Tax.KNP.TaxMode.Simple.931",
"Tax.KNP.TaxMode.Simple.932","Traffic","Traffic.Input","Traffic.Output","Traffic.Transit",
"Traffic.Transit.Input","Traffic.Transit.Output","Work","Work.Closing","Work.Execution",
"Work.Plan",
        };
    [NotMapped]
    public static string[]? CatalogCode = Array.Empty<string>();
    [NotMapped]
    public static SortedDictionary<string, Sign> Basic = new();
    [NotMapped]
    public static SortedDictionary<string, Sign> Switch = new();  //TODO
    [NotMapped]
    public static SortedDictionary<string, Sign> Template = new(); //TODO
    [NotMapped]
    public static SortedDictionary<string, Sign> Catalog = new();  //TODO
    public Sign() { }
    static Sign() 
    {
        foreach (string bc in BasicCode)
        {
            Basic.Add(bc, new Sign { Code = bc });
        }
        foreach (string bc in CatalogCode)
        {
            Catalog.Add(bc, new Sign { Code = bc });
        }
    }
}
