﻿namespace BN;
[Serializable]
public partial class Sign : HeadClass
{
    private byte id;
    public byte Id
    {
        get => id;
        set => id = FixId(value);  //TEST
    }
    public Sign? Parent { get; set; }
    private DateTime date1;
    public DateTime Date1
    {
        get => date1;
        set => date1 = FixDate1(value);  //TEST
    }
    public string? Date2 { get; set; }
    public string? Code { get; set; }
    public string? Description { get; set; }
    public string? More { get; set; }
    public Role? Role { get; set; }
    public Info? Info { get; set; }
    public Sign() { }
    static Sign() { }
    public byte FixId(byte inId = default)
    {
        byte FixId = inId;
        if (FixId < 0)
        {
            FixId = 0;
        }

        TraceState(FixId, "Sign.FixId(...), return ");
        return FixId;
    }
}
