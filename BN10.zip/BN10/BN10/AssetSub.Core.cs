﻿namespace BN;
[Serializable]
[Table("Asset")]
public partial class AssetSub : Asset
{
    public AssetSub() { }
    static AssetSub() { }
}
