﻿namespace BN;
[Serializable]
[Table("Price")]
public partial class Markup : Price
{
    public Markup() { }
    static Markup()
    {
        Basic.Add("Price.MarkupBasic", Price.Basic[key: "Price.MarkupBasic"]);
    }
}
