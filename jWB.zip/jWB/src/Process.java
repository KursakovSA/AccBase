public class Process extends Model {
	// origin - 28.09.2023, last edit - 14.10.2023
	public Face face1;
    public Face face2;
    public Face face;
    public Slice slice;
    public Geo geo;
    public Sign sign;
    public Account account;
    public Asset asset;
    public Deal deal;
    public Item item;
    public Debt debt;
    public Price price;
    public Role role;
    public Info info;
    public Meter meter;
    public String meterValue;
    public Unit unit;
    public Mark mark;
}
