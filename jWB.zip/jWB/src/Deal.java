public class Deal extends Model {
	// origin - 28.09.2023, last edit - 14.10.2023
    public Face face1;
    public Face face2;
    public Face face;
    public Geo geo;
    public Role role;
    public Info info;
}