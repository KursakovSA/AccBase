public class AssetDto extends ModelDto {
	// origin - 01.10.2023, last edit - 14.10.2023
	public String geo;
    public String role;
    public String info;
    public String unit;
}
