public class ModelDto {
	// origin - 30.09.2023, last edit - 14.10.2023
	public String id;
	public String parent;
	public String date1;
	public String date2;
	public String code;
	public String description;
	public String more;

	public static void test() {
		// origin - 30.09.2023, last edit - 14.10.2023
		try {
			WB.addEvent(new AccountDto(), "AccountDto", "ModelDto.test()");
			WB.addEvent(new AssetDto(), "AssetDto", "ModelDto.test()");
			WB.addEvent(new DealDto(), "DealDto", "ModelDto.test()");
			WB.addEvent(new DebtDto(), "DebtDto", "ModelDto.test()");
			WB.addEvent(new FaceDto(), "FaceDto", "ModelDto.test()");
			WB.addEvent(new GeoDto(), "GeoDto", "Modeldto.test()");
			WB.addEvent(new InfoDto(), "InfoDto", "ModelDto.test()");
			WB.addEvent(new ItemDto(), "ItemDto", "ModelDto.test()");
			WB.addEvent(new MarkDto(), "MarkDto", "ModelDto.test()");
			WB.addEvent(new MeterDto(), "MeterDto", "ModelDto.test()");
			WB.addEvent(new PriceDto(), "PriceDto", "ModelDto.test()");
			WB.addEvent(new ProcessDto(), "ProcessDto", "ModelDto.test()");
			WB.addEvent(new RoleDto(), "RoleDto", "ModelDto.test()");
			WB.addEvent(new SignDto(), "SignDto", "ModelDto.test()");
			WB.addEvent(new SliceDto(), "SliceDto", "ModelDto.test()");
			WB.addEvent(new UnitDto(), "UnitDto", "ModelDto.test()");
			WB.addEvent(new WorkbookDto(), "WorkbookDto", "ModelDto.test()");
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		} finally {
		}
	}

	public String toString() {
		// origin - 30.09.2023, last edit - 14.09.2023
		return this.getClass().getName() + "{" + "id='" + id + '\'' + ", code=" + code + ", description=" + description
				+ '}';
	}
}
