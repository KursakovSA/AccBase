public class ProcessDto extends ModelDto {
	// origin - 01.10.2023, last edit - 14.10.2023
	public String face1;
    public String face2;
    public String face;
    public String slice;
    public String geo;
    public String sign;
    public String account;
    public String asset;
    public String deal;
    public String item;
    public String debt;
    public String price;
    public String role;
    public String info;
    public String meter;
    public String meterValue;
    public String unit;
    public String mark;
}
